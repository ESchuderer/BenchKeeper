'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { launch, appBase } = require('./helpers.js');
const D = require('../../js/drawing.js');
const data = require('../../js/data.js');

let browser, app;
test.before(async () => { browser = await launch(); app = await appBase(); });
test.after(async () => { await browser.close(); app.close(); });

async function openPrint(hash, scheme = 'light') {
  const ctx = await browser.newContext({ viewport: { width: 1100, height: 900 }, colorScheme: scheme });
  const page = await ctx.newPage();
  await page.goto(app.base + hash);
  await page.getByRole('heading', { level: 1 }).waitFor();
  await page.emulateMedia({ media: 'print', colorScheme: scheme });
  return { ctx, page };
}

const pageCount = (buf) => (buf.toString('latin1').match(/\/Type\s*\/Page[^s]/g) || []).length;

test('print hides navigation, search and buttons, shows header, drawing, tables and footer', async () => {
  const { ctx, page } = await openPrint('#/cartridge/308_win');
  const shown = (sel) => page.locator(sel).first().isVisible();
  assert.equal(await shown('button'), false);
  assert.equal(await page.getByRole('link', { name: 'All cartridges' }).isVisible(), false);
  assert.equal(await shown('header.site'), false);
  assert.equal(await shown('h1'), true);
  assert.equal(await shown('svg.cartridge-drawing'), true);
  assert.equal(await shown('table.values'), true);
  assert.match(await page.locator('.site-foot').textContent(), /Source: C\.I\.P\. TDCC, revised 2008-09-23/);
  assert.equal(await page.locator('.site-foot').isVisible(), true);
  await ctx.close();
});

test('the start page prints without its controls too', async () => {
  const { ctx, page } = await openPrint('');
  assert.equal(await page.getByLabel('Search').isVisible(), false);
  assert.equal(await page.getByLabel('Family').isVisible(), false);
  await ctx.close();
});

test('print is black on white even when the system is dark', async () => {
  const { ctx, page } = await openPrint('#/cartridge/308_win', 'dark');
  const c = await page.evaluate(() => {
    const cs = (el) => getComputedStyle(el);
    return {
      bg: cs(document.body).backgroundColor, ink: cs(document.body).color,
      outline: cs(document.querySelector('path.outline')).stroke,
      dim: cs(document.querySelector('line.dim')).stroke,
      label: cs(document.querySelector('text.dim-label')).fill,
      th: cs(document.querySelector('table.values thead th')).color
    };
  });
  assert.equal(c.bg, 'rgb(255, 255, 255)');
  for (const k of ['ink', 'outline', 'dim', 'label', 'th']) assert.equal(c[k], 'rgb(0, 0, 0)', k);
  await ctx.close();
});

test('the drawing is as wide as the content area of A4 and its labels are at least 6 pt', async () => {
  const { ctx, page } = await openPrint('#/cartridge/308_win');
  const mm = await page.evaluate(() => {
    const svg = document.querySelector('svg.cartridge-drawing');
    const r = svg.getBoundingClientRect();
    const vbw = +svg.dataset.vbw;
    const label = svg.querySelector('text.dim-label');
    const fontUnits = parseFloat(getComputedStyle(label).fontSize); // user units
    return { w: r.width * 25.4 / 96, vbw, pt: fontUnits * (r.width / vbw) * 25.4 / 96 / 0.3528 };
  });
  // A4 portrait, 12 mm margins -> 186 mm
  assert.ok(Math.abs(mm.w - 186) < 0.8, `width ${mm.w} mm`);
  assert.ok(mm.pt >= 6, `${mm.pt} pt`);
  await ctx.close();
});

test('the printed scale is the printed drawing width over its content width', async () => {
  const { ctx, page } = await openPrint('#/cartridge/308_win');
  const shown = await page.evaluate(() => {
    const t = [...document.querySelectorAll('svg.cartridge-drawing text')].filter((e) => getComputedStyle(e).display !== 'none' && /^Scale /.test(e.textContent));
    const svg = document.querySelector('svg.cartridge-drawing');
    return { texts: t.map((e) => e.textContent), wmm: svg.getBoundingClientRect().width * 25.4 / 96, vbw: +svg.dataset.vbw };
  });
  assert.equal(shown.texts.length, 1);
  const s = shown.wmm / shown.vbw;
  assert.equal(shown.texts[0], 'Scale ' + D.formatScale(s));
  await ctx.close();
});

test('every cartridge prints on exactly one A4 portrait page', async () => {
  const ctx = await browser.newContext({ viewport: { width: 1100, height: 900 } });
  const page = await ctx.newPage();
  await page.goto(app.base);
  const keys = await page.locator('main table a').evaluateAll((as) => as.map((a) => a.getAttribute('href')));
  const failures = [];
  for (const href of keys) {
    await page.evaluate((h) => { location.hash = h; }, href);
    await page.locator('svg.cartridge-drawing').waitFor();
    const buf = await page.pdf({ format: 'A4', portrait: true, printBackground: true, preferCSSPageSize: true });
    const n = pageCount(buf);
    if (n !== 1) failures.push(`${href}: ${n} pages`);
  }
  assert.deepEqual(failures, []);
  await ctx.close();
});

test('content never overlaps the fixed footer (the last table ends above it)', async () => {
  const ctx = await browser.newContext({ viewport: { width: 794, height: 1123 } });
  const page = await ctx.newPage();
  await page.goto(app.base + '#/cartridge/338_lapua_mag');
  await page.locator('svg.cartridge-drawing').waitFor();
  await page.emulateMedia({ media: 'print' });
  const r = await page.evaluate(() => {
    const foot = document.querySelector('.site-foot').getBoundingClientRect().top;
    const last = Math.max(...[...document.querySelectorAll('table.values')].map((t) => t.getBoundingClientRect().bottom));
    return { foot, last };
  });
  assert.ok(r.last <= r.foot + 1, JSON.stringify(r));
  await ctx.close();
});

test('data sanity for the print scale helper', () => {
  assert.ok(data.length === 25);
});
