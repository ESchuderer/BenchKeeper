'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const data = require('../../js/data.js');

const KEYS = ['223_rem', '243_win', '6_5_creedmoor', '6_5_x_55_se', '270_win', '7_x_64', '308_win',
  '30_06_spring', '8_x_57_is', '9_3_x_62', '7_62_x_39', '338_lapua_mag', '300_win_mag', '7_mm_rem_mag',
  '9_3_x_74_r', '7_x_65_r', '9_mm_luger', '45_auto', '40_s_w', '38_special', '357_magnum', '44_rem_mag',
  '22_long_rifle', '22_win_mag_r_f', '17_hmr'];

const byKey = (k) => data.find((r) => r.key === k);

test('holds exactly the 25 records in published order', () => {
  assert.equal(data.length, 25);
  assert.deepEqual(data.map((r) => r.key), KEYS);
});

test('family counts are 12 rimless, 2 rimmed, 2 belted, 6 pistol, 3 rimfire', () => {
  const n = (f) => data.filter((r) => r.family === f).length;
  assert.deepEqual([n('rimless'), n('rimmed'), n('belted'), n('pistol'), n('rimfire')], [12, 2, 2, 6, 3]);
});

test('every record has the fields the app relies on', () => {
  for (const r of data) {
    for (const f of ['key', 'name', 'family', 'country', 'tab', 'published', 'revised', 'pressureMethod']) {
      assert.equal(typeof r[f], 'string', `${r.key}.${f}`);
    }
    assert.equal(typeof r.cartridge.lengths.L3, 'number', `${r.key} L3`);
    assert.ok(r.annotations.category && r.annotations.primerType && r.annotations.defaultBulletShape, r.key);
    assert.ok(r.chamber && typeof r.chamber === 'object', r.key);
  }
});

test('names are kept as published', () => {
  assert.equal(byKey('6_5_creedmoor').name, '6,5 Creedmoor');
  assert.equal(byKey('40_s_w').name, '40 S.& W.');
  assert.equal(byKey('22_win_mag_r_f').name, '22 Win. Mag. R.F.');
  assert.deepEqual(byKey('308_win').alternativeNames, ['308 Winchester', '7,62 x 51']);
  assert.equal(byKey('223_rem').alternativeNames, undefined);
});

test('spot checks of numbers, tolerances and angles', () => {
  const w = byKey('308_win');
  assert.equal(w.cartridge.lengths.L3, 51.18);
  assert.equal(w.cartridge.lengths.L2Tol, -0.2);
  assert.equal(w.cartridge.lengths.L1Tol, undefined);
  assert.equal(byKey('223_rem').cartridge.lengths.L1Tol, -0.2);
  assert.equal(w.cartridge.pressures.Pmax, 4150);
  assert.equal(w.annotations.publishedCapacity.grH2O, 56);
  assert.deepEqual(byKey('6_5_x_55_se').cartridge.junctionCone.alpha, { degrees: 50, minutes: 35, seconds: 2 });
  assert.equal(byKey('243_win').cartridge.junctionCone.alpha, 40);
  assert.equal(byKey('7_mm_rem_mag').chamber.rifling.i, 3);
  assert.equal(byKey('300_win_mag').cartridge.caseHead.ETol, -0.2);
  assert.equal(byKey('9_mm_luger').cartridge.lengths.L3Tol, -0.25);
  assert.equal(byKey('22_long_rifle').cartridge.caseHead.beta, 0);
  assert.equal(byKey('7_x_64').annotations.publishedCapacity, undefined);
  assert.equal(byKey('17_hmr').annotations.defaultBulletShape, 'pointy');
  assert.equal(byKey('223_rem').chamber.rifling.i.seconds, 36);
});

test('every record is plain JSON data (round-trips unchanged)', () => {
  assert.deepEqual(JSON.parse(JSON.stringify(data)), data);
});
