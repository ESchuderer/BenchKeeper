'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const data = require('../../js/data.js');
const D = require('../../js/drawing.js');

const rec = (k) => data.find((r) => r.key === k);
const draw = (k) => D.renderDrawing(rec(k));

test('inline SVG with the accessible name "<name> drawing"', () => {
  const d = draw('308_win');
  assert.match(d.svg, /^<svg /);
  assert.match(d.svg, /role="img"/);
  assert.match(d.svg, /aria-label="308 Win\. drawing"/);
  assert.match(d.svg, /viewBox="[-\d.]+ [-\d.]+ [\d.]+ [\d.]+"/);
  assert.ok(!/ (width|height)="/.test(d.svg.split('>')[0]), 'sized by CSS, not by attributes');
});

test('names are escaped (40 S.& W.)', () => {
  const d = draw('40_s_w');
  assert.match(d.svg, /aria-label="40 S\.&amp; W\. drawing"/);
  assert.ok(!/S\.& W/.test(d.svg));
  assert.match(d.svg, />40 S\.&amp; W\.</);
});

test('1 user unit = 1 mm: the L3 extension line sits at x = 51.18', () => {
  const d = draw('308_win');
  assert.match(d.svg, /x1="51\.18"/);
  assert.match(d.svg, /x1="71\.12"/);
});

test('labels are text elements with symbol and value', () => {
  const d = draw('308_win');
  for (const t of ['L3 51.18', 'L6 71.12', 'R1 12.01', 'R 1.37', 'P1 11.96', 'P2 11.53', 'H1 8.72', 'H2 8.72', 'G1 7.85', 'L1 39.62', 'L2 43.48', 'E1 10.39', 'α 40°']) {
    assert.ok(d.svg.includes('>' + t + '</text>'), t);
  }
});

test('title block: name, table, revision, units and scale', () => {
  const d = draw('308_win');
  for (const t of ['308 Win.', 'C.I.P. table I', 'Revised 2008-09-23', 'Dimensions in mm']) assert.ok(d.svg.includes('>' + t + '</text>'), t);
  const m = /class="[^"]*scale-print[^"]*"[^>]*>(Scale [\d.]+:1)</.exec(d.svg);
  assert.ok(m, 'print scale');
  const printScale = D.CONST.PRINT_WIDTH_MM / d.viewBox.w;
  assert.equal(m[1], 'Scale ' + D.formatScale(printScale));
  assert.match(d.svg, /class="[^"]*scale-screen[^"]*"/);
});

test('scale formatting', () => {
  assert.equal(D.formatScale(2.14), '2.1:1');
  assert.equal(D.formatScale(2), '2:1');
  assert.equal(D.formatScale(1), '1:1');
  assert.equal(D.formatScale(0.5), '1:2');
  assert.equal(D.formatScale(0.4), '1:2.5');
});

test('hatching only in the section (lower half)', () => {
  const d = draw('308_win');
  const m = /<path class="cut"[^>]* d="([^"]+)"/.exec(d.svg);
  assert.ok(m, 'cut path');
  const nums = m[1].match(/-?\d+(\.\d+)?/g).map(Number);
  for (let i = 1; i < nums.length; i += 2) assert.ok(nums[i] >= -1e-9, 'y >= 0');
  assert.match(d.svg, /<pattern id="hatch-308_win"/);
  assert.match(d.svg, /fill="url\(#hatch-308_win\)"/);
});

test('viewBox is at least 1.7 : 1 so that small cartridges stay short when printed full width', () => {
  for (const r of data) {
    const d = D.renderDrawing(r);
    assert.ok(d.viewBox.w / d.viewBox.h >= 1.7 - 1e-9, `${r.key} ${d.viewBox.w}x${d.viewBox.h}`);
    assert.ok(d.viewBox.w > 0 && d.viewBox.h > 0);
  }
});

test('no NaN or undefined leaks into any drawing; every drawing has notes as an array', () => {
  for (const r of data) {
    const d = D.renderDrawing(r);
    assert.ok(!/NaN|undefined|Infinity/.test(d.svg), r.key);
    assert.ok(Array.isArray(d.notes), r.key);
  }
});

test('notes of the model are passed on', () => {
  assert.ok(draw('38_special').notes.some((n) => /groove/i.test(n)));
  assert.deepEqual(draw('308_win').notes, []);
});

test('unavailable drawing says why and has no svg', () => {
  const r = JSON.parse(JSON.stringify(rec('308_win')));
  delete r.cartridge.lengths.L3;
  const d = D.renderDrawing(r);
  assert.equal(d.svg, '');
  assert.match(d.notes.join(' '), /L3/);
});

test('print scale for 308 Win. is a sensible enlargement and labels stay >= 6 pt on A4', () => {
  const d = draw('308_win');
  const s = D.CONST.PRINT_WIDTH_MM / d.viewBox.w;
  assert.ok(s > 1.2 && s < 4, String(s));
  for (const r of data) {
    const dd = D.renderDrawing(r);
    const mmPerUnit = D.CONST.PRINT_WIDTH_MM / dd.viewBox.w;
    const pt = D.CONST.FONT * mmPerUnit / 0.3528;
    assert.ok(pt >= 6, `${r.key}: ${pt.toFixed(1)} pt`);
  }
});

test('a record without name, table or revision still draws, without printing "undefined"', () => {
  const r = JSON.parse(JSON.stringify(rec('308_win')));
  delete r.name; delete r.tab; delete r.revised;
  let d;
  assert.doesNotThrow(() => { d = D.renderDrawing(r); });
  assert.ok(d.svg.length > 0);
  assert.ok(!/undefined|NaN/.test(d.svg));
});

test('hostile numbers never leak into the SVG', () => {
  for (const [sec, f, v] of [['lengths', 'L3', 0], ['caseHead', 'E', 1e6], ['powderChamber', 'P1', 1e6], ['lengths', 'L6', Infinity], ['projectile', 'G1', -3]]) {
    const r = JSON.parse(JSON.stringify(rec('308_win')));
    r.cartridge[sec][f] = v;
    const d = D.renderDrawing(r);
    assert.ok(!/NaN|Infinity|undefined/.test(d.svg), sec + '.' + f);
    if (d.svg) assert.ok(d.viewBox && Object.values(d.viewBox).every(Number.isFinite), sec + '.' + f);
  }
});
