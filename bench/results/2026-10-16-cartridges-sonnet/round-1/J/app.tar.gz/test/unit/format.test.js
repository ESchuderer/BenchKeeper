'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const F = require('../../js/format.js');

test('numbers print as published: decimal point, no separators, no trailing .0', () => {
  assert.equal(F.formatNumber(4150.0), '4150');
  assert.equal(F.formatNumber(51.18), '51.18');
  assert.equal(F.formatNumber(0.5), '0.5');
  assert.equal(F.formatNumber(-0.25), '-0.25');
  assert.equal(F.formatNumber(305), '305');
  assert.equal(F.formatNumber(10000), '10000');
});

test('angles: plain degrees and degrees-minutes-seconds', () => {
  assert.equal(F.formatAngle(40), '40°');
  assert.equal(F.formatAngle(0), '0°');
  assert.equal(F.formatAngle({ degrees: 39, minutes: 59, seconds: 49 }), '39°59\'49"');
  assert.equal(F.formatAngle({ degrees: 34, minutes: 30, seconds: 0 }), '34°30\'0"');
  assert.equal(F.formatAngle({ degrees: 0, minutes: 42, seconds: 29 }), '0°42\'29"');
});

test('angle to decimal degrees', () => {
  assert.equal(F.toDegrees(35), 35);
  assert.ok(Math.abs(F.toDegrees({ degrees: 50, minutes: 35, seconds: 2 }) - 50.58388888) < 1e-6);
  assert.equal(F.toDegrees(undefined), undefined);
  assert.equal(F.toDegrees('x'), undefined);
});

test('tolerances carry their sign', () => {
  assert.equal(F.formatTolerance(-0.2), '-0.2');
  assert.equal(F.formatTolerance(0.1), '+0.1');
  assert.equal(F.formatTolerance(-0.25), '-0.25');
});

test('which fields are angles', () => {
  for (const f of ['alpha', 'alpha1', 'beta', 'delta', 'i']) assert.ok(F.isAngleField(f), f);
  for (const f of ['deltaL', 'L1', 'h', 's', 'G', 'u', 'r', 'R']) assert.ok(!F.isAngleField(f), f);
});

test('symbols are the field name except the listed ones', () => {
  const expected = {
    eMin: 'e min', r1Min: 'r1 min', r1Max: 'r1 max', alpha: 'α', alpha1: 'α1', beta: 'β', delta: 'δ',
    deltaL: 'delta L', L3PlusG: 'L3 + G', L3: 'L3', Pmax: 'Pmax', R1: 'R1', Fe: 'Fe', i: 'i', G1: 'G1'
  };
  for (const [k, v] of Object.entries(expected)) assert.equal(F.symbolFor(k), v, k);
});

test('units', () => {
  assert.equal(F.unitFor('Pmax'), 'bar');
  assert.equal(F.unitFor('PK'), 'bar');
  assert.equal(F.unitFor('PE'), 'bar');
  assert.equal(F.unitFor('EE'), 'J');
  assert.equal(F.unitFor('M'), 'g');
  assert.equal(F.unitFor('Q'), 'mm²');
  assert.equal(F.unitFor('N'), '');
  for (const f of ['alpha', 'alpha1', 'beta', 'delta', 'i']) assert.equal(F.unitFor(f), '°', f);
  for (const f of ['L3', 'R1', 'u', 'deltaL', 'G1', 'h']) assert.equal(F.unitFor(f), 'mm', f);
});

test('value cell: value with tolerance beside it', () => {
  assert.equal(F.formatCell('L1', 36.52, -0.2), '36.52 -0.2');
  assert.equal(F.formatCell('L1', 39.62), '39.62');
  assert.equal(F.formatCell('alpha', 46), '46°');
  assert.equal(F.formatCell('alpha', { degrees: 50, minutes: 35, seconds: 2 }), '50°35\'2"');
  assert.equal(F.formatCell('Pmax', 4150), '4150');
});

test('non-finite angle parts are treated as absent, not printed', () => {
  assert.equal(F.formatAngle({ degrees: 10, minutes: Infinity, seconds: NaN }), '10°0\'0"');
  assert.equal(F.toDegrees({ degrees: 10, minutes: Infinity }), 10);
  assert.equal(F.toDegrees({ degrees: NaN }), undefined);
});
