'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const data = require('../../js/data.js');
const G = require('../../js/geometry.js');

const rec = (k) => data.find((r) => r.key === k);
const clone = (k, mutate) => { const r = JSON.parse(JSON.stringify(rec(k))); mutate(r); return r; };
const near = (a, b, tol = 1e-3, msg) => assert.ok(Math.abs(a - b) <= tol, `${msg || ''} ${a} vs ${b}`);
const pt = (p, r, z, tol = 1e-3) => { near(p[0], r, tol, 'r'); near(p[1], z, tol, 'z'); };
const has = (pts, r, z, tol = 1.5e-3) => pts.some((p) => Math.abs(p[0] - r) <= tol && Math.abs(p[1] - z) <= tol);
const dist = (a, b) => Math.hypot(a[0] - b[0], a[1] - b[1]);
const noteText = (m) => m.notes.join(' | ');

/* ---------- rim type ---------- */

test('rim type', () => {
  assert.equal(G.rimType(rec('300_win_mag')), 'belted');
  assert.equal(G.rimType(rec('22_long_rifle')), 'rimfire');
  assert.equal(G.rimType(rec('38_special')), 'rimmed');
  assert.equal(G.rimType(rec('308_win')), 'rimless');
  assert.equal(G.rimType(clone('308_win', (r) => { r.cartridge.caseHead.R1 = 11.5; })), 'rebated'); // 11.5/11.96 < 0.98
  assert.equal(G.rimType(clone('308_win', (r) => { r.cartridge.caseHead.R1 = 12.558; })), 'rimmed'); // exactly 1.05
});

/* ---------- head face, rim edge, groove ---------- */

test('308 Win.: chamfer and groove points, in order', () => {
  const m = G.buildModel(rec('308_win'));
  assert.equal(m.ok, true);
  const o = m.outer;
  pt(o[0], 0, 0);
  pt(o[1], 5.739, 0);
  pt(o[2], 6.005, 0.38);
  pt(o[3], 6.005, 1.37);
  pt(o[4], 5.195, 1.37);
  pt(o[5], 5.195, 2.77);
  pt(o[6], 5.98, 3.85);
  assert.equal(m.rimType, 'rimless');
});

test('chamfer extent is limited to R1/4', () => {
  const m = G.buildModel(clone('308_win', (r) => { r.cartridge.caseHead.f = 10; r.cartridge.caseHead.R = 12; r.cartridge.caseHead.E = 20; r.cartridge.caseHead.beta = 80; }));
  near(m.outer[1][0], 12.01 / 2 - 12.01 / 4, 1e-9);
});

test('no chamfer when beta is 90 or more: square corner', () => {
  const m = G.buildModel(clone('308_win', (r) => { r.cartridge.caseHead.beta = 90; }));
  pt(m.outer[1], 6.005, 0);
  pt(m.outer[2], 6.005, 1.37);
});

test('rimfire rim edge is a half-round of radius min(R/2, (R1-P1)/2)', () => {
  const m = G.buildModel(rec('22_long_rifle'));
  assert.equal(m.rimType, 'rimfire');
  const arc = m.outer.filter((p) => p[1] <= 1.09 + 1e-9 && p[1] >= 0 && p[0] > 2.9);
  near(Math.max(...arc.map((p) => p[0])), 3.53, 1e-9, 'outermost r');
  const c = [3.53 - 0.545, 0.545];
  for (const p of m.outer.slice(1)) if (p[0] > 2.99 && p[1] <= 1.09) near(dist(p, c), 0.545, 1e-6, 'on arc');
  pt(m.outer[1], 3.53 - 0.545, 0);
  assert.ok(has(m.outer, 2.87, 1.09), 'steps in to P1/2 at z = R');
});

test('rimfire radius is limited by (R1 - P1)/2 when that is smaller', () => {
  const m = G.buildModel(clone('22_long_rifle', (r) => { r.cartridge.caseHead.R = 3; }));
  const maxR = Math.max(...m.outer.map((p) => p[0]));
  near(maxR, 3.53, 1e-9);
  const rho = (7.06 - 5.74) / 2;
  pt(m.outer[1], 3.53 - rho, 0);
});

test('square corner without beta and f', () => {
  const m = G.buildModel(rec('9_3_x_74_r'));
  const sq = G.buildModel(clone('308_win', (r) => { delete r.cartridge.caseHead.beta; delete r.cartridge.caseHead.f; }));
  pt(sq.outer[1], 6.005, 0);
  pt(sq.outer[2], 6.005, 1.37);
  assert.match(noteText(sq), /chamfer.*beta.*f|chamfer.*β.*f/i);
  assert.ok(m.outer.length > 3);
});

test('missing f only: square head, note names f', () => {
  const m = G.buildModel(clone('308_win', (r) => { delete r.cartridge.caseHead.f; }));
  pt(m.outer[1], 6.005, 0);
  assert.match(noteText(m), /chamfer not drawn: f /i);
});

test('rimfire without f gets no chamfer note', () => {
  const m = G.buildModel(rec('22_long_rifle'));
  assert.doesNotMatch(noteText(m), /chamfer/i);
});

test('belted: ramp at delta to R3/2, belt to E, step in to P1/2', () => {
  const m = G.buildModel(rec('300_win_mag'));
  assert.equal(m.rimType, 'belted');
  const o = m.outer;
  assert.ok(has(o, 6.035, 1.27), 'groove wall');
  assert.ok(has(o, 6.035, 2.21), 'floor end');
  assert.ok(has(o, 6.755, 3.238), 'belt ramp end');
  assert.ok(has(o, 6.755, 5.59), 'belt end');
  assert.ok(has(o, 6.515, 5.59), 'step in to P1/2');
  near(m.belt.rampEndZ, 3.238, 1e-3);
});

test('38 Special: no groove, steps in at z = R, notes name the missing values', () => {
  const m = G.buildModel(rec('38_special'));
  assert.equal(m.rimType, 'rimmed');
  assert.equal(m.groove, null);
  const i = m.outer.findIndex((p) => Math.abs(p[0] - 11.18 / 2) < 1e-9 && Math.abs(p[1] - 1.5) < 1e-9);
  assert.ok(i > 0);
  pt(m.outer[i + 1], 9.63 / 2, 1.5);
  assert.match(noteText(m), /groove not drawn: E, E1 and e min/i);
});

test('groove needs e min: missing eMin drops the groove and says so', () => {
  const m = G.buildModel(clone('308_win', (r) => { delete r.cartridge.caseHead.eMin; }));
  assert.equal(m.groove, null);
  assert.match(noteText(m), /e min/);
});

test('belt without R3 keeps the plain groove and says so', () => {
  const m = G.buildModel(clone('300_win_mag', (r) => { delete r.cartridge.caseHead.R3; }));
  assert.ok(m.groove);
  assert.equal(m.belt, null);
  assert.match(noteText(m), /belt not drawn: R3/i);
});

/* ---------- body, shoulder, neck ---------- */

test('308 Win.: bottleneck with rounded shoulder corners', () => {
  const m = G.buildModel(rec('308_win'));
  const s = m.shoulder;
  pt(s.A, 5.765, 39.62);
  pt(s.B, 4.36, 43.48);
  assert.equal(s.filletA.radius, 0.76);
  assert.equal(s.filletB.radius, 3.18);
  pt(m.outer[m.outer.length - 1], 4.36, 51.18);
  pt(m.mouth, 4.36, 51.18);
  // the straight shoulder segment between the two tangent points lies on the line A-B
  const t1 = s.filletA.t2, t2 = s.filletB.t1;
  const cross = (t2[0] - t1[0]) * (s.B[1] - s.A[1]) - (t2[1] - t1[1]) * (s.B[0] - s.A[0]);
  near(cross, 0, 1e-6, 'collinear');
  // arcs: tangent points are at radius from the centre and the arc points lie on the circle
  for (const f of [s.filletA, s.filletB]) {
    near(dist(f.center, f.t1), f.radius, 1e-6);
    near(dist(f.center, f.t2), f.radius, 1e-6);
  }
  // body line direction is perpendicular to the radius at the first tangent point
  const body = [s.filletA.t1[0] - 5.98, s.filletA.t1[1] - 3.85];
  const rad = [s.filletA.t1[0] - s.filletA.center[0], s.filletA.t1[1] - s.filletA.center[1]];
  near(body[0] * rad[0] + body[1] * rad[1], 0, 1e-6, 'tangent');
  // the sharp corners are cut: neither is on the outline, both are within the fillet reach
  assert.ok(!has(m.outer, 5.765, 39.62, 1e-4));
});

test('alpha is only a label: the line is drawn through the published points', () => {
  const m = G.buildModel(clone('308_win', (r) => { r.cartridge.junctionCone.alpha = 10; }));
  pt(m.shoulder.A, 5.765, 39.62);
  pt(m.shoulder.B, 4.36, 43.48);
  assert.equal(m.shoulder.alpha, 10);
});

test('no rounding without r1 min / r2, with a note', () => {
  const m = G.buildModel(rec('338_lapua_mag')); // no r1Min
  assert.equal(m.shoulder.filletA, null);
  assert.ok(m.shoulder.filletB);
  assert.match(noteText(m), /body-side shoulder corner not rounded: r1 min/i);
  assert.ok(has(m.outer, 13.82 / 2, 54.9), 'sharp corner point is on the outline');
});

test('fillet is limited to fit on the shoulder (6,5 x 55 SE, r1 min 3.5, r2 3.7)', () => {
  const m = G.buildModel(rec('6_5_x_55_se'));
  const f = m.shoulder;
  const len = dist(f.A, f.B);
  const da = dist(f.A, f.filletA.t2), db = dist(f.B, f.filletB.t1);
  assert.ok(da + db <= len + 1e-9);
});

test('straight case (9 mm Luger) has no shoulder', () => {
  const m = G.buildModel(rec('9_mm_luger'));
  assert.equal(m.shoulder, null);
  pt(m.outer[m.outer.length - 1], 4.825, 19.15);
  assert.ok(has(m.outer, 4.965, 2.98), 'body starts at the groove ramp end');
  assert.doesNotMatch(noteText(m), /shoulder/i, 'straight by design: not a missing value');
});

test('bottleneck with a value missing becomes straight and names it', () => {
  const m = G.buildModel(clone('308_win', (r) => { delete r.cartridge.lengths.L2; }));
  assert.equal(m.shoulder, null);
  assert.match(noteText(m), /L2/);
  pt(m.outer[m.outer.length - 1], 8.72 / 2, 51.18);
});

test('17 HMR is a bottleneck without fillets', () => {
  const m = G.buildModel(rec('17_hmr'));
  assert.ok(m.shoulder);
  assert.equal(m.shoulder.filletA, null);
  assert.equal(m.shoulder.filletB, null);
  assert.equal(m.rimType, 'rimfire');
});

test('missing core values make the drawing unavailable', () => {
  const m = G.buildModel(clone('308_win', (r) => { delete r.cartridge.lengths.L3; }));
  assert.equal(m.ok, false);
  assert.deepEqual(m.missing, ['L3']);
});

test('outer profile is a function of z beyond the rim: z never decreases after the rim edge', () => {
  for (const r of data) {
    const m = G.buildModel(r);
    assert.ok(m.ok, r.key);
    let zmax = -1;
    for (const p of m.outer) { assert.ok(p[1] >= zmax - 1e-9, `${r.key} z decreasing at ${p}`); zmax = Math.max(zmax, p[1]); }
    pt(m.outer[0], 0, 0);
    near(m.outer[m.outer.length - 1][1], r.cartridge.lengths.L3, 1e-9);
  }
});

/* ---------- bullet ---------- */

test('308 Win.: pointy bullet', () => {
  const b = G.buildModel(rec('308_win')).bullet;
  assert.equal(b.shape, 'pointy');
  near(b.s, 7.85, 1e-9);
  near(b.zb, 43.33, 1e-9);
  near(b.Lb, 27.79, 1e-9);
  near(b.z0, 54.446, 1e-9);
  near(b.m, 1.27, 1e-9);
  near(b.Rb, 3.925, 1e-9);
  assert.equal(b.heeled, false);
  pt(b.nose[0], 3.925, 54.446);
  pt(b.nose[b.nose.length - 1], 0.635, 71.12);
  // tangent ogive: all nose points lie on a circle of radius rho centred at r = G1/2 - rho, z = z0
  const a = 3.925 - 0.635, n = 71.12 - 54.446;
  const rho = (a * a + n * n) / (2 * a);
  near(b.rho, rho, 1e-9);
  for (const p of b.nose) near(dist(p, [3.925 - rho, 54.446]), rho, 1e-6, 'on ogive');
  // tangent to the cylinder at the start: first segment is (almost) along z
  assert.ok(b.nose[1][0] <= 3.925 + 1e-12);
});

test('9 mm Luger: rounded pistol bullet', () => {
  const b = G.buildModel(rec('9_mm_luger')).bullet;
  near(b.s, 0.4 * 9.03, 1e-9);
  const zb = 19.15 - 0.4 * 9.03;
  near(b.zb, zb, 1e-9);
  near(b.z0, zb + 0.65 * (29.69 - zb), 1e-9);
  near(b.m, 0.15 * 9.03, 1e-9);
  // quarter ellipse centred at (m/2, z0) with semi-axes (G1/2 - m/2) and n
  const a = 9.03 / 2 - b.m / 2, n = 29.69 - b.z0;
  for (const p of b.nose) near(((p[0] - b.m / 2) / a) ** 2 + ((p[1] - b.z0) / n) ** 2, 1, 1e-9, 'on ellipse');
  pt(b.nose[b.nose.length - 1], b.m / 2, 29.69);
});

test('rifle rounded and flat, rimfire and semi-wadcutter parameters', () => {
  const rifleRound = G.buildModel(clone('308_win', (r) => { r.annotations.defaultBulletShape = 'rounded'; })).bullet;
  near(rifleRound.s, 0.8 * 7.85, 1e-9);
  near(rifleRound.k, 0.55, 1e-12);
  const rifleFlat = G.buildModel(clone('308_win', (r) => { r.annotations.defaultBulletShape = 'flat'; })).bullet;
  near(rifleFlat.k, 0.6, 1e-12);
  near(rifleFlat.m, 0.55 * 7.85, 1e-9);
  const pistolFlat = G.buildModel(rec('40_s_w')).bullet;
  assert.equal(pistolFlat.shape, 'flat');
  near(pistolFlat.s, 0.4 * 10.17, 1e-9);
  near(pistolFlat.k, 0.7, 1e-12);
  for (let i = 1; i < pistolFlat.nose.length; i++) { // straight cone
    const c = (pistolFlat.nose[i][0] - pistolFlat.nose[0][0]) * (pistolFlat.nose[1][1] - pistolFlat.nose[0][1]) -
      (pistolFlat.nose[i][1] - pistolFlat.nose[0][1]) * (pistolFlat.nose[1][0] - pistolFlat.nose[0][0]);
    near(c, 0, 1e-9);
  }
  const swc = G.buildModel(rec('357_magnum')).bullet;
  assert.equal(swc.shape, 'semi_wadcutter');
  near(swc.s, 0.6 * 9.12, 1e-9);
  near(swc.k, 0.78, 1e-12);
  near(swc.m, 0.6 * 9.12, 1e-9);
  const rimfireRound = G.buildModel(rec('22_win_mag_r_f')).bullet;
  near(rimfireRound.s, 0.8 * 5.7, 1e-9);
  near(rimfireRound.k, 0.55, 1e-12);
  const pistolRound = G.buildModel(rec('45_auto')).bullet;
  near(pistolRound.k, 0.65, 1e-12);
});

test('22 Long Rifle is heeled: exposed bullet at the case outside diameter, heel at the inside diameter', () => {
  const m = G.buildModel(rec('22_long_rifle'));
  const b = m.bullet;
  assert.equal(b.heeled, true);
  near(b.Rb, 2.86, 1e-9);
  near(b.Rseat, 2.26, 1e-9);
  near(m.walls.tb, 0.6, 1e-9);
  near(m.walls.tnEff, m.walls.tb, 1e-12);
  pt(b.profile[0], 2.26, 15.57 - 0.8 * 5.72);
  assert.ok(has(b.profile, 2.26, 15.57), 'heel up to the mouth');
  assert.ok(has(b.profile, 2.86, 15.57), 'steps out to the case diameter at the mouth');
});

test('outside view hides the seated part', () => {
  const m = G.buildModel(rec('308_win'));
  for (const p of m.bullet.exposed) assert.ok(p[1] >= 51.18 - 1e-9);
  pt(m.bullet.exposed[0], 3.925, 51.18);
  pt(m.bullet.exposed[m.bullet.exposed.length - 1], 0.635, 71.12);
  assert.ok(m.bullet.profile[0][1] < 51.18);
  near(m.bullet.profile[0][1], 43.33, 1e-9);
});

test('missing G1: no bullet, no walls, notes name G1', () => {
  const m = G.buildModel(clone('308_win', (r) => { delete r.cartridge.projectile.G1; }));
  assert.equal(m.bullet, null);
  assert.equal(m.walls, null);
  assert.equal(m.inner, null);
  assert.match(noteText(m), /G1/);
});

test('missing L6: no bullet but walls are drawn', () => {
  const m = G.buildModel(clone('308_win', (r) => { delete r.cartridge.lengths.L6; }));
  assert.equal(m.bullet, null);
  assert.ok(m.walls);
  assert.match(noteText(m), /bullet not drawn: L6/i);
});

test('rounded bullet without a category is not drawn and says so', () => {
  const m = G.buildModel(clone('9_mm_luger', (r) => { delete r.annotations.category; }));
  assert.equal(m.bullet, null);
  assert.match(noteText(m), /category/);
});

test('unknown bullet shape is not drawn and says so', () => {
  const m = G.buildModel(clone('9_mm_luger', (r) => { r.annotations.defaultBulletShape = 'banana'; }));
  assert.equal(m.bullet, null);
  assert.match(noteText(m), /defaultBulletShape/);
});

/* ---------- section ---------- */

test('308 Win.: walls, solid head and pocket', () => {
  const m = G.buildModel(rec('308_win'));
  near(m.walls.tn, 0.435, 1e-9);
  near(m.walls.tb, 0.6, 1e-9);
  near(m.w, 4.8, 1e-9);
  assert.deepEqual(m.pocket, { d: 5.33, depth: 3.3 });
  const cs = m.section.caseSection;
  assert.ok(has(cs, 2.665, 3.3), 'pocket corner');
  assert.ok(has(cs, 0, 3.3), 'pocket bottom on axis');
  assert.ok(has(cs, 0, 4.8), 'solid head end on axis');
  assert.ok(has(cs, 2.665, 0), 'head face starts at the pocket edge');
  // inner line: tb along the body, tn along the neck
  const inner = m.inner;
  pt(inner[0], 5.98 - (5.98 - 5.765) * (4.8 - 3.85) / (39.62 - 3.85) - 0.6, 4.8, 2e-3);
  pt(inner[inner.length - 1], 3.925, 51.18);
  assert.ok(inner.every((p, i) => i === 0 || p[1] >= inner[i - 1][1] - 1e-9));
});

test('wall blends linearly across the shoulder', () => {
  const m = G.buildModel(rec('308_win'));
  const mid = (39.62 + 43.48) / 2;
  const outerR = (z) => { for (let i = 1; i < m.outer.length; i++) { const a = m.outer[i - 1], b = m.outer[i]; if (z >= a[1] && z <= b[1] && b[1] > a[1]) return a[0] + (b[0] - a[0]) * (z - a[1]) / (b[1] - a[1]); } };
  const innerR = (z) => { for (let i = 1; i < m.inner.length; i++) { const a = m.inner[i - 1], b = m.inner[i]; if (z >= a[1] && z <= b[1] && b[1] > a[1]) return a[0] + (b[0] - a[0]) * (z - a[1]) / (b[1] - a[1]); } };
  // at mid-shoulder the wall is (tb + tn) / 2 = 0.5175 (outer/inner are piecewise linear; the arcs are far away)
  near(outerR(mid) - innerR(mid), (0.6 + 0.435) / 2, 2e-3, 'mid shoulder wall');
  near(outerR(30) - innerR(30), 0.6, 1e-6, 'body wall');
  near(outerR(47) - innerR(47), 0.435, 1e-6, 'neck wall');
});

test('primer pockets by primer type; rimfire has none', () => {
  assert.deepEqual(G.buildModel(rec('9_mm_luger')).pocket, { d: 4.45, depth: 3.04 }); // sp
  assert.deepEqual(G.buildModel(rec('223_rem')).pocket, { d: 4.45, depth: 3.04 }); // sr
  assert.deepEqual(G.buildModel(rec('45_auto')).pocket, { d: 5.33, depth: 3.04 }); // lp
  assert.deepEqual(G.buildModel(rec('44_rem_mag')).pocket, { d: 5.33, depth: 3.04 }); // lpm
  assert.deepEqual(G.buildModel(rec('357_magnum')).pocket, { d: 4.45, depth: 3.04 }); // spm
  assert.deepEqual(G.buildModel(rec('338_lapua_mag')).pocket, { d: 5.33, depth: 3.3 }); // lrm
  assert.deepEqual(G.buildModel(rec('9_3_x_62')).pocket, { d: 5.33, depth: 3.3 }); // lr
  for (const k of ['22_long_rifle', '22_win_mag_r_f', '17_hmr']) {
    const m = G.buildModel(rec(k));
    assert.equal(m.pocket, null, k);
    near(m.w, 2.5, 1e-9, k + ' w');
  }
});

test('unknown primer type on a centrefire case: no pocket and a note', () => {
  const m = G.buildModel(clone('308_win', (r) => { r.annotations.primerType = 'xx'; }));
  assert.equal(m.pocket, null);
  assert.match(noteText(m), /pocket not drawn: primer type/i);
});

test('w takes the largest of its terms', () => {
  assert.equal(G.buildModel(rec('308_win')).w, 4.8); // pocket depth + 1.5
  // groove at a high E dominates: E + tb
  const m = G.buildModel(clone('308_win', (r) => { r.cartridge.caseHead.E = 6; }));
  near(m.w, 6.6, 1e-9);
  // belted: ramp end + tb is used instead of E + tb
  const b = G.buildModel(rec('300_win_mag'));
  near(b.w, Math.max(2.5, 0.25 * 13.03 / 2, 3.3 + 1.5, b.belt.rampEndZ + b.walls.tb), 1e-9);
});

test('straight case: the wall blends from tb at w to tn at the bullet base so the bullet fits', () => {
  const m = G.buildModel(rec('9_mm_luger'));
  near(m.walls.tn, 0.31, 1e-9);
  near(m.walls.tb, 0.6, 1e-9);
  const zb = m.bullet.zb;
  const last = m.inner[m.inner.length - 1];
  near(last[0], 4.825 - 0.31, 1e-9);
  const atBase = m.inner.find((p) => Math.abs(p[1] - zb) < 1e-9);
  assert.ok(atBase, 'inner vertex at the bullet base');
  near(atBase[0], (4.965 - (4.965 - 4.825) * (zb - 2.98) / (19.15 - 2.98)) - 0.31, 1e-6);
});

test('invariant: the inner wall radius is never smaller than the seated bullet radius (all 25)', () => {
  for (const r of data) {
    const m = G.buildModel(r);
    assert.ok(m.bullet && m.inner, r.key);
    const innerR = (z) => {
      for (let i = 1; i < m.inner.length; i++) {
        const a = m.inner[i - 1], b = m.inner[i];
        if (z >= a[1] - 1e-12 && z <= b[1] + 1e-12) return b[1] > a[1] ? a[0] + (b[0] - a[0]) * (z - a[1]) / (b[1] - a[1]) : Math.min(a[0], b[0]);
      }
      return undefined;
    };
    const zb = m.bullet.zb, L3 = r.cartridge.lengths.L3;
    for (let i = 0; i <= 200; i++) {
      const z = zb + (L3 - zb) * i / 200;
      const ir = innerR(z);
      assert.notEqual(ir, undefined, `${r.key} z=${z}`);
      assert.ok(ir >= m.bullet.Rseat - 1e-6, `${r.key}: inner ${ir} < bullet ${m.bullet.Rseat} at z=${z.toFixed(2)}`);
    }
  }
});

test('section polygons are closed, simple enough to hatch: first and last points connect to the axis or pocket edge', () => {
  for (const r of data) {
    const m = G.buildModel(r);
    const cs = m.section.caseSection;
    assert.ok(cs.length > 8, r.key);
    assert.ok(cs.every((p) => p[0] >= -1e-9), r.key);
    const bs = m.section.bulletSection;
    assert.ok(bs.length >= 5, r.key);
    pt(bs[0], 0, m.bullet.zb);
    assert.ok(has(bs, 0, r.cartridge.lengths.L6, 1e-9), r.key);
  }
});

test('all 25 records build without notes about missing mandatory geometry values', () => {
  for (const r of data) {
    const m = G.buildModel(r);
    assert.equal(m.ok, true, r.key);
    assert.ok(Array.isArray(m.notes), r.key);
  }
});

test('values for the dimension lines are passed through unchanged', () => {
  const m = G.buildModel(rec('308_win'));
  assert.deepEqual(m.values, { L1: 39.62, L2: 43.48, L3: 51.18, L6: 71.12, R: 1.37, R1: 12.01, P1: 11.96, P2: 11.53,
    H1: 8.72, H2: 8.72, G1: 7.85, E1: 10.39, alpha: 40 });
  const l = G.buildModel(rec('9_mm_luger')).values;
  assert.equal(l.P2, undefined);
  assert.equal(l.alpha, undefined);
});

/* ---------- robustness (review findings) ---------- */

test('non-positive core values make the drawing unavailable instead of producing NaN', () => {
  for (const bad of [0, -5, 1e-12]) {
    const m = G.buildModel(clone('308_win', (r) => { r.cartridge.lengths.L3 = bad; }));
    assert.equal(m.ok, false, `L3=${bad}`);
    assert.match(noteText(m), /L3/);
  }
  assert.equal(G.buildModel(clone('308_win', (r) => { r.cartridge.powderChamber.P1 = 0; })).ok, false);
  assert.equal(G.buildModel(clone('308_win', (r) => { r.cartridge.caseHead.R1 = -1; })).ok, false);
});

test('a body start beyond the mouth makes the drawing unavailable', () => {
  const m = G.buildModel(clone('308_win', (r) => { r.cartridge.caseHead.E = 1e6; }));
  assert.equal(m.ok, false);
  assert.match(noteText(m), /L3/);
});

test('hostile values never throw and never leak non-finite coordinates', () => {
  const keys = ['308_win', '300_win_mag', '9_mm_luger', '22_long_rifle', '17_hmr', '38_special'];
  const values = [0, -1, 1e6, NaN, Infinity, '5', null];
  const finite = (pts) => pts.every((p) => Number.isFinite(p[0]) && Number.isFinite(p[1]));
  for (const k of keys) {
    const base = rec(k);
    for (const sec of ['caseHead', 'collar', 'junctionCone', 'lengths', 'powderChamber', 'projectile']) {
      for (const f of Object.keys(base.cartridge[sec] || {})) {
        for (const v of values) {
          const r = clone(k, (x) => { x.cartridge[sec][f] = v; });
          let m;
          assert.doesNotThrow(() => { m = G.buildModel(r); }, `${k} ${sec}.${f}=${v}`);
          if (!m.ok) continue;
          for (const part of [m.outer, m.inner, m.section && m.section.caseSection, m.bullet && m.bullet.exposed, m.bullet && m.bullet.profile]) {
            if (part) assert.ok(finite(part), `${k} ${sec}.${f}=${v} produced a non-finite point`);
          }
        }
      }
    }
  }
});

test('a straight case that publishes none of the shoulder values gets no shoulder note', () => {
  const m = G.buildModel(rec('9_mm_luger'));
  assert.equal(m.shoulder, null);
  assert.doesNotMatch(noteText(m), /shoulder/i);
});

test('a partly published shoulder names what is missing', () => {
  const m = G.buildModel(clone('308_win', (r) => { delete r.cartridge.junctionCone.alpha; delete r.cartridge.lengths.L2; }));
  assert.equal(m.shoulder, null);
  assert.match(noteText(m), /Shoulder not drawn: α and L2 not published/);
});
