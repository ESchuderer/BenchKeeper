'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const data = require('../../js/data.js');
const G = require('../../js/geometry.js');
const L = require('../../js/layout.js');

const rec = (k) => data.find((r) => r.key === k);
const scene = (k) => L.layoutScene(G.buildModel(rec(k)), rec(k));
const near = (a, b, tol = 1e-6, msg) => assert.ok(Math.abs(a - b) <= tol, `${msg || ''} ${a} vs ${b}`);
const texts = (s) => s.labels.map((l) => l.text).sort();

test('308 Win.: every published dimension is labelled with symbol and value', () => {
  const s = scene('308_win');
  assert.deepEqual(texts(s), ['E1 10.39', 'G1 7.85', 'H1 8.72', 'H2 8.72', 'L1 39.62', 'L2 43.48', 'L3 51.18', 'L6 71.12',
    'P1 11.96', 'P2 11.53', 'R 1.37', 'R1 12.01', 'α 40°'].sort());
});

test('angle label keeps degrees, minutes, seconds', () => {
  assert.ok(scene('6_5_x_55_se').labels.some((l) => l.text === 'α 50°35\'2"'));
});

test('unpublished dimensions are omitted (9 mm Luger, 38 Special, 17 HMR)', () => {
  assert.deepEqual(texts(scene('9_mm_luger')), ['E1 8.79', 'G1 9.03', 'H2 9.65', 'L3 19.15', 'L6 29.69', 'P1 9.93', 'R 1.27', 'R1 9.96'].sort());
  assert.deepEqual(texts(scene('38_special')), ['G1 9.12', 'H2 9.63', 'L3 29.34', 'L6 39.37', 'P1 9.63', 'R 1.5', 'R1 11.18'].sort());
  const hmr = texts(scene('17_hmr'));
  for (const t of ['L1 22.2', 'L2 23.54', 'P2 6.15', 'H1 4.9', 'α 50°']) assert.ok(hmr.includes(t), t);
  assert.ok(!hmr.some((t) => t.startsWith('E1')));
});

test('dimension lines are true to scale: their length equals the published value in mm', () => {
  const s = scene('308_win');
  const len = (d) => Math.hypot(d.b[0] - d.a[0], d.b[1] - d.a[1]);
  const v = { L3: 51.18, L6: 71.12, R1: 12.01, R: 1.37, P1: 11.96, P2: 11.53, H1: 8.72, H2: 8.72, G1: 7.85, L1: 39.62, L2: 43.48, E1: 10.39 };
  for (const [id, value] of Object.entries(v)) {
    assert.ok(s.dims[id], id);
    near(len(s.dims[id]), value, 1e-9, id);
  }
  // axial dimensions start at the head face
  for (const id of ['L1', 'L2', 'L3', 'L6', 'R']) near(Math.min(s.dims[id].a[0], s.dims[id].b[0]), 0, 1e-9, id);
  // axial dimensions are horizontal, diameters vertical and symmetric about the axis
  for (const id of ['L1', 'L2', 'L3', 'L6', 'R']) near(s.dims[id].a[1], s.dims[id].b[1], 1e-9, id);
  for (const id of ['R1', 'P1', 'P2', 'H1', 'H2', 'G1', 'E1']) {
    near(s.dims[id].a[0], s.dims[id].b[0], 1e-9, id);
    near(s.dims[id].a[1], -s.dims[id].b[1], 1e-9, id);
  }
  // diameters are measured at the right place along the axis
  near(s.dims.P2.a[0], 39.62, 1e-9);
  near(s.dims.H1.a[0], 43.48, 1e-9);
  near(s.dims.H2.a[0], 51.18, 1e-9);
});

test('every dimension has two arrowheads and two extension lines', () => {
  for (const r of data) {
    const s = L.layoutScene(G.buildModel(r), r);
    for (const [id, d] of Object.entries(s.dims)) {
      assert.equal(d.arrows, 2, `${r.key} ${id}`);
      assert.equal(d.extensions, 2, `${r.key} ${id}`);
    }
    assert.equal(s.items.filter((i) => i.type === 'arrow').length >= 2 * Object.keys(s.dims).length, true, r.key);
    assert.ok(s.items.filter((i) => i.cls === 'ext').length >= 2 * Object.keys(s.dims).length, r.key);
  }
});

function rectHitsSeg(rc, sg, m) {
  const x0 = rc.x - m, y0 = rc.y - m, x1 = rc.x + rc.w + m, y1 = rc.y + rc.h + m;
  const inside = (x, y) => x >= x0 && x <= x1 && y >= y0 && y <= y1;
  if (inside(sg[0], sg[1]) || inside(sg[2], sg[3])) return true;
  const edge = (ax, ay, bx, by, cx, cy, dx, dy) => {
    const d = (bx - ax) * (dy - cy) - (by - ay) * (dx - cx);
    if (Math.abs(d) < 1e-12) return false;
    const t = ((cx - ax) * (dy - cy) - (cy - ay) * (dx - cx)) / d;
    const u = ((cx - ax) * (by - ay) - (cy - ay) * (bx - ax)) / d;
    return t >= 0 && t <= 1 && u >= 0 && u <= 1;
  };
  return edge(sg[0], sg[1], sg[2], sg[3], x0, y0, x1, y0) || edge(sg[0], sg[1], sg[2], sg[3], x1, y0, x1, y1) ||
    edge(sg[0], sg[1], sg[2], sg[3], x1, y1, x0, y1) || edge(sg[0], sg[1], sg[2], sg[3], x0, y1, x0, y0);
}
function pointInPoly(p, poly) {
  let c = false;
  for (let i = 0, j = poly.length - 1; i < poly.length; j = i++) {
    const a = poly[i], b = poly[j];
    if ((a[1] > p[1]) !== (b[1] > p[1]) && p[0] < (b[0] - a[0]) * (p[1] - a[1]) / (b[1] - a[1]) + a[0]) c = !c;
  }
  return c;
}
const rectsHit = (a, b, m) => a.x < b.x + b.w + m && b.x < a.x + a.w + m && a.y < b.y + b.h + m && b.y < a.y + a.h + m;

test('labels overlap neither each other, nor the outline, dimension, extension or centre lines (all 25)', () => {
  for (const r of data) {
    const s = L.layoutScene(G.buildModel(r), r);
    assert.ok(s.labels.length >= 7, r.key);
    s.labels.forEach((a, i) => {
      s.labels.slice(i + 1).forEach((b) => assert.ok(!rectsHit(a.rect, b.rect, 0.2), `${r.key}: ${a.text} overlaps ${b.text}`));
      for (const sg of s.segments) assert.ok(!rectHitsSeg(a.rect, sg, 0.2), `${r.key}: ${a.text} touches a ${sg[4]} line`);
      const c = [[a.rect.x, a.rect.y], [a.rect.x + a.rect.w, a.rect.y], [a.rect.x, a.rect.y + a.rect.h],
        [a.rect.x + a.rect.w, a.rect.y + a.rect.h], [a.rect.x + a.rect.w / 2, a.rect.y + a.rect.h / 2]];
      for (const poly of s.silhouettes) for (const p of c) assert.ok(!pointInPoly(p, poly), `${r.key}: ${a.text} lies on the part`);
    });
    for (const t of s.titleBlockObstacles || []) for (const a of s.labels) assert.ok(!rectsHit(a.rect, t, 0), r.key);
  }
});

test('label rectangles are as wide as the text needs (monospace estimate)', () => {
  const s = scene('308_win');
  for (const l of s.labels) {
    assert.ok(l.rect.w >= l.text.length * L.CONST.FONT * 0.6 - 1e-9, l.text);
    assert.ok(l.rect.h >= L.CONST.FONT * 0.9, l.text);
  }
});

test('the scene bounding box contains every segment and label', () => {
  for (const r of data) {
    const s = L.layoutScene(G.buildModel(r), r);
    const b = s.bbox;
    for (const sg of s.segments) for (const [x, y] of [[sg[0], sg[1]], [sg[2], sg[3]]]) {
      assert.ok(x >= b.x - 1e-9 && x <= b.x + b.w + 1e-9 && y >= b.y - 1e-9 && y <= b.y + b.h + 1e-9, `${r.key} seg`);
    }
    for (const l of s.labels) {
      assert.ok(l.rect.x >= b.x - 1e-9 && l.rect.x + l.rect.w <= b.x + b.w + 1e-9, `${r.key} label x`);
      assert.ok(l.rect.y >= b.y - 1e-9 && l.rect.y + l.rect.h <= b.y + b.h + 1e-9, `${r.key} label y`);
    }
  }
});

test('outside view above the axis, section below: hatched polygons lie at y >= 0', () => {
  const s = scene('308_win');
  const cuts = s.items.filter((i) => i.type === 'polygon' && i.hatch);
  assert.ok(cuts.length >= 1);
  for (const c of cuts) for (const p of c.pts) assert.ok(p[1] >= -1e-9);
  const outline = s.items.find((i) => i.cls === 'outline');
  assert.ok(outline.pts.every((p) => p[1] <= 1e-9));
});

test('x equals z in mm: the mouth lies at x = L3, the tip at x = L6', () => {
  const s = scene('308_win');
  const outline = s.items.find((i) => i.cls === 'outline');
  const xs = outline.pts.map((p) => p[0]);
  near(Math.max(...xs), 71.12, 1e-9);
  assert.ok(outline.pts.some((p) => Math.abs(p[0] - 51.18) < 1e-9 && Math.abs(p[1] + 4.36) < 1e-9), 'mouth corner');
  assert.ok(outline.pts.some((p) => Math.abs(p[0] - 0) < 1e-9 && Math.abs(p[1]) < 1e-9), 'axis at the head face');
});

test('a dash-dot centre line lies on the axis', () => {
  const s = scene('308_win');
  const c = s.items.find((i) => i.cls === 'centre');
  assert.ok(c);
  near(c.y1, 0); near(c.y2, 0);
  assert.ok(c.x1 < 0 && c.x2 > 71.12);
});

test('shoulder angle marker is drawn when alpha is published', () => {
  const s = scene('308_win');
  assert.ok(s.items.some((i) => i.cls === 'angle'), 'arc');
  assert.ok(s.items.some((i) => i.cls === 'construction'), 'mirror line');
  assert.ok(!scene('9_mm_luger').items.some((i) => i.cls === 'angle'));
});

test('without a bullet the mouth closes on the axis and no bullet dimensions appear', () => {
  const r = JSON.parse(JSON.stringify(rec('308_win')));
  delete r.cartridge.projectile.G1;
  const s = L.layoutScene(G.buildModel(r), r);
  assert.ok(!s.dims.G1 && !s.dims.L6);
  assert.ok(s.dims.L3);
});

test('unavailable model yields an empty scene', () => {
  const r = JSON.parse(JSON.stringify(rec('308_win')));
  delete r.cartridge.lengths.L3;
  const s = L.layoutScene(G.buildModel(r), r);
  assert.deepEqual(s.labels, []);
  assert.equal(s.items.length, 0);
});

test('the outside view closes the bullet tip on the axis (meplat edge)', () => {
  const s = scene('308_win');
  const outline = s.items.find((i) => i.cls === 'outline');
  const last = outline.pts[outline.pts.length - 1];
  near(last[0], 71.12, 1e-9); near(last[1], 0, 1e-9);
});

test('every label found a free spot (none fell back to its preferred position)', () => {
  for (const r of data) {
    const s = L.layoutScene(G.buildModel(r));
    assert.ok(s.labels.every((l) => l.placed === true), r.key);
  }
});
