'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const data = require('../../js/data.js');
const S = require('../../js/search.js');

const names = (rs) => rs.map((r) => r.name);

test('empty query and family All list everything in record order', () => {
  assert.equal(S.filterRecords(data, { q: '', family: 'all' }).length, 25);
  assert.equal(S.filterRecords(data, {}).length, 25);
  assert.equal(S.filterRecords(data, { q: '   ' })[0].name, '223 Rem.');
});

test('alternative names are searched: 7,62 x 51 finds 308 Win.', () => {
  assert.deepEqual(names(S.filterRecords(data, { q: '7,62 x 51' })), ['308 Win.']);
});

test('case, spacing and decimal separator are ignored', () => {
  assert.deepEqual(names(S.filterRecords(data, { q: '7.62X51' })), ['308 Win.']);
  assert.deepEqual(names(S.filterRecords(data, { q: '7,62x51' })), ['308 Win.']);
  assert.deepEqual(names(S.filterRecords(data, { q: '6.5 creed' })), ['6,5 Creedmoor']);
});

test('names match as substrings', () => {
  assert.deepEqual(names(S.filterRecords(data, { q: 'creed' })), ['6,5 Creedmoor']);
  assert.deepEqual(names(S.filterRecords(data, { q: '30-06' })), ['30-06 Spring.']);
  assert.deepEqual(names(S.filterRecords(data, { q: 'ACP' })), ['45 Auto']);
  assert.deepEqual(names(S.filterRecords(data, { q: 'lang für' })), ['22 Long Rifle']);
});

test('no match gives an empty list', () => {
  assert.equal(S.filterRecords(data, { q: 'zzz' }).length, 0);
});

test('family filter', () => {
  assert.deepEqual(names(S.filterRecords(data, { family: 'belted' })), ['300 Win. Mag.', '7 mm Rem. Mag.']);
  assert.equal(S.filterRecords(data, { family: 'pistol' }).length, 6);
  assert.equal(S.filterRecords(data, { family: 'rimfire' }).length, 3);
  assert.equal(S.filterRecords(data, { family: 'rimless' }).length, 12);
  assert.equal(S.filterRecords(data, { family: 'rimmed' }).length, 2);
});

test('search and family combine', () => {
  assert.deepEqual(names(S.filterRecords(data, { q: 'win', family: 'rimless' })), ['243 Win.', '270 Win.', '308 Win.']);
  assert.deepEqual(names(S.filterRecords(data, { q: 'win', family: 'belted' })), ['300 Win. Mag.']);
});

test('families offered by the select', () => {
  assert.deepEqual(S.FAMILIES, ['all', 'rimless', 'rimmed', 'belted', 'pistol', 'rimfire']);
});

test('normalise', () => {
  assert.equal(S.normalise(' 7,62 X 51 '), '7.62x51');
});

test('hash state round trip', () => {
  assert.deepEqual(S.parseListQuery('q=7%2C62%20x%2051&family=belted'), { q: '7,62 x 51', family: 'belted' });
  assert.equal(S.listQuery({ q: '7,62 x 51', family: 'belted' }), 'q=7%2C62%20x%2051&family=belted');
  assert.equal(S.listQuery({ q: '', family: 'all' }), '');
  assert.deepEqual(S.parseListQuery('family=bogus'), { q: '', family: 'all' });
  assert.deepEqual(S.parseListQuery(''), { q: '', family: 'all' });
});

test('routes', () => {
  assert.deepEqual(S.parseRoute(''), { name: 'list', q: '', family: 'all' });
  assert.deepEqual(S.parseRoute('#/'), { name: 'list', q: '', family: 'all' });
  assert.deepEqual(S.parseRoute('#/?q=win&family=pistol'), { name: 'list', q: 'win', family: 'pistol' });
  assert.deepEqual(S.parseRoute('#/cartridge/308_win'), { name: 'detail', key: '308_win' });
  assert.deepEqual(S.parseRoute('#/cartridge/'), { name: 'notfound' });
  assert.deepEqual(S.parseRoute('#/what'), { name: 'notfound' });
  assert.equal(S.detailHash('308_win'), '#/cartridge/308_win');
  assert.equal(S.listHash({ q: 'win', family: 'pistol' }), '#/?q=win&family=pistol');
  assert.equal(S.listHash({}), '#/');
});
