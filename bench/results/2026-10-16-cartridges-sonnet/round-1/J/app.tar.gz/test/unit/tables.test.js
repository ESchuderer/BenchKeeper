'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const data = require('../../js/data.js');
const T = require('../../js/tables.js');

const rec = (k) => data.find((r) => r.key === k);
const titles = (secs) => secs.map((s) => s.title);
const section = (secs, title) => secs.find((s) => s.title === title);
const row = (sec, symbol) => sec.rows.find((r) => r.symbol === symbol);

test('223 Rem.: cartridge sections in reading order', () => {
  const t = T.buildTables(rec('223_rem'));
  assert.deepEqual(titles(t.cartridge), ['Case head', 'Powder chamber', 'Collar', 'Junction cone', 'Lengths',
    'Projectile', 'Pressures', 'Miscellaneous']);
});

test('223 Rem.: chamber sections in reading order', () => {
  const t = T.buildTables(rec('223_rem'));
  assert.deepEqual(titles(t.chamber), ['Breech', 'Powder chamber', 'Collar', 'Junction cone', 'Lengths',
    'Barrel', 'Grooves', 'Rifling']);
});

test('empty sections are omitted (9 mm Luger has no junction cone)', () => {
  const t = T.buildTables(rec('9_mm_luger'));
  assert.ok(!titles(t.cartridge).includes('Junction cone'));
  assert.ok(!titles(t.chamber).includes('Junction cone'));
});

test('tolerance is merged into the value and never a row of its own', () => {
  const t = T.buildTables(rec('223_rem'));
  const len = section(t.cartridge, 'Lengths');
  assert.deepEqual(len.rows.map((r) => [r.symbol, r.value]),
    [['L1', '36.52 -0.2'], ['L2', '39.55 -0.2'], ['L3', '44.7'], ['L6', '57.4']]);
  const all = [...t.cartridge, ...t.chamber].flatMap((s) => s.rows.map((r) => r.symbol));
  assert.ok(!all.some((s) => /Tol$/.test(s)));
  const w = T.buildTables(rec('308_win'));
  const wl = section(w.cartridge, 'Lengths');
  assert.equal(row(wl, 'L1').value, '39.62');
  assert.equal(row(wl, 'L2').value, '43.48 -0.2');
});

test('rows carry symbol, value and unit', () => {
  const t = T.buildTables(rec('223_rem'));
  const p = section(t.cartridge, 'Pressures');
  assert.deepEqual(row(p, 'Pmax'), { field: 'Pmax', symbol: 'Pmax', value: '4300', unit: 'bar' });
  assert.equal(row(p, 'EE').unit, 'J');
  assert.equal(row(p, 'M').unit, 'g');
  assert.equal(row(section(t.chamber, 'Grooves'), 'Q').unit, 'mm²');
  assert.equal(row(section(t.chamber, 'Grooves'), 'N').unit, '');
  assert.equal(row(section(t.cartridge, 'Case head'), 'β').unit, '°');
  assert.equal(row(section(t.cartridge, 'Case head'), 'e min').value, '0.76');
});

test('angles: degrees, and degrees minutes seconds', () => {
  const se = T.buildTables(rec('6_5_x_55_se'));
  assert.equal(row(section(se.cartridge, 'Junction cone'), 'α').value, '50°35\'2"');
  const w243 = T.buildTables(rec('243_win'));
  assert.equal(row(section(w243.cartridge, 'Junction cone'), 'α').value, '40°');
  const rm = T.buildTables(rec('7_mm_rem_mag'));
  assert.equal(row(section(rm.chamber, 'Rifling'), 'i').value, '3°');
  assert.equal(row(section(T.buildTables(rec('223_rem')).chamber, 'Rifling'), 'i').value, '3°10\'36"');
});

test('special symbols', () => {
  const t = T.buildTables(rec('223_rem'));
  assert.ok(row(section(t.cartridge, 'Projectile'), 'L3 + G'));
  assert.ok(row(section(t.cartridge, 'Miscellaneous'), 'delta L'));
  assert.ok(row(section(t.chamber, 'Junction cone'), 'r1 max'));
  assert.ok(row(section(t.cartridge, 'Junction cone'), 'r1 min'));
  assert.ok(row(section(t.chamber, 'Rifling'), 'α1'));
});

test('belted: R3 and ETol appear in the case head', () => {
  const t = T.buildTables(rec('300_win_mag'));
  const ch = section(t.cartridge, 'Case head');
  assert.equal(row(ch, 'E').value, '5.59 -0.2');
  assert.equal(row(ch, 'R3').value, '13.51');
});

test('every record builds, with at least a Lengths section in each part', () => {
  for (const r of data) {
    const t = T.buildTables(r);
    assert.ok(section(t.cartridge, 'Lengths'), r.key);
    assert.ok(section(t.chamber, 'Lengths'), r.key);
    for (const s of [...t.cartridge, ...t.chamber]) assert.ok(s.rows.length > 0, `${r.key} ${s.title}`);
  }
});

test('unknown fields are appended after the known ones, tolerance still merged', () => {
  const t = T.buildTables({ cartridge: { lengths: { L3: 10, L3Tol: -1, Lx: 2 } }, chamber: {} });
  assert.deepEqual(section(t.cartridge, 'Lengths').rows.map((r) => [r.symbol, r.value]), [['L3', '10 -1'], ['Lx', '2']]);
});
