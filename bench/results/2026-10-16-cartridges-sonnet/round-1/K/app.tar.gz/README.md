# C.I.P. cartridge reference

A static reference database of 25 C.I.P. cartridges for reloaders, gunsmiths and engineers: searchable list, detail view with all cartridge and chamber values, a dimensioned 2D drawing computed from each record, and a one-page A4 print sheet.

Plain HTML, CSS and JavaScript. No framework, no build step, no server code, no runtime dependencies, no network requests.

## Use

Open `index.html` directly from disk in Chromium (`file://`), or serve the folder with any static file server, from the root or from a sub-path:

```sh
npm run serve                  # built-in static server, prints its address (sub-path: npm run serve -- some/path)
```

Any other static file server works the same way.

Addresses are hash routes: `#/` is the list, `#/cartridge/308_win` a detail view. They survive a reload and can be bookmarked.

## Data

The 25 records are the only data (OpenBallistics, <https://github.com/PiMetry/OpenBallistics>, MIT, commit e83db43). They are kept as supplied in `tests/fixtures/records.jsonl`; `js/data.js` is generated from that file (`npm run data`) and a unit test checks that both are identical. Nothing is fetched, added or changed at run time.

Units not stated in the brief: the fields `u`, `Fe`, `S`, `h`, `s`, `b`, `G`, `deltaL` and `L3PlusG` are shown in mm; the published water capacity `grH2O` is shown as grains of water (`gr H2O`).

## Layout

| Path | Purpose |
| --- | --- |
| `index.html` | shell, content security policy, script loading |
| `css/styles.css`, `css/print.css` | screen styles with light/dark themes; one-page A4 print rules |
| `js/format.js` | numbers, angles, units, symbols, tolerances, search matching |
| `js/geometry.js`, `js/bullet.js`, `js/mathutil.js` | pure geometry: outer profile, walls, section, pocket, bullet; reports missing values |
| `js/dimensions.js` | dimension lines, extension lines, label placement without overlaps, title block, view box |
| `js/drawing.js` | SVG markup (1 user unit = 1 mm) |
| `js/router.js`, `js/views.js`, `js/app.js` | hash routing and DOM views |
| `openspec/changes/build-cartridge-reference/` | proposal, specs, design and tasks of this change |

Drawing rules, missing-value handling and every interpretation made where the brief leaves room are in `openspec/changes/build-cartridge-reference/design.md`. When a value a rule needs is not published, the drawing leaves that feature out and says which value is missing in a note under the drawing.

## Develop and test

Node.js 22. The app itself needs nothing installed; the tests use Playwright (dev dependency) with Chromium.

```sh
npm install
npx playwright install chromium    # once
npm test                           # unit tests, then end-to-end tests
npm run test:unit                  # geometry, layout, formatting, search, SVG, router (fast, no browser)
npm run test:e2e                   # real Chromium: file://, served sub-path, phone, dark, print/PDF
npm run coverage                   # line coverage of the pure modules
```

The end-to-end tests check, for all 25 cartridges, that labels do not overlap (measured with `getBBox()` against the drawn geometry), that the drawing is to scale, and that every detail view prints on exactly one A4 page.

If Chromium cannot start because system libraries are missing (minimal containers), unpack them into `~/chromium-libs` (the tests add that directory to `LD_LIBRARY_PATH`; override with `CIP_CHROMIUM_LIBS`).

`scripts/screenshot.js`, `scripts/print-preview.js` and `scripts/contact-sheet.js` write screenshots of the drawings, of the print layout and of all 25 drawings at once to `test-output/`.

## Known limits

- On a 360 px wide phone the drawing is scaled to the screen width, so its labels are small (about 7 px); pinch-zoom works.
- No flash hole is drawn between the primer pocket and the powder chamber (the brief gives no dimensions for it).
- The title block states the scale of the A4 print (for example "Scale 1.31:1 on A4 print"). On screen the drawing is fitted to its container, so no fixed on-screen scale exists; 1 SVG unit is always 1 mm of cartridge.
