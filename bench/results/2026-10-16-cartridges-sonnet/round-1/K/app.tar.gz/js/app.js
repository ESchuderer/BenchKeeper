'use strict';
// Entry point: hash router, document title, focus and scroll handling.
(function (global) {
  const CIP = global.CIP;
  const { records, router, views } = CIP;

  const SITE_TITLE = 'C.I.P. cartridges';
  const main = document.getElementById('main');
  const listView = views.createListView(records);
  const byKey = new Map(records.map((r) => [r.key, r]));

  let current = null;
  let listScroll = 0;
  let firstRender = true;

  function titleFor(heading) {
    return `${heading} – ${SITE_TITLE}`;
  }

  function resolve(route) {
    if (route.view === 'detail') {
      const record = byKey.get(route.key);
      return record
        ? { kind: 'detail', title: titleFor(record.name), view: views.createDetailView(record, () => global.print()) }
        : { kind: 'missing', title: titleFor('Cartridge not found'), view: views.createNotFoundView() };
    }
    return { kind: 'list', title: SITE_TITLE, view: listView };
  }

  function show(route) {
    if (current && current.kind === 'list') listScroll = global.scrollY;
    const next = resolve(route);
    main.replaceChildren(next.view.root);
    document.title = next.title;
    current = next;
    if (next.kind === 'list') global.scrollTo(0, listScroll);
    else global.scrollTo(0, 0);
    if (!firstRender) next.view.heading.focus({ preventScroll: true });
    firstRender = false;
  }

  // The skip link would otherwise change the hash, which the router reads as "go to the list".
  document.querySelector('.skip-link').addEventListener('click', (event) => {
    event.preventDefault();
    main.focus();
  });

  global.addEventListener('hashchange', () => show(router.parseHash(global.location.hash)));
  show(router.parseHash(global.location.hash));
})(window);
