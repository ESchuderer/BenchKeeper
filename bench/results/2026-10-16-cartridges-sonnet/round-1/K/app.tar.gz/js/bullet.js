'use strict';
// Bullet geometry from the brief's rules (seating depth, cylinder, nose, heeled bullets). Pure functions.
(function (global) {
  const CIP = (global.CIP = global.CIP || {});
  const { pt, dedupe, clipFromZ, DEG } = CIP.mathutil || require('./mathutil.js');

  const HEELED_TOLERANCE = 0.015;
  const POINTY_MIN_MEPLAT = 1.27;
  const NOSE_STEP_DEG = 1.5;
  const ELLIPSE_STEPS = Math.ceil(90 / (NOSE_STEP_DEG * 2)); // quarter ellipse, sampled more coarsely than the ogive

  // seating depth factor (of G1) and cylinder fraction k by shape; rounded/flat depend on the cartridge category.
  function seatingRule(shape, category) {
    const pistol = category === 'pistol';
    switch (shape) {
      case 'pointy':
        return { sFactor: 1.0, k: 0.4 };
      case 'rounded':
        return { sFactor: pistol ? 0.4 : 0.8, k: pistol ? 0.65 : 0.55 };
      case 'flat':
        return { sFactor: pistol ? 0.4 : 0.8, k: pistol ? 0.7 : 0.6 };
      case 'semi_wadcutter':
        return { sFactor: 0.6, k: 0.78 };
      default:
        return null;
    }
  }

  const needsCategory = (shape) => shape === 'rounded' || shape === 'flat';

  /** Seating depth s and cylinder fraction k; null when the shape (or the category it needs) is unknown. */
  function seating(shape, category, G1) {
    if (needsCategory(shape) && !['rifle', 'pistol', 'rimfire'].includes(category)) return null;
    const rule = seatingRule(shape, category);
    return rule ? { s: rule.sFactor * G1, k: rule.k } : null;
  }

  const isHeeled = (H2, G1) => H2 - G1 <= HEELED_TOLERANCE + 1e-9;

  function ogive(zc, d, m, n) {
    const delta = d / 2 - m / 2;
    const rho = (delta * delta + n * n) / (2 * delta);
    const sweep = Math.asin(Math.min(1, n / rho));
    const steps = Math.max(8, Math.ceil(sweep / (NOSE_STEP_DEG * DEG)));
    // The centre lies on the radial line where the nose starts: z = zc, r = d/2 - rho.
    const centerR = d / 2 - rho;
    const points = [];
    for (let i = 0; i <= steps; i += 1) {
      const a = (sweep * i) / steps;
      points.push(pt(zc + rho * Math.sin(a), centerR + rho * Math.cos(a)));
    }
    points[points.length - 1] = pt(zc + n, m / 2); // exact tip, removes rounding noise
    return { rho, points };
  }

  function ellipse(zc, d, m, n) {
    const a = d / 2 - m / 2;
    const out = [];
    for (let i = 0; i <= ELLIPSE_STEPS; i += 1) {
      const t = ((Math.PI / 2) * i) / ELLIPSE_STEPS;
      out.push(pt(zc + n * Math.sin(t), m / 2 + a * Math.cos(t)));
    }
    out[out.length - 1] = pt(zc + n, m / 2);
    return out;
  }

  const MEPLAT_FACTOR = { rounded: 0.15, flat: 0.55, semi_wadcutter: 0.6 };

  function nose(shape, zc, d, G1, n) {
    if (shape === 'pointy') {
      const m = Math.max(0.08 * G1, POINTY_MIN_MEPLAT);
      if (!(d / 2 > m / 2)) return null; // shank no wider than the flat tip: no ogive exists
      const og = ogive(zc, d, m, n);
      return { m, rho: og.rho, points: og.points };
    }
    const m = MEPLAT_FACTOR[shape] * G1;
    if (shape === 'rounded') return { m, rho: null, points: ellipse(zc, d, m, n) };
    return { m, rho: null, points: [pt(zc, d / 2), pt(zc + n, m / 2)] };
  }

  /**
   * @param {{shape:string, category:string, G1:number, L3:number, L6:number, H2:number, tb:number}} p
   * @returns {object} bullet geometry, or {missing: string[]} when a needed value is absent
   */
  function build({ shape, category, G1, L3, L6, H2, tb }) {
    const rule = seating(shape, category, G1);
    if (!rule) return { missing: needsCategory(shape) ? ['category'] : ['default bullet shape'] };
    const { s, k } = rule;
    const heeled = isHeeled(H2, G1);
    const d = heeled ? H2 : G1;
    const seatD = heeled ? H2 - 2 * tb : G1;
    const zb = L3 - s;
    const Lb = L6 - zb;
    if (!(Lb > 0)) return { missing: ['L6'] };
    const zc = zb + k * Lb;
    const n = L6 - zc;
    const tip = nose(shape, zc, d, G1, n);
    if (!tip) return { unusable: 'G1 is too small for the nose shape (the flat tip would be as wide as the shank)' };

    const shank = [pt(zb, 0), pt(zb, seatD / 2), pt(L3, seatD / 2)];
    if (heeled) shank.push(pt(L3, d / 2));
    const outline = dedupe([...shank, pt(zc, d / 2), ...tip.points, pt(L6, 0)]);

    const noseAndTip = dedupe([pt(zc, d / 2), ...tip.points, pt(L6, 0)]);
    const visible = zc > L3 ? dedupe([pt(L3, d / 2), ...noseAndTip]) : clipFromZ(noseAndTip, L3);
    return { shape, category, heeled, d, seatD, s, zb, Lb, k, zc, n, m: tip.m, rho: tip.rho, outline, visible };
  }

  const api = { seating, isHeeled, build };
  CIP.bullet = api;
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
})(typeof window !== 'undefined' ? window : globalThis);
