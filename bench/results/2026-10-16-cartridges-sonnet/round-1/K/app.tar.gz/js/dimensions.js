'use strict';
// Dimension lines, extension lines, labels and title block for the cartridge drawing. Pure functions, no DOM.
// Drawing coordinates: x = z (mm along the axis), y = -r in the upper (outside) half and +r in the lower (section) half.
(function (global) {
  const CIP = (global.CIP = global.CIP || {});
  const { radiusAt } = CIP.mathutil || require('./mathutil.js');
  const format = CIP.format || require('./format.js');

  const FONT = 2.8; // label size in mm (user units)
  const CHAR_ADVANCE = 0.62; // monospace advance in em, deliberately generous
  const ASCENT = 0.8 * FONT;
  const DESCENT = 0.25 * FONT;
  const ARROW_LENGTH = 1.6;
  const ARROW_HALF_WIDTH = 0.28;
  const ROW_PITCH = 6.0;
  const FIRST_ROW_GAP = 4;
  const EXTENSION_GAP = 0.8;
  const EXTENSION_OVERSHOOT = 1.2;
  const LABEL_GAP = 1.0;
  const VIEW_MARGIN = 3;
  const R1_LINE_X = -4;
  const SHORT_DIMENSION_MARGIN = 1.5; // below 2 arrowheads + this, the arrows go outside and the label beside
  const TAIL_LENGTH = ARROW_LENGTH + 1;
  const BODY_OFFSET = 1.5; // P1 / P2 dimension lines sit this far from the body start / shoulder start
  const NECK_OFFSET = 1; // H1 / H2 dimension lines sit this far inside the neck
  const MAX_SEARCH_NODES = 200000;
  const COLLISION_PAD = 0.3; // minimum clearance checked by findCollisions
  const LABEL_SEPARATION = 1.6; // clearance the row search asks for, so neighbouring labels do not look joined

  // The printed drawing is fitted into this box (css/print.css: full printable width, fixed height), so the
  // scale on paper follows from the view box. Keep both values in step with print.css.
  const PRINT_AREA = { width: 190, height: 96 };

  const TITLE = { pad: 1.8, nameSize: 3.8, textSize: 2.5, nameStep: 5.0, textStep: 3.6, gap: 4.5 };

  const textWidth = (text, size = FONT) => text.length * CHAR_ADVANCE * size;

  function labelRect(text, x, baseline, anchor) {
    const w = textWidth(text);
    let x0 = x;
    if (anchor === 'middle') x0 = x - w / 2;
    else if (anchor === 'end') x0 = x - w;
    return { x0, y0: baseline - ASCENT, x1: x0 + w, y1: baseline + DESCENT };
  }

  const line = (cls, x1, y1, x2, y2) => ({ cls, x1, y1, x2, y2 });
  const arrow = (x, y, dx, dy) => ({ x, y, dx, dy });

  // ---- context ------------------------------------------------------------------------------------------------

  function makeContext(g, options) {
    const pts = g.profile.points;
    const rmax = Math.max(...pts.map((p) => p.r));
    const silhouette = g.bullet ? [...pts, ...g.bullet.visible.filter((p) => p.z > g.v.L3)] : pts;
    const maxNodes = options.maxSearchNodes === undefined ? MAX_SEARCH_NODES : options.maxSearchNodes;
    return { g, v: g.v, rmax, silhouette, maxNodes, radius: (z) => radiusAt(silhouette, z) };
  }

  // ---- length dimensions (stacked below the section) ----------------------------------------------------------

  function lengthSpecs(ctx) {
    const { g, v } = ctx;
    const headR = g.profile.points[1].r; // radius where the head face meets the rim edge
    const specs = [{ id: 'R', symbol: 'R', value: v.R, endR: v.R1 / 2 }];
    if (v.L1 !== undefined) specs.push({ id: 'L1', symbol: 'L1', value: v.L1, endR: ctx.radius(v.L1) });
    if (v.L2 !== undefined) specs.push({ id: 'L2', symbol: 'L2', value: v.L2, endR: ctx.radius(v.L2) });
    specs.push({ id: 'L3', symbol: 'L3', value: v.L3, endR: v.H2 / 2 });
    if (g.bullet) specs.push({ id: 'L6', symbol: 'L6', value: v.L6, endR: g.bullet.m / 2 });
    return specs.map((spec) => ({ ...spec, startR: headR })).sort((a, b) => a.value - b.value);
  }

  function lengthItem(ctx, spec, row) {
    const y = ctx.rmax + FIRST_ROW_GAP + row * ROW_PITCH;
    const z1 = spec.value;
    const text = `${spec.symbol} ${format.formatNumber(spec.value)}`;
    const lines = [
      line('extension-line', 0, spec.startR + EXTENSION_GAP, 0, y + EXTENSION_OVERSHOOT),
      line('extension-line', z1, spec.endR + EXTENSION_GAP, z1, y + EXTENSION_OVERSHOOT),
      line('dimension-line', 0, y, z1, y),
    ];
    const short = z1 < 2 * ARROW_LENGTH + SHORT_DIMENSION_MARGIN;
    let arrows;
    if (short) {
      lines.push(line('dimension-tail', -TAIL_LENGTH, y, 0, y), line('dimension-tail', z1, y, z1 + TAIL_LENGTH, y));
      arrows = [arrow(0, y, 1, 0), arrow(z1, y, -1, 0)];
    } else {
      arrows = [arrow(0, y, -1, 0), arrow(z1, y, 1, 0)];
    }
    const label = short
      ? { text, x: z1 + TAIL_LENGTH + LABEL_GAP, baseline: y + 0.35 * FONT, anchor: 'start' }
      : { text, x: z1 / 2, baseline: y - 1.3, anchor: 'middle' };
    return { id: spec.id, kind: 'length', y, lines, arrows, label: { ...label, rect: labelRect(label.text, label.x, label.baseline, label.anchor) } };
  }

  /** The short R label moves to the left of its dimension when the right-hand position is blocked. */
  function relocateShortLabel(items) {
    const r = items.find((i) => i.id === 'R');
    if (!r) return;
    const blocked = items.some((o) => o !== r && o.lines.some((l) => segmentHitsRect(l, r.label.rect, COLLISION_PAD)));
    if (!blocked) return;
    const x = -TAIL_LENGTH - LABEL_GAP;
    r.label = { ...r.label, x, anchor: 'end', rect: labelRect(r.label.text, x, r.label.baseline, 'end') };
  }

  // ---- diameter dimensions and alpha (leaders up to rows above the section) -----------------------------------

  function diameterSpecs(ctx) {
    const { g, v } = ctx;
    const specs = [];
    // z where the rim reaches its full radius (the body can be wider than the rim, e.g. 9,3 x 62)
    const rimEdgeZ = g.profile.points.find((p) => Math.abs(p.r - v.R1 / 2) < 1e-6).z;
    specs.push({ id: 'R1', symbol: 'R1', value: v.R1, x: R1_LINE_X, rimEdgeZ });
    if (g.profile.key.grooveFloor) {
      const f = g.profile.key.grooveFloor;
      specs.push({ id: 'E1', symbol: 'E1', value: v.E1, x: (f.z0 + f.z1) / 2 });
    }
    specs.push({ id: 'P1', symbol: 'P1', value: v.P1, x: g.profile.key.bodyStart.z + BODY_OFFSET });
    if (v.P2 !== undefined && v.L1 !== undefined) specs.push({ id: 'P2', symbol: 'P2', value: v.P2, x: v.L1 - BODY_OFFSET });
    if (v.H1 !== undefined && v.L2 !== undefined) specs.push({ id: 'H1', symbol: 'H1', value: v.H1, x: v.L2 + NECK_OFFSET });
    specs.push({ id: 'H2', symbol: 'H2', value: v.H2, x: v.L3 - NECK_OFFSET });
    if (g.bullet) specs.push({ id: 'G1', symbol: 'G1', value: v.G1, x: g1Position(g) });
    return specs;
  }

  function g1Position(g) {
    const b = g.bullet;
    const visibleCylinder = b.zc - g.v.L3;
    return visibleCylinder > 1.2 ? g.v.L3 + visibleCylinder / 2 : g.v.L3 + Math.max(0.2, visibleCylinder / 2);
  }

  function diameterItem(spec, leaderTopY) {
    const half = spec.value / 2;
    const lines = [
      line('dimension-line', spec.x, -half, spec.x, half),
      line('extension-line', spec.x, -half, spec.x, leaderTopY),
    ];
    if (spec.id === 'R1') {
      const startX = spec.rimEdgeZ - 0.6;
      lines.push(line('extension-line', startX, -half, spec.x - 1.5, -half), line('extension-line', startX, half, spec.x - 1.5, half));
    }
    return {
      id: spec.id,
      kind: 'diameter',
      lines,
      arrows: [arrow(spec.x, -half, 0, -1), arrow(spec.x, half, 0, 1)],
    };
  }

  function alphaSpec(ctx) {
    const { g } = ctx;
    const sh = g.shoulder;
    if (!sh || !sh.apex || g.v.alpha === undefined) return null;
    const mid = { z: (sh.start.z + sh.end.z) / 2, r: (sh.start.r + sh.end.r) / 2 };
    const radius = Math.hypot(sh.apex.z - mid.z, mid.r);
    const half = Math.atan2(mid.r, sh.apex.z - mid.z);
    return { id: 'alpha', symbol: 'α', text: `α ${format.formatAngle(g.v.alpha)}`, x: mid.z, mid, apex: sh.apex, radius, half };
  }

  function alphaItem(spec, leaderTopY) {
    const { apex, radius, half, mid } = spec;
    const end = (sign) => ({ x: apex.z - radius * Math.cos(half), y: sign * radius * Math.sin(half) });
    const upper = end(-1);
    const lower = end(1);
    // Arc point at angle phi: (apex.z - radius*cos(phi), radius*sin(phi)), phi from -half (upper end) to +half.
    // Arrowheads point along the arc, away from the axis crossing.
    const upDir = { dx: Math.sin(half), dy: -Math.cos(half) };
    const downDir = { dx: Math.sin(half), dy: Math.cos(half) };
    return {
      id: 'alpha',
      kind: 'angle',
      lines: [line('extension-line', upper.x, upper.y, upper.x, leaderTopY)],
      arc: { cx: apex.z, cy: 0, radius, x1: upper.x, y1: upper.y, x2: lower.x, y2: lower.y, sweep: 0 },
      arrows: [arrow(upper.x, upper.y, upDir.dx, upDir.dy), arrow(lower.x, lower.y, downDir.dx, downDir.dy)],
      mid,
    };
  }

  // ---- row assignment ---------------------------------------------------------------------------------------

  function rowCenterY(ctx, row) {
    return -(ctx.rmax + 5 + row * ROW_PITCH);
  }

  function candidateRect(text, x, row, align, ctx) {
    const yc = rowCenterY(ctx, row);
    const baseline = yc + 0.35 * FONT;
    const anchor = align;
    const ax = align === 'start' ? x + LABEL_GAP : x - LABEL_GAP;
    return { text, x: ax, baseline, anchor, rect: labelRect(text, ax, baseline, anchor) };
  }

  const within = (x, rect, pad) => x >= rect.x0 - pad && x <= rect.x1 + pad;
  const rectsTouch = (a, b, pad) => a.x0 < b.x1 + pad && b.x0 < a.x1 + pad && a.y0 < b.y1 + pad && b.y0 < a.y1 + pad;

  /** A leader at x reaches up to its row; it must not run through a label sitting at or below that row. */
  function conflicts(a, b) {
    if (rectsTouch(a.cand.rect, b.cand.rect, LABEL_SEPARATION)) return true;
    if (b.row <= a.row && within(a.x, b.cand.rect, LABEL_SEPARATION / 2)) return true;
    if (a.row <= b.row && within(b.x, a.cand.rect, LABEL_SEPARATION / 2)) return true;
    return false;
  }

  function searchRows(entries, maxRows, ctx) {
    const placed = [];
    let nodes = 0;
    const visit = (index) => {
      if (index === entries.length) return true;
      const e = entries[index];
      for (let row = 0; row < maxRows; row += 1) {
        for (const align of ['start', 'end']) {
          nodes += 1;
          if (nodes > ctx.maxNodes) return false;
          const cand = candidateRect(e.text, e.x, row, align, ctx);
          const here = { x: e.x, row, cand, id: e.id };
          if (placed.some((p) => conflicts(here, p))) continue;
          placed.push(here);
          if (visit(index + 1)) return true;
          placed.pop();
        }
      }
      return false;
    };
    return visit(0) ? placed.slice() : null;
  }

  function assignRows(entries, ctx) {
    for (let maxRows = 1; maxRows <= entries.length; maxRows += 1) {
      const found = searchRows(entries, maxRows, ctx);
      if (found) return found;
    }
    // Guaranteed layout: a descending staircase of start-aligned labels.
    return entries.map((e, i) => {
      const row = entries.length - 1 - i;
      return { x: e.x, row, id: e.id, cand: candidateRect(e.text, e.x, row, 'start', ctx) };
    });
  }

  function topItems(ctx) {
    const specs = diameterSpecs(ctx);
    const alpha = alphaSpec(ctx);
    const entries = [
      ...specs.map((s) => ({ id: s.id, x: s.x, text: `${s.symbol} ${format.formatNumber(s.value)}` })),
      ...(alpha ? [{ id: 'alpha', x: alpha.x, text: alpha.text }] : []),
    ].sort((a, b) => a.x - b.x);
    const placement = new Map(assignRows(entries, ctx).map((p) => [p.id, p]));
    const make = (id, build) => {
      const p = placement.get(id);
      const item = build(rowCenterY(ctx, p.row));
      return { ...item, row: p.row, label: p.cand };
    };
    const items = specs.map((s) => make(s.id, (top) => diameterItem(s, top)));
    if (alpha) items.push(make('alpha', (top) => alphaItem(alpha, top)));
    return items;
  }

  // ---- title block and view box --------------------------------------------------------------------------------

  const scaleLine = (scale) => `Scale ${scale.toFixed(2)}:1 on A4 print (1 unit = 1 mm)`;

  function titleLines(meta, scale) {
    return [
      { text: meta.name, size: TITLE.nameSize, bold: true, step: TITLE.nameStep },
      { text: `C.I.P. table ${meta.tab} · revised ${meta.revised}`, size: TITLE.textSize, step: TITLE.textStep },
      { text: 'Dimensions in mm', size: TITLE.textSize, step: TITLE.textStep },
      { text: scaleLine(scale), size: TITLE.textSize, step: TITLE.textStep },
    ];
  }

  function titleBlock(meta, scale, centerX, top) {
    const lines = titleLines(meta, scale);
    const width = Math.max(...lines.map((l) => textWidth(l.text, l.size))) + 2 * TITLE.pad;
    const x0 = centerX - width / 2;
    let y = top + TITLE.pad;
    const placed = lines.map((l) => {
      y += l.step;
      return { text: l.text, size: l.size, bold: !!l.bold, x: x0 + TITLE.pad, y: y - 0.25 * l.size };
    });
    const bottom = y + TITLE.pad * 0.6;
    return { rect: { x0, y0: top, x1: x0 + width, y1: bottom }, lines: placed };
  }

  function bounds(ctx, items) {
    const b = { x0: 0, y0: -ctx.rmax, x1: ctx.v.L6 !== undefined && ctx.g.bullet ? ctx.v.L6 : ctx.v.L3, y1: ctx.rmax };
    const grow = (x, y) => {
      b.x0 = Math.min(b.x0, x);
      b.x1 = Math.max(b.x1, x);
      b.y0 = Math.min(b.y0, y);
      b.y1 = Math.max(b.y1, y);
    };
    for (const it of items) {
      grow(it.label.rect.x0, it.label.rect.y0);
      grow(it.label.rect.x1, it.label.rect.y1);
      for (const l of it.lines) {
        grow(l.x1, l.y1);
        grow(l.x2, l.y2);
      }
      for (const a of it.arrows) grow(a.x - a.dx * ARROW_LENGTH, a.y - a.dy * ARROW_LENGTH);
    }
    return b;
  }

  /**
   * @param {object} g geometry from CIP.geometry.build
   * @param {{maxSearchNodes?: number}} [options] cap for the label-row search (the tests lower it to reach the fallback)
   * @returns {object|null} items (with label rectangles), title block and view box; null when g is not drawable
   */
  function layout(g, options = {}) {
    if (!g || !g.ok) return null;
    const ctx = makeContext(g, options);
    const bottom = lengthSpecs(ctx).map((spec, row) => lengthItem(ctx, spec, row));
    const items = [...bottom, ...topItems(ctx)];
    relocateShortLabel(items);
    const content = bounds(ctx, items);
    const centerX = (content.x0 + content.x1) / 2;
    // The block's size does not depend on the scale digits, so it is placed once to size the view box and
    // written again with the scale that view box implies.
    const sizing = titleBlock(g.meta, 0, centerX, content.y1 + TITLE.gap);
    const x0 = Math.min(content.x0, sizing.rect.x0) - VIEW_MARGIN;
    const x1 = Math.max(content.x1, sizing.rect.x1) + VIEW_MARGIN;
    const y0 = content.y0 - VIEW_MARGIN;
    const y1 = sizing.rect.y1 + VIEW_MARGIN;
    const viewBox = { x: x0, y: y0, w: x1 - x0, h: y1 - y0 };
    const printScale = Math.min(PRINT_AREA.width / viewBox.w, PRINT_AREA.height / viewBox.h);
    const title = titleBlock(g.meta, printScale, centerX, content.y1 + TITLE.gap);
    return { items, title, viewBox, rmax: ctx.rmax, font: FONT };
  }

  // ---- geometry helper ----------------------------------------------------------------------------------------

  /** Does segment s touch rect r (expanded by pad)? Liang-Barsky clipping. */
  function segmentHitsRect(s, r, pad = 0) {
    const x0 = r.x0 - pad;
    const x1 = r.x1 + pad;
    const y0 = r.y0 - pad;
    const y1 = r.y1 + pad;
    const dx = s.x2 - s.x1;
    const dy = s.y2 - s.y1;
    let t0 = 0;
    let t1 = 1;
    const clip = (p, q) => {
      if (p === 0) return q >= 0;
      const t = q / p;
      if (p < 0) {
        if (t > t1) return false;
        if (t > t0) t0 = t;
      } else {
        if (t < t0) return false;
        if (t < t1) t1 = t;
      }
      return true;
    };
    return clip(-dx, s.x1 - x0) && clip(dx, x1 - s.x1) && clip(-dy, s.y1 - y0) && clip(dy, y1 - s.y1);
  }

  const api = { layout, segmentHitsRect, FONT, ARROW_LENGTH, ARROW_HALF_WIDTH, PRINT_AREA };
  CIP.dimensions = api;
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
})(typeof window !== 'undefined' ? window : globalThis);
