'use strict';
// Renders the cartridge drawing as an SVG markup string from geometry + dimension layout. No DOM access.
// 1 user unit = 1 mm; x = z along the axis (head on the left); upper half (y < 0) outside view, lower half section.
(function (global) {
  const CIP = (global.CIP = global.CIP || {});
  const geometry = CIP.geometry || require('./geometry.js');
  const dimensions = CIP.dimensions || require('./dimensions.js');
  const format = CIP.format || require('./format.js');
  const { radiusAt } = CIP.mathutil || require('./mathutil.js');

  const { FONT, ARROW_LENGTH, ARROW_HALF_WIDTH } = dimensions;
  const CENTRE_LINE_OVERHANG = 3;
  const HATCH_PITCH = 1;
  const CENTRE_DASH = '6 1.2 1 1.2';
  const SVG_NS = 'http://www.w3.org/2000/svg';

  const num = (n) => String(Math.round(n * 1000) / 1000);
  const esc = format.escapeHtml;

  const pathOf = (pts, sign, close = false) =>
    pts.map((p, i) => `${i === 0 ? 'M' : 'L'} ${num(p.z)} ${num(sign * p.r)}`).join(' ') + (close ? ' Z' : '');

  const lineEl = (cls, x1, y1, x2, y2, extra = '') =>
    `<line class="${cls}" x1="${num(x1)}" y1="${num(y1)}" x2="${num(x2)}" y2="${num(y2)}"${extra}/>`;

  function arrowPath(a) {
    const bx = a.x - a.dx * ARROW_LENGTH;
    const by = a.y - a.dy * ARROW_LENGTH;
    const nx = -a.dy * ARROW_HALF_WIDTH;
    const ny = a.dx * ARROW_HALF_WIDTH;
    return `<path class="arrowhead" d="M ${num(a.x)} ${num(a.y)} L ${num(bx + nx)} ${num(by + ny)} L ${num(bx - nx)} ${num(by - ny)} Z"/>`;
  }

  function dimensionGroup(item) {
    const parts = item.lines.map((l) => lineEl(l.cls, l.x1, l.y1, l.x2, l.y2));
    if (item.arc) {
      const a = item.arc;
      parts.push(
        `<path class="dimension-line" fill="none" d="M ${num(a.x1)} ${num(a.y1)} A ${num(a.radius)} ${num(a.radius)} 0 0 ${a.sweep} ${num(a.x2)} ${num(a.y2)}"/>`,
      );
    }
    parts.push(...item.arrows.map(arrowPath));
    const { label } = item;
    parts.push(
      `<text class="dim-label" x="${num(label.x)}" y="${num(label.baseline)}" text-anchor="${label.anchor}" font-size="${FONT}">${esc(label.text)}</text>`,
    );
    return `<g class="dim" data-dim="${esc(item.id)}">${parts.join('')}</g>`;
  }

  /** Circle edges seen from the side: thin lines from the silhouette to the axis where the profile changes direction. */
  function edgeLines(g) {
    const pts = g.profile.points;
    const byZ = new Map();
    const add = (z, r) => {
      const key = num(z);
      if (z > 1e-9 && z < g.v.L3 - 1e-9 && (!byZ.has(key) || byZ.get(key) < r)) byZ.set(key, r);
    };
    for (const p of pts) if (p.edge && !p.mouth) add(p.z, p.r);
    const { shoulderStart, shoulderEnd } = g.profile.key;
    for (const corner of [shoulderStart, shoulderEnd]) if (corner) add(corner.z, radiusAt(pts, corner.z));
    const edges = [...byZ].map(([z, r]) => lineEl('edge', Number(z), -r, Number(z), 0));
    const b = g.bullet;
    if (b && b.zc > g.v.L3 + 1e-9) edges.push(lineEl('edge', b.zc, -b.d / 2, b.zc, 0));
    return edges;
  }

  function outsideView(g) {
    const pts = g.profile.points;
    const mouth = pts[pts.length - 1];
    const parts = [`<path class="outline outline-upper" fill="none" d="${pathOf(pts, -1)}"/>`];
    parts.push(...edgeLines(g));
    const bulletR = g.bullet ? g.bullet.visible[0].r : 0;
    parts.push(lineEl('outline', mouth.z, -mouth.r, mouth.z, -bulletR));
    if (g.bullet) parts.push(`<path class="outline bullet-visible" fill="none" d="${pathOf(g.bullet.visible, -1)}"/>`);
    return `<g class="view-outside">${parts.join('')}</g>`;
  }

  function sectionView(g) {
    const parts = [];
    if (g.section) {
      parts.push(`<path class="cut cut-case" fill="url(#hatch-case)" d="${pathOf(g.section.polygon, 1, true)}"/>`);
      if (g.section.bullet) {
        parts.push(`<path class="cut cut-bullet" fill="url(#hatch-bullet)" d="${pathOf(g.section.bullet.polygon, 1, true)}"/>`);
      }
    } else {
      parts.push(`<path class="outline outline-lower" fill="none" d="${pathOf(g.profile.points, 1)}"/>`);
      if (g.bullet) parts.push(`<path class="outline" fill="none" d="${pathOf(g.bullet.outline, 1)}"/>`);
    }
    return `<g class="view-section">${parts.join('')}</g>`;
  }

  function defs() {
    const hatch = (id, angle) =>
      `<pattern id="${id}" patternUnits="userSpaceOnUse" width="${HATCH_PITCH}" height="${HATCH_PITCH}" patternTransform="rotate(${angle})">` +
      `<line class="hatch-line" x1="0" y1="0" x2="0" y2="${HATCH_PITCH}"/></pattern>`;
    return `<defs>${hatch('hatch-case', 45)}${hatch('hatch-bullet', -45)}</defs>`;
  }

  function titleBlock(title) {
    const r = title.rect;
    const texts = title.lines.map(
      (l) =>
        `<text class="title-text${l.bold ? ' title-name' : ''}" x="${num(l.x)}" y="${num(l.y)}" font-size="${l.size}">${esc(l.text)}</text>`,
    );
    const frame = `<rect class="title-frame" x="${num(r.x0)}" y="${num(r.y0)}" width="${num(r.x1 - r.x0)}" height="${num(r.y1 - r.y0)}"/>`;
    return `<g class="title-block">${frame}${texts.join('')}</g>`;
  }

  function renderSvg(g, layout, options = {}) {
    const describedBy = options.describedBy ? ` aria-describedby="${esc(options.describedBy)}"` : '';
    const vb = layout.viewBox;
    const tip = g.bullet ? g.v.L6 : g.v.L3;
    const centre = lineEl('centre-line', -CENTRE_LINE_OVERHANG, 0, tip + CENTRE_LINE_OVERHANG, 0, ` stroke-dasharray="${CENTRE_DASH}"`);
    return (
      `<svg xmlns="${SVG_NS}" class="drawing" role="img" aria-label="${esc(g.name)} drawing"${describedBy} ` +
      `viewBox="${num(vb.x)} ${num(vb.y)} ${num(vb.w)} ${num(vb.h)}" preserveAspectRatio="xMidYMid meet">` +
      `${defs()}${sectionView(g)}${outsideView(g)}${centre}` +
      `<g class="dimensions">${layout.items.map(dimensionGroup).join('')}</g>${titleBlock(layout.title)}</svg>`
    );
  }

  /**
   * @param {object} record
   * @param {{describedBy?: string}} [options] id of the element describing the drawing (notes, facts)
   * @returns {{ok:boolean, svg:string, notes:string[], geometry:object, layout:object|null, facts:object|null}}
   */
  function build(record, options = {}) {
    const g = geometry.build(record);
    if (!g.ok) return { ok: false, svg: '', notes: g.notes, geometry: g, layout: null, facts: null };
    const layout = dimensions.layout(g);
    return {
      ok: true,
      svg: renderSvg(g, layout, options),
      notes: g.notes,
      geometry: g,
      layout,
      facts: { rimType: g.rimType, bulletShape: g.bullet ? g.bullet.shape : null },
    };
  }

  const api = { build, renderSvg };
  CIP.drawing = api;
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
})(typeof window !== 'undefined' ? window : globalThis);
