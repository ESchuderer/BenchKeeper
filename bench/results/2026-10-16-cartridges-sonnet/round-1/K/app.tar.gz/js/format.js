'use strict';
// Formatting of record values, symbols, units, tolerances and search matching. Pure functions, no DOM.
(function (global) {
  const CIP = (global.CIP = global.CIP || {});

  const ANGLE_FIELDS = new Set(['alpha', 'alpha1', 'beta', 'delta', 'i']);

  const UNITS = {
    Pmax: 'bar',
    PK: 'bar',
    PE: 'bar',
    EE: 'J',
    M: 'g',
    Q: 'mm²',
    N: '',
  };

  const SYMBOLS = {
    eMin: 'e min',
    r1Min: 'r1 min',
    r1Max: 'r1 max',
    alpha: 'α',
    alpha1: 'α1',
    beta: 'β',
    delta: 'δ',
    deltaL: 'delta L',
    L3PlusG: 'L3 + G',
  };

  const TOLERANCE_SUFFIX = 'Tol';

  const SECTION_TITLES = {
    caseHead: 'Case head',
    collar: 'Collar',
    junctionCone: 'Junction cone',
    lengths: 'Lengths',
    misc: 'Miscellaneous',
    powderChamber: 'Powder chamber',
    pressures: 'Pressures',
    projectile: 'Projectile',
    barrel: 'Barrel',
    breech: 'Breech',
    grooves: 'Grooves',
    rifling: 'Rifling',
  };

  const SECTION_ORDER = {
    cartridge: ['caseHead', 'collar', 'junctionCone', 'lengths', 'misc', 'powderChamber', 'pressures', 'projectile'],
    chamber: ['barrel', 'breech', 'collar', 'grooves', 'junctionCone', 'lengths', 'powderChamber', 'rifling'],
  };

  // Row order inside a section: published order, except where a reader expects the main figure first.
  const ROW_ORDER = {
    pressures: ['Pmax', 'PK', 'PE', 'EE', 'M'],
  };

  const isAngleField = (field) => ANGLE_FIELDS.has(field);
  const isTolField = (field) => field.length > TOLERANCE_SUFFIX.length && field.endsWith(TOLERANCE_SUFFIX);

  const formatNumber = (n) => String(n);

  function formatAngle(angle) {
    if (typeof angle === 'number') return `${formatNumber(angle)}°`;
    return `${formatNumber(angle.degrees)}°${formatNumber(angle.minutes)}'${formatNumber(angle.seconds)}"`;
  }

  const formatValue = (field, value) => (isAngleField(field) ? formatAngle(value) : formatNumber(value));

  function unitFor(field) {
    if (isAngleField(field)) return '°';
    return Object.prototype.hasOwnProperty.call(UNITS, field) ? UNITS[field] : 'mm';
  }

  const symbolFor = (field) => (Object.prototype.hasOwnProperty.call(SYMBOLS, field) ? SYMBOLS[field] : field);

  function orderedFields(sectionKey, section) {
    const fields = Object.keys(section).filter((f) => !isTolField(f));
    const preferred = ROW_ORDER[sectionKey];
    if (!preferred) return fields;
    const rank = (f) => (preferred.includes(f) ? preferred.indexOf(f) : preferred.length);
    return fields
      .map((f, index) => ({ f, index }))
      .sort((a, b) => rank(a.f) - rank(b.f) || a.index - b.index)
      .map((x) => x.f);
  }

  function sectionRows(sectionKey, section) {
    return orderedFields(sectionKey, section).map((field) => {
      const value = formatValue(field, section[field]);
      const tolField = field + TOLERANCE_SUFFIX;
      const tol = Object.prototype.hasOwnProperty.call(section, tolField) ? formatNumber(section[tolField]) : null;
      return {
        field,
        symbol: symbolFor(field),
        value,
        tol,
        display: tol === null ? value : `${value} ${tol}`,
        unit: unitFor(field),
      };
    });
  }

  function groupSections(group, data) {
    return SECTION_ORDER[group]
      .filter((key) => data[key] && Object.keys(data[key]).length > 0)
      .map((key) => ({ key, title: SECTION_TITLES[key], rows: sectionRows(key, data[key]) }));
  }

  const normalizeSearch = (text) => String(text).toLowerCase().replace(/,/g, '.').replace(/\s+/g, ' ').trim();

  const namesOf = (record) => [record.name, ...(record.alternativeNames || [])];

  function matchesQuery(record, query) {
    const q = normalizeSearch(query);
    if (q === '') return true;
    return namesOf(record).some((name) => normalizeSearch(name).includes(q));
  }

  function filterRecords(records, { query = '', family = '' } = {}) {
    return records.filter((r) => (family === '' || r.family === family) && matchesQuery(r, query));
  }

  // Alternative names to show when a record is listed only because one of them matched.
  function alternativeMatch(record, query) {
    const q = normalizeSearch(query);
    if (q === '' || !record.alternativeNames || normalizeSearch(record.name).includes(q)) return null;
    return record.alternativeNames.some((n) => normalizeSearch(n).includes(q)) ? [...record.alternativeNames] : null;
  }

  const HTML_ESCAPES = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' };
  const escapeHtml = (text) => String(text).replace(/[&<>"']/g, (c) => HTML_ESCAPES[c]);

  const api = {
    formatNumber,
    formatAngle,
    unitFor,
    symbolFor,
    sectionRows,
    groupSections,
    normalizeSearch,
    matchesQuery,
    filterRecords,
    alternativeMatch,
    escapeHtml,
  };
  CIP.format = api;
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
})(typeof window !== 'undefined' ? window : globalThis);
