'use strict';
// Cartridge case geometry computed from a record's published values. Pure functions, no DOM.
// z runs along the axis from the head face (z = 0) to the mouth; r is the radius (half the diameter).
(function (global) {
  const CIP = (global.CIP = global.CIP || {});
  const M = CIP.mathutil || require('./mathutil.js');
  const Bullet = CIP.bullet || require('./bullet.js');
  const { pt, dedupe, radiusAt, arcPoints, fillet, toDegrees, DEG, EPS } = M;

  const RIMMED_RATIO = 1.05;
  const REBATED_RATIO = 0.98;
  const MIN_SOLID_HEAD = 2.5;
  const MIN_BODY_WALL = 0.6;
  const BODY_WALL_PER_NECK_WALL = 1.3;
  const BODY_WALL_LIMIT = 0.35;
  const POCKET_CLEARANCE = 1.5;
  const FILLET_FRACTION = 0.45;

  const POCKET_DIAMETER = { sp: 4.45, spm: 4.45, sr: 4.45, lp: 5.33, lpm: 5.33, lr: 5.33, lrm: 5.33 };
  const POCKET_DEPTH = { sp: 3.04, spm: 3.04, sr: 3.04, lp: 3.04, lpm: 3.04, lr: 3.3, lrm: 3.3 };

  const ESSENTIAL = [
    ['R1', (v) => v.R1],
    ['R', (v) => v.R],
    ['P1', (v) => v.P1],
    ['H2', (v) => v.H2],
    ['L3', (v) => v.L3],
  ];

  const isNum = (x) => typeof x === 'number' && Number.isFinite(x);
  const list = (values) => values.join(', ');

  function readValues(record) {
    const c = record.cartridge;
    const head = c.caseHead || {};
    const get = (section, key) => (c[section] && isNum(c[section][key]) ? c[section][key] : undefined);
    const angle = (value) => (value === undefined ? undefined : toDegrees(value));
    const v = {
      R: head.R, R1: head.R1, R3: head.R3, E: head.E, E1: head.E1, eMin: head.eMin, f: head.f,
      beta: angle(head.beta), delta: angle(head.delta),
      P1: get('powderChamber', 'P1'), P2: get('powderChamber', 'P2'),
      H1: get('collar', 'H1'), H2: get('collar', 'H2'),
      L1: get('lengths', 'L1'), L2: get('lengths', 'L2'), L3: get('lengths', 'L3'), L6: get('lengths', 'L6'),
      G1: get('projectile', 'G1'),
      alpha: c.junctionCone ? c.junctionCone.alpha : undefined,
      r1Min: get('junctionCone', 'r1Min'), r2: get('junctionCone', 'r2'),
    };
    return Object.fromEntries(Object.entries(v).filter(([, value]) => value !== undefined));
  }

  function rimTypeOf(family, R1, P1) {
    if (family === 'belted') return 'belted';
    if (family === 'rimfire') return 'rimfire';
    const ratio = R1 / P1;
    if (ratio >= RIMMED_RATIO) return 'rimmed';
    if (ratio < REBATED_RATIO) return 'rebated';
    return 'rimless';
  }

  /** Collects missing-value reports; each becomes a note under the drawing. */
  function createReport() {
    const missing = [];
    const notes = [];
    return {
      missing,
      notes,
      add(feature, values, text) {
        missing.push({ feature, values });
        notes.push(text || `${feature} not drawn: ${list(values)} not published.`);
      },
    };
  }

  // ---- outer half-profile -------------------------------------------------------------------------------------

  function rimfireHead(v) {
    const edgeRadius = Math.min(v.R / 2, (v.R1 - v.P1) / 2);
    const cx = v.R1 / 2 - edgeRadius; // radius of the half-round's centre line; its outermost point lies at R1/2
    const points = [pt(0, 0), pt(0, cx)];
    if (v.R / 2 - edgeRadius > EPS) points.push(pt(v.R / 2 - edgeRadius, cx));
    // half-round: the angle runs from pi to 0, so z goes from R/2 - rho to R/2 + rho and r bulges out to cx + rho = R1/2
    const arc = arcPoints(v.R / 2, cx, edgeRadius, Math.PI, 0);
    points.push(...arc);
    if (v.R - (v.R / 2 + edgeRadius) > EPS) points.push({ ...pt(v.R, cx), edge: true });
    return { points: dedupe(points), edgeRadius };
  }

  function headProfile(v, rimType, report) {
    if (rimType === 'rimfire') return rimfireHead(v);
    const points = [pt(0, 0)];
    const absent = [['β', v.beta], ['f', v.f]].filter(([, value]) => !isNum(value)).map(([symbol]) => symbol);
    if (absent.length === 0 && v.beta < 90) {
      const chamfer = Math.min(v.f * Math.tan(v.beta * DEG), v.R1 / 4);
      points.push(pt(0, v.R1 / 2 - chamfer), { ...pt(v.f, v.R1 / 2), edge: true });
    } else {
      if (absent.length) report.add('Head chamfer', absent, `Head chamfer not drawn (square corner): ${list(absent)} not published.`);
      points.push(pt(0, v.R1 / 2));
    }
    points.push({ ...pt(v.R, v.R1 / 2), edge: true });
    return { points, edgeRadius: null };
  }

  function grooveProfile(v, rimType, report, points) {
    const key = { grooveFloor: null, beltRampEnd: null, bodyStart: null };
    const hasGroove = isNum(v.E) && isNum(v.E1) && isNum(v.eMin) && rimType !== 'rimfire';
    if (!hasGroove) {
      if (rimType === 'rimless' || rimType === 'rebated' || rimType === 'belted') {
        const absent = ['E', 'E1', 'e min'].filter((s) => !isNum(v[s === 'e min' ? 'eMin' : s]));
        report.add('Extractor groove', absent);
      }
      points.push({ ...pt(v.R, v.P1 / 2), edge: true });
      key.bodyStart = pt(v.R, v.P1 / 2);
      return key;
    }
    points.push({ ...pt(v.R, v.E1 / 2), edge: true }, { ...pt(v.R + v.eMin, v.E1 / 2), edge: true });
    key.grooveFloor = { z0: v.R, z1: v.R + v.eMin, r: v.E1 / 2 };
    const beltPossible = rimType === 'belted' && isNum(v.R3) && isNum(v.delta) && v.delta > 0;
    if (rimType === 'belted' && !beltPossible) {
      report.add('Belt', ['R3', 'δ'].filter((s) => !isNum(v[s === 'δ' ? 'delta' : s])));
    }
    if (beltPossible) {
      const rampEnd = pt(v.R + v.eMin + (v.R3 / 2 - v.E1 / 2) / Math.tan(v.delta * DEG), v.R3 / 2);
      points.push({ ...rampEnd, edge: true }, { ...pt(v.E, v.R3 / 2), edge: true });
      key.beltRampEnd = rampEnd;
    }
    points.push({ ...pt(v.E, v.P1 / 2), edge: true });
    key.bodyStart = pt(v.E, v.P1 / 2);
    return key;
  }

  function shoulderState(v, report) {
    const needed = ['alpha', 'L1', 'L2'];
    const absent = needed.filter((k) => v[k] === undefined);
    if (absent.length === needed.length) {
      report.add('Shoulder', ['α', 'L1', 'L2'], 'Straight case: no shoulder drawn (α, L1, L2 not published).');
      return false;
    }
    const names = { alpha: 'α', L1: 'L1', L2: 'L2' };
    if (absent.length) {
      const text = `Shoulder not drawn: ${list(absent.map((k) => names[k]))} not published; the case is drawn straight.`;
      report.add('Shoulder', absent.map((k) => names[k]), text);
      return false;
    }
    const lacking = ['P2', 'H1'].filter((k) => v[k] === undefined);
    if (lacking.length) {
      report.add('Shoulder', lacking, `Shoulder not drawn: ${list(lacking)} not published; the case is drawn straight.`);
      return false;
    }
    return true;
  }

  function bodyToMouth(v, report, points, bodyStart) {
    const mouth = pt(v.L3, v.H2 / 2);
    const key = { shoulderStart: null, shoulderEnd: null, mouth };
    if (!shoulderState(v, report)) {
      points.push({ ...mouth, edge: true, mouth: true });
      return { key, shoulder: null };
    }
    const s0 = pt(v.L1, v.P2 / 2);
    const s1 = pt(v.L2, v.H1 / 2);
    key.shoulderStart = s0;
    key.shoulderEnd = s1;
    const f1 = v.r1Min > 0 ? fillet(bodyStart, s0, s1, v.r1Min, FILLET_FRACTION) : null;
    const f2 = v.r2 > 0 ? fillet(s0, s1, mouth, v.r2, FILLET_FRACTION) : null;
    const missingRadii = ['r1Min', 'r2'].filter((k) => !(v[k] > 0));
    if (missingRadii.length) {
      const names = missingRadii.map((k) => (k === 'r1Min' ? 'r1 min' : 'r2'));
      report.add('Shoulder corner rounding', names);
    }
    pushCorner(points, f1, s0);
    pushCorner(points, f2, s1);
    points.push({ ...mouth, edge: true, mouth: true });
    const halfAngle = Math.atan((s0.r - s1.r) / (s1.z - s0.z));
    const apex = halfAngle > 0 ? pt(s0.z + s0.r / Math.tan(halfAngle), 0) : null;
    return { key, shoulder: { start: s0, end: s1, apex, halfAngle, published: v.alpha } };
  }

  function pushCorner(points, rounded, corner) {
    if (!rounded) {
      points.push({ ...corner, edge: true });
      return;
    }
    points.push(...rounded.points);
  }

  // ---- section: walls, solid head, pocket ---------------------------------------------------------------------

  /** Neck wall tn and body wall tb of the brief; null while G1 is unknown. */
  function bodyWall(v) {
    if (!isNum(v.G1)) return null;
    const tn = (v.H2 - v.G1) / 2;
    const tb = Math.min(Math.max(BODY_WALL_PER_NECK_WALL * tn, MIN_BODY_WALL), (BODY_WALL_LIMIT * v.P1) / 2);
    return { tn, tb };
  }

  function wallThickness(v, bullet) {
    const wall = bodyWall(v);
    if (!wall) return null;
    // a heeled bullet fills the case at its inside diameter, so the wall stays tb where it is seated
    return { ...wall, tnEffective: bullet && bullet.heeled ? wall.tb : wall.tn };
  }

  function pocketOf(primerType, rimType, report) {
    if (rimType === 'rimfire') return null;
    if (!Object.prototype.hasOwnProperty.call(POCKET_DIAMETER, primerType)) {
      report.add('Primer pocket', ['primer type'], 'Primer pocket not drawn: primer type not published or unknown.');
      return null;
    }
    return { d: POCKET_DIAMETER[primerType], depth: POCKET_DEPTH[primerType] };
  }

  function solidHeadLength(v, pocket, key, tb) {
    const candidates = [MIN_SOLID_HEAD, (0.25 * v.P1) / 2];
    if (pocket) candidates.push(pocket.depth + POCKET_CLEARANCE);
    if (key.beltRampEnd) candidates.push(key.beltRampEnd.z + tb);
    else if (key.grooveFloor) candidates.push(v.E + tb);
    return Math.max(...candidates);
  }

  /** Wall thickness along z: tb on the body, tn on the neck, linear across the shoulder (or into the seat). */
  /** Straight cases have no shoulder: the wall ramps from tb to tn at 45 degrees, ending where the bullet is seated. */
  function wallProfile(shoulder, walls, seatStart) {
    const { tb, tnEffective: tn } = walls;
    const stops = shoulder
      ? [[shoulder.start.z, tb], [shoulder.end.z, tn]]
      : isNum(seatStart) ? [[seatStart - Math.abs(tb - tn), tb], [seatStart, tn]] : [];
    const thickness = (z) => {
      if (!stops.length) return tb;
      if (z <= stops[0][0]) return tb;
      if (z >= stops[1][0]) return tn;
      return tb + ((tn - tb) * (z - stops[0][0])) / (stops[1][0] - stops[0][0]);
    };
    return { thickness, breakpoints: stops.map((s) => s[0]) };
  }

  function innerLine(v, outer, bodyIndex, w, wall) {
    const bodyPoly = [pt(0, v.P1 / 2), ...outer.slice(bodyIndex)];
    const zs = new Set([w, v.L3, ...wall.breakpoints.filter((z) => z > w && z < v.L3)]);
    for (const p of outer) if (p.z > w && p.z < v.L3) zs.add(p.z);
    return [...zs].sort((a, b) => a - b).map((z) => pt(z, radiusAt(bodyPoly, z) - wall.thickness(z)));
  }

  function sectionPolygon(outer, inner, w, pocket) {
    const head = pocket ? [pt(pocket.depth, 0), pt(pocket.depth, pocket.d / 2), pt(0, pocket.d / 2)] : [pt(0, 0)];
    const cut = inner.slice().reverse();
    const mouth = outer[outer.length - 1];
    return dedupe([...head, ...outer.slice(1), pt(mouth.z, cut[0].r), ...cut, pt(w, 0)]);
  }

  // ---- orchestration ------------------------------------------------------------------------------------------

  function buildWalls(v, key, shoulder, outer, bodyIndex, bullet, pocket, report) {
    const t = wallThickness(v, bullet);
    if (!t) {
      report.add('Section walls', ['G1']);
      return { walls: null, section: null };
    }
    const w = solidHeadLength(v, pocket, key, t.tb);
    const wall = wallProfile(shoulder, t, bullet ? bullet.zb : undefined);
    const inner = innerLine(v, outer, bodyIndex, w, wall);
    return {
      walls: { tn: t.tn, tb: t.tb, tnEffective: t.tnEffective, w, inner },
      section: { polygon: sectionPolygon(outer, inner, w, pocket) },
    };
  }

  function bulletInputs(record, v, tb) {
    return {
      shape: record.annotations && record.annotations.defaultBulletShape,
      category: record.annotations && record.annotations.category,
      G1: v.G1, L3: v.L3, L6: v.L6, H2: v.H2, tb,
    };
  }

  function buildBullet(record, v, report) {
    const absent = ['G1', 'L6'].filter((k) => !isNum(v[k]));
    if (absent.length) {
      report.add('Bullet', absent);
      return null;
    }
    const bullet = Bullet.build(bulletInputs(record, v, bodyWall(v).tb));
    if (bullet.unusable) {
      report.add('Bullet', [], `Bullet not drawn: ${bullet.unusable}.`);
      return null;
    }
    if (bullet.missing) {
      report.add('Bullet', bullet.missing);
      return null;
    }
    return bullet;
  }

  /**
   * @param {object} record one of the supplied cartridge records
   * @returns {object} geometry; `ok` is false (with `missing`/`notes`) when the outline itself cannot be drawn
   */
  function build(record) {
    const report = createReport();
    const v = readValues(record);
    const lacking = ESSENTIAL.filter(([, get]) => !isNum(get(v))).map(([name]) => name);
    if (lacking.length) {
      report.add('Drawing', lacking, `Drawing not possible: ${list(lacking)} not published.`);
      return { ok: false, name: record.name, key: record.key, v, missing: report.missing, notes: report.notes };
    }
    const rimType = rimTypeOf(record.family, v.R1, v.P1);
    const head = headProfile(v, rimType, report);
    const points = head.points;
    const grooveKey = grooveProfile(v, rimType, report, points);
    const bodyIndex = points.length - 1;
    const { key: caseKey, shoulder } = bodyToMouth(v, report, points, grooveKey.bodyStart);
    const key = { ...grooveKey, ...caseKey };

    const bullet = buildBullet(record, v, report);
    const primerType = record.annotations && record.annotations.primerType;
    const pocket = pocketOf(primerType, rimType, report);
    const { walls, section } = buildWalls(v, key, shoulder, points, bodyIndex, bullet, pocket, report);
    if (section && bullet) section.bullet = { polygon: bullet.outline };

    return {
      ok: true,
      name: record.name,
      key: record.key,
      meta: { name: record.name, tab: record.tab, revised: record.revised },
      v,
      rimType,
      category: record.annotations && record.annotations.category,
      shape: record.annotations && record.annotations.defaultBulletShape,
      primerType,
      rim: { edgeRadius: head.edgeRadius },
      profile: { points, bodyIndex, key },
      shoulder,
      bullet,
      walls,
      pocket,
      section,
      missing: report.missing,
      notes: report.notes,
    };
  }

  const api = { build };
  CIP.geometry = api;
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
})(typeof window !== 'undefined' ? window : globalThis);
