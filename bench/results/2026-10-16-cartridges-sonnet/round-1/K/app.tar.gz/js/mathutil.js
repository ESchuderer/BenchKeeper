'use strict';
// Small geometry helpers shared by the drawing modules. Points are {z, r}: z along the axis, r the radius.
(function (global) {
  const CIP = (global.CIP = global.CIP || {});

  const DEG = Math.PI / 180;
  const EPS = 1e-9;
  const ARC_STEP_DEG = 3;

  /** @param {number|{degrees:number,minutes:number,seconds:number}} angle @returns {number} degrees */
  function toDegrees(angle) {
    if (typeof angle === 'number') return angle;
    return angle.degrees + angle.minutes / 60 + angle.seconds / 3600;
  }

  const pt = (z, r) => ({ z, r });
  const dist = (a, b) => Math.hypot(a.z - b.z, a.r - b.r);

  /** Radius of a z-monotone polyline at z (the last segment wins at a vertical step). */
  function radiusAt(poly, z) {
    if (z <= poly[0].z) return poly[0].r;
    for (let i = poly.length - 1; i > 0; i -= 1) {
      const a = poly[i - 1];
      const b = poly[i];
      if (z >= a.z - EPS && z <= b.z + EPS && b.z - a.z > EPS) return a.r + ((b.r - a.r) * (z - a.z)) / (b.z - a.z);
    }
    return poly[poly.length - 1].r;
  }

  /** Points on an arc, both ends included: z = cz + rad*cos(a), r = cr + rad*sin(a), angles in radians. */
  function arcPoints(cz, cr, rad, a0, a1, stepDeg = ARC_STEP_DEG) {
    const n = Math.max(2, Math.ceil(Math.abs(a1 - a0) / (stepDeg * DEG)));
    const out = [];
    for (let i = 0; i <= n; i += 1) {
      const a = a0 + ((a1 - a0) * i) / n;
      out.push(pt(cz + rad * Math.cos(a), cr + rad * Math.sin(a)));
    }
    return out;
  }

  /**
   * Fillet of radius `radius` in the corner between prev->corner and corner->next.
   * The tangent length is limited to maxFrac of both adjoining segments. Returns null when there is no corner.
   */
  function fillet(prev, corner, next, radius, maxFrac = 0.45) {
    const lenIn = dist(prev, corner);
    const lenOut = dist(corner, next);
    if (lenIn < EPS || lenOut < EPS) return null; // a zero-length segment has no direction, hence no corner
    const d1 = { z: (corner.z - prev.z) / lenIn, r: (corner.r - prev.r) / lenIn };
    const d2 = { z: (next.z - corner.z) / lenOut, r: (next.r - corner.r) / lenOut };
    const dot = Math.max(-1, Math.min(1, d1.z * d2.z + d1.r * d2.r));
    const turn = Math.acos(dot);
    if (turn < 1e-6 || !(radius > 0)) return null;
    const tangentLimit = maxFrac * Math.min(lenIn, lenOut);
    const tangent = Math.min(radius * Math.tan(turn / 2), tangentLimit);
    const rad = tangent / Math.tan(turn / 2);
    const start = pt(corner.z - d1.z * tangent, corner.r - d1.r * tangent);
    const end = pt(corner.z + d2.z * tangent, corner.r + d2.r * tangent);
    const cross = d1.z * d2.r - d1.r * d2.z;
    const normal = cross > 0 ? { z: -d1.r, r: d1.z } : { z: d1.r, r: -d1.z };
    const center = pt(start.z + normal.z * rad, start.r + normal.r * rad);
    const a0 = Math.atan2(start.r - center.r, start.z - center.z);
    let sweep = Math.atan2(end.r - center.r, end.z - center.z) - a0;
    while (sweep > Math.PI) sweep -= 2 * Math.PI;
    while (sweep < -Math.PI) sweep += 2 * Math.PI;
    return { start, end, radius: rad, tangent, points: arcPoints(center.z, center.r, rad, a0, a0 + sweep) };
  }

  /** The part of a z-monotone polyline at or beyond zMin, starting exactly at zMin. */
  function clipFromZ(poly, zMin) {
    if (poly[0].z >= zMin) return poly.slice();
    for (let i = 1; i < poly.length; i += 1) {
      const a = poly[i - 1];
      const b = poly[i];
      if (b.z >= zMin && b.z > a.z) {
        const start = pt(zMin, a.r + ((b.r - a.r) * (zMin - a.z)) / (b.z - a.z));
        return [start, ...poly.slice(b.z - zMin < EPS ? i + 1 : i)].filter(
          (p, idx, all) => idx === 0 || dist(p, all[idx - 1]) > EPS || idx === all.length - 1,
        );
      }
    }
    return [];
  }

  /** Drops consecutive duplicate points. */
  function dedupe(points) {
    return points.filter((p, i) => i === 0 || dist(p, points[i - 1]) > EPS);
  }

  const api = { DEG, EPS, toDegrees, pt, dist, radiusAt, arcPoints, fillet, clipFromZ, dedupe };
  CIP.mathutil = api;
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
})(typeof window !== 'undefined' ? window : globalThis);
