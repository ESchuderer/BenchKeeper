'use strict';
// Hash routes: "#/" is the list, "#/cartridge/<key>" a detail view. Pure functions.
(function (global) {
  const CIP = (global.CIP = global.CIP || {});

  const LIST_HREF = '#/';
  const DETAIL_PREFIX = '#/cartridge/';

  function safeDecode(text) {
    try {
      return decodeURIComponent(text);
    } catch (error) {
      return text; // malformed escape: keep it verbatim, it will simply match no cartridge
    }
  }

  /** @param {string} hash location.hash @returns {{view:'list'}|{view:'detail', key:string}} */
  function parseHash(hash) {
    if (typeof hash === 'string' && hash.startsWith(DETAIL_PREFIX)) {
      return { view: 'detail', key: safeDecode(hash.slice(DETAIL_PREFIX.length).replace(/\/+$/, '')) };
    }
    return { view: 'list' };
  }

  const hrefFor = (key) => DETAIL_PREFIX + encodeURIComponent(key);

  const api = { parseHash, hrefFor, LIST_HREF };
  CIP.router = api;
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
})(typeof window !== 'undefined' ? window : globalThis);
