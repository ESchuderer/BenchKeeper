'use strict';
// DOM views: the list and the detail page. All markup is built from the embedded records and escaped.
(function (global) {
  const CIP = (global.CIP = global.CIP || {});
  const format = CIP.format || require('./format.js');
  const router = CIP.router || require('./router.js');
  const drawing = CIP.drawing || require('./drawing.js');

  const { escapeHtml: esc } = format;
  const FAMILIES = ['rimless', 'rimmed', 'belted', 'pistol', 'rimfire'];
  const SAFE_URL = /^https?:\/\//i;
  const DESCRIPTION_ID = 'drawing-description';

  // ---- list ---------------------------------------------------------------------------------------------------

  const countText = (n) => `${n} cartridges`;

  function rowHtml(record, query) {
    const also = format.alternativeMatch(record, query);
    const alsoHtml = also ? `<span class="also">also: ${also.map(esc).join(', ')}</span>` : '';
    const l3 = format.formatNumber(record.cartridge.lengths.L3);
    return (
      `<tr><th scope="row"><a href="${esc(router.hrefFor(record.key))}">${esc(record.name)}</a>${alsoHtml}</th>` +
      `<td>${esc(record.family)}</td><td class="num">${l3}<span class="unit"> mm</span></td></tr>`
    );
  }

  const LIST_TEMPLATE = `
    <h1 tabindex="-1">Cartridges</h1>
    <div class="filters" role="search" aria-label="Filter cartridges">
      <div class="field"><label for="search">Search</label>
        <input id="search" name="search" type="text" inputmode="search" enterkeyhint="search" autocomplete="off" autocapitalize="off" spellcheck="false"></div>
      <div class="field"><label for="family">Family</label>
        <select id="family" name="family"><option value="">All</option>${FAMILIES.map((f) => `<option value="${f}">${f}</option>`).join('')}</select></div>
    </div>
    <p class="count" id="count" role="status" aria-live="polite"></p>
    <table class="list">
      <caption class="sr-only">Cartridges with family and case length L3</caption>
      <thead><tr><th scope="col">Name</th><th scope="col">Family</th><th scope="col" class="num">Case length L3</th></tr></thead>
      <tbody></tbody>
    </table>
    <p class="empty" hidden>No cartridge matches.</p>`;

  /**
   * Builds the list view once; the returned object keeps the filter state so it survives navigation.
   * @param {ReadonlyArray<object>} records
   */
  function createListView(records) {
    const root = document.createElement('div');
    root.className = 'view view-list';
    root.innerHTML = LIST_TEMPLATE;
    const search = root.querySelector('#search');
    const family = root.querySelector('#family');
    const count = root.querySelector('#count');
    const body = root.querySelector('tbody');
    const empty = root.querySelector('.empty');

    function update() {
      const shown = format.filterRecords(records, { query: search.value, family: family.value });
      body.innerHTML = shown.map((r) => rowHtml(r, search.value)).join('');
      count.textContent = countText(shown.length);
      empty.hidden = shown.length !== 0;
    }
    search.addEventListener('input', update);
    family.addEventListener('change', update);
    update();
    return { root, heading: root.querySelector('h1') };
  }

  // ---- detail -------------------------------------------------------------------------------------------------

  function dateHtml(value) {
    return `<time datetime="${esc(value)}">${esc(value)}</time>`;
  }

  function capacityHtml(capacity) {
    if (!capacity) return '<span class="muted">not published</span>';
    const value = `${format.formatNumber(capacity.grH2O)}<span class="unit"> gr H2O</span>`;
    const source = SAFE_URL.test(capacity.url || '')
      ? `<a href="${esc(capacity.url)}" target="_blank" rel="noopener noreferrer">${esc(capacity.source)}</a>`
      : esc(capacity.source || '');
    const note = capacity.note ? `<span class="muted"> (${esc(capacity.note)})</span>` : '';
    return `${value} · source ${source}${note}`;
  }

  function factsHtml(r) {
    const a = r.annotations || {};
    const fact = (term, html, wide = false) => `<div class="fact${wide ? ' fact-wide' : ''}"><dt>${esc(term)}</dt><dd>${html}</dd></div>`;
    const alternatives = r.alternativeNames && r.alternativeNames.length ? fact('Alternative names', r.alternativeNames.map(esc).join(', '), true) : '';
    return (
      '<dl class="facts">' +
      alternatives +
      fact('Family', esc(r.family)) +
      fact('Category', esc(a.category)) +
      fact('Primer type', esc(a.primerType)) +
      fact('C.I.P. table', esc(r.tab)) +
      fact('Country', esc(r.country)) +
      fact('Published', dateHtml(r.published)) +
      fact('Revised', dateHtml(r.revised)) +
      fact('Pressure method', esc(r.pressureMethod)) +
      fact('Water capacity', capacityHtml(a.publishedCapacity), true) +
      '</dl>'
    );
  }

  function rowsHtml(rows) {
    return rows
      .map((row) => {
        const tol = row.tol === null ? '' : ` <span class="tol">${esc(row.tol)}</span>`;
        return `<tr><th scope="row">${esc(row.symbol)}</th><td class="num">${esc(row.value)}${tol}</td><td class="unit">${esc(row.unit)}</td></tr>`;
      })
      .join('');
  }

  function tablesHtml(group, data) {
    return format
      .groupSections(group, data)
      .map(
        (s) =>
          `<table class="values"><caption>${esc(s.title)}</caption>` +
          '<thead><tr><th scope="col">Symbol</th><th scope="col">Value</th><th scope="col">Unit</th></tr></thead>' +
          `<tbody>${rowsHtml(s.rows)}</tbody></table>`,
      )
      .join('');
  }

  function drawingHtml(record) {
    const out = drawing.build(record, { describedBy: DESCRIPTION_ID });
    const facts = out.facts
      ? `<p class="drawing-facts">Rim type: ${esc(out.facts.rimType)}${out.facts.bulletShape ? ` · bullet shape: ${esc(out.facts.bulletShape)}` : ''}</p>`
      : '';
    const title = out.ok ? 'Not drawn or simplified:' : 'Drawing unavailable:';
    const notes = out.notes.length
      ? `<div class="drawing-notes"><p class="drawing-notes-title">${title}</p><ul>${out.notes.map((n) => `<li>${esc(n)}</li>`).join('')}</ul></div>`
      : '';
    return `<figure class="drawing-figure">${out.svg}<figcaption id="${DESCRIPTION_ID}">${facts}${notes}</figcaption></figure>`;
  }

  function detailHtml(r) {
    return (
      `<div class="toolbar"><a class="back" href="${router.LIST_HREF}">All cartridges</a>` +
      '<button type="button" class="print-button">Print</button></div>' +
      '<article class="detail">' +
      `<header class="detail-head"><h1 tabindex="-1">${esc(r.name)}</h1><p class="print-only sheet-kind">C.I.P. cartridge and chamber data sheet</p></header>` +
      `<section class="facts-section" aria-label="Facts">${factsHtml(r)}</section>` +
      `<section class="drawing-section" aria-labelledby="drawing-h"><h2 id="drawing-h" class="drawing-heading">Drawing</h2>${drawingHtml(r)}</section>` +
      `<section class="values-section" aria-labelledby="cartridge-h"><h2 id="cartridge-h">Cartridge values</h2><div class="tables">${tablesHtml('cartridge', r.cartridge)}</div></section>` +
      `<section class="values-section" aria-labelledby="chamber-h"><h2 id="chamber-h">Chamber values</h2><div class="tables">${tablesHtml('chamber', r.chamber)}</div></section>` +
      '</article>' +
      `<p class="print-footer">Source: C.I.P. TDCC, revised ${esc(r.revised)}</p>`
    );
  }

  function createDetailView(record, onPrint) {
    const root = document.createElement('div');
    root.className = 'view view-detail';
    root.innerHTML = detailHtml(record);
    root.querySelector('.print-button').addEventListener('click', onPrint);
    return { root, heading: root.querySelector('h1') };
  }

  function createNotFoundView() {
    const root = document.createElement('div');
    root.className = 'view view-missing';
    root.innerHTML =
      `<div class="toolbar"><a class="back" href="${router.LIST_HREF}">All cartridges</a></div>` +
      '<h1 tabindex="-1">Cartridge not found</h1><p>No cartridge has this address.</p>';
    return { root, heading: root.querySelector('h1') };
  }

  const api = { createListView, createDetailView, createNotFoundView };
  CIP.views = api;
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
})(typeof window !== 'undefined' ? window : globalThis);
