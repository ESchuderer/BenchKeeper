# Design

## Context

Greenfield, empty repository, Node 22 dev container, no network at run time. The app must run from `file://` in Chromium, which forbids `fetch()` of local JSON and ES-module imports, so everything is classic scripts loading global-free modules through one namespace. Motivation and scope: see `proposal.md`; behaviour: see `specs/`.

## Goals / Non-Goals

**Goals:** pure, unit-testable geometry and layout code separated from DOM code; deterministic label placement with provable non-overlap; one print sheet per cartridge.

**Non-Goals:** editing data, unit conversion (inch/grain), comparison views, ballistics, any server or build step.

## Decisions

### D1 — Files and module pattern
```
index.html           shell, CSP meta, links CSS, loads scripts with defer
css/styles.css       screen styles, themes (prefers-color-scheme), drawing classes
css/print.css        @media print rules (linked with media="print")
js/data.js           window.CIP.records = [...25 records, verbatim...]
js/format.js         numbers, angles, units, symbols, tolerance, search matching
js/geometry.js       pure: record -> {rimType, profile, bullet, walls, pocket, missing[]}
js/dimensions.js     pure: geometry -> dimension items + label placement (rects)
js/drawing.js        pure: geometry+dimensions -> SVG markup string
js/views.js          DOM: list view, detail view, tables
js/app.js            hash router, focus/title handling, print button
```
Each file is an IIFE that attaches to `globalThis.CIP` and also `module.exports` when `module` exists, so `node --test` can `require` them. *Alternative:* ES modules — rejected, blocked on `file://`. *Alternative:* data in `data.json` — rejected, `fetch` blocked on `file://`.

### D2 — Routing
Hash routes: `#/` list, `#/cartridge/<key>` detail (`key` is the record's `key`, e.g. `308_win`). Hash routing needs no server rewrite, works from `file://` and sub-paths, and survives reload. The list view's DOM and filter state are kept in memory when leaving it, so "All cartridges" and the back button restore filters (within one page load).

### D3 — Search
Normalise = lower-case, `,`→`.`, collapse white space, trim. A record matches when the normalised query is a substring of the normalised name or of any normalised alternative name. No squashing of punctuation: it would make "6.5" match "7 x 65 R".

### D4 — Formatting
Numbers print via `String(n)` (JSON `35.0` parses to `35`, which is "as published" for display `35°`, `4150`). Angle object → `D°M'S"` always with all three parts (`1°45'0"`). Units by field name: bar (Pmax, PK, PE), J (EE), g (M), mm² (Q), none (N), degrees (alpha, alpha1, beta, delta, i), mm for everything else (see proposal assumption). `<X>Tol` is attached to `X` within the same section and never listed.

### D5 — Geometry (coordinates)
Profile points are `{z, r}`, z along the axis from the head face, r the radius. Brief points like `(R1/2, f)` are (r, z) pairs; the code converts. The outer half-profile is an ordered list of segments (`line`, `arc`) from `(0,0)` to the mouth; sampling it gives r(z) for the section wall. Every feature is built by a small function that returns `{points}` or `{missing:[...]}`; the orchestrator concatenates and gathers the `missing` list.

Interpretations where the brief leaves room:
- Rim edge at the head face is chamfered only when `beta` and `f` are both published and beta < 90°; the rimfire half-round replaces the chamfer.
- Belt ramp: from the floor end `(E1/2, R + e min)` the radius grows linearly with z at `dr/dz = tan δ` until `R3/2`.
- **Wall at the neck of a straight case**: a straight case has no shoulder, so the wall is `tb` along the body and ramps at 45° to `tn` ending at the bullet base `zb`, then stays `tn` in the seat so the bullet touches the inner wall. For a heeled case tn would be 0, so the wall stays `tb` (the heel fills the case at its inside diameter).
- The inner line is the body-line radius minus the wall, sampled at the union of the outer profile's z-breakpoints and the wall's breakpoints, so shoulder rounding follows through. Below the solid head the inner line starts at `w` with radius `P1/2 − tb` (groove/belt material stays solid between inner and outer line).
- Section polygon (hatched) = solid head + walls, with the primer pocket cut from the head face; no flash hole is drawn (no data for it).
- Bullet in section is hatched in the opposite direction; seated part is drawn only in the section.
- α: shown by an arc centred on the cone apex through the middle of the shoulder lines. The apex is derived from the published points, never from `S`.

### D6 — Dimension layout (no collisions by construction; rows found by search)
Drawing coordinates: x = z, y = ±r, axis at y = 0, user unit = mm. Font 2.8 mm monospace (width estimate 0.62 em per character is conservative and platform independent).

- **Length dimensions** (R, L1, L2, L3, L6): extension lines drop vertically from the lower silhouette to horizontal dimension lines stacked below, ordered by increasing length (nearest = shortest); the label sits centred above its own line. R is short, so its arrows sit outside the extension lines and the label is to the right (or, if that collides, to the left).
- **Diameter dimensions** (R1, E1, P1, P2, H1, H2, G1) and α: a vertical dimension line across the section with arrowheads on the silhouette, and an extension line rising from the upper silhouette to a label **above the cartridge's bounding box**, in numbered rows. Rows are assigned by an iterative-deepening depth-first search over (row, alignment) in x order (smallest number of rows first, start-aligned preferred, node cap with a guaranteed staircase fallback), rejecting any candidate whose label rectangle overlaps another label, or whose extension line passes through another label. The result is a pyramid: end-aligned labels step up towards the middle and start-aligned labels step down away from it, so a cluster of n close dimensions needs only about n/2 rows.
- All label rectangles therefore lie outside the cartridge's bounding box; the only things inside it are lines. Tests re-check the final rectangles geometrically, and in Chromium with `getBBox()`.
- Title block bottom-right under the dimension rows; the view box is computed from the union of everything, with a minimum width large enough for the title block.
- Dimension items are SVG groups `<g class="dim" data-dim="L3">` so tests and CSS can address them.

### D7 — Drawing legibility on phone and print
The SVG has only `viewBox` and `width:100%; height:auto`, so it scales to the container. Fonts are sized in user units, so labels print at roughly 1.4–2× the on-screen scale (180 mm print width over a 100–140 mm wide drawing). On a 360 px phone the drawing is small but remains pinch-zoomable (viewport zoom is not disabled); no horizontal scrolling is introduced.

### D8 — Scale text
The brief asks for "the scale", but on screen the drawing is fitted to the container, so no on-screen scale is fixed. The printed sheet is deterministic (the SVG is fitted into a 190 × 96 mm box), so the title block states that: "Scale 1.31:1 on A4 print (1 unit = 1 mm)", computed from the view box as `min(190/w, 96/h)`. An e2e test measures the real print scale and compares. `PRINT_AREA` in `js/dimensions.js` and the SVG height in `css/print.css` must be kept in step.

### D9 — Print
`@page { size: A4 portrait; margin: 10mm }`. Print hides toolbar and filters, shows the page header and a footer fixed at the bottom edge of the page area (a footer pushed into the margin with a negative offset made Chromium add a second page), forces `color: #000; background: #fff` by overriding the theme variables, and flows the value tables into five CSS columns with `break-inside: avoid` per table; the facts form a six-column grid. The SVG keeps the full printable width but gets a fixed height (96 mm) with `preserveAspectRatio meet`, so narrow pistol drawings do not become page-high. Verified with Chromium `page.pdf()` page count for all 25 cartridges and a 93 % height budget.

### D10 — Tests (dev only)
`node --test`: unit tests for format/search/geometry/dimension layout, data integrity (hash of the record JSON against a copy of the supplied lines kept as a test fixture), e2e with Playwright (`file://` and static server): list, filters, detail, labels via `getBBox`, request log, phone overflow, dark theme, PDF page count.

### D11 — Security
Strict CSP meta (`default-src 'none'; script-src 'self'; style-src 'self'; base-uri 'none'; form-action 'none'`); all dynamic text through an `esc()` helper or `textContent`; external source links get `rel="noopener noreferrer"`.

## Risks / Trade-offs

- CSP `'self'` on `file://` may behave differently across Chromium versions → verified in headless Chromium; fallback is dropping `'self'` for explicit relative loading if needed.
- Label estimate vs real text widths → generous 0.62 em estimate plus an in-browser `getBBox` check on all 25 cartridges.
- One-page print for the longest tables (rifle with `h`, `s`, belted etc.) → three columns, 7.5 pt; page-count test on all 25.
- Unit assumptions for unlisted fields (mm) → documented in proposal; trivial to change in one map.
- Straight-case wall blend and α arc placement are drawing conventions not fixed by the brief → documented above, covered by tests for non-overlap with bullet.
