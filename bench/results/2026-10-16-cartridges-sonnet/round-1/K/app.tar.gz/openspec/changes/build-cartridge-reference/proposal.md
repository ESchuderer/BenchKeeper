# Proposal

## Why

Reloaders, gunsmiths and engineers who need C.I.P. cartridge and chamber dimensions have to open per-cartridge PDF sheets or tables scattered over several sites. OpenBallistics shows that a browsable, dimension-accurate database is useful, but it needs a build toolchain and a network. This change delivers a self-contained reference of 25 C.I.P. cartridges that opens from disk, prints as a one-page A4 sheet, and draws each cartridge to scale from its own published values.

## What Changes

- A static web app (`index.html` + CSS + JavaScript, no framework, no build step, no network requests) that works from `file://` in Chromium and from any static file server.
- Start page: searchable, family-filterable list of the 25 cartridges with a live count.
- Detail view per cartridge with its own bookmarkable address: descriptive facts, a computed 2D drawing, and all cartridge and chamber values in grouped tables with tolerances inline.
- A dimensioned SVG drawing (outside view above the axis, hatched section below), derived only from the record's published values, 1 SVG unit = 1 mm.
- A print layout: one black-on-white A4 portrait page per detail view.
- Light/dark themes following the system setting; usable on a phone.
- The 25 records are embedded verbatim as the only data (OpenBallistics, MIT, commit e83db43).

## Capabilities

### New Capabilities
- `cartridge-browse`: start page list, name/alternative-name search, family filter, result count, navigation to detail.
- `cartridge-detail`: detail view facts, value tables with units/tolerances/symbols/angle formats, per-cartridge address, navigation controls.
- `cartridge-drawing`: scaled SVG drawing — geometry rules, dimension lines and labels, title block, responsive scaling, missing-value reporting.
- `print-output`: one-page A4 portrait black-on-white print of a detail view.
- `static-delivery`: offline, no-build, no-network delivery from `file://` or a static server; themes; phone usability.

### Modified Capabilities
<!-- none: greenfield project -->

## Impact

- New files in the project root: `index.html`, `css/`, `js/`; dev-only `tests/` and `package.json` (Node 22 test runner, Playwright for browser verification — never needed to run the app).
- No runtime dependencies, no server code, no data fetching.
- Assumption recorded: the brief does not give units for the fields `u`, `Fe`, `S`, `h`, `s`, `b`, `G`, `deltaL`, `L3PlusG`; they are lengths and are shown in mm. The water-capacity field `grH2O` is shown as grains of water (`gr H2O`).
