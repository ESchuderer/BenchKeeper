# Spec Delta

## Purpose

Lets a user find a cartridge among the 25 records by name or family and open its detail view from a compact start page.

## ADDED Requirements

### Requirement: Start page lists every cartridge
The start page SHALL show the heading "Cartridges" and, for every cartridge, its name, its family and its case length L3. Each name SHALL be a link whose text is exactly the record's `name` and which opens that cartridge's detail view.

#### Scenario: Initial list
- **WHEN** the user opens the app without an address fragment
- **THEN** the heading "Cartridges" is shown, 25 cartridges are listed, and the text "25 cartridges" is shown

#### Scenario: Name is shown as published
- **WHEN** the list is shown
- **THEN** a link with the exact text "6,5 Creedmoor" exists and its row shows family "rimless" and L3 "48.77"

#### Scenario: Link opens detail
- **WHEN** the user activates the link "308 Win."
- **THEN** the detail view of "308 Win." is shown

### Requirement: Search filters by name and alternative names
A field labelled "Search" SHALL filter the list as the user types, matching case-insensitively against the name and every alternative name; a comma and a point SHALL be treated alike, runs of white space as one space, and leading and trailing white space SHALL be ignored.

#### Scenario: Alternative name matches
- **WHEN** the user types "7,62 x 51" into "Search"
- **THEN** only "308 Win." is listed and "1 cartridges" is shown

#### Scenario: Decimal separator variants
- **WHEN** the user types "7.62 x 51"
- **THEN** "308 Win." is listed

#### Scenario: Case-insensitive name match
- **WHEN** the user types "creed"
- **THEN** only "6,5 Creedmoor" is listed

#### Scenario: No match
- **WHEN** the user types a text that matches no name
- **THEN** no cartridge is listed, "0 cartridges" is shown and a "No cartridge matches" message is shown

#### Scenario: Match through alternative name is explained
- **WHEN** a cartridge is listed because an alternative name matched
- **THEN** its row shows its alternative names as plain text separate from the link

### Requirement: Family filter
A select labelled "Family" SHALL offer the options All, rimless, rimmed, belted, pistol and rimfire, and SHALL restrict the list to the chosen family. It SHALL combine with the search text.

#### Scenario: Filter by family
- **WHEN** the user chooses "belted"
- **THEN** exactly "300 Win. Mag." and "7 mm Rem. Mag." are listed and "2 cartridges" is shown

#### Scenario: Family and search combined
- **WHEN** family is "pistol" and the search text is "mag"
- **THEN** only "357 Magnum" and "44 Rem. Mag." are listed

#### Scenario: Reset to All
- **WHEN** the user chooses "All"
- **THEN** all cartridges matching the search text are listed

### Requirement: Result count
The text "<n> cartridges" SHALL state the number of listed cartridges, and SHALL be announced to assistive technology when it changes.

#### Scenario: Count follows filters
- **WHEN** the family is "rimfire"
- **THEN** "3 cartridges" is shown

### Requirement: Filters survive a visit to a detail view
The search text and family choice SHALL be kept when the user returns to the list through the link "All cartridges" or the browser's back button within the same page load.

#### Scenario: Return keeps filter
- **WHEN** the user filters for "rimmed", opens "7 x 65 R" and activates "All cartridges"
- **THEN** the family select still shows "rimmed" and "2 cartridges" is shown
