# Spec Delta

## Purpose

Presents everything published for one cartridge — facts, drawing, cartridge values and chamber values — at its own address, with values formatted as published.

## ADDED Requirements

### Requirement: Detail view has a stable address
Each cartridge's detail view SHALL have its own address that a reload restores and that can be bookmarked. An address that names no cartridge SHALL show a "Cartridge not found" message with a link "All cartridges".

#### Scenario: Reload restores the view
- **WHEN** the detail view of "9 mm Luger" is shown and the page is reloaded
- **THEN** the detail view of "9 mm Luger" is shown again

#### Scenario: Direct open
- **WHEN** a user opens the app at the address of a cartridge
- **THEN** that cartridge's detail view is shown without first visiting the list

#### Scenario: Unknown address
- **WHEN** the address names no cartridge
- **THEN** a "Cartridge not found" message and a link "All cartridges" are shown

#### Scenario: Back button
- **WHEN** the user opens a detail view and presses the browser's back button
- **THEN** the list is shown

### Requirement: Descriptive facts
The detail view SHALL show the cartridge's name as the page heading, followed by alternative names (when the record has them), family, category, primer type, C.I.P. table, country, published date, revised date, pressure method and the published water capacity with a link to its source.

#### Scenario: Facts of 308 Win.
- **WHEN** the detail view of "308 Win." is shown
- **THEN** the heading is "308 Win.", the alternative names "308 Winchester" and "7,62 x 51" are shown, family "rimless", category "rifle", primer type "lr", C.I.P. table "I", country "US", published "1984-06-14", revised "2008-09-23", pressure method "Transducer" are shown

#### Scenario: Water capacity with source
- **WHEN** the record has a published capacity
- **THEN** the capacity value is shown in grains of water together with a link whose text is the source and whose target is the record's source URL, plus the record's note when present

#### Scenario: No capacity published
- **WHEN** the record has no published capacity (for example "7 x 64")
- **THEN** the water capacity is shown as not published and no source link is shown

### Requirement: Value tables grouped by section
All cartridge values and all chamber values SHALL be shown in tables grouped by their section of the record, each table having the columns "Symbol", "Value" and "Unit". Sections without values SHALL NOT be shown.

#### Scenario: Sections and columns
- **WHEN** the detail view of "223 Rem." is shown
- **THEN** the cartridge tables include the sections case head, collar, junction cone, lengths, miscellaneous, powder chamber, pressures and projectile, the chamber tables include barrel, breech, collar, grooves, junction cone, lengths, powder chamber and rifling, and every table has the column headers "Symbol", "Value", "Unit"

#### Scenario: Empty section is omitted
- **WHEN** the detail view of "9 mm Luger" is shown
- **THEN** no junction cone table is shown in either group

### Requirement: Values are shown as published
Numeric values SHALL be shown with a decimal point, without a thousands separator and without added or dropped digits beyond the JSON number's own form. Names SHALL be shown exactly as published. Lengths and diameters SHALL carry the unit "mm", Pmax, PK and PE "bar", EE "J", M "g", Q "mm²", and N SHALL carry no unit.

#### Scenario: Length and pressure
- **WHEN** the detail view of "308 Win." is shown
- **THEN** the lengths table shows L3 "51.18" with unit "mm" and the pressures table shows Pmax "4150" with unit "bar", EE "3920" with unit "J", M "25" with unit "g"

#### Scenario: Area and count
- **WHEN** the chamber grooves of "308 Win." are shown
- **THEN** Q is "47.51" with unit "mm²" and N is "4" with an empty unit

### Requirement: Tolerances are shown next to their value
A field named `<X>Tol` SHALL be shown beside the value of X, separated by a space, and SHALL NOT have a row of its own.

#### Scenario: Tolerance beside value
- **WHEN** the lengths table of "308 Win." is shown
- **THEN** the L1 value reads "39.62 -0.2" and no row has the symbol "L1Tol"

#### Scenario: Tolerance in another section
- **WHEN** the case head table of "300 Win. Mag." is shown
- **THEN** the E value reads "5.59 -0.2"

### Requirement: Symbols
A row's symbol SHALL be the record's field name, except eMin "e min", r1Min "r1 min", r1Max "r1 max", alpha "α", alpha1 "α1", beta "β", delta "δ", deltaL "delta L" and L3PlusG "L3 + G".

#### Scenario: Special symbols
- **WHEN** the detail view of "308 Win." is shown
- **THEN** rows with the symbols "e min", "r1 min", "r1 max", "α", "α1", "β", "δ", "delta L" and "L3 + G" exist and no row is named "eMin" or "alpha"

### Requirement: Angles
An angle (alpha, alpha1, beta, delta, i) given as a number SHALL be shown in degrees as `40°`; one given as `{degrees, minutes, seconds}` SHALL be shown as `39°59'49"`. The angle's tolerance rules are those of any other field.

#### Scenario: Degrees only
- **WHEN** the junction cone of "308 Win." is shown
- **THEN** α reads "40°"

#### Scenario: Degrees minutes seconds
- **WHEN** the junction cone of "338 Lapua Mag." is shown
- **THEN** α reads `39°59'49"`

#### Scenario: Zero seconds are kept
- **WHEN** the rifling of "308 Win." is shown
- **THEN** i reads `1°45'0"`

### Requirement: Navigation and print controls
The detail view SHALL offer a button "Print" that opens the browser's print dialog and a link "All cartridges" that returns to the list.

#### Scenario: Print button
- **WHEN** the user presses "Print"
- **THEN** the browser's print dialog is requested

#### Scenario: Back link
- **WHEN** the user activates "All cartridges"
- **THEN** the list with the heading "Cartridges" is shown

### Requirement: Document title and focus
Each view SHALL set the document title to its heading, and after a navigation between views the keyboard focus SHALL move to the view's main heading.

#### Scenario: Title follows view
- **WHEN** the detail view of "45 Auto" is shown
- **THEN** the document title starts with "45 Auto"
