# Spec Delta

## Purpose

Draws each cartridge as a scaled, dimensioned 2D drawing computed only from the record's published values, and states plainly which values were missing for any feature it could not draw.

## ADDED Requirements

### Requirement: Drawing is an accessible inline SVG at true scale
The detail view SHALL contain an inline SVG whose accessible name is "<name> drawing", with the axis horizontal, the head on the left, and 1 SVG user unit equal to 1 mm in the drawing's coordinate system.

#### Scenario: Accessible name
- **WHEN** the detail view of "308 Win." is shown
- **THEN** an image with the accessible name "308 Win. drawing" exists

#### Scenario: True scale
- **WHEN** the drawing of "308 Win." is measured in SVG user units
- **THEN** the distance from the head face to the bullet tip is 71.12 and the rim diameter is 12.01

### Requirement: Two halves — outside view and section
The upper half of the drawing SHALL be the outside view and the lower half a section whose cut walls are hatched, with a dash-dot centre line on the axis. The outer half-profile SHALL run from the axis at the head face to the mouth and be mirrored at the axis.

#### Scenario: Section is hatched
- **WHEN** a drawing is shown
- **THEN** the lower half contains a hatched region for the cut case walls and head, the upper half contains no hatched region, and a dash-dot centre line lies on the axis

#### Scenario: Symmetric outline
- **WHEN** the outer silhouette of the case is sampled
- **THEN** the lower silhouette is the mirror of the upper one about the axis

### Requirement: Rim type classification
The rim type SHALL be belted for family `belted`, rimfire for family `rimfire`, and otherwise rimmed when R1/P1 >= 1.05, rebated when R1/P1 < 0.98 and rimless in between.

#### Scenario: Classification examples
- **WHEN** rim types are derived
- **THEN** "308 Win." is rimless, "300 Win. Mag." belted, "22 Long Rifle" rimfire, "38 Special" rimmed and "9 mm Luger" rimless

### Requirement: Head face and rim edge
Where beta and f are published and beta is below 90°, the head face edge SHALL be chamfered from `(R1/2 - min(f·tanβ, R1/4), 0)` to `(R1/2, f)` and then rise to `(R1/2, R)`. A rimfire case SHALL have a half-round rim edge of radius `min(R/2, (R1-P1)/2)` whose outermost point lies at R1/2. Otherwise the corner is square. Points are written (r, z).

#### Scenario: Chamfer
- **WHEN** the profile of "308 Win." is computed
- **THEN** it contains the points (r 5.739, z 0), (r 6.005, z 0.38) and (r 6.005, z 1.37)

#### Scenario: Half-round rim
- **WHEN** the profile of "22 Long Rifle" is computed
- **THEN** its rim edge is a half-round of radius 0.545 whose outermost radius is 3.53

#### Scenario: Missing beta
- **WHEN** beta or f is not published and the case is not rimfire
- **THEN** the corner is square and the drawing notes the missing value

### Requirement: Extractor groove and belt
Where E and E1 are published the profile SHALL run from `(R1/2, R)` in to `(E1/2, R)`, along the floor to `(E1/2, R + e min)`, then in a straight ramp out to `(P1/2, E)`. A belted case SHALL instead ramp out at angle δ to the axis up to the belt radius R3/2, follow the belt to z = E and step in to P1/2. Without a groove the profile steps in from `(R1/2, R)` to `(P1/2, R)`.

#### Scenario: Groove profile
- **WHEN** the profile of "308 Win." is computed
- **THEN** it contains (r 6.005, z 1.37), (r 5.195, z 1.37), (r 5.195, z 2.77) and (r 5.98, z 3.85)

#### Scenario: Belt
- **WHEN** the profile of "300 Win. Mag." is computed
- **THEN** after the groove floor it ramps at 35° to the axis to r 6.755, follows it to z 5.59 and steps in to r 6.515

#### Scenario: No groove
- **WHEN** the record has no E and E1 (for example "7 x 65 R")
- **THEN** the profile steps in from r 6.66 to r 5.945 at z 1.4 and the drawing makes no missing-value note for the groove, because a rimmed case has none

### Requirement: Body, shoulder and neck
The body SHALL be a straight line from P1/2 at the body start to `(P2/2, L1)` on a bottleneck case; a case lacking alpha, L1 or L2 is straight and its body runs to `(H2/2, L3)`. The shoulder SHALL run from `(P2/2, L1)` to `(H1/2, L2)`, drawn through the published points and labelled α; the body-side corner SHALL be rounded with r1 min and the neck-side corner with r2 where published. The neck SHALL run from `(H1/2, L2)` to `(H2/2, L3)`, followed by the mouth face.

#### Scenario: Bottleneck points
- **WHEN** the profile of "308 Win." is computed
- **THEN** the shoulder line runs from the unrounded corner (r 5.765, z 39.62) to (r 4.36, z 43.48), the profile ends at the mouth (r 4.36, z 51.18), and the two corners are rounded with r1 min 0.76 and r2 3.18

#### Scenario: Straight case
- **WHEN** the profile of "9 mm Luger" is computed
- **THEN** the body runs from r 4.965 to r 4.825 at z 19.15 and the drawing says the case is straight

#### Scenario: Corner rounding only where published
- **WHEN** the profile of "17 HMR" is computed (no r1 min, no r2)
- **THEN** the shoulder corners are sharp and the drawing says r1 min and r2 are not published

### Requirement: Bullet
A bullet SHALL be drawn from the mouth to the tip at z = L6 with shank diameter G1 and the nose shape named by `annotations.defaultBulletShape`. Seating depth s is 1.0·G1 pointy; 0.8·G1 rounded or flat on rifle and rimfire cartridges; 0.4·G1 rounded or flat on pistol cartridges; 0.6·G1 semi_wadcutter. The base is at zb = L3 − s and the bullet length Lb = L6 − zb.

#### Scenario: Pointy seating
- **WHEN** the bullet of "308 Win." is computed
- **THEN** s is 7.85, zb is 43.33 and Lb is 27.79

#### Scenario: Pistol rounded
- **WHEN** the bullet of "9 mm Luger" is computed
- **THEN** s is 3.612 (0.4·9.03)

### Requirement: Bullet cylinder
The cylinder SHALL run from the base to `zb + k·Lb` with k = 0.40 pointy; 0.55 rounded rifle or rimfire; 0.65 rounded pistol; 0.60 flat rifle; 0.70 flat pistol; 0.78 semi_wadcutter.

#### Scenario: Cylinder end of 308 Win.
- **WHEN** the bullet of "308 Win." is computed
- **THEN** the cylinder ends at z 54.446

#### Scenario: Cylinder end of 9 mm Luger
- **WHEN** the bullet of "9 mm Luger" (rounded, pistol) is computed
- **THEN** the cylinder ends at zb + 0.65·Lb

### Requirement: Bullet nose
The nose SHALL run from the cylinder end to the tip with a flat tip of diameter m. Pointy: tangent ogive, m = max(0.08·G1, 1.27), arc radius ρ = ((G1/2 − m/2)² + n²) / (2·(G1/2 − m/2)) with nose length n, centred at r = G1/2 − ρ on the radial line where the nose starts. Rounded: quarter ellipse, m = 0.15·G1. Flat: straight cone, m = 0.55·G1. Semi_wadcutter: straight cone, m = 0.6·G1.

#### Scenario: Ogive of 308 Win.
- **WHEN** the nose of "308 Win." is computed
- **THEN** m is 1.27, n is 16.674 and the arc radius is 43.9 (±0.1) and the arc is tangent to the cylinder

#### Scenario: Meplat of other shapes
- **WHEN** the noses of "9 mm Luger" (rounded), "40 S.& W." (flat) and "357 Magnum" (semi_wadcutter) are computed
- **THEN** m is 1.3545, 5.5935 and 5.472

#### Scenario: Tip location
- **WHEN** any drawing is computed
- **THEN** the tip lies at z = L6 with a flat tip of radius m/2

### Requirement: Heeled bullets
For a heeled case (H2 − G1 <= 0.015, e.g. 22 Long Rifle) the exposed bullet SHALL have the case's outside diameter and the seated heel the case's inside diameter H2 − 2·tb.

#### Scenario: 22 Long Rifle heel
- **WHEN** the bullet of "22 Long Rifle" is computed
- **THEN** the exposed bullet diameter is 5.72 and the seated heel diameter is 4.52

### Requirement: Outside view hides the seated bullet
The outside view SHALL show only the bullet part above the mouth; the section SHALL show the seated part inside the case.

#### Scenario: Visibility
- **WHEN** a drawing is shown
- **THEN** no bullet outline lies at z < L3 in the upper half and the bullet's seated part is visible in the lower half

### Requirement: Section wall thickness
Neck wall tn = (H2 − G1)/2; body wall tb = min(max(1.3·tn, 0.6), 0.35·P1/2). The inner line SHALL follow the outer body, shoulder and neck at tb along the body and tn along the neck, blended linearly across the shoulder.

#### Scenario: Walls of 308 Win.
- **WHEN** the walls of "308 Win." are computed
- **THEN** tn is 0.435 and tb is 0.6, and the inner radius at the mouth is 3.925

### Requirement: Solid head
The solid head SHALL run from the head face to z = w = max(2.5, 0.25·P1/2, pocket depth + 1.5, E + tb where a groove exists, or the belt ramp end + tb on belted cases).

#### Scenario: Head of 308 Win.
- **WHEN** w is computed for "308 Win."
- **THEN** w is 4.8 (pocket depth 3.3 + 1.5)

### Requirement: Primer pocket
Centrefire cases SHALL have a primer pocket of diameter 4.45 (sp, spm, sr) or 5.33 (lp, lpm, lr, lrm) and depth 3.04 (sp, spm, sr, lp, lpm) or 3.3 (lr, lrm); rimfire cases have none.

#### Scenario: Pocket
- **WHEN** the section of "308 Win." (primer lr) is drawn
- **THEN** a pocket of diameter 5.33 and depth 3.3 is cut into the head

#### Scenario: Rimfire has no pocket
- **WHEN** the section of "22 Long Rifle" is drawn
- **THEN** no primer pocket is cut

### Requirement: Dimensions
The drawing SHALL carry dimension lines with arrowheads and extension lines for L3, L6, R1, R and P1 and, where published, P2, H1, H2, G1, L1, L2, E1 and the shoulder angle α. Each SHALL be labelled with its symbol and value, such as "L3 51.18", and the label of α SHALL read like "α 40°".

#### Scenario: Labels present
- **WHEN** the drawing of "308 Win." is shown
- **THEN** it has labels "L3 51.18", "L6 71.12", "R1 12.01", "R 1.37", "P1 11.96", "P2 11.53", "H1 8.72", "H2 8.72", "G1 7.85", "L1 39.62", "L2 43.48", "E1 10.39" and "α 40°"

#### Scenario: Unpublished dimension is omitted
- **WHEN** the drawing of "9 mm Luger" is shown
- **THEN** there are no labels for P2, H1, L1, L2 and α

#### Scenario: Dimension line endpoints are exact
- **WHEN** the dimension line of a length is measured
- **THEN** its length in user units equals the published value

### Requirement: Labels do not collide
Dimension labels SHALL NOT overlap each other, the case or bullet outline, the dimension lines of other dimensions, or the title block, and SHALL lie entirely inside the drawing's view box.

#### Scenario: All 25 drawings
- **WHEN** the label rectangles of every cartridge's drawing are measured
- **THEN** no two overlap and none overlaps the outline or the title block

### Requirement: Title block
The drawing SHALL contain a title block with the cartridge name, the C.I.P. table and revision date, the text "Dimensions in mm" and the scale.

#### Scenario: Title block text
- **WHEN** the drawing of "308 Win." is shown
- **THEN** its title block reads "308 Win.", "C.I.P. table I · revised 2008-09-23", "Dimensions in mm" and a scale line such as "Scale 1.31:1 on A4 print (1 unit = 1 mm)"

#### Scenario: Scale is the printed scale
- **WHEN** the detail view is printed on A4
- **THEN** the number in the scale line equals the real enlargement of the printed drawing within 1 %

### Requirement: Responsive and printable scaling
The drawing SHALL scale to the width of the container, including a phone screen, without horizontal scrolling and keeping its proportions, and its text and lines SHALL stay legible when printed.

#### Scenario: Phone width
- **WHEN** the viewport is 360 CSS pixels wide
- **THEN** the drawing's rendered width does not exceed the viewport and the page has no horizontal overflow

### Requirement: Missing values are reported
When a value a rule needs is missing the drawing SHALL omit that feature, SHALL NOT invent a number, and SHALL state which value is missing in a note under the drawing.

#### Scenario: Missing r1 min
- **WHEN** the record lacks r1 min but has alpha
- **THEN** the note says that r1 min is not published and the shoulder body-side corner is not rounded

#### Scenario: Missing value stops a feature only
- **WHEN** the record lacks P2 on a case that otherwise has alpha, L1 and L2
- **THEN** the shoulder is not drawn, the note names P2, and the rest of the drawing is still produced

### Requirement: Data is not altered
The drawing and its tables SHALL use only the embedded records and SHALL NOT fetch, add or change data.

#### Scenario: No extra numbers
- **WHEN** a drawing's dimension labels are read
- **THEN** every number in them equals the record's published value formatted as in the tables
