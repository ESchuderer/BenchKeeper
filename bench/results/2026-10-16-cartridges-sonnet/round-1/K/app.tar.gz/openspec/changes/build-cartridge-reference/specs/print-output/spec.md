# Spec Delta

## Purpose

Turns a detail view into a clean one-page A4 portrait data sheet when printed or saved as PDF.

## ADDED Requirements

### Requirement: One A4 portrait page
A printed detail view SHALL occupy exactly one A4 portrait page for every one of the 25 cartridges.

#### Scenario: Page count
- **WHEN** the detail view of any cartridge is printed to PDF on A4 portrait
- **THEN** the PDF has exactly one page

### Requirement: Print content and order
The printed page SHALL contain, in this order, a page header with the cartridge name, the drawing at the full width of the printable area with every label legible, then the tables, and a footer with the source "C.I.P. TDCC" and the revised date. It SHALL NOT show navigation, the search field, the family select or any button.

#### Scenario: Chrome is hidden
- **WHEN** the detail view is printed
- **THEN** the "Print" button, the link "All cartridges" and any search or filter control are not visible

#### Scenario: Footer
- **WHEN** the detail view of "308 Win." is printed
- **THEN** a footer reading "Source: C.I.P. TDCC, revised 2008-09-23" is visible

#### Scenario: Drawing width
- **WHEN** the detail view is printed
- **THEN** the drawing element spans the width of the printable area (the drawing is fitted and centred in a fixed-height frame) and its smallest text is at least 6 pt high

#### Scenario: Safety margin
- **WHEN** the detail view of any cartridge is laid out for print
- **THEN** its content uses at most 93 % of the page's printable height, so other fonts do not push it onto a second page

### Requirement: Print is black on white
Print output SHALL use black ink on a white background regardless of the on-screen theme, with no coloured or shaded fills.

#### Scenario: Dark theme prints light
- **WHEN** the system is set to dark and the page is printed
- **THEN** the printed text is black and the background white
