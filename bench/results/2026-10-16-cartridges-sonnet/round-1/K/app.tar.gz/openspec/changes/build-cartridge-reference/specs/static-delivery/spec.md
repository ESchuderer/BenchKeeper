# Spec Delta

## Purpose

Defines how the app is delivered and how it looks: a dependency-free static site that works offline from disk, in light and dark themes, on desktop and phone.

## ADDED Requirements

### Requirement: Plain static app, no build, no network
The app SHALL consist of `index.html` in the project root with its CSS and JavaScript files, using no framework, no build step, no server code and no runtime dependency, and SHALL make no network request of its own (no CDN, web font or analytics).

#### Scenario: No requests beyond local files
- **WHEN** the app is opened and every view is visited
- **THEN** all requests are for files of the project folder and none for another origin

### Requirement: Works from disk and from a static server
The app SHALL work fully when `index.html` is opened directly from disk in Chromium, and also when the folder is served by any static file server, including from a sub-path.

#### Scenario: File URL
- **WHEN** `index.html` is opened through a `file://` address
- **THEN** the list, search, filter, detail views, drawings and reload of a detail address all work

#### Scenario: Served from a sub-path
- **WHEN** the folder is served by a static server under a sub-path
- **THEN** the same behaviour is observed

### Requirement: Embedded data is the only data
The 25 supplied records SHALL be embedded unchanged; the app SHALL NOT add, alter or fetch data.

#### Scenario: Record integrity
- **WHEN** the embedded records are compared with the supplied records
- **THEN** there are 25 records with the supplied keys, names, families and values

### Requirement: Light and dark themes
On screen the app SHALL follow the system colour-scheme setting, in both the page and the drawing, with sufficient contrast; print SHALL always be light.

#### Scenario: Dark system setting
- **WHEN** the system prefers a dark colour scheme
- **THEN** the page background is dark, the text light and the drawing strokes light

### Requirement: Technical-reference look and phone usability
The interface SHALL be dense, calm and precise, with tabular numerals for numbers, and SHALL be usable at 360 CSS pixels wide without horizontal page scrolling and with touch targets of at least 44 px height for controls.

#### Scenario: Phone
- **WHEN** the viewport is 360 px wide
- **THEN** the list, a detail view and its tables show no horizontal page scroll and the controls are at least 44 px high

### Requirement: Keyboard and assistive technology access
Every control SHALL be operable by keyboard with a visible focus indicator, the search field and select SHALL have programmatic labels, and tables SHALL have captions and column headers.

#### Scenario: Labels
- **WHEN** the start page is inspected
- **THEN** a textbox named "Search" and a combobox named "Family" exist

### Requirement: Content security
The page SHALL restrict itself by a content security policy to its own scripts and styles, and SHALL build all markup from the embedded data with escaping.

#### Scenario: Policy present
- **WHEN** `index.html` is inspected
- **THEN** it declares a policy that forbids inline scripts and external origins
