# Tasks

## 1. Scaffold and data

- [x] 1.1 Add `package.json` (dev only: playwright) with `test`, `test:unit`, `test:e2e` scripts; verify `npm test` runs an empty suite
- [x] 1.2 Write the data-integrity test first (25 records, keys, names, families, SHA-256 of the canonical JSON of each record against a fixture copied from the brief), watch it fail
- [x] 1.3 Embed the 25 records verbatim in `js/data.js`; verify the integrity test passes

## 2. Formatting and search (tests first)

- [x] 2.1 Write failing unit tests for number, angle (`40°`, `39°59'49"`, `1°45'0"`), unit, symbol, tolerance and section-grouping functions
- [x] 2.2 Implement `js/format.js`; verify the tests pass
- [x] 2.3 Write failing unit tests for search normalisation and matching (`7,62 x 51` finds 308 Win.; `7.62 x 51`; `6.5` does not match `7 x 65 R`), then implement; verify green

## 3. Geometry (tests first)

- [x] 3.1 Write failing unit tests for rim type, head chamfer, half-round rim, groove, belt, body/shoulder/neck points, shoulder rounding, per the spec scenario numbers
- [x] 3.2 Write failing unit tests for bullet seating, cylinder end, ogive/ellipse/cone, heeled bullet, walls, w, pocket
- [x] 3.3 Write failing unit tests for the missing-value reporting (strip fields from fixtures; nothing invented)
- [x] 3.4 Implement `js/geometry.js`; verify all geometry tests pass for all 25 records without NaN

## 4. Dimensions and drawing (tests first)

- [x] 4.1 Write failing unit tests for dimension items (symbols, values, exact lengths, omitted when unpublished) and for label placement (no label/label, label/outline, label/title-block overlaps, inside view box) over all 25 records
- [x] 4.2 Implement `js/dimensions.js`; verify tests pass
- [x] 4.3 Write failing unit tests for the SVG string (accessible name, viewBox, hatch only in lower half, title block text, centre line, escaping), implement `js/drawing.js`; verify green
- [x] 4.4 Render the 25 drawings to PNG with Chromium and inspect them visually; fix defects found

## 5. Views, routing, styles

- [x] 5.1 Write failing e2e tests for list, search, family filter, count, links, filters kept on return, back button, reload of detail address, unknown address
- [x] 5.2 Implement `index.html`, `js/views.js`, `js/app.js`, `css/styles.css`; verify e2e green on `file://` and on a static server under a sub-path
- [x] 5.3 Write and pass e2e tests for detail facts, tables (columns, sections, units, tolerances, symbols, angles), Print button calls `window.print`, All cartridges link, title/focus

## 6. Responsive, themes, print

- [x] 6.1 e2e: 360 px width has no horizontal overflow and controls ≥ 44 px; dark scheme colours; no cross-origin requests; CSP present
- [x] 6.2 Implement `css/print.css`; e2e: PDF is exactly one A4 page for each of the 25 cartridges, chrome hidden, footer text, black on white, drawing smallest text ≥ 6 pt
- [x] 6.3 Inspect the PDFs and screenshots (light, dark, phone) visually and fix defects

## 7. Review and verification

- [x] 7.1 Run the full verification loop (unit, e2e, coverage ≥ 80 % of pure modules, security grep for network APIs)
- [x] 7.2 Run code-reviewer, security-reviewer and a11y reviews; fix CRITICAL/HIGH findings and re-run tests
- [x] 7.3 Write `README.md` (how to open, how to test, data provenance, assumptions) and verify the documented commands run as written
- [x] 7.4 `openspec validate build-cartridge-reference --strict` passes

## Workflow follow-up

- Archive the change after review (`openspec archive build-cartridge-reference`).
