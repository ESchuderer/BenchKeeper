'use strict';
// Dev helper: renders all 25 drawings with the app's own modules into one image (test-output/contact-*.png).
const path = require('node:path');
const { launch, fileBase, root } = require('../tests/e2e/helpers.js');

(async () => {
  const browser = await launch();
  const page = await browser.newPage({ viewport: { width: 1800, height: 1000 } });
  await page.goto(fileBase());
  await page.locator('h1').waitFor();
  const parts = [[0, 9], [9, 18], [18, 25]];
  for (const [from, to] of parts) {
    await page.evaluate(([a, b]) => {
      const main = document.getElementById('main');
      const grid = document.createElement('div');
      grid.style.cssText = 'display:grid;grid-template-columns:repeat(3,1fr);gap:8px;padding:8px';
      for (const r of window.CIP.records.slice(a, b)) {
        const cell = document.createElement('div');
        cell.style.cssText = 'background:var(--sheet);border:1px solid var(--rule)';
        cell.innerHTML = window.CIP.drawing.build(r).svg;
        grid.append(cell);
      }
      main.replaceChildren(grid);
    }, [from, to]);
    await page.screenshot({ path: path.join(root, 'test-output', `contact-${from}.png`), fullPage: true });
  }
  await browser.close();
})();
