'use strict';
// Dev helper: screenshots the print layout of a detail view (print media, A4 printable width) into test-output/.
const path = require('node:path');
const { launch, fileBase, detailHash, root } = require('../tests/e2e/helpers.js');

(async () => {
  const browser = await launch();
  for (const key of process.argv.slice(2)) {
    const page = await browser.newPage({ viewport: { width: 718, height: 1024 }, deviceScaleFactor: 2 });
    await page.goto(fileBase() + detailHash(key));
    await page.locator('svg.drawing').waitFor();
    await page.emulateMedia({ media: 'print' });
    const h = await page.evaluate(() => document.querySelector('main').getBoundingClientRect().height);
    console.log(key, 'main height px', Math.round(h), '(printable page height ~1024 px)');
    await page.screenshot({ path: path.join(root, 'test-output', `print-${key}.png`), fullPage: true });
    await page.close();
  }
  await browser.close();
})();
