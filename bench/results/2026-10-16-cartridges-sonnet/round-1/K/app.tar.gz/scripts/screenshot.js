'use strict';
// Dev helper: screenshots views of the app from file:// into test-output/. Usage: node scripts/screenshot.js key [key...]
const path = require('node:path');
const { chromium } = require('playwright');

const root = path.join(__dirname, '..');
const url = (hash) => `file://${path.join(root, 'index.html')}${hash}`;

(async () => {
  const keys = process.argv.slice(2);
  const browser = await chromium.launch();
  const page = await browser.newPage({ viewport: { width: 1100, height: 900 }, deviceScaleFactor: 2 });
  const problems = [];
  page.on('console', (m) => ['error', 'warning'].includes(m.type()) && problems.push(`${m.type()}: ${m.text()}`));
  page.on('pageerror', (e) => problems.push(`pageerror: ${e.message}`));
  await page.goto(url('#/'));
  await page.screenshot({ path: path.join(root, 'test-output', 'list.png') });
  for (const key of keys) {
    await page.goto(url(`#/cartridge/${key}`));
    await page.locator('svg.drawing').screenshot({ path: path.join(root, 'test-output', `drawing-${key}.png`) });
  }
  console.log(problems.length ? problems.join('\n') : 'no console problems');
  await browser.close();
})();
