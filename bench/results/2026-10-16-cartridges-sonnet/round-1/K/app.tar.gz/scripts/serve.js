'use strict';
// Dev helper: serves the project folder statically. Usage: node scripts/serve.js [sub/path]  (default: site root)
const { startServer } = require('../tests/e2e/helpers.js');

const prefix = process.argv[2] ? `/${process.argv[2].replace(/^\/+|\/+$/g, '')}` : '';
startServer(prefix).then((server) => console.log(`Serving at ${server.base}`));
