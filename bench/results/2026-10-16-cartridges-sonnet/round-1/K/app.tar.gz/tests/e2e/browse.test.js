'use strict';
// Spec: cartridge-browse and the routing part of cartridge-detail. Runs from file:// and from a served sub-path.
const test = require('node:test');
const assert = require('node:assert/strict');
const { records, launch, startServer, fileBase, detailHash, watch } = require('./helpers.js');

const names = (page) => page.locator('table.list tbody th a').allInnerTexts();
const count = (page) => page.getByRole('status').innerText();

function runSuite(label, startServer) {
  test.describe(`browse (${label})`, () => {
    let browser;
    let page;
    let problems;
    let server = null;
    let base = fileBase();
    const getBase = () => base;
    test.before(async () => {
      browser = await launch();
      if (startServer) {
        server = await startServer();
        base = server.base;
      }
    });
    test.after(async () => {
      await browser.close();
      if (server) await server.close();
    });
    test.beforeEach(async () => {
      page = await browser.newPage();
      problems = watch(page);
      await page.goto(getBase());
      await page.getByRole('heading', { level: 1, name: 'Cartridges' }).waitFor();
    });
    test.afterEach(async () => {
      assert.deepEqual(problems, []);
      await page.close();
    });

    test('start page lists all 25 cartridges with name, family and L3', async () => {
      assert.equal(await count(page), '25 cartridges');
      assert.deepEqual(await names(page), records.map((r) => r.name));
      const row = page.locator('table.list tbody tr').filter({ has: page.getByRole('link', { name: '6,5 Creedmoor', exact: true }) });
      assert.match(await row.innerText(), /rimless/);
      assert.match(await row.innerText(), /48\.77/);
    });

    test('link text is exactly the record name for every cartridge', async () => {
      for (const r of records) {
        assert.equal(await page.getByRole('link', { name: r.name, exact: true }).count(), 1, r.name);
      }
    });

    test('a link opens the detail view', async () => {
      await page.getByRole('link', { name: '308 Win.', exact: true }).click();
      await page.getByRole('heading', { level: 1, name: '308 Win.' }).waitFor();
      assert.match(page.url(), /#\/cartridge\/308_win$/);
    });

    test('search finds a cartridge through an alternative name and explains why', async () => {
      await page.getByLabel('Search').fill('7,62 x 51');
      assert.deepEqual(await names(page), ['308 Win.']);
      assert.equal(await count(page), '1 cartridges');
      assert.match(await page.locator('table.list tbody tr').innerText(), /also: 308 Winchester, 7,62 x 51/);
      assert.equal(await page.getByRole('link', { name: '308 Win.', exact: true }).innerText(), '308 Win.');
    });

    test('search treats comma and point alike, ignores case and surrounding blanks', async () => {
      await page.getByLabel('Search').fill('  7.62 X 51 ');
      assert.deepEqual(await names(page), ['308 Win.']);
      await page.getByLabel('Search').fill('creed');
      assert.deepEqual(await names(page), ['6,5 Creedmoor']);
      await page.getByLabel('Search').fill('6.5');
      assert.deepEqual(await names(page), ['6,5 Creedmoor', '6,5 x 55 SE']);
    });

    test('search with no match shows 0 cartridges and a message', async () => {
      await page.getByLabel('Search').fill('zzz');
      assert.equal(await count(page), '0 cartridges');
      assert.deepEqual(await names(page), []);
      await page.getByText('No cartridge matches').waitFor();
    });

    test('family filter offers the six options and filters', async () => {
      const options = await page.getByLabel('Family').locator('option').allInnerTexts();
      assert.deepEqual(options, ['All', 'rimless', 'rimmed', 'belted', 'pistol', 'rimfire']);
      await page.getByLabel('Family').selectOption('belted');
      assert.deepEqual(await names(page), ['300 Win. Mag.', '7 mm Rem. Mag.']);
      assert.equal(await count(page), '2 cartridges');
      await page.getByLabel('Family').selectOption({ label: 'rimfire' });
      assert.equal(await count(page), '3 cartridges');
      await page.getByLabel('Family').selectOption({ label: 'All' });
      assert.equal(await count(page), '25 cartridges');
    });

    test('family and search combine', async () => {
      await page.getByLabel('Family').selectOption('pistol');
      await page.getByLabel('Search').fill('mag');
      assert.deepEqual(await names(page), ['357 Magnum', '44 Rem. Mag.']);
    });

    test('count is a polite live region', async () => {
      assert.equal(await page.locator('#count').getAttribute('aria-live'), 'polite');
    });

    test('filters survive a visit to a detail view (link and back button)', async () => {
      await page.getByLabel('Family').selectOption('rimmed');
      await page.getByRole('link', { name: '7 x 65 R', exact: true }).click();
      await page.getByRole('heading', { level: 1, name: '7 x 65 R' }).waitFor();
      await page.getByRole('link', { name: 'All cartridges' }).click();
      await page.getByRole('heading', { level: 1, name: 'Cartridges' }).waitFor();
      assert.equal(await page.getByLabel('Family').inputValue(), 'rimmed');
      assert.equal(await count(page), '2 cartridges');
      await page.getByRole('link', { name: '9,3 x 74 R', exact: true }).click();
      await page.goBack();
      await page.getByRole('heading', { level: 1, name: 'Cartridges' }).waitFor();
      assert.equal(await count(page), '2 cartridges');
    });

    test('detail address survives a reload and opens directly', async () => {
      await page.goto(getBase() + detailHash('9_mm_luger'));
      await page.getByRole('heading', { level: 1, name: '9 mm Luger' }).waitFor();
      await page.reload();
      await page.getByRole('heading', { level: 1, name: '9 mm Luger' }).waitFor();
      assert.match(await page.title(), /^9 mm Luger/);
    });

    test('an unknown cartridge address says so and links back', async () => {
      await page.goto(getBase() + detailHash('no_such_cartridge'));
      await page.getByText('Cartridge not found').first().waitFor();
      await page.getByRole('link', { name: 'All cartridges' }).click();
      await page.getByRole('heading', { level: 1, name: 'Cartridges' }).waitFor();
    });

    test('back button from a detail view shows the list', async () => {
      await page.getByRole('link', { name: '45 Auto', exact: true }).click();
      await page.getByRole('heading', { level: 1, name: '45 Auto' }).waitFor();
      await page.goBack();
      await page.getByRole('heading', { level: 1, name: 'Cartridges' }).waitFor();
    });

    test('keyboard focus moves to the heading after navigation and the title follows the view', async () => {
      await page.getByRole('link', { name: '45 Auto', exact: true }).click();
      await page.getByRole('heading', { level: 1, name: '45 Auto' }).waitFor();
      assert.equal(await page.evaluate(() => document.activeElement.tagName), 'H1');
      assert.match(await page.title(), /^45 Auto/);
      await page.getByRole('link', { name: 'All cartridges' }).click();
      await page.getByRole('heading', { level: 1, name: 'Cartridges' }).waitFor();
      assert.equal(await page.evaluate(() => document.activeElement.tagName), 'H1');
      assert.doesNotMatch(await page.title(), /^45 Auto/);
    });

    test('search and select are labelled form controls', async () => {
      await page.getByRole('textbox', { name: 'Search' }).waitFor();
      await page.getByRole('combobox', { name: 'Family' }).waitFor();
    });
  });
}

runSuite('file://', null);
runSuite('http sub-path', () => startServer('/some/sub/path'));
