'use strict';
// Spec: cartridge-detail.
const test = require('node:test');
const assert = require('node:assert/strict');
const { records, launch, fileBase, detailHash, watch } = require('./helpers.js');

let browser;
let page;
let problems;

test.before(async () => {
  browser = await launch();
});
test.after(() => browser.close());
test.beforeEach(async () => {
  page = await browser.newPage();
  problems = watch(page);
  await page.addInitScript(() => {
    window.__printCalls = 0;
    window.print = () => {
      window.__printCalls += 1;
    };
  });
});
test.afterEach(async () => {
  assert.deepEqual(problems, []);
  await page.close();
});

const open = async (key, name) => {
  await page.goto(fileBase() + detailHash(key));
  await page.getByRole('heading', { level: 1, name, exact: true }).waitFor();
};
const group = (heading) => page.locator('section', { has: page.getByRole('heading', { name: heading }) });
const row = (heading, caption, symbol) =>
  group(heading).locator('table', { has: page.locator('caption', { hasText: new RegExp(`^${caption}$`) }) }).locator('tbody tr', { has: page.locator('th', { hasText: new RegExp(`^${symbol}$`) }) });
const fact = (term) => page.locator('.fact', { has: page.locator('dt', { hasText: new RegExp(`^${term}$`) }) }).locator('dd');

test('facts of 308 Win.', async () => {
  await open('308_win', '308 Win.');
  assert.equal(await fact('Alternative names').innerText(), '308 Winchester, 7,62 x 51');
  assert.equal(await fact('Family').innerText(), 'rimless');
  assert.equal(await fact('Category').innerText(), 'rifle');
  assert.equal(await fact('Primer type').innerText(), 'lr');
  assert.equal(await fact('C.I.P. table').innerText(), 'I');
  assert.equal(await fact('Country').innerText(), 'US');
  assert.equal(await fact('Published').innerText(), '1984-06-14');
  assert.equal(await fact('Revised').innerText(), '2008-09-23');
  assert.equal(await fact('Pressure method').innerText(), 'Transducer');
});

test('records without alternative names show no such fact', async () => {
  await open('223_rem', '223 Rem.');
  assert.equal(await page.locator('.fact dt', { hasText: 'Alternative names' }).count(), 0);
});

test('water capacity with its source link and note', async () => {
  await open('308_win', '308 Win.');
  const dd = fact('Water capacity');
  assert.match(await dd.innerText(), /^56 gr H2O/);
  assert.match(await dd.innerText(), /Lapua brass measures 55\.8 \(lapua-308\)/);
  const link = dd.getByRole('link', { name: 'kwk' });
  assert.equal(await link.getAttribute('href'), 'http://kwk.us/cases.html');
  assert.match(await link.getAttribute('rel'), /noopener/);
});

test('missing capacity is said so and has no link', async () => {
  await open('7_x_64', '7 x 64');
  const dd = fact('Water capacity');
  assert.equal(await dd.innerText(), 'not published');
  assert.equal(await dd.getByRole('link').count(), 0);
});

test('223 Rem. has the cartridge and chamber sections with Symbol/Value/Unit columns', async () => {
  await open('223_rem', '223 Rem.');
  const cart = await group('Cartridge values').locator('caption').allInnerTexts();
  assert.deepEqual(cart, ['Case head', 'Collar', 'Junction cone', 'Lengths', 'Miscellaneous', 'Powder chamber', 'Pressures', 'Projectile']);
  const chamber = await group('Chamber values').locator('caption').allInnerTexts();
  assert.deepEqual(chamber, ['Barrel', 'Breech', 'Collar', 'Grooves', 'Junction cone', 'Lengths', 'Powder chamber', 'Rifling']);
  const tables = page.locator('table.values');
  for (let i = 0; i < (await tables.count()); i += 1) {
    assert.deepEqual(await tables.nth(i).locator('thead th').allInnerTexts(), ['Symbol', 'Value', 'Unit']);
  }
});

test('empty sections are omitted (9 mm Luger has no junction cone)', async () => {
  await open('9_mm_luger', '9 mm Luger');
  assert.equal(await page.locator('table.values caption', { hasText: 'Junction cone' }).count(), 0);
});

test('lengths, pressures, area and count are shown with their units', async () => {
  await open('308_win', '308 Win.');
  assert.deepEqual(await row('Cartridge values', 'Lengths', 'L3').locator('td').allInnerTexts(), ['51.18', 'mm']);
  assert.deepEqual(await row('Cartridge values', 'Pressures', 'Pmax').locator('td').allInnerTexts(), ['4150', 'bar']);
  assert.deepEqual(await row('Cartridge values', 'Pressures', 'EE').locator('td').allInnerTexts(), ['3920', 'J']);
  assert.deepEqual(await row('Cartridge values', 'Pressures', 'M').locator('td').allInnerTexts(), ['25', 'g']);
  assert.deepEqual(await row('Chamber values', 'Grooves', 'Q').locator('td').allInnerTexts(), ['47.51', 'mm²']);
  assert.deepEqual(await row('Chamber values', 'Grooves', 'N').locator('td').allInnerTexts(), ['4', '']);
});

test('a tolerance sits beside its value and has no row of its own', async () => {
  await open('308_win', '308 Win.');
  assert.equal(await row('Cartridge values', 'Lengths', 'L1').locator('td').first().innerText(), '39.62 -0.2');
  assert.equal(await page.locator('table.values th', { hasText: /Tol$/ }).count(), 0);
  await open('300_win_mag', '300 Win. Mag.');
  assert.equal(await row('Cartridge values', 'Case head', 'E').locator('td').first().innerText(), '5.59 -0.2');
});

test('special symbols', async () => {
  await open('308_win', '308 Win.');
  const symbols = await page.locator('table.values tbody th').allInnerTexts();
  for (const s of ['e min', 'r1 min', 'r1 max', 'α', 'α1', 'β', 'δ', 'delta L', 'L3 + G']) assert.ok(symbols.includes(s), s);
  for (const s of ['eMin', 'r1Min', 'r1Max', 'alpha', 'alpha1', 'beta', 'delta', 'deltaL', 'L3PlusG']) assert.ok(!symbols.includes(s), s);
});

test('angles in degrees and in degrees minutes seconds', async () => {
  await open('308_win', '308 Win.');
  assert.equal(await row('Cartridge values', 'Junction cone', 'α').locator('td').first().innerText(), '40°');
  assert.equal(await row('Chamber values', 'Rifling', 'i').locator('td').first().innerText(), '1°45\'0"');
  assert.equal(await row('Chamber values', 'Rifling', 'α1').locator('td').first().innerText(), '71°25\'59"');
  await open('338_lapua_mag', '338 Lapua Mag.');
  assert.equal(await row('Cartridge values', 'Junction cone', 'α').locator('td').first().innerText(), '39°59\'49"');
});

test('names and decimals are shown as published', async () => {
  await open('6_5_creedmoor', '6,5 Creedmoor');
  assert.equal(await page.title(), '6,5 Creedmoor – C.I.P. cartridges');
  assert.equal(await row('Cartridge values', 'Lengths', 'L3').locator('td').first().innerText(), '48.77');
});

test('Print asks the browser to print; All cartridges returns to the list', async () => {
  await open('45_auto', '45 Auto');
  await page.getByRole('button', { name: 'Print' }).click();
  assert.equal(await page.evaluate(() => window.__printCalls), 1);
  await page.getByRole('link', { name: 'All cartridges' }).click();
  await page.getByRole('heading', { level: 1, name: 'Cartridges' }).waitFor();
});

test('every detail view renders: tables, drawing, no Tol rows, no undefined text', async () => {
  for (const r of records) {
    await open(r.key, r.name);
    assert.ok((await page.locator('table.values').count()) >= 8, r.key);
    await page.getByRole('img', { name: `${r.name} drawing`, exact: true }).waitFor();
    const text = await page.locator('main').innerText();
    assert.doesNotMatch(text, /undefined|NaN|\[object/, r.key);
    assert.equal(await page.locator('table.values th', { hasText: /Tol$/ }).count(), 0, r.key);
  }
});

test('keyboard: toolbar controls are reachable and show a focus ring', async () => {
  await open('45_auto', '45 Auto');
  await page.keyboard.press('Tab');
  await page.keyboard.press('Tab');
  const focused = await page.evaluate(() => {
    const el = document.activeElement;
    return { text: el.textContent, outline: getComputedStyle(el).outlineStyle };
  });
  assert.ok(/All cartridges|Print/.test(focused.text), focused.text);
  assert.notEqual(focused.outline, 'none');
});
