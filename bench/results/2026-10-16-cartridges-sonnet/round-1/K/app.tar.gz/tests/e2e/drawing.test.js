'use strict';
// Spec: cartridge-drawing, measured in the real browser (getBBox / path sampling), for all 25 cartridges.
const test = require('node:test');
const assert = require('node:assert/strict');
const { records, launch, fileBase, detailHash, watch } = require('./helpers.js');

let browser;
let page;
let problems;

test.before(async () => {
  browser = await launch();
});
test.after(() => browser.close());
test.beforeEach(async () => {
  page = await browser.newPage({ viewport: { width: 1200, height: 900 } });
  problems = watch(page);
});
test.afterEach(async () => {
  assert.deepEqual(problems, []);
  await page.close();
});

const open = async (r) => {
  await page.goto(fileBase() + detailHash(r.key));
  await page.getByRole('img', { name: `${r.name} drawing`, exact: true }).waitFor();
};

/** Runs inside the page: label boxes vs every drawn line, arrow and outline, vs each other, title block, view box. */
function measureCollisions() {
  const svg = document.querySelector('svg.drawing');
  const vb = svg.viewBox.baseVal;
  const labels = [...svg.querySelectorAll('.dim-label')].map((t) => {
    const b = t.getBBox();
    return { text: t.textContent, x0: b.x, y0: b.y, x1: b.x + b.width, y1: b.y + b.height };
  });
  const frame = svg.querySelector('.title-frame').getBBox();
  const title = { x0: frame.x, y0: frame.y, x1: frame.x + frame.width, y1: frame.y + frame.height };
  const samples = [];
  for (const el of svg.querySelectorAll('.outline, .edge, .dimension-line, .extension-line, .dimension-tail, .arrowhead, .cut')) {
    const len = el.getTotalLength();
    const n = Math.max(2, Math.ceil(len / 0.1));
    for (let i = 0; i <= n; i += 1) {
      const p = el.getPointAtLength((len * i) / n);
      samples.push({ x: p.x, y: p.y, cls: el.getAttribute('class') });
    }
  }
  const problemsFound = [];
  const touch = (a, b, pad) => a.x0 < b.x1 + pad && b.x0 < a.x1 + pad && a.y0 < b.y1 + pad && b.y0 < a.y1 + pad;
  labels.forEach((l, i) => {
    if (l.x0 < vb.x || l.y0 < vb.y || l.x1 > vb.x + vb.width || l.y1 > vb.y + vb.height) problemsFound.push(`${l.text}: outside view box`);
    if (touch(l, title, 0)) problemsFound.push(`${l.text}: overlaps the title block`);
    labels.slice(i + 1).forEach((o) => touch(l, o, 0) && problemsFound.push(`${l.text} overlaps ${o.text}`));
    const hit = samples.find((s) => s.x >= l.x0 && s.x <= l.x1 && s.y >= l.y0 && s.y <= l.y1);
    if (hit) problemsFound.push(`${l.text}: touched by ${hit.cls} at ${hit.x.toFixed(2)},${hit.y.toFixed(2)}`);
  });
  const t = [...svg.querySelectorAll('.title-text')].map((e) => e.getBBox());
  t.forEach((b) => {
    if (b.x < frame.x || b.x + b.width > frame.x + frame.width) problemsFound.push('title text overflows its frame');
  });
  return { problems: problemsFound, labelCount: labels.length };
}

test('every drawing: no label overlaps another label, the outline, any line, arrow or the title block', async () => {
  for (const r of records) {
    await open(r);
    const result = await page.evaluate(measureCollisions);
    assert.deepEqual(result.problems, [], r.key);
    assert.ok(result.labelCount >= 7, `${r.key} has ${result.labelCount} labels`);
  }
});

test('true scale for every cartridge: head at 0, rim diameter R1, tip at L6, mouth at L3', async () => {
  for (const r of records) {
    await open(r);
    const box = await page.evaluate(() => {
      const bb = (sel) => {
        const b = document.querySelector(sel).getBBox();
        return { x0: b.x, y0: b.y, x1: b.x + b.width, y1: b.y + b.height };
      };
      return { outline: bb('.outline-upper'), bullet: bb('.bullet-visible'), cut: bb('.cut-case') };
    });
    const c = r.cartridge;
    const near = (a, b, msg) => assert.ok(Math.abs(a - b) < 0.002, `${r.key} ${msg}: ${a} vs ${b}`);
    near(box.outline.x0, 0, 'head face');
    const widest = Math.max(c.caseHead.R1, c.powderChamber.P1) / 2; // the body can be wider than the rim
    near(box.outline.y0, -widest, 'widest radius');
    near(box.bullet.x1, c.lengths.L6, 'tip');
    near(box.outline.x1, c.lengths.L3, 'mouth');
    near(box.cut.y1, widest, 'section widest radius (mirror)');
    assert.ok(box.cut.y0 >= -1e-9, `${r.key} hatched section lies below the axis`);
  }
});

test('outside view is unhatched, section hatched, centre line is dash-dot on the axis', async () => {
  await open(records.find((r) => r.key === '308_win'));
  const facts = await page.evaluate(() => {
    const svg = document.querySelector('svg.drawing');
    const centre = svg.querySelector('.centre-line');
    return {
      upperFills: [...svg.querySelectorAll('.view-outside *')].map((e) => getComputedStyle(e).fill).filter((f) => f.includes('url')),
      lowerFills: [...svg.querySelectorAll('.view-section *')].map((e) => e.getAttribute('fill')).filter(Boolean),
      centreY: [centre.getAttribute('y1'), centre.getAttribute('y2')],
      dash: getComputedStyle(centre).strokeDasharray,
    };
  });
  assert.deepEqual(facts.upperFills, []);
  assert.ok(facts.lowerFills.every((f) => f.startsWith('url(#hatch')) && facts.lowerFills.length === 2);
  assert.deepEqual(facts.centreY, ['0', '0']);
  assert.notEqual(facts.dash, 'none');
  assert.ok(facts.dash.split(',').length >= 4, facts.dash);
});

test('the labels of 308 Win. are exactly the published values', async () => {
  await open(records.find((r) => r.key === '308_win'));
  const texts = await page.locator('svg.drawing .dim-label').allTextContents();
  assert.deepEqual(texts.sort(), ['E1 10.39', 'G1 7.85', 'H1 8.72', 'H2 8.72', 'L1 39.62', 'L2 43.48', 'L3 51.18', 'L6 71.12', 'P1 11.96', 'P2 11.53', 'R 1.37', 'R1 12.01', 'α 40°'].sort());
  const title = await page.locator('svg.drawing .title-text').allTextContents();
  assert.deepEqual(title.slice(0, 3), ['308 Win.', 'C.I.P. table I · revised 2008-09-23', 'Dimensions in mm']);
  assert.match(title[3], /^Scale \d\.\d\d:1 on A4 print \(1 unit = 1 mm\)$/);
});

test('dimension groups carry arrowheads and extension lines', async () => {
  await open(records.find((r) => r.key === '308_win'));
  const dims = await page.evaluate(() =>
    [...document.querySelectorAll('svg.drawing g.dim')].map((g) => ({
      id: g.dataset.dim,
      arrows: g.querySelectorAll('.arrowhead').length,
      ext: g.querySelectorAll('.extension-line').length,
    })),
  );
  assert.equal(dims.length, 13);
  for (const d of dims) {
    assert.ok(d.arrows >= 2, `${d.id} arrowheads`);
    assert.ok(d.ext >= 1, `${d.id} extension line`);
  }
});

test('missing values are reported under the drawing, complete records have no note', async () => {
  await open(records.find((r) => r.key === '308_win'));
  assert.equal(await page.locator('.drawing-notes').count(), 0);
  await open(records.find((r) => r.key === '17_hmr'));
  const notes = await page.locator('.drawing-notes li').allInnerTexts();
  assert.ok(notes.some((n) => n.includes('r1 min') && n.includes('r2')), notes.join('|'));
  await open(records.find((r) => r.key === '9_mm_luger'));
  assert.ok((await page.locator('.drawing-notes li').allInnerTexts()).some((n) => /straight/i.test(n)));
  assert.match(await page.locator('.drawing-facts').innerText(), /Rim type: rimless · bullet shape: rounded/);
});
