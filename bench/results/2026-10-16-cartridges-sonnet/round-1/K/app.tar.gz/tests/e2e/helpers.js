'use strict';
// Shared e2e helpers: browser launch (with optional private system libs), static server, app URLs.
const fs = require('node:fs');
const http = require('node:http');
const os = require('node:os');
const path = require('node:path');
const { chromium } = require('playwright');

const root = path.join(__dirname, '..', '..');
const records = require('../../js/data.js');

const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8' };

/** Chromium needs a few system libraries; in minimal containers they can be unpacked to a private directory. */
function browserEnv() {
  const libs = process.env.CIP_CHROMIUM_LIBS || path.join(os.homedir(), 'chromium-libs');
  if (!fs.existsSync(libs)) return process.env;
  const dirs = [`${libs}/usr/lib/x86_64-linux-gnu`, `${libs}/lib/x86_64-linux-gnu`];
  return {
    ...process.env,
    LD_LIBRARY_PATH: [...dirs, process.env.LD_LIBRARY_PATH].filter(Boolean).join(':'),
    FONTCONFIG_FILE: fs.existsSync(`${libs}/fonts.conf`) ? `${libs}/fonts.conf` : process.env.FONTCONFIG_FILE,
  };
}

const launch = () => chromium.launch({ env: browserEnv() });

/** Serves the project folder under `prefix` (e.g. "/some/sub/path"). */
function startServer(prefix = '') {
  const requests = [];
  const server = http.createServer((req, res) => {
    requests.push(req.url);
    let url;
    try {
      url = decodeURIComponent(req.url.split('?')[0]);
    } catch (error) {
      res.writeHead(400).end('bad request');
      return;
    }
    if (!url.startsWith(`${prefix}/`)) {
      res.writeHead(404).end('not found');
      return;
    }
    const rel = url.slice(prefix.length) === '/' ? '/index.html' : url.slice(prefix.length);
    const file = path.join(root, rel);
    if (!file.startsWith(root + path.sep) || !fs.existsSync(file) || fs.statSync(file).isDirectory()) {
      res.writeHead(404).end('not found');
      return;
    }
    res.writeHead(200, { 'content-type': MIME[path.extname(file)] || 'application/octet-stream' }).end(fs.readFileSync(file));
  });
  return new Promise((resolve) => {
    server.listen(0, '127.0.0.1', () => {
      const { port } = server.address();
      resolve({ base: `http://127.0.0.1:${port}${prefix}/`, requests, close: () => new Promise((r) => server.close(r)) });
    });
  });
}

const fileBase = () => `file://${path.join(root, 'index.html')}`;
const detailHash = (key) => `#/cartridge/${key}`;

/** Collects console errors, page errors and failed requests of a page. */
function watch(page) {
  const problems = [];
  page.on('console', (m) => ['error', 'warning'].includes(m.type()) && problems.push(`console ${m.type()}: ${m.text()}`));
  page.on('pageerror', (e) => problems.push(`pageerror: ${e.message}`));
  page.on('requestfailed', (r) => problems.push(`request failed: ${r.url()}`));
  return problems;
}

module.exports = { root, records, launch, startServer, fileBase, detailHash, watch };
