'use strict';
// Spec: static-delivery (phone usability, themes, no network, CSP, accessibility hooks).
const test = require('node:test');
const assert = require('node:assert/strict');
const { records, launch, fileBase, detailHash, watch } = require('./helpers.js');

let browser;
test.before(async () => {
  browser = await launch();
});
test.after(() => browser.close());

const luminance = (rgb) => {
  const [r, g, b] = rgb.match(/\d+(\.\d+)?/g).slice(0, 3).map(Number);
  return (0.2126 * r + 0.7152 * g + 0.0722 * b) / 255;
};

test('phone (360 px): no horizontal overflow on the list and on all 25 detail views; drawing fits', async () => {
  const page = await browser.newPage({ viewport: { width: 360, height: 740 }, deviceScaleFactor: 2, hasTouch: true, isMobile: true });
  const problems = watch(page);
  await page.goto(fileBase());
  await page.getByRole('heading', { level: 1, name: 'Cartridges' }).waitFor();
  const overflow = () => page.evaluate(() => ({ scroll: document.documentElement.scrollWidth, client: document.documentElement.clientWidth }));
  let m = await overflow();
  assert.ok(m.scroll <= m.client, `list overflows: ${m.scroll} > ${m.client}`);
  for (const r of records) {
    await page.goto(fileBase() + detailHash(r.key));
    await page.getByRole('img', { name: `${r.name} drawing`, exact: true }).waitFor();
    m = await overflow();
    assert.ok(m.scroll <= m.client, `${r.key} overflows: ${m.scroll} > ${m.client}`);
    const svgWidth = await page.locator('svg.drawing').evaluate((e) => e.getBoundingClientRect().width);
    assert.ok(svgWidth <= 360 && svgWidth > 300, `${r.key} drawing width ${svgWidth}`);
  }
  assert.deepEqual(problems, []);
  await page.close();
});

test('phone: controls and list rows are at least 44 px high', async () => {
  const page = await browser.newPage({ viewport: { width: 360, height: 740 }, hasTouch: true, isMobile: true });
  await page.goto(fileBase());
  await page.getByRole('heading', { level: 1, name: 'Cartridges' }).waitFor();
  const h = (loc) => loc.evaluate((e) => e.getBoundingClientRect().height);
  assert.ok((await h(page.getByLabel('Search'))) >= 44);
  assert.ok((await h(page.getByLabel('Family'))) >= 44);
  assert.ok((await h(page.locator('table.list tbody tr').first())) >= 44);
  assert.ok((await h(page.getByRole('link', { name: '308 Win.', exact: true }))) >= 44 - 1);
  await page.goto(fileBase() + detailHash('308_win'));
  await page.getByRole('heading', { level: 1, name: '308 Win.' }).waitFor();
  assert.ok((await h(page.getByRole('button', { name: 'Print' }))) >= 44);
  assert.ok((await h(page.getByRole('link', { name: 'All cartridges' }))) >= 44);
  await page.close();
});

test('phone: text stays readable (base font at least 15 px, inputs 16 px)', async () => {
  const page = await browser.newPage({ viewport: { width: 360, height: 740 } });
  await page.goto(fileBase());
  const sizes = await page.evaluate(() => ({
    body: parseFloat(getComputedStyle(document.body).fontSize),
    input: parseFloat(getComputedStyle(document.querySelector('#search')).fontSize),
  }));
  assert.ok(sizes.body >= 15);
  assert.ok(sizes.input >= 16);
  await page.close();
});

for (const scheme of ['light', 'dark']) {
  test(`${scheme} system setting: page and drawing follow it`, async () => {
    const page = await browser.newPage({ colorScheme: scheme });
    await page.goto(fileBase() + detailHash('308_win'));
    await page.getByRole('img', { name: '308 Win. drawing' }).waitFor();
    const c = await page.evaluate(() => ({
      bg: getComputedStyle(document.body).backgroundColor,
      fg: getComputedStyle(document.body).color,
      stroke: getComputedStyle(document.querySelector('svg.drawing .outline')).stroke,
      label: getComputedStyle(document.querySelector('svg.drawing .dim-label')).fill,
      link: getComputedStyle(document.querySelector('.back')).color,
    }));
    if (scheme === 'dark') {
      assert.ok(luminance(c.bg) < 0.15, c.bg);
      assert.ok(luminance(c.fg) > 0.7, c.fg);
      assert.ok(luminance(c.stroke) > 0.7, c.stroke);
      assert.ok(luminance(c.label) > 0.7, c.label);
    } else {
      assert.ok(luminance(c.bg) > 0.85, c.bg);
      assert.ok(luminance(c.fg) < 0.2, c.fg);
      assert.ok(luminance(c.stroke) < 0.2, c.stroke);
    }
    await page.close();
  });
}

test('numbers use tabular numerals', async () => {
  const page = await browser.newPage();
  await page.goto(fileBase() + detailHash('308_win'));
  await page.getByRole('heading', { level: 1, name: '308 Win.' }).waitFor();
  assert.match(await page.evaluate(() => getComputedStyle(document.querySelector('td.num')).fontVariantNumeric), /tabular-nums/);
  await page.close();
});

test('no network request beyond the project files, in any view', async () => {
  const page = await browser.newPage();
  const urls = [];
  page.on('request', (r) => urls.push(r.url()));
  await page.goto(fileBase());
  await page.getByRole('heading', { level: 1, name: 'Cartridges' }).waitFor();
  for (const r of records) {
    await page.goto(fileBase() + detailHash(r.key));
    await page.getByRole('heading', { level: 1, name: r.name, exact: true }).waitFor();
  }
  assert.ok(urls.length > 0);
  const base = fileBase().replace(/index\.html$/, '');
  for (const url of urls) assert.ok(url.startsWith(base), `unexpected request ${url}`);
  await page.close();
});

test('the page declares a CSP that forbids inline scripts and external origins', async () => {
  const page = await browser.newPage();
  const messages = [];
  page.on('console', (m) => messages.push(m.text()));
  await page.goto(fileBase());
  await page.getByRole('heading', { level: 1, name: 'Cartridges' }).waitFor();
  const csp = await page.locator('meta[http-equiv="Content-Security-Policy"]').getAttribute('content');
  assert.match(csp, /default-src 'none'/);
  assert.match(csp, /script-src 'self'/);
  assert.doesNotMatch(csp, /unsafe-inline|unsafe-eval|https?:/);
  await page.evaluate(() => {
    const s = document.createElement('script');
    s.textContent = 'window.__inlineRan = true';
    document.head.append(s);
  });
  assert.equal(await page.evaluate(() => window.__inlineRan), undefined);
  assert.ok(messages.some((m) => /Content Security Policy/i.test(m)), 'inline script was blocked by CSP');
  await page.close();
});

test('markup characters in the address cannot inject content', async () => {
  const page = await browser.newPage();
  const problems = watch(page);
  await page.goto(`${fileBase()}#/cartridge/%3Cimg%20src=x%20onerror=alert(1)%3E`);
  await page.getByText('Cartridge not found').first().waitFor();
  assert.equal(await page.locator('img').count(), 0);
  assert.deepEqual(problems, []);
  await page.close();
});

test('the page has a landmark structure, a skip link and one h1 per view', async () => {
  const page = await browser.newPage();
  await page.goto(fileBase() + detailHash('308_win'));
  await page.getByRole('heading', { level: 1, name: '308 Win.' }).waitFor();
  assert.equal(await page.getByRole('heading', { level: 1 }).count(), 1);
  assert.equal(await page.getByRole('main').count(), 1);
  assert.equal(await page.getByRole('banner').count(), 1);
  assert.equal(await page.getByRole('contentinfo').count(), 1);
  assert.equal(await page.getByRole('link', { name: 'Skip to content' }).count(), 1);
  assert.equal(await page.locator('html').getAttribute('lang'), 'en');
  for (const t of await page.locator('table.values').all()) assert.ok((await t.locator('caption').count()) === 1);
  await page.close();
});

test('skip link moves focus to the content without leaving the current view', async () => {
  const page = await browser.newPage();
  await page.goto(fileBase() + detailHash('308_win'));
  await page.getByRole('heading', { level: 1, name: '308 Win.' }).waitFor();
  await page.keyboard.press('Tab');
  assert.equal(await page.evaluate(() => document.activeElement.className), 'skip-link');
  await page.keyboard.press('Enter');
  assert.match(page.url(), /#\/cartridge\/308_win$/);
  assert.equal(await page.evaluate(() => document.activeElement.id), 'main');
  assert.equal(await page.getByRole('heading', { level: 1, name: '308 Win.' }).count(), 1);
  await page.close();
});

for (const scheme of ['light', 'dark']) {
  test(`${scheme}: form control borders have at least 3:1 contrast against their surroundings`, async () => {
    const page = await browser.newPage({ colorScheme: scheme });
    await page.goto(fileBase());
    await page.getByRole('heading', { level: 1, name: 'Cartridges' }).waitFor();
    const result = await page.evaluate(() => {
      const channels = (c) => c.match(/\d+(\.\d+)?/g).slice(0, 3).map(Number);
      const lum = (c) => {
        const [r, g, b] = channels(c).map((v) => v / 255).map((v) => (v <= 0.03928 ? v / 12.92 : ((v + 0.055) / 1.055) ** 2.4));
        return 0.2126 * r + 0.7152 * g + 0.0722 * b;
      };
      const ratio = (a, b) => {
        const [hi, lo] = [lum(a), lum(b)].sort((x, y) => y - x);
        return (hi + 0.05) / (lo + 0.05);
      };
      const page = getComputedStyle(document.body).backgroundColor;
      return ['#search', '#family'].map((sel) => {
        const cs = getComputedStyle(document.querySelector(sel));
        return { sel, border: ratio(cs.borderTopColor, page), inner: ratio(cs.borderTopColor, cs.backgroundColor) };
      });
    });
    for (const r of result) {
      assert.ok(r.border >= 3, `${r.sel} border vs page ${r.border.toFixed(2)}`);
      assert.ok(r.inner >= 3, `${r.sel} border vs field ${r.inner.toFixed(2)}`);
    }
    await page.close();
  });
}

test('the filters form a search landmark; the drawing is described by its notes', async () => {
  const page = await browser.newPage();
  await page.goto(fileBase());
  await page.getByRole('search', { name: 'Filter cartridges' }).waitFor();
  await page.goto(fileBase() + detailHash('17_hmr'));
  await page.getByRole('img', { name: '17 HMR drawing', exact: true }).waitFor();
  const description = await page.evaluate(() => {
    const id = document.querySelector('svg.drawing').getAttribute('aria-describedby');
    return document.getElementById(id).textContent;
  });
  assert.match(description, /Rim type: rimfire/);
  assert.match(description, /r1 min/);
  await page.close();
});

test('no label text is set below 12 px in the interface (small caps included)', async () => {
  const page = await browser.newPage({ viewport: { width: 1100, height: 900 } });
  await page.goto(fileBase() + detailHash('308_win'));
  await page.getByRole('heading', { level: 1, name: '308 Win.' }).waitFor();
  const smallest = await page.evaluate(() =>
    Math.min(...[...document.querySelectorAll('main *:not(svg *)')].filter((e) => e.childNodes.length && [...e.childNodes].some((n) => n.nodeType === 3 && n.textContent.trim())).map((e) => parseFloat(getComputedStyle(e).fontSize))),
  );
  assert.ok(smallest >= 12.5, `smallest interface text ${smallest}px`);
  await page.close();
});
