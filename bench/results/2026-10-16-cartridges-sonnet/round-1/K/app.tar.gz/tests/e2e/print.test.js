'use strict';
// Spec: print-output. One A4 portrait page, black on white, header / drawing / tables / footer.
const test = require('node:test');
const assert = require('node:assert/strict');
const { records, launch, fileBase, detailHash } = require('./helpers.js');

const A4_PRINTABLE_PX = Math.round(((210 - 20) / 25.4) * 96); // 10 mm side margins

let browser;
test.before(async () => {
  browser = await launch();
});
test.after(() => browser.close());

const pageCount = (pdf) => (pdf.toString('latin1').match(/\/Type\s*\/Page(?![s\w])/g) || []).length;

async function openForPrint(scheme, r) {
  const page = await browser.newPage({ viewport: { width: A4_PRINTABLE_PX, height: 1000 }, colorScheme: scheme });
  await page.goto(fileBase() + detailHash(r.key));
  await page.getByRole('img', { name: `${r.name} drawing`, exact: true }).waitFor();
  return page;
}

test('every detail view prints on exactly one A4 portrait page', async () => {
  const page = await browser.newPage();
  const failures = [];
  for (const r of records) {
    await page.goto(fileBase() + detailHash(r.key));
    await page.getByRole('img', { name: `${r.name} drawing`, exact: true }).waitFor();
    const pdf = await page.pdf({ format: 'A4', preferCSSPageSize: true, printBackground: false });
    const pages = pageCount(pdf);
    if (pages !== 1) failures.push(`${r.key}: ${pages} pages`);
    assert.match(pdf.toString('latin1', 0, 8), /^%PDF/);
    const box = pdf.toString('latin1').match(/\/MediaBox\s*\[\s*0\s+0\s+([\d.]+)\s+([\d.]+)\s*\]/);
    assert.ok(box && Math.abs(Number(box[1]) - 595.28) < 1 && Math.abs(Number(box[2]) - 841.89) < 1, `${r.key} A4 portrait: ${box && box.slice(1)}`);
  }
  assert.deepEqual(failures, []);
  await page.close();
});

test('the printed content leaves a safety margin on the page (other fonts, other metrics)', async () => {
  const PAGE_CONTENT_PX = Math.round(((297 - 20) / 25.4) * 96); // 10 mm margins; main includes the footer's reserve
  for (const r of records) {
    const page = await openForPrint('light', r);
    await page.emulateMedia({ media: 'print' });
    const height = await page.evaluate(() => document.querySelector('main').getBoundingClientRect().height);
    assert.ok(height <= PAGE_CONTENT_PX * 0.93, `${r.key}: content ${Math.round(height)} px of ${PAGE_CONTENT_PX}`);
    await page.close();
  }
});

test('print hides navigation, search, filters and buttons; shows header, drawing, tables and footer in order', async () => {
  const r = records.find((x) => x.key === '308_win');
  const page = await openForPrint('light', r);
  await page.emulateMedia({ media: 'print' });
  for (const sel of ['.toolbar', '.print-button', '.back', '.site-header', '.site-footer', '.filters', '.skip-link', 'table.list']) {
    for (const el of await page.locator(sel).all()) assert.equal(await el.isVisible(), false, sel);
  }
  assert.equal(await page.getByRole('button', { name: 'Print' }).isVisible(), false);
  assert.equal(await page.getByRole('link', { name: 'All cartridges' }).isVisible(), false);
  const footer = page.locator('.print-footer');
  assert.equal(await footer.isVisible(), true);
  assert.equal(await footer.innerText(), 'Source: C.I.P. TDCC, revised 2008-09-23');
  const y = async (loc) => (await loc.boundingBox()).y;
  const header = await y(page.getByRole('heading', { level: 1, name: '308 Win.' }));
  const drawing = await y(page.locator('svg.drawing'));
  const firstTable = await y(page.locator('table.values').first());
  assert.ok(header < drawing && drawing < firstTable, `order ${header} < ${drawing} < ${firstTable}`);
  await page.close();
});

test('the drawing spans the full printable width and its smallest text is at least 6 pt', async () => {
  for (const r of records) {
    const page = await openForPrint('light', r);
    await page.emulateMedia({ media: 'print' });
    const m = await page.evaluate(() => {
      const svg = document.querySelector('svg.drawing');
      const main = document.querySelector('main').getBoundingClientRect();
      const width = svg.getBoundingClientRect().width;
      const vb = svg.viewBox.baseVal;
      const pxPerUnit = width / vb.width;
      const sizes = [...svg.querySelectorAll('text')].map((t) => parseFloat(t.getAttribute('font-size')) * pxPerUnit * 0.75);
      return { width, mainWidth: main.width, minPt: Math.min(...sizes) };
    });
    assert.ok(m.width >= m.mainWidth - 1, `${r.key}: drawing ${m.width} of ${m.mainWidth}`);
    assert.ok(m.minPt >= 6, `${r.key}: smallest text ${m.minPt.toFixed(1)} pt`);
    await page.close();
  }
});

for (const scheme of ['light', 'dark']) {
  test(`print is black on white even when the screen theme is ${scheme}`, async () => {
    const r = records.find((x) => x.key === '300_win_mag');
    const page = await openForPrint(scheme, r);
    await page.emulateMedia({ media: 'print', colorScheme: scheme });
    const result = await page.evaluate(() => {
      const bad = [];
      const isBlack = (c) => c === 'rgb(0, 0, 0)';
      const isClear = (c) => c === 'rgba(0, 0, 0, 0)' || c === 'rgb(255, 255, 255)';
      for (const el of document.querySelectorAll('main *, body, html')) {
        const cs = getComputedStyle(el);
        if (el.closest('svg')) {
          if (el.matches('.outline, .cut, .dimension-line, .extension-line, .edge, .centre-line, .hatch-line, .title-frame') && !isBlack(cs.stroke)) bad.push(`${el.getAttribute('class')} stroke ${cs.stroke}`);
          if (el.matches('.dim-label, .title-text, .arrowhead') && !isBlack(cs.fill)) bad.push(`${el.getAttribute('class')} fill ${cs.fill}`);
          continue;
        }
        if (el.getClientRects().length === 0) continue; // not rendered in print (hidden toolbar, buttons)
        if (el.textContent.trim() && !el.children.length && !isBlack(cs.color)) bad.push(`${el.tagName} color ${cs.color}`);
        if (!isClear(cs.backgroundColor)) bad.push(`${el.tagName} background ${cs.backgroundColor}`);
      }
      return { bad, bodyBg: getComputedStyle(document.body).backgroundColor };
    });
    assert.deepEqual(result.bad, []);
    assert.equal(result.bodyBg, 'rgb(255, 255, 255)');
    await page.close();
  });
}

test('printing the list is not a blank page: the table prints, the filters do not', async () => {
  const page = await browser.newPage({ viewport: { width: A4_PRINTABLE_PX, height: 1000 } });
  await page.goto(fileBase());
  await page.getByRole('heading', { level: 1, name: 'Cartridges' }).waitFor();
  await page.emulateMedia({ media: 'print' });
  assert.equal(await page.locator('table.list').isVisible(), true);
  assert.equal(await page.locator('.filters').isVisible(), false);
  await page.close();
});

test('the scale stated in the title block is the scale actually printed', async () => {
  const mmPerPx = 25.4 / 96;
  for (const r of records) {
    const page = await openForPrint('light', r);
    await page.emulateMedia({ media: 'print' });
    const m = await page.evaluate(() => {
      const svg = document.querySelector('svg.drawing');
      const box = svg.getBoundingClientRect();
      const vb = svg.viewBox.baseVal;
      const text = [...svg.querySelectorAll('.title-text')].map((t) => t.textContent).find((t) => t.startsWith('Scale'));
      const frame = svg.querySelector('.title-frame').getBoundingClientRect();
      return { px: Math.min(box.width / vb.width, box.height / vb.height), text, frameWidth: frame.width, boxWidth: box.width, vbWidth: vb.width };
    });
    const stated = Number(m.text.match(/Scale (\d\.\d\d):1/)[1]);
    const printed = m.px * mmPerPx; // millimetres on paper per drawing unit (= per mm of cartridge)
    assert.ok(Math.abs(printed - stated) / stated < 0.01, `${r.key}: stated ${stated}, printed ${printed.toFixed(3)}`);
    await page.close();
  }
});
