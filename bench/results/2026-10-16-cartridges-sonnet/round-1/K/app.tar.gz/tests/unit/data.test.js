'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

const root = path.join(__dirname, '..', '..');
const fixture = fs
  .readFileSync(path.join(root, 'tests', 'fixtures', 'records.jsonl'), 'utf8')
  .split('\n')
  .filter(Boolean)
  .map((line) => JSON.parse(line));

const records = require(path.join(root, 'js', 'data.js'));

test('embeds exactly the 25 supplied records', () => {
  assert.equal(fixture.length, 25);
  assert.equal(records.length, 25);
});

test('every embedded record equals the supplied record', () => {
  assert.deepEqual(records, fixture);
});

test('keys are unique and url-safe', () => {
  const keys = records.map((r) => r.key);
  assert.equal(new Set(keys).size, 25);
  for (const key of keys) assert.match(key, /^[a-z0-9_]+$/);
});

test('names are kept as published', () => {
  const names = records.map((r) => r.name);
  assert.ok(names.includes('6,5 Creedmoor'));
  assert.ok(names.includes('40 S.& W.'));
  assert.ok(names.includes('22 Win. Mag. R.F.'));
});

test('families are the five published ones', () => {
  const families = new Set(records.map((r) => r.family));
  assert.deepEqual([...families].sort(), ['belted', 'pistol', 'rimfire', 'rimless', 'rimmed']);
});

test('records are deeply frozen so views cannot mutate them', () => {
  assert.throws(() => {
    'use strict';
    records[0].name = 'x';
  }, TypeError);
  assert.throws(() => {
    'use strict';
    records[0].cartridge.lengths.L3 = 1;
  }, TypeError);
});
