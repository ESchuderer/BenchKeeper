'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');

const records = require('../../js/data.js');
require('../../js/format.js');
require('../../js/mathutil.js');
require('../../js/bullet.js');
const geometry = require('../../js/geometry.js');
const dimensions = require('../../js/dimensions.js');
const { findCollisions } = require('./helpers/collisions.js');

const byKey = (key) => records.find((r) => r.key === key);
const layoutOf = (key) => dimensions.layout(geometry.build(byKey(key)));
const clone = (value) => JSON.parse(JSON.stringify(value));
const labels = (layout) => layout.items.map((i) => i.label.text);
const item = (layout, id) => layout.items.find((i) => i.id === id);

const overlaps = (a, b, pad = 0) =>
  a.x0 < b.x1 + pad && b.x0 < a.x1 + pad && a.y0 < b.y1 + pad && b.y0 < a.y1 + pad;

test('308 Win. has every required label with symbol and value', () => {
  const texts = labels(layoutOf('308_win'));
  for (const expected of ['L3 51.18', 'L6 71.12', 'R1 12.01', 'R 1.37', 'P1 11.96', 'P2 11.53', 'H1 8.72', 'H2 8.72', 'G1 7.85', 'L1 39.62', 'L2 43.48', 'E1 10.39', 'α 40°']) {
    assert.ok(texts.includes(expected), `${expected} in ${texts.join(' | ')}`);
  }
  assert.equal(texts.length, 13);
});

test('alpha label uses degrees minutes seconds when published so', () => {
  assert.ok(labels(layoutOf('338_lapua_mag')).includes('α 39°59\'49"'));
});

test('unpublished dimensions are omitted (9 mm Luger has no P2, H1, L1, L2, alpha)', () => {
  const texts = labels(layoutOf('9_mm_luger'));
  assert.deepEqual(texts.map((t) => t.split(' ')[0]).sort(), ['E1', 'G1', 'H2', 'L3', 'L6', 'P1', 'R', 'R1']);
});

test('rimmed and rimfire cases have no E1 dimension', () => {
  assert.ok(!labels(layoutOf('7_x_65_r')).some((t) => t.startsWith('E1')));
  assert.ok(!labels(layoutOf('22_long_rifle')).some((t) => t.startsWith('E1')));
});

test('length dimension lines measure exactly the published value', () => {
  const layout = layoutOf('308_win');
  const expected = { L1: 39.62, L2: 43.48, L3: 51.18, L6: 71.12, R: 1.37 };
  for (const [id, value] of Object.entries(expected)) {
    const line = item(layout, id).lines.find((l) => l.cls === 'dimension-line');
    assert.ok(Math.abs(Math.abs(line.x2 - line.x1) - value) < 1e-9, id);
    assert.equal(line.y1, line.y2);
    assert.equal(Math.min(line.x1, line.x2), 0, `${id} starts at the head face`);
  }
});

test('diameter dimension lines are vertical, centred on the axis and measure the published value', () => {
  const layout = layoutOf('308_win');
  const expected = { R1: 12.01, E1: 10.39, P1: 11.96, P2: 11.53, H1: 8.72, H2: 8.72, G1: 7.85 };
  for (const [id, value] of Object.entries(expected)) {
    const line = item(layout, id).lines.find((l) => l.cls === 'dimension-line');
    assert.equal(line.x1, line.x2, id);
    assert.ok(Math.abs(Math.abs(line.y2 - line.y1) - value) < 1e-9, id);
    assert.ok(Math.abs(line.y1 + line.y2) < 1e-9, `${id} symmetric about the axis`);
  }
});

test('every dimension has a dimension line, arrowheads and an extension line', () => {
  for (const it of layoutOf('308_win').items) {
    assert.ok(it.lines.some((l) => l.cls === 'dimension-line') || it.arc, `${it.id} dimension line`);
    assert.ok(it.lines.some((l) => l.cls === 'extension-line'), `${it.id} extension line`);
    assert.ok(it.arrows.length >= 2, `${it.id} arrowheads`);
  }
});

test('alpha is drawn as an arc about the shoulder apex with extension line', () => {
  const alpha = item(layoutOf('308_win'), 'alpha');
  assert.ok(alpha.arc);
  assert.ok(alpha.lines.some((l) => l.cls === 'extension-line'));
  assert.equal(alpha.arrows.length, 2);
});

test('the title block carries name, table, revision date, units and scale', () => {
  const layout = layoutOf('308_win');
  const texts = layout.title.lines.map((l) => l.text);
  assert.deepEqual(texts.slice(0, 3), ['308 Win.', 'C.I.P. table I · revised 2008-09-23', 'Dimensions in mm']);
  const expected = Math.min(dimensions.PRINT_AREA.width / layout.viewBox.w, dimensions.PRINT_AREA.height / layout.viewBox.h);
  assert.equal(texts[3], `Scale ${expected.toFixed(2)}:1 on A4 print (1 unit = 1 mm)`);
});

test('the view box contains every label, the title block and the outline', () => {
  const layout = layoutOf('308_win');
  const vb = layout.viewBox;
  const inside = (r) => r.x0 >= vb.x && r.y0 >= vb.y && r.x1 <= vb.x + vb.w && r.y1 <= vb.y + vb.h;
  for (const it of layout.items) assert.ok(inside(it.label.rect), it.id);
  assert.ok(inside(layout.title.rect));
  assert.ok(vb.x < 0 && vb.x + vb.w > 71.12);
});

test('all 25 drawings: labels do not overlap each other, the outline, dimension lines of others, or the title block', () => {
  for (const r of records) {
    const g = geometry.build(r);
    const layout = dimensions.layout(g);
    const problems = findCollisions(g, layout);
    assert.deepEqual(problems, [], `${r.key}: ${problems.join('; ')}`);
    const rects = layout.items.map((i) => ({ id: i.id, ...i.label.rect }));
    for (let i = 0; i < rects.length; i += 1) {
      for (let j = i + 1; j < rects.length; j += 1) {
        assert.ok(!overlaps(rects[i], rects[j], 0.3), `${r.key}: ${rects[i].id} overlaps ${rects[j].id}`);
      }
      assert.ok(!overlaps(rects[i], layout.title.rect, 0.3), `${r.key}: ${rects[i].id} overlaps title block`);
    }
  }
});

test('the collision checker really detects an overlap', () => {
  const g = geometry.build(byKey('308_win'));
  const layout = dimensions.layout(g);
  const broken = clone(layout);
  const [a, b] = broken.items;
  b.label.rect = { ...a.label.rect };
  assert.ok(findCollisions(g, broken).length > 0);
  const onOutline = clone(layout);
  onOutline.items[0].label.rect = { x0: 10, y0: -7, x1: 20, y1: -5 }; // straddles the upper edge of the body
  assert.ok(findCollisions(g, onOutline).length > 0);
});

test('labels lie outside the cartridge bounding box (above, below, left or right of it)', () => {
  for (const r of records) {
    const g = geometry.build(r);
    const layout = dimensions.layout(g);
    const rmax = Math.max(...g.profile.points.map((p) => p.r));
    for (const it of layout.items) {
      const rect = it.label.rect;
      const clear = rect.y1 < -rmax || rect.y0 > rmax || rect.x1 < 0 || rect.x0 > r.cartridge.lengths.L6;
      assert.ok(clear, `${r.key} ${it.id}`);
    }
  }
});

test('label text uses only published values (no invented numbers)', () => {
  const g = geometry.build(byKey('9_mm_luger'));
  const texts = labels(dimensions.layout(g));
  assert.ok(texts.includes('L3 19.15') && texts.includes('H2 9.65') && texts.includes('G1 9.03') && texts.includes('E1 8.79'));
});

test('layout does not break when values are missing', () => {
  const rec = clone(byKey('308_win'));
  delete rec.cartridge.lengths.L6;
  delete rec.cartridge.projectile.G1;
  delete rec.cartridge.powderChamber.P2;
  const g = geometry.build(rec);
  const layout = dimensions.layout(g);
  const texts = labels(layout);
  assert.ok(!texts.some((t) => t.startsWith('L6') || t.startsWith('G1') || t.startsWith('P2')));
  assert.ok(texts.includes('L3 51.18'));
  assert.deepEqual(findCollisions(g, layout), []);
});

test('an unbuildable geometry gives no layout', () => {
  const rec = clone(byKey('308_win'));
  delete rec.cartridge.lengths.L3;
  assert.equal(dimensions.layout(geometry.build(rec)), null);
});

test('R1 extension lines start at the rim even when the body is wider (9,3 x 62)', () => {
  const g = geometry.build(byKey('9_3_x_62'));
  const r1 = dimensions.layout(g).items.find((i) => i.id === 'R1');
  const horizontals = r1.lines.filter((l) => l.cls === 'extension-line' && l.y1 === l.y2);
  assert.equal(horizontals.length, 2);
  for (const l of horizontals) {
    assert.ok(Math.abs(Math.abs(l.y1) - 11.95 / 2) < 1e-9);
    assert.ok(l.x1 < 1.5, `starts at the rim (x ${l.x1}), not at the body start`);
  }
});

test('when the row search is cut off, the staircase fallback is still collision free', () => {
  for (const r of records) {
    const g = geometry.build(r);
    const lay = dimensions.layout(g, { maxSearchNodes: 1 });
    const rows = lay.items.filter((i) => i.kind !== 'length').map((i) => i.row);
    assert.equal(new Set(rows).size, rows.length, `${r.key}: staircase uses one row per label`);
    assert.deepEqual(findCollisions(g, lay), [], r.key);
  }
});

test('the R label moves to the left when the right-hand position is blocked', () => {
  const rec = clone(byKey('22_long_rifle'));
  rec.cartridge.lengths.L3 = 8;
  rec.cartridge.lengths.L6 = 18;
  const g = geometry.build(rec);
  const lay = dimensions.layout(g);
  const r = lay.items.find((i) => i.id === 'R');
  assert.equal(r.label.anchor, 'end');
  assert.deepEqual(findCollisions(g, lay), []);
});

test('the label separation asked of the row search keeps neighbouring labels visibly apart', () => {
  for (const r of records) {
    const lay = dimensions.layout(geometry.build(r));
    const top = lay.items.filter((i) => i.kind !== 'length').map((i) => ({ id: i.id, ...i.label.rect }));
    for (let a = 0; a < top.length; a += 1) {
      for (let b = a + 1; b < top.length; b += 1) {
        assert.ok(!overlaps(top[a], top[b], 1.0), `${r.key}: ${top[a].id} too close to ${top[b].id}`);
      }
    }
  }
});
