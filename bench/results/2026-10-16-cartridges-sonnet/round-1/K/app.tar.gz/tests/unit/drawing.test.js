'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');

const records = require('../../js/data.js');
require('../../js/format.js');
require('../../js/mathutil.js');
require('../../js/bullet.js');
require('../../js/geometry.js');
require('../../js/dimensions.js');
const drawing = require('../../js/drawing.js');

const byKey = (key) => records.find((r) => r.key === key);
const clone = (value) => JSON.parse(JSON.stringify(value));
const render = (key) => drawing.build(byKey(key));
const between = (s, open, close) => {
  const i = s.indexOf(open);
  assert.ok(i >= 0, `${open} present`);
  const j = s.indexOf(close, i);
  return s.slice(i, j + close.length);
};
const numbers = (d) => (d.match(/-?\d+(?:\.\d+)?/g) || []).map(Number);

test('the SVG is inline, labelled "<name> drawing", scaled by its view box', () => {
  const { svg } = render('308_win');
  assert.match(svg, /^<svg [^>]*xmlns="http:\/\/www\.w3\.org\/2000\/svg"/);
  assert.match(svg, /role="img"/);
  assert.match(svg, /aria-label="308 Win\. drawing"/);
  assert.match(svg, /viewBox="-?[\d.]+ -?[\d.]+ [\d.]+ [\d.]+"/);
  assert.doesNotMatch(svg, /<svg [^>]*\b(width|height)=/);
  assert.doesNotMatch(svg, /<script|on\w+=|href=/i);
});

test('names with markup characters are escaped', () => {
  const rec = clone(byKey('308_win'));
  rec.name = '308 <b>"Win."</b> & co';
  const { svg } = drawing.build(rec);
  assert.doesNotMatch(svg, /<b>/);
  assert.match(svg, /aria-label="308 &lt;b&gt;&quot;Win\.&quot;&lt;\/b&gt; &amp; co drawing"/);
});

test('1 user unit = 1 mm: tip at L6, rim diameter R1, head at the left', () => {
  const { svg, layout } = render('308_win');
  const outline = between(svg, '<path class="outline outline-upper"', '/>');
  const xs = numbers(outline.match(/ d="([^"]*)"/)[1]).filter((_, i) => i % 2 === 0);
  assert.equal(Math.min(...xs), 0);
  const bullet = between(svg, '<path class="outline bullet-visible"', '/>');
  const bx = numbers(bullet.match(/ d="([^"]*)"/)[1]).filter((_, i) => i % 2 === 0);
  assert.equal(Math.max(...bx), 71.12);
  const ys = numbers(outline.match(/ d="([^"]*)"/)[1]).filter((_, i) => i % 2 === 1);
  assert.equal(Math.min(...ys), -6.005);
  assert.ok(layout.viewBox.w > 71.12);
});

test('the upper half is the outside view without hatching; the lower half is a hatched section', () => {
  const { svg } = render('308_win');
  const upper = between(svg, '<g class="view-outside">', '</g>');
  const lower = between(svg, '<g class="view-section">', '</g>');
  assert.doesNotMatch(upper, /url\(#/);
  assert.match(lower, /class="cut cut-case"[^>]*fill="url\(#hatch-case\)"/);
  const cut = between(lower, '<path class="cut cut-case"', '/>');
  const ys = numbers(cut.match(/ d="([^"]*)"/)[1]).filter((_, i) => i % 2 === 1);
  assert.ok(ys.every((y) => y >= 0), 'hatched region lies in the lower half');
  assert.match(svg, /<pattern id="hatch-case"/);
});

test('a dash-dot centre line lies on the axis', () => {
  const { svg } = render('308_win');
  const centre = between(svg, '<line class="centre-line"', '/>');
  assert.match(centre, /y1="0"/);
  assert.match(centre, /y2="0"/);
  assert.match(centre, /stroke-dasharray="[\d. ]+"/);
});

test('outside view hides the seated bullet; the section shows it', () => {
  const { svg, geometry } = render('308_win');
  const bullet = between(svg, '<path class="outline bullet-visible"', '/>');
  const xs = numbers(bullet.match(/ d="([^"]*)"/)[1]).filter((_, i) => i % 2 === 0);
  assert.ok(Math.min(...xs) >= 51.18 - 1e-9);
  const section = between(svg, '<path class="cut cut-bullet"', '/>');
  const sx = numbers(section.match(/ d="([^"]*)"/)[1]).filter((_, i) => i % 2 === 0);
  assert.ok(Math.min(...sx) <= geometry.bullet.zb + 1e-9);
});

test('the primer pocket is cut out of the section head', () => {
  const { svg } = render('308_win');
  const cut = between(svg, '<path class="cut cut-case"', '/>');
  const d = cut.match(/ d="([^"]*)"/)[1];
  assert.match(d, /\b3\.3 0\b/);
  assert.match(d, /\b3\.3 2\.665\b/);
});

test('dimensions are grouped, addressable and labelled', () => {
  const { svg } = render('308_win');
  for (const id of ['L3', 'L6', 'R1', 'R', 'P1', 'P2', 'H1', 'H2', 'G1', 'L1', 'L2', 'E1', 'alpha']) {
    assert.match(svg, new RegExp(`<g class="dim" data-dim="${id}">`), id);
  }
  assert.match(svg, /<text class="dim-label"[^>]*>L3 51\.18<\/text>/);
  assert.match(svg, /<text class="dim-label"[^>]*>α 40°<\/text>/);
  assert.match(svg, /class="arrowhead"/);
  assert.match(svg, /class="extension-line"/);
});

test('the title block states name, table, revision, units and scale', () => {
  const { svg } = render('308_win');
  const block = between(svg, '<g class="title-block">', '</g>');
  assert.match(block, />308 Win\.</);
  assert.match(block, /C\.I\.P\. table I · revised 2008-09-23/);
  assert.match(block, /Dimensions in mm/);
  assert.match(block, /Scale \d\.\d\d:1 on A4 print \(1 unit = 1 mm\)/);
});

test('missing values are reported in notes and never invented', () => {
  const rec = clone(byKey('308_win'));
  delete rec.cartridge.junctionCone.r1Min;
  const out = drawing.build(rec);
  assert.ok(out.notes.some((n) => n.includes('r1 min')));
  assert.doesNotMatch(out.svg, /NaN|undefined|Infinity/);
});

test('an undrawable record gives notes and no SVG', () => {
  const rec = clone(byKey('308_win'));
  delete rec.cartridge.lengths.L3;
  const out = drawing.build(rec);
  assert.equal(out.ok, false);
  assert.equal(out.svg, '');
  assert.ok(out.notes.some((n) => n.includes('L3')));
});

test('all 25 drawings render without NaN and with unique dimension groups', () => {
  for (const r of records) {
    const out = drawing.build(r);
    assert.equal(out.ok, true, r.key);
    assert.doesNotMatch(out.svg, /NaN|undefined|Infinity/, r.key);
    const ids = [...out.svg.matchAll(/data-dim="([^"]+)"/g)].map((m) => m[1]);
    assert.equal(new Set(ids).size, ids.length, r.key);
    assert.ok(out.svg.length < 60000, `${r.key} svg size ${out.svg.length}`);
  }
});

test('notes of a complete bottleneck case are empty', () => {
  assert.deepEqual(render('308_win').notes, []);
});

test('drawing facts line mentions rim type and bullet shape', () => {
  const out = render('300_win_mag');
  assert.equal(out.facts.rimType, 'belted');
  assert.equal(out.facts.bulletShape, 'pointy');
});

test('without wall data the lower half shows the plain outline instead of a hatched section', () => {
  const rec = clone(byKey('308_win'));
  delete rec.cartridge.projectile.G1;
  const out = drawing.build(rec);
  assert.equal(out.ok, true);
  assert.doesNotMatch(out.svg, /class="cut/);
  assert.match(out.svg, /outline-lower/);
  assert.ok(out.notes.some((n) => n.includes('G1')));
});

test('the SVG can point at its description (notes and facts) for assistive technology', () => {
  const out = drawing.build(byKey('308_win'), { describedBy: 'drawing-description' });
  assert.match(out.svg, /aria-describedby="drawing-description"/);
  assert.match(out.svg, /aria-label="308 Win\. drawing"/);
  assert.doesNotMatch(drawing.build(byKey('308_win')).svg, /aria-describedby/);
});
