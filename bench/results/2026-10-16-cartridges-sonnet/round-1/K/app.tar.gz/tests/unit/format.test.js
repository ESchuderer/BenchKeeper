'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');

require('../../js/data.js');
const format = require('../../js/format.js');
const records = require('../../js/data.js');
const byKey = (key) => records.find((r) => r.key === key);

test('formatNumber shows numbers as published, point separator, no thousands separator', () => {
  assert.equal(format.formatNumber(51.18), '51.18');
  assert.equal(format.formatNumber(4150), '4150');
  assert.equal(format.formatNumber(0.1), '0.1');
  assert.equal(format.formatNumber(-0.25), '-0.25');
  assert.equal(format.formatNumber(12345.5), '12345.5');
});

test('formatAngle shows degrees or degrees minutes seconds', () => {
  assert.equal(format.formatAngle(40), '40°');
  assert.equal(format.formatAngle(0), '0°');
  assert.equal(format.formatAngle({ degrees: 39, minutes: 59, seconds: 49 }), '39°59\'49"');
  assert.equal(format.formatAngle({ degrees: 1, minutes: 45, seconds: 0 }), '1°45\'0"');
  assert.equal(format.formatAngle({ degrees: 0, minutes: 42, seconds: 29 }), '0°42\'29"');
});

test('unitFor maps fields to units', () => {
  for (const f of ['L3', 'R1', 'P1', 'G1', 'E1', 'u', 'h', 'S', 'Fe', 'deltaL', 'L3PlusG', 'r1Min', 'Z', 'F']) {
    assert.equal(format.unitFor(f), 'mm', f);
  }
  for (const f of ['Pmax', 'PK', 'PE']) assert.equal(format.unitFor(f), 'bar', f);
  assert.equal(format.unitFor('EE'), 'J');
  assert.equal(format.unitFor('M'), 'g');
  assert.equal(format.unitFor('Q'), 'mm²');
  assert.equal(format.unitFor('N'), '');
  for (const f of ['alpha', 'alpha1', 'beta', 'delta', 'i']) assert.equal(format.unitFor(f), '°', f);
});

test('symbolFor uses the field name except the published special symbols', () => {
  const expected = {
    eMin: 'e min', r1Min: 'r1 min', r1Max: 'r1 max', alpha: 'α', alpha1: 'α1', beta: 'β',
    delta: 'δ', deltaL: 'delta L', L3PlusG: 'L3 + G', L3: 'L3', Pmax: 'Pmax', i: 'i', G1: 'G1',
  };
  for (const [field, symbol] of Object.entries(expected)) assert.equal(format.symbolFor(field), symbol, field);
});

test('sectionRows attaches tolerances to their value and never lists them', () => {
  const rows = format.sectionRows('lengths', byKey('308_win').cartridge.lengths);
  const l1 = rows.find((r) => r.symbol === 'L1');
  assert.equal(l1.value, '39.62');
  assert.equal(l1.tol, '-0.2');
  assert.equal(l1.display, '39.62 -0.2');
  assert.equal(l1.unit, 'mm');
  assert.ok(!rows.some((r) => /Tol$/.test(r.field)));
  assert.equal(rows.find((r) => r.symbol === 'L3').display, '51.18');
});

test('sectionRows formats angles and special symbols', () => {
  const cone = format.sectionRows('junctionCone', byKey('308_win').cartridge.junctionCone);
  assert.equal(cone.find((r) => r.symbol === 'α').display, '40°');
  assert.ok(cone.some((r) => r.symbol === 'r1 min'));
  const lapua = format.sectionRows('junctionCone', byKey('338_lapua_mag').cartridge.junctionCone);
  assert.equal(lapua.find((r) => r.symbol === 'α').display, '39°59\'49"');
  const rifling = format.sectionRows('rifling', byKey('308_win').chamber.rifling);
  assert.equal(rifling.find((r) => r.symbol === 'i').display, '1°45\'0"');
  assert.equal(rifling.find((r) => r.symbol === 'i').unit, '°');
});

test('pressures are listed Pmax first and carry their units', () => {
  const rows = format.sectionRows('pressures', byKey('308_win').cartridge.pressures);
  assert.deepEqual(rows.map((r) => r.symbol), ['Pmax', 'PK', 'PE', 'EE', 'M']);
  assert.deepEqual(rows.map((r) => r.unit), ['bar', 'bar', 'bar', 'J', 'g']);
  assert.equal(rows[0].display, '4150');
});

test('N has no unit, Q is in mm²', () => {
  const rows = format.sectionRows('grooves', byKey('308_win').chamber.grooves);
  assert.equal(rows.find((r) => r.symbol === 'N').unit, '');
  assert.equal(rows.find((r) => r.symbol === 'N').display, '4');
  assert.equal(rows.find((r) => r.symbol === 'Q').unit, 'mm²');
});

test('tolerance of a field in another record section: ETol next to E', () => {
  const rows = format.sectionRows('caseHead', byKey('300_win_mag').cartridge.caseHead);
  assert.equal(rows.find((r) => r.symbol === 'E').display, '5.59 -0.2');
});

test('groupSections returns non-empty sections in a fixed order with titles', () => {
  const luger = format.groupSections('cartridge', byKey('9_mm_luger').cartridge);
  assert.deepEqual(luger.map((s) => s.key), ['caseHead', 'collar', 'lengths', 'misc', 'powderChamber', 'pressures', 'projectile']);
  const chamber = format.groupSections('chamber', byKey('223_rem').chamber);
  assert.deepEqual(chamber.map((s) => s.title), ['Barrel', 'Breech', 'Collar', 'Grooves', 'Junction cone', 'Lengths', 'Powder chamber', 'Rifling']);
  const cart = format.groupSections('cartridge', byKey('223_rem').cartridge);
  assert.deepEqual(cart.map((s) => s.title), ['Case head', 'Collar', 'Junction cone', 'Lengths', 'Miscellaneous', 'Powder chamber', 'Pressures', 'Projectile']);
});

test('every record formats without NaN or undefined', () => {
  for (const r of records) {
    for (const group of ['cartridge', 'chamber']) {
      for (const s of format.groupSections(group, r[group])) {
        for (const row of s.rows) {
          assert.ok(row.display && !/NaN|undefined|\[object/.test(row.display), `${r.key} ${s.key} ${row.field}`);
        }
      }
    }
  }
});

test('normalizeSearch lower-cases, treats comma as point, collapses and trims white space', () => {
  assert.equal(format.normalizeSearch('  7,62   X 51 '), '7.62 x 51');
  assert.equal(format.normalizeSearch(''), '');
});

test('search matches name and alternative names', () => {
  const m = (key, q) => format.matchesQuery(byKey(key), q);
  assert.ok(m('308_win', '7,62 x 51'));
  assert.ok(m('308_win', '7.62 x 51'));
  assert.ok(m('308_win', '308 winchester'));
  assert.ok(m('308_win', ' 308 '));
  assert.ok(m('6_5_creedmoor', 'creed'));
  assert.ok(m('6_5_creedmoor', '6.5'));
  assert.ok(!m('7_x_65_r', '6.5'), '6.5 must not match "7 x 65 R"');
  assert.ok(m('22_long_rifle', '22lr'));
  assert.ok(m('223_rem', ''));
});

test('filterRecords combines query and family', () => {
  const names = (opts) => format.filterRecords(records, opts).map((r) => r.name);
  assert.equal(names({ query: '', family: '' }).length, 25);
  assert.deepEqual(names({ query: '7,62 x 51', family: '' }), ['308 Win.']);
  assert.deepEqual(names({ query: '', family: 'belted' }), ['300 Win. Mag.', '7 mm Rem. Mag.']);
  assert.deepEqual(names({ query: 'mag', family: 'pistol' }), ['357 Magnum', '44 Rem. Mag.']);
  assert.equal(names({ query: '', family: 'rimfire' }).length, 3);
  assert.deepEqual(names({ query: 'zzz', family: '' }), []);
  assert.deepEqual(names({ query: 'creed', family: 'rimless' }), ['6,5 Creedmoor']);
  assert.deepEqual(names({ query: '', family: 'rimmed' }), ['9,3 x 74 R', '7 x 65 R']);
});

test('alternativeMatch reports alt names only when the name itself does not match', () => {
  assert.deepEqual(format.alternativeMatch(byKey('308_win'), '7,62 x 51'), ['308 Winchester', '7,62 x 51']);
  assert.equal(format.alternativeMatch(byKey('308_win'), '308 win.'), null);
  assert.equal(format.alternativeMatch(byKey('308_win'), ''), null);
});

test('escapeHtml escapes markup characters', () => {
  assert.equal(format.escapeHtml('<a href="x">&\'</a>'), '&lt;a href=&quot;x&quot;&gt;&amp;&#39;&lt;/a&gt;');
});
