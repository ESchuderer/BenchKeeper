'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');

const records = require('../../js/data.js');
require('../../js/format.js');
require('../../js/mathutil.js');
require('../../js/bullet.js');
const geometry = require('../../js/geometry.js');

const byKey = (key) => records.find((r) => r.key === key);
const build = (key) => geometry.build(byKey(key));
const clone = (value) => JSON.parse(JSON.stringify(value));
const near = (a, b, tol = 1e-3) => Math.abs(a - b) <= tol;
const hasPoint = (points, z, r, tol = 1e-3) => points.some((p) => near(p.z, z, tol) && near(p.r, r, tol));
const distance = (a, b) => Math.hypot(a.z - b.z, a.r - b.r);

function distanceToPolyline(p, pts) {
  let best = Infinity;
  for (let i = 1; i < pts.length; i += 1) {
    const a = pts[i - 1];
    const b = pts[i];
    const dz = b.z - a.z;
    const dr = b.r - a.r;
    const len2 = dz * dz + dr * dr;
    const t = len2 === 0 ? 0 : Math.max(0, Math.min(1, ((p.z - a.z) * dz + (p.r - a.r) * dr) / len2));
    best = Math.min(best, distance(p, { z: a.z + t * dz, r: a.r + t * dr }));
  }
  return best;
}

test('rim type follows family, then R1/P1', () => {
  assert.equal(build('308_win').rimType, 'rimless');
  assert.equal(build('300_win_mag').rimType, 'belted');
  assert.equal(build('22_long_rifle').rimType, 'rimfire');
  assert.equal(build('38_special').rimType, 'rimmed');
  assert.equal(build('9_mm_luger').rimType, 'rimless');
  assert.equal(build('9_3_x_74_r').rimType, 'rimmed');
});

test('rim type thresholds: rimmed at >= 1.05, rebated below 0.98, else rimless', () => {
  const make = (r1, p1) => {
    const rec = clone(byKey('308_win'));
    rec.cartridge.caseHead.R1 = r1;
    rec.cartridge.powderChamber.P1 = p1;
    return geometry.build(rec).rimType;
  };
  assert.equal(make(10.5, 10), 'rimmed');
  assert.equal(make(10.49, 10), 'rimless');
  assert.equal(make(9.8, 10), 'rimless');
  assert.equal(make(9.79, 10), 'rebated');
});

test('head chamfer of 308 Win. runs from (r 5.739, z 0) to (r 6.005, z 0.38) then up to z 1.37', () => {
  const p = build('308_win').profile.points;
  assert.ok(hasPoint(p, 0, 5.739));
  assert.ok(hasPoint(p, 0.38, 6.005));
  assert.ok(hasPoint(p, 1.37, 6.005));
  assert.deepEqual({ z: p[0].z, r: p[0].r }, { z: 0, r: 0 });
});

test('chamfer length is limited to R1/4', () => {
  const rec = clone(byKey('308_win'));
  rec.cartridge.caseHead.f = 20;
  rec.cartridge.caseHead.R = 25;
  rec.cartridge.caseHead.E = 40;
  rec.cartridge.caseHead.eMin = 1;
  const p = geometry.build(rec).profile.points;
  assert.ok(hasPoint(p, 0, 6.005 - 12.01 / 4));
});

test('22 Long Rifle has a half-round rim edge of radius 0.545 reaching r 3.53', () => {
  const g = build('22_long_rifle');
  const p = g.profile.points;
  const maxR = Math.max(...p.filter((q) => q.z < 1.2).map((q) => q.r));
  assert.ok(near(maxR, 3.53, 1e-6));
  const center = { z: 0.545, r: 3.53 - 0.545 };
  const arc = p.filter((q) => q.z > 0.01 && q.z < 1.08 && q.r > center.r + 1e-9);
  assert.ok(arc.length >= 8);
  for (const q of arc) assert.ok(near(distance(q, center), 0.545, 1e-6));
  assert.ok(near(g.rim.edgeRadius, 0.545, 1e-9));
});

test('half-round radius is limited by (R1 - P1)/2', () => {
  const rec = clone(byKey('22_long_rifle'));
  rec.cartridge.caseHead.R1 = 5.9;
  const g = geometry.build(rec);
  assert.ok(near(g.rim.edgeRadius, (5.9 - 5.74) / 2, 1e-9));
  assert.ok(near(Math.max(...g.profile.points.map((q) => q.r)), 2.95, 1e-9));
});

test('a missing beta gives a square corner and is reported', () => {
  const rec = clone(byKey('308_win'));
  delete rec.cartridge.caseHead.beta;
  const g = geometry.build(rec);
  assert.ok(hasPoint(g.profile.points, 0, 6.005));
  assert.ok(g.missing.some((m) => m.values.includes('β')));
  assert.ok(g.notes.some((n) => n.includes('β')));
});

test('extractor groove of 308 Win.', () => {
  const p = build('308_win').profile.points;
  assert.ok(hasPoint(p, 1.37, 5.195));
  assert.ok(hasPoint(p, 2.77, 5.195));
  assert.ok(hasPoint(p, 3.85, 5.98));
});

test('belted 300 Win. Mag. ramps at delta to the belt, follows it to E and steps in', () => {
  const g = build('300_win_mag');
  const p = g.profile.points;
  const rampEndZ = 1.27 + 0.94 + (13.51 / 2 - 12.07 / 2) / Math.tan((35 * Math.PI) / 180);
  assert.ok(hasPoint(p, 1.27 + 0.94, 6.035));
  assert.ok(hasPoint(p, rampEndZ, 6.755));
  assert.ok(hasPoint(p, 5.59, 6.755));
  assert.ok(hasPoint(p, 5.59, 6.515));
  assert.ok(near(g.profile.key.beltRampEnd.z, rampEndZ, 1e-9));
});

test('a case without a groove steps in at z = R (7 x 65 R)', () => {
  const g = build('7_x_65_r');
  assert.ok(hasPoint(g.profile.points, 1.4, 6.66));
  assert.ok(hasPoint(g.profile.points, 1.4, 5.945));
  assert.ok(near(g.profile.key.bodyStart.z, 1.4));
  assert.ok(!g.notes.some((n) => /groove/i.test(n)), 'rimmed case: no groove note');
});

test('rimless case lacking groove values reports them', () => {
  const rec = clone(byKey('308_win'));
  delete rec.cartridge.caseHead.E1;
  const g = geometry.build(rec);
  assert.ok(g.notes.some((n) => /groove/i.test(n) && n.includes('E1')));
  assert.ok(hasPoint(g.profile.points, 1.37, 5.98));
});

test('bottleneck key points of 308 Win.', () => {
  const g = build('308_win');
  const key = g.profile.key;
  assert.deepEqual([key.shoulderStart.z, key.shoulderStart.r], [39.62, 11.53 / 2]);
  assert.deepEqual([key.shoulderEnd.z, key.shoulderEnd.r], [43.48, 4.36]);
  assert.deepEqual([key.mouth.z, key.mouth.r], [51.18, 4.36]);
  const last = g.profile.points[g.profile.points.length - 1];
  assert.deepEqual([last.z, last.r], [51.18, 4.36]);
  assert.ok(hasPoint(g.profile.points, 43.48 + 0, 4.36, 0.5), 'profile reaches the neck');
});

test('shoulder corners are rounded with r1 min and r2 where published', () => {
  const g = build('308_win');
  const pts = g.profile.points;
  const theta = Math.atan((11.53 / 2 - 8.72 / 2) / (43.48 - 39.62)); // shoulder slope to the axis
  assert.ok(near(g.shoulder.halfAngle, theta, 1e-9));
  const bodySlope = Math.atan((11.96 / 2 - 11.53 / 2) / (39.62 - 3.85));
  const turn1 = theta + bodySlope;
  const sagitta1 = 0.76 * (1 / Math.cos(turn1 / 2) - 1);
  assert.ok(near(distanceToPolyline(g.profile.key.shoulderStart, pts), sagitta1, 0.002));
  const sagitta2 = 3.18 * (1 / Math.cos(theta / 2) - 1);
  assert.ok(near(distanceToPolyline(g.profile.key.shoulderEnd, pts), sagitta2, 0.004));
  assert.ok(!pts.some((p) => near(p.z, 39.62, 1e-9) && near(p.r, 11.53 / 2, 1e-9)), 'rounded corner is not a vertex');
});

test('shoulder apex lies on the axis at the extension of the shoulder line', () => {
  const g = build('223_rem');
  assert.ok(near(g.shoulder.apex.z, 47.1, 0.1));
  assert.equal(g.shoulder.apex.r, 0);
});

test('17 HMR has sharp shoulder corners and reports r1 min and r2', () => {
  const g = build('17_hmr');
  assert.ok(hasPoint(g.profile.points, 22.2, 3.075, 1e-9));
  assert.ok(hasPoint(g.profile.points, 23.54, 2.45, 1e-9));
  assert.ok(g.notes.some((n) => n.includes('r1 min') && n.includes('r2')));
});

test('338 Lapua Mag. rounds only the neck-side corner (no r1 min)', () => {
  const g = build('338_lapua_mag');
  assert.ok(hasPoint(g.profile.points, 54.9, 13.82 / 2, 1e-9));
  assert.ok(g.notes.some((n) => n.includes('r1 min')));
  assert.ok(!g.notes.some((n) => n.includes('r2')));
});

test('a case lacking alpha, L1 or L2 is straight and the body runs to (H2/2, L3)', () => {
  const g = build('9_mm_luger');
  assert.equal(g.shoulder, null);
  assert.ok(hasPoint(g.profile.points, 2.98, 4.965));
  assert.ok(hasPoint(g.profile.points, 19.15, 4.825));
  assert.ok(g.notes.some((n) => /straight/i.test(n)));
});

test('a straight case notes only the values it lacks', () => {
  const rec = clone(byKey('308_win'));
  delete rec.cartridge.lengths.L2;
  const g = geometry.build(rec);
  assert.equal(g.shoulder, null);
  assert.ok(g.notes.some((n) => /straight/i.test(n) && n.includes('L2') && !n.includes('L1')));
});

test('missing P2 on a bottleneck case: no shoulder, reported, rest drawn', () => {
  const rec = clone(byKey('308_win'));
  delete rec.cartridge.powderChamber.P2;
  const g = geometry.build(rec);
  assert.equal(g.shoulder, null);
  assert.ok(g.notes.some((n) => n.includes('P2')));
  assert.ok(g.bullet);
  assert.ok(g.profile.points.length > 5);
});

test('bullet seating and cylinder of 308 Win. (pointy)', () => {
  const b = build('308_win').bullet;
  assert.ok(near(b.s, 7.85, 1e-9));
  assert.ok(near(b.zb, 43.33, 1e-9));
  assert.ok(near(b.Lb, 27.79, 1e-9));
  assert.equal(b.k, 0.4);
  assert.ok(near(b.zc, 54.446, 1e-9));
});

test('pointy tangent ogive of 308 Win.', () => {
  const b = build('308_win').bullet;
  assert.ok(near(b.m, 1.27, 1e-12));
  assert.ok(near(b.n, 16.674, 1e-9));
  assert.ok(near(b.rho, 43.9, 0.1));
  const nose = b.visible.filter((p) => p.z >= b.zc - 1e-9);
  const center = { z: b.zc, r: 7.85 / 2 - b.rho };
  const arc = nose.filter((p) => p.z < 71.12 - 1e-9 && p.z > b.zc + 1e-9);
  assert.ok(arc.length > 10);
  for (const p of arc) assert.ok(near(distance(p, center), b.rho, 1e-6));
  assert.ok(hasPoint(nose, b.zc, 7.85 / 2, 1e-9));
  const tip = b.visible[b.visible.length - 2];
  assert.ok(near(tip.z, 71.12, 1e-9) && near(tip.r, 0.635, 1e-6));
  const end = b.visible[b.visible.length - 1];
  assert.deepEqual([end.z, end.r], [71.12, 0]);
});

test('meplat is at least 1.27 for small pointy bullets (17 HMR)', () => {
  const b = build('17_hmr').bullet;
  assert.equal(b.m, 1.27);
  assert.ok(near(b.s, 4.38, 1e-9));
});

test('rounded pistol bullet (9 mm Luger): seating 0.4 G1, k 0.65, quarter ellipse, m 0.15 G1', () => {
  const g = build('9_mm_luger');
  const b = g.bullet;
  assert.ok(near(b.s, 3.612, 1e-9));
  assert.equal(b.k, 0.65);
  assert.ok(near(b.zc, b.zb + 0.65 * b.Lb, 1e-9));
  assert.ok(near(b.m, 1.3545, 1e-9));
  const a = 9.03 / 2 - b.m / 2;
  const mid = b.visible.filter((p) => p.z > b.zc + 1e-9 && p.z < 29.69 - 1e-9);
  assert.ok(mid.length > 8);
  for (const p of mid) {
    const u = (p.z - b.zc) / b.n;
    const v = (p.r - b.m / 2) / a;
    assert.ok(near(u * u + v * v, 1, 1e-9));
  }
});

test('rounded on a rimfire cartridge uses rifle values (22 Win. Mag. R.F.)', () => {
  const b = build('22_win_mag_r_f').bullet;
  assert.ok(near(b.s, 0.8 * 5.7, 1e-9));
  assert.equal(b.k, 0.55);
});

test('flat pistol bullet (40 S.& W.): k 0.70, m 0.55 G1, seating 0.4 G1, straight cone', () => {
  const b = build('40_s_w').bullet;
  assert.equal(b.k, 0.7);
  assert.ok(near(b.m, 0.55 * 10.17, 1e-9));
  assert.ok(near(b.s, 0.4 * 10.17, 1e-9));
  const cone = b.visible.filter((p) => p.z >= b.zc - 1e-9);
  assert.equal(cone.length, 3);
});

test('semi-wadcutter (357 Magnum): s 0.6 G1, k 0.78, m 0.6 G1', () => {
  const b = build('357_magnum').bullet;
  assert.ok(near(b.s, 0.6 * 9.12, 1e-9));
  assert.equal(b.k, 0.78);
  assert.ok(near(b.m, 0.6 * 9.12, 1e-9));
});

test('flat rifle bullet uses k 0.60 and rifle seating', () => {
  const rec = clone(byKey('308_win'));
  rec.annotations.defaultBulletShape = 'flat';
  const b = geometry.build(rec).bullet;
  assert.equal(b.k, 0.6);
  assert.ok(near(b.s, 0.8 * 7.85, 1e-9));
});

test('heeled case (22 Long Rifle): exposed bullet at case OD, seated heel at case ID', () => {
  const g = build('22_long_rifle');
  const b = g.bullet;
  assert.equal(b.heeled, true);
  assert.ok(near(b.d, 5.72, 1e-9));
  assert.ok(near(b.seatD, 4.52, 1e-9));
  assert.ok(near(g.walls.tb, 0.6, 1e-9));
  assert.ok(b.outline.some((p) => near(p.r, 4.52 / 2, 1e-9)));
  assert.ok(b.visible.every((p) => p.r <= 5.72 / 2 + 1e-9));
});

test('a non-heeled case is detected by H2 - G1 > 0.015', () => {
  assert.equal(build('22_win_mag_r_f').bullet.heeled, false);
  assert.equal(build('308_win').bullet.heeled, false);
});

test('the outside view shows only the bullet above the mouth', () => {
  for (const r of records) {
    const g = geometry.build(r);
    if (!g.bullet) continue;
    assert.ok(g.bullet.visible.every((p) => p.z >= r.cartridge.lengths.L3 - 1e-9), r.key);
    assert.ok(g.bullet.outline[0].z < r.cartridge.lengths.L3, r.key);
  }
});

test('wall thicknesses of 308 Win.', () => {
  const w = build('308_win').walls;
  assert.ok(near(w.tn, 0.435, 1e-9));
  assert.ok(near(w.tb, 0.6, 1e-9));
  const last = w.inner[w.inner.length - 1];
  assert.ok(near(last.z, 51.18, 1e-9) && near(last.r, 3.925, 1e-9));
});

test('tb is limited by 0.35 P1/2 and grows with 1.3 tn', () => {
  const rec = clone(byKey('308_win'));
  rec.cartridge.collar.H2 = 7.85 + 2 * 0.8; // tn 0.8 -> 1.04
  rec.cartridge.collar.H1 = rec.cartridge.collar.H2;
  assert.ok(near(geometry.build(rec).walls.tb, 1.04, 1e-9));
  rec.cartridge.powderChamber.P1 = 3; // 0.35 * 1.5 = 0.525
  rec.cartridge.caseHead.R1 = 3.2;
  assert.ok(near(geometry.build(rec).walls.tb, 0.525, 1e-9));
});

test('inner line follows tb on the body, blends across the shoulder, tn on the neck', () => {
  const g = build('308_win');
  const inner = g.walls.inner;
  const at = (z) => {
    for (let i = 1; i < inner.length; i += 1) {
      if (inner[i].z >= z) {
        const a = inner[i - 1];
        const b = inner[i];
        return a.r + ((b.r - a.r) * (z - a.z)) / (b.z - a.z || 1);
      }
    }
    return NaN;
  };
  const bodyR = (z) => 5.98 + ((11.53 / 2 - 5.98) * (z - 3.85)) / (39.62 - 3.85);
  assert.ok(near(at(20), bodyR(20) - 0.6, 1e-3));
  assert.ok(near(at(45), 4.36 - 0.435, 1e-6));
  assert.ok(near(g.walls.inner[0].z, g.walls.w, 1e-9));
  assert.ok(near(g.walls.inner[0].r, 5.98 - 0.6, 0.01), 'body line is slightly tapered');
});

test('straight case: wall is tb up the body and tn where the bullet is seated', () => {
  const g = build('9_mm_luger');
  const last = g.walls.inner[g.walls.inner.length - 1];
  assert.ok(near(last.r, 9.65 / 2 - (9.65 - 9.03) / 2, 1e-9));
  const seat = g.walls.inner.filter((p) => p.z >= g.bullet.zb - 1e-9);
  for (const p of seat) assert.ok(p.r >= 9.03 / 2 - 1e-6 && p.r <= 9.03 / 2 + 0.05, `seat radius ${p.r}`);
});

test('solid head length w', () => {
  assert.ok(near(build('308_win').walls.w, 4.8, 1e-9)); // pocket 3.3 + 1.5
  assert.ok(near(build('223_rem').walls.w, 4.54, 1e-9)); // pocket 3.04 + 1.5 beats E + tb
  assert.ok(near(build('45_auto').walls.w, 4.11 + 0.6, 1e-9)); // E + tb beats pocket
  assert.ok(near(build('300_win_mag').walls.w, 4.8, 1e-9)); // belt ramp end + tb is smaller
  assert.ok(near(build('22_long_rifle').walls.w, 2.5, 1e-9));
});

test('w uses the belt ramp end + tb on belted cases when that is the largest', () => {
  const rec = clone(byKey('300_win_mag'));
  rec.annotations.primerType = 'sp';
  rec.cartridge.caseHead.eMin = 3;
  const g = geometry.build(rec);
  assert.ok(near(g.walls.w, g.profile.key.beltRampEnd.z + 0.6, 1e-9));
});

test('primer pocket by primer type; rimfire has none', () => {
  assert.deepEqual(build('308_win').pocket, { d: 5.33, depth: 3.3 });
  assert.deepEqual(build('223_rem').pocket, { d: 4.45, depth: 3.04 });
  assert.deepEqual(build('45_auto').pocket, { d: 5.33, depth: 3.04 });
  assert.deepEqual(build('357_magnum').pocket, { d: 4.45, depth: 3.04 });
  assert.deepEqual(build('338_lapua_mag').pocket, { d: 5.33, depth: 3.3 });
  assert.equal(build('22_long_rifle').pocket, null);
});

test('unknown primer type: no pocket, reported', () => {
  const rec = clone(byKey('308_win'));
  rec.annotations.primerType = 'xx';
  const g = geometry.build(rec);
  assert.equal(g.pocket, null);
  assert.ok(g.notes.some((n) => /primer/i.test(n)));
});

test('section polygon excludes the primer pocket and spans head to mouth', () => {
  const g = build('308_win');
  const poly = g.section.polygon;
  assert.ok(hasPoint(poly, 3.3, 0));
  assert.ok(hasPoint(poly, 3.3, 5.33 / 2));
  assert.ok(hasPoint(poly, 0, 5.33 / 2));
  assert.ok(hasPoint(poly, g.walls.w, 0));
  assert.ok(hasPoint(poly, 51.18, 4.36));
  assert.ok(hasPoint(poly, 51.18, 3.925));
});

test('missing G1: no bullet and no walls, still an outline, reported', () => {
  const rec = clone(byKey('308_win'));
  delete rec.cartridge.projectile.G1;
  const g = geometry.build(rec);
  assert.equal(g.bullet, null);
  assert.equal(g.walls, null);
  assert.equal(g.section, null);
  assert.ok(g.profile.points.length > 10);
  assert.ok(g.notes.some((n) => n.includes('G1')));
});

test('missing L6: no bullet, reported', () => {
  const rec = clone(byKey('308_win'));
  delete rec.cartridge.lengths.L6;
  const g = geometry.build(rec);
  assert.equal(g.bullet, null);
  assert.ok(g.notes.some((n) => n.includes('L6')));
  assert.ok(g.walls);
});

test('essential values missing: no drawing, says which', () => {
  const rec = clone(byKey('308_win'));
  delete rec.cartridge.lengths.L3;
  const g = geometry.build(rec);
  assert.equal(g.ok, false);
  assert.ok(g.missing.some((m) => m.values.includes('L3')));
});

test('no number is invented: values come from the record', () => {
  const g = build('308_win');
  assert.equal(g.v.L3, 51.18);
  assert.equal(g.v.R1, 12.01);
  assert.equal(g.v.alpha, 40);
});

test('all 25 records build a finite, monotone, consistent geometry', () => {
  for (const r of records) {
    const g = geometry.build(r);
    assert.equal(g.ok, true, r.key);
    const pts = g.profile.points;
    for (const p of pts) assert.ok(Number.isFinite(p.z) && Number.isFinite(p.r) && p.r >= 0, `${r.key} finite`);
    for (let i = 1; i < pts.length; i += 1) {
      assert.ok(pts[i].z >= pts[i - 1].z - 1e-9, `${r.key} z monotone at ${i}: ${pts[i - 1].z} -> ${pts[i].z}`);
    }
    const last = pts[pts.length - 1];
    assert.ok(near(last.z, r.cartridge.lengths.L3, 1e-9) && near(last.r, r.cartridge.collar.H2 / 2, 1e-9), `${r.key} mouth`);
    assert.ok(g.walls && g.section && g.bullet, `${r.key} complete`);
    for (const p of g.walls.inner) assert.ok(Number.isFinite(p.z) && p.r > 0, `${r.key} inner`);
    assert.ok(g.bullet.outline.every((p) => Number.isFinite(p.z) && Number.isFinite(p.r)), `${r.key} bullet`);
    assert.ok(near(g.bullet.visible[g.bullet.visible.length - 1].z, r.cartridge.lengths.L6, 1e-9), `${r.key} tip at L6`);
    assert.ok(g.walls.w > 0 && g.walls.w < r.cartridge.lengths.L3, `${r.key} w`);
  }
});

test('the inner line never crosses the outer profile and the bullet never pokes through the wall by more than rounding', () => {
  for (const r of records) {
    const g = geometry.build(r);
    const outer = g.profile.points;
    const radiusAt = (z) => {
      for (let i = 1; i < outer.length; i += 1) {
        if (outer[i].z >= z && outer[i].z > outer[i - 1].z) {
          const a = outer[i - 1];
          const b = outer[i];
          return a.r + ((b.r - a.r) * (z - a.z)) / (b.z - a.z);
        }
      }
      return outer[outer.length - 1].r;
    };
    for (const p of g.walls.inner) {
      assert.ok(p.r < radiusAt(p.z) - 0.1, `${r.key} inner below outer at z=${p.z}`);
    }
    for (const p of g.bullet.outline) {
      if (p.z < g.walls.w || p.z >= r.cartridge.lengths.L3 - 1e-9) continue; // at the mouth the heel steps out to the case OD
      const innerR = g.walls.inner.reduce((best, q) => (Math.abs(q.z - p.z) < Math.abs(best.z - p.z) ? q : best)).r;
      assert.ok(p.r <= innerR + 0.1, `${r.key} bullet inside wall at z=${p.z}: ${p.r} vs ${innerR}`);
    }
  }
});

test('a degenerate corner (zero-length segment) is not rounded and yields no NaN', () => {
  const rec = clone(byKey('308_win'));
  rec.cartridge.lengths.L2 = rec.cartridge.lengths.L3; // neck of zero length
  rec.cartridge.collar.H1 = rec.cartridge.collar.H2;
  const g = geometry.build(rec);
  assert.ok(g.profile.points.every((p) => Number.isFinite(p.z) && Number.isFinite(p.r)));
});

test('belted case without R3 and delta draws the plain groove and says what is missing', () => {
  const rec = clone(byKey('300_win_mag'));
  delete rec.cartridge.caseHead.R3;
  const g = geometry.build(rec);
  assert.equal(g.profile.key.beltRampEnd, null);
  assert.ok(g.notes.some((n) => n.startsWith('Belt') && n.includes('R3')));
  assert.ok(g.profile.points.every((p) => Number.isFinite(p.z) && Number.isFinite(p.r)));
});

test('a bullet whose cylinder is entirely seated starts its visible part at the mouth', () => {
  const rec = clone(byKey('308_win'));
  rec.cartridge.lengths.L6 = 51.18 + 3;
  const g = geometry.build(rec);
  assert.ok(g.bullet.zc < 51.18);
  const vis = g.bullet.visible;
  assert.ok(near(vis[0].z, 51.18, 1e-9));
  assert.ok(vis[0].r < 7.85 / 2 && vis[0].r > 0);
  for (let i = 1; i < vis.length; i += 1) assert.ok(vis[i].z >= vis[i - 1].z - 1e-9);
});

test('a bullet thinner than its meplat is reported, not drawn as NaN', () => {
  const rec = clone(byKey('17_hmr'));
  rec.cartridge.projectile.G1 = 1.0;
  rec.cartridge.collar.H2 = 1.2;
  rec.cartridge.collar.H1 = 1.2;
  const g = geometry.build(rec);
  assert.equal(g.bullet, null);
  assert.ok(g.notes.some((n) => n.startsWith('Bullet')));
});

test('wall thickness is computed in one place: bullet heel and walls agree', () => {
  const g = build('22_long_rifle');
  assert.ok(near(g.bullet.seatD, 5.72 - 2 * g.walls.tb, 1e-9));
});
