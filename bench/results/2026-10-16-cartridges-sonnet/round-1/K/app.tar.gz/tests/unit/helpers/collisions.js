'use strict';
// Test oracle: independent re-check of a dimension layout (labels vs outline, lines, title block, view box).
// Kept out of the shipped code; the e2e tests repeat the same checks with real text boxes in Chromium.
const dimensions = require('../../../js/dimensions.js');

const COLLISION_PAD = 0.3;
const line = (cls, x1, y1, x2, y2) => ({ cls, x1, y1, x2, y2 });
const rectsTouch = (a, b, pad) => a.x0 < b.x1 + pad && b.x0 < a.x1 + pad && a.y0 < b.y1 + pad && b.y0 < a.y1 + pad;
const { segmentHitsRect } = dimensions;

function outlineSegments(g) {
  const segs = [];
  const path = (pts, sign) => {
    for (let i = 1; i < pts.length; i += 1) segs.push(line('outline', pts[i - 1].z, sign * pts[i - 1].r, pts[i].z, sign * pts[i].r));
  };
  const pts = g.profile.points;
  path(pts, -1);
  path(pts, 1);
  if (g.bullet) {
    path(g.bullet.visible, -1);
    path(g.bullet.outline, 1);
    const mouth = pts[pts.length - 1];
    const bulletR = g.bullet.visible[0].r;
    segs.push(line('outline', mouth.z, -mouth.r, mouth.z, -bulletR), line('outline', mouth.z, mouth.r, mouth.z, bulletR));
  }
  return segs;
}

function findCollisions(g, lay) {
  const problems = [];
  const vb = lay.viewBox;
  const outline = outlineSegments(g);
  const lines = lay.items.flatMap((i) => i.lines.map((l) => ({ id: i.id, ...l })));
  for (const item of lay.items) {
    const rect = item.label.rect;
    if (rect.x0 < vb.x || rect.y0 < vb.y || rect.x1 > vb.x + vb.w || rect.y1 > vb.y + vb.h) problems.push(`${item.id} label outside the view box`);
    if (rectsTouch(rect, lay.title.rect, COLLISION_PAD)) problems.push(`${item.id} label overlaps the title block`);
    if (outline.some((s) => segmentHitsRect(s, rect, COLLISION_PAD))) problems.push(`${item.id} label overlaps the outline`);
    for (const l of lines) if (segmentHitsRect(l, rect, COLLISION_PAD)) problems.push(`${item.id} label overlaps a ${l.cls} of ${l.id}`);
    for (const other of lay.items) {
      if (other !== item && rectsTouch(rect, other.label.rect, COLLISION_PAD)) problems.push(`${item.id} label overlaps ${other.id} label`);
    }
  }
  return problems;
}


module.exports = { findCollisions };
