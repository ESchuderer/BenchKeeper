'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const M = require('../../js/mathutil.js');

test('toDegrees accepts numbers and degree/minute/second objects', () => {
  assert.equal(M.toDegrees(40), 40);
  assert.ok(Math.abs(M.toDegrees({ degrees: 39, minutes: 59, seconds: 49 }) - 39.99694444) < 1e-6);
});

test('fillet returns null for a straight line, zero-length segments and non-positive radius', () => {
  const a = M.pt(0, 0);
  assert.equal(M.fillet(a, M.pt(1, 0), M.pt(2, 0), 1), null);
  assert.equal(M.fillet(a, a, M.pt(2, 1), 1), null);
  assert.equal(M.fillet(a, M.pt(1, 0), M.pt(1, 0), 1), null);
  assert.equal(M.fillet(a, M.pt(1, 0), M.pt(2, 1), 0), null);
});

test('fillet is tangent to both segments and limited by the segment length', () => {
  const f = M.fillet(M.pt(0, 0), M.pt(10, 0), M.pt(20, 10), 2);
  assert.ok(Math.abs(f.tangent - 2 * Math.tan(Math.PI / 8)) < 1e-9);
  assert.ok(Math.abs(M.dist(f.start, M.pt(10, 0)) - f.tangent) < 1e-9);
  const tight = M.fillet(M.pt(0, 0), M.pt(10, 0), M.pt(11, 1), 50, 0.45);
  assert.ok(tight.tangent <= 0.45 * Math.SQRT2 + 1e-9);
});

test('radiusAt interpolates and takes the last segment at a vertical step', () => {
  const poly = [M.pt(0, 1), M.pt(2, 3), M.pt(2, 5), M.pt(4, 5)];
  assert.equal(M.radiusAt(poly, 1), 2);
  assert.equal(M.radiusAt(poly, 3), 5);
  assert.equal(M.radiusAt(poly, -1), 1);
  assert.equal(M.radiusAt(poly, 9), 5);
});

test('clipFromZ starts exactly at zMin and keeps later points', () => {
  const poly = [M.pt(0, 4), M.pt(10, 0)];
  const clipped = M.clipFromZ(poly, 5);
  assert.deepEqual(clipped[0], M.pt(5, 2));
  assert.deepEqual(clipped[clipped.length - 1], M.pt(10, 0));
  assert.deepEqual(M.clipFromZ(poly, 0), poly);
  assert.deepEqual(M.clipFromZ(poly, 11), []);
});

test('dedupe drops consecutive duplicates only', () => {
  const p = M.pt(1, 1);
  assert.equal(M.dedupe([p, p, M.pt(2, 2), p]).length, 3);
});
