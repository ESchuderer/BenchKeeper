'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const router = require('../../js/router.js');

test('empty hash and #/ are the list', () => {
  assert.deepEqual(router.parseHash(''), { view: 'list' });
  assert.deepEqual(router.parseHash('#'), { view: 'list' });
  assert.deepEqual(router.parseHash('#/'), { view: 'list' });
});

test('#/cartridge/<key> is a detail view', () => {
  assert.deepEqual(router.parseHash('#/cartridge/308_win'), { view: 'detail', key: '308_win' });
  assert.deepEqual(router.parseHash('#/cartridge/6_5_creedmoor/'), { view: 'detail', key: '6_5_creedmoor' });
});

test('keys are decoded safely and never trusted', () => {
  assert.deepEqual(router.parseHash('#/cartridge/%3Cb%3E'), { view: 'detail', key: '<b>' });
  assert.deepEqual(router.parseHash('#/cartridge/%E0%A4%A'), { view: 'detail', key: '%E0%A4%A' });
  assert.deepEqual(router.parseHash('#/cartridge/'), { view: 'detail', key: '' });
});

test('other fragments fall back to the list', () => {
  assert.deepEqual(router.parseHash('#/nonsense'), { view: 'list' });
  assert.deepEqual(router.parseHash('#top'), { view: 'list' });
});

test('hrefFor builds the detail address', () => {
  assert.equal(router.hrefFor('308_win'), '#/cartridge/308_win');
  assert.equal(router.hrefFor('a b'), '#/cartridge/a%20b');
  assert.equal(router.LIST_HREF, '#/');
});
