# Spec: C.I.P. cartridge database

Source of truth: the project brief (25 OpenBallistics records, list + detail + SVG drawing + print). This file records only the decisions the brief leaves open.

## Commands
- Unit tests: `npm test` (node:test, no dependencies)
- Browser tests: `npm run test:e2e` (Playwright, dev dependency only)
- Run: open `index.html` directly, or serve the folder with any static server

## Structure
- `index.html`, `style.css`: shell and styles
- `data.js`: the 25 records, unchanged
- `model.js`: formatting (angles, tolerance, symbols, units), table sections, search
- `drawing.js`: geometry rules 1-9 and SVG layout, pure functions
- `app.js`: hash router, list, detail, print
- `test/`: unit tests; `e2e/`: browser tests

All scripts are classic scripts sharing `globalThis.CIP` (ES modules do not load from `file://`).

## Decisions
- Route: `#/cartridge/<key>`; works on `file://` and survives reload.
- Number display: `String(value)` (published `25.0` shows `25`). Tolerance is shown after the value as published (`39.62 -0.2`); the `Tol` field has no row.
- Angle: number `40°`; object `39°59'49"` (all three parts, as published). Unit column for angles: `°`. `N` has an empty unit.
- Search: case-insensitive, whitespace ignored, over `name` and `alternativeNames`.
- Count text: always `<n> cartridges`.
- Water capacity: `<grH2O> gr H2O`, link text is the source name, `url` is the target.
- Drawing coordinates: `x = z`, `y = -r` (outside view, up) and `y = +r` (section, down), 1 unit = 1 mm.
- Heeled case (`H2 - G1 <= 0.015`): neck wall `tn` is set to `tb`, because `tn = 0` removes the wall that the seated heel (`H2 - 2·tb`) must sit in.
- Straight case: wall blends linearly from `tb` at the body start to `tn` at the mouth.
- Dimensions: lengths from the head face stacked above the part; diameters as vertical chords with leaders stacked below the part; α as a leader to the shoulder surface. Labels are placed by construction and checked by tests.
- Missing value a rule needs: feature skipped, reason listed under the drawing (`Drawing notes`). Exception: R, R1, P1, H2, L3, L6, G1 or the bullet shape missing means no drawing, because all geometry depends on them.

## Success criteria
- Every listed behavior in the brief is covered by a unit or browser test.
- For all 25 records: drawing renders, labels do not overlap each other or the outline, no network request, works from `file://`.
- Print: one A4 portrait page for all 25 records.

## Plan
1. Tests + `model.js` (formatting, sections, search)
2. Tests + `drawing.js` geometry (profile, bullet, section)
3. Tests + `drawing.js` dimensions, title block, SVG
4. `index.html`, `style.css`, `app.js` (list, detail, routing, print)
5. Browser tests, visual checks at phone and desktop, print to PDF
6. Review
