(function () {
  const { cartridges, model: M, drawing: D } = globalThis.CIP;
  const $ = (s) => document.querySelector(s);
  const esc = M.esc;
  const listView = $('#list-view');
  const detailView = $('#detail-view');
  const search = $('#search');
  const family = $('#family');
  let listScroll = 0;

  $('#list tbody').innerHTML = cartridges
    .map((r) => `<tr><td><a href="#/cartridge/${encodeURIComponent(r.key)}">${esc(r.name)}</a></td><td>${esc(r.family)}</td><td class="num">${M.formatNumber(r.cartridge.lengths.L3)} mm</td></tr>`)
    .join('');
  const rows = [...document.querySelectorAll('#list tbody tr')];

  function filter() {
    let n = 0;
    cartridges.forEach((r, i) => {
      const show = M.matches(r, search.value, family.value);
      rows[i].hidden = !show;
      n += show;
    });
    $('#count').textContent = `${n} cartridges`;
    $('#empty').hidden = n > 0;
  }
  search.addEventListener('input', filter);
  family.addEventListener('change', filter);
  filter();

  const table = (s) =>
    `<table><caption>${esc(s.title)}</caption><thead><tr><th scope="col">Symbol</th><th scope="col" class="num">Value</th><th scope="col">Unit</th></tr></thead><tbody>` +
    s.rows.map((r) => `<tr><th scope="row">${esc(r.symbol)}</th><td class="num">${esc(r.value)}${r.tol ? ` <span class="tol">${esc(r.tol)}</span>` : ''}</td><td>${esc(r.unit)}</td></tr>`).join('') +
    '</tbody></table>';

  function detail(rec) {
    const cap = M.capacity(rec);
    const a = rec.annotations;
    const meta = [
      ['Alternative names', (rec.alternativeNames || []).map(esc).join(', ') || 'none'],
      ['Family', esc(rec.family)],
      ['Category', esc(a.category)],
      ['Primer type', esc(a.primerType)],
      ['C.I.P. table', esc(rec.tab)],
      ['Country', esc(rec.country)],
      ['Published', esc(rec.published)],
      ['Revised', esc(rec.revised)],
      ['Pressure method', esc(rec.pressureMethod)],
      [
        'Water capacity',
        cap
          ? `${esc(cap.text)} (<a href="${esc(cap.url)}" rel="noopener noreferrer">${esc(cap.source)}</a>)${cap.note ? ` <span class="note">${esc(cap.note)}</span>` : ''}`
          : 'not published',
      ],
    ];
    const art = D.render(rec);
    const part = (title, key) => `<h2>${title}</h2><div class="tables">${M.sections(rec, key).map(table).join('')}</div>`;
    return (
      `<nav class="toolbar"><a href="#/">All cartridges</a><button type="button" id="print">Print</button></nav>` +
      `<h1 tabindex="-1">${esc(rec.name)}</h1>` +
      `<dl class="meta">${meta.map(([k, v]) => `<div><dt>${k}</dt><dd>${v}</dd></div>`).join('')}</dl>` +
      `<figure class="drawing-figure">${art.svg}${art.notes.length ? `<figcaption><ul class="drawing-notes">${art.notes.map((n) => `<li>${esc(n)}</li>`).join('')}</ul></figcaption>` : ''}</figure>` +
      part('Cartridge values', 'cartridge') +
      part('Chamber values', 'chamber') +
      `<footer class="source">Source: C.I.P. TDCC, revised ${esc(rec.revised)}</footer>`
    );
  }

  function route() {
    const m = location.hash.match(/^#\/cartridge\/([^/?#]+)/);
    let key;
    try { key = m && decodeURIComponent(m[1]); } catch { /* malformed address: not found */ }
    const rec = cartridges.find((r) => r.key === key);
    if (!listView.hidden) listScroll = window.scrollY;
    listView.hidden = !!m;
    detailView.hidden = !m;
    if (!m) {
      document.title = 'Cartridges';
      window.scrollTo(0, listScroll);
      $('#list-title').focus({ preventScroll: true });
      return;
    }
    if (rec) {
      detailView.innerHTML = detail(rec);
      $('#print').addEventListener('click', () => window.print());
      document.title = `${rec.name} | Cartridges`;
    } else {
      detailView.innerHTML = '<nav class="toolbar"><a href="#/">All cartridges</a></nav><h1 tabindex="-1">Cartridge not found</h1>';
      document.title = 'Cartridge not found | Cartridges';
    }
    window.scrollTo(0, 0);
    detailView.querySelector('h1').focus({ preventScroll: true });
  }
  window.addEventListener('hashchange', route);
  route();
})();
