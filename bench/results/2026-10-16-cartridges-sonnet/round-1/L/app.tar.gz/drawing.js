// Technical drawing of a cartridge as inline SVG: 1 user unit = 1 mm, x = z along the axis (head on the left),
// y = -r for the outside view (up) and +r for the section (down).
(function (root) {
  const CIP = (root.CIP = root.CIP || {});
  const G = typeof require === 'function' && typeof module === 'object' ? require('./geometry.js') : CIP.geometry;
  const M = typeof require === 'function' && typeof module === 'object' ? require('./model.js') : CIP.model;

  const FS = 2.8; // label font size
  const PITCH = 4.2; // row pitch of the dimension stacks
  const GAP = 3.5; // part to first dimension row
  const ARROW = 1.6;
  const PRINT = { w: 186, h: 100 }; // A4 portrait content box in mm; style.css print rules use the same size

  const num = (v) => +v.toFixed(3);
  const esc = M.esc;
  const textW = (t, fs = FS) => t.length * 0.62 * fs;
  const pathD = (pts, sign) => pts.map(([r, z], i) => `${i ? 'L' : 'M'}${num(z)} ${num(sign * r)}`).join('');

  const STYLE = `
.outline{fill:none;stroke:var(--ink,#111);stroke-width:.3;stroke-linejoin:round}
.fill-case{fill:var(--case,#d9d4c7)}.fill-bullet{fill:var(--bullet,#c8a27a)}
.cut{stroke:none}
.hatch{stroke:var(--ink,#111);stroke-width:.12}.hatch-b{stroke:var(--ink,#111);stroke-width:.1;opacity:.7}
.paper{fill:var(--paper,#fff)}
.centre{fill:none;stroke:var(--ink,#111);stroke-width:.15;stroke-dasharray:6 1.2 1 1.2}
.ext,.dimline{stroke:var(--dim,#1a4f8b);stroke-width:.15;fill:none}
.arrow{fill:var(--dim,#1a4f8b);stroke:none}
.label{fill:var(--ink,#111);font-family:ui-monospace,"SF Mono",Menlo,Consolas,"DejaVu Sans Mono","Liberation Mono",monospace;font-size:${FS}px;font-variant-numeric:tabular-nums}
.tb-frame{fill:none;stroke:var(--ink,#111);stroke-width:.25}
.tb-text{fill:var(--ink,#111);font-family:system-ui,-apple-system,"Segoe UI",Roboto,"Helvetica Neue",Arial,sans-serif;font-size:2.6px}
.tb-name{font-weight:700;font-size:3px}`;

  function arrowD(tx, ty, ux, uy) {
    const bx = tx - ux * ARROW;
    const by = ty - uy * ARROW;
    const px = -uy * 0.5;
    const py = ux * 0.5;
    return `M${num(tx)} ${num(ty)}L${num(bx + px)} ${num(by + py)}L${num(bx - px)} ${num(by - py)}Z`;
  }

  function render(rec) {
    const m = G.buildModel(rec);
    if (!m.ok) return { svg: '', notes: m.notes, labels: [], leaderXs: [], model: m };
    const v = m.v;
    const b = m.bullet;
    const c = rec.cartridge;
    const fmt = M.formatNumber;

    const rmax = Math.max(...m.outer.map((p) => p[0]), b.rx);
    const bounds = { x0: -4, x1: v.L6 + 3, y0: -rmax, y1: rmax };
    const labels = [];
    const grow = (x, y) => {
      bounds.x0 = Math.min(bounds.x0, x); bounds.x1 = Math.max(bounds.x1, x);
      bounds.y0 = Math.min(bounds.y0, y); bounds.y1 = Math.max(bounds.y1, y);
    };
    const line = (cls, x0, y0, x1, y1) => { grow(x0, y0); grow(x1, y1); return `<line class="${cls}" x1="${num(x0)}" y1="${num(y0)}" x2="${num(x1)}" y2="${num(y1)}"/>`; };
    const arrow = (tx, ty, ux, uy) => { grow(tx - ux * ARROW, ty - uy * ARROW); grow(tx, ty); return `<path class="arrow" d="${arrowD(tx, ty, ux, uy)}"/>`; };
    const label = (text, x, y, anchor) => {
      const w = textW(text);
      const x0 = anchor === 'middle' ? x - w / 2 : anchor === 'end' ? x - w : x;
      const rect = { text, x0, x1: x0 + w, y0: y - 0.78 * FS, y1: y + 0.22 * FS };
      labels.push(rect);
      grow(rect.x0, rect.y0); grow(rect.x1, rect.y1);
      return `<text class="label" x="${num(x)}" y="${num(y)}" text-anchor="${anchor}">${esc(text)}</text>`;
    };
    const dimGroup = (id, parts) => `<g class="dim" data-dim="${esc(id)}">${parts.join('')}</g>`;
    const topAt = (z) => Math.max(...m.outer.filter((p) => Math.abs(p[1] - z) < 1e-9).map((p) => p[0]));

    // lengths from the head face, stacked above the part, shortest nearest
    const lengths = [{ id: 'R', z: v.R, top: topAt(v.R) }];
    if (m.shoulder) lengths.push({ id: 'L1', z: v.L1, top: v.P2 / 2 }, { id: 'L2', z: v.L2, top: v.H1 / 2 });
    lengths.push({ id: 'L3', z: v.L3, top: v.H2 / 2 }, { id: 'L6', z: v.L6, top: b.m / 2 });
    const headTop = topAt(0);
    const dims = [];
    lengths.forEach((d, i) => {
      const y = -(rmax + GAP + i * PITCH);
      const text = `${d.id} ${fmt(v[d.id])}`;
      const parts = [
        line('ext', 0, -headTop - 0.8, 0, y - 1.2),
        line('ext', d.z, -d.top - 0.8, d.z, y - 1.2),
      ];
      const short = d.z < 3 * ARROW;
      if (short) {
        parts.push(line('dimline', -ARROW - 1.2, y, d.z + ARROW + 1.2, y), arrow(0, y, 1, 0), arrow(d.z, y, -1, 0));
        parts.push(label(text, d.z + ARROW + 2.2, y - 0.9, 'start'));
      } else {
        parts.push(line('dimline', 0, y, d.z, y), arrow(0, y, -1, 0), arrow(d.z, y, 1, 0));
        parts.push(label(text, d.z / 2, y - 0.9, 'middle'));
      }
      dims.push(dimGroup(d.id, parts));
    });

    // diameters as chords across the part, leaders down to stacked labels
    const rimZ = m.outer.filter((p) => p[0] >= v.R1 / 2 - 1e-9 && p[1] <= v.R + 1e-9).map((p) => p[1]);
    const zG = (v.L3 + b.zc) / 2;
    const zH2 = zG - v.L3 < 1.5 ? zG - 1.5 : v.L3; // short exposed shank: H2 chord moves onto the neck
    const lengthXs = lengths.map((d) => d.z);
    const items = [{ id: 'R1', x: Math.min(...rimZ) + 0.25 * (Math.max(...rimZ) - Math.min(...rimZ)), r: v.R1 / 2, text: `R1 ${fmt(v.R1)}` }];
    if (m.groove) items.push({ id: 'E1', x: v.R + 0.75 * v.eMin, r: v.E1 / 2, text: `E1 ${fmt(v.E1)}` });
    items.push({ id: 'P1', x: m.zBodyStart + 0.8, r: v.P1 / 2, text: `P1 ${fmt(v.P1)}` });
    if (m.shoulder) {
      const slide = v.L2 - v.L1 < 3 ? 1 : 0; // short shoulder: P2 and H1 chords move onto the nearly cylindrical body and neck
      const alphaText = `α ${M.formatAngle(c.junctionCone.alpha)}`;
      items.push(
        { id: 'P2', x: v.L1 - slide, r: v.P2 / 2, text: `P2 ${fmt(v.P2)}` },
        { id: 'α', x: (v.L1 + v.L2) / 2, r: (v.P2 + v.H1) / 4, text: alphaText, leader: true },
        { id: 'H1', x: v.L2 + slide, r: v.H1 / 2, text: `H1 ${fmt(v.H1)}` },
      );
    }
    items.push({ id: 'H2', x: zH2, r: v.H2 / 2, text: `H2 ${fmt(v.H2)}` }, { id: 'G1', x: zG, r: b.rx, text: `G1 ${fmt(v.G1)}` });
    items.sort((p, q) => p.x - q.x);

    items.forEach((it) => { it.w = textW(it.text); });
    const placed = [];
    for (const it of items) {
      for (let row = 0; ; row++) {
        const lo = it.x - 1 - it.w;
        const hi = it.x;
        const free = placed.every((p) => {
          const plo = p.x - 1 - p.w;
          if (p.row === row) return lo >= p.x + 1 || hi <= plo - 1;
          if (p.row < row) return it.x < plo - 0.6 || it.x > p.x + 0.6;
          return p.x < lo - 0.6 || p.x > hi + 0.6;
        });
        if (free) { it.row = row; placed.push(it); break; }
      }
    }
    for (const it of items) {
      const y = rmax + GAP + it.row * PITCH;
      const parts = [];
      if (it.leader) {
        parts.push(line('ext', it.x, it.r, it.x, y), arrow(it.x, it.r, 0, -1));
      } else {
        if (!lengthXs.some((z) => Math.abs(z - it.x) < 1e-9)) parts.push(line('ext', it.x, -it.r, it.x, -it.r - 2));
        parts.push(line('ext', it.x, it.r, it.x, y), line('dimline', it.x, -it.r, it.x, it.r), arrow(it.x, -it.r, 0, -1), arrow(it.x, it.r, 0, 1));
      }
      parts.push(label(it.text, it.x - 1, y + 0.35 * FS, 'end'));
      dims.push(dimGroup(it.id, parts));
    }

    // title block below everything
    const tbLines = [rec.name, `C.I.P. table ${rec.tab}, revised ${rec.revised}`, 'Dimensions in mm', 'Scale 0.00:1 on A4'];
    const tbW = Math.max(...tbLines.map((t) => textW(t, 2.6))) + 4;
    const tbH = 4 * 3.6 + 1.6;
    const vx0 = bounds.x0 - 2;
    const vx1 = Math.max(bounds.x1 + 2, vx0 + tbW + 4);
    const tbY = bounds.y1 + 3;
    const vy1 = tbY + tbH + 2;
    const vy0 = bounds.y0 - 2;
    const W = vx1 - vx0;
    const H = vy1 - vy0;
    const scale = Math.floor(Math.min(PRINT.w / W, PRINT.h / H) * 100) / 100;
    tbLines[3] = `Scale ${scale}:1 on A4`;
    const tbX = vx1 - 2 - tbW;
    const tb = [`<rect class="tb-frame" x="${num(tbX)}" y="${num(tbY)}" width="${num(tbW)}" height="${num(tbH)}"/>`];
    tbLines.forEach((t, i) => tb.push(`<text class="tb-text${i ? '' : ' tb-name'}" x="${num(tbX + 2)}" y="${num(tbY + 3.6 * (i + 1) - 0.4)}">${esc(t)}</text>`));

    const bulletOut = [[0, v.L3], ...b.exposed, [0, v.L6]];
    const upper = [...m.outer, ...b.exposed, [0, v.L6]];
    const defs =
      '<defs><pattern id="hatch-case" width="0.9" height="0.9" patternUnits="userSpaceOnUse" patternTransform="rotate(45)"><rect class="paper" width="0.9" height="0.9"/><line class="hatch" x1="0" y1="0" x2="0" y2="0.9"/></pattern>' +
      '<pattern id="hatch-bullet" width="1.2" height="1.2" patternUnits="userSpaceOnUse" patternTransform="rotate(-45)"><rect class="paper" width="1.2" height="1.2"/><line class="hatch-b" x1="0" y1="0" x2="0" y2="1.2"/></pattern></defs>';
    const part = [
      `<path class="fill-case cut" d="${pathD(m.caseOutside, -1)}Z"/>`,
      `<path class="fill-bullet cut" d="${pathD(bulletOut, -1)}Z"/>`,
      `<path class="cut" fill="url(#hatch-case)" d="${pathD(m.caseSection, 1)}Z"/>`,
      `<path class="cut" fill="url(#hatch-bullet)" d="${pathD(b.section, 1)}Z"/>`,
      `<path class="outline" d="${pathD(upper, -1)}"/>`,
      `<path class="outline" d="${pathD(m.caseSection, 1)}"/>`,
      `<path class="outline" d="${pathD(b.section, 1)}"/>`,
      `<line class="centre" x1="-3" y1="0" x2="${num(v.L6 + 3)}" y2="0"/>`,
    ];
    const svg =
      `<svg xmlns="http://www.w3.org/2000/svg" class="drawing" role="img" aria-label="${esc(rec.name)} drawing" viewBox="${num(vx0)} ${num(vy0)} ${num(W)} ${num(H)}" preserveAspectRatio="xMidYMid meet">` +
      `<style>${STYLE}</style>${defs}<g class="part">${part.join('')}</g><g class="dims">${dims.join('')}</g><g class="titleblock">${tb.join('')}</g></svg>`;

    return {
      svg, notes: m.notes, labels, model: m, scale,
      viewBox: { x: vx0, y: vy0, w: W, h: H },
      leaderXs: items.map((i) => i.x),
    };
  }

  CIP.drawing = { render };
  if (typeof module === 'object') module.exports = CIP.drawing;
})(globalThis);
