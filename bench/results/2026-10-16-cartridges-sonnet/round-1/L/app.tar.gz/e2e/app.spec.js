const { test, expect } = require('@playwright/test');
const data = require('../data.js');

const detail = (key) => `#/cartridge/${key}`;

test.describe('start page', () => {
  test('lists every cartridge with name, family and L3', async ({ page }) => {
    await page.goto('');
    await expect(page.getByRole('heading', { name: 'Cartridges', level: 1 })).toBeVisible();
    await expect(page.getByText('25 cartridges', { exact: true })).toBeVisible();
    const rows = page.locator('#list tbody tr');
    await expect(rows).toHaveCount(25);
    const luger = rows.filter({ has: page.getByRole('link', { name: '9 mm Luger', exact: true }) });
    await expect(luger).toContainText('pistol');
    await expect(luger).toContainText('19.15 mm');
    for (const rec of data) await expect(page.getByRole('link', { name: rec.name, exact: true })).toHaveCount(1);
  });

  test('search filters by name and alternative names as the user types', async ({ page }) => {
    await page.goto('');
    const search = page.getByLabel('Search');
    await search.pressSequentially('7,62 x 51');
    await expect(page.getByRole('link', { name: '308 Win.', exact: true })).toBeVisible();
    await expect(page.locator('#list tbody tr:visible')).toHaveCount(1);
    await expect(page.getByText('1 cartridges', { exact: true })).toBeVisible();
    await search.fill('7,62');
    await expect(page.locator('#list tbody tr:visible')).toHaveCount(3); // 308 Win., 30-06 Spring. (7,62 x 63), 7,62 x 39
    await search.fill('zzz');
    await expect(page.getByText('0 cartridges', { exact: true })).toBeVisible();
    await search.fill('');
    await expect(page.getByText('25 cartridges', { exact: true })).toBeVisible();
  });

  test('family select filters and combines with search', async ({ page }) => {
    await page.goto('');
    const family = page.getByLabel('Family');
    await expect(family.locator('option')).toHaveText(['All', 'rimless', 'rimmed', 'belted', 'pistol', 'rimfire']);
    await family.selectOption('pistol');
    await expect(page.getByText('6 cartridges', { exact: true })).toBeVisible();
    await page.getByLabel('Search').fill('mag');
    await expect(page.getByText('2 cartridges', { exact: true })).toBeVisible();
    await expect(page.getByRole('link', { name: '44 Rem. Mag.' })).toBeVisible();
    await family.selectOption('');
    await expect(page.getByText('6 cartridges', { exact: true })).toBeVisible();
  });

  test('filters survive a trip to a detail view and back', async ({ page }) => {
    await page.goto('');
    await page.getByLabel('Search').fill('win');
    await page.getByRole('link', { name: '243 Win.', exact: true }).click();
    await expect(page.getByRole('heading', { name: '243 Win.', level: 1 })).toBeVisible();
    await page.getByRole('link', { name: 'All cartridges' }).click();
    await expect(page.getByLabel('Search')).toHaveValue('win');
    await expect(page.getByRole('heading', { name: 'Cartridges', level: 1 })).toBeVisible();
  });
});

test.describe('detail view', () => {
  test('shows the header facts, capacity with source link, tables and nav', async ({ page }) => {
    await page.goto('');
    await page.getByRole('link', { name: '308 Win.', exact: true }).click();
    await expect(page.getByRole('heading', { name: '308 Win.', level: 1 })).toBeVisible();
    const meta = page.locator('dl.meta');
    for (const t of ['308 Winchester, 7,62 x 51', 'rimless', 'rifle', 'lr', 'US', '1984-06-14', '2008-09-23', 'Transducer', '56 gr H2O'])
      await expect(meta).toContainText(t);
    await expect(meta.getByRole('link', { name: 'kwk' })).toHaveAttribute('href', 'http://kwk.us/cases.html');
    await expect(page.getByRole('button', { name: 'Print' })).toBeVisible();
    await expect(page.getByRole('link', { name: 'All cartridges' })).toBeVisible();
    const lengths = page.getByRole('table', { name: 'Lengths' }).first();
    await expect(lengths.getByRole('columnheader')).toHaveText(['Symbol', 'Value', 'Unit']);
    const l1 = lengths.getByRole('row').filter({ hasText: /^L1/ });
    await expect(l1).toHaveText(/L1\s*39\.62 -0\.2\s*mm/);
    await expect(page.getByRole('cell', { name: /Tol/ })).toHaveCount(0);
    await expect(page.getByRole('rowheader', { name: /Tol$/ })).toHaveCount(0);
    await expect(page.getByRole('rowheader', { name: 'e min' })).toHaveCount(1);
    await expect(page.getByRole('row', { name: /^Pmax 4150 bar/ })).toHaveCount(1);
    await expect(page.getByRole('row', { name: /^i 1°45'0" °/ })).toHaveCount(1);
    await expect(page.getByRole('heading', { name: 'Cartridge values' })).toBeVisible();
    await expect(page.getByRole('heading', { name: 'Chamber values' })).toBeVisible();
    await expect(page.getByText('Source: C.I.P. TDCC, revised 2008-09-23')).toBeVisible();
  });

  test('its address survives a reload and works as a bookmark', async ({ page }) => {
    await page.goto(detail('6_5_creedmoor'));
    await expect(page.getByRole('heading', { name: '6,5 Creedmoor', level: 1 })).toBeVisible();
    await page.reload();
    await expect(page.getByRole('heading', { name: '6,5 Creedmoor', level: 1 })).toBeVisible();
    expect(page.url()).toContain('#/cartridge/6_5_creedmoor');
    await page.goBack().catch(() => {});
  });

  test('Print opens the print dialog', async ({ page }) => {
    await page.goto(detail('308_win'));
    await page.evaluate(() => { window.__printed = 0; window.print = () => { window.__printed++; }; });
    await page.getByRole('button', { name: 'Print' }).click();
    expect(await page.evaluate(() => window.__printed)).toBe(1);
  });

  test('unknown key says so and links back', async ({ page }) => {
    await page.goto(detail('nope'));
    await expect(page.getByRole('heading', { name: 'Cartridge not found' })).toBeVisible();
    await page.getByRole('link', { name: 'All cartridges' }).click();
    await expect(page.getByRole('heading', { name: 'Cartridges', level: 1 })).toBeVisible();
  });

  test('a malformed address shows the not-found view', async ({ page }) => {
    await page.goto('#/cartridge/%E0%A4%A');
    await expect(page.getByRole('heading', { name: 'Cartridge not found' })).toBeVisible();
  });

  test('focus moves to the heading of the view that opens', async ({ page }) => {
    await page.goto('');
    await page.getByRole('link', { name: '308 Win.', exact: true }).click();
    await expect(page.getByRole('heading', { name: '308 Win.', level: 1 })).toBeFocused();
    await page.getByRole('link', { name: 'All cartridges' }).click();
    await expect(page.getByRole('heading', { name: 'Cartridges', level: 1 })).toBeFocused();
  });

  test('missing values are reported under the drawing', async ({ page }) => {
    await page.goto(detail('338_lapua_mag'));
    await expect(page.locator('.drawing-notes')).toContainText('r1 min');
    await page.goto(detail('223_rem'));
    await expect(page.locator('.drawing-notes')).toHaveCount(0);
  });
});

test.describe('drawing', () => {
  test('has an accessible name and the dimension labels', async ({ page }) => {
    await page.goto(detail('308_win'));
    const svg = page.getByRole('img', { name: '308 Win. drawing' });
    await expect(svg).toBeVisible();
    const text = await svg.locator('text.label').allTextContents();
    for (const s of ['L3 51.18', 'L6 71.12', 'R1 12.01', 'R 1.37', 'P1 11.96', 'P2 11.53', 'H1 8.72', 'H2 8.72', 'G1 7.85', 'L1 39.62', 'L2 43.48', 'E1 10.39', 'α 40°'])
      expect(text).toContain(s);
  });

  test('rendered labels (real fonts) overlap neither each other nor the outline, for all 25 cartridges', async ({ page }) => {
    await page.goto('');
    for (const rec of data) {
      await page.goto(detail(rec.key));
      const problems = await page.evaluate(() => {
        const svg = document.querySelector('svg.drawing');
        const boxes = [...svg.querySelectorAll('text.label')].map((t) => ({ t: t.textContent, b: t.getBBox() }));
        const out = [];
        const hit = (a, b) => a.x < b.x + b.width && b.x < a.x + a.width && a.y < b.y + b.height && b.y < a.y + a.height;
        boxes.forEach((p, i) => boxes.slice(i + 1).forEach((q) => hit(p.b, q.b) && out.push(`${p.t} / ${q.t}`)));
        for (const path of svg.querySelectorAll('path.outline')) {
          const len = path.getTotalLength();
          for (let d = 0; d <= len; d += 0.1) {
            const pt = path.getPointAtLength(d);
            for (const p of boxes) if (pt.x > p.b.x && pt.x < p.b.x + p.b.width && pt.y > p.b.y && pt.y < p.b.y + p.b.height) out.push(`${p.t} on outline`);
          }
        }
        const vb = svg.viewBox.baseVal;
        for (const p of boxes) if (p.b.x < vb.x || p.b.y < vb.y || p.b.x + p.b.width > vb.x + vb.width || p.b.y + p.b.height > vb.y + vb.height) out.push(`${p.t} outside viewBox`);
        return [...new Set(out)];
      });
      expect(problems, rec.key).toEqual([]);
    }
  });

  test('is true to scale: 1 user unit is 1 mm in the geometry', async ({ page }) => {
    await page.goto(detail('308_win'));
    const box = await page.evaluate(() => {
      const outline = document.querySelector('svg.drawing path.outline');
      const b = outline.getBBox();
      return { x: b.x, w: b.width, h: b.height };
    });
    expect(box.x).toBeCloseTo(0, 2);
    expect(box.w).toBeCloseTo(71.12, 2); // L6
    expect(box.h).toBeCloseTo(12.01 / 2, 2); // upper half: R1/2
  });

  test('scales to a phone screen without horizontal scrolling', async ({ page }) => {
    await page.setViewportSize({ width: 360, height: 740 });
    for (const key of ['338_lapua_mag', '22_long_rifle']) {
      await page.goto(detail(key));
      const m = await page.evaluate(() => ({ sw: document.documentElement.scrollWidth, iw: window.innerWidth, w: document.querySelector('svg.drawing').getBoundingClientRect().width }));
      expect(m.sw).toBeLessThanOrEqual(m.iw);
      expect(m.w).toBeGreaterThan(300);
    }
  });
});

test.describe('app', () => {
  test('makes no network request beyond its own files and logs no errors, every detail view', async ({ page, baseURL }) => {
    const requests = [];
    const errors = [];
    page.on('request', (r) => requests.push(r.url()));
    page.on('console', (m) => ['error', 'warning'].includes(m.type()) && errors.push(m.text()));
    page.on('pageerror', (e) => errors.push(String(e)));
    await page.goto('');
    for (const rec of data) await page.goto(detail(rec.key));
    const origin = new URL(baseURL);
    const base = baseURL.replace(/index\.html$/, '');
    for (const u of requests) expect(u.startsWith(base) || u.startsWith('data:'), u).toBe(true);
    expect(requests.some((u) => /^https?:\/\/(?!localhost)/.test(u))).toBe(false);
    expect(origin.protocol === 'file:' || origin.hostname === 'localhost').toBe(true);
    expect(errors).toEqual([]);
  });

  test('follows the system colour scheme', async ({ page }) => {
    await page.goto(detail('308_win'));
    await page.emulateMedia({ colorScheme: 'light' });
    const light = await page.evaluate(() => getComputedStyle(document.body).backgroundColor);
    await page.emulateMedia({ colorScheme: 'dark' });
    const dark = await page.evaluate(() => getComputedStyle(document.body).backgroundColor);
    expect(light).not.toBe(dark);
    expect(dark).toBe('rgb(17, 20, 23)');
  });

  test('uses tabular numbers', async ({ page }) => {
    await page.goto('');
    expect(await page.evaluate(() => getComputedStyle(document.body).fontVariantNumeric)).toContain('tabular-nums');
  });
});

test.describe('print', () => {
  test('is black on white, without navigation, search or buttons', async ({ page }) => {
    await page.goto(detail('308_win'));
    await page.emulateMedia({ media: 'print', colorScheme: 'dark' });
    const s = await page.evaluate(() => {
      const vis = (sel) => [...document.querySelectorAll(sel)].some((e) => e.offsetParent !== null || getComputedStyle(e).position === 'fixed');
      return {
        bg: getComputedStyle(document.body).backgroundColor,
        fg: getComputedStyle(document.body).color,
        link: getComputedStyle(document.querySelector('dl.meta a')).color,
        nav: vis('.toolbar'), button: vis('button'), search: vis('#search'), list: vis('#list'),
      };
    });
    expect(s).toEqual({ bg: 'rgb(255, 255, 255)', fg: 'rgb(0, 0, 0)', link: 'rgb(0, 0, 0)', nav: false, button: false, search: false, list: false });
  });

  test('each detail view is one A4 portrait page (all 25 cartridges)', async ({ page }) => {
    await page.emulateMedia({ media: 'print' });
    for (const rec of data) {
      await page.goto(detail(rec.key));
      const pdf = await page.pdf({ preferCSSPageSize: true });
      const text = pdf.toString('latin1');
      expect((text.match(/\/Type\s*\/Page\b(?!s)/g) || []).length, rec.key).toBe(1);
      const box = text.match(/\/MediaBox\s*\[\s*0\s+0\s+([\d.]+)\s+([\d.]+)\s*\]/);
      expect(Math.round(+box[1])).toBe(595);
      expect(Math.round(+box[2])).toBe(842);
    }
  });

  test('the drawing is full width and legible, with page header and source footer', async ({ page }) => {
    await page.goto(detail('308_win'));
    await page.emulateMedia({ media: 'print' });
    const m = await page.evaluate(() => {
      const svg = document.querySelector('svg.drawing').getBoundingClientRect();
      const main = document.querySelector('#detail-view').getBoundingClientRect();
      const ppm = svg.width / document.querySelector('svg.drawing').viewBox.baseVal.width; // css px per user unit
      const h1 = document.querySelector('#detail-view h1').getBoundingClientRect();
      const foot = document.querySelector('.source').getBoundingClientRect();
      const tables = document.querySelector('.tables').getBoundingClientRect();
      return { full: svg.width / main.width, fontMm: (2.8 * Math.min(svg.width / document.querySelector('svg.drawing').viewBox.baseVal.width, svg.height / document.querySelector('svg.drawing').viewBox.baseVal.height) * 25.4) / 96, h1Top: h1.top, svgTop: svg.top, tablesTop: tables.top, svgBottom: svg.bottom, footTop: foot.top, ppm };
    });
    expect(m.full).toBeGreaterThan(0.99);
    expect(m.fontMm).toBeGreaterThan(2.8); // label font at least 2.8 mm = about 8 pt
    expect(m.h1Top).toBeLessThan(m.svgTop);
    expect(m.svgBottom).toBeLessThanOrEqual(m.tablesTop + 1);
    expect(m.footTop).toBeGreaterThan(m.tablesTop);
  });
});
