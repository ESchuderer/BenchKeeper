// Cartridge outline, section and bullet from a record (brief rules 1-9). Points are [r, z]: radius, distance from the head face.
(function (root) {
  const CIP = (root.CIP = root.CIP || {});
  const M = typeof require === 'function' && typeof module === 'object' ? require('./model.js') : CIP.model;
  const DEG = Math.PI / 180;
  const isNum = (v) => typeof v === 'number' && Number.isFinite(v);
  const toDeg = (a) => (isNum(a) ? a : a && typeof a === 'object' ? a.degrees + a.minutes / 60 + a.seconds / 3600 : undefined);
  const same = (p, q) => Math.abs(p[0] - q[0]) < 1e-9 && Math.abs(p[1] - q[1]) < 1e-9;
  const compact = (pts) => pts.filter((p, i) => !i || !same(p, pts[i - 1]));

  const POCKET_D = { sp: 4.45, spm: 4.45, sr: 4.45, lp: 5.33, lpm: 5.33, lr: 5.33, lrm: 5.33 };
  const POCKET_DEPTH = { sp: 3.04, spm: 3.04, sr: 3.04, lp: 3.04, lpm: 3.04, lr: 3.3, lrm: 3.3 };
  const sym = M.symbolLabel;
  const ARC_STEPS = 16;

  function rimType(rec) {
    if (rec.family === 'belted' || rec.family === 'rimfire') return rec.family;
    const q = rec.cartridge.caseHead.R1 / rec.cartridge.powderChamber.P1;
    return q >= 1.05 ? 'rimmed' : q < 0.98 ? 'rebated' : 'rimless';
  }

  // Round the corner b of the polyline a-b-c with radius rad, as sampled arc points; tangent length is capped at 45% of either side.
  function fillet(a, b, c, rad) {
    const u = [a[0] - b[0], a[1] - b[1]];
    const v = [c[0] - b[0], c[1] - b[1]];
    const lu = Math.hypot(...u);
    const lv = Math.hypot(...v);
    u[0] /= lu; u[1] /= lu; v[0] /= lv; v[1] /= lv;
    const phi = Math.acos(Math.max(-1, Math.min(1, u[0] * v[0] + u[1] * v[1])));
    if (phi > Math.PI - 1e-6) return [b];
    const t = Math.min(rad / Math.tan(phi / 2), 0.45 * lu, 0.45 * lv);
    const r = t * Math.tan(phi / 2);
    const bis = [u[0] + v[0], u[1] + v[1]];
    const lb = Math.hypot(...bis);
    const d = r / Math.sin(phi / 2);
    const cen = [b[0] + (bis[0] / lb) * d, b[1] + (bis[1] / lb) * d];
    const p0 = [b[0] + u[0] * t, b[1] + u[1] * t];
    const p1 = [b[0] + v[0] * t, b[1] + v[1] * t];
    const a0 = Math.atan2(p0[1] - cen[1], p0[0] - cen[0]);
    let da = Math.atan2(p1[1] - cen[1], p1[0] - cen[0]) - a0;
    while (da > Math.PI) da -= 2 * Math.PI;
    while (da < -Math.PI) da += 2 * Math.PI;
    return Array.from({ length: 9 }, (_, i) => [cen[0] + r * Math.cos(a0 + (da * i) / 8), cen[1] + r * Math.sin(a0 + (da * i) / 8)]);
  }

  // Part of a polyline (z non-decreasing) from z0 upward, starting on z0.
  function clipFrom(poly, z0) {
    const out = [];
    poly.forEach(([r, z], i) => {
      if (z < z0) return;
      if (!out.length && i > 0 && z > z0) {
        const [pr, pz] = poly[i - 1];
        out.push([pr + ((r - pr) * (z0 - pz)) / (z - pz), z0]);
      }
      out.push([r, z]);
    });
    return out;
  }

  function nose(shape, rx, m, zc, tip) {
    const n = tip - zc;
    const a = rx - m / 2;
    const pts = [];
    if (shape === 'pointy') {
      const rho = (a * a + n * n) / (2 * a);
      const tmax = Math.asin(Math.min(1, n / rho));
      for (let i = 1; i < ARC_STEPS; i++) {
        const t = (tmax * i) / ARC_STEPS;
        pts.push([rx - rho + rho * Math.cos(t), zc + rho * Math.sin(t)]);
      }
      return { pts, rho };
    }
    if (shape === 'rounded') {
      for (let i = 1; i < ARC_STEPS; i++) {
        const t = ((Math.PI / 2) * i) / ARC_STEPS;
        pts.push([m / 2 + a * Math.cos(t), zc + n * Math.sin(t)]);
      }
    }
    return { pts };
  }

  const NOSE = {
    pointy: { k: () => 0.4, m: (G) => Math.max(0.08 * G, 1.27) },
    rounded: { k: (p) => (p ? 0.65 : 0.55), m: (G) => 0.15 * G },
    flat: { k: (p) => (p ? 0.7 : 0.6), m: (G) => 0.55 * G },
    semi_wadcutter: { k: () => 0.78, m: (G) => 0.6 * G },
  };

  function bulletModel(v, rec, heeled, tb) {
    const shape = rec.annotations.defaultBulletShape;
    const pistol = rec.annotations.category === 'pistol';
    const G = v.G1;
    const s = shape === 'pointy' ? G : shape === 'semi_wadcutter' ? 0.6 * G : (pistol ? 0.4 : 0.8) * G;
    const zb = v.L3 - s;
    const Lb = v.L6 - zb;
    const zc = zb + NOSE[shape].k(pistol) * Lb;
    const m = NOSE[shape].m(G);
    const rx = heeled ? v.H2 / 2 : G / 2;
    const rs = heeled ? (v.H2 - 2 * tb) / 2 : G / 2;
    const nz = nose(shape, rx, m, zc, v.L6);
    const side = [[rx, zb], [rx, zc], ...nz.pts, [m / 2, v.L6]];
    const exposed = compact(clipFrom(side, v.L3));
    const section = compact([[0, zb], [rs, zb], [rs, v.L3], ...exposed, [0, v.L6]]);
    return { shape, s, zb, Lb, zc, m, rho: nz.rho, rx, rs, exposed, section };
  }

  function inputs(rec) {
    const c = rec.cartridge;
    const h = c.caseHead || {};
    const col = c.collar || {};
    const j = c.junctionCone || {};
    const l = c.lengths || {};
    const p = c.powderChamber || {};
    return {
      R: h.R, R1: h.R1, R3: h.R3, E: h.E, E1: h.E1, eMin: h.eMin, f: h.f, beta: toDeg(h.beta), delta: toDeg(h.delta),
      H1: col.H1, H2: col.H2, alpha: toDeg(j.alpha), r1Min: j.r1Min, r2: j.r2,
      L1: l.L1, L2: l.L2, L3: l.L3, L6: l.L6, P1: p.P1, P2: p.P2, G1: (c.projectile || {}).G1,
    };
  }

  const missing = (v, keys) => keys.filter((k) => !isNum(v[k]));

  function buildModel(rec) {
    const v = inputs(rec);
    const notes = [];
    const core = missing(v, ['R', 'R1', 'P1', 'H2', 'L3', 'L6', 'G1']);
    const shape = rec.annotations.defaultBulletShape;
    if (core.length) return { ok: false, notes: [`${core.join(', ')} not published: no drawing.`] };
    if (!NOSE[shape]) return { ok: false, notes: ['Bullet shape not published: no drawing.'] };

    const rim = rimType(rec);
    const rr = v.R1 / 2;
    const pts = [[0, 0]];

    // 2. head face and rim edge
    const lacking = missing(v, ['beta', 'f']);
    if (!lacking.length && v.beta < 90) {
      pts.push([rr - Math.min(v.f * Math.tan(v.beta * DEG), v.R1 / 4), 0], [rr, v.f], [rr, v.R]);
    } else if (rim === 'rimfire') {
      const rho = Math.min(v.R / 2, (v.R1 - v.P1) / 2);
      for (let i = 0; i <= ARC_STEPS; i++) {
        const t = (Math.PI * i) / ARC_STEPS;
        pts.push([rr - rho + rho * Math.sin(t), rho - rho * Math.cos(t)]);
      }
      if (2 * rho < v.R - 1e-9) pts.push([rr - rho, v.R]);
    } else {
      if (lacking.length) notes.push(`${lacking.map(sym).join(', ')} not published: head chamfer not drawn.`);
      pts.push([rr, 0], [rr, v.R]);
    }

    // 3. extractor groove, belt
    let beltRampEnd;
    let groove = false;
    const grooveMissing = missing(v, ['E', 'E1', 'eMin']);
    if (grooveMissing.length === 0) {
      groove = true;
      const floorEnd = v.R + v.eMin;
      pts.push([v.E1 / 2, v.R], [v.E1 / 2, floorEnd]);
      const beltMissing = rim === 'belted' ? missing(v, ['R3', 'delta']) : [];
      if (rim === 'belted' && !beltMissing.length) {
        beltRampEnd = Math.min(floorEnd + (v.R3 / 2 - v.E1 / 2) / Math.tan(v.delta * DEG), v.E);
        pts.push([v.R3 / 2, beltRampEnd], [v.R3 / 2, v.E], [v.P1 / 2, v.E]);
      } else {
        if (beltMissing.length) notes.push(`${beltMissing.map(sym).join(', ')} not published: belt not drawn.`);
        pts.push([v.P1 / 2, v.E]);
      }
    } else {
      if (grooveMissing.length < 3) notes.push(`${grooveMissing.map(sym).join(', ')} not published: extractor groove not drawn.`);
      if (rim === 'belted') notes.push(`${grooveMissing.map(sym).join(', ')} not published: belt not drawn.`);
      pts.push([v.P1 / 2, v.R]);
    }
    const bodyIdx = pts.length - 1;
    const zBodyStart = pts[bodyIdx][1];

    // 4-6. body, shoulder, neck
    const shoulderGiven = ['alpha', 'L1', 'L2'].filter((k) => isNum(v[k]));
    const shoulderLacking = missing(v, ['alpha', 'L1', 'L2', 'P2', 'H1']);
    const shoulder = shoulderLacking.length === 0;
    if (!shoulder && shoulderGiven.length) notes.push(`${shoulderLacking.map(sym).join(', ')} not published: shoulder not drawn, case drawn straight.`);
    const mouth = [v.H2 / 2, v.L3];
    if (shoulder) {
      const prev = pts[bodyIdx];
      const A = [v.P2 / 2, v.L1];
      const B = [v.H1 / 2, v.L2];
      if (isNum(v.r1Min)) pts.push(...fillet(prev, A, B, v.r1Min));
      else { pts.push(A); notes.push('r1 min not published: body-side shoulder corner not rounded.'); }
      if (isNum(v.r2)) pts.push(...fillet(A, B, mouth, v.r2));
      else { pts.push(B); notes.push('r2 not published: neck-side shoulder corner not rounded.'); }
    }
    pts.push(mouth);

    // 8. walls, solid head, pocket
    const heeled = v.H2 - v.G1 <= 0.015;
    let tn = (v.H2 - v.G1) / 2;
    const tb = Math.min(Math.max(1.3 * tn, 0.6), (0.35 * v.P1) / 2);
    if (heeled) tn = tb; // tn = 0 would remove the wall the seated heel (H2 - 2 tb) sits in
    const primer = rec.annotations.primerType;
    let pocket = null;
    if (rim !== 'rimfire') {
      if (POCKET_D[primer]) pocket = { d: POCKET_D[primer], depth: POCKET_DEPTH[primer] };
      else notes.push('Primer type not published: primer pocket not drawn.');
    }
    const w = Math.max(
      2.5,
      (0.25 * v.P1) / 2,
      pocket ? pocket.depth + 1.5 : 0,
      beltRampEnd !== undefined ? beltRampEnd + tb : groove ? v.E + tb : 0,
    );
    const L1 = v.L1;
    const L2 = v.L2;
    const wall = (z) => {
      const [a, b] = shoulder ? [L1, L2] : [zBodyStart, v.L3];
      return tb + (tn - tb) * Math.max(0, Math.min(1, (z - a) / (b - a)));
    };
    const body = pts.slice(bodyIdx);
    const inner = [];
    body.forEach(([r, z], i) => {
      if (z < w) {
        const nx = body[i + 1];
        if (nx && nx[1] > w) inner.push([r + ((nx[0] - r) * (w - z)) / (nx[1] - z) - wall(w), w]);
        return;
      }
      if (!inner.length && z > w) inner.push([r - wall(w), w]);
      inner.push([r - wall(z), z]);
    });

    const bullet = bulletModel(v, rec, heeled, tb);
    const caseSection = [
      ...(pocket ? [[0, pocket.depth], [pocket.d / 2, pocket.depth], [pocket.d / 2, 0]] : [[0, 0]]),
      ...pts.slice(1),
      ...inner.slice().reverse(),
      [0, w],
    ];
    return {
      ok: true, notes, rim, heeled, shoulder, groove, tn, tb, w, pocket, zBodyStart, beltRampEnd,
      outer: pts, inner, caseSection, caseOutside: [...pts, [0, v.L3]], bullet, v,
    };
  }

  CIP.geometry = { rimType, buildModel, fillet, clipFrom };
  if (typeof module === 'object') module.exports = CIP.geometry;
})(globalThis);
