// Formatting, table sections and search. Classic script: shares globalThis.CIP, also loadable from Node tests.
(function (root) {
  const CIP = (root.CIP = root.CIP || {});

  const SYMBOLS = {
    eMin: 'e min', r1Min: 'r1 min', r1Max: 'r1 max', alpha: 'α', alpha1: 'α1', beta: 'β', delta: 'δ',
    deltaL: 'delta L', L3PlusG: 'L3 + G',
  };
  const ANGLES = ['alpha', 'alpha1', 'beta', 'delta', 'i'];
  const UNITS = { Pmax: 'bar', PK: 'bar', PE: 'bar', EE: 'J', M: 'g', Q: 'mm²', N: '' };
  const TITLES = {
    caseHead: 'Case head', collar: 'Collar', junctionCone: 'Junction cone', lengths: 'Lengths', misc: 'Misc',
    powderChamber: 'Powder chamber', pressures: 'Pressures', projectile: 'Projectile', barrel: 'Barrel',
    breech: 'Breech', grooves: 'Grooves', rifling: 'Rifling',
  };

  const esc = (s) => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  const formatNumber = (v) => String(v);
  const formatAngle = (a) =>
    typeof a === 'number' ? `${a}°` : `${a.degrees}°${a.minutes}'${a.seconds}"`;
  const symbolLabel = (field) => SYMBOLS[field] || field;
  const unitOf = (field) => (ANGLES.includes(field) ? '°' : field in UNITS ? UNITS[field] : 'mm');
  const formatValue = (field, v) => (ANGLES.includes(field) ? formatAngle(v) : formatNumber(v));
  const formatTol = (t) => (t > 0 ? `+${t}` : String(t));

  function sections(rec, part) {
    return Object.entries(rec[part])
      .map(([key, fields]) => ({
        title: TITLES[key] || key,
        rows: Object.keys(fields)
          .filter((f) => !f.endsWith('Tol'))
          .map((f) => ({
            symbol: symbolLabel(f),
            value: formatValue(f, fields[f]),
            tol: f + 'Tol' in fields ? formatTol(fields[f + 'Tol']) : '',
            unit: unitOf(f),
          })),
      }))
      .filter((s) => s.rows.length);
  }

  const squash = (s) => s.toLowerCase().replace(/\s+/g, '');
  function matches(rec, query, family) {
    if (family && rec.family !== family) return false;
    const q = squash(query);
    return !q || [rec.name, ...(rec.alternativeNames || [])].some((n) => squash(n).includes(q));
  }

  function capacity(rec) {
    const c = rec.annotations.publishedCapacity;
    return c ? { text: `${formatNumber(c.grH2O)} gr H2O`, source: c.source, url: c.url, note: c.note || '' } : null;
  }

  CIP.model = { esc, formatNumber, formatAngle, formatTol, symbolLabel, unitOf, sections, matches, capacity };
  if (typeof module === 'object') module.exports = CIP.model;
})(globalThis);
