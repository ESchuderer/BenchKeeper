const { defineConfig } = require('@playwright/test');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { pathToFileURL } = require('url');

// Use a locally installed Chromium when the revision Playwright expects is missing.
const cache = path.join(os.homedir(), '.cache', 'ms-playwright');
const local = fs.existsSync(cache)
  ? fs.readdirSync(cache).filter((d) => /^chromium-\d+$/.test(d)).map((d) => path.join(cache, d, 'chrome-linux64', 'chrome')).find((f) => fs.existsSync(f))
  : undefined;

module.exports = defineConfig({
  testDir: 'e2e',
  reporter: 'list',
  use: { chromiumSandbox: false, launchOptions: local ? { executablePath: local } : {} },
  webServer: { command: 'node e2e/serve.js', url: 'http://localhost:4173/index.html', reuseExistingServer: true },
  projects: [
    { name: 'file', use: { baseURL: pathToFileURL(path.join(__dirname, 'index.html')).href } },
    { name: 'http', use: { baseURL: 'http://localhost:4173/index.html' } },
  ],
});
