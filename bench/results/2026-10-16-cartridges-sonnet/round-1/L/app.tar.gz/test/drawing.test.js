const { test } = require('node:test');
const assert = require('node:assert/strict');
const data = require('../data.js');
const D = require('../drawing.js');

const byKey = (k) => data.find((r) => r.key === k);
const texts = (res) => res.labels.map((l) => l.text);

// Outline segments in SVG coordinates (x = z, y = -r above the axis, +r below).
function outlineSegments(m) {
  const segs = [];
  const add = (pts) => {
    for (const sign of [-1, 1]) for (let i = 1; i < pts.length; i++) segs.push([pts[i - 1][1], sign * pts[i - 1][0], pts[i][1], sign * pts[i][0]]);
  };
  add(m.outer);
  add(m.bullet.exposed);
  add(m.inner);
  add(m.bullet.section);
  return segs;
}
const inter = (a, b) => a.x0 < b.x1 && b.x0 < a.x1 && a.y0 < b.y1 && b.y0 < a.y1;
function segHitsRect(s, r) {
  // sample the segment; fine enough for 0.05 mm
  const n = Math.max(2, Math.ceil(Math.hypot(s[2] - s[0], s[3] - s[1]) / 0.05));
  for (let i = 0; i <= n; i++) {
    const x = s[0] + ((s[2] - s[0]) * i) / n;
    const y = s[1] + ((s[3] - s[1]) * i) / n;
    if (x > r.x0 && x < r.x1 && y > r.y0 && y < r.y1) return true;
  }
  return false;
}
function inside(poly, x, y) {
  let c = false;
  for (let i = 0, j = poly.length - 1; i < poly.length; j = i++) {
    const [xi, yi] = poly[i];
    const [xj, yj] = poly[j];
    if (yi > y !== yj > y && x < ((xj - xi) * (y - yi)) / (yj - yi) + xi) c = !c;
  }
  return c;
}

test('308 Win.: the dimension labels carry symbol and value', () => {
  const t = texts(D.render(byKey('308_win')));
  for (const s of ['L3 51.18', 'L6 71.12', 'R1 12.01', 'R 1.37', 'P1 11.96', 'P2 11.53', 'H1 8.72', 'H2 8.72', 'G1 7.85', 'L1 39.62', 'L2 43.48', 'E1 10.39', 'α 40°'])
    assert.ok(t.includes(s), s);
});

test('dimensions only where published', () => {
  const luger = texts(D.render(byKey('9_mm_luger')));
  for (const s of ['L3 19.15', 'L6 29.69', 'R1 9.96', 'R 1.27', 'P1 9.93', 'H2 9.65', 'G1 9.03', 'E1 8.79']) assert.ok(luger.includes(s), s);
  assert.ok(!luger.some((s) => /^(P2|H1|L1|L2|α) /.test(s)));
  const sp = texts(D.render(byKey('38_special')));
  assert.ok(!sp.some((s) => s.startsWith('E1')));
});

test('alpha is shown as degrees, minutes, seconds when published that way', () => {
  assert.ok(texts(D.render(byKey('6_5_x_55_se'))).includes('α 50°35\'2"'));
});

test('svg: accessible name, inline, millimetre units, no transform scaling', () => {
  const { svg } = D.render(byKey('308_win'));
  assert.match(svg, /^<svg [^>]*role="img"/);
  assert.match(svg, /aria-label="308 Win\. drawing"/);
  assert.match(svg, /viewBox="-?[\d.]+ -?[\d.]+ [\d.]+ [\d.]+"/);
  assert.ok(!/transform="[^"]*scale/.test(svg));
  assert.ok(!/<(image|script)|https?:\/\/(?!www\.w3\.org)/.test(svg));
});

test('svg: names are escaped', () => {
  const { svg } = D.render(byKey('40_s_w'));
  assert.ok(svg.includes('aria-label="40 S.&amp; W. drawing"'));
  assert.ok(svg.includes('40 S.&amp; W.'));
});

test('svg: coordinates are millimetres, x = z (mouth at L3, tip at L6)', () => {
  const { svg } = D.render(byKey('308_win'));
  const outline = svg.match(/<path class="outline[^"]*" d="([^"]+)"/g).join(' ');
  assert.match(outline, /51\.18 -4\.36/);
  assert.match(outline, /71\.12 /);
});

test('svg: dash-dot centre line, hatching, extension lines and arrowheads', () => {
  const { svg } = D.render(byKey('308_win'));
  assert.match(svg, /class="centre"/);
  assert.match(svg, /<pattern id="hatch-case"/);
  assert.match(svg, /fill="url\(#hatch-case\)"/);
  assert.ok((svg.match(/class="ext"/g) || []).length >= 13);
  assert.ok((svg.match(/class="arrow"/g) || []).length >= 24);
  assert.ok((svg.match(/class="dim"/g) || []).length === 13);
});

test('svg: title block with name, table, revision, units and scale', () => {
  const r = D.render(byKey('308_win'));
  assert.match(r.svg, /class="titleblock"/);
  assert.ok(r.svg.includes('308 Win.'));
  assert.ok(r.svg.includes('C.I.P. table I'));
  assert.ok(r.svg.includes('revised 2008-09-23'));
  assert.ok(r.svg.includes('Dimensions in mm'));
  assert.match(r.svg, /Scale \d+(\.\d+)?:1/);
  assert.ok(r.scale > 0.5 && r.scale < 5);
});

test('scale: the title block scale fits the drawing on A4 (186 x 100 mm)', () => {
  for (const rec of data) {
    const r = D.render(rec);
    const w = r.viewBox.w;
    const h = r.viewBox.h;
    assert.ok(w * r.scale <= 186 + 1e-9 && h * r.scale <= 100 + 1e-9, rec.key);
    assert.ok(r.svg.includes(`Scale ${r.scale}:1`), rec.key);
  }
});

test('labels never overlap each other (all 25 cartridges)', () => {
  for (const rec of data) {
    const { labels } = D.render(rec);
    for (let i = 0; i < labels.length; i++)
      for (let j = i + 1; j < labels.length; j++) assert.ok(!inter(labels[i], labels[j]), `${rec.key}: ${labels[i].text} / ${labels[j].text}`);
  }
});

test('labels never touch the outline or the part (all 25 cartridges)', () => {
  for (const rec of data) {
    const r = D.render(rec);
    const segs = outlineSegments(r.model);
    const silhouette = [...r.model.outer.map((p) => [p[1], -p[0]]), ...r.model.bullet.exposed.map((p) => [p[1], -p[0]]), [r.model.v.L6, 0], [0, 0]];
    for (const l of r.labels) {
      for (const s of segs) assert.ok(!segHitsRect(s, l), `${rec.key}: ${l.text} crosses the outline`);
      assert.ok(!inside(silhouette, (l.x0 + l.x1) / 2, (l.y0 + l.y1) / 2), `${rec.key}: ${l.text} lies on the part`);
    }
  }
});

test('labels stay inside the view box (all 25 cartridges)', () => {
  for (const rec of data) {
    const r = D.render(rec);
    const { x, y, w, h } = r.viewBox;
    for (const l of r.labels) assert.ok(l.x0 >= x && l.x1 <= x + w && l.y0 >= y && l.y1 <= y + h, `${rec.key}: ${l.text}`);
  }
});

test('leader lines of diameters are at least 1 mm apart (all 25 cartridges)', () => {
  for (const rec of data) {
    const xs = D.render(rec).leaderXs;
    for (let i = 1; i < xs.length; i++) assert.ok(xs[i] - xs[i - 1] >= 1, `${rec.key}: ${xs.join(' ')}`);
  }
});

test('drawing notes are returned for missing values', () => {
  const r = D.render(byKey('338_lapua_mag'));
  assert.ok(r.notes.some((n) => n.includes('r1 min')));
  assert.deepEqual(D.render(byKey('223_rem')).notes, []);
});

test('a record without a core value renders no svg and says why', () => {
  const rec = structuredClone(byKey('308_win'));
  delete rec.cartridge.projectile.G1;
  const r = D.render(rec);
  assert.equal(r.svg, '');
  assert.ok(r.notes.some((n) => n.includes('G1')));
});
