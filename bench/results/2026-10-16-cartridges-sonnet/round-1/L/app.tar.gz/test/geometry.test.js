const { test } = require('node:test');
const assert = require('node:assert/strict');
const data = require('../data.js');
const D = require('../geometry.js');

const byKey = (k) => data.find((r) => r.key === k);
const clone = (k, edit) => {
  const r = structuredClone(byKey(k));
  if (edit) edit(r);
  return r;
};
const near = (a, b, eps = 1e-6) => Math.abs(a - b) <= eps;
const has = (pts, r, z, eps = 1e-6) => pts.some((p) => near(p[0], r, eps) && near(p[1], z, eps));
const DEG = Math.PI / 180;

test('rimType: family belted and rimfire, otherwise R1/P1 thresholds', () => {
  assert.equal(D.rimType(byKey('300_win_mag')), 'belted');
  assert.equal(D.rimType(byKey('22_long_rifle')), 'rimfire');
  assert.equal(D.rimType(byKey('308_win')), 'rimless');
  assert.equal(D.rimType(byKey('9_3_x_74_r')), 'rimmed');
  assert.equal(D.rimType(byKey('38_special')), 'rimmed');
  assert.equal(D.rimType(clone('308_win', (r) => (r.cartridge.caseHead.R1 = 11.6))), 'rebated'); // 11.6 / 11.96 < 0.98
});

test('rimType: 1.05 is rimmed, just under is rimless, 0.98 is rimless', () => {
  const at = (q) => D.rimType(clone('308_win', (r) => { r.cartridge.caseHead.R1 = 10 * q; r.cartridge.powderChamber.P1 = 10; }));
  assert.equal(at(1.05), 'rimmed');
  assert.equal(at(1.049), 'rimless');
  assert.equal(at(0.98), 'rimless');
  assert.equal(at(0.979), 'rebated');
});

test('profile: head chamfer, rim edge and extractor groove (308 Win.)', () => {
  const m = D.buildModel(byKey('308_win'));
  const o = m.outer;
  const c = Math.min(0.38 * Math.tan(35 * DEG), 12.01 / 4);
  assert.deepEqual(o[0], [0, 0]);
  assert.ok(has(o, 12.01 / 2 - c, 0));
  assert.ok(has(o, 12.01 / 2, 0.38));
  assert.ok(has(o, 12.01 / 2, 1.37));
  assert.ok(has(o, 10.39 / 2, 1.37));
  assert.ok(has(o, 10.39 / 2, 1.37 + 1.4));
  assert.ok(has(o, 11.96 / 2, 3.85));
  assert.equal(m.zBodyStart, 3.85);
});

test('profile: chamfer length is limited to R1/4', () => {
  const r = clone('308_win', (x) => { x.cartridge.caseHead.f = 20; x.cartridge.caseHead.beta = 80; });
  const m = D.buildModel(r);
  assert.ok(has(m.outer, 12.01 / 2 - 12.01 / 4, 0));
});

test('profile: no chamfer when beta is 90 or more, square corner', () => {
  const m = D.buildModel(clone('308_win', (x) => (x.cartridge.caseHead.beta = 90)));
  assert.ok(has(m.outer, 12.01 / 2, 0));
  assert.ok(has(m.outer, 12.01 / 2, 1.37));
  assert.ok(!has(m.outer, 12.01 / 2, 0.38));
});

test('profile: no groove steps in from (R1/2, R) to (P1/2, R) (9,3 x 74 R)', () => {
  const m = D.buildModel(byKey('9_3_x_74_r'));
  const i = m.outer.findIndex((p) => near(p[0], 13.35 / 2) && near(p[1], 1.4));
  assert.ok(i > 0);
  assert.deepEqual(m.outer[i + 1], [11.9 / 2, 1.4]);
  assert.equal(m.zBodyStart, 1.4);
});

test('profile: rimfire rim edge is a half-round whose outermost point lies at R1/2 (22 LR)', () => {
  const m = D.buildModel(byKey('22_long_rifle'));
  const rho = Math.min(1.09 / 2, (7.06 - 5.74) / 2);
  assert.ok(has(m.outer, 7.06 / 2 - rho, 0));
  assert.ok(has(m.outer, 7.06 / 2, rho));
  assert.ok(has(m.outer, 7.06 / 2 - rho, 2 * rho));
  assert.ok(Math.max(...m.outer.map((p) => p[0])) <= 7.06 / 2 + 1e-9);
  assert.ok(has(m.outer, 5.74 / 2, 1.09));
});

test('profile: belted ramp at delta to the axis up to the belt, belt to E, step in to P1/2', () => {
  const m = D.buildModel(byKey('300_win_mag'));
  const dz = (13.51 / 2 - 12.07 / 2) / Math.tan(35 * DEG);
  const z0 = 1.27 + 0.94;
  assert.ok(has(m.outer, 12.07 / 2, z0));
  assert.ok(has(m.outer, 13.51 / 2, z0 + dz));
  assert.ok(has(m.outer, 13.51 / 2, 5.59));
  assert.ok(has(m.outer, 13.03 / 2, 5.59));
  assert.ok(near(m.beltRampEnd, z0 + dz));
});

test('profile: straight case runs from the body start to (H2/2, L3) (9 mm Luger)', () => {
  const m = D.buildModel(byKey('9_mm_luger'));
  const i = m.outer.findIndex((p) => near(p[0], 9.93 / 2) && near(p[1], 2.98));
  assert.deepEqual(m.outer[i + 1], [9.65 / 2, 19.15]);
  assert.equal(m.outer.length, i + 2);
  assert.equal(m.shoulder, false);
});

test('profile: bottleneck passes the published shoulder points when not rounded (338 Lapua Mag.)', () => {
  const m = D.buildModel(byKey('338_lapua_mag'));
  assert.ok(has(m.outer, 13.82 / 2, 54.9));
  assert.ok(m.shoulder);
  assert.deepEqual(m.outer.at(-1), [9.41 / 2, 69.2]);
});

test('profile: shoulder corners are rounded with r1 min (body side) and r2 (neck side)', () => {
  const m = D.buildModel(byKey('308_win'));
  assert.ok(!has(m.outer, 11.53 / 2, 39.62, 1e-3));
  assert.ok(!has(m.outer, 8.72 / 2, 43.48, 1e-3));
  const near2 = (r, z, d) => m.outer.some((p) => Math.hypot(p[0] - r, p[1] - z) < d);
  assert.ok(near2(11.53 / 2, 39.62, 0.4));
  assert.ok(near2(8.72 / 2, 43.48, 1.0));
  assert.deepEqual(m.outer.at(-1), [8.72 / 2, 51.18]);
});

test('profile: the shoulder line is drawn through the published points', () => {
  const m = D.buildModel(byKey('308_win'));
  // midpoint of the shoulder lies on the line (P2/2, L1) to (H1/2, L2)
  assert.ok(has(m.outer, (11.53 / 2 + 8.72 / 2) / 2, (39.62 + 43.48) / 2, 1e-6) || m.outer.some((p, i, a) => {
    if (!i) return false;
    const [r0, z0] = a[i - 1];
    const [r1, z1] = p;
    const mr = (11.53 + 8.72) / 4;
    const mz = (39.62 + 43.48) / 2;
    return mz >= z0 && mz <= z1 && near(r0 + ((r1 - r0) * (mz - z0)) / (z1 - z0), mr, 1e-6);
  }));
});

test('profile: a case without alpha, L1 or L2 is straight (22 Win. Mag. R.F.)', () => {
  const m = D.buildModel(byKey('22_win_mag_r_f'));
  assert.equal(m.shoulder, false);
  assert.deepEqual(m.outer.at(-1), [6.15 / 2, 26.8]);
});

test('walls: tn, tb and the solid head w (308 Win.)', () => {
  const m = D.buildModel(byKey('308_win'));
  assert.ok(near(m.tn, (8.72 - 7.85) / 2));
  assert.ok(near(m.tb, 0.6));
  assert.ok(near(m.w, Math.max(2.5, 0.25 * 11.96 / 2, 3.3 + 1.5, 3.85 + 0.6)));
});

test('walls: tb is limited to 0.35 * P1/2 and grows with 1.3 * tn', () => {
  const thin = D.buildModel(clone('308_win', (r) => { r.cartridge.powderChamber.P1 = 1; r.cartridge.caseHead.R1 = 1; }));
  assert.ok(near(thin.tb, 0.35 * 0.5));
  const thick = D.buildModel(clone('308_win', (r) => (r.cartridge.projectile.G1 = 6.0)));
  assert.ok(near(thick.tn, 1.36));
  assert.ok(near(thick.tb, 1.3 * 1.36));
});

test('walls: w uses the belt ramp end on belted cases and no pocket on rimfire (300 Win. Mag., 22 LR)', () => {
  const b = D.buildModel(byKey('300_win_mag'));
  assert.ok(near(b.w, Math.max(2.5, 0.25 * 13.03 / 2, 3.3 + 1.5, b.beltRampEnd + b.tb)));
  const f = D.buildModel(byKey('22_long_rifle'));
  assert.equal(f.pocket, null);
  assert.ok(near(f.w, 2.5));
});

test('pocket: diameter and depth by primer type', () => {
  const pk = (k) => D.buildModel(byKey(k)).pocket;
  assert.deepEqual(pk('223_rem'), { d: 4.45, depth: 3.04 }); // sr
  assert.deepEqual(pk('308_win'), { d: 5.33, depth: 3.3 }); // lr
  assert.deepEqual(pk('300_win_mag'), { d: 5.33, depth: 3.3 }); // lrm
  assert.deepEqual(pk('9_mm_luger'), { d: 4.45, depth: 3.04 }); // sp
  assert.deepEqual(pk('45_auto'), { d: 5.33, depth: 3.04 }); // lp
  assert.deepEqual(pk('357_magnum'), { d: 4.45, depth: 3.04 }); // spm
  assert.deepEqual(pk('44_rem_mag'), { d: 5.33, depth: 3.04 }); // lpm
});

test('inner line: starts at the cavity floor z = w and ends at the mouth with the neck wall', () => {
  const m = D.buildModel(byKey('308_win'));
  assert.ok(near(m.inner[0][1], m.w));
  assert.ok(near(m.inner[0][0], 11.96 / 2 - m.tb, 0.02));
  assert.deepEqual(m.inner.at(-1).map((v) => +v.toFixed(6)), [+(8.72 / 2 - m.tn).toFixed(6), 51.18]);
  assert.ok(m.inner.every((p) => p[0] > 0));
});

test('bullet: pointy tangent ogive (308 Win.)', () => {
  const b = D.buildModel(byKey('308_win')).bullet;
  const G = 7.85;
  assert.ok(near(b.s, G));
  assert.ok(near(b.zb, 51.18 - G));
  assert.ok(near(b.Lb, 71.12 - b.zb));
  assert.ok(near(b.zc, b.zb + 0.4 * b.Lb));
  assert.ok(near(b.m, 1.27));
  const a = G / 2 - b.m / 2;
  const n = 71.12 - b.zc;
  assert.ok(near(b.rho, (a * a + n * n) / (2 * a)));
  const arc = b.exposed.filter((p) => p[1] > b.zc + 1e-9 && p[1] < 71.12 - 1e-9);
  assert.ok(arc.length > 4);
  for (const [r, z] of arc) assert.ok(near(Math.hypot(r - (G / 2 - b.rho), z - b.zc), b.rho, 1e-6));
  assert.deepEqual(b.exposed.at(-1).map((v) => +v.toFixed(6)), [+(b.m / 2).toFixed(6), 71.12]);
  assert.deepEqual(b.exposed[0], [G / 2, 51.18]);
});

test('bullet: meplat of a pointy bullet is max(0.08 G1, 1.27)', () => {
  const big = D.buildModel(clone('308_win', (r) => { r.cartridge.projectile.G1 = 20; r.cartridge.collar.H2 = 21; })).bullet;
  assert.ok(near(big.m, 1.6));
});

test('bullet: rounded pistol (9 mm Luger) quarter ellipse, seat 0.4 G1, cylinder 0.65', () => {
  const b = D.buildModel(byKey('9_mm_luger')).bullet;
  const G = 9.03;
  assert.ok(near(b.s, 0.4 * G));
  assert.ok(near(b.zb, 19.15 - 0.4 * G));
  assert.ok(near(b.zc, b.zb + 0.65 * (29.69 - b.zb)));
  assert.ok(near(b.m, 0.15 * G));
  const a = G / 2 - b.m / 2;
  const n = 29.69 - b.zc;
  const mid = b.exposed.filter((p) => p[1] > b.zc + 1e-9 && p[1] < 29.69 - 1e-9);
  for (const [r, z] of mid) assert.ok(near(((r - b.m / 2) / a) ** 2 + ((z - b.zc) / n) ** 2, 1, 1e-6));
});

test('bullet: rounded rifle and rimfire seat 0.8 G1, cylinder 0.55', () => {
  const b = D.buildModel(byKey('22_win_mag_r_f')).bullet;
  assert.ok(near(b.s, 0.8 * 5.7));
  assert.ok(near(b.zc, b.zb + 0.55 * b.Lb));
});

test('bullet: flat pistol (40 S&W) cone with meplat 0.55 G1, cylinder 0.7', () => {
  const b = D.buildModel(byKey('40_s_w')).bullet;
  assert.ok(near(b.s, 0.4 * 10.17));
  assert.ok(near(b.zc, b.zb + 0.7 * b.Lb));
  assert.ok(near(b.m, 0.55 * 10.17));
  assert.deepEqual(b.exposed.slice(-2).map((p) => p.map((v) => +v.toFixed(6))), [[+(10.17 / 2).toFixed(6), +b.zc.toFixed(6)], [+(b.m / 2).toFixed(6), 28.83]]);
});

test('bullet: flat rifle cylinder is 0.60 and seat 0.8 G1', () => {
  const b = D.buildModel(clone('308_win', (r) => (r.annotations.defaultBulletShape = 'flat'))).bullet;
  assert.ok(near(b.s, 0.8 * 7.85));
  assert.ok(near(b.zc, b.zb + 0.6 * b.Lb));
  assert.ok(near(b.m, 0.55 * 7.85));
});

test('bullet: semi wadcutter seat 0.6 G1, cylinder 0.78, meplat 0.6 G1 (357 Magnum)', () => {
  const b = D.buildModel(byKey('357_magnum')).bullet;
  assert.ok(near(b.s, 0.6 * 9.12));
  assert.ok(near(b.zc, b.zb + 0.78 * b.Lb));
  assert.ok(near(b.m, 0.6 * 9.12));
});

test('bullet: rounded rifle uses 0.8 G1 seat on rimfire (22 LR) and heeled case gets the case diameters', () => {
  const m = D.buildModel(byKey('22_long_rifle'));
  assert.equal(m.heeled, true);
  assert.ok(near(m.bullet.s, 0.8 * 5.72));
  assert.ok(near(m.bullet.exposed[0][0], 5.72 / 2)); // case outside diameter
  const heel = m.bullet.section.find((p) => near(p[1], 15.57) && p[0] < 5.72 / 2 - 1e-9);
  assert.ok(near(heel[0], (5.72 - 2 * m.tb) / 2));
  assert.ok(near(m.tn, m.tb));
});

test('bullet: not heeled when H2 - G1 exceeds 0.015', () => {
  assert.equal(D.buildModel(byKey('22_win_mag_r_f')).heeled, false);
  assert.equal(D.buildModel(byKey('308_win')).heeled, false);
});

test('section: case polygon has the pocket notch and closes on the axis', () => {
  const m = D.buildModel(byKey('308_win'));
  const s = m.caseSection;
  assert.deepEqual(s[0], [0, 3.3]);
  assert.deepEqual(s[1], [5.33 / 2, 3.3]);
  assert.deepEqual(s[2], [5.33 / 2, 0]);
  assert.deepEqual(s.at(-1), [0, m.w]);
});

test('missing values: groove without e min is not drawn and the note names the value', () => {
  const m = D.buildModel(clone('308_win', (r) => delete r.cartridge.caseHead.eMin));
  assert.ok(m.ok);
  assert.ok(!has(m.outer, 10.39 / 2, 1.37));
  assert.equal(m.zBodyStart, 1.37);
  assert.ok(m.notes.some((n) => n.includes('e min')));
});

test('missing values: belt without R3 is not drawn', () => {
  const m = D.buildModel(clone('300_win_mag', (r) => delete r.cartridge.caseHead.R3));
  assert.ok(!has(m.outer, 13.51 / 2, 5.59));
  assert.ok(m.notes.some((n) => n.includes('R3')));
  assert.equal(m.beltRampEnd, undefined);
});

test('missing values: unrounded shoulder corners are reported (338 Lapua Mag., 17 HMR)', () => {
  assert.ok(D.buildModel(byKey('338_lapua_mag')).notes.some((n) => n.includes('r1 min')));
  const h = D.buildModel(byKey('17_hmr')).notes.join(' ');
  assert.ok(h.includes('r1 min') && h.includes('r2'));
});

test('missing values: bottleneck without P2 is drawn straight and says so', () => {
  const m = D.buildModel(clone('308_win', (r) => delete r.cartridge.powderChamber.P2));
  assert.equal(m.shoulder, false);
  assert.ok(m.notes.some((n) => n.includes('P2')));
});

test('missing values: no primer type means no pocket', () => {
  const m = D.buildModel(clone('308_win', (r) => delete r.annotations.primerType));
  assert.equal(m.pocket, null);
  assert.ok(m.notes.some((n) => n.includes('primer')));
});

test('missing values: a core value missing means no drawing, never an invented number', () => {
  const m = D.buildModel(clone('308_win', (r) => delete r.cartridge.projectile.G1));
  assert.equal(m.ok, false);
  assert.ok(m.notes.some((n) => n.includes('G1')));
});

test('data: no invented notes for complete records', () => {
  assert.deepEqual(D.buildModel(byKey('223_rem')).notes, []);
  assert.deepEqual(D.buildModel(byKey('9_mm_luger')).notes, []);
});

test('all 25 records build a model', () => {
  for (const rec of data) {
    const m = D.buildModel(rec);
    assert.ok(m.ok, rec.key);
    for (const [r, z] of m.outer) assert.ok(Number.isFinite(r) && Number.isFinite(z) && r >= 0, rec.key);
    assert.ok(m.w < rec.cartridge.lengths.L3, rec.key);
    assert.ok(m.inner.every((p) => p[0] > 0), rec.key);
  }
});

test('missing values: a partly published shoulder (alpha, L1, L2) is drawn straight and names what is missing', () => {
  const m = D.buildModel(clone('223_rem', (r) => delete r.cartridge.junctionCone.alpha));
  assert.equal(m.shoulder, false);
  assert.ok(m.notes.some((n) => n.includes('alpha') || n.includes('α')));
  const both = D.buildModel(clone('223_rem', (r) => { delete r.cartridge.lengths.L1; delete r.cartridge.lengths.L2; }));
  assert.ok(both.notes.some((n) => n.includes('L1') && n.includes('L2')));
});

test('missing values: a centrefire case without beta and f says the chamfer is not drawn', () => {
  const m = D.buildModel(clone('223_rem', (r) => { delete r.cartridge.caseHead.beta; delete r.cartridge.caseHead.f; }));
  assert.ok(m.notes.some((n) => n.includes('β') && n.includes('f') && n.includes('chamfer')));
});
