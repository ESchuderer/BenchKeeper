const { test } = require('node:test');
const assert = require('node:assert/strict');
const data = require('../data.js');
const M = require('../model.js');

const byKey = (k) => data.find((r) => r.key === k);

test('data: 25 records with unique keys and names', () => {
  assert.equal(data.length, 25);
  assert.equal(new Set(data.map((r) => r.key)).size, 25);
  assert.equal(new Set(data.map((r) => r.name)).size, 25);
});

test('formatAngle: number shows degrees', () => {
  assert.equal(M.formatAngle(40), '40°');
  assert.equal(M.formatAngle(46.0), '46°');
});

test('formatAngle: object shows degrees, minutes, seconds', () => {
  assert.equal(M.formatAngle({ degrees: 39, minutes: 59, seconds: 49 }), '39°59\'49"');
  assert.equal(M.formatAngle({ degrees: 34, minutes: 30, seconds: 0 }), '34°30\'0"');
});

test('formatNumber: as published, decimal point, no thousands separator', () => {
  assert.equal(M.formatNumber(51.18), '51.18');
  assert.equal(M.formatNumber(4150.0), '4150');
  assert.equal(M.formatNumber(5375), '5375');
});

test('symbolLabel: field name except the listed symbols', () => {
  assert.equal(M.symbolLabel('L3'), 'L3');
  assert.equal(M.symbolLabel('eMin'), 'e min');
  assert.equal(M.symbolLabel('r1Min'), 'r1 min');
  assert.equal(M.symbolLabel('r1Max'), 'r1 max');
  assert.equal(M.symbolLabel('alpha'), 'α');
  assert.equal(M.symbolLabel('alpha1'), 'α1');
  assert.equal(M.symbolLabel('beta'), 'β');
  assert.equal(M.symbolLabel('delta'), 'δ');
  assert.equal(M.symbolLabel('deltaL'), 'delta L');
  assert.equal(M.symbolLabel('L3PlusG'), 'L3 + G');
  assert.equal(M.symbolLabel('Pmax'), 'Pmax');
});

test('unitOf: mm by default, bar, J, g, mm², angles, none for N', () => {
  assert.equal(M.unitOf('L3'), 'mm');
  assert.equal(M.unitOf('Pmax'), 'bar');
  assert.equal(M.unitOf('PK'), 'bar');
  assert.equal(M.unitOf('PE'), 'bar');
  assert.equal(M.unitOf('EE'), 'J');
  assert.equal(M.unitOf('M'), 'g');
  assert.equal(M.unitOf('Q'), 'mm²');
  assert.equal(M.unitOf('N'), '');
  for (const a of ['alpha', 'alpha1', 'beta', 'delta', 'i']) assert.equal(M.unitOf(a), '°');
});

test('sections: tolerance sits on the value row, never a row of its own', () => {
  const secs = M.sections(byKey('308_win'), 'cartridge');
  const lengths = secs.find((s) => s.title === 'Lengths');
  assert.deepEqual(lengths.rows.map((r) => r.symbol), ['L1', 'L2', 'L3', 'L6']);
  const l1 = lengths.rows.find((r) => r.symbol === 'L1');
  assert.deepEqual(l1, { symbol: 'L1', value: '39.62', tol: '-0.2', unit: 'mm' });
  const all = secs.flatMap((s) => s.rows.map((r) => r.symbol));
  assert.ok(!all.some((s) => /Tol$/.test(s)));
});

test('sections: angles, dms angles, pressures and counts', () => {
  const c = M.sections(byKey('223_rem'), 'cartridge');
  const head = c.find((s) => s.title === 'Case head');
  assert.deepEqual(head.rows.find((r) => r.symbol === 'β'), { symbol: 'β', value: '35°', tol: '', unit: '°' });
  const ch = M.sections(byKey('223_rem'), 'chamber');
  const rifling = ch.find((s) => s.title === 'Rifling');
  assert.equal(rifling.rows.find((r) => r.symbol === 'i').value, '3°10\'36"');
  const grooves = ch.find((s) => s.title === 'Grooves');
  assert.deepEqual(grooves.rows.find((r) => r.symbol === 'N'), { symbol: 'N', value: '6', tol: '', unit: '' });
  const pr = c.find((s) => s.title === 'Pressures');
  assert.deepEqual(pr.rows.find((r) => r.symbol === 'Pmax'), { symbol: 'Pmax', value: '4300', tol: '', unit: 'bar' });
});

test('sections: empty sections are omitted, symbols are mapped', () => {
  const luger = M.sections(byKey('9_mm_luger'), 'cartridge');
  assert.ok(!luger.some((s) => s.title === 'Junction cone'));
  const rem = M.sections(byKey('223_rem'), 'cartridge');
  const syms = rem.flatMap((s) => s.rows.map((r) => r.symbol));
  for (const s of ['e min', 'r1 min', 'α', 'δ', 'delta L', 'L3 + G']) assert.ok(syms.includes(s), s);
});

test('sections: every numeric field of every record appears exactly once', () => {
  for (const rec of data) {
    for (const part of ['cartridge', 'chamber']) {
      const expected = Object.values(rec[part])
        .flatMap((o) => Object.keys(o))
        .filter((k) => !/Tol$/.test(k)).length;
      const got = M.sections(rec, part).reduce((n, s) => n + s.rows.length, 0);
      assert.equal(got, expected, `${rec.key} ${part}`);
    }
  }
});

test('matches: name, alternative names, whitespace and case', () => {
  const r308 = byKey('308_win');
  assert.ok(M.matches(r308, '7,62 x 51', ''));
  assert.ok(M.matches(r308, '7,62x51', ''));
  assert.ok(M.matches(r308, '308 WINCHESTER', ''));
  assert.ok(M.matches(r308, '308 win', ''));
  assert.ok(!M.matches(r308, '7,62 x 63', ''));
  assert.ok(M.matches(byKey('30_06_spring'), '7,62 x 63', ''));
});

test('matches: family filter', () => {
  const r308 = byKey('308_win');
  assert.ok(M.matches(r308, '', 'rimless'));
  assert.ok(!M.matches(r308, '', 'rimmed'));
  assert.ok(M.matches(r308, '', ''));
});

test('filter: family counts across the data', () => {
  const n = (f) => data.filter((r) => M.matches(r, '', f)).length;
  assert.equal(n(''), 25);
  assert.equal(n('rimless'), 12);
  assert.equal(n('belted'), 2);
  assert.equal(n('rimmed'), 2);
  assert.equal(n('pistol'), 6);
  assert.equal(n('rimfire'), 3);
});

test('capacity: published water capacity with source link, absent when not published', () => {
  assert.deepEqual(M.capacity(byKey('308_win')), {
    text: '56 gr H2O',
    source: 'kwk',
    url: 'http://kwk.us/cases.html',
    note: 'Lapua brass measures 55.8 (lapua-308)',
  });
  assert.equal(M.capacity(byKey('7_x_64')), null);
});
