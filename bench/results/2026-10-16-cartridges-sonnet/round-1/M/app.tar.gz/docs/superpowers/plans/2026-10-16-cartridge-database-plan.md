# Cartridge database: plan

1. Scaffold: `package.json` (`npm test` = `node --test "test/*.test.js"`), `.gitignore`, `js/data.js` (25 records verbatim) with a data test (25 records, unique keys).
2. `js/format.js` with tests first: angle, tolerance, number, symbols, units, table rows, alt-name search, family filter.
3. `js/drawing.js` geometry with tests first: rim type, head and groove profile, belted, shoulder and fillets, bullet rules, walls and head, pocket, missing values, dimension set.
4. Drawing layout and SVG render; test label overlap for all 25 records.
5. `index.html`, `style.css`, `js/app.js`: list, filters, detail, routing, print button.
6. Browser verification: file://, static server, mobile, dark, print PDF one page.
7. Code review subagent, fixes, commit per task.
