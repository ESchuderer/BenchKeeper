# Cartridge database: design

Source of requirements: the task brief (25 C.I.P. records, start page, detail view, SVG drawing, print, look and feel). This file records only decisions the brief leaves open. All are the builder's calls.

## Goals
- Static reference app: `index.html` + CSS + classic JS, no build, no network, works from `file://`.
- Detail view with a computed, to-scale SVG drawing (1 user unit = 1 mm).

## Non-goals
- No data editing or fetching, no chamber drawing, no unit conversion, no framework.
- `annotations.implausible`, `confidence`, `S`, `deltaL` are shown only in the tables (if at all), not interpreted.

## Architecture
- `js/data.js`: the 25 records, `CARTRIDGES`.
- `js/format.js`: pure formatting (angles, tolerances, symbols, units, table rows), search filter.
- `js/drawing.js`: pure geometry (`buildDrawing(record)` returns profile, section, bullet, dimensions, label boxes, missing values) and the SVG string renderer.
- `js/app.js`: hash routing (`#/` list, `#/cartridge/<key>`), DOM rendering.
- Modules are IIFEs exporting to `globalThis` and `module.exports`, so `node --test` loads them without a bundler.
- Hash routing: `file://` has no server rewrite, and the hash survives reload and bookmarks.

## Decisions (builder's calls)
- Coordinates in the rules are `(r, z)` pairs, as the groove rule `(P1/2, E)` shows.
- Chamfer takes precedence over the rimfire half-round when both could apply (no record has both).
- Rim type is computed and exposed on the drawing model; it changes no geometry beyond the rules given.
- Straight cases: the "neck" for the wall rule is the seated part `[zb, L3]`; wall goes from `tb` to `tn` linearly over `[zb - s, zb]`. Heeled cases use `tb` everywhere (`tn` would be 0).
- On belted cases the inner line follows the body line, not the belt.
- Fillets are polyline arcs; radius is reduced when it would exceed half of an adjacent segment.
- Missing values are reported only when a feature the case should have cannot be drawn (r1 min, r2 on a bottleneck; one of E/E1/e min on rimless and belted; delta, R3 on belted; one of beta/f on non-rimfire; primer type on centrefire). Absence of a groove on rimmed and rimfire cases is not "missing".
- Dimension layout: lengths in a ladder below (shortest nearest); diameters in a ladder right of the tip with extension lines and rotated labels in a band above; R1 on the left; E1 with outside arrows in the groove; R as the nearest length row; the shoulder angle as a detached wedge marker above the shoulder (the cone apex lies inside the bullet or neck).
- Title block lower right. Scale in the block is the print scale at 190 mm drawing width.
- Search ignores case, spaces, and treats `,` and `.` alike.
- List count text is literally `<n> cartridges`.
- Angle unit cell: `deg`. `N` unit cell is empty. Tolerances are shown with the value everywhere X is shown (tables, list L3), not in drawing labels.
- Section order is fixed; empty sections are skipped.

## Checks
- `node --test`: formatting, search, geometry rules, label overlap over all 25 records.
- Browser: Playwright MCP on `file://` and a static server, phone width, dark scheme, print emulation and PDF page count.
