// Views and routing. #/ is the list, #/cartridge/<key> a detail view.
(function () {
  var F = Format, D = Drawing, ALL = CARTRIDGES;
  var FAMILIES = ['all', 'rimless', 'rimmed', 'belted', 'pistol', 'rimfire'];
  var state = { q: '', family: 'all' };
  var main = document.getElementById('main');

  function h(tag, props) {
    var e = document.createElement(tag);
    Object.keys(props || {}).forEach(function (k) {
      if (k === 'text') e.textContent = props[k];
      else if (k.slice(0, 2) === 'on') e.addEventListener(k.slice(2), props[k]);
      else e.setAttribute(k, props[k]);
    });
    for (var i = 2; i < arguments.length; i++) {
      var c = arguments[i];
      if (c !== null && c !== undefined) e.appendChild(typeof c === 'string' ? document.createTextNode(c) : c);
    }
    return e;
  }

  function listView() {
    var tbody = h('tbody');
    var count = h('p', { id: 'count', 'aria-live': 'polite' });
    function update() {
      var rows = F.filter(ALL, state.q, state.family);
      tbody.textContent = '';
      rows.forEach(function (c) {
        tbody.appendChild(h('tr', {}, h('td', {}, h('a', { href: '#/cartridge/' + c.key, text: c.name })),
          h('td', { text: c.family }), h('td', { class: 'num', text: F.l3Text(c) })));
      });
      if (!rows.length) tbody.appendChild(h('tr', {}, h('td', { colspan: 3, class: 'empty', text: 'No cartridge matches.' })));
      count.textContent = rows.length + ' cartridges';
    }
    var search = h('input', { id: 'search', type: 'search', autocomplete: 'off', spellcheck: 'false', oninput: function (e) { state.q = e.target.value; update(); } });
    search.value = state.q;
    var family = h('select', { id: 'family', onchange: function (e) { state.family = e.target.value; update(); } });
    FAMILIES.forEach(function (f) { family.appendChild(h('option', { value: f, text: f === 'all' ? 'All' : f })); });
    family.value = state.family;
    update();
    return h('div', { class: 'list-view' },
      h('h1', { text: 'Cartridges', tabindex: '-1' }),
      h('form', { class: 'filters', role: 'search', onsubmit: function (e) { e.preventDefault(); } },
        h('div', { class: 'field' }, h('label', { for: 'search', text: 'Search' }), search),
        h('div', { class: 'field' }, h('label', { for: 'family', text: 'Family' }), family),
        count),
      h('table', { class: 'list' },
        h('thead', {}, h('tr', {}, h('th', { scope: 'col', text: 'Name' }), h('th', { scope: 'col', text: 'Family' }), h('th', { scope: 'col', class: 'num', text: 'Case length L3' }))),
        tbody));
  }

  function meta(c) {
    var cap = c.annotations && c.annotations.publishedCapacity;
    var capCell = cap
      ? [F.capacityText(c) + ' (source: ', h('a', { href: cap.url, text: cap.source }), ')' + (cap.note ? ', ' + cap.note : '')]
      : ['not published'];
    var items = [
      ['Alternative names', (c.alternativeNames || []).join(', ') || 'none'],
      ['Family', c.family],
      ['Category', (c.annotations || {}).category || 'not published'],
      ['Primer type', (c.annotations || {}).primerType || 'not published'],
      ['C.I.P. table', c.tab],
      ['Country', c.country],
      ['Published', c.published],
      ['Revised', c.revised],
      ['Pressure method', c.pressureMethod],
      ['Water capacity', capCell]
    ];
    var dl = h('dl', { class: 'meta' });
    items.forEach(function (it) {
      var dd = h('dd');
      [].concat(it[1]).forEach(function (n) { dd.appendChild(typeof n === 'string' ? document.createTextNode(n) : n); });
      dl.appendChild(h('div', {}, h('dt', { text: it[0] }), dd));
    });
    return dl;
  }

  function tables(c, group, title) {
    var wrap = h('section', { class: 'values' }, h('h2', { text: title }));
    var grid = h('div', { class: 'tables' });
    F.sections(c, group).forEach(function (s) {
      var tb = h('tbody');
      s.rows.forEach(function (r) {
        tb.appendChild(h('tr', {}, h('th', { scope: 'row', text: r.symbol }), h('td', { class: 'num', text: r.value }), h('td', { class: 'unit', text: r.unit })));
      });
      grid.appendChild(h('table', {},
        h('caption', { text: title.split(' ')[0] + ': ' + s.title }),
        h('thead', {}, h('tr', {}, h('th', { scope: 'col', text: 'Symbol' }), h('th', { scope: 'col', class: 'num', text: 'Value' }), h('th', { scope: 'col', text: 'Unit' }))),
        tb));
    });
    wrap.appendChild(grid);
    return wrap;
  }

  function detailView(c) {
    var fig = h('figure', { class: 'drawing-figure' });
    fig.innerHTML = D.svg(c);
    var note = D.missingNote(D.geometry(c));
    if (note) fig.appendChild(h('figcaption', { class: 'drawing-note', text: note }));
    return h('article', { class: 'detail' },
      h('div', { class: 'toolbar' },
        h('a', { href: '#/', text: 'All cartridges' }),
        h('button', { type: 'button', onclick: function () { window.print(); }, text: 'Print' })),
      h('header', { class: 'page-header' }, h('p', { class: 'print-only', text: 'C.I.P. cartridge reference' }), h('h1', { text: c.name, tabindex: '-1' })),
      meta(c),
      fig,
      tables(c, 'cartridge', 'Cartridge values'),
      tables(c, 'chamber', 'Chamber values'),
      h('p', { class: 'source', text: 'Source: C.I.P. TDCC, revised ' + c.revised }));
  }

  function notFound() {
    return h('div', {}, h('h1', { text: 'Cartridge not found', tabindex: '-1' }), h('p', {}, h('a', { href: '#/', text: 'All cartridges' })));
  }

  var first = true;
  function route() {
    var m = /^#\/cartridge(\/.*)?$/.exec(location.hash), key = null;
    try { key = m && /^\/([^/]+)$/.test(m[1] || '') ? decodeURIComponent(m[1].slice(1)) : null; } catch (e) { key = null; }
    var c = key && ALL.filter(function (x) { return x.key === key; })[0];
    main.textContent = '';
    if (m && c) { main.appendChild(detailView(c)); document.title = c.name + ' - Cartridges'; }
    else if (m) { main.appendChild(notFound()); document.title = 'Cartridge not found'; }
    else { main.appendChild(listView()); document.title = 'Cartridges'; }
    if (!first) { window.scrollTo(0, 0); main.querySelector('h1').focus(); }
    first = false;
  }

  window.addEventListener('hashchange', route);
  route();
})();
