// Cartridge drawing: geometry (pure) and SVG rendering. Points are {z, r}: z along the axis from the
// head face, r the radius. SVG units are mm: x = z, y = -r (outside view, upper) or +r (section, lower).
(function (root) {
  var DEG = Math.PI / 180;
  var POCKET = {
    sp: [4.45, 3.04], spm: [4.45, 3.04], sr: [4.45, 3.04], lp: [5.33, 3.04], lpm: [5.33, 3.04], lr: [5.33, 3.3], lrm: [5.33, 3.3]
  };

  function P(z, r) { return { z: z, r: r }; }
  function has(v) { return v !== undefined && v !== null && (typeof v === 'object' || isFinite(v)); }
  function deg(a) { return typeof a === 'number' ? a : a.degrees + a.minutes / 60 + a.seconds / 3600; }
  function dist(a, b) { return Math.hypot(a.z - b.z, a.r - b.r); }
  function unit(a, b) { var d = dist(a, b); return { z: (b.z - a.z) / d, r: (b.r - a.r) / d }; }

  function rimType(rec) {
    if (rec.family === 'belted') return 'belted';
    if (rec.family === 'rimfire') return 'rimfire';
    var q = rec.cartridge.caseHead.R1 / rec.cartridge.powderChamber.P1;
    return q >= 1.05 ? 'rimmed' : q < 0.98 ? 'rebated' : 'rimless';
  }

  // Round the corner at v (between a and b) with radius rad; the radius shrinks when it would
  // use more than half of an adjacent segment.
  function fillet(a, v, b, rad) {
    var u1 = unit(v, a), u2 = unit(v, b);
    var th = Math.acos(Math.max(-1, Math.min(1, u1.z * u2.z + u1.r * u2.r)));
    if (th < 1e-6 || th > Math.PI - 1e-6) return [v];
    var t = Math.min(rad / Math.tan(th / 2), 0.5 * Math.min(dist(a, v), dist(b, v)));
    rad = t * Math.tan(th / 2);
    var p1 = P(v.z + u1.z * t, v.r + u1.r * t), p2 = P(v.z + u2.z * t, v.r + u2.r * t);
    var bz = u1.z + u2.z, br = u1.r + u2.r, bl = Math.hypot(bz, br), k = rad / Math.sin(th / 2);
    var c = P(v.z + bz / bl * k, v.r + br / bl * k);
    var a0 = Math.atan2(p1.r - c.r, p1.z - c.z), d = Math.atan2(p2.r - c.r, p2.z - c.z) - a0;
    while (d > Math.PI) d -= 2 * Math.PI;
    while (d < -Math.PI) d += 2 * Math.PI;
    var n = Math.max(4, Math.ceil(Math.abs(d) / (4 * DEG))), out = [];
    for (var i = 0; i <= n; i++) out.push(P(c.z + rad * Math.cos(a0 + d * i / n), c.r + rad * Math.sin(a0 + d * i / n)));
    return out;
  }

  function dedupe(pts) {
    return pts.filter(function (p, i) { return !i || dist(p, pts[i - 1]) > 1e-9; });
  }

  // Linear interpolation of r at z on a polyline whose z does not decrease.
  function interp(pts, z) {
    if (z <= pts[0].z) return pts[0].r;
    for (var i = 1; i < pts.length; i++) {
      var a = pts[i - 1], b = pts[i];
      if (z <= b.z + 1e-12 && b.z > a.z) return a.r + (b.r - a.r) * (z - a.z) / (b.z - a.z);
    }
    return pts[pts.length - 1].r;
  }

  function bulletModel(rec, g, miss) {
    var a = rec.annotations || {}, G1 = rec.cartridge.projectile.G1, L3 = rec.cartridge.lengths.L3, L6 = rec.cartridge.lengths.L6;
    var shape = a.defaultBulletShape, pistol = a.category === 'pistol';
    if (['rifle', 'pistol', 'rimfire'].indexOf(a.category) < 0) { miss.push('category'); return null; }
    if (!has(G1) || !has(L6) || ['pointy', 'rounded', 'flat', 'semi_wadcutter'].indexOf(shape) < 0) {
      miss.push(!has(L6) ? 'L6' : !has(G1) ? 'G1' : 'bullet shape');
      return null;
    }
    var s = shape === 'pointy' ? G1 : shape === 'semi_wadcutter' ? 0.6 * G1 : (pistol ? 0.4 : 0.8) * G1;
    var k = { pointy: 0.40, rounded: pistol ? 0.65 : 0.55, flat: pistol ? 0.70 : 0.60, semi_wadcutter: 0.78 }[shape];
    var m = { pointy: Math.max(0.08 * G1, 1.27), rounded: 0.15 * G1, flat: 0.55 * G1, semi_wadcutter: 0.6 * G1 }[shape];
    var zb = L3 - s, Lb = L6 - zb, zc = zb + k * Lb, n = L6 - zc;
    var re = g.heeled ? rec.cartridge.collar.H2 / 2 : G1 / 2, rs = g.heeled ? re - g.tb : G1 / 2;
    var nose = [], i, N = 24, h = re - m / 2;
    if (shape === 'pointy') {
      var rho = (h * h + n * n) / (2 * h), cr = re - rho, tmax = Math.asin(Math.min(1, n / rho));
      for (i = 0; i <= N; i++) nose.push(P(zc + rho * Math.sin(tmax * i / N), cr + rho * Math.cos(tmax * i / N)));
      nose[N] = P(L6, m / 2);
    } else if (shape === 'rounded') {
      for (i = 0; i <= N; i++) nose.push(P(zc + n * Math.sin(Math.PI / 2 * i / N), m / 2 + h * Math.cos(Math.PI / 2 * i / N)));
      nose[N] = P(L6, m / 2);
    } else {
      nose = [P(zc, re), P(L6, m / 2)];
    }
    return { shape: shape, s: s, k: k, zb: zb, Lb: Lb, zc: zc, m: m, re: re, rs: rs, nose: nose };
  }

  function geometry(rec) {
    var cc = rec.cartridge, h = cc.caseHead, pc = cc.powderChamber, col = cc.collar || {}, jc = cc.junctionCone || {}, len = cc.lengths;
    var type = rimType(rec), miss = [];
    var R1 = h.R1, R = h.R, P1 = pc.P1, rr = R1 / 2, H2 = col.H2, G1 = cc.projectile.G1, L3 = len.L3;
    var pts = [P(0, 0)], zbs, beltRampEnd = null, i;

    // head face and rim edge
    if (has(h.beta) && has(h.f) && deg(h.beta) < 90) {
      var ch = Math.min(h.f * Math.tan(deg(h.beta) * DEG), R1 / 4);
      pts.push(P(0, rr - ch), P(h.f, rr), P(R, rr));
    } else if (type === 'rimfire') {
      var rho = Math.min(R / 2, (R1 - P1) / 2), rc = rr - rho;
      for (i = 0; i <= 12; i++) pts.push(P(rho - rho * Math.cos(Math.PI * i / 12), rc + rho * Math.sin(Math.PI * i / 12)));
      pts.push(P(R, rc));
    } else {
      if (has(h.beta) !== has(h.f)) miss.push(has(h.f) ? 'beta' : 'f');
      pts.push(P(0, rr), P(R, rr));
    }

    // extractor groove, belt, or step to the body
    var wantsGroove = type === 'rimless' || type === 'belted';
    if (has(h.E) && has(h.E1) && has(h.eMin)) {
      pts.push(P(R, h.E1 / 2), P(R + h.eMin, h.E1 / 2));
      if (type === 'belted' && has(h.delta) && has(h.R3)) {
        beltRampEnd = R + h.eMin + (h.R3 / 2 - h.E1 / 2) / Math.tan(deg(h.delta) * DEG);
        pts.push(P(beltRampEnd, h.R3 / 2), P(h.E, h.R3 / 2), P(h.E, P1 / 2));
      } else {
        if (type === 'belted') miss.push(has(h.delta) ? 'R3' : 'delta');
        pts.push(P(h.E, P1 / 2));
      }
      zbs = h.E;
    } else {
      if (wantsGroove) ['E', 'E1', 'eMin'].forEach(function (k) { if (!has(h[k])) miss.push(k === 'eMin' ? 'e min' : k); });
      pts.push(P(R, P1 / 2));
      zbs = R;
    }
    pts = dedupe(pts);
    var bodyStart = pts.length - 1;

    // body, shoulder, neck
    var shoulderIn = has(jc.alpha) && has(len.L1) && has(len.L2);
    var bottleneck = shoulderIn && has(pc.P2) && has(col.H1);
    var sh = [['α', jc.alpha], ['L1', len.L1], ['L2', len.L2]];
    if (!shoulderIn && sh.some(function (x) { return has(x[1]); })) sh.forEach(function (x) { if (!has(x[1])) miss.push(x[0]); });
    if (shoulderIn && !bottleneck) miss.push(has(pc.P2) ? 'H1' : 'P2');
    var corner1, corner2;
    if (bottleneck) {
      var v1 = P(len.L1, pc.P2 / 2), v2 = P(len.L2, col.H1 / 2), v3 = P(L3, H2 / 2), prev = pts[pts.length - 1];
      var f1 = has(jc.r1Min) ? fillet(prev, v1, v2, jc.r1Min) : [v1];
      var f2 = has(jc.r2) ? fillet(v1, v2, v3, jc.r2) : [v2];
      if (!has(jc.r1Min)) miss.push('r1 min');
      if (!has(jc.r2)) miss.push('r2');
      pts = pts.concat(f1, f2, [v3]);
      corner1 = v1; corner2 = v2;
    } else {
      pts.push(P(L3, H2 / 2));
    }
    var outer = dedupe(pts);
    var groove = has(h.E) && has(h.E1) && has(h.eMin) ? { z: R + h.eMin / 2, D: h.E1 } : null;
    var body = outer.slice(bodyStart);
    var bodyR = function (z) { return z <= zbs ? P1 / 2 : interp(body, z); };

    // walls, solid head, primer pocket
    var tn = (H2 - G1) / 2, heeled = H2 - G1 <= 0.015;
    var tb = Math.min(Math.max(1.3 * tn, 0.6), 0.35 * P1 / 2), tnEff = heeled ? tb : tn;
    var pocket = null, pk = POCKET[(rec.annotations || {}).primerType];
    if (type !== 'rimfire') {
      if (pk) pocket = { d: pk[0], depth: pk[1] };
      else miss.push('primer type');
    }
    var w = Math.max(2.5, 0.25 * P1 / 2);
    if (pocket) w = Math.max(w, pocket.depth + 1.5);
    if (zbs > R) w = Math.max(w, (beltRampEnd !== null ? beltRampEnd : zbs) + tb);

    var g = { name: rec.name, rimType: type, bottleneck: bottleneck, heeled: heeled, missing: miss, outer: outer, bodyStart: P(zbs, P1 / 2),
      beltRampEnd: beltRampEnd, groove: groove, tb: tb, tn: tn, w: w, pocket: pocket, corner1: corner1 || null, corner2: corner2 || null };
    g.bullet = bulletModel(rec, g, miss);

    // inner line: wall tb on the body, tn on the neck, linear across the shoulder (straight case: over the seated part)
    var zA, zB;
    if (bottleneck) { zA = len.L1; zB = len.L2; }
    else if (g.bullet) { zB = g.bullet.zb; zA = Math.max(w, zB - g.bullet.s); }
    else { zA = zB = L3; }
    var wall = function (z) {
      if (heeled) return tb;
      if (z <= zA) return tb;
      if (z >= zB) return tnEff;
      return tb + (tnEff - tb) * (z - zA) / (zB - zA);
    };
    var zs = [w, L3, zA, zB].concat(body.map(function (p) { return p.z; }))
      .filter(function (z) { return z >= w - 1e-9 && z <= L3 + 1e-9; })
      .sort(function (a, b) { return a - b; });
    zs = zs.filter(function (z, i) { return !i || z - zs[i - 1] > 1e-9; });
    g.inner = zs.map(function (z) { return P(z, bodyR(z) - wall(z)); });
    g.innerR = function (z) { return interp(g.inner, z); };

    // section polygons (z, r > 0): case wall and solid head, bullet
    var cs = outer.slice();
    if (pocket) cs[0] = P(0, pocket.d / 2);
    cs.push(P(L3, g.inner[g.inner.length - 1].r));
    for (i = g.inner.length - 1; i >= 0; i--) cs.push(g.inner[i]);
    cs.push(P(w, 0));
    if (pocket) cs.push(P(pocket.depth, 0), P(pocket.depth, pocket.d / 2));
    g.section = { case: dedupe(cs), bullet: [] };
    g.upper = outer.slice();
    var b = g.bullet;
    if (b) {
      g.upper.push(P(L3, b.re), P(b.zc, b.re));
      g.upper = g.upper.concat(b.nose.slice(1), [P(b.nose[b.nose.length - 1].z, 0)]);
      var bs = [P(b.zb, 0), P(b.zb, b.rs), P(L3, b.rs)];
      if (b.rs !== b.re) bs.push(P(L3, b.re));
      bs.push(P(b.zc, b.re));
      g.section.bullet = dedupe(bs.concat(b.nose.slice(1), [P(len.L6, 0)]));
    } else {
      g.upper.push(P(L3, 0));
    }
    g.upper = dedupe(g.upper);
    g.tip = b ? len.L6 : L3;
    g.rmax = Math.max.apply(null, outer.map(function (p) { return p.r; }));
    g.alpha = bottleneck ? deg(jc.alpha) : null;
    return g;
  }

  // ---- layout: dimensions, labels, title block, view box -------------------------------------------

  var Fmt = typeof module === 'object' && module.exports ? require('./format.js') : root.Format;
  var FS = 3.6, TF = 3.1, NF = 4, AL = 1.6, AH = 0.5, TAIL = 2.0, EGAP = 0.8, ROW0 = 5, ROWSTEP = 7.5, PRINT_W = 190;

  function tw(t, fs) { return t.length * 0.62 * (fs || FS); }
  function line(x1, y1, x2, y2, type) { return { x1: x1, y1: y1, x2: x2, y2: y2, type: type }; }
  function arrow(x, y, dx, dy) { return { x: x, y: y, dx: dx, dy: dy }; }
  // horizontal label, text anchored at its start (x, baseline yb)
  function hbox(x, yb, w, fs) { return { x0: x, y0: yb - 0.95 * fs, x1: x + w, y1: yb + 0.3 * fs }; }
  // label rotated by -90 degrees, reading upward from (xb, yb)
  function vbox(xb, yb, w, fs) { return { x0: xb - 0.95 * fs, x1: xb + 0.3 * fs, y0: yb - w, y1: yb }; }

  // Dimension line between two points; arrows inside, or outside with tails when too short.
  function dimLine(x1, y1, x2, y2) {
    var L = Math.hypot(x2 - x1, y2 - y1), ux = (x2 - x1) / L, uy = (y2 - y1) / L;
    var lines = [line(x1, y1, x2, y2, 'dim')], arrows;
    if (L >= 2 * AL + 1) {
      arrows = [arrow(x1, y1, -ux, -uy), arrow(x2, y2, ux, uy)];
    } else {
      arrows = [arrow(x1, y1, ux, uy), arrow(x2, y2, -ux, -uy)];
      lines.push(line(x1 - ux * TAIL, y1 - uy * TAIL, x1, y1, 'dim'), line(x2, y2, x2 + ux * TAIL, y2 + uy * TAIL, 'dim'));
    }
    return { lines: lines, arrows: arrows };
  }

  function polySegs(pts, sign, close) {
    var out = [];
    for (var i = 1; i < pts.length; i++) out.push(line(pts[i - 1].z, sign * pts[i - 1].r, pts[i].z, sign * pts[i].r, 'outline'));
    if (close) out.push(line(pts[pts.length - 1].z, sign * pts[pts.length - 1].r, pts[0].z, sign * pts[0].r, 'outline'));
    return out;
  }

  function outlineSegments(g) {
    return polySegs(g.upper, -1, false).concat(polySegs(g.section.case, 1, true), polySegs(g.section.bullet, 1, true),
      [line(-3.5, 0, g.tip + 3, 0, 'centre')]);
  }

  function layout(g, rec) {
    var cc = rec.cartridge, h = cc.caseHead, pc = cc.powderChamber, col = cc.collar || {}, len = cc.lengths;
    var rm = g.rmax, rr = h.R1 / 2, tip = g.tip, dims = [], yBand;
    var label = function (sym, text, box, x, y, rot, anchor) { return { text: text, box: box, x: x, y: y, rot: rot, anchor: anchor || 'start' }; };
    var txt = function (sym, v) { return sym + ' ' + Fmt.num(v); };

    // lengths: ladder below, shortest nearest; R is the nearest row
    var head0 = g.outer[1].r;
    var rows = [{ sym: 'R', z: h.R, ext2: rr + EGAP, right: true }];
    var lr = [];
    if (g.bottleneck) lr.push({ sym: 'L1', z: len.L1, ext2: pc.P2 / 2 + EGAP }, { sym: 'L2', z: len.L2, ext2: col.H1 / 2 + EGAP });
    lr.push({ sym: 'L3', z: len.L3, ext2: col.H2 / 2 + EGAP });
    if (g.bullet) lr.push({ sym: 'L6', z: len.L6, ext2: g.bullet.m / 2 + EGAP });
    rows = rows.concat(lr.sort(function (a, b) { return a.z - b.z; }));
    rows.forEach(function (r, k) {
      var y = rm + ROW0 + ROWSTEP * k, d = dimLine(0, y, r.z, y), t = txt(r.sym, r.sym === 'R' ? h.R : len[r.sym]), w = tw(t);
      var lines = d.lines.concat([line(0, head0 + EGAP, 0, y + 1.2, 'ext'), line(r.z, r.ext2, r.z, y + 1.2, 'ext')]), box, lb;
      if (r.right) {
        // right of the arrow tail, or left of it when an extension line of a longer row is in the way
        var xr = r.z + TAIL + 0.6, limit = Math.min.apply(null, rows.slice(1).map(function (o) { return o.z; }));
        box = hbox(xr + w + 0.6 > limit ? -TAIL - 0.6 - w : xr, y + 0.3 * FS, w, FS);
        lb = label(r.sym, t, box, box.x0, y + 0.3 * FS, 0);
      } else {
        // centred above the line; left of the line when the text is longer than the dimension
        var x0 = w + 0.8 > r.z ? -1.2 - w : Math.max(r.z / 2 - w / 2, 0.4);
        box = hbox(x0, y - 1.4, w, FS);
        lb = label(r.sym, t, box, x0, y - 1.4, 0);
      }
      dims.push({ symbol: r.sym, kind: 'length', lines: lines, arrows: d.arrows, label: lb });
    });

    // diameters on the right: ladder beyond the tip, smallest nearest, labels in a band above
    var cols = [{ sym: 'P1', D: pc.P1, z0: g.bodyStart.z }];
    if (g.bottleneck) cols.push({ sym: 'P2', D: pc.P2, z0: len.L1 });
    if (has(col.H1)) cols.push({ sym: 'H1', D: col.H1, z0: len.L3 + EGAP });
    cols.push({ sym: 'H2', D: col.H2, z0: len.L3 + EGAP });
    if (g.bullet) cols.push({ sym: 'G1', D: rec.cartridge.projectile.G1, z0: g.bullet.zc });
    cols = cols.map(function (c, i) { c.i = i; return c; })
      .sort(function (a, b) { return a.D - b.D || a.i - b.i; });
    var maxD = Math.max.apply(null, cols.map(function (c) { return c.D; }));
    yBand = -(maxD / 2 + 3);
    cols.forEach(function (c, i) {
      var x = tip + 6 + 6 * i, t = txt(c.sym, c.D), w = tw(t), d = dimLine(x, -c.D / 2, x, c.D / 2);
      var lines = d.lines.concat([line(c.z0, -c.D / 2, x + 1.2, -c.D / 2, 'ext'), line(c.z0, c.D / 2, x + 1.2, c.D / 2, 'ext'),
        line(x, -c.D / 2, x, yBand, 'leader')]);
      var box = vbox(x + 0.35 + 0.95 * FS, yBand, w, FS);
      dims.push({ symbol: c.sym, kind: 'diameter', lines: lines, arrows: d.arrows,
        label: label(c.sym, t, box, x + 0.35 + 0.95 * FS, yBand, -90) });
    });

    // diameters on the left: groove (nearest), rim; labels above the head
    var lcols = [];
    if (g.groove) lcols.push({ sym: 'E1', D: g.groove.D, xs: h.R });
    lcols.push({ sym: 'R1', D: h.R1, xs: -0.6 });
    lcols.forEach(function (c, i) {
      var x = -6.5 - 5.5 * i, yb = -(rm + 3.5 + 5.5 * i), t = txt(c.sym, c.D), w = tw(t), d = dimLine(x, -c.D / 2, x, c.D / 2);
      var lines = d.lines.concat([line(c.xs, -c.D / 2, x - 1.2, -c.D / 2, 'ext'), line(c.xs, c.D / 2, x - 1.2, c.D / 2, 'ext'),
        line(x, -c.D / 2, x, yb, 'leader')]);
      var box = hbox(x + 0.8, yb, w, FS);
      dims.push({ symbol: c.sym, kind: 'diameter', lines: lines, arrows: d.arrows, label: label(c.sym, t, box, x + 0.8, yb, 0) });
    });

    // shoulder angle: detached wedge above the shoulder (the cone apex lies inside neck or bullet)
    if (g.bottleneck) {
      var a2 = g.alpha / 2 * DEG, Lr = 7, ra = 4.5, s = Math.sin(a2), c2 = Math.cos(a2);
      var ax = (len.L1 + len.L2) / 2 + 5, ay = -(rm + 1.8 + Lr * s);
      var arcLen = ra * 2 * a2, extra = arcLen < 3.5 ? 2.0 / ra : 0, th = a2 + extra;
      var p1 = [ax - ra * Math.cos(th), ay - ra * Math.sin(th)], p2 = [ax - ra * Math.cos(th), ay + ra * Math.sin(th)];
      var lines2 = [line(ax - Lr * c2, ay - Lr * s, ax, ay, 'ext'), line(ax - Lr * c2, ay + Lr * s, ax, ay, 'ext')];
      var arcPts = [], n = 12;
      for (var i = 0; i <= n; i++) {
        var t0 = -th + 2 * th * i / n;
        arcPts.push([ax - ra * Math.cos(t0), ay + ra * Math.sin(t0)]);
      }
      for (i = 1; i < arcPts.length; i++) lines2.push(line(arcPts[i - 1][0], arcPts[i - 1][1], arcPts[i][0], arcPts[i][1], 'dim'));
      // arrow tips on the rays, pointing along the arc
      var ta = a2, tipU = [ax - ra * Math.cos(ta), ay - ra * Math.sin(ta)], tipL = [ax - ra * Math.cos(ta), ay + ra * Math.sin(ta)];
      var dirU = [Math.sin(ta), -Math.cos(ta)], dirL = [Math.sin(ta), Math.cos(ta)];
      var sign = extra ? -1 : 1;
      var at = 'α ' + Fmt.angle(rec.cartridge.junctionCone.alpha), aw = tw(at), abox = hbox(ax + 1.5, ay + 0.3 * FS, aw, FS);
      dims.push({ symbol: 'α', kind: 'angle', lines: lines2, arc: arcPts,
        arrows: [arrow(tipU[0], tipU[1], sign * dirU[0], sign * dirU[1]), arrow(tipL[0], tipL[1], sign * dirL[0], sign * dirL[1])],
        label: label('α', at, abox, ax + 1.5, ay + 0.3 * FS, 0) });
      void p1; void p2;
    }

    // title block, lower right below the diameter ladder
    var name = rec.name, nw = tw(name, NF), tbw = Math.max(46, nw + 4), tx = tip + 4, ty = rm + 4;
    var tbox = { x0: tx, y0: ty, x1: tx + tbw, y1: ty + 32 };

    // view box
    var xs = [tbox.x1, -3.5, tip + 3], ys = [tbox.y1, -rm, rm];
    dims.forEach(function (d) {
      xs.push(d.label.box.x0, d.label.box.x1); ys.push(d.label.box.y0, d.label.box.y1);
      d.lines.forEach(function (l) { xs.push(l.x1, l.x2); ys.push(l.y1, l.y2); });
    });
    var x0 = Math.min.apply(null, xs) - 2, x1 = Math.max.apply(null, xs) + 2, y0 = Math.min.apply(null, ys) - 2, y1 = Math.max.apply(null, ys) + 2;
    var W = x1 - x0, scale = (PRINT_W / W).toFixed(1);
    return { dims: dims, viewBox: { x: x0, y: y0, w: W, h: y1 - y0 }, scale: scale,
      title: { box: tbox, name: name, nameSize: NF, lines: ['C.I.P. table ' + rec.tab, 'Revised ' + rec.revised, 'Dimensions in mm',
        'Scale ' + scale + ' : 1', '(' + PRINT_W + ' mm print width)'] } };
  }

  // ---- SVG ----------------------------------------------------------------------------------------

  function esc(s) { return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;'); }
  function f(n) { return String(Math.round(n * 1000) / 1000); }
  function pathD(pts, sign, close) {
    return pts.map(function (p, i) { return (i ? 'L' : 'M') + f(p.z) + ' ' + f(sign * p.r); }).join('') + (close ? 'Z' : '');
  }
  function arrowPath(a) {
    var bx = a.x - a.dx * AL, by = a.y - a.dy * AL, px = -a.dy * AH, py = a.dx * AH;
    return 'M' + f(a.x) + ' ' + f(a.y) + 'L' + f(bx + px) + ' ' + f(by + py) + 'L' + f(bx - px) + ' ' + f(by - py) + 'Z';
  }

  function missingNote(g) {
    return g.missing.length ? 'Not drawn, value not published: ' + g.missing.join(', ') + '.' : '';
  }

  function svg(rec) {
    var g = geometry(rec), l = layout(g, rec), v = l.viewBox, o = [], name = esc(rec.name);
    o.push('<svg xmlns="http://www.w3.org/2000/svg" class="drawing" viewBox="' + [f(v.x), f(v.y), f(v.w), f(v.h)].join(' ') +
      '" role="img" aria-label="' + name + ' drawing" preserveAspectRatio="xMidYMid meet">');
    o.push('<title>' + name + ' drawing</title>');
    o.push('<desc>Outside view above the axis, section below, dimensions in mm, rim type ' + g.rimType +
      (g.missing.length ? '. ' + esc(missingNote(g)) : '') + '</desc>');
    o.push('<defs><pattern id="hatch-case" width="1" height="1" patternUnits="userSpaceOnUse" patternTransform="rotate(45)">' +
      '<line class="hatch" x1="0" y1="0" x2="0" y2="1"/></pattern>' +
      '<pattern id="hatch-bullet" width="1.6" height="1.6" patternUnits="userSpaceOnUse" patternTransform="rotate(-45)">' +
      '<line class="hatch hatch-bullet" x1="0" y1="0" x2="0" y2="1.6"/></pattern></defs>');
    o.push('<rect class="frame" x="' + f(v.x + 0.6) + '" y="' + f(v.y + 0.6) + '" width="' + f(v.w - 1.2) + '" height="' + f(v.h - 1.2) + '"/>');
    o.push('<path class="outline surface" d="' + pathD(g.upper, -1, true) + '"/>');
    o.push('<path class="outline cut" fill="url(#hatch-case)" d="' + pathD(g.section.case, 1, true) + '"/>');
    if (g.section.bullet.length) o.push('<path class="outline cut" fill="url(#hatch-bullet)" d="' + pathD(g.section.bullet, 1, true) + '"/>');
    o.push('<path class="centre" d="M-3.5 0L' + f(g.tip + 3) + ' 0"/>');
    l.dims.forEach(function (d) {
      o.push('<g class="dim" data-symbol="' + esc(d.symbol) + '">');
      d.lines.forEach(function (s) {
        o.push('<line class="' + s.type + '-line" x1="' + f(s.x1) + '" y1="' + f(s.y1) + '" x2="' + f(s.x2) + '" y2="' + f(s.y2) + '"/>');
      });
      d.arrows.forEach(function (a) { o.push('<path class="arrow" d="' + arrowPath(a) + '"/>'); });
      var b = d.label;
      o.push('<text class="dim-label" font-size="' + FS + '" x="' + f(b.x) + '" y="' + f(b.y) + '"' +
        (b.rot ? ' transform="rotate(' + b.rot + ' ' + f(b.x) + ' ' + f(b.y) + ')"' : '') + '>' + esc(b.text) + '</text>');
      o.push('</g>');
    });
    var t = l.title, tb = t.box;
    o.push('<g class="title-block"><rect class="frame" x="' + f(tb.x0) + '" y="' + f(tb.y0) + '" width="' + f(tb.x1 - tb.x0) +
      '" height="' + f(tb.y1 - tb.y0) + '"/>');
    o.push('<text class="title-name" font-size="' + t.nameSize + '" x="' + f(tb.x0 + 2) + '" y="' + f(tb.y0 + 5.8) + '">' + esc(t.name) + '</text>');
    t.lines.forEach(function (s, i) {
      o.push('<text class="title-line" font-size="' + TF + '" x="' + f(tb.x0 + 2) + '" y="' + f(tb.y0 + 11.5 + 4.3 * i) + '">' + esc(s) + '</text>');
    });
    o.push('</g></svg>');
    return o.join('\n');
  }

  var api = { rimType: rimType, geometry: geometry, fillet: fillet, deg: deg, layout: layout, svg: svg, esc: esc,
    outlineSegments: outlineSegments, missingNote: missingNote };
  if (typeof module === 'object' && module.exports) module.exports = api;
  else root.Drawing = api;
})(globalThis);
