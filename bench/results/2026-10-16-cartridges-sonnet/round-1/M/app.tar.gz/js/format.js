// Pure formatting and filtering helpers. No DOM.
(function (root) {
  var SYMBOLS = {
    eMin: 'e min', r1Min: 'r1 min', r1Max: 'r1 max', alpha: 'α', alpha1: 'α1', beta: 'β', delta: 'δ',
    deltaL: 'delta L', L3PlusG: 'L3 + G'
  };
  var ANGLES = { alpha: 1, alpha1: 1, beta: 1, delta: 1, i: 1 };
  var UNITS = { Pmax: 'bar', PK: 'bar', PE: 'bar', EE: 'J', M: 'g', Q: 'mm²', N: '' };
  var SECTIONS = {
    cartridge: [
      ['caseHead', 'Case head'], ['collar', 'Collar'], ['junctionCone', 'Junction cone'], ['lengths', 'Lengths'],
      ['misc', 'Misc'], ['powderChamber', 'Powder chamber'], ['pressures', 'Pressures'], ['projectile', 'Projectile']
    ],
    chamber: [
      ['barrel', 'Barrel'], ['breech', 'Breech'], ['collar', 'Collar'], ['grooves', 'Grooves'],
      ['junctionCone', 'Junction cone'], ['lengths', 'Lengths'], ['powderChamber', 'Powder chamber'], ['rifling', 'Rifling']
    ]
  };

  function num(n) { return String(n); }

  function angle(a) {
    if (typeof a === 'number') return num(a) + '°';
    return num(a.degrees) + '°' + num(a.minutes) + "'" + num(a.seconds) + '"';
  }

  function symbol(key) { return Object.prototype.hasOwnProperty.call(SYMBOLS, key) ? SYMBOLS[key] : key; }

  function unit(key) {
    if (ANGLES[key]) return 'deg';
    return Object.prototype.hasOwnProperty.call(UNITS, key) ? UNITS[key] : 'mm';
  }

  function tol(t) { return (t > 0 ? '+' : '') + num(t); }

  // Value of `key` in `sec`, with its tolerance next to it.
  function valueText(sec, key) {
    var v = ANGLES[key] ? angle(sec[key]) : num(sec[key]);
    return (key + 'Tol') in sec ? v + ' ' + tol(sec[key + 'Tol']) : v;
  }

  function sectionRows(sec) {
    return Object.keys(sec)
      .filter(function (k) { return !(/Tol$/.test(k) && k.slice(0, -3) in sec); })
      .map(function (k) { return { symbol: symbol(k), value: valueText(sec, k), unit: unit(k) }; });
  }

  function sections(rec, group) {
    return SECTIONS[group]
      .filter(function (s) { return rec[group][s[0]] && Object.keys(rec[group][s[0]]).length; })
      .map(function (s) { return { key: s[0], title: s[1], rows: sectionRows(rec[group][s[0]]) }; });
  }

  function l3Text(rec) { return valueText(rec.cartridge.lengths, 'L3') + ' mm'; }

  function capacityText(rec) {
    var c = rec.annotations && rec.annotations.publishedCapacity;
    return c ? num(c.grH2O) + ' gr H2O' : '';
  }

  // Lower case, no spaces, "," and "." alike: "7,62 x 51" and "7.62x51" match the same names.
  function norm(s) { return String(s).toLowerCase().replace(/\s+/g, '').replace(/,/g, '.'); }

  function filter(list, query, family) {
    var q = norm(query);
    return list.filter(function (c) {
      if (family && family !== 'all' && c.family !== family) return false;
      return !q || [c.name].concat(c.alternativeNames || []).some(function (n) { return norm(n).indexOf(q) !== -1; });
    });
  }

  var api = {
    num: num, angle: angle, symbol: symbol, unit: unit, valueText: valueText, sectionRows: sectionRows,
    sections: sections, l3Text: l3Text, capacityText: capacityText, filter: filter
  };
  if (typeof module === 'object' && module.exports) module.exports = api;
  else root.Format = api;
})(globalThis);
