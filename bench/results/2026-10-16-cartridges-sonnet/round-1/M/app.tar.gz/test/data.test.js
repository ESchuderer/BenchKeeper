const test = require('node:test');
const assert = require('node:assert/strict');
const C = require('../js/data.js');

test('25 records with unique keys and names', () => {
  assert.equal(C.length, 25);
  assert.equal(new Set(C.map((c) => c.key)).size, 25);
  assert.equal(new Set(C.map((c) => c.name)).size, 25);
});

test('records keep published values', () => {
  const r = C.find((c) => c.key === '308_win');
  assert.equal(r.cartridge.lengths.L3, 51.18);
  assert.equal(r.cartridge.pressures.Pmax, 4150);
  assert.deepEqual(r.alternativeNames, ['308 Winchester', '7,62 x 51']);
  assert.equal(C.find((c) => c.key === '6_5_creedmoor').name, '6,5 Creedmoor');
  assert.deepEqual(C.find((c) => c.key === '223_rem').chamber.rifling.i, { degrees: 3, minutes: 10, seconds: 36 });
});

test('every record has the fields the app reads', () => {
  for (const c of C) {
    for (const k of ['key', 'name', 'family', 'tab', 'country', 'published', 'revised', 'pressureMethod']) assert.ok(c[k], c.key + ' ' + k);
    assert.ok(c.cartridge.lengths.L3 > 0 && c.cartridge.lengths.L6 > 0, c.key);
    assert.ok(c.cartridge.caseHead.R1 > 0 && c.cartridge.powderChamber.P1 > 0, c.key);
    assert.ok(['rimless', 'rimmed', 'belted', 'pistol', 'rimfire'].includes(c.family), c.key);
  }
});
