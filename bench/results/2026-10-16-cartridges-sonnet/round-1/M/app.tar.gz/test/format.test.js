const test = require('node:test');
const assert = require('node:assert/strict');
const F = require('../js/format.js');
const C = require('../js/data.js');
const rec = (k) => C.find((c) => c.key === k);

test('numbers as published', () => {
  assert.equal(F.num(51.18), '51.18');
  assert.equal(F.num(4150.0), '4150');
  assert.equal(F.num(0), '0');
  assert.equal(F.num(-0.2), '-0.2');
});

test('angles', () => {
  assert.equal(F.angle(40), '40°');
  assert.equal(F.angle({ degrees: 39, minutes: 59, seconds: 49 }), '39°59\'49"');
  assert.equal(F.angle({ degrees: 34, minutes: 30, seconds: 0 }), '34°30\'0"');
});

test('symbols', () => {
  assert.equal(F.symbol('eMin'), 'e min');
  assert.equal(F.symbol('r1Min'), 'r1 min');
  assert.equal(F.symbol('r1Max'), 'r1 max');
  assert.equal(F.symbol('alpha'), 'α');
  assert.equal(F.symbol('alpha1'), 'α1');
  assert.equal(F.symbol('beta'), 'β');
  assert.equal(F.symbol('delta'), 'δ');
  assert.equal(F.symbol('deltaL'), 'delta L');
  assert.equal(F.symbol('L3PlusG'), 'L3 + G');
  assert.equal(F.symbol('Pmax'), 'Pmax');
});

test('units', () => {
  assert.equal(F.unit('Pmax'), 'bar');
  assert.equal(F.unit('PK'), 'bar');
  assert.equal(F.unit('PE'), 'bar');
  assert.equal(F.unit('EE'), 'J');
  assert.equal(F.unit('M'), 'g');
  assert.equal(F.unit('Q'), 'mm²');
  assert.equal(F.unit('N'), '');
  assert.equal(F.unit('L3'), 'mm');
  assert.equal(F.unit('alpha'), 'deg');
});

test('tolerance is shown next to its value and never as its own row', () => {
  const rows = F.sectionRows(rec('308_win').cartridge.lengths);
  assert.deepEqual(rows.map((r) => r.symbol), ['L1', 'L2', 'L3', 'L6']);
  assert.deepEqual(rows[0], { symbol: 'L1', value: '39.62 -0.2', unit: 'mm' });
  assert.equal(rows[2].value, '51.18');
  assert.equal(F.sectionRows(rec('300_win_mag').cartridge.caseHead).find((r) => r.symbol === 'E').value, '5.59 -0.2');
});

test('angle rows', () => {
  const rows = F.sectionRows(rec('223_rem').chamber.rifling);
  assert.equal(rows.find((r) => r.symbol === 'i').value, '3°10\'36"');
  assert.equal(rows.find((r) => r.symbol === 'α1').value, '90°');
  assert.equal(rows.find((r) => r.symbol === 'i').unit, 'deg');
});

test('sections: fixed order, empty skipped, titles', () => {
  const s = F.sections(rec('9_mm_luger'), 'cartridge');
  assert.deepEqual(s.map((x) => x.title), ['Case head', 'Collar', 'Lengths', 'Misc', 'Powder chamber', 'Pressures', 'Projectile']);
  const ch = F.sections(rec('9_mm_luger'), 'chamber');
  assert.deepEqual(ch.map((x) => x.title), ['Barrel', 'Breech', 'Collar', 'Grooves', 'Lengths', 'Powder chamber', 'Rifling']);
});

test('every record: all non-tolerance values appear, each tolerance is merged', () => {
  for (const c of C) {
    for (const group of ['cartridge', 'chamber']) {
      let expected = 0;
      for (const sec of Object.values(c[group])) {
        for (const k of Object.keys(sec)) if (!/Tol$/.test(k) || !(k.slice(0, -3) in sec)) expected++;
      }
      const got = F.sections(c, group).reduce((n, s) => n + s.rows.length, 0);
      assert.equal(got, expected, c.key + ' ' + group);
    }
  }
});

test('L3 text for the list includes tolerance', () => {
  assert.equal(F.l3Text(rec('308_win')), '51.18 mm');
  assert.equal(F.l3Text(rec('9_mm_luger')), '19.15 -0.25 mm');
});

test('search: names, alternative names, case, spaces, comma and dot', () => {
  const names = (q, fam) => F.filter(C, q, fam || 'all').map((c) => c.name);
  assert.deepEqual(names('7,62 x 51'), ['308 Win.']);
  assert.deepEqual(names('7.62x51'), ['308 Win.']);
  assert.deepEqual(names('308 WINCHESTER'), ['308 Win.']);
  assert.deepEqual(names('creed'), ['6,5 Creedmoor']);
  assert.equal(names('').length, 25);
  assert.equal(names('  ').length, 25);
  assert.deepEqual(names('zzz'), []);
  assert.deepEqual(names('22lr'), ['22 Long Rifle']);
});

test('family filter', () => {
  const n = (f) => F.filter(C, '', f).length;
  assert.equal(n('all'), 25);
  assert.equal(n('rimless') + n('rimmed') + n('belted') + n('pistol') + n('rimfire'), 25);
  assert.equal(n('belted'), 2);
  assert.equal(n('rimmed'), 2);
  assert.equal(n('rimfire'), 3);
  assert.equal(F.filter(C, '9', 'pistol').every((c) => c.family === 'pistol'), true);
});

test('capacity text', () => {
  assert.equal(F.capacityText(rec('308_win')), '56 gr H2O');
  assert.equal(F.capacityText(rec('7_x_64')), '');
});
