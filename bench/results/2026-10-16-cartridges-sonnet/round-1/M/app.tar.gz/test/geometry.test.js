const test = require('node:test');
const assert = require('node:assert/strict');
const D = require('../js/drawing.js');
const C = require('../js/data.js');
const rec = (k) => C.find((c) => c.key === k);
const near = (a, b, eps = 1e-6) => assert.ok(Math.abs(a - b) <= eps, a + ' != ' + b);
const has = (pts, z, r) => pts.some((p) => Math.abs(p.z - z) < 1e-6 && Math.abs(p.r - r) < 1e-6);

test('rim type', () => {
  assert.equal(D.rimType(rec('308_win')), 'rimless');
  assert.equal(D.rimType(rec('6_5_x_55_se')), 'rimless');
  assert.equal(D.rimType(rec('9_3_x_74_r')), 'rimmed');
  assert.equal(D.rimType(rec('38_special')), 'rimmed');
  assert.equal(D.rimType(rec('300_win_mag')), 'belted');
  assert.equal(D.rimType(rec('22_long_rifle')), 'rimfire');
  const r = JSON.parse(JSON.stringify(rec('308_win')));
  r.cartridge.caseHead.R1 = r.cartridge.powderChamber.P1 * 0.97;
  assert.equal(D.rimType(r), 'rebated');
  r.cartridge.caseHead.R1 = r.cartridge.powderChamber.P1 * 1.05;
  assert.equal(D.rimType(r), 'rimmed');
  r.cartridge.caseHead.R1 = r.cartridge.powderChamber.P1 * 0.98;
  assert.equal(D.rimType(r), 'rimless');
});

test('308 outer profile: chamfer, rim, groove, body, shoulder, neck', () => {
  const g = D.geometry(rec('308_win'));
  const o = g.outer;
  assert.deepEqual(o[0], { z: 0, r: 0 });
  const c = Math.min(0.38 * Math.tan(35 * Math.PI / 180), 12.01 / 4);
  assert.ok(has(o, 0, 12.01 / 2 - c));
  assert.ok(has(o, 0.38, 12.01 / 2));
  assert.ok(has(o, 1.37, 12.01 / 2));
  assert.ok(has(o, 1.37, 10.39 / 2));
  assert.ok(has(o, 1.37 + 1.4, 10.39 / 2));
  assert.ok(has(o, 3.85, 11.96 / 2));
  assert.deepEqual(o[o.length - 1], { z: 51.18, r: 8.72 / 2 });
  assert.equal(g.rimType, 'rimless');
  assert.equal(g.bottleneck, true);
  assert.deepEqual(g.missing, []);
  // z never decreases after the rim edge, r never exceeds the rim radius
  for (let i = 1; i < o.length; i++) assert.ok(o[i].z >= o[i - 1].z - 1e-9 || i < 3);
  assert.ok(Math.max(...o.map((p) => p.r)) <= 12.01 / 2 + 1e-9);
});

test('shoulder passes through published points when no fillet applies', () => {
  const g = D.geometry(rec('308_win'));
  // fillet tangent points lie on the shoulder line
  const a = { z: 39.62, r: 11.53 / 2 }, b = { z: 43.48, r: 8.72 / 2 };
  const slope = (b.r - a.r) / (b.z - a.z);
  // the longest segment between the two fillets is the straight shoulder
  const seg = g.outer.slice(1).map((p, i) => [g.outer[i], p]).filter(([p, q]) => p.z >= a.z && q.z <= b.z)
    .sort((x, y) => (y[1].z - y[0].z) - (x[1].z - x[0].z))[0];
  assert.ok(seg[1].z - seg[0].z > 2);
  for (const p of seg) near(p.r, a.r + slope * (p.z - a.z), 1e-6);
  // half cone angle of the published points is alpha/2
  near(Math.atan(-slope) / (Math.PI / 180) * 2, 40, 0.1);
});

test('fillet is tangent and stays inside the corner', () => {
  const g = D.geometry(rec('6_5_x_55_se'));
  const pts = g.outer.filter((p) => p.z > 43.49 - 1.5 && p.z < 43.49 + 1.5);
  assert.ok(pts.length > 4);
  // no point lies outside the sharp corner polyline
  for (const p of pts) assert.ok(p.r <= 12.2 / 2 + 1e-9);
});

test('missing values are named, not invented', () => {
  assert.deepEqual(D.geometry(rec('338_lapua_mag')).missing, ['r1 min']);
  assert.deepEqual(D.geometry(rec('17_hmr')).missing, ['r1 min', 'r2']);
  for (const k of ['308_win', '9_mm_luger', '22_long_rifle', '9_3_x_74_r', '300_win_mag']) assert.deepEqual(D.geometry(rec(k)).missing, [], k);
  const r = JSON.parse(JSON.stringify(rec('308_win')));
  delete r.cartridge.caseHead.eMin;
  const g = D.geometry(r);
  assert.deepEqual(g.missing, ['e min']);
  assert.ok(!has(g.outer, 1.37, 10.39 / 2));
});

test('straight case runs to (H2/2, L3)', () => {
  const g = D.geometry(rec('9_mm_luger'));
  assert.equal(g.bottleneck, false);
  assert.deepEqual(g.outer[g.outer.length - 1], { z: 19.15, r: 9.65 / 2 });
  assert.ok(has(g.outer, 2.98, 9.93 / 2));
});

test('rimmed case without groove steps in at z = R', () => {
  const g = D.geometry(rec('9_3_x_74_r'));
  assert.ok(has(g.outer, 1.4, 13.35 / 2));
  assert.ok(has(g.outer, 1.4, 11.9 / 2));
  assert.deepEqual(g.missing, []);
});

test('belted: ramp at delta to the belt, belt to E, step in', () => {
  const g = D.geometry(rec('300_win_mag'));
  const zr = 1.27 + 0.94 + (13.51 / 2 - 12.07 / 2) / Math.tan(35 * Math.PI / 180);
  assert.ok(has(g.outer, zr, 13.51 / 2));
  assert.ok(has(g.outer, 5.59, 13.51 / 2));
  assert.ok(has(g.outer, 5.59, 13.03 / 2));
  near(g.beltRampEnd, zr);
});

test('rimfire rim edge is a half-round with its outermost point at R1/2', () => {
  const g = D.geometry(rec('22_long_rifle'));
  const rho = Math.min(1.09 / 2, (7.06 - 5.74) / 2);
  assert.ok(has(g.outer, rho, 7.06 / 2));
  near(Math.max(...g.outer.map((p) => p.r)), 7.06 / 2);
  assert.ok(has(g.outer, 0, 7.06 / 2 - rho));
  assert.ok(has(g.outer, 1.09, 5.74 / 2));
});

test('pointy bullet: seating, cylinder, meplat, tangent ogive', () => {
  const g = D.geometry(rec('308_win'));
  const b = g.bullet;
  near(b.s, 7.85);
  near(b.zb, 51.18 - 7.85);
  near(b.zc, b.zb + 0.4 * (71.12 - b.zb));
  near(b.m, 1.27);
  const tip = b.nose[b.nose.length - 1];
  near(tip.z, 71.12);
  near(tip.r, 1.27 / 2);
  const n = 71.12 - b.zc, a = 7.85 / 2 - 1.27 / 2, rho = (a * a + n * n) / (2 * a);
  const cr = 7.85 / 2 - rho;
  for (const p of b.nose) near(Math.hypot(p.z - b.zc, p.r - cr), rho, 1e-6);
  near(b.nose[0].r, 7.85 / 2);
  assert.equal(b.shape, 'pointy');
});

test('bullet seating and meplat by shape and class', () => {
  const m = (k) => D.geometry(rec(k)).bullet;
  near(m('9_mm_luger').s, 0.4 * 9.03);
  near(m('9_mm_luger').m, 0.15 * 9.03);
  near(m('9_mm_luger').zc, m('9_mm_luger').zb + 0.65 * (29.69 - m('9_mm_luger').zb));
  near(m('40_s_w').s, 0.4 * 10.17);
  near(m('40_s_w').m, 0.55 * 10.17);
  near(m('40_s_w').zc, m('40_s_w').zb + 0.70 * (28.83 - m('40_s_w').zb));
  near(m('357_magnum').s, 0.6 * 9.12);
  near(m('357_magnum').m, 0.6 * 9.12);
  near(m('357_magnum').zc, m('357_magnum').zb + 0.78 * (40.39 - m('357_magnum').zb));
  near(m('22_win_mag_r_f').s, 0.8 * 5.7);
  near(m('22_win_mag_r_f').zc, m('22_win_mag_r_f').zb + 0.55 * (34.29 - m('22_win_mag_r_f').zb));
  near(m('17_hmr').s, 4.38);
  near(m('17_hmr').m, 1.27);
});

test('rounded nose is a quarter ellipse ending in the meplat', () => {
  const b = D.geometry(rec('9_mm_luger')).bullet;
  const tip = b.nose[b.nose.length - 1];
  near(tip.z, 29.69);
  near(tip.r, b.m / 2);
  near(b.nose[0].r, 9.03 / 2);
});

test('heeled case (22 LR): exposed bullet is case diameter, heel is inside diameter', () => {
  const g = D.geometry(rec('22_long_rifle'));
  assert.equal(g.heeled, true);
  near(g.bullet.re, 5.72 / 2);
  near(g.bullet.rs, 5.72 / 2 - g.tb);
  assert.equal(D.geometry(rec('22_win_mag_r_f')).heeled, false);
});

test('walls and solid head', () => {
  const g = D.geometry(rec('308_win'));
  near(g.tn, (8.72 - 7.85) / 2);
  near(g.tb, Math.min(Math.max(1.3 * g.tn, 0.6), 0.35 * 11.96 / 2));
  near(g.w, Math.max(2.5, 0.25 * 11.96 / 2, 3.3 + 1.5, 3.85 + g.tb));
  assert.deepEqual(g.pocket, { d: 5.33, depth: 3.3 });
  const s = D.geometry(rec('223_rem'));
  assert.deepEqual(s.pocket, { d: 4.45, depth: 3.04 });
  assert.deepEqual(D.geometry(rec('45_auto')).pocket, { d: 5.33, depth: 3.04 });
  assert.equal(D.geometry(rec('22_long_rifle')).pocket, null);
  near(D.geometry(rec('22_long_rifle')).w, 2.5);
  // belted: head length uses the belt ramp end
  const b = D.geometry(rec('300_win_mag'));
  near(b.w, Math.max(2.5, 0.25 * 13.03 / 2, 3.3 + 1.5, b.beltRampEnd + b.tb));
});

test('inner line follows the outer at tb on the body and tn on the neck', () => {
  const g = D.geometry(rec('308_win'));
  const at = (z) => {
    for (let i = 1; i < g.inner.length; i++) {
      const a = g.inner[i - 1], b = g.inner[i];
      if (z >= a.z - 1e-9 && z <= b.z + 1e-9) return a.r + (b.r - a.r) * (z - a.z) / (b.z - a.z || 1);
    }
    throw new Error('z not on inner ' + z);
  };
  near(at(30), (11.96 / 2 + (11.53 / 2 - 11.96 / 2) * (30 - 3.85) / (39.62 - 3.85)) - g.tb, 1e-3);
  near(at(48), 8.72 / 2 - g.tn, 1e-3);
  assert.ok(g.inner[0].z === g.w || Math.abs(g.inner[0].z - g.w) < 1e-9);
  assert.ok(Math.abs(g.inner[g.inner.length - 1].z - 51.18) < 1e-9);
});

test('section polygons are closed shapes inside the outline', () => {
  for (const c of C) {
    const g = D.geometry(c);
    assert.ok(g.section.case.length > 8, c.key);
    const rmax = Math.max(...g.outer.map((p) => p.r));
    for (const p of g.section.case) assert.ok(p.r >= -1e-9 && p.r <= rmax + 1e-9 && p.z >= -1e-9, c.key);
    for (const p of g.section.bullet) assert.ok(p.r >= -1e-9 && p.z <= c.cartridge.lengths.L6 + 1e-9, c.key);
    // bullet seated part sits inside the case bore
    for (const p of g.section.bullet) {
      if (p.z >= g.bullet.zb - 1e-9 && p.z <= c.cartridge.lengths.L3 && (p.z < c.cartridge.lengths.L3 - 1e-9 || p.r <= g.bullet.rs + 1e-9)) {
        const ri = g.innerR(p.z);
        assert.ok(p.r <= ri + 1e-6, c.key + ' bullet wider than bore at ' + p.z + ': ' + p.r + ' > ' + ri);
      }
    }
  }
});

test('partial shoulder data is reported, no shoulder is invented', () => {
  for (const [path, name] of [['alpha', 'α'], ['L1', 'L1'], ['L2', 'L2']]) {
    const r = JSON.parse(JSON.stringify(rec('308_win')));
    if (path === 'alpha') delete r.cartridge.junctionCone.alpha; else delete r.cartridge.lengths[path];
    const g = D.geometry(r);
    assert.equal(g.bottleneck, false);
    assert.deepEqual(g.missing, [name]);
  }
  const r = JSON.parse(JSON.stringify(rec('9_mm_luger')));
  delete r.annotations.category;
  assert.deepEqual(D.geometry(r).missing, ['category']);
});
