const test = require('node:test');
const assert = require('node:assert/strict');
const D = require('../js/drawing.js');
const C = require('../js/data.js');
const rec = (k) => C.find((c) => c.key === k);

const L = (c) => { const g = D.geometry(c); return { g, l: D.layout(g, c) }; };
const segsOf = (l) => {
  const out = [];
  for (const d of l.dims) for (const s of d.lines) out.push({ x1: s.x1, y1: s.y1, x2: s.x2, y2: s.y2, owner: d.symbol, type: s.type });
  return out;
};
// Cohen-Sutherland style segment/box intersection
function hits(s, b) {
  const inside = (x, y) => x > b.x0 && x < b.x1 && y > b.y0 && y < b.y1;
  if (inside(s.x1, s.y1) || inside(s.x2, s.y2)) return true;
  const edges = [[b.x0, b.y0, b.x1, b.y0], [b.x1, b.y0, b.x1, b.y1], [b.x1, b.y1, b.x0, b.y1], [b.x0, b.y1, b.x0, b.y0]];
  const ccw = (ax, ay, bx, by, cx, cy) => (cy - ay) * (bx - ax) > (by - ay) * (cx - ax);
  return edges.some(([x3, y3, x4, y4]) =>
    ccw(s.x1, s.y1, x3, y3, x4, y4) !== ccw(s.x2, s.y2, x3, y3, x4, y4) &&
    ccw(s.x1, s.y1, s.x2, s.y2, x3, y3) !== ccw(s.x1, s.y1, s.x2, s.y2, x4, y4));
}
const overlap = (a, b) => a.x0 < b.x1 && b.x0 < a.x1 && a.y0 < b.y1 && b.y0 < a.y1;

test('required dimensions exist on every cartridge, with symbol and value labels', () => {
  for (const c of C) {
    const { l } = L(c);
    const sym = l.dims.map((d) => d.symbol);
    for (const s of ['L3', 'L6', 'R1', 'R', 'P1']) assert.ok(sym.includes(s), c.key + ' ' + s);
    const txt = (s) => l.dims.find((d) => d.symbol === s).label.text;
    assert.equal(txt('L3'), 'L3 ' + String(c.cartridge.lengths.L3));
    assert.equal(txt('R1'), 'R1 ' + String(c.cartridge.caseHead.R1));
  }
  assert.equal(L(rec('308_win')).l.dims.find((d) => d.symbol === 'L3').label.text, 'L3 51.18');
});

test('optional dimensions appear where published', () => {
  const sym = (k) => L(rec(k)).l.dims.map((d) => d.symbol);
  for (const s of ['P2', 'H1', 'H2', 'G1', 'L1', 'L2', 'E1', 'α']) assert.ok(sym('308_win').includes(s), s);
  assert.ok(!sym('9_mm_luger').includes('P2') && !sym('9_mm_luger').includes('L1') && !sym('9_mm_luger').includes('α'));
  assert.ok(sym('9_mm_luger').includes('E1') && sym('9_mm_luger').includes('H2') && sym('9_mm_luger').includes('G1'));
  assert.ok(!sym('9_3_x_74_r').includes('E1'));
  assert.equal(L(rec('308_win')).l.dims.find((d) => d.symbol === 'α').label.text, 'α 40°');
  assert.equal(L(rec('6_5_x_55_se')).l.dims.find((d) => d.symbol === 'α').label.text, 'α 50°35\'2"');
});

test('every dimension has a dimension line, arrowheads and extension lines', () => {
  for (const c of C) {
    for (const d of L(c).l.dims) {
      assert.ok(d.arrows.length >= 2, c.key + ' ' + d.symbol + ' arrows');
      assert.ok(d.lines.some((s) => s.type === 'dim'), c.key + ' ' + d.symbol + ' dim line');
      if (d.symbol !== 'α' && d.symbol !== 'E1') assert.ok(d.lines.filter((s) => s.type === 'ext').length >= 2, c.key + ' ' + d.symbol + ' ext lines');
    }
  }
});

test('labels overlap neither each other, nor lines, nor the outline', () => {
  for (const c of C) {
    const { g, l } = L(c);
    const boxes = l.dims.map((d) => ({ id: d.symbol, b: d.label.box })).concat([{ id: 'title', b: l.title.box }]);
    for (let i = 0; i < boxes.length; i++) for (let j = i + 1; j < boxes.length; j++) {
      assert.ok(!overlap(boxes[i].b, boxes[j].b), c.key + ': ' + boxes[i].id + ' overlaps ' + boxes[j].id);
    }
    const segs = segsOf(l).concat(D.outlineSegments(g));
    for (const bx of boxes) for (const s of segs) {
      assert.ok(!hits(s, bx.b), c.key + ': label ' + bx.id + ' hit by ' + (s.owner || 'outline') + ' ' + JSON.stringify(s));
    }
  }
});

test('everything fits the view box', () => {
  for (const c of C) {
    const { l } = L(c);
    const v = l.viewBox;
    for (const d of l.dims) {
      const b = d.label.box;
      assert.ok(b.x0 >= v.x && b.x1 <= v.x + v.w && b.y0 >= v.y && b.y1 <= v.y + v.h, c.key + ' ' + d.symbol);
      for (const s of d.lines) assert.ok(s.x1 >= v.x && s.x2 <= v.x + v.w + 1e-9 && Math.min(s.y1, s.y2) >= v.y && Math.max(s.y1, s.y2) <= v.y + v.h, c.key + ' line ' + d.symbol);
    }
    assert.ok(l.title.box.x1 <= v.x + v.w && l.title.box.y1 <= v.y + v.h);
  }
});

test('svg: accessible name, mm viewBox, escaped text, title block', () => {
  for (const c of C) {
    const s = D.svg(c);
    assert.ok(s.startsWith('<svg'), c.key);
    assert.ok(s.includes('aria-label="' + D.esc(c.name) + ' drawing"'), c.key);
    assert.ok(s.includes('Dimensions in mm'), c.key);
    assert.ok(s.includes('C.I.P. table ' + c.tab), c.key);
    assert.ok(s.includes(c.revised), c.key);
    assert.ok(/Scale \d+(\.\d)? : 1/.test(s), c.key);
    assert.ok(!/&(?!amp;|lt;|gt;|quot;|#)/.test(s), c.key + ' unescaped &');
    assert.ok(s.includes('class="centre"'), c.key);
  }
  assert.ok(D.svg(rec('40_s_w')).includes('40 S.&amp; W. drawing'));
});

test('missing note names the missing values', () => {
  assert.equal(D.missingNote(D.geometry(rec('308_win'))), '');
  assert.equal(D.missingNote(D.geometry(rec('338_lapua_mag'))), 'Not drawn, value not published: r1 min.');
  assert.equal(D.missingNote(D.geometry(rec('17_hmr'))), 'Not drawn, value not published: r1 min, r2.');
});
