/* Start page, detail view and routing. */
(function () {
  var records = window.CARTRIDGES;
  var PRINT_WIDTH_PX = 718; // 190 mm: A4 portrait with 10 mm margins

  var listView = document.getElementById('list-view');
  var detailView = document.getElementById('detail-view');
  var search = document.getElementById('search');
  var family = document.getElementById('family');
  var listBody = document.getElementById('list-body');
  var count = document.getElementById('count');
  var empty = document.getElementById('list-empty');
  var redraw = null; // redraws the drawing of the open detail view

  function h(tag, attrs) {
    var el = document.createElement(tag);
    Object.keys(attrs || {}).forEach(function (k) {
      if (k === 'text') el.textContent = attrs[k];
      else el.setAttribute(k, attrs[k]);
    });
    for (var i = 2; i < arguments.length; i++) {
      var c = arguments[i];
      if (c !== null && c !== undefined) el.appendChild(typeof c === 'string' ? document.createTextNode(c) : c);
    }
    return el;
  }

  // ---- start page ----------------------------------------------------------------------------
  function renderList() {
    var rows = Catalog.filter(records, search.value, family.value);
    listBody.textContent = '';
    rows.forEach(function (r) {
      listBody.appendChild(h('tr', {},
        h('th', { scope: 'row' }, h('a', { href: Catalog.detailHref(r), text: r.name })),
        h('td', { text: r.family }),
        h('td', { class: 'num', text: Format.num(r.cartridge.lengths.L3) + ' mm' })));
    });
    count.textContent = Catalog.countText(rows.length);
    empty.hidden = rows.length > 0;
  }

  // ---- detail view ---------------------------------------------------------------------------
  function fact(label, value) { return h('div', {}, h('dt', { text: label }), h('dd', {}, value)); }

  function renderFacts(r) {
    var cap = Format.capacity(r);
    var capValue = 'not published';
    if (cap) {
      capValue = h('span', {}, cap.text + ' (', h('a', { href: cap.url, rel: 'noopener noreferrer', text: cap.source }), ')' + (cap.note ? ', ' + cap.note : ''));
    }
    return h('dl', { class: 'facts' },
      fact('Alternative names', (r.alternativeNames || []).join(', ') || 'none'),
      fact('Family', r.family),
      fact('Category', r.annotations.category),
      fact('Primer type', r.annotations.primerType),
      fact('C.I.P. table', r.tab),
      fact('Country', r.country),
      fact('Published', r.published),
      fact('Revised', r.revised),
      fact('Pressure method', r.pressureMethod),
      fact('Water capacity', capValue));
  }

  function renderTables(r) {
    var wrap = h('div', { class: 'tables' });
    Format.groups(r).forEach(function (g) {
      var col = h('section', { class: 'table-group' }, h('h2', { text: g.title }));
      g.sections.forEach(function (s) {
        col.appendChild(h('table', { class: 'values' },
          h('caption', { text: s.title }),
          h('thead', {}, h('tr', {}, h('th', { scope: 'col', text: 'Symbol' }), h('th', { scope: 'col', text: 'Value' }), h('th', { scope: 'col', text: 'Unit' }))),
          h('tbody', {}, s.rows.map(function (row) {
            return h('tr', {}, h('th', { scope: 'row', text: row.symbol }), h('td', { class: 'num', text: row.value }), h('td', { class: 'unit', text: row.unit }));
          }).reduce(function (a, tr) { a.appendChild(tr); return a; }, document.createDocumentFragment()))));
      });
      wrap.appendChild(col);
    });
    return wrap;
  }

  function mountDrawing(r, box, notes) {
    var lastWidth = 0;
    function draw(widthPx) {
      if (!(widthPx > 0)) return;
      var res = Drawing.render(r, { widthPx: widthPx });
      if (!res.ok) {
        box.textContent = 'Drawing not available, value missing: ' + res.missing.map(Format.symbol).join(', ') + '.';
        notes.textContent = '';
        return;
      }
      box.innerHTML = res.svg;
      notes.textContent = Drawing.noteText(res.notes);
    }
    redraw = function (widthPx) { draw(widthPx || box.clientWidth || lastWidth); };
    new ResizeObserver(function () {
      var w = box.clientWidth;
      if (w > 0 && Math.abs(w - lastWidth) >= 1) { lastWidth = w; draw(w); }
    }).observe(box);
  }

  function renderDetail(r) {
    detailView.textContent = '';
    var box = h('div', { class: 'drawing-box' });
    var notes = h('p', { class: 'drawing-notes' });
    var print = h('button', { type: 'button', class: 'print-button', text: 'Print' });
    print.addEventListener('click', function () { window.print(); });
    detailView.appendChild(h('div', { class: 'sheet' },
      h('nav', { class: 'toolbar no-print' }, h('a', { href: '#/', text: 'All cartridges' }), print),
      h('header', { class: 'sheet-head' }, h('h1', { tabindex: '-1', text: r.name })),
      renderFacts(r),
      h('figure', { class: 'drawing-figure' }, box, h('figcaption', {}, notes,
        h('span', { class: 'schematic', text: 'Drawn from C.I.P. dimensions; bullet, case walls and primer pocket are schematic.' }))),
      renderTables(r),
      h('footer', { class: 'sheet-foot', text: 'Source: C.I.P. TDCC, revised ' + r.revised })));
    mountDrawing(r, box, notes);
    document.title = r.name + ' - Cartridges';
  }

  function renderNotFound(key) {
    detailView.textContent = '';
    detailView.appendChild(h('div', { class: 'sheet' },
      h('header', { class: 'sheet-head' }, h('h1', { tabindex: '-1', text: 'Cartridge not found' })),
      h('p', { text: 'No cartridge has the key "' + key + '".' }),
      h('p', {}, h('a', { href: '#/', text: 'All cartridges' }))));
    document.title = 'Cartridge not found - Cartridges';
    redraw = null;
  }

  // ---- routing -------------------------------------------------------------------------------
  var firstRoute = true;
  function route() {
    var r = Catalog.parseRoute(window.location.hash);
    var heading;
    if (r.view === 'detail') {
      var rec = Catalog.find(records, r.key);
      if (rec) renderDetail(rec); else renderNotFound(r.key);
      listView.hidden = true;
      detailView.hidden = false;
      heading = detailView.querySelector('h1');
    } else {
      redraw = null;
      detailView.hidden = true;
      detailView.textContent = '';
      listView.hidden = false;
      document.title = 'Cartridges';
      heading = listView.querySelector('h1');
    }
    if (!firstRoute) { window.scrollTo(0, 0); heading.focus({ preventScroll: true }); }
    firstRoute = false;
  }

  // The drawing is laid out for its width: lay it out for the paper width while printing.
  window.addEventListener('beforeprint', function () { if (redraw) redraw(PRINT_WIDTH_PX); });
  window.addEventListener('afterprint', function () { if (redraw) redraw(); });

  search.addEventListener('input', renderList);
  family.addEventListener('change', renderList);
  document.getElementById('filters').addEventListener('submit', function (e) { e.preventDefault(); });
  window.addEventListener('hashchange', route);
  renderList();
  route();
})();
