/* List filtering and hash routing. */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.Catalog = factory();
})(typeof self !== 'undefined' ? self : this, function () {
  var ROUTE = /^#\/cartridge\/(.+)$/;

  // Case, decimal comma and spaces are ignored: "7,62 x 51", "7.62x51" and "7,62X51" are the same query.
  function normalise(s) { return String(s).toLowerCase().replace(/,/g, '.').replace(/\s+/g, ''); }

  function filter(records, query, family) {
    var q = normalise(query);
    return records.filter(function (r) {
      if (family && family !== 'all' && r.family !== family) return false;
      return !q || [r.name].concat(r.alternativeNames || []).some(function (n) { return normalise(n).indexOf(q) !== -1; });
    });
  }

  function countText(n) { return n + ' cartridges'; }

  function parseRoute(hash) {
    var m = ROUTE.exec(hash || '');
    if (!m) return { view: 'list' };
    var key = m[1];
    try { key = decodeURIComponent(key); } catch (e) { /* malformed escape: keep the raw text, it will not be found */ }
    return { view: 'detail', key: key };
  }

  function detailHref(record) { return '#/cartridge/' + encodeURIComponent(record.key); }

  function find(records, key) { return records.find(function (r) { return r.key === key; }); }

  return { filter: filter, countText: countText, parseRoute: parseRoute, detailHref: detailHref, find: find };
});
