/* True-scale SVG drawing of a cartridge: 1 user unit = 1 mm, z along x (head left), radius along y.
   Upper half: outside view. Lower half: section. Dimension lines, labels and a title block are laid out
   for a given display width so that text stays readable; labels never overlap lines or each other. */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory(require('./format.js'), require('./geometry.js'));
  else root.Drawing = factory(root.Format, root.Geometry);
})(typeof self !== 'undefined' ? self : this, function (Format, Geometry) {
  var FS_PX = 10.5;               // text height in CSS px
  var CHAR_W = 0.62;              // monospace advance in em (DejaVu/Menlo 0.60, Consolas 0.55)
  var PX_PER_MM = 96 / 25.4;
  var STEP = 0.5;                 // label search grid in text heights
  var SEARCH = 14;                // label search radius in text heights

  function r3(x) { var y = Math.round(x * 1000) / 1000; return y === 0 ? 0 : y; }
  function esc(s) { return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;'); }
  function pathOf(p) { return 'M' + p.map(function (q) { return r3(q[0]) + ' ' + r3(q[1]); }).join('L'); }
  function up(p) { return [p.z, -p.r]; }
  function lo(p) { return [p.z, p.r]; }

  function segHitsRect(s, r) {
    var t0 = 0, t1 = 1, dx = s.x2 - s.x1, dy = s.y2 - s.y1;
    var p = [-dx, dx, -dy, dy], q = [s.x1 - r.x0, r.x1 - s.x1, s.y1 - r.y0, r.y1 - s.y1];
    for (var i = 0; i < 4; i++) {
      if (p[i] === 0) { if (q[i] < 0) return false; } else {
        var t = q[i] / p[i];
        if (p[i] < 0) { if (t > t1) return false; if (t > t0) t0 = t; } else { if (t < t0) return false; if (t < t1) t1 = t; }
      }
    }
    return true;
  }

  function scaleText(pxPerUnit) {
    var s = pxPerUnit / PX_PER_MM;
    function f(x) { return String(Math.round(x * 10) / 10); }
    return 'Scale ' + (s >= 1 ? f(s) + ':1' : '1:' + f(1 / s));
  }

  function layout(record, g, pxPerUnit) {
    var u = 1 / pxPerUnit, fs = FS_PX * u, v = g.v, b = g.bullet;
    var al = 7 * u, aw = 2.3 * u, gap = 3.5 * u, ov = 4 * u, stub = 2.2 * al;
    var laneH = 2.0 * fs;
    var segs = [], rects = [], labels = [], reqs = [], extMap = {};
    var draw = { hatch: [], outline: [], thin: [], dims: [], arrows: [], leaders: [], centre: [] };
    var failed = 0, moved = 0;

    function seg(x1, y1, x2, y2, kind) { segs.push({ x1: x1, y1: y1, x2: x2, y2: y2, kind: kind }); }
    function poly(points, kind, bucket, attrs) {
      for (var i = 1; i < points.length; i++) seg(points[i - 1][0], points[i - 1][1], points[i][0], points[i][1], kind);
      bucket.push('<path d="' + pathOf(points) + '"' + (attrs || '') + '/>');
    }
    function line(x1, y1, x2, y2, kind, bucket) {
      seg(x1, y1, x2, y2, kind);
      bucket.push('<line x1="' + r3(x1) + '" y1="' + r3(y1) + '" x2="' + r3(x2) + '" y2="' + r3(y2) + '"/>');
    }
    // Extension lines on the same axis-parallel line are merged into one.
    function ext(horizontal, c, from, to) {
      var key = (horizontal ? 'h' : 'v') + r3(c), e = extMap[key];
      var lo_ = Math.min(from, to), hi_ = Math.max(from, to);
      if (!e) extMap[key] = { horizontal: horizontal, c: c, lo: lo_, hi: hi_ };
      else { e.lo = Math.min(e.lo, lo_); e.hi = Math.max(e.hi, hi_); }
    }
    function arrow(x, y, dx, dy) {
      var bx = x - dx * al, by = y - dy * al, px = -dy * aw, py = dx * aw;
      var p1 = [bx + px, by + py], p2 = [bx - px, by - py];
      seg(x, y, p1[0], p1[1], 'arrow'); seg(p1[0], p1[1], p2[0], p2[1], 'arrow'); seg(p2[0], p2[1], x, y, 'arrow');
      draw.arrows.push('<path d="M' + r3(x) + ' ' + r3(y) + 'L' + r3(p1[0]) + ' ' + r3(p1[1]) + 'L' + r3(p2[0]) + ' ' + r3(p2[1]) + 'Z"/>');
    }

    // ---- outline, edges, section ------------------------------------------------------------
    var outerUp = g.outer.map(up), outerLo = g.outer.map(lo);
    var hr = v.R1 / 2;
    var rmax = Math.max.apply(null, g.outer.map(function (p) { return p.r; }));
    poly(outerUp, 'outline', draw.outline, ' data-part="case-outside"');
    poly(outerLo, 'outline', draw.outline, ' data-part="case-section"');

    var edges = {};
    for (var i = 1; i < g.outer.length - 1; i++) {
      var p = g.outer[i], a = g.outer[i - 1], c = g.outer[i + 1];
      if (p.arc || p.z <= 0) continue;
      var turn = Math.abs(Math.atan2(c.r - p.r, c.z - p.z) - Math.atan2(p.r - a.r, p.z - a.z));
      if (turn > Math.PI) turn = 2 * Math.PI - turn;
      if (turn > 0.05) edges[r3(p.z)] = Math.max(edges[r3(p.z)] || 0, p.r);
    }
    Object.keys(edges).forEach(function (z) { line(+z, -edges[z], +z, 0, 'edge', draw.thin); });

    var mouth = g.mouth;
    if (b && Math.abs(mouth.r - b.rExposed) > 1e-6) line(mouth.z, -mouth.r, mouth.z, -b.rExposed, 'outline', draw.outline);
    if (b) poly(b.exposed.map(up), 'outline', draw.outline, ' data-part="bullet-outside"');

    var pocketPart = null;
    if (g.walls && g.inner.length) {
      var inn = g.inner, lastIn = inn[inn.length - 1];
      var solid = [];
      if (g.pocket) solid.push([0, g.pocket.d / 2]); else solid.push([0, 0]);
      g.outer.slice(1).forEach(function (q) { solid.push(lo(q)); });
      solid.push(lo(lastIn));
      for (i = inn.length - 2; i >= 0; i--) solid.push(lo(inn[i]));
      solid.push([g.w, 0]);
      if (g.pocket) solid.push([g.pocket.depth, 0], [g.pocket.depth, g.pocket.d / 2]);
      draw.hatch.push('<path d="' + pathOf(solid) + 'Z" fill="url(#hatch-case)" stroke="none"/>');
      poly(inn.map(lo), 'outline', draw.outline, ' data-part="case-inner"');
      line(mouth.z, mouth.r, lastIn.z, lastIn.r, 'outline', draw.outline);
      line(g.w, inn[0].r, g.w, 0, 'outline', draw.outline);
      if (g.pocket) {
        pocketPart = [[0, g.pocket.d / 2], [g.pocket.depth, g.pocket.d / 2], [g.pocket.depth, 0]];
        poly(pocketPart, 'outline', draw.outline, ' data-part="primer-pocket"');
      }
    }
    if (b) {
      var bsec = b.seated.concat(b.exposed).map(lo);
      draw.hatch.push('<path d="' + pathOf(bsec) + 'Z" fill="url(#hatch-bullet)" stroke="none"/>');
      poly(bsec, 'outline', draw.outline, ' data-part="bullet-section"');
    }
    var tipZ = b ? v.L6 : v.L3;
    line(-1.4 * fs, 0, tipZ + 1.4 * fs, 0, 'centre', draw.centre);

    // ---- label bookkeeping ------------------------------------------------------------------
    function rectOf(text, x, y, anchor) {
      var w = Array.from(text).length * CHAR_W * fs + 0.2 * fs;
      var x0 = anchor === 'end' ? x - w : anchor === 'middle' ? x - w / 2 : x - 0.1 * fs;
      return { x0: x0, x1: x0 + w, y0: y - 0.8 * fs, y1: y + 0.22 * fs };
    }
    function free(r) {
      var m = 0.12 * fs, q = { x0: r.x0 - m, x1: r.x1 + m, y0: r.y0 - m, y1: r.y1 + m }, i;
      for (i = 0; i < rects.length; i++) {
        var o = rects[i];
        if (!(q.x1 <= o.x0 || o.x1 <= q.x0 || q.y1 <= o.y0 || o.y1 <= q.y0)) return false;
      }
      for (i = 0; i < segs.length; i++) {
        var s = segs[i];
        if (Math.max(s.x1, s.x2) < q.x0 || Math.min(s.x1, s.x2) > q.x1 || Math.max(s.y1, s.y2) < q.y0 || Math.min(s.y1, s.y2) > q.y1) continue;
        if (segHitsRect(s, q)) return false;
      }
      return true;
    }
    var offsets = null;
    function spiral() {
      if (offsets) return offsets;
      offsets = [];
      var n = Math.round(SEARCH / STEP);
      for (var ix = -n; ix <= n; ix++) for (var iy = -n; iy <= n; iy++) offsets.push([ix * STEP * fs, iy * STEP * fs]);
      offsets.sort(function (p, q) { return Math.hypot(p[0], p[1]) - Math.hypot(q[0], q[1]); });
      return offsets;
    }
    function place(req) {
      var first = req.cands[0], chosen = null, k, o, cand, rect;
      for (k = 0; k < req.cands.length && !chosen; k++) {
        cand = req.cands[k]; rect = rectOf(req.text, cand.x, cand.y, cand.anchor);
        if (free(rect)) chosen = { x: cand.x, y: cand.y, anchor: cand.anchor, rect: rect };
      }
      if (!chosen) {
        var sp = spiral();
        for (k = 0; k < sp.length && !chosen; k++) {
          o = sp[k]; rect = rectOf(req.text, first.x + o[0], first.y + o[1], first.anchor);
          if (free(rect)) chosen = { x: first.x + o[0], y: first.y + o[1], anchor: first.anchor, rect: rect };
        }
      }
      if (!chosen) { failed++; chosen = { x: first.x, y: first.y, anchor: first.anchor, rect: rectOf(req.text, first.x, first.y, first.anchor) }; }
      else if (chosen.x !== first.x || chosen.y !== first.y) moved++;
      rects.push(chosen.rect);
      labels.push({ id: req.id, text: req.text, x: chosen.x, y: chosen.y, anchor: chosen.anchor, rect: chosen.rect });
      if (req.leaderTo && Math.hypot(chosen.x - first.x, chosen.y - first.y) > 0.8 * fs) {
        var rr = chosen.rect, to = req.leaderTo;
        var fx = Math.max(rr.x0, Math.min(to.x, rr.x1)), fy = Math.max(rr.y0, Math.min(to.y, rr.y1));
        if (Math.hypot(fx - to.x, fy - to.y) > 0.3 * fs) line(fx, fy, to.x, to.y, 'leader', draw.leaders);
      }
    }
    function request(id, text, cands, leaderTo) { reqs.push({ id: id, text: text, cands: cands, leaderTo: leaderTo }); }

    // ---- dimension lines --------------------------------------------------------------------
    function sym(f) { return Format.symbol(f); }
    function text(f, value) { return sym(f) + ' ' + Format.value(f, value); }

    // lengths below the part, nested by span
    var lowers = [{ id: 'R', z2: v.R, y2: hr }];
    if (Geometry.pub(v.L1)) lowers.push({ id: 'L1', z2: v.L1, y2: Geometry.radiusAt(g.outer, v.L1) });
    if (Geometry.pub(v.L2)) lowers.push({ id: 'L2', z2: v.L2, y2: Geometry.radiusAt(g.outer, v.L2) });
    lowers.push({ id: 'L3', z2: v.L3, y2: mouth.r });
    if (Geometry.pub(v.L6)) lowers.push({ id: 'L6', z2: v.L6, y2: b ? b.m / 2 : 0 });
    lowers.sort(function (p, q) { return p.z2 - q.z2; });
    var laneY0 = rmax + gap + 1.6 * fs;
    lowers.forEach(function (d, k) {
      var y = laneY0 + k * laneH, x1 = 0, x2 = d.z2, inside = x2 - x1 >= 2.6 * al;
      ext(false, x1, hr + gap, y + ov); ext(false, x2, d.y2 + gap, y + ov);
      if (inside) {
        line(x1, y, x2, y, 'dim', draw.dims); arrow(x1, y, -1, 0); arrow(x2, y, 1, 0);
      } else {
        line(x1 - stub, y, x2 + stub, y, 'dim', draw.dims); arrow(x1, y, 1, 0); arrow(x2, y, -1, 0);
      }
      var t = text(d.id, v[d.id]);
      request(d.id, t, inside
        ? [{ x: (x1 + x2) / 2, y: y - 0.3 * fs, anchor: 'middle' }]
        : [{ x: x2 + stub + 0.35 * fs, y: y + 0.35 * fs, anchor: 'start' }, { x: x1 - stub - 0.35 * fs, y: y + 0.35 * fs, anchor: 'end' }],
      { x: (x1 + x2) / 2, y: y });
    });

    // diameters in vertical lanes: E1 and R1 left of the head, the rest right of the bullet tip
    var rimStart = 0;
    for (i = 0; i < g.outer.length; i++) if (Math.abs(g.outer[i].r - hr) < 1e-9) { rimStart = g.outer[i].z; break; }
    var zCyl = b ? Math.max(b.zc, v.L3) : v.L3;
    var rightD = [
      { id: 'G1', D: v.G1, zf: zCyl, rank: 0 }, { id: 'H2', D: v.H2, zf: v.L3, rank: 1 }, { id: 'H1', D: v.H1, zf: v.L2, rank: 2 },
      { id: 'P2', D: v.P2, zf: v.L1, rank: 3 }, { id: 'P1', D: v.P1, zf: g.bodyStart.z, rank: 4 }
    ].filter(function (d) { return Geometry.pub(d.D) && (d.id !== 'H1' || g.bottleneck) && (d.id !== 'P2' || g.bottleneck); });
    var leftD = [{ id: 'E1', D: v.E1, zf: v.R, rank: 0 }, { id: 'R1', D: v.R1, zf: rimStart, rank: 1 }]
      .filter(function (d) { return Geometry.pub(d.D) && (d.id !== 'E1' || g.groove); });
    function byD(p, q) { return p.D - q.D || p.rank - q.rank; }
    rightD.sort(byD); leftD.sort(byD);
    var allD = rightD.concat(leftD);
    var maxHalf = Math.max.apply(null, allD.map(function (d) { return d.D / 2 + (d.D >= 2.6 * al ? 0 : stub); }));
    var yTop = -Math.max(maxHalf, rmax) - 0.4 * fs;
    function vDim(d, k, side) {
      var x = side > 0 ? tipZ + 2.0 * fs + k * 1.3 * fs : -(2.0 * fs + k * 1.3 * fs);
      var r = d.D / 2, inside = d.D >= 2.6 * al, top = inside ? -r : -(r + stub);
      ext(true, -r, d.zf, x + side * ov); ext(true, r, d.zf, x + side * ov);
      if (inside) {
        line(x, -r, x, r, 'dim', draw.dims); arrow(x, -r, 0, -1); arrow(x, r, 0, 1);
      } else {
        line(x, -r - stub, x, r + stub, 'dim', draw.dims); arrow(x, -r, 0, 1); arrow(x, r, 0, -1);
      }
      var base = yTop - 0.3 * fs - k * 1.5 * fs;
      line(x, top, x, base - 0.3 * fs, 'dim', draw.dims);
      request(d.id, text(d.id, v[d.id]), [{ x: x - side * 0.3 * fs, y: base, anchor: side > 0 ? 'end' : 'start' }], { x: x, y: base - 0.3 * fs });
    }
    rightD.forEach(function (d, k) { vDim(d, k, 1); });
    leftD.forEach(function (d, k) { vDim(d, k, -1); });

    // shoulder angle: arc between the cone line and its mirror image at the shoulder start
    var alphaArc = null;
    if (g.bottleneck && v.alpha !== undefined) {
      var P = { x: v.L1, y: -v.P2 / 2 };
      var h = Math.atan(((v.P2 - v.H1) / 2) / (v.L2 - v.L1));
      var sh = Math.hypot(v.L2 - v.L1, (v.P2 - v.H1) / 2);
      var rho = Math.min(Math.max(0.85 * sh, 2.6 * fs), 0.9 * (v.P2 / 2) / Math.sin(h));
      var ch = Math.cos(h), sn = Math.sin(h), lenC = rho + ov;
      line(P.x, P.y, P.x + lenC * ch, P.y - lenC * sn, 'ext', draw.thin);
      if (lenC > sh) line(P.x + sh * ch, P.y + sh * sn, P.x + lenC * ch, P.y + lenC * sn, 'ext', draw.thin);
      var pt = function (th) { return [P.x + rho * Math.cos(th), P.y + rho * Math.sin(th)]; };
      var arc = function (t1, t2) {
        var n = 8, pts = [], j;
        for (j = 0; j <= n; j++) pts.push(pt(t1 + (t2 - t1) * j / n));
        for (j = 1; j < pts.length; j++) seg(pts[j - 1][0], pts[j - 1][1], pts[j][0], pts[j][1], 'dim');
        draw.dims.push('<path d="M' + r3(pts[0][0]) + ' ' + r3(pts[0][1]) + 'A' + r3(rho) + ' ' + r3(rho) + ' 0 0 1 ' + r3(pts[n][0]) + ' ' + r3(pts[n][1]) + '"/>');
      };
      var tg = function (th) { return [-Math.sin(th), Math.cos(th)]; };
      var e1 = pt(-h), e2 = pt(h), t1 = tg(-h), t2 = tg(h);
      if (rho * 2 * h >= 2.6 * al) {
        arc(-h, h); arrow(e2[0], e2[1], t2[0], t2[1]); arrow(e1[0], e1[1], -t1[0], -t1[1]);
      } else {
        var dl = stub / rho;
        arc(-h - dl, -h); arc(h, h + dl); arrow(e2[0], e2[1], -t2[0], -t2[1]); arrow(e1[0], e1[1], t1[0], t1[1]);
      }
      alphaArc = { x: P.x, y: P.y, rho: rho, half: h };
      request('alpha', text('alpha', v.alpha), [{ x: P.x + rho + 0.8 * fs, y: P.y + 0.35 * fs, anchor: 'start' }], { x: P.x + rho, y: P.y });
    }

    // extension lines (merged), then labels, so labels see every line
    Object.keys(extMap).forEach(function (key) {
      var e = extMap[key];
      if (e.horizontal) line(e.lo, e.c, e.hi, e.c, 'ext', draw.thin);
      else line(e.c, e.lo, e.c, e.hi, 'ext', draw.thin);
    });
    var order = { G1: 0, H2: 0, H1: 0, P2: 0, P1: 0, E1: 0, R1: 0 };
    reqs.sort(function (p, q) { return (order[q.id] === 0 ? 1 : 0) - (order[p.id] === 0 ? 1 : 0); });
    reqs.forEach(place);

    // ---- extents and title block ------------------------------------------------------------
    var box = { x0: Infinity, y0: Infinity, x1: -Infinity, y1: -Infinity };
    function grow(x0, y0, x1, y1) { box.x0 = Math.min(box.x0, x0); box.y0 = Math.min(box.y0, y0); box.x1 = Math.max(box.x1, x1); box.y1 = Math.max(box.y1, y1); }
    segs.forEach(function (s) { grow(Math.min(s.x1, s.x2), Math.min(s.y1, s.y2), Math.max(s.x1, s.x2), Math.max(s.y1, s.y2)); });
    labels.forEach(function (l) { grow(l.rect.x0, l.rect.y0, l.rect.x1, l.rect.y1); });

    var tb = [record.name, 'C.I.P. table ' + record.tab, 'Revised ' + record.revised, 'Dimensions in mm', scaleText(pxPerUnit)];
    var tw = function (s, k) { return Array.from(s).length * CHAR_W * fs * (k || 1); };
    var pad = 0.6 * fs, rowH = 1.8 * fs;
    var c1 = Math.max(tw(tb[1]), tw(tb[3])) + 2 * pad, c2 = Math.max(tw(tb[2]), tw(tb[4])) + 2 * pad;
    var bw = Math.max(c1 + c2, tw(tb[0], 1.2) + 2 * pad);
    c2 = bw - c1;
    var bx = box.x1 - bw, by = box.y1 + 1.8 * fs;
    grow(bx, by, bx + bw, by + 3 * rowH);
    var block = [
      '<rect x="' + r3(bx) + '" y="' + r3(by) + '" width="' + r3(bw) + '" height="' + r3(3 * rowH) + '"/>',
      '<path d="M' + r3(bx) + ' ' + r3(by + rowH) + 'H' + r3(bx + bw) + 'M' + r3(bx) + ' ' + r3(by + 2 * rowH) + 'H' + r3(bx + bw) +
        'M' + r3(bx + c1) + ' ' + r3(by + rowH) + 'V' + r3(by + 3 * rowH) + '"/>'
    ];
    var ty = function (row) { return r3(by + row * rowH + rowH / 2 + 0.3 * fs); };
    var blockText = [
      '<text x="' + r3(bx + pad) + '" y="' + ty(0) + '" font-size="' + r3(1.2 * fs) + '" font-weight="700">' + esc(tb[0]) + '</text>',
      '<text x="' + r3(bx + pad) + '" y="' + ty(1) + '">' + esc(tb[1]) + '</text>',
      '<text x="' + r3(bx + c1 + pad) + '" y="' + ty(1) + '">' + esc(tb[2]) + '</text>',
      '<text x="' + r3(bx + pad) + '" y="' + ty(2) + '">' + esc(tb[3]) + '</text>',
      '<text x="' + r3(bx + c1 + pad) + '" y="' + ty(2) + '">' + esc(tb[4]) + '</text>'
    ];

    var m = 1.2 * fs;
    var vb = { x: r3(box.x0 - m), y: r3(box.y0 - m), w: r3(box.x1 - box.x0 + 2 * m), h: r3(box.y1 - box.y0 + 2 * m) };

    // ---- svg --------------------------------------------------------------------------------
    var sw = function (k) { return r3(k * u); };
    var hs = 3.6 * u;
    var labelSvg = labels.map(function (l) {
      return '<text x="' + r3(l.x) + '" y="' + r3(l.y) + '"' + (l.anchor === 'start' ? '' : ' text-anchor="' + l.anchor + '"') + '>' + esc(l.text) + '</text>';
    });
    var svg = '<svg xmlns="http://www.w3.org/2000/svg" class="drawing" viewBox="' + vb.x + ' ' + vb.y + ' ' + vb.w + ' ' + vb.h +
      '" role="img" aria-label="' + esc(record.name) + ' drawing">' +
      '<desc>True-scale half section of ' + esc(record.name) + ': outside view above the axis, section below. 1 unit = 1 mm.</desc>' +
      '<defs>' +
      '<pattern id="hatch-case" width="' + r3(hs) + '" height="' + r3(hs) + '" patternUnits="userSpaceOnUse" patternTransform="rotate(45)"><line class="hatch-line" x1="0" y1="0" x2="0" y2="' + r3(hs) + '" stroke-width="' + sw(0.8) + '"/></pattern>' +
      '<pattern id="hatch-bullet" width="' + r3(hs * 1.7) + '" height="' + r3(hs * 1.7) + '" patternUnits="userSpaceOnUse" patternTransform="rotate(-45)"><line class="hatch-line" x1="0" y1="0" x2="0" y2="' + r3(hs * 1.7) + '" stroke-width="' + sw(0.7) + '"/></pattern>' +
      '</defs>' +
      '<g class="hatch">' + draw.hatch.join('') + '</g>' +
      '<g class="outline" fill="none" stroke-width="' + sw(1.5) + '" stroke-linejoin="round">' + draw.outline.join('') + '</g>' +
      '<g class="thin" fill="none" stroke-width="' + sw(0.8) + '">' + draw.thin.join('') + '</g>' +
      '<g class="centre" fill="none" stroke-width="' + sw(0.9) + '" stroke-dasharray="' + [9, 2.5, 1.5, 2.5].map(sw).join(' ') + '">' + draw.centre.join('') + '</g>' +
      '<g class="dims" fill="none" stroke-width="' + sw(0.9) + '">' + draw.dims.join('') + draw.leaders.join('') + '</g>' +
      '<g class="arrows">' + draw.arrows.join('') + '</g>' +
      '<g class="titleblock" fill="none" stroke-width="' + sw(1) + '">' + block.join('') + '</g>' +
      '<g class="labels" font-size="' + r3(fs) + '" stroke-width="' + sw(3) + '">' + labelSvg.join('') + blockText.join('') + '</g>' +
      '</svg>';

    return {
      ok: true, svg: svg, viewBox: vb, fontSize: fs, labels: labels, segments: segs, failed: failed, moved: moved,
      titleBlock: tb, notes: g.notes, alpha: alphaArc,
      parts: { caseUpper: outerUp, caseLower: outerLo, bulletUpper: b ? b.exposed.map(up) : [], pocket: pocketPart }
    };
  }

  // Lay out for a display width in CSS px; the text size in user units depends on the scale, which
  // depends on the extent, so iterate to the fixed point (the map is monotone, it converges).
  function render(record, opts) {
    var g = Geometry.build(record);
    if (!g.ok) return { ok: false, missing: g.missing };
    var widthPx = opts.widthPx, p = widthPx / (g.v.L3 + 60), sc = null;
    for (var i = 0; i < 12; i++) {
      sc = layout(record, g, p);
      var next = widthPx / sc.viewBox.w;
      if (Math.abs(next - p) / p < 0.004) break;
      p = next;
    }
    return sc;
  }

  function noteText(notes) {
    if (!notes.length) return '';
    var parts = notes.map(function (n) { return n.feature + ' (' + n.missing.map(Format.symbol).join(', ') + ')'; });
    return 'Not drawn, value missing: ' + parts.join('; ') + '.';
  }

  return { render: render, noteText: noteText, scaleText: scaleText };
});
