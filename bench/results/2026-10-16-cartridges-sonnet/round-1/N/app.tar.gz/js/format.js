/* Display formatting for cartridge values: numbers, angles, symbols, units, table rows. */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.Format = factory();
})(typeof self !== 'undefined' ? self : this, function () {
  var SYMBOLS = {
    eMin: 'e min', r1Min: 'r1 min', r1Max: 'r1 max', alpha: 'α', alpha1: 'α1',
    beta: 'β', delta: 'δ', deltaL: 'delta L', L3PlusG: 'L3 + G'
  };
  var ANGLES = { alpha: 1, alpha1: 1, beta: 1, delta: 1, i: 1 };
  var UNITS = { Pmax: 'bar', PK: 'bar', PE: 'bar', EE: 'J', M: 'g', Q: 'mm²', N: '' };
  var SECTION_TITLES = {
    caseHead: 'Case head', collar: 'Collar', junctionCone: 'Junction cone', lengths: 'Lengths',
    misc: 'Miscellaneous', powderChamber: 'Powder chamber', pressures: 'Pressures',
    projectile: 'Projectile', barrel: 'Barrel', breech: 'Breech', grooves: 'Grooves', rifling: 'Rifling'
  };

  function num(v) { return String(v); }

  function angle(v) {
    if (typeof v === 'number') return num(v) + '°';
    return v.degrees + '°' + v.minutes + "'" + v.seconds + '"';
  }

  function symbol(field) { return Object.prototype.hasOwnProperty.call(SYMBOLS, field) ? SYMBOLS[field] : field; }

  function unit(field) {
    if (Object.prototype.hasOwnProperty.call(UNITS, field)) return UNITS[field];
    return ANGLES[field] ? 'deg' : 'mm';
  }

  function value(field, v) { return ANGLES[field] ? angle(v) : num(v); }

  // One row per field; <X>Tol is appended to the value of X and has no row of its own.
  function rows(section) {
    var out = [];
    Object.keys(section).forEach(function (field) {
      if (/Tol$/.test(field)) return;
      var text = value(field, section[field]);
      var tol = section[field + 'Tol'];
      if (tol !== undefined) text += ' ' + num(tol);
      out.push({ field: field, symbol: symbol(field), value: text, unit: unit(field) });
    });
    return out;
  }

  function groups(record) {
    return [['Cartridge', record.cartridge], ['Chamber', record.chamber]].map(function (g) {
      var sections = [];
      Object.keys(g[1]).forEach(function (id) {
        var r = rows(g[1][id]);
        if (r.length) sections.push({ id: id, title: SECTION_TITLES[id] || id, rows: r });
      });
      return { title: g[0], sections: sections };
    });
  }

  function capacity(record) {
    var c = record.annotations && record.annotations.publishedCapacity;
    if (!c) return null;
    return { text: num(c.grH2O) + ' gr H2O', source: c.source, url: c.url, note: c.note };
  }

  return { num: num, angle: angle, symbol: symbol, unit: unit, value: value, rows: rows, groups: groups, capacity: capacity };
});
