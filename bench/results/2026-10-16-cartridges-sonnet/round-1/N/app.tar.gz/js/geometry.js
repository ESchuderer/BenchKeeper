/* Half-profile geometry of a cartridge: (r, z) points from the axis at the head face to the mouth,
   walls, primer pocket and bullet. Pure functions, no DOM. Values that a rule needs but the record
   lacks are never invented: the feature is skipped and listed in `notes`. */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.Geometry = factory();
})(typeof self !== 'undefined' ? self : this, function () {
  var EPS = 1e-9;
  var ARC_STEPS = 8;
  var NOSE_STEPS = 24;
  var SECTIONS = ['caseHead', 'collar', 'junctionCone', 'lengths', 'misc', 'powderChamber', 'projectile'];
  // primer type -> [pocket diameter, depth]
  var POCKETS = {
    sp: [4.45, 3.04], spm: [4.45, 3.04], sr: [4.45, 3.04], lp: [5.33, 3.04], lpm: [5.33, 3.04], lr: [5.33, 3.3], lrm: [5.33, 3.3]
  };
  var SEATING = { pointy: 1.0, semi_wadcutter: 0.6 };
  var CYLINDER = { pointy: 0.4, semi_wadcutter: 0.78 };

  function pub(x) { return typeof x === 'number' && isFinite(x); }
  function isAngle(x) { return pub(x) || (!!x && typeof x === 'object' && pub(x.degrees)); }
  function rad(d) { return d * Math.PI / 180; }
  function toDeg(a) { return typeof a === 'number' ? a : a.degrees + a.minutes / 60 + a.seconds / 3600; }
  function dist(a, b) { return Math.hypot(a.z - b.z, a.r - b.r); }

  function flatten(record) {
    var v = {};
    SECTIONS.forEach(function (s) {
      var sec = record.cartridge && record.cartridge[s];
      if (sec) Object.keys(sec).forEach(function (k) { v[k] = sec[k]; });
    });
    return v;
  }

  function rimType(record) {
    if (record.family === 'belted') return 'belted';
    if (record.family === 'rimfire') return 'rimfire';
    var ratio = record.cartridge.caseHead.R1 / record.cartridge.powderChamber.P1;
    if (ratio >= 1.05) return 'rimmed';
    if (ratio < 0.98) return 'rebated';
    return 'rimless';
  }

  // Linear interpolation of the radius at z along a polyline that is non-decreasing in z.
  function radiusAt(poly, z) {
    if (z <= poly[0].z) return poly[0].r;
    for (var i = 1; i < poly.length; i++) {
      var a = poly[i - 1], b = poly[i];
      if (b.z > a.z && z >= a.z && z <= b.z) return a.r + (b.r - a.r) * (z - a.z) / (b.z - a.z);
    }
    return poly[poly.length - 1].r;
  }

  // Round the corner B between A and C with radius rho; tangent length at most maxT.
  function fillet(A, B, C, rho, maxT, steps) {
    var u1 = unit(A, B), u2 = unit(C, B);
    var theta = Math.acos(Math.max(-1, Math.min(1, u1.z * u2.z + u1.r * u2.r)));
    if (!(rho > 0) || theta > Math.PI - 1e-3 || theta < 1e-3) return [{ r: B.r, z: B.z }];
    var t = rho / Math.tan(theta / 2);
    if (t > maxT) { t = maxT; rho = t * Math.tan(theta / 2); }
    var T1 = { z: B.z + u1.z * t, r: B.r + u1.r * t };
    var T2 = { z: B.z + u2.z * t, r: B.r + u2.r * t };
    var bis = unit({ z: B.z + u1.z + u2.z, r: B.r + u1.r + u2.r }, B);
    var d = rho / Math.sin(theta / 2);
    var c = { z: B.z + bis.z * d, r: B.r + bis.r * d };
    var a1 = Math.atan2(T1.r - c.r, T1.z - c.z);
    var sweep = Math.atan2(T2.r - c.r, T2.z - c.z) - a1;
    if (sweep > Math.PI) sweep -= 2 * Math.PI;
    if (sweep < -Math.PI) sweep += 2 * Math.PI;
    var out = [];
    for (var i = 0; i <= steps; i++) {
      var a = a1 + sweep * i / steps;
      out.push({ r: c.r + rho * Math.sin(a), z: c.z + rho * Math.cos(a), arc: true });
    }
    out[0] = { r: T1.r, z: T1.z, arc: true };
    out[steps] = { r: T2.r, z: T2.z, arc: true };
    return out;
  }

  function unit(to, from) {
    var dz = to.z - from.z, dr = to.r - from.r, l = Math.hypot(dz, dr) || 1;
    return { z: dz / l, r: dr / l };
  }

  function build(record) {
    var v = flatten(record);
    var ann = record.annotations || {};
    var core = ['R1', 'P1', 'R', 'L3', 'H2'].filter(function (k) { return !pub(v[k]); });
    if (core.length) return { ok: false, missing: core, notes: [] };

    var notes = [];
    var type = rimType(record);
    var belted = type === 'belted';
    var outer = [{ r: 0, z: 0 }];
    function push(r, z, arc) {
      var last = outer[outer.length - 1];
      if (Math.abs(last.r - r) < EPS && Math.abs(last.z - z) < EPS) return;
      outer.push(arc ? { r: r, z: z, arc: true } : { r: r, z: z });
    }

    // Head face and rim edge
    var hr = v.R1 / 2;
    var chamfer = isAngle(v.beta) && pub(v.f) && toDeg(v.beta) < 90;
    if (isAngle(v.beta) !== pub(v.f)) notes.push({ feature: 'head chamfer', missing: [isAngle(v.beta) ? 'f' : 'beta'] });
    var rho = Math.min(v.R / 2, (v.R1 - v.P1) / 2);
    if (chamfer) {
      push(hr - Math.min(v.f * Math.tan(rad(toDeg(v.beta))), v.R1 / 4), 0);
      push(hr, v.f);
      push(hr, v.R);
    } else if (type === 'rimfire' && rho > 0) {
      push(hr - rho, 0);
      for (var i = 0; i <= ARC_STEPS; i++) {
        var t = Math.PI / 2 * i / ARC_STEPS;
        push(hr - rho + rho * Math.sin(t), rho - rho * Math.cos(t), true);
      }
      push(hr, v.R - rho);
      for (i = 0; i <= ARC_STEPS; i++) {
        t = Math.PI / 2 * i / ARC_STEPS;
        push(hr - rho + rho * Math.cos(t), v.R - rho + rho * Math.sin(t), true);
      }
    } else {
      push(hr, 0);
      push(hr, v.R);
    }

    // Extractor groove, belt, or plain step in
    var groove = null, beltRampEnd = null, z0 = v.R;
    var gMissing = ['E', 'E1', 'eMin'].filter(function (k) { return !pub(v[k]); });
    if (gMissing.length === 0) {
      groove = { E: v.E, E1: v.E1, eMin: v.eMin };
      push(v.E1 / 2, v.R);
      push(v.E1 / 2, v.R + v.eMin);
      var zFloor = v.R + v.eMin;
      var beltMissing = ['R3', 'delta'].filter(function (k) { return !(k === 'delta' ? isAngle(v[k]) : pub(v[k])); });
      if (belted && beltMissing.length) notes.push({ feature: 'belt', missing: beltMissing });
      if (belted && !beltMissing.length && v.R3 / 2 > v.E1 / 2) {
        beltRampEnd = Math.min(zFloor + (v.R3 / 2 - v.E1 / 2) / Math.tan(rad(toDeg(v.delta))), v.E);
        push(v.R3 / 2, beltRampEnd);
        push(v.R3 / 2, v.E);
      }
      push(v.P1 / 2, v.E);
      z0 = v.E;
    } else {
      // rimmed and rimfire cases have no groove; the others should
      if (gMissing.length < 3 || type === 'rimless' || type === 'belted') notes.push({ feature: 'extractor groove', missing: gMissing });
      push(v.P1 / 2, v.R);
    }
    var bodyIndex = outer.length - 1;
    var bodyStart = { r: v.P1 / 2, z: z0 };

    // Body, shoulder, neck
    var bottleneck = false;
    if (isAngle(v.alpha)) bottleneck = pub(v.L1) && pub(v.L2);
    if (bottleneck) {
      var sMissing = ['P2', 'H1'].filter(function (k) { return !pub(v[k]); });
      if (sMissing.length) { notes.push({ feature: 'shoulder', missing: sMissing }); bottleneck = false; }
    }
    if (bottleneck) {
      var Bc = { r: v.P2 / 2, z: v.L1 }, Cc = { r: v.H1 / 2, z: v.L2 }, Dm = { r: v.H2 / 2, z: v.L3 };
      var rMissing = ['r1Min', 'r2'].filter(function (k) { return !pub(v[k]); });
      if (rMissing.length) notes.push({ feature: 'shoulder corner radius', missing: rMissing });
      var shoulder = dist(Bc, Cc);
      var c1 = pub(v.r1Min) ? fillet(bodyStart, Bc, Cc, v.r1Min, 0.5 * Math.min(shoulder, dist(bodyStart, Bc)), ARC_STEPS) : [Bc];
      var c2 = pub(v.r2) ? fillet(Bc, Cc, Dm, v.r2, 0.5 * Math.min(shoulder, dist(Cc, Dm)), ARC_STEPS) : [Cc];
      c1.concat(c2).forEach(function (p) { push(p.r, p.z, p.arc); });
    }
    push(v.H2 / 2, v.L3);
    var mouth = { r: outer[outer.length - 1].r, z: outer[outer.length - 1].z };

    // Walls, primer pocket, solid head
    var hasG1 = pub(v.G1);
    if (!hasG1) notes.push({ feature: 'case walls and bullet', missing: ['G1'] });
    var heeled = hasG1 && v.H2 - v.G1 <= 0.015;
    var walls = null;
    if (hasG1) {
      var tn = (v.H2 - v.G1) / 2;
      walls = { tn: tn, tb: Math.min(Math.max(1.3 * tn, 0.6), 0.35 * v.P1 / 2) };
    }
    var primer = ann.primerType;
    var pocket = null;
    if (type !== 'rimfire' && primer !== 'rimfire') {
      if (POCKETS[primer]) pocket = { d: POCKETS[primer][0], depth: POCKETS[primer][1] };
      else notes.push({ feature: 'primer pocket', missing: ['primerType'] });
    }
    var wc = [2.5, 0.25 * v.P1 / 2];
    if (pocket) wc.push(pocket.depth + 1.5);
    if (walls) {
      if (belted && beltRampEnd !== null) wc.push(beltRampEnd + walls.tb);
      else if (groove) wc.push(v.E + walls.tb);
    }
    var w = Math.max.apply(null, wc);

    // Bullet scalars (the seating depth positions the wall blend of straight cases)
    var shape = ann.defaultBulletShape;
    var pistol = ann.category === 'pistol';
    var b = null;
    if (hasG1 && pub(v.L6)) {
      var okShape = shape === 'pointy' || shape === 'rounded' || shape === 'flat' || shape === 'semi_wadcutter';
      if (!okShape) notes.push({ feature: 'bullet', missing: ['defaultBulletShape'] });
      else b = bulletScalars(shape, pistol, v);
    } else if (hasG1) notes.push({ feature: 'bullet', missing: ['L6'] });

    var inner = [];
    if (walls) {
      var tFn = function (z) {
        if (heeled) return walls.tb;
        if (bottleneck) {
          if (z <= v.L1) return walls.tb;
          if (z >= v.L2) return walls.tn;
          return walls.tb + (walls.tn - walls.tb) * (z - v.L1) / (v.L2 - v.L1);
        }
        if (!b || z <= b.zb) return walls.tb;
        return walls.tb + (walls.tn - walls.tb) * (z - b.zb) / (v.L3 - b.zb);
      };
      var body = outer.slice(bodyIndex);
      var zs = [w, v.L3];
      outer.forEach(function (p) { if (p.z > w && p.z < v.L3) zs.push(p.z); });
      if (bottleneck) zs.push(v.L1, v.L2);
      if (!bottleneck && b) zs.push(b.zb);
      zs = zs.filter(function (z) { return z >= w && z <= v.L3; }).sort(function (a, c) { return a - c; })
        .filter(function (z, i, a) { return i === 0 || z - a[i - 1] > EPS; });
      inner = zs.map(function (z) {
        var base = z < bodyStart.z ? v.P1 / 2 : radiusAt(body, z);
        return { r: base - tFn(z), z: z };
      });
    }
    var bullet = b ? bulletProfile(b, v, heeled, walls, inner) : null;

    return {
      ok: true, v: v, rimType: type, rimfire: type === 'rimfire', belted: belted, bottleneck: bottleneck, heeled: heeled,
      outer: outer, bodyIndex: bodyIndex, bodyStart: bodyStart, mouth: mouth, groove: groove, beltRampEnd: beltRampEnd,
      walls: walls, w: w, pocket: pocket, inner: inner, bullet: bullet, notes: notes
    };
  }

  function bulletScalars(shape, pistol, v) {
    var G1 = v.G1;
    var s = SEATING[shape] !== undefined ? SEATING[shape] : (pistol ? 0.4 : 0.8);
    var k = CYLINDER[shape] !== undefined ? CYLINDER[shape]
      : shape === 'rounded' ? (pistol ? 0.65 : 0.55) : (pistol ? 0.7 : 0.6);
    var m = shape === 'pointy' ? Math.max(0.08 * G1, 1.27)
      : shape === 'rounded' ? 0.15 * G1 : shape === 'flat' ? 0.55 * G1 : 0.6 * G1;
    s *= G1;
    var zb = v.L3 - s, Lb = v.L6 - zb;
    return { shape: shape, s: s, k: k, m: m, zb: zb, Lb: Lb, zc: zb + k * Lb };
  }

  function bulletProfile(b, v, heeled, walls, inner) {
    var Rb = heeled ? v.H2 / 2 : v.G1 / 2;
    var out = { shape: b.shape, s: b.s, k: b.k, m: b.m, zb: b.zb, Lb: b.Lb, zc: b.zc, rExposed: Rb, heeled: heeled };
    var n = v.L6 - b.zc, mr = b.m / 2, a = Rb - mr, nose = [], i, t;
    if (b.shape === 'pointy') {
      var rho = (a * a + n * n) / (2 * a);
      var cr = Rb - rho, phi = Math.asin(Math.min(1, n / rho));
      out.rho = rho;
      for (i = 0; i <= NOSE_STEPS; i++) { t = phi * i / NOSE_STEPS; nose.push({ r: cr + rho * Math.cos(t), z: b.zc + rho * Math.sin(t) }); }
    } else if (b.shape === 'rounded') {
      for (i = 0; i <= NOSE_STEPS; i++) { t = Math.PI / 2 * i / NOSE_STEPS; nose.push({ r: mr + a * Math.cos(t), z: b.zc + n * Math.sin(t) }); }
    } else {
      nose.push({ r: Rb, z: b.zc }, { r: mr, z: v.L6 });
    }
    nose[0] = { r: Rb, z: b.zc };
    nose[nose.length - 1] = { r: mr, z: v.L6 };
    var exposed = [];
    if (b.zc > v.L3 + EPS) exposed.push({ r: Rb, z: v.L3 });
    else exposed.push({ r: radiusAt(nose, v.L3), z: v.L3 });
    nose.forEach(function (p) { if (p.z > v.L3 + EPS) exposed.push(p); });
    exposed.push({ r: 0, z: v.L6 });
    out.exposed = exposed;

    var seated = [{ r: 0, z: b.zb }];
    if (heeled) {
      out.rHeel = v.H2 / 2 - walls.tb;
      seated.push({ r: out.rHeel, z: b.zb }, { r: out.rHeel, z: v.L3 });
    } else {
      seated.push({ r: Math.min(Rb, radiusAt(inner, b.zb)), z: b.zb });
      inner.forEach(function (p) { if (p.z > b.zb + EPS) seated.push({ r: Math.min(Rb, p.r), z: p.z }); });
    }
    out.seated = seated;
    return out;
  }

  return { build: build, rimType: rimType, fillet: fillet, radiusAt: radiusAt, toDeg: toDeg, rad: rad, pub: pub };
});
