const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { defineConfig } = require('@playwright/test');

// Use the Chromium that is installed, whatever its build number.
function chromiumPath() {
  const base = path.join(os.homedir(), '.cache', 'ms-playwright');
  if (!fs.existsSync(base)) return undefined;
  const dir = fs.readdirSync(base).filter((d) => /^chromium-\d+$/.test(d)).sort().pop();
  return dir ? path.join(base, dir, 'chrome-linux64', 'chrome') : undefined;
}

module.exports = defineConfig({
  testDir: 'test/e2e',
  timeout: 60000,
  fullyParallel: true,
  reporter: 'list',
  use: { launchOptions: { executablePath: chromiumPath(), args: ['--no-sandbox'] } }
});
