const { test, expect } = require('@playwright/test');
const path = require('node:path');
const { pathToFileURL } = require('node:url');
const data = require('../../js/data.js');

const URL = pathToFileURL(path.resolve(__dirname, '../../index.html')).href;

// Fail on console errors, page errors and any request that leaves the file system.
test.beforeEach(async ({ page }) => {
  page.problems = [];
  page.on('console', (m) => { if (['error', 'warning'].includes(m.type())) page.problems.push(m.text()); });
  page.on('pageerror', (e) => page.problems.push(String(e)));
  await page.route(/^(?!file:|data:)/, (route) => { page.problems.push('network: ' + route.request().url()); route.abort(); });
});
test.afterEach(async ({ page }) => { expect(page.problems).toEqual([]); });

test('start page lists 25 cartridges', async ({ page }) => {
  await page.goto(URL);
  await expect(page.getByRole('heading', { level: 1, name: 'Cartridges' })).toBeVisible();
  await expect(page.getByText('25 cartridges')).toBeVisible();
  for (const r of data) await expect(page.getByRole('link', { name: r.name, exact: true })).toBeVisible();
  const row = page.getByRole('row', { name: /308 Win\./ });
  await expect(row).toContainText('rimless');
  await expect(row).toContainText('51.18');
});

test('search finds alternative names and filters as you type', async ({ page }) => {
  await page.goto(URL);
  await page.getByLabel('Search').pressSequentially('7,62 x 51');
  await expect(page.getByText('1 cartridges')).toBeVisible();
  await expect(page.getByRole('link', { name: '308 Win.', exact: true })).toBeVisible();
  await page.getByLabel('Search').fill('');
  await expect(page.getByText('25 cartridges')).toBeVisible();
});

test('family select filters', async ({ page }) => {
  await page.goto(URL);
  await page.getByLabel('Family').selectOption('pistol');
  await expect(page.getByText('6 cartridges')).toBeVisible();
  await page.getByLabel('Family').selectOption('All');
  await expect(page.getByText('25 cartridges')).toBeVisible();
  await page.getByLabel('Family').selectOption('rimfire');
  await page.getByLabel('Search').fill('22');
  await expect(page.getByText('2 cartridges')).toBeVisible();
});

test('detail view survives a reload and links back', async ({ page }) => {
  await page.goto(URL);
  await page.getByRole('link', { name: '6,5 Creedmoor', exact: true }).click();
  await expect(page.getByRole('heading', { level: 1, name: '6,5 Creedmoor' })).toBeVisible();
  expect(page.url()).toContain('creedmoor');
  await page.reload();
  await expect(page.getByRole('heading', { level: 1, name: '6,5 Creedmoor' })).toBeVisible();
  await expect(page.getByRole('img', { name: '6,5 Creedmoor drawing' })).toBeVisible();
  await page.getByRole('link', { name: 'All cartridges' }).click();
  await expect(page.getByText('25 cartridges')).toBeVisible();
  await page.goBack();
  await expect(page.getByRole('heading', { level: 1, name: '6,5 Creedmoor' })).toBeVisible();
});

test('detail view shows facts, tables and tolerances', async ({ page }) => {
  await page.goto(URL + '#/cartridge/308_win');
  for (const t of ['308 Winchester, 7,62 x 51', 'rimless', 'rifle', 'lr', '1984-06-14', '2008-09-23', 'Transducer', '56 gr H2O']) {
    await expect(page.locator('dl.facts')).toContainText(t);
  }
  await expect(page.getByRole('link', { name: 'kwk' })).toHaveAttribute('href', 'http://kwk.us/cases.html');
  const tables = page.getByRole('table');
  expect(await tables.count()).toBeGreaterThan(10);
  await expect(page.getByRole('columnheader', { name: 'Symbol' }).first()).toBeVisible();
  await expect(page.getByRole('row', { name: /^L1 39\.62 -0\.2 mm$/ })).toBeVisible();
  await expect(page.getByRole('row', { name: /^α 40 deg$|^α 40° deg$/ }).first()).toBeVisible();
  await expect(page.getByRole('row', { name: /^Pmax 4150 bar$/ })).toBeVisible();
  await expect(page.getByRole('row', { name: /L1Tol/ })).toHaveCount(0);
  await expect(page.getByRole('button', { name: 'Print' })).toBeVisible();
});

test('unknown key shows a not-found page', async ({ page }) => {
  await page.goto(URL + '#/cartridge/nope');
  await expect(page.getByRole('heading', { level: 1, name: 'Cartridge not found' })).toBeVisible();
  await page.getByRole('link', { name: 'All cartridges' }).click();
  await expect(page.getByText('25 cartridges')).toBeVisible();
});

test('Print button calls window.print', async ({ page }) => {
  await page.addInitScript(() => { window.__printed = 0; window.print = () => { window.__printed++; }; });
  await page.goto(URL + '#/cartridge/223_rem');
  await page.getByRole('button', { name: 'Print' }).click();
  expect(await page.evaluate(() => window.__printed)).toBe(1);
});

test('drawing labels: rendered boxes do not overlap each other or lines', async ({ page }) => {
  for (const vp of [{ width: 360, height: 800 }, { width: 1280, height: 900 }]) {
    await page.setViewportSize(vp);
    for (const r of data) {
      await page.goto(URL + '#/cartridge/' + r.key);
      await page.reload();
      await expect(page.getByRole('img', { name: r.name + ' drawing' })).toBeVisible();
      const bad = await page.evaluate(() => {
        const svg = document.querySelector('svg.drawing');
        const texts = [...svg.querySelectorAll('.labels text')].map((t) => ({ s: t.textContent, b: t.getBBox() }));
        const out = [];
        const lines = [...svg.querySelectorAll('.outline path, .outline line, .thin line, .dims line, .dims path')];
        for (let i = 0; i < texts.length; i++) {
          const a = texts[i].b;
          for (let j = i + 1; j < texts.length; j++) {
            const b = texts[j].b;
            if (!(a.x + a.width <= b.x || b.x + b.width <= a.x || a.y + a.height <= b.y || b.y + b.height <= a.y)) out.push(texts[i].s + ' x ' + texts[j].s);
          }
          // sample points along every line and test against the text box
          for (const el of lines) {
            if (el.closest('.titleblock')) continue;
            const len = el.getTotalLength ? el.getTotalLength() : 0;
            const n = Math.max(2, Math.ceil(len / 0.2));
            for (let k = 0; k <= n; k++) {
              const p = el.getPointAtLength(len * k / n);
              if (p.x > a.x && p.x < a.x + a.width && p.y > a.y + a.height * 0.2 && p.y < a.y + a.height * 0.85) { out.push(texts[i].s + ' on line'); break; }
            }
          }
        }
        return out;
      });
      expect(bad, `${r.key} @${vp.width}`).toEqual([]);
    }
  }
});

test('print: one A4 page for every cartridge', async ({ page }) => {
  test.setTimeout(240000);
  await page.setViewportSize({ width: 1280, height: 900 });
  for (const r of data) {
    await page.goto(URL + '#/cartridge/' + r.key);
    await page.reload();
    await expect(page.getByRole('img', { name: r.name + ' drawing' })).toBeVisible();
    const pdf = await page.pdf({ preferCSSPageSize: true, printBackground: true });
    const pages = (pdf.toString('latin1').match(/\/Type\s*\/Page[^s]/g) || []).length;
    expect(pages, r.key).toBe(1);
  }
});
