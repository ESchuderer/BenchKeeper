const test = require('node:test');
const assert = require('node:assert/strict');
const Catalog = require('../../js/catalog.js');
const data = require('../../js/data.js');

const names = (list) => list.map((r) => r.name);

test('data: 25 unique records with URL-safe keys and valid families', () => {
  assert.equal(data.length, 25);
  assert.equal(new Set(data.map((r) => r.key)).size, 25);
  for (const r of data) {
    assert.match(r.key, /^[a-z0-9_]+$/);
    assert.ok(['rimless', 'rimmed', 'belted', 'pistol', 'rimfire'].includes(r.family), r.key);
    assert.equal(typeof r.name, 'string');
  }
});

test('data: lengths are ordered L1 < L2 < L3 < L6 where published', () => {
  for (const r of data) {
    const l = r.cartridge.lengths;
    if (l.L1 !== undefined && l.L2 !== undefined) assert.ok(l.L1 < l.L2 && l.L2 < l.L3, r.key);
    assert.ok(l.L3 < l.L6, r.key);
  }
});

test('search finds alternative names', () => {
  assert.deepEqual(names(Catalog.filter(data, '7,62 x 51', 'all')), ['308 Win.']);
  assert.deepEqual(names(Catalog.filter(data, '308 WINCHESTER', 'all')), ['308 Win.']);
  assert.deepEqual(names(Catalog.filter(data, '7,62x51', 'all')), ['308 Win.']);
  assert.deepEqual(names(Catalog.filter(data, '7.62 x 51', 'all')), ['308 Win.']);
  assert.equal(Catalog.filter(data, '7,62', 'all').length, 3);
  assert.deepEqual(names(Catalog.filter(data, '22lr', 'all')), ['22 Long Rifle']);
});

test('search by name, empty query and no match', () => {
  assert.equal(Catalog.filter(data, '', 'all').length, 25);
  assert.equal(Catalog.filter(data, '   ', 'all').length, 25);
  assert.deepEqual(names(Catalog.filter(data, 'creed', 'all')), ['6,5 Creedmoor']);
  assert.equal(Catalog.filter(data, 'zzz', 'all').length, 0);
});

test('family filter and combination', () => {
  const counts = { all: 25, rimless: 12, rimmed: 2, belted: 2, pistol: 6, rimfire: 3 };
  for (const [f, n] of Object.entries(counts)) assert.equal(Catalog.filter(data, '', f).length, n, f);
  assert.deepEqual(names(Catalog.filter(data, '7,62', 'rimfire')), []);
  assert.deepEqual(names(Catalog.filter(data, '22', 'rimfire')), ['22 Long Rifle', '22 Win. Mag. R.F.']);
});

test('count text', () => {
  assert.equal(Catalog.countText(25), '25 cartridges');
  assert.equal(Catalog.countText(1), '1 cartridges');
  assert.equal(Catalog.countText(0), '0 cartridges');
});

test('routes', () => {
  assert.deepEqual(Catalog.parseRoute(''), { view: 'list' });
  assert.deepEqual(Catalog.parseRoute('#'), { view: 'list' });
  assert.deepEqual(Catalog.parseRoute('#/'), { view: 'list' });
  assert.deepEqual(Catalog.parseRoute('#/cartridge/308_win'), { view: 'detail', key: '308_win' });
  assert.deepEqual(Catalog.parseRoute('#/cartridge/%E0%A4%A'), { view: 'detail', key: '%E0%A4%A' });
  assert.deepEqual(Catalog.parseRoute('#/nonsense'), { view: 'list' });
  assert.equal(Catalog.detailHref(data[0]), '#/cartridge/223_rem');
  assert.equal(Catalog.find(data, '308_win').name, '308 Win.');
  assert.equal(Catalog.find(data, 'nope'), undefined);
});
