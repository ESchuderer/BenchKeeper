const test = require('node:test');
const assert = require('node:assert/strict');
const Drawing = require('../../js/drawing.js');
const Geometry = require('../../js/geometry.js');
const data = require('../../js/data.js');

const rec = (k) => data.find((r) => r.key === k);
// CSS px per user unit: 360 px phone, 768 px tablet, 1100 px desktop, 718 px (190 mm) print
const WIDTHS = [328, 720, 1060, 718];

function hits(s, r) {
  let t0 = 0, t1 = 1;
  const dx = s.x2 - s.x1, dy = s.y2 - s.y1;
  const p = [-dx, dx, -dy, dy], q = [s.x1 - r.x0, r.x1 - s.x1, s.y1 - r.y0, r.y1 - s.y1];
  for (let i = 0; i < 4; i++) {
    if (p[i] === 0) { if (q[i] < 0) return false; } else {
      const t = q[i] / p[i];
      if (p[i] < 0) { if (t > t1) return false; if (t > t0) t0 = t; } else { if (t < t0) return false; if (t < t1) t1 = t; }
    }
  }
  return true;
}

test('svg: accessible name, true-scale viewBox, escaped name', () => {
  const s = Drawing.render(rec('40_s_w'), { widthPx: 800 });
  assert.match(s.svg, /^<svg [^>]*role="img"/);
  assert.ok(s.svg.includes('aria-label="40 S.&amp; W. drawing"'));
  assert.ok(!s.svg.includes('S.& W.'));
  assert.ok(s.viewBox.w > 28.83 && s.viewBox.h > 10);
});

test('coordinates are millimetres: z along x, radius along y, head at x = 0', () => {
  const s = Drawing.render(rec('308_win'), { widthPx: 800 });
  const up = s.parts.caseUpper, lo = s.parts.caseLower;
  assert.equal(Math.min(...up.map((p) => p[0])), 0);
  assert.equal(Math.max(...up.map((p) => p[0])), 51.18);
  assert.equal(Math.min(...up.map((p) => p[1])), -12.01 / 2);
  assert.equal(Math.max(...lo.map((p) => p[1])), 12.01 / 2);
  assert.equal(Math.max(...s.parts.bulletUpper.map((p) => p[0])), 71.12);
  assert.ok(s.viewBox.x < 0);
});

test('308 Win. carries every required dimension label', () => {
  const s = Drawing.render(rec('308_win'), { widthPx: 800 });
  const texts = s.labels.map((l) => l.text);
  for (const t of ['L3 51.18', 'L6 71.12', 'R1 12.01', 'R 1.37', 'P1 11.96', 'P2 11.53', 'H1 8.72', 'H2 8.72', 'G1 7.85', 'L1 39.62', 'L2 43.48', 'E1 10.39', 'α 40°']) {
    assert.ok(texts.includes(t), `${t} in ${texts.join(' | ')}`);
  }
});

test('angle label shows d m s', () => {
  const s = Drawing.render(rec('6_5_x_55_se'), { widthPx: 800 });
  assert.ok(s.labels.some((l) => l.text === 'α 50°35\'2"'));
});

test('unpublished dimensions are not drawn', () => {
  const texts = (k) => Drawing.render(rec(k), { widthPx: 800 }).labels.map((l) => l.text.split(' ')[0]);
  for (const k of ['9_mm_luger', '22_long_rifle', '22_win_mag_r_f']) {
    const t = texts(k);
    for (const sym of ['L3', 'L6', 'R1', 'R', 'P1', 'H2', 'G1']) assert.ok(t.includes(sym), `${k} ${sym}`);
    for (const sym of ['P2', 'H1', 'L1', 'L2', 'α']) assert.ok(!t.includes(sym), `${k} no ${sym}`);
  }
  assert.ok(!texts('9_3_x_74_r').includes('E1'));
  assert.ok(texts('9_mm_luger').includes('E1'));
});

test('title block: name, table, revision date, units, scale', () => {
  const s = Drawing.render(rec('223_rem'), { widthPx: 800 });
  const t = s.titleBlock;
  assert.deepEqual(t.slice(0, 3), ['223 Rem.', 'C.I.P. table I', 'Revised 2017-05-17']);
  assert.equal(t[3], 'Dimensions in mm');
  assert.match(t[4], /^Scale \d+(\.\d)?:1$|^Scale 1:\d+(\.\d)?$/);
});

test('scale text follows the displayed width (1 unit = 1 mm)', () => {
  const big = Drawing.render(rec('308_win'), { widthPx: 1100 }).titleBlock[4];
  const small = Drawing.render(rec('308_win'), { widthPx: 330 }).titleBlock[4];
  assert.notEqual(big, small);
  assert.match(big, /^Scale \d/);
  assert.match(small, /^Scale 1:/);
});

test('notes name the missing values', () => {
  assert.equal(Drawing.noteText(Geometry.build(rec('338_lapua_mag')).notes), 'Not drawn, value missing: shoulder corner radius (r1 min).');
  assert.equal(Drawing.noteText(Geometry.build(rec('17_hmr')).notes), 'Not drawn, value missing: shoulder corner radius (r1 min, r2).');
  assert.equal(Drawing.noteText([]), '');
});

test('labels overlap neither each other nor any line, at phone, tablet, desktop and print width', () => {
  for (const r of data) {
    for (const widthPx of WIDTHS) {
      const s = Drawing.render(r, { widthPx });
      const where = `${r.key} @${widthPx}`;
      assert.equal(s.failed, 0, `${where}: labels without a free spot`);
      for (let i = 0; i < s.labels.length; i++) {
        const a = s.labels[i].rect;
        for (const seg of s.segments) {
          if (seg.kind === 'leader') continue;
          assert.ok(!hits(seg, a), `${where}: "${s.labels[i].text}" hits a ${seg.kind} line`);
        }
        for (let j = i + 1; j < s.labels.length; j++) {
          const b = s.labels[j].rect;
          assert.ok(a.x1 <= b.x0 || b.x1 <= a.x0 || a.y1 <= b.y0 || b.y1 <= a.y0, `${where}: "${s.labels[i].text}" overlaps "${s.labels[j].text}"`);
        }
        const vb = s.viewBox;
        assert.ok(a.x0 >= vb.x && a.x1 <= vb.x + vb.w && a.y0 >= vb.y && a.y1 <= vb.y + vb.h, `${where}: "${s.labels[i].text}" inside the viewBox`);
      }
    }
  }
});

test('text stays at least 9 px high on screen, at every width', () => {
  for (const r of data) {
    for (const widthPx of WIDTHS) {
      const s = Drawing.render(r, { widthPx });
      const pxPerUnit = widthPx / s.viewBox.w;
      assert.ok(s.fontSize * pxPerUnit >= 9.5, `${r.key} @${widthPx}: ${s.fontSize * pxPerUnit}px`);
    }
  }
});

test('the cartridge stays recognisable on a phone (at least 40 % of the width)', () => {
  for (const r of data) {
    const s = Drawing.render(r, { widthPx: 328 });
    assert.ok(r.cartridge.lengths.L6 / s.viewBox.w > 0.4, `${r.key}: ${r.cartridge.lengths.L6 / s.viewBox.w}`);
  }
});

test('section view: hatched walls and head, bullet, pocket, centre line', () => {
  const s = Drawing.render(rec('223_rem'), { widthPx: 800 });
  assert.match(s.svg, /fill="url\(#hatch-case\)"/);
  assert.match(s.svg, /fill="url\(#hatch-bullet\)"/);
  assert.match(s.svg, /class="centre"/);
  assert.ok(s.parts.pocket);
  assert.equal(Drawing.render(rec('22_long_rifle'), { widthPx: 800 }).parts.pocket, null);
});

test('every record renders at every width without a missing-value error', () => {
  for (const r of data) for (const widthPx of WIDTHS) assert.equal(Drawing.render(r, { widthPx }).ok, true);
  const bad = JSON.parse(JSON.stringify(rec('308_win')));
  delete bad.cartridge.lengths.L3;
  const s = Drawing.render(bad, { widthPx: 800 });
  assert.equal(s.ok, false);
  assert.deepEqual(s.missing, ['L3']);
});
