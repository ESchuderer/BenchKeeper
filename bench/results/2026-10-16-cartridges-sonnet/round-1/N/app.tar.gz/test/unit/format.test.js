const test = require('node:test');
const assert = require('node:assert/strict');
const Format = require('../../js/format.js');
const data = require('../../js/data.js');

const byKey = (k) => data.find((r) => r.key === k);

test('num shows values as published', () => {
  assert.equal(Format.num(4150.0), '4150');
  assert.equal(Format.num(9.6), '9.6');
  assert.equal(Format.num(0), '0');
  assert.equal(Format.num(51.18), '51.18');
});

test('angle shows degrees or d m s', () => {
  assert.equal(Format.angle(40), '40°');
  assert.equal(Format.angle({ degrees: 39, minutes: 59, seconds: 49 }), '39°59\'49"');
  assert.equal(Format.angle({ degrees: 0, minutes: 42, seconds: 29 }), '0°42\'29"');
});

test('symbols follow the field name except the listed ones', () => {
  const expected = {
    eMin: 'e min', r1Min: 'r1 min', r1Max: 'r1 max', alpha: 'α', alpha1: 'α1',
    beta: 'β', delta: 'δ', deltaL: 'delta L', L3PlusG: 'L3 + G',
    L3: 'L3', Pmax: 'Pmax', R1: 'R1', r: 'r', G: 'G'
  };
  for (const [field, symbol] of Object.entries(expected)) assert.equal(Format.symbol(field), symbol, field);
});

test('units', () => {
  assert.equal(Format.unit('Pmax'), 'bar');
  assert.equal(Format.unit('PK'), 'bar');
  assert.equal(Format.unit('PE'), 'bar');
  assert.equal(Format.unit('EE'), 'J');
  assert.equal(Format.unit('M'), 'g');
  assert.equal(Format.unit('Q'), 'mm²');
  assert.equal(Format.unit('N'), '');
  for (const a of ['alpha', 'alpha1', 'beta', 'delta', 'i']) assert.equal(Format.unit(a), 'deg', a);
  for (const m of ['L3', 'R1', 'u', 'Fe', 'deltaL', 'L3PlusG']) assert.equal(Format.unit(m), 'mm', m);
});

test('tolerance is shown next to its value and never as a row', () => {
  const rows = Format.rows(byKey('308_win').cartridge.lengths);
  assert.deepEqual(rows.map((r) => r.symbol), ['L1', 'L2', 'L3', 'L6']);
  assert.equal(rows[0].value, '39.62 -0.2');
  assert.equal(rows[2].value, '51.18');
  assert.equal(rows[0].unit, 'mm');
});

test('angle rows keep d m s and plain degrees', () => {
  const rows = Format.rows(byKey('6_5_x_55_se').cartridge.junctionCone);
  const alpha = rows.find((r) => r.symbol === 'α');
  assert.equal(alpha.value, '50°35\'2"');
  assert.equal(alpha.unit, 'deg');
  assert.equal(Format.rows(byKey('308_win').cartridge.junctionCone).find((r) => r.symbol === 'α').value, '40°');
});

test('sections skip empty sections and group cartridge and chamber', () => {
  const groups = Format.groups(byKey('9_mm_luger'));
  assert.deepEqual(groups.map((g) => g.title), ['Cartridge', 'Chamber']);
  for (const g of groups) for (const s of g.sections) assert.ok(s.rows.length > 0, s.title);
  assert.ok(!groups[0].sections.some((s) => s.id === 'junctionCone'));
});

test('every record: no Tol row, every row has a unit except N', () => {
  for (const rec of data) {
    for (const g of Format.groups(rec)) {
      for (const s of g.sections) {
        for (const r of s.rows) {
          assert.ok(!/Tol$/.test(r.symbol), `${rec.key} ${r.symbol}`);
          if (r.symbol !== 'N') assert.notEqual(r.unit, '', `${rec.key} ${r.symbol}`);
          assert.ok(!/\d,\d/.test(r.value), 'decimal point only');
        }
      }
    }
  }
});

test('every field of every record appears in a table', () => {
  for (const rec of data) {
    const shown = new Set();
    for (const g of Format.groups(rec)) for (const s of g.sections) for (const r of s.rows) shown.add(`${g.title}.${s.id}.${r.field}`);
    for (const [grp, title] of [['cartridge', 'Cartridge'], ['chamber', 'Chamber']]) {
      for (const [sec, fields] of Object.entries(rec[grp])) {
        for (const f of Object.keys(fields)) {
          if (/Tol$/.test(f)) continue;
          assert.ok(shown.has(`${title}.${sec}.${f}`), `${rec.key} ${grp}.${sec}.${f}`);
        }
      }
    }
  }
});

test('water capacity', () => {
  assert.equal(Format.capacity(byKey('308_win')).text, '56 gr H2O');
  assert.equal(Format.capacity(byKey('308_win')).url, 'http://kwk.us/cases.html');
  assert.equal(Format.capacity(byKey('7_x_64')), null);
});
