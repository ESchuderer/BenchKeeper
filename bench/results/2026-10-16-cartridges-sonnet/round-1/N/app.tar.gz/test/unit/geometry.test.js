const test = require('node:test');
const assert = require('node:assert/strict');
const Geometry = require('../../js/geometry.js');
const data = require('../../js/data.js');

const rec = (k) => data.find((r) => r.key === k);
const clone = (o) => JSON.parse(JSON.stringify(o));
const near = (a, b, eps = 1e-6) => assert.ok(Math.abs(a - b) <= eps, `${a} != ${b}`);
const has = (pts, r, z, eps = 1e-6) => pts.some((p) => Math.abs(p.r - r) <= eps && Math.abs(p.z - z) <= eps);
const deg = (d) => (d * Math.PI) / 180;

test('rim type thresholds', () => {
  const mk = (family, R1, P1) => ({ family, cartridge: { caseHead: { R1 }, powderChamber: { P1 } } });
  assert.equal(Geometry.rimType(mk('belted', 20, 10)), 'belted');
  assert.equal(Geometry.rimType(mk('rimfire', 7, 5.7)), 'rimfire');
  assert.equal(Geometry.rimType(mk('rimless', 10.5, 10)), 'rimmed');
  assert.equal(Geometry.rimType(mk('rimless', 10.49, 10)), 'rimless');
  assert.equal(Geometry.rimType(mk('rimless', 9.7, 10)), 'rebated');
  assert.equal(Geometry.rimType(mk('rimless', 9.8, 10)), 'rimless');
  assert.equal(Geometry.rimType(mk('pistol', 11.18, 9.63)), 'rimmed');
  assert.equal(Geometry.rimType(rec('223_rem')), 'rimless');
  assert.equal(Geometry.rimType(rec('9_3_x_74_r')), 'rimmed');
});

test('fillet rounds a right angle with the requested radius', () => {
  const pts = Geometry.fillet({ r: 0, z: -10 }, { r: 0, z: 0 }, { r: 10, z: 0 }, 2, 100, 8);
  near(pts[0].z, -2); near(pts[0].r, 0);
  near(pts[pts.length - 1].z, 0); near(pts[pts.length - 1].r, 2);
  for (const p of pts) near(Math.hypot(p.z + 2, p.r - 2), 2, 1e-9);
  assert.ok(pts.every((p) => p.arc));
});

test('fillet radius is limited by the tangent length', () => {
  const pts = Geometry.fillet({ r: 0, z: -10 }, { r: 0, z: 0 }, { r: 10, z: 0 }, 50, 1.5, 8);
  near(pts[0].z, -1.5);
  near(pts[pts.length - 1].r, 1.5);
});

test('223 Rem. head: chamfer, rim edge, groove', () => {
  const g = Geometry.build(rec('223_rem'));
  const o = g.outer;
  assert.deepEqual(o[0], { r: 0, z: 0 });
  near(o[1].r, 4.8 - 0.45 * Math.tan(deg(35))); near(o[1].z, 0);
  assert.ok(has(o, 4.8, 0.45));
  assert.ok(has(o, 4.8, 1.14));
  assert.ok(has(o, 8.43 / 2, 1.14));
  assert.ok(has(o, 8.43 / 2, 1.14 + 0.76));
  assert.ok(has(o, 9.58 / 2, 3.13));
  assert.equal(g.rimType, 'rimless');
  near(g.bodyStart.z, 3.13);
  assert.deepEqual(g.outer[g.outer.length - 1], { r: 6.43 / 2, z: 44.7 });
  assert.deepEqual(g.mouth, { r: 6.43 / 2, z: 44.7 });
});

test('chamfer length is limited to R1/4', () => {
  const r = clone(rec('223_rem'));
  r.cartridge.caseHead.f = 20;
  const o = Geometry.build(r).outer;
  near(o[1].r, 4.8 - 9.6 / 4);
});

test('no groove without E and E1: step in at z = R', () => {
  const g = Geometry.build(rec('9_3_x_74_r'));
  assert.equal(g.rimType, 'rimmed');
  assert.ok(has(g.outer, 13.35 / 2, 1.4));
  assert.ok(has(g.outer, 11.9 / 2, 1.4));
  assert.equal(g.groove, null);
  near(g.bodyStart.z, 1.4);
  assert.deepEqual(g.notes, []);
});

test('square corner without chamfer values', () => {
  const r = clone(rec('9_3_x_74_r'));
  delete r.cartridge.caseHead.beta;
  const g = Geometry.build(r);
  assert.deepEqual(g.outer.slice(0, 3), [{ r: 0, z: 0 }, { r: 13.35 / 2, z: 0 }, { r: 13.35 / 2, z: 1.4 }]);
});

test('belted case: ramp at delta to the belt, belt to E, step in to P1/2', () => {
  const g = Geometry.build(rec('300_win_mag'));
  assert.equal(g.rimType, 'belted');
  const zFloor = 1.27 + 0.94;
  assert.ok(has(g.outer, 12.07 / 2, zFloor));
  const zRamp = zFloor + (13.51 / 2 - 12.07 / 2) / Math.tan(deg(35));
  assert.ok(has(g.outer, 13.51 / 2, zRamp));
  near(g.beltRampEnd, zRamp);
  assert.ok(has(g.outer, 13.51 / 2, 5.59));
  assert.ok(has(g.outer, 13.03 / 2, 5.59));
  near(g.bodyStart.z, 5.59);
});

test('rimfire rim edge is a half-round whose outermost point lies at R1/2', () => {
  const g = Geometry.build(rec('17_hmr'));
  assert.equal(g.rimType, 'rimfire');
  const rim = g.outer.filter((p) => p.z <= 1.27 + 1e-9);
  near(Math.max(...rim.map((p) => p.r)), 7.47 / 2, 1e-9);
  const rho = Math.min(1.27 / 2, (7.47 - 6.15) / 2);
  assert.ok(has(g.outer, 7.47 / 2 - rho, 0));
  assert.ok(has(g.outer, 7.47 / 2, rho));
  assert.ok(has(g.outer, 7.47 / 2 - rho, 1.27));
  assert.ok(has(g.outer, 6.15 / 2, 1.27));
});

test('bottleneck passes through the published shoulder points (no corner radii)', () => {
  const g = Geometry.build(rec('17_hmr'));
  assert.ok(g.bottleneck);
  assert.ok(has(g.outer, 6.15 / 2, 22.2));
  assert.ok(has(g.outer, 4.9 / 2, 23.54));
  assert.ok(has(g.outer, 4.9 / 2, 27.03));
});

test('shoulder corners are rounded with r1 min and r2', () => {
  const g = Geometry.build(rec('6_5_x_55_se'));
  assert.ok(g.outer.filter((p) => p.arc).length >= 12);
  const plain = Geometry.build(Object.assign(clone(rec('6_5_x_55_se')), {}));
  assert.ok(plain.outer.every((p) => p.r >= 0));
  // tangent points lie on the published shoulder line
  const l1 = 43.49, l2 = 47.13, ra = 11.04 / 2, rb = 7.6 / 2;
  const arcs = g.outer.filter((p) => p.arc);
  for (const p of arcs) assert.ok(p.z > l1 - 4 && p.z < l2 + 4);
  near(Geometry.radiusAt(g.outer, (l1 + l2) / 2) - (ra + rb) / 2, 0, 0.35);
});

test('straight case runs to (H2/2, L3)', () => {
  const g = Geometry.build(rec('9_mm_luger'));
  assert.equal(g.bottleneck, false);
  assert.deepEqual(g.mouth, { r: 9.65 / 2, z: 19.15 });
  assert.ok(g.outer.every((p) => p.z <= 19.15));
  assert.deepEqual(g.notes, []);
});

test('walls, solid head and primer pocket', () => {
  let g = Geometry.build(rec('308_win'));
  near(g.walls.tn, (8.72 - 7.85) / 2);
  near(g.walls.tb, 0.6);
  assert.deepEqual(g.pocket, { d: 5.33, depth: 3.3 });
  near(g.w, 4.8);
  g = Geometry.build(rec('223_rem'));
  assert.deepEqual(g.pocket, { d: 4.45, depth: 3.04 });
  near(g.w, 3.13 + 0.6 > 3.04 + 1.5 ? 3.73 : 4.54);
  g = Geometry.build(rec('45_auto'));
  assert.deepEqual(g.pocket, { d: 5.33, depth: 3.04 });
  g = Geometry.build(rec('357_magnum'));
  assert.deepEqual(g.pocket, { d: 4.45, depth: 3.04 });
  g = Geometry.build(rec('44_rem_mag'));
  assert.deepEqual(g.pocket, { d: 5.33, depth: 3.04 });
  g = Geometry.build(rec('300_win_mag'));
  assert.deepEqual(g.pocket, { d: 5.33, depth: 3.3 });
  near(g.w, 4.8);
  g = Geometry.build(rec('22_long_rifle'));
  assert.equal(g.pocket, null);
  near(g.w, 2.5);
});

test('body wall: 0.35*P1/2 limit and 0.6 minimum', () => {
  const r = clone(rec('308_win'));
  r.cartridge.powderChamber.P1 = 2;
  near(Geometry.build(r).walls.tb, 0.35);
  const r2 = clone(rec('308_win'));
  r2.cartridge.collar.H2 = 10.5; // tn = 1.325, 1.3*tn = 1.7225
  near(Geometry.build(r2).walls.tb, 1.3 * 1.325);
});

test('inner line: tb on the body, tn on the neck, linear across the shoulder', () => {
  const g = Geometry.build(rec('17_hmr'));
  const { tb, tn } = g.walls;
  const t = (z) => Geometry.radiusAt(g.outer, z) - Geometry.radiusAt(g.inner, z);
  near(t(10), tb);
  near(t(22.2), tb);
  near(t((22.2 + 23.54) / 2), (tb + tn) / 2);
  near(t(25), tn);
  near(g.inner[0].z, g.w);
  near(g.inner[g.inner.length - 1].z, 27.03);
  near(g.inner[g.inner.length - 1].r, 4.9 / 2 - tn);
});

test('straight case: wall tapers to tn at the mouth, snug on the bullet', () => {
  const g = Geometry.build(rec('9_mm_luger'));
  near(g.inner[g.inner.length - 1].r, 9.03 / 2);
  near(Geometry.radiusAt(g.outer, 5) - Geometry.radiusAt(g.inner, 5), g.walls.tb);
});

test('heeled case (22 Long Rifle)', () => {
  const g = Geometry.build(rec('22_long_rifle'));
  assert.equal(g.heeled, true);
  assert.equal(Geometry.build(rec('22_win_mag_r_f')).heeled, false);
  const b = g.bullet;
  near(b.rExposed, 5.72 / 2);
  near(b.rHeel, 5.72 / 2 - 0.6);
  near(Geometry.radiusAt(g.outer, 8) - Geometry.radiusAt(g.inner, 8), 0.6);
  assert.ok(b.seated.every((p) => p.r <= b.rHeel + 1e-9));
  assert.deepEqual(b.exposed[0], { r: 5.72 / 2, z: 15.57 });
});

test('pointy bullet: seating depth G1, ogive on the tangent circle, meplat', () => {
  const b = Geometry.build(rec('308_win')).bullet;
  near(b.s, 7.85);
  near(b.zb, 51.18 - 7.85);
  near(b.Lb, 71.12 - b.zb);
  near(b.zc, b.zb + 0.4 * b.Lb);
  near(b.m, 1.27);
  const a = 7.85 / 2 - 1.27 / 2;
  const n = 71.12 - b.zc;
  near(b.rho, (a * a + n * n) / (2 * a));
  const cr = 7.85 / 2 - b.rho;
  for (const p of b.exposed.filter((q) => q.z > b.zc + 1e-9 && q.r > 0 && q.z < 71.12)) near(Math.hypot(p.z - b.zc, p.r - cr), b.rho, 1e-6);
  assert.deepEqual(b.exposed[b.exposed.length - 1], { r: 0, z: 71.12 });
  near(b.exposed[b.exposed.length - 2].r, 1.27 / 2);
  assert.deepEqual(b.seated[0], { r: 0, z: b.zb });
  near(b.exposed[0].r, 7.85 / 2);
  near(b.exposed[0].z, 51.18);
});

test('bullet seating depth and cylinder length by shape and category', () => {
  const cases = [
    ['9_mm_luger', 0.4 * 9.03, 0.65, 0.15 * 9.03],
    ['40_s_w', 0.4 * 10.17, 0.7, 0.55 * 10.17],
    ['357_magnum', 0.6 * 9.12, 0.78, 0.6 * 9.12],
    ['22_long_rifle', 0.8 * 5.72, 0.55, 0.15 * 5.72],
    ['22_win_mag_r_f', 0.8 * 5.7, 0.55, 0.15 * 5.7],
    ['17_hmr', 4.38, 0.4, Math.max(0.08 * 4.38, 1.27)]
  ];
  for (const [key, s, k, m] of cases) {
    const g = Geometry.build(rec(key));
    const b = g.bullet;
    near(b.s, s); near(b.k, k); near(b.m, m);
    near(b.zb, g.v.L3 - s);
    near(b.zc, b.zb + k * (g.v.L6 - b.zb));
  }
});

test('rounded nose is a quarter ellipse, flat and semi-wadcutter are cones', () => {
  const g = Geometry.build(rec('9_mm_luger'));
  const b = g.bullet;
  const a = 9.03 / 2 - b.m / 2, n = 29.69 - b.zc;
  for (const p of b.exposed.filter((q) => q.z > b.zc && q.r > 0 && q.z < 29.69 && q.r !== b.m / 2)) {
    near(((p.z - b.zc) / n) ** 2 + ((p.r - b.m / 2) / a) ** 2, 1, 1e-6);
  }
  const c = Geometry.build(rec('357_magnum')).bullet;
  const nose = c.exposed.filter((q) => q.z >= c.zc - 1e-9);
  assert.equal(nose.length, 3);
  near(nose[0].r, 9.12 / 2); near(nose[1].r, c.m / 2); near(nose[1].z, 40.39);
});

test('missing values are reported, never invented', () => {
  const lapua = Geometry.build(rec('338_lapua_mag'));
  assert.deepEqual(lapua.notes, [{ feature: 'shoulder corner radius', missing: ['r1Min'] }]);
  const hmr = Geometry.build(rec('17_hmr'));
  assert.deepEqual(hmr.notes, [{ feature: 'shoulder corner radius', missing: ['r1Min', 'r2'] }]);
  assert.deepEqual(Geometry.build(rec('22_long_rifle')).notes, [{ feature: 'head chamfer', missing: ['f'] }]);
  assert.deepEqual(Geometry.build(rec('308_win')).notes, []);
  const r = clone(rec('308_win'));
  delete r.cartridge.junctionCone.alpha;
  const g = Geometry.build(r);
  assert.equal(g.bottleneck, false);
  const r2 = clone(rec('308_win'));
  delete r2.cartridge.powderChamber.P2;
  const g2 = Geometry.build(r2);
  assert.equal(g2.bottleneck, false);
  assert.deepEqual(g2.notes, [{ feature: 'shoulder', missing: ['P2'] }]);
  const r3 = clone(rec('308_win'));
  delete r3.cartridge.projectile.G1;
  const g3 = Geometry.build(r3);
  assert.equal(g3.bullet, null);
  assert.ok(g3.notes.some((n) => n.missing.includes('G1')));
  const r4 = clone(rec('308_win'));
  delete r4.cartridge.caseHead.eMin;
  const g4 = Geometry.build(r4);
  assert.equal(g4.groove, null);
  assert.ok(g4.notes.some((n) => n.feature === 'extractor groove' && n.missing.includes('eMin')));
});

test('core values missing: no drawing', () => {
  const r = clone(rec('308_win'));
  delete r.cartridge.lengths.L3;
  const g = Geometry.build(r);
  assert.equal(g.ok, false);
  assert.deepEqual(g.missing, ['L3']);
});

test('all 25 records build consistent profiles', () => {
  for (const r of data) {
    const g = Geometry.build(r);
    assert.equal(g.ok, true, r.key);
    for (let i = 1; i < g.outer.length; i++) {
      assert.ok(g.outer[i].z >= g.outer[i - 1].z - 1e-9, `${r.key} z monotone at ${i}`);
      assert.ok(g.outer[i].r >= 0, r.key);
    }
    assert.ok(g.w < g.v.L3, r.key);
    for (const p of g.inner) assert.ok(p.r < Geometry.radiusAt(g.outer, p.z) + 1e-9 && p.r > 0, `${r.key} inner at ${p.z}`);
    assert.ok(g.bullet, r.key);
    assert.ok(g.bullet.zc >= g.v.L3, `${r.key} cylinder reaches the mouth`);
    assert.ok(g.bullet.zb > g.w, `${r.key} bullet base in the cavity`);
    for (const p of g.bullet.seated) assert.ok(p.r <= Geometry.radiusAt(g.inner, Math.max(p.z, g.inner[0].z)) + 1e-9, `${r.key} seated inside case`);
    const ex = g.bullet.exposed;
    for (let i = 1; i < ex.length; i++) assert.ok(ex[i].z >= ex[i - 1].z - 1e-9, r.key);
    near(ex[ex.length - 1].z, g.v.L6);
  }
});

test('published alpha agrees with the shoulder points within 1 degree', () => {
  for (const r of data) {
    const g = Geometry.build(r);
    if (!g.bottleneck) continue;
    const v = g.v;
    const half = Math.atan(((v.P2 - v.H1) / 2) / (v.L2 - v.L1)) * 180 / Math.PI;
    const published = typeof v.alpha === 'number' ? v.alpha : v.alpha.degrees + v.alpha.minutes / 60 + v.alpha.seconds / 3600;
    assert.ok(Math.abs(2 * half - published) < 1, `${r.key}: ${2 * half} vs ${published}`);
  }
});
