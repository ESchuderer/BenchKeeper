# C.I.P. cartridge reference

A static reference of 25 C.I.P. cartridges and chambers, with a computed true-to-scale drawing for each.
Modelled on the cartridge database of [OpenBallistics](https://openreloading.github.io/OpenBallistics/).

## Use

- **From disk:** open `index.html` in a browser (tested in Chromium via `file://`).
- **Served:** any static file server works (the e2e tests serve the folder with a 20-line Node server, `serve()` in `test/e2e/helpers.js`).

Detail views have bookmarkable addresses of the form `index.html#/cartridge/308_win`.
No build step, no framework, no network requests.

## Layout

| Path | Purpose |
| --- | --- |
| `index.html`, `css/style.css` | page and styles (light/dark, phone, A4 print) |
| `js/data.js` | the 25 records, unchanged (generated, see below) |
| `js/format.js` | numbers, angles, symbols, units, sections, list filter |
| `js/geometry.js` | pure cartridge geometry (profile, bullet, walls, notes) |
| `js/drawing.js` | dimension layout, label placement, SVG output |
| `js/app.js` | views and hash router |
| `test/` | unit tests (`node:test`) and e2e tests (Playwright) |
| `openspec/` | specification and design of the change |

## Development

Node.js 22. The app has no runtime dependencies; `playwright` is a dev dependency for the e2e tests.

```sh
npm install
npx playwright install chromium   # once, for e2e
npm test                          # unit tests
npm run test:e2e                  # browser tests: file://, static server, print to PDF
npm run build:data                # regenerate js/data.js from test/fixtures/cartridges.jsonl
```

If Chromium lacks system libraries or fonts (minimal containers), `test/e2e/helpers.js` uses
`~/.local/chromium-libs` and `~/.fonts/fonts.conf` when they exist.

## Data

Source: OpenBallistics (<https://github.com/PiMetry/OpenBallistics>, MIT, commit e83db43), values from C.I.P. TDCC.
The records are used exactly as given; a test compares `js/data.js` with the fixture.
Drawings use only published values. When a value a drawing feature needs is missing, the feature is left out and a note says which value is missing.
