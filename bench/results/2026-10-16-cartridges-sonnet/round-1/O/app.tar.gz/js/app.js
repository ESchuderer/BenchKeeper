// Views and hash router. All data goes through textContent, never innerHTML.
(function () {
  const { cartridges, format: F, drawing: D } = window.CIP;
  const app = document.getElementById('app');
  const FAMILIES = ['all', 'rimless', 'rimmed', 'belted', 'pistol', 'rimfire'];
  const filters = { q: '', family: 'all' }; // survives navigating to a detail view and back

  function h(tag, attrs, ...kids) {
    const el = document.createElement(tag);
    for (const [k, v] of Object.entries(attrs || {})) {
      if (v === false || v == null) continue;
      if (k.startsWith('on')) el.addEventListener(k.slice(2), v); else el.setAttribute(k, v === true ? '' : v);
    }
    for (const kid of kids.flat()) if (kid != null) el.append(kid);
    return el;
  }

  const backLink = () => h('a', { href: '#/', class: 'back' }, 'All cartridges');

  function listView() {
    document.title = 'C.I.P. cartridges';
    const search = h('input', { type: 'search', id: 'search', autocomplete: 'off', spellcheck: 'false', value: filters.q });
    const family = h('select', { id: 'family' }, FAMILIES.map((f) => h('option', { value: f, selected: f === filters.family }, f === 'all' ? 'All' : f)));
    const count = h('p', { class: 'count', 'aria-live': 'polite' });
    const body = h('tbody');
    function update() {
      filters.q = search.value; filters.family = family.value;
      const shown = cartridges.filter((r) => F.matches(r, search.value, family.value));
      body.replaceChildren(...shown.map((r) => h('tr', {},
        h('td', {}, h('a', { href: `#/cartridge/${r.key}` }, r.name)),
        h('td', {}, r.family),
        h('td', { class: 'num' }, `${F.num(r.cartridge.lengths.L3)} mm`))));
      count.textContent = `${shown.length} cartridges`;
    }
    search.addEventListener('input', update);
    family.addEventListener('change', update);
    update();
    return h('div', { class: 'list-view' },
      h('h1', { tabindex: '-1' }, 'Cartridges'),
      h('form', { class: 'controls', role: 'search', onsubmit: (e) => e.preventDefault() },
        h('label', { for: 'search' }, 'Search'), search,
        h('label', { for: 'family' }, 'Family'), family, count),
      h('table', { class: 'list' },
        h('thead', {}, h('tr', {}, h('th', { scope: 'col' }, 'Name'), h('th', { scope: 'col' }, 'Family'), h('th', { scope: 'col', class: 'num' }, 'L3'))),
        body));
  }

  function fact(label, content, wide) {
    return h('div', { class: wide ? 'wide' : null }, h('dt', {}, label), h('dd', {}, content || NP));
  }
  const NP = 'not published';

  function detailView(rec) {
    document.title = `${rec.name} – C.I.P. cartridges`;
    const cap = F.capacity(rec);
    const capEl = cap
      ? [cap.text, ' (source: ', h('a', { href: cap.url, target: '_blank', rel: 'noopener' }, cap.source), ')', cap.note ? ` – ${cap.note}` : '']
      : NP;
    const a = rec.annotations || {};
    const facts = h('dl', { class: 'facts' },
      fact('Alternative names', rec.alternativeNames ? rec.alternativeNames.join(', ') : NP, true),
      fact('Family', rec.family),
      fact('Category', a.category || NP),
      fact('Primer type', a.primerType || NP),
      fact('C.I.P. table', rec.tab || NP),
      fact('Country', rec.country || NP),
      fact('Published', rec.published || NP),
      fact('Revised', rec.revised || NP),
      fact('Pressure method', rec.pressureMethod || NP),
      fact('Water capacity', capEl, true));

    const model = D.buildModel(rec);
    const svgDoc = new DOMParser().parseFromString(D.toSvg(rec, model), 'image/svg+xml');
    const ok = svgDoc.documentElement.nodeName === 'svg';
    const figure = h('figure', { class: 'drawing-fig' }, ok ? svgDoc.documentElement : h('p', {}, 'Drawing unavailable.'));
    if (model.notes.length)
      figure.append(h('ul', { class: 'notes' }, model.notes.map((n) => h('li', {}, n))));

    const group = (title, part) => h('section', { class: 'group' }, h('h2', {}, title),
      h('div', { class: 'tables' }, F.sections(rec, part).map((s) => h('table', { class: 'values' },
        h('caption', {}, s.title),
        h('thead', {}, h('tr', {}, h('th', { scope: 'col' }, 'Symbol'), h('th', { scope: 'col', class: 'num' }, 'Value'), h('th', { scope: 'col' }, 'Unit'))),
        h('tbody', {}, s.rows.map((r) => h('tr', {}, h('th', { scope: 'row' }, r.symbol), h('td', { class: 'num' }, r.text), h('td', {}, r.unit))))))));

    return h('article', { class: 'detail' },
      h('nav', { class: 'toolbar' }, backLink(), h('button', { type: 'button', class: 'print', onclick: () => window.print() }, 'Print')),
      h('h1', { tabindex: '-1' }, rec.name),
      facts, figure,
      group('Cartridge', 'cartridge'), group('Chamber', 'chamber'),
      h('p', { class: 'source' }, rec.revised ? `Source: C.I.P. TDCC, revised ${rec.revised}` : 'Source: C.I.P. TDCC'));
  }

  function notFound() {
    document.title = 'Cartridge not found – C.I.P. cartridges';
    return h('div', {}, h('h1', { tabindex: '-1' }, 'Cartridge not found'), h('p', {}, 'No cartridge has this address.'), backLink());
  }

  let first = true;
  function render() {
    const m = /^#\/cartridge(?:\/(.*))?$/.exec(location.hash);
    let view;
    if (!m) view = listView();
    else {
      let key = m[1] || '';
      try { key = decodeURIComponent(key); } catch (e) { key = ''; }
      const rec = cartridges.find((r) => r.key === key);
      view = rec ? detailView(rec) : notFound();
    }
    app.replaceChildren(view);
    if (!first) { window.scrollTo(0, 0); const h1 = app.querySelector('h1'); if (h1) h1.focus({ preventScroll: true }); }
    first = false;
  }
  // the skip link must not change the hash: that would be a route change
  document.querySelector('.skip').addEventListener('click', (e) => { e.preventDefault(); app.focus(); });
  window.addEventListener('hashchange', render);
  render();
})();
