// Drawing layout and SVG output. SVG user unit = 1 mm; x = z (head on the left), y = -r (outside view, up) and +r (section, down).
(function (root) {
  const CIP = (root.CIP = root.CIP || {});
  const Gm = root.CIP.geometry || (typeof require !== 'undefined' ? require('./geometry.js') : null);
  const Fm = root.CIP.format || (typeof require !== 'undefined' ? require('./format.js') : null);

  const FONT_SIZE = 2.4;
  const CHAR_W = 0.64; // em per character: conservative for tabular digits in common sans fonts
  const LANE = 5, ARROW = 2.2, GAP = 0.8, A4_WIDTH = 190;
  const n = (x) => String(Math.round(x * 1000) / 1000);
  const esc = (s) => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  const up = ([z, r]) => [z, -r];
  const textW = (t, size = FONT_SIZE) => t.length * CHAR_W * size;

  function segHitsRect(a, b, r) {
    const inside = (p) => p[0] >= r.x && p[0] <= r.x + r.w && p[1] >= r.y && p[1] <= r.y + r.h;
    if (inside(a) || inside(b)) return true;
    const E = [[[r.x, r.y], [r.x + r.w, r.y]], [[r.x + r.w, r.y], [r.x + r.w, r.y + r.h]],
      [[r.x + r.w, r.y + r.h], [r.x, r.y + r.h]], [[r.x, r.y + r.h], [r.x, r.y]]];
    const ccw = (p, q, s) => (s[1] - p[1]) * (q[0] - p[0]) > (q[1] - p[1]) * (s[0] - p[0]);
    return E.some(([c, d]) => ccw(a, c, d) !== ccw(b, c, d) && ccw(a, b, c) !== ccw(a, b, d));
  }
  const rectsOverlap = (p, q) => p.x < q.x + q.w && q.x < p.x + p.w && p.y < q.y + q.h && q.y < p.y + p.h;

  function buildModel(rec) {
    const g = Gm.buildDrawing(rec);
    const key = rec.key;
    if (!g.ok) return { ok: false, key, name: rec.name, notes: g.notes, labels: [], dims: {}, shapes: {}, items: [], viewBox: [0, 0, 100, 20], title: { lines: [] } };
    const c = rec.cartridge, h = c.caseHead, le = c.lengths, pc = c.powderChamber, co = c.collar;
    const { L3, L6 } = le;
    const b = g.bullet;
    const items = []; // {t:'line'|'poly'|'arrow', ...}; the section view uses +r as +y, so only the upper half is flipped
    const labels = [];
    const dims = {};
    const pts = []; // all points for the bounding box

    // ---- shapes of the case and the bullet
    const pr = g.pocket ? g.pocket.d / 2 : 0;
    const outerLowerRZ = [[0, pr]];
    g.outer.forEach((p) => { if (!(p[0] === 0 && p[1] < pr) && (p[0] !== outerLowerRZ.at(-1)[0] || p[1] !== outerLowerRZ.at(-1)[1])) outerLowerRZ.push(p); });
    const mouthRZ = [L3, co.H2 / 2];
    const innerPathRZ = [mouthRZ, ...[...g.inner].reverse(), [g.w, 0]];
    const shapes = {
      outerUpper: g.outer.map(up),
      outerLower: outerLowerRZ,
      bulletUpper: b ? [mouthRZ, ...b.exposed].map(up) : [],
      bulletLower: b ? b.full : [],
      innerLower: innerPathRZ,
      pocketLower: g.pocket ? [[0, pr], [g.pocket.depth, pr], [g.pocket.depth, 0]] : [],
      hatch: g.hatch,
    };
    const outline = [shapes.outerUpper, shapes.outerLower, shapes.bulletUpper, shapes.bulletLower, shapes.innerLower, shapes.pocketLower];
    outline.forEach((p) => pts.push(...p));

    // ---- primitives
    const line = (a, bb, cls) => { items.push({ t: 'line', a, b: bb, cls }); pts.push(a, bb); };
    function arrow(tip, outward, inward) {
      // outward: unit vector pointing out of the dimension line at `tip`; inward arrows have their tail inside.
      const len = ARROW, hw = 0.45;
      const dir = inward ? [-outward[0], -outward[1]] : outward; // direction of travel into the tip
      const tail = [tip[0] - dir[0] * len, tip[1] - dir[1] * len];
      const nrm = [-dir[1], dir[0]];
      const tri = [tip, [tail[0] + nrm[0] * hw, tail[1] + nrm[1] * hw], [tail[0] - nrm[0] * hw, tail[1] - nrm[1] * hw]];
      items.push({ t: 'arrow', pts: tri }); pts.push(...tri);
    }
    function dimLine(a, bb) {
      const L = Math.hypot(bb[0] - a[0], bb[1] - a[1]);
      const u = [(bb[0] - a[0]) / L, (bb[1] - a[1]) / L];
      const short = L < 6;
      if (short) {
        const ext = ARROW + 1;
        line([a[0] - u[0] * ext, a[1] - u[1] * ext], [bb[0] + u[0] * ext, bb[1] + u[1] * ext], 'dim');
        arrow(a, [-u[0], -u[1]], true); arrow(bb, u, true);
      } else {
        line(a, bb, 'dim');
        arrow(a, [-u[0], -u[1]], false); arrow(bb, u, false);
      }
    }
    function addLabel(id, text, cx, cy, rot) {
      const w = rot ? FONT_SIZE : textW(text), hh = rot ? textW(text) : FONT_SIZE;
      const l = { id, text, x: cx - w / 2, y: cy - hh / 2, w, h: hh, cx, cy, rot: !!rot };
      labels.push(l); pts.push([l.x, l.y], [l.x + w, l.y + hh]);
      return l;
    }
    const symText = (k, v) => `${Fm.symbol(k)} ${v}`;
    const num = Fm.num;

    // ---- length dimensions in lanes above the outside view
    const Rtop = Math.max(...g.outer.map((p) => p[1]));
    const lengths = [['R', 0, h.R, -h.R1 / 2]];
    if (g.shape === 'bottleneck') lengths.push(['L1', 0, le.L1, -pc.P2 / 2], ['L2', 0, le.L2, -co.H1 / 2]);
    lengths.push(['L3', 0, L3, -co.H2 / 2], ['L6', 0, L6, b ? -b.m / 2 : 0]);
    lengths.forEach(([k, z0, z1, ay], i) => {
      const y = -(Rtop + 6 + i * LANE);
      dims[k] = { a: [z0, y], b: [z1, y], value: z1 - z0 };
      dimLine([z0, y], [z1, y]);
      line([z1, ay - GAP], [z1, y - 1.5], 'ext');
      if (k === 'R') {
        addLabel(k, symText(k, num(h.R)), z1 + 4 + textW(symText(k, num(h.R))) / 2, y);
      } else addLabel(k, symText(k, num(z1)), (z0 + z1) / 2, y - GAP - FONT_SIZE / 2);
    });
    const topLane = -(Rtop + 6 + (lengths.length - 1) * LANE);
    line([0, -h.R1 / 2 - GAP], [0, topLane - 1.5], 'ext');

    // ---- diameter dimensions: vertical lines in lanes right of the bullet tip and left of the head
    function diameterLane(k, d, anchorZ, x, side) {
      const a = [x, -d / 2], bb = [x, d / 2];
      dims[k] = { a, b: bb, value: d };
      dimLine(a, bb);
      const dir = side === 'right' ? 1 : -1;
      [-1, 1].forEach((s) => line([anchorZ + dir * GAP, s * d / 2], [x + dir * 1.5, s * d / 2], 'ext'));
      addLabel(k, symText(k, num(d)), x + dir * (1.5 + FONT_SIZE / 2), 0, true);
    }
    const right = [['G1', c.projectile.G1, b && b.zc > L3 ? b.zc : L3]];
    right.push(['H2', co.H2, L3]);
    if (g.shape === 'bottleneck') right.push(['H1', co.H1, le.L2], ['P2', pc.P2, le.L1]);
    right.push(['P1', pc.P1, g.z0]);
    right.sort((p, q) => p[1] - q[1]).forEach(([k, d, z], i) => diameterLane(k, d, z, L6 + 7 + i * 6.5, 'right'));
    const left = [['R1', h.R1, 0]];
    if (g.grooved) left.push(['E1', h.E1, h.R]);
    left.sort((p, q) => p[1] - q[1]).forEach(([k, d, z], i) => diameterLane(k, d, z, -6 - i * 5.5, 'left'));

    // ---- shoulder angle: construction lines to the apex, an arc between them, label on a leader
    let alphaLabel = null;
    if (g.cone && g.cone.apex) {
      const [za] = g.cone.apex, v2 = g.cone.v2;
      const dist = Math.hypot(za - v2[0], v2[1]);
      const half = Math.atan2(v2[1], za - v2[0]);
      const t = Math.min(8, 0.6 * dist), rho = dist - t; // arc sits t mm along the cone line from the neck end
      const along = (d) => [v2[0] + (za - v2[0]) * (d / dist), v2[1] * (1 - d / dist)];
      line(up(v2), up(along(t + 1.5)), 'cone'); line(v2, along(t + 1.5), 'cone');
      const arcPts = [];
      for (let i = 0; i <= 24; i++) {
        const t = Math.PI - half + (2 * half * i) / 24;
        arcPts.push([za + rho * Math.cos(t), rho * Math.sin(t)]);
      }
      items.push({ t: 'poly', pts: arcPts, cls: 'dim' }); pts.push(...arcPts);
      const tUp = arcPts[arcPts.length - 1], tLo = arcPts[0];
      const tang = (p, q) => { const L = Math.hypot(q[0] - p[0], q[1] - p[1]); return [(q[0] - p[0]) / L, (q[1] - p[1]) / L]; };
      arrow(tUp, tang(arcPts[arcPts.length - 2], tUp), false); arrow(tLo, tang(arcPts[1], tLo), false);
      const text = symText('alpha', Fm.angle(rec.cartridge.junctionCone.alpha));
      const w = textW(text);
      const hard = outline.flatMap((p) => p.slice(1).map((q, i) => [p[i], q]));
      const soft = items.filter((it) => it.t === 'line').map((it) => [it.a, it.b]);
      const bad = (r, useSoft) => labels.some((l) => rectsOverlap(r, l)) || hard.some(([p, q]) => segHitsRect(p, q, r)) || (useSoft && soft.some(([p, q]) => segHitsRect(p, q, r)));
      let found = null;
      for (const useSoft of [true, false]) {
        for (const dy of [4, 6.5, 9, 11.5, 14, 17, 20, 24]) {
          for (const dx of [0, -6, 6, -12, 12, -18, 18, -26, 26, -36, 36]) {
            const r = { x: tUp[0] + dx - w / 2, y: tUp[1] - dy - FONT_SIZE / 2, w, h: FONT_SIZE };
            if (!bad(r, useSoft)) { found = { r, dx, dy }; break; }
          }
          if (found) break;
        }
        if (found) break;
      }
      if (!found) found = { r: { x: tUp[0] - w / 2, y: tUp[1] - 30, w, h: FONT_SIZE }, dx: 0, dy: 30 };
      alphaLabel = addLabel('α', text, found.r.x + w / 2, found.r.y + FONT_SIZE / 2);
      line(tUp, [alphaLabel.cx, alphaLabel.y + alphaLabel.h], 'leader');
      dims['α'] = { a: tLo, b: tUp, value: null };
    }

    // ---- bounding box, title block
    const bb = { minX: Infinity, minY: Infinity, maxX: -Infinity, maxY: -Infinity };
    pts.forEach(([x, y]) => { bb.minX = Math.min(bb.minX, x); bb.minY = Math.min(bb.minY, y); bb.maxX = Math.max(bb.maxX, x); bb.maxY = Math.max(bb.maxY, y); });
    // title block: top right, above the diameter lanes and clear of the length lanes
    const lines = [rec.name, `C.I.P. Tab. ${rec.tab || 'n/a'}`, `Rev. ${rec.revised || 'n/a'}`, 'Dimensions in mm', 'Scale 0.0 : 1 on A4'];
    const bw = Math.max(textW(lines[3]), textW(lines[4]), textW(rec.name, 3.2)) + 4;
    const bh = 4 + 3.6 + 4 * 3.4;
    const rightHalf = Math.max(...right.map(([, d]) => d / 2 + (d < 6 ? ARROW + 1 : 0)));
    const bx = Math.max(bb.maxX - bw, L6 + 3);
    const by = -(rightHalf + 5) - bh;
    const block = { x: bx, y: by, w: bw, h: bh };
    const M = 4;
    const minX = bb.minX, maxX = Math.max(bb.maxX, bx + bw), minY = Math.min(bb.minY, by);
    const vb = [minX - M, minY - M, maxX - minX + 2 * M, bb.maxY - minY + 2 * M];
    lines[4] = `Scale ${(A4_WIDTH / vb[2]).toFixed(1)} : 1 on A4`;

    return {
      ok: true, key, name: rec.name, rimType: g.rimType, shape: g.shape, shapes, items, labels, dims, notes: g.notes,
      title: { lines, block }, viewBox: vb.map((x) => +n(x)),
    };
  }

  const pointsAttr = (p) => p.map(([x, y]) => `${n(x)},${n(y)}`).join(' ');
  const SW = { ol: 0.35, dim: 0.15, ext: 0.12, cone: 0.12, leader: 0.12, ctr: 0.2 };

  function toSvg(rec, model) {
    const m = model || buildModel(rec);
    const id = 'drw-' + rec.key;
    const vb = m.viewBox;
    const label = `${rec.name} drawing`;
    const out = [];
    out.push(`<svg xmlns="http://www.w3.org/2000/svg" class="drawing" viewBox="${vb.map(n).join(' ')}" role="img" aria-labelledby="${id}-t" aria-describedby="${id}-d" preserveAspectRatio="xMidYMid meet" fill="none" stroke="currentColor" font-size="${FONT_SIZE}" stroke-linejoin="round" style="font-variant-numeric:tabular-nums">`);
    out.push(`<title id="${id}-t">${esc(label)}</title>`);
    if (!m.ok) {
      out.push(`<desc id="${id}-d">${esc(m.notes.join(' '))}</desc></svg>`);
      return out.join('');
    }
    out.push(`<desc id="${id}-d">${esc(`${m.rimType} ${m.shape} case, section below the axis; dimensions in millimetres`)}</desc>`);
    out.push(`<defs><pattern id="${id}-h" width="0.8" height="0.8" patternUnits="userSpaceOnUse" patternTransform="rotate(45)"><line x1="0" y1="0" x2="0" y2="0.8" stroke-width="0.12"/></pattern></defs>`);
    const s = m.shapes;
    out.push(`<polygon class="hatch" points="${pointsAttr(s.hatch)}" fill="url(#${id}-h)" stroke="none"/>`);
    out.push(`<line class="ctr" x1="-3" y1="0" x2="${n(rec.cartridge.lengths.L6 + 3)}" y2="0" stroke-width="${SW.ctr}" stroke-dasharray="4 1 0.6 1"/>`);
    out.push(`<g class="outline" stroke-width="${SW.ol}">`);
    for (const k of ['outerUpper', 'outerLower', 'bulletUpper', 'bulletLower', 'innerLower', 'pocketLower'])
      if (s[k].length) out.push(`<polyline points="${pointsAttr(s[k])}"/>`);
    out.push('</g><g class="dims">');
    for (const it of m.items) {
      if (it.t === 'line') out.push(`<line class="${it.cls}" x1="${n(it.a[0])}" y1="${n(it.a[1])}" x2="${n(it.b[0])}" y2="${n(it.b[1])}" stroke-width="${SW[it.cls]}"${it.cls === 'cone' ? ' stroke-dasharray="1.2 0.6"' : ''}/>`);
      else if (it.t === 'arrow') out.push(`<polygon class="arrow" points="${pointsAttr(it.pts)}" fill="currentColor" stroke="none"/>`);
      else if (it.t === 'poly') out.push(`<polyline class="${it.cls}" points="${pointsAttr(it.pts)}" stroke-width="${SW[it.cls]}"/>`);
    }
    out.push('</g><g class="labels" fill="currentColor" stroke="none" text-anchor="middle" dominant-baseline="central" style="stroke:var(--paper,#fff);stroke-width:0.7;paint-order:stroke;stroke-linejoin:round">');
    for (const l of m.labels) {
      const tr = l.rot ? ` transform="rotate(-90 ${n(l.cx)} ${n(l.cy)})"` : '';
      out.push(`<text class="label" data-dim="${esc(l.id)}" x="${n(l.cx)}" y="${n(l.cy)}"${tr}>${esc(l.text)}</text>`);
    }
    const t = m.title.block, tl = m.title.lines;
    out.push('</g>');
    out.push(`<g class="title-block"><rect x="${n(t.x)}" y="${n(t.y)}" width="${n(t.w)}" height="${n(t.h)}" stroke-width="0.35"/>`);
    out.push(`<g fill="currentColor" stroke="none" dominant-baseline="central"><text x="${n(t.x + 2)}" y="${n(t.y + 3.2)}" font-size="3.2" font-weight="bold">${esc(tl[0])}</text>`);
    tl.slice(1).forEach((x, i) => out.push(`<text x="${n(t.x + 2)}" y="${n(t.y + 7.2 + i * 3.4)}">${esc(x)}</text>`));
    out.push('</g></g></svg>');
    return out.join('');
  }

  CIP.drawing = { buildModel, toSvg, FONT_SIZE };
  if (typeof module !== 'undefined') module.exports = CIP.drawing;
})(typeof window !== 'undefined' ? window : globalThis);
