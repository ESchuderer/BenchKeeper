// Formatting of published values: numbers, angles, symbols, units, sections, capacity, list filtering.
(function (root) {
  const CIP = (root.CIP = root.CIP || {});

  const SYMBOLS = {
    eMin: 'e min', r1Min: 'r1 min', r1Max: 'r1 max', alpha: 'α', alpha1: 'α1',
    beta: 'β', delta: 'δ', deltaL: 'delta L', L3PlusG: 'L3 + G',
  };
  const ANGLES = new Set(['alpha', 'alpha1', 'beta', 'delta', 'i']);
  const UNITS = { Pmax: 'bar', PK: 'bar', PE: 'bar', EE: 'J', M: 'g', Q: 'mm²', N: '' };

  const SECTION_TITLES = {
    caseHead: 'Case head', collar: 'Collar', junctionCone: 'Junction cone', lengths: 'Lengths',
    misc: 'Misc', powderChamber: 'Powder chamber', pressures: 'Pressures', projectile: 'Projectile',
    barrel: 'Barrel', breech: 'Breech', grooves: 'Grooves', rifling: 'Rifling',
  };

  const num = (n) => String(n);
  const angle = (a) =>
    typeof a === 'number' ? `${num(a)}°` : `${num(a.degrees)}°${num(a.minutes)}'${num(a.seconds)}"`;
  const symbol = (field) => SYMBOLS[field] || field;
  const unit = (field) => (ANGLES.has(field) ? '' : field in UNITS ? UNITS[field] : 'mm');
  const value = (field, v) => (ANGLES.has(field) ? angle(v) : num(v));

  // One table per non-empty record section; `<X>Tol` merges into X's value text.
  function sections(rec, part) {
    return Object.entries(rec[part])
      .map(([id, obj]) => ({
        id,
        title: SECTION_TITLES[id] || id,
        rows: Object.keys(obj)
          .filter((k) => !k.endsWith('Tol'))
          .map((k) => {
            const tol = k + 'Tol' in obj ? num(obj[k + 'Tol']) : '';
            const v = value(k, obj[k]);
            return { key: k, symbol: symbol(k), value: v, tol, text: tol ? `${v} ${tol}` : v, unit: unit(k) };
          }),
      }))
      .filter((s) => s.rows.length);
  }

  function capacity(rec) {
    const c = rec.annotations && rec.annotations.publishedCapacity;
    return c ? { text: `${num(c.grH2O)} gr H2O`, source: c.source, url: c.url, note: c.note || '' } : null;
  }

  function matches(rec, query, family) {
    if (family && family !== 'all' && rec.family !== family) return false;
    const q = query.trim().toLowerCase();
    return !q || [rec.name, ...(rec.alternativeNames || [])].some((n) => n.toLowerCase().includes(q));
  }

  CIP.format = { num, angle, symbol, unit, sections, capacity, matches, SECTION_TITLES };
  if (typeof module !== 'undefined') module.exports = CIP.format;
})(typeof window !== 'undefined' ? window : globalThis);
