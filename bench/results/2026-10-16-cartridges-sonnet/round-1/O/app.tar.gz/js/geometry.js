// Pure cartridge geometry. Points are [z, r]: z along the axis from the head face, r the radius (>= 0).
// The brief writes the same points as (r, z). The lower half of the drawing is the mirror image.
(function (root) {
  const CIP = (root.CIP = root.CIP || {});

  const isNum = (x) => typeof x === 'number' && Number.isFinite(x);
  const deg = (a) => (typeof a === 'number' ? a : a.degrees + a.minutes / 60 + a.seconds / 3600);
  const rad = (d) => (d * Math.PI) / 180;
  const Fm = root.CIP.format || (typeof require !== 'undefined' ? require('./format.js') : null);
  const sym = (k) => Fm.symbol(k);
  const missing = (obj, keys) => keys.filter((k) => !isNum(obj[k]) && !(obj[k] && isNum(obj[k].degrees)));

  const POCKETS = { sp: [4.45, 3.04], spm: [4.45, 3.04], sr: [4.45, 3.04], lp: [5.33, 3.04], lpm: [5.33, 3.04], lr: [5.33, 3.3], lrm: [5.33, 3.3] };

  function rimType(rec) {
    if (rec.family === 'belted') return 'belted';
    if (rec.family === 'rimfire') return 'rimfire';
    const ratio = rec.cartridge.caseHead.R1 / rec.cartridge.powderChamber.P1;
    return ratio >= 1.05 ? 'rimmed' : ratio < 0.98 ? 'rebated' : 'rimless';
  }

  const same = (a, b) => Math.abs(a[0] - b[0]) < 1e-12 && Math.abs(a[1] - b[1]) < 1e-12;
  function push(poly, p) { if (!poly.length || !same(poly[poly.length - 1], p)) poly.push(p); }

  // r of a polyline at z (last segment covering z, so vertical steps give the outer value)
  function rAt(poly, z) {
    for (let i = poly.length - 1; i > 0; i--) {
      const [z0, r0] = poly[i - 1], [z1, r1] = poly[i];
      if (z >= Math.min(z0, z1) - 1e-12 && z <= Math.max(z0, z1) + 1e-12 && z1 !== z0) return r0 + ((r1 - r0) * (z - z0)) / (z1 - z0);
    }
    return poly[poly.length - 1][1];
  }

  // Tangent arc replacing the corner at b between a and c. The tangent length is capped at 45% of the
  // shorter neighbouring segment so arcs never cross. Returns points from the first to the second tangent point.
  function fillet(a, b, c, radius) {
    const l1 = Math.hypot(b[0] - a[0], b[1] - a[1]), l2 = Math.hypot(c[0] - b[0], c[1] - b[1]);
    const u1 = [(b[0] - a[0]) / l1, (b[1] - a[1]) / l1], u2 = [(c[0] - b[0]) / l2, (c[1] - b[1]) / l2];
    const cross = u1[0] * u2[1] - u1[1] * u2[0];
    const theta = Math.atan2(Math.abs(cross), u1[0] * u2[0] + u1[1] * u2[1]);
    if (theta < 1e-6) return [b];
    const t = Math.min(radius * Math.tan(theta / 2), 0.45 * Math.min(l1, l2));
    const rr = t / Math.tan(theta / 2);
    const t1 = [b[0] - u1[0] * t, b[1] - u1[1] * t];
    const side = Math.sign(cross); // +: turning towards +r (counter-clockwise in [z, r])
    const n = [-u1[1] * side, u1[0] * side];
    const cen = [t1[0] + n[0] * rr, t1[1] + n[1] * rr];
    const a0 = Math.atan2(t1[1] - cen[1], t1[0] - cen[0]);
    const steps = Math.max(2, Math.ceil(theta / rad(5)));
    const pts = [];
    for (let i = 0; i <= steps; i++) {
      const ang = a0 + side * (theta * i) / steps;
      pts.push([cen[0] + rr * Math.cos(ang), cen[1] + rr * Math.sin(ang)]);
    }
    return pts;
  }

  function lerpWall(z, z0, w0, z1, w1) { return z <= z0 ? w0 : z >= z1 ? w1 : w0 + ((w1 - w0) * (z - z0)) / (z1 - z0); }

  function buildBullet(rec, ctx) {
    const { L3, L6, G1, H2, tb } = ctx;
    const ann = rec.annotations || {};
    const shape = ann.defaultBulletShape;
    const pistol = ann.category === 'pistol';
    const heeled = H2 - G1 <= 0.015;
    const Gx = heeled ? H2 : G1;
    const sMul = { pointy: 1, rounded: pistol ? 0.4 : 0.8, flat: pistol ? 0.4 : 0.8, semi_wadcutter: 0.6 }[shape];
    const k = { pointy: 0.4, rounded: pistol ? 0.65 : 0.55, flat: pistol ? 0.7 : 0.6, semi_wadcutter: 0.78 }[shape];
    const mm = { pointy: Math.max(0.08 * G1, 1.27), rounded: 0.15 * G1, flat: 0.55 * G1, semi_wadcutter: 0.6 * G1 }[shape];
    if (!sMul) return null;
    const s = sMul * G1, zb = L3 - s, Lb = L6 - zb, zc = zb + k * Lb, n = L6 - zc;
    const R = Gx / 2, m = mm * (Gx / G1), hw = R - m / 2;
    const nose = [];
    let rho = null, center = null;
    const N = 48;
    if (shape === 'pointy') {
      rho = (hw * hw + n * n) / (2 * hw);
      center = [zc, R - rho];
      const thEnd = Math.atan2(n, rho - hw);
      for (let i = 0; i <= N; i++) {
        const th = (thEnd * i) / N;
        nose.push([zc + rho * Math.sin(th), center[1] + rho * Math.cos(th)]);
      }
      nose[nose.length - 1] = [L6, m / 2];
    } else if (shape === 'rounded') {
      for (let i = 0; i <= N; i++) {
        const ph = (Math.PI / 2 * i) / N;
        nose.push([zc + n * Math.sin(ph), m / 2 + hw * Math.cos(ph)]);
      }
    } else {
      nose.push([zc, R], [L6, m / 2]);
    }
    const tip = [L6, 0];
    // outside view: only the part beyond the mouth
    const full = [[zb, 0]];
    if (heeled) full.push([zb, H2 / 2 - tb], [L3, H2 / 2 - tb], [L3, R]); else full.push([zb, R]);
    full.push(...nose, tip);
    const exposed = [];
    const i = nose.findIndex((p) => p[0] >= L3);
    if (zc < L3 && i > 0) {
      const [a, b] = [nose[i - 1], nose[i]];
      exposed.push([L3, a[1] + ((b[1] - a[1]) * (L3 - a[0])) / (b[0] - a[0])], ...nose.slice(i));
    } else exposed.push([L3, R], [zc, R], ...nose);
    exposed.push(tip);
    return { shape, heeled, s, zb, Lb, k, zc, n, m, rho, center, nose, full, exposed, exposedRadius: R, heelRadius: H2 / 2 - tb, G1, notes: [] };
  }

  function buildDrawing(rec) {
    const c = rec.cartridge, h = c.caseHead, le = c.lengths, jc = c.junctionCone || {}, co = c.collar, pc = c.powderChamber;
    const notes = [];
    const req = [['R1', h], ['R', h], ['P1', pc], ['H2', co], ['L3', le], ['L6', le], ['G1', c.projectile]];
    const lacking = req.filter(([k, o]) => !isNum(o[k])).map(([k]) => k);
    if (lacking.length) return { ok: false, rimType: null, notes: [`Drawing not available: ${lacking.join(', ')} not published`] };

    const { R1, R } = h, { P1 } = pc, { H2 } = co, { L3, L6 } = le, { G1 } = c.projectile;
    const type = rimType(rec);
    const outer = [[0, 0]];
    let z0, belt = false, z1 = null, hasGroove = false;

    // head face and rim
    if (type === 'rimfire') {
      const rr = Math.min(R / 2, (R1 - P1) / 2), cr = R1 / 2 - rr, cz = R / 2;
      push(outer, [0, cr]);
      if (rr < R / 2) push(outer, [cz - rr, cr]);
      for (let i = 0; i <= 36; i++) { const t = (Math.PI * i) / 36; push(outer, [cz - rr * Math.cos(t), cr + rr * Math.sin(t)]); }
      if (rr < R / 2) push(outer, [R, cr]);
      push(outer, [R, P1 / 2]);
      z0 = R;
    } else {
      const miss = missing(h, ['beta', 'f']);
      if (!miss.length && deg(h.beta) < 90) {
        const ch = Math.min(h.f * Math.tan(rad(deg(h.beta))), R1 / 4);
        push(outer, [0, R1 / 2 - ch]); push(outer, [h.f, R1 / 2]);
      } else {
        if (miss.length) notes.push(`Chamfer not drawn: ${miss.map(sym).join(', ')} not published`);
        push(outer, [0, R1 / 2]);
      }
      push(outer, [R, R1 / 2]);
      const gmiss = missing(h, ['E', 'E1', 'eMin']);
      if (!gmiss.length) {
        hasGroove = true;
        push(outer, [R, h.E1 / 2]); push(outer, [R + h.eMin, h.E1 / 2]);
        z0 = h.E;
        if (type === 'belted') {
          const bmiss = missing(h, ['R3', 'delta']);
          if (bmiss.length) notes.push(`Belt not drawn: ${bmiss.map(sym).join(', ')} not published`);
          else {
            belt = true;
            z1 = R + h.eMin + (h.R3 / 2 - h.E1 / 2) / Math.tan(rad(deg(h.delta)));
            push(outer, [z1, h.R3 / 2]); push(outer, [h.E, h.R3 / 2]); push(outer, [h.E, P1 / 2]);
          }
        }
        if (!belt) push(outer, [h.E, P1 / 2]);
      } else {
        notes.push(`Extractor groove not drawn: ${gmiss.map(sym).join(', ')} not published`);
        push(outer, [R, P1 / 2]);
        z0 = R;
      }
    }

    // body, shoulder, neck
    const start = [z0, P1 / 2], mouth = [L3, H2 / 2];
    let shape = 'straight', vertices = [start, mouth], cone = null;
    const hasShoulder = isNum(le.L1) && isNum(le.L2) && jc.alpha !== undefined;
    if (hasShoulder) {
      const smiss = missing({ P2: pc.P2, H1: co.H1 }, ['P2', 'H1']);
      if (smiss.length) notes.push(`Shoulder not drawn: ${smiss.join(', ')} not published`);
      else { shape = 'bottleneck'; vertices = [start, [le.L1, pc.P2 / 2], [le.L2, co.H1 / 2], mouth]; }
    }
    const body = [start];
    if (shape === 'bottleneck') {
      const [, v1, v2] = vertices;
      let arc1 = [v1], arc2 = [v2];
      if (isNum(jc.r1Min)) arc1 = fillet(start, v1, v2, jc.r1Min); else notes.push('Shoulder corner not rounded: r1 min not published');
      if (isNum(jc.r2)) arc2 = fillet(v1, v2, mouth, jc.r2); else notes.push('Neck corner not rounded: r2 not published');
      arc1.forEach((p) => push(body, p)); arc2.forEach((p) => push(body, p));
      const slope = (v1[1] - v2[1]) / (v2[0] - v1[0]);
      cone = { apex: [v2[0] + v2[1] / slope, 0], v1, v2 };
    }
    push(body, mouth);
    body.slice(1).forEach((p) => push(outer, p));

    // walls, pocket, solid head
    const heeled = H2 - G1 <= 0.015;
    const tn0 = (H2 - G1) / 2;
    const tb = Math.min(Math.max(1.3 * tn0, 0.6), 0.35 * P1 / 2);
    const tn = heeled ? tb : tn0;
    const pk = (rec.annotations || {}).primerType;
    const pocket = type !== 'rimfire' && POCKETS[pk] ? { d: POCKETS[pk][0], depth: POCKETS[pk][1] } : null;
    const grooveEnd = type === 'rimfire' ? 0 : belt ? z1 + tb : hasGroove ? h.E + tb : 0;
    const w = Math.max(2.5, 0.25 * P1 / 2, pocket ? pocket.depth + 1.5 : 0, grooveEnd);

    const bullet = buildBullet(rec, { L3, L6, G1, H2, tb });
    if (!bullet) notes.push(`Bullet not drawn: shape "${(rec.annotations || {}).defaultBulletShape}" not published or unknown`);
    const zbWall = bullet ? bullet.zb : L3; // without a bullet, only the mouth is thinned
    const bodyOuter = [[0, P1 / 2], ...body];
    let wall;
    if (shape === 'bottleneck') wall = (z) => lerpWall(z, le.L1, tb, le.L2, tn);
    else wall = (z) => lerpWall(z, zbWall - (tb - tn), tb, zbWall, tn);
    const zs = new Set([w, L3]);
    body.forEach((p) => { if (p[0] > w && p[0] < L3) zs.add(p[0]); });
    const bp = shape === 'bottleneck' ? [le.L1, le.L2] : [zbWall - (tb - tn), zbWall];
    bp.forEach((z) => { if (z > w && z < L3) zs.add(z); });
    const inner = [...zs].sort((a, b) => a - b).map((z) => [z, rAt(bodyOuter, z) - wall(z)]);
    inner[inner.length - 1] = [L3, H2 / 2 - tn];

    // hatch polygon (upper-half coordinates, r >= 0)
    const pr = pocket ? pocket.d / 2 : 0;
    const hatch = [[0, pr]];
    outer.forEach((p) => { if (!(p[0] === 0 && p[1] < pr)) push(hatch, p); });
    push(hatch, [L3, H2 / 2 - tn]);
    for (let i = inner.length - 1; i >= 0; i--) push(hatch, inner[i]);
    push(hatch, [w, 0]);
    if (pocket) { push(hatch, [pocket.depth, 0]); push(hatch, [pocket.depth, pr]); }
    else push(hatch, [0, 0]);

    const pts = [outer, bullet ? bullet.full : []].flat();
    const bbox = {
      minZ: Math.min(...pts.map((p) => p[0])), maxZ: Math.max(...pts.map((p) => p[0])),
      maxR: Math.max(...pts.map((p) => p[1])),
    };
    return { ok: true, rimType: type, shape, vertices, outer, bodyOuter, inner, hatch, w, walls: { tn, tb }, pocket, bullet, cone, notes, bbox, belt, grooved: hasGroove, grooveEndZ: z1, z0 };
  }

  CIP.geometry = { buildDrawing, rimType, rAt };
  if (typeof module !== 'undefined') module.exports = CIP.geometry;
})(typeof window !== 'undefined' ? window : globalThis);
