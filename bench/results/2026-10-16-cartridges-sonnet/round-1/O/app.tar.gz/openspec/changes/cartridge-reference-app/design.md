# Design

## Context

Greenfield: `/work` holds only OpenSpec scaffolding. Requirements and motivation are in `proposal.md` and `specs/`. Hard constraints: plain HTML/CSS/JS, no build step, no network, must run from `file://` in Chromium. Under `file://` Chromium blocks ES module scripts and `fetch()` of local files, which shapes the module and data decisions. The 25 records are given verbatim and must stay unchanged. Several records have quirks the code must survive: `junctionCone: {}`, `i` as a plain number, a missing `alternativeNames`/`publishedCapacity`, `beta: 0`, `G2: 68.61` (as published, shown as is), `L4`/`L5`/`G2`/`Fe` fields not named in the brief (shown under their field name), and a name containing `&` (`40 S.& W.`).

## Goals / Non-Goals

**Goals:** a pure, unit-testable geometry core (record in → polylines, dimensions, notes out); every spec scenario covered by an automated test; the same drawing code serves screen and print.

**Non-Goals:** editing or fetching data, URL state for search/filter, unit conversion, a bullet boat-tail or other shape detail not in the geometry rules, a full CAD-grade dimensioning engine.

## Decisions

### D1. Classic scripts on one global namespace, data as a JS file
`index.html` loads, in order, `js/data.js`, `js/format.js`, `js/geometry.js`, `js/drawing.js`, `js/app.js` with plain `<script>`. Each file attaches to `window.CIP` and, when `module` exists, also does `module.exports = ...` so Node tests `require` the same files. Data lives in `js/data.js` as `CIP.cartridges = [...]`, because `fetch('data.json')` fails on `file://`.
*Alternatives:* ES modules (blocked on `file://`); inline JSON in HTML (not testable in Node); a bundler (violates "no build step").
`js/data.js` is generated once from `test/fixtures/cartridges.jsonl` (the brief's lines verbatim) by `scripts/build-data.mjs`; a test asserts deep equality. The script is a dev tool, not a build step: the generated file is committed.

### D2. Hash routing
Addresses are `index.html#/cartridge/<key>` (list: `#/` or empty), using the record's `key`. A hash survives reload and bookmarking on `file://` and under any static server with no server rewrite rules. `hashchange` re-renders. Unknown key → "Cartridge not found" plus the "All cartridges" link. Focus moves to the view heading after navigation; the title follows the view.
*Alternative:* History API paths (need server fallback; break on `file://`).

### D3. Rendering without innerHTML for data
Views are built with a small `h(tag, attrs, ...children)` helper on `createElement`/`createElementNS` and `textContent`, so names such as `40 S.& W.` need no escaping and cannot inject markup. List filtering re-renders the list region only, so the Search field keeps focus while typing. The counter is an `aria-live="polite"` element.

### D4. Formatting (`format.js`)
- Number → `String(n)`: `4150.0` → `4150`, `51.18` → `51.18`. No locale, no thousands separator.
- Angle: number → `${n}°`; `{degrees,minutes,seconds}` → `${d}°${m}'${s}"` always with all three parts (`1°30'0"`), as published.
- Tolerance: `X` and `XTol` render in one cell, `49.49 -0.2`; `*Tol` keys never become rows. A row's tolerance is found by key `<field>Tol` in the same section object.
- Sections: record groups in order — cartridge: caseHead "Case head", collar "Collar", junctionCone "Junction cone", lengths "Lengths", misc "Misc", powderChamber "Powder chamber", pressures "Pressures", projectile "Projectile"; chamber: barrel, breech, collar, grooves, junctionCone, lengths, powderChamber, rifling. Empty groups are skipped. Row order = record key order.
- Units by field: angle fields (alpha, alpha1, beta, delta, i) carry `°` in the value and an empty unit cell; N empty; Pmax/PK/PE bar; EE J; M g; Q mm²; every other numeric field mm (including `u`, `S`, `Fe`, `deltaL`, `G2`, `L4`, `L5`, `h`, `s`, `b`).
- Symbols: the brief's override map, else the field name.
- Water capacity: `grH2O` as published with unit "gr H2O", the source link (`url`, text = `source`, `rel="noopener"`), and `note` when present.

### D5. Geometry (`geometry.js`): pure functions on a record
`buildDrawing(record)` returns `{rimType, outer, inner, hatch, bullet, dims, notes, bbox}` with every curve **flattened to polylines** (arcs sampled at ≤ 5° steps). Polylines make hatch clipping, bounding boxes and the label-collision test trivial and exact enough at 1 unit = 1 mm. Profiles are computed in `(z, r)` with `r ≥ 0` and mapped to SVG as `x = z`, `y = -r` (outside view, upper) and `y = +r` (section, lower).

The brief writes points as `(r, z)`; the code stores them as `[z, r]`.

Interpretations where the brief leaves room:
1. **Rim edge, rimfire.** `rr = min(R/2, (R1-P1)/2)`; semicircle centred at `(R/2, R1/2 - rr)` bulging outward to `r = R1/2`; the head face runs `(0,0) → (0, R1/2-rr)` then (if `rr < R/2`) straight to the arc, and after the arc the profile returns to `P1/2` at `z = R`. For both rimfire records with a rim `rr = R/2` exactly, so the arc spans the full rim thickness.
2. **Groove.** Point list exactly as rule 3. Body start is `(P1/2, E)` with a groove (belted: after the belt step), `(P1/2, R)` without one, `(P1/2, R)` after the half-round for rimfire. Belt ramp end is `z = R + eMin + (R3/2 - E1/2)/tan δ`; belted needs R3, δ, E1, E, eMin, R.
3. **Corner rounding** (r1 min body-side, r2 neck-side) is a tangent arc between the adjacent straight lines. The tangent length is capped at 45% of the shorter adjacent segment so arcs never cross; the drawn radius is then the capped value. No radius is invented: a missing radius means a sharp corner plus a note.
4. **Straight cases** (no alpha, L1 or L2): the body runs `(P1/2, z0) → (H2/2, L3)`.
5. **Walls.** `tn = (H2-G1)/2`, `tb = min(max(1.3·tn, 0.6), 0.35·P1/2)`. Bottleneck: wall `tb` for `z ≤ L1`, linear to `tn` over `[L1, L2]`, `tn` for `z ≥ L2`. Straight case: wall `tn` for `z ≥ zb` (the seat of the bullet, so the shank fits), blended linearly back to `tb` over the following `tb - tn` of axial length. Heeled case: `tn` would be 0, so the wall stays `tb` throughout and the bullet heel has diameter `H2 - 2·tb`.
6. **Hatch region (lower half).** Polygon: start at `(0, pocketR)` (or `(0,0)` rimfire), follow the outer profile to the mouth, in to the inner radius, back along the inner profile to `z = w`, down to `(w, 0)`, along the axis to `(pocketDepth, 0)`, up to `(pocketDepth, pocketR)`, close. Hatch is an SVG `<pattern>` (45°, user-space units, 0.5 mm pitch) so it prints as vector lines.
7. **Bullet.** Exactly rule 7; ogive points `c + ρ(sin θ, cos θ)` with `c = (zn, G1/2 - ρ)`, θ from 0 to the angle where `r = m/2` (test: end z = L6 within 1e-6); rounded nose is the quarter ellipse with semi-axes `n` (axial) and `G1/2 - m/2` (radial) centred at `(zn, m/2)`; flat/semi_wadcutter are straight cones; every tip ends in a vertical meplat to the axis. Outside view draws only `z ≥ L3`; the section draws the whole bullet from the flat base at `zb`. Exposed diameter is `G1`, or `H2` when heeled.
8. **Solid head `w`** exactly per rule 8, including the groove term `E + tb` and belt term `ramp end + tb`.
9. **Missing values.** Each optional feature declares the fields it needs; if any is absent the feature is skipped and `notes` gets `"<feature> not drawn: <fields> not published"` (features: chamfer, extractor groove, belt, shoulder radius r1 min / r2, bullet). Rimmed and rimless records without E/E1 report the groove note; rimfire records do not (not applicable). Dimension lines for unpublished optional fields are silently omitted, as the spec says. Notes render under the drawing and in print.
10. **Rim type** is returned for the SVG `<desc>` ("rimless bottleneck case") and tests; no geometry depends on it beyond the rimfire/belted branches the rules define.

### D6. Dimensions and labels (`drawing.js`)
Dimension geometry is laid out in lanes so that line crossings cannot occur by construction:
- **Lengths** (R, L1, L2, L3, L6 — only published ones, in ascending value) are horizontal dimension lines in lanes above the outside view, 5 mm apart starting 6 mm above the highest outline point. Extension lines are vertical from the feature to its lane. Labels sit centred above their line.
- **Diameters** are vertical dimension lines spanning `±d/2` with horizontal extension lines from the upper and lower outline points. **Right lanes** (beyond the bullet tip, ascending by diameter so that outer extension lines never cross inner lines): G1, H2, H1, P2, P1. **Left lanes** (beyond the head face): E1 then R1, same ordering rule. Vertical labels are rotated −90° beside their line (a lane pitch of 5 mm is more than the 2.4 mm text height).
- **α** is drawn with the shoulder line prolonged (thin, dashed) to the cone apex on the axis in both halves, an arc between the two lines with arrowheads, and its label placed in clear space above the shoulder joined by a leader line.
- **Arrowheads** are closed filled triangles 2.2 mm long.
- **Label placement.** A label is a rectangle (estimated width = characters × 0.62 × font size, a tabular-figure approximation; height = font size). Each label has an ordered list of candidate positions (primary lane position, then shifted along the lane, then moved outward lane by lane). The first candidate whose rectangle is disjoint from placed rectangles and from the outline polylines is taken. A Node test runs this for all 25 records and asserts disjointness; a browser test checks real `getBBox()` rectangles.
- **Title block**: a framed box in the bottom-right corner below the lanes: name, `C.I.P. Tab. <tab>`, `Rev. <revised>`, `Dimensions in mm`, `Scale <n> : 1 on A4`. Since the SVG scales to its container, the scale printed is the one at which the drawing prints on A4: `190 mm / viewBox width`, rounded to one decimal. The viewBox is `bbox` of everything plus 4 mm margin; the SVG has `width: 100%; height: auto`.
- Font size 2.4 units (≥ 7 pt once printed at ≥ 1.0 scale; the A4 scale is typically 1.5–1.8). Strokes are in mm units too (outline 0.35, dimension 0.15, centre line 0.2 dash-dot `4 1 0.6 1`), so the whole drawing scales uniformly.
- SVG carries `role="img"`, `aria-labelledby` on `<title>` "<name> drawing" and a `<desc>`. Colours use CSS custom properties (`currentColor` family), so dark mode and print need no separate drawing.

### D7. Layout, themes, print
One `css/style.css`. System font stacks only (`system-ui`, `ui-monospace`); `font-variant-numeric: tabular-nums`; numeric cells right-aligned; `color-scheme: light dark` with `prefers-color-scheme` custom properties. Phone: single column, tables full width, drawing `max-width: 100%`. Print (`@media print`): `@page { size: A4 portrait; margin: 10mm }`; the print block forces light colour variables, hides the nav/link/button/search controls, shows a header with the name and a footer `Source: C.I.P. TDCC, revised <date>`; the drawing is `width: 100%` (190 mm); the value tables flow in 3 CSS columns at 7 pt with `break-inside: avoid` per table section so everything fits one page. "Print" is `window.print()`.

### D8. Tests and tooling
`package.json` with dev dependencies only: Node's built-in `node:test` for unit tests and `playwright` (Chromium) for end-to-end tests run against `file://` and a tiny `node:http` static server defined in the test helper. Order: unit tests for `format`, geometry and label placement first (red), then code; e2e per spec scenario; `page.pdf({format:'A4'})` and a page-count check for all 25; screenshots in light, dark, and 360 px for a visual review of the drawings. Browser installation needs network access at dev time only; if Chromium cannot be installed or launched in the container, e2e falls back to a documented manual checklist and the report says so.

## Risks / Trade-offs

- [Text width is estimated, not measured] → the Node placement test uses a conservative factor, and the browser test re-checks with `getBBox()`.
- [Text legibility on a 360 px phone: a ~115 mm wide drawing renders at ≈ 3 px/mm, so 2.4-unit labels are ≈ 7 px] → the spec requires fit-to-width, so the drawing stays whole; the user can zoom/pinch. Noted in the final report rather than solved with horizontal scrolling.
- [Lane layout widens the drawing (~45 mm of lanes), shrinking the cartridge] → accepted for crossing-free dimensioning; lanes are only created for published dimensions.
- [Rule 5 radii and α/S data may not exactly agree with each other (e.g. S vs. computed apex)] → the drawing follows the rules ("through the published points") and never uses `S` for geometry.
- [Curves as polylines] → 5° sampling gives sub-0.02 mm sagitta on the radii used; invisible at print scale.
- [`G2: 68.61` in `7 mm Rem. Mag.` looks like a data error] → shown as published, not altered or drawn.
- [Hash addresses are not "pretty"] → deliberate for `file://` support.

## Open Questions

None that would change specs, approach or tasks.
