# Proposal

## Why

Reloaders, gunsmiths and engineers need a fast, precise, offline reference for C.I.P. cartridge and chamber dimensions. The OpenBallistics cartridge database is the model, but there is no small, self-contained copy that opens from disk, shows every published value with its tolerance, and draws the cartridge true to scale. This change builds that reference for a fixed set of 25 records.

## What Changes

- New static web app (`index.html` + CSS + JS, no framework, no build, no network) that works from `file://` and from any static file server.
- Start page "Cartridges": list of all 25 cartridges (name link, family, case length L3), live "Search" over name and alternative names, "Family" select, and an "<n> cartridges" counter.
- Detail view per cartridge with its own bookmarkable address: header facts, water capacity with source link, all cartridge and chamber values grouped by section in Symbol / Value / Unit tables (tolerances shown beside the value, angles as degrees or d°m's"), "Print" button and "All cartridges" link.
- Computed 2D drawing (inline SVG, 1 unit = 1 mm): outside view above, hatched section below, centre line, dimension lines with extension lines and arrowheads, non-overlapping labels, title block, graceful handling of missing values.
- Print stylesheet: one A4 portrait page, black on white, header, full-width drawing, tables, source footer; no navigation or controls.
- Light/dark on screen following the system setting; phone-usable layout.
- The 25 records embedded unchanged as the only data.
- Dev-only tooling: Node 22 test runner (and a headless browser for end-to-end checks) as npm dev dependencies.

## Capabilities

### New Capabilities
- `cartridge-list`: start page listing, text search, family filter and result count.
- `cartridge-detail`: detail view content, value formatting rules (units, tolerances, angles, symbols), per-cartridge addressing and navigation.
- `cartridge-drawing`: the computed true-to-scale SVG drawing, its geometry, dimensions, labels, title block and missing-value reporting.
- `cartridge-print`: the A4 print layout of the detail view.
- `app-delivery`: offline static delivery (file:// and static server, no network or dependencies), colour schemes, responsiveness.

### Modified Capabilities

None. `openspec/specs/` is empty.

## Impact

- New files in the project root: `index.html`, `css/`, `js/` (data, formatting, geometry, drawing, app), `test/`, `package.json` (dev dependencies only).
- No existing code, APIs or runtime dependencies are affected. Source data is used as given and never fetched or altered.
- Out of scope: editing data, unit conversion, ballistics calculations, comparison views, routing beyond list and detail, any server code.
