# Spec Delta

## Purpose

The app is a self-contained static reference that works anywhere a browser opens a file, with no setup, network or runtime dependencies, in a calm technical look.

## ADDED Requirements

### Requirement: Static delivery
The app SHALL be `index.html` in the project root with its CSS and JavaScript files, using plain HTML, CSS and JavaScript only: no framework, no build step, no server code, no runtime dependency. It SHALL work fully when `index.html` is opened from disk in Chromium and when the folder is served by any static file server.

#### Scenario: Opened from disk
- **WHEN** `index.html` is opened through a `file://` address in Chromium
- **THEN** the list, search, filter, every detail view, the drawing and "Print" work, and the console shows no errors

#### Scenario: Served statically
- **WHEN** the folder is served by a static file server
- **THEN** the same behavior holds, and a detail address opened directly shows that detail view

### Requirement: No network requests
The app SHALL make no network request: no CDN, web font, analytics or data fetch. All 25 records SHALL be embedded unchanged.

#### Scenario: Offline load
- **WHEN** the app is loaded and every detail view opened
- **THEN** every request is for one of the app's own files and none targets another origin

### Requirement: Data fidelity
The app SHALL use the 25 supplied records as the only data, without adding, changing or fetching data.

#### Scenario: Records unchanged
- **WHEN** the embedded data is compared with the supplied records
- **THEN** all 25 records are present and deep-equal

### Requirement: Colour schemes
On screen the app SHALL follow the system light or dark setting, with readable contrast in both. Print SHALL always be light.

#### Scenario: Dark system setting
- **WHEN** the system prefers dark
- **THEN** page and drawing use a dark palette with text contrast of at least 4.5:1

### Requirement: Technical typography
Numbers SHALL use tabular figures and be right-aligned in tables; the interface SHALL be dense and calm, in English.

#### Scenario: Tabular numbers
- **WHEN** a value table is shown
- **THEN** the Value cells use tabular numerals and align on the decimal point or right edge

### Requirement: Phone usability
The start page and detail view SHALL be usable at a 360 px wide viewport without horizontal page scrolling.

#### Scenario: Phone viewport
- **WHEN** the viewport is 360 px wide
- **THEN** list, controls, tables and drawing fit the width and all controls are reachable
