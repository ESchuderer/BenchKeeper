# Spec Delta

## Purpose

The detail view presents every published fact and dimension of one cartridge and its chamber, precisely as published, at an address that can be bookmarked.

## ADDED Requirements

### Requirement: Detail header facts
The detail view SHALL have the cartridge's name as its heading, followed by alternative names, family, category, primer type, C.I.P. table (`tab`), country, published date, revised date, pressure method, and the published water capacity with a link to its source. Facts the record does not contain SHALL be shown as "not published".

#### Scenario: Facts of 308 Win.
- **WHEN** the detail view of `308 Win.` opens
- **THEN** the heading is `308 Win.`, alternative names `308 Winchester` and `7,62 x 51` are shown, and so are family `rimless`, category `rifle`, primer type `lr`, table `I`, country `US`, published `1984-06-14`, revised `2008-09-23`, method `Transducer`

#### Scenario: Water capacity with source link
- **WHEN** the detail view of `308 Win.` opens
- **THEN** the capacity `56` grains H2O is shown with a link to `http://kwk.us/cases.html` whose text names the source `kwk`

#### Scenario: No published capacity
- **WHEN** the detail view of `7 x 64` opens
- **THEN** the water capacity reads "not published" and no source link is shown

### Requirement: Value tables by section
The detail view SHALL show all cartridge values and all chamber values in tables grouped by their section of the record, each table with the columns "Symbol", "Value" and "Unit". A section without values SHALL NOT be shown.

#### Scenario: Sections of a bottleneck rifle case
- **WHEN** the detail view of `223 Rem.` opens
- **THEN** cartridge sections case head, collar, junction cone, lengths, misc, powder chamber, pressures and projectile are shown, and chamber sections barrel, breech, collar, grooves, junction cone, lengths, powder chamber and rifling

#### Scenario: Empty section omitted
- **WHEN** the detail view of `9 mm Luger` opens (junction cone `{}`)
- **THEN** no junction cone table is shown for either cartridge or chamber

#### Scenario: Every value appears once
- **WHEN** any detail view opens
- **THEN** each scalar value of the record's `cartridge` and `chamber` objects appears in exactly one table row

### Requirement: Value formatting
Values SHALL be shown as published: decimal point, no thousands separator, no added or dropped digits (`51.18`, `4150`, `25`). Units SHALL be mm for lengths and diameters, bar for Pmax, PK and PE, J for EE, g for M, mm² for Q; N SHALL have no unit. Names SHALL be shown as published.

#### Scenario: Units
- **WHEN** the detail view of `6,5 Creedmoor` opens
- **THEN** the Pmax row reads `4350` with unit `bar`, EE reads `3400` with `J`, M reads `25` with `g`, Q reads `34.66` with `mm²`, and N reads `6` with an empty unit

### Requirement: Tolerances beside the value
A field `<X>Tol` SHALL be shown next to the value of X in the same cell, and SHALL NOT have a row of its own.

#### Scenario: Tolerance shown
- **WHEN** the detail view of `270 Win.` opens
- **THEN** the L1 row's value reads `49.49 -0.2` and no row has the symbol `L1Tol`

### Requirement: Angle formatting
An angle given as a number of degrees SHALL be shown as `40°`; an angle given as degrees, minutes and seconds SHALL be shown as `39°59'49"`. Angles are alpha, alpha1, beta, delta and i.

#### Scenario: Both angle forms
- **WHEN** the detail view of `338 Lapua Mag.` opens
- **THEN** the cartridge α row reads `39°59'49"` and the chamber α1 row reads `90°`

#### Scenario: Plain number for i
- **WHEN** the detail view of `7 mm Rem. Mag.` opens (chamber `i` is the number `3.0`)
- **THEN** the i row reads `3°`

### Requirement: Symbols
The Symbol column SHALL show the field name, except eMin "e min", r1Min "r1 min", r1Max "r1 max", alpha "α", alpha1 "α1", beta "β", delta "δ", deltaL "delta L" and L3PlusG "L3 + G".

#### Scenario: Renamed symbols
- **WHEN** the detail view of `243 Win.` opens
- **THEN** rows labelled `e min`, `r1 min`, `α`, `β`, `δ`, `delta L` and `L3 + G` exist and none is labelled `eMin`, `alpha` or `L3PlusG`

### Requirement: Navigation and addressing
Each detail view SHALL have its own address that opens the same view after a reload and when bookmarked. The view SHALL have a "Print" button and a link "All cartridges" that returns to the start page.

#### Scenario: Reload keeps the view
- **WHEN** the user opens `45 Auto` and reloads the page
- **THEN** the detail view of `45 Auto` is shown

#### Scenario: Back to the list
- **WHEN** the user follows "All cartridges"
- **THEN** the start page with heading "Cartridges" is shown

#### Scenario: Unknown address
- **WHEN** the address names a cartridge that does not exist
- **THEN** a message "Cartridge not found" and the link "All cartridges" are shown
