# Spec Delta

## Purpose

The drawing gives a true-to-scale 2D technical view of a cartridge, computed only from its published values, with dimensions that a reloader or gunsmith can read off.

## ADDED Requirements

### Requirement: Scale and structure
The detail view SHALL contain an inline SVG with the accessible name "<name> drawing", in which 1 SVG user unit equals 1 mm, the axis is horizontal and the head is on the left. The upper half SHALL be the outside view and the lower half a section with cut walls hatched. A dash-dot centre line SHALL mark the axis.

#### Scenario: True scale
- **WHEN** the drawing of `308 Win.` is built
- **THEN** the case outline spans exactly L3 = 51.18 units from the head face to the mouth and the bullet tip lies at L6 = 71.12 units

#### Scenario: Accessible name
- **WHEN** the drawing of `6,5 Creedmoor` is shown
- **THEN** the SVG has role `img` and accessible name `6,5 Creedmoor drawing`

#### Scenario: Mirrored halves
- **WHEN** any drawing is built
- **THEN** the lower half's outline is the mirror image of the upper half's at the axis

Points in this capability are written (r, z): radius from the axis first, distance from the head face second.

### Requirement: Rim type
The rim type SHALL be derived from the record: family `belted` is belted, `rimfire` is rimfire; otherwise R1/P1 >= 1.05 is rimmed, R1/P1 < 0.98 is rebated, anything else is rimless.

#### Scenario: Classification
- **WHEN** rim types are derived for `9,3 x 74 R`, `6,5 x 55 SE`, `300 Win. Mag.` and `22 Long Rifle`
- **THEN** they are rimmed (R1/P1 = 1.12), rimless (1.00), belted and rimfire

### Requirement: Head profile
The outline SHALL follow the head rules: a chamfer from `(R1/2 - min(f·tan β, R1/4), 0)` to `(R1/2, f)` where beta and f are published and beta < 90°; a half-round rim edge on rimfire cases; otherwise a square corner. Where E and E1 are published the extractor groove SHALL be drawn; on belted cases the belt SHALL follow it; without a groove the profile steps in to P1/2 after the rim.

#### Scenario: Chamfer present
- **WHEN** the drawing of `223 Rem.` is built (beta 35°, f 0.45)
- **THEN** the head outline passes through `(R1/2 - min(0.45·tan 35°, R1/4), 0)` and `(R1/2, 0.45)`

#### Scenario: Chamfer skipped
- **WHEN** the drawing of `22 Win. Mag. R.F.` is built (no beta, no f)
- **THEN** no chamfer is drawn and the rim edge is half-round

#### Scenario: Groove
- **WHEN** the drawing of `308 Win.` is built
- **THEN** the outline reaches `(E1/2, R)`, `(E1/2, R + e min)` and `(P1/2, E)`

#### Scenario: Belt
- **WHEN** the drawing of `300 Win. Mag.` is built
- **THEN** from the groove floor the outline ramps out at δ to R3/2, follows the belt to z = E and steps in to P1/2

#### Scenario: Rimmed case without groove
- **WHEN** the drawing of `9,3 x 74 R` is built
- **THEN** the outline steps in from `(R1/2, R)` to `(P1/2, R)`

### Requirement: Body, shoulder and neck
A case with alpha, L1 and L2 SHALL be drawn as a bottleneck: body from P1/2 to `(P2/2, L1)`, shoulder to `(H1/2, L2)`, neck to `(H2/2, L3)`, with the body-side corner rounded by r1 min and the neck-side corner by r2 where published. A case without alpha, L1 or L2 SHALL be straight, its body running to `(H2/2, L3)`.

#### Scenario: Bottleneck through published points
- **WHEN** the drawing of `243 Win.` is built
- **THEN** the unrounded shoulder polyline has its vertices at `(P2/2, L1)`, `(H1/2, L2)` and `(H2/2, L3)` with z = 39.62, 45.83 and 51.94, the drawn outline ends at `(H2/2, L3)`, and each rounded corner lies at the distance r·(1/cos(θ/2) − 1) from its vertex (θ = turning angle)

#### Scenario: Straight case
- **WHEN** the drawing of `45 Auto` is built
- **THEN** the body runs straight from P1/2 to `(H2/2, L3)` with no shoulder

#### Scenario: Corner radius missing
- **WHEN** the drawing of `17 HMR` is built (no r1 min, no r2)
- **THEN** the shoulder corners are sharp and the drawing states that r1 min and r2 are missing

### Requirement: Bullet
A bullet SHALL be drawn from the mouth to the tip at z = L6 with shank diameter G1 and the nose shape from `annotations.defaultBulletShape` (pointy, rounded, flat, semi_wadcutter), using the seating depth, cylinder length, meplat diameter and nose curve of the geometry rules. The outside view SHALL hide the seated part; the section SHALL show it inside the case.

#### Scenario: Pointy bullet
- **WHEN** the drawing of `308 Win.` is built
- **THEN** the exposed bullet has diameter G1 7.85, a tangent-ogive nose ending at z = 71.12 with a flat meplat of max(0.08·G1, 1.27) = 1.27

#### Scenario: Pistol rounded bullet
- **WHEN** the drawing of `9 mm Luger` is built
- **THEN** the seating depth is 0.4·G1 and the nose is a quarter ellipse with meplat 0.15·G1

### Requirement: Heeled bullet
On a heeled case (H2 - G1 <= 0.015) the exposed bullet SHALL have the case's outside diameter and the seated heel the case's inside diameter H2 - 2·tb.

#### Scenario: Heeled case
- **WHEN** the drawing of `22 Long Rifle` is built
- **THEN** the exposed bullet has diameter H2 = 5.72 and the seated heel has diameter H2 - 2·tb

### Requirement: Section walls and head
The section SHALL show the inner line following the outer body, shoulder and neck at the wall thicknesses tb (body) and tn (neck), blended linearly across the shoulder, with a solid head from the head face to z = w and, on centrefire cases, a primer pocket of the diameter and depth set by the primer type. Rimfire cases SHALL have no pocket.

#### Scenario: Primer pocket
- **WHEN** the drawings of `308 Win.` (lr) and `9 mm Luger` (sp) are built
- **THEN** the pockets are 5.33 × 3.3 and 4.45 × 3.04

#### Scenario: Rimfire
- **WHEN** the drawing of `17 HMR` is built
- **THEN** its section has no primer pocket

### Requirement: Dimension lines
The drawing SHALL carry dimension lines with arrowheads and extension lines for L3, L6, R1, R and P1 and, where published, P2, H1, H2, G1, L1, L2, E1 and the shoulder angle α. Each SHALL be labelled with its symbol and value, such as `L3 51.18`, with α in the angle format of the detail view.

#### Scenario: All dimensions present
- **WHEN** the drawing of `308 Win.` is built
- **THEN** labels `L3 51.18`, `L6 71.12`, `R1 12.01`, `R 1.37`, `P1 11.96`, `P2 11.53`, `H1 8.72`, `H2 8.72`, `G1 7.85`, `L1 39.62`, `L2 43.48`, `E1 10.39` and `α 40°` exist

#### Scenario: Unpublished dimensions omitted
- **WHEN** the drawing of `45 Auto` is built
- **THEN** there are no L1, L2, H1, P2 or α dimensions

### Requirement: Labels do not collide
No dimension label SHALL overlap another label or the outline of the cartridge, for any of the 25 cartridges.

#### Scenario: Crowded shoulder
- **WHEN** the drawing of `17 HMR` (L1 22.2, L2 23.54) or `8 x 57 IS` is built
- **THEN** all label boxes are pairwise disjoint and disjoint from the outline

### Requirement: Title block
The drawing SHALL include a title block with the cartridge name, C.I.P. table, revision date, the text "Dimensions in mm" and the scale.

#### Scenario: Title block content
- **WHEN** the drawing of `308 Win.` is built
- **THEN** the title block contains `308 Win.`, `Tab. I`, `2008-09-23`, `Dimensions in mm` and a scale

### Requirement: Missing values
When a value that a geometry rule needs is missing, the drawing SHALL omit that feature, SHALL state beside the drawing which value is missing, and SHALL NOT use an invented number.

#### Scenario: Missing groove value
- **WHEN** the drawing of a case lacking E1 is built
- **THEN** no groove is drawn and the note names E1 as missing

#### Scenario: Complete record
- **WHEN** the drawing of `308 Win.` is built
- **THEN** no missing-value note is shown

### Requirement: Responsive drawing
The SVG SHALL scale to the width of its container, down to a phone screen, keeping its aspect ratio.

#### Scenario: Phone width
- **WHEN** the viewport is 360 px wide
- **THEN** the drawing is at most 360 px wide, is not clipped and has no horizontal page scrolling
