# Spec Delta

## Purpose

The start page lets a reader find a cartridge among the 25 records quickly, by name, alternative name or family, and open its detail view.

## ADDED Requirements

### Requirement: Cartridge list
The start page SHALL show a heading "Cartridges" and one entry per cartridge with its name, family and case length L3. The name SHALL be a link whose text is exactly the record's `name` and which opens that cartridge's detail view.

#### Scenario: All cartridges listed on first load
- **WHEN** the start page opens without a filter
- **THEN** 25 entries are listed, each with name link, family and L3 (for example `308 Win.`, `rimless`, `51.18 mm`)

#### Scenario: Names are shown as published
- **WHEN** the list shows the cartridge with key `6_5_creedmoor`
- **THEN** its link text is exactly `6,5 Creedmoor`

#### Scenario: Link opens the detail view
- **WHEN** the user follows the link `270 Win.`
- **THEN** the detail view for that cartridge opens

### Requirement: Search by name
A field labelled "Search" SHALL filter the list as the user types, matching the record's name and its alternative names, ignoring letter case and surrounding spaces.

#### Scenario: Alternative name matches
- **WHEN** the user types `7,62 x 51` in "Search"
- **THEN** the list contains `308 Win.`

#### Scenario: No match
- **WHEN** the user types text that matches no name
- **THEN** no entries are listed and the counter reads `0 cartridges`

### Requirement: Family filter
A select labelled "Family" SHALL offer All, rimless, rimmed, belted, pistol and rimfire, and SHALL restrict the list to the chosen family. Search and Family SHALL combine.

#### Scenario: Filter by family
- **WHEN** the user selects `belted`
- **THEN** only `300 Win. Mag.` and `7 mm Rem. Mag.` are listed

#### Scenario: Combined filters
- **WHEN** the user selects `rimfire` and types `22`
- **THEN** `22 Long Rifle` and `22 Win. Mag. R.F.` are listed and `17 HMR` is not

### Requirement: Result count
The page SHALL show the text "<n> cartridges", where n is the number of listed entries.

#### Scenario: Count follows the filters
- **WHEN** the page loads, and then the user selects `pistol`
- **THEN** the counter reads `25 cartridges`, then `6 cartridges`
