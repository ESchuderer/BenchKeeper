# Spec Delta

## Purpose

A cartridge's detail view prints as a single clean A4 sheet that can be filed or pinned up as a data sheet.

## ADDED Requirements

### Requirement: Print button
The "Print" button SHALL open the browser's print dialog.

#### Scenario: Print pressed
- **WHEN** the user presses "Print" in a detail view
- **THEN** the browser's print function is called once

### Requirement: Printed page
A printed detail view SHALL be one A4 portrait page, black on white regardless of the screen colour scheme, with a page header carrying the cartridge name, the drawing at full width with every label legible, then the value tables.

#### Scenario: One page for every cartridge
- **WHEN** the detail view of any of the 25 cartridges is printed to PDF on A4 portrait
- **THEN** the PDF has exactly one page

#### Scenario: Always light
- **WHEN** the system colour scheme is dark and a detail view is printed
- **THEN** the page is black on white

#### Scenario: Legible labels
- **WHEN** a detail view is printed
- **THEN** the drawing is as wide as the printable area and the smallest label text is at least 7 pt

### Requirement: Print hides interface
A printed page SHALL NOT show navigation, the link "All cartridges", search, the Family select or buttons.

#### Scenario: Controls hidden
- **WHEN** a detail view is printed
- **THEN** the "Print" button and the link "All cartridges" are not part of the page

### Requirement: Print footer
A printed page SHALL end with a footer giving the source: "C.I.P. TDCC" and the cartridge's revised date.

#### Scenario: Footer text
- **WHEN** `308 Win.` is printed
- **THEN** the footer reads `Source: C.I.P. TDCC, revised 2008-09-23`
