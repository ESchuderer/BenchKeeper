# Tasks

## 1. Project setup and data

- [x] 1.1 Create `package.json` (dev dependencies only: `playwright`; scripts `test`, `test:e2e`), `.gitignore` (`node_modules`, test output); verify `npm install` succeeds and `node --test` runs with zero tests.
- [x] 1.2 Save the brief's 25 JSON lines verbatim as `test/fixtures/cartridges.jsonl`; verify with a one-line check that it has 25 lines, all parse, and 25 distinct `key`s.
- [x] 1.3 Write `scripts/build-data.mjs` generating `js/data.js` (`CIP.cartridges`, with the Node `module.exports` guard) from the fixture; write `test/data.test.js` (deep equality to the fixture, 25 records) and verify it passes.
- [x] 1.4 Install Chromium for Playwright and verify a headless launch opens a `file://` page; if it cannot run in this container, record that in the report and plan the manual checklist instead.

## 2. Formatting (`js/format.js`)

- [x] 2.1 Write `test/format.test.js` first from the cartridge-detail scenarios (number as published, angles in both forms and plain `i`, tolerance merge, symbol map, units incl. N empty and mm², renamed symbols, section grouping and empty-group skipping, all-values-once over all 25 records, capacity text); verify it fails.
- [x] 2.2 Implement `js/format.js` per design D4; verify `node --test test/format.test.js` passes.

## 3. Geometry core (`js/geometry.js`)

- [x] 3.1 Write `test/geometry.test.js` first from the cartridge-drawing scenarios: rim-type table, chamfer points, half-round, groove and belt points, rimmed no-groove step, bottleneck points at L1/L2/L3 (passing through published points), straight case, corner radii and missing-radius note, bullet seat/cylinder/meplat/tip numbers for pointy, rounded (rifle/pistol), flat, semi_wadcutter and heeled, walls, pocket sizes per primer type, solid-head `w`, mirror symmetry, a synthetic record lacking E1 (note names E1, no groove), and "all 25 build with no NaN and a complete record gives no notes"; verify it fails.
- [x] 3.2 Implement outer profile, groove/belt and shoulder with fillets in `js/geometry.js`; verify the corresponding tests pass.
- [x] 3.3 Implement bullet, walls, hatch polygon, pocket, `w` and missing-value notes; verify the full `test/geometry.test.js` passes for all 25 records.

## 4. Dimensions, labels and SVG (`js/drawing.js`)

- [x] 4.1 Write `test/drawing.test.js` first: label text per cartridge (e.g. `L3 51.18`, `α 40°`, none of L1/L2/H1/P2/α for `45 Auto`), title-block text, `role="img"` and name `<name> drawing`, viewBox in mm, pairwise-disjoint label boxes and label/outline disjointness for all 25 records; verify it fails.
- [x] 4.2 Implement lanes, dimension lines with arrowheads and extension lines, α construction and the label placer; verify label tests pass for all 25 records.
- [x] 4.3 Implement SVG output (outline, mirrored halves, hatch pattern, centre line, bullet, title block with A4 scale, notes); verify `test/drawing.test.js` passes and write three sample SVGs (`308 Win.`, `300 Win. Mag.`, `22 Long Rifle`) to a temp folder to inspect their screenshots.

## 5. App shell: list, detail, routing

- [x] 5.1 Write the e2e tests first (`test/e2e/*.spec.js`, run on `file://` and via the static server) for cartridge-list and cartridge-detail scenarios (heading, 25 links with exact names, search `7,62 x 51`, family filters and counts, combined filter, detail facts and links, tables and columns, reload on a detail address, back link, unknown address); verify they fail.
- [x] 5.2 Implement `index.html`, `js/app.js` (hash router, list, filters, counter, detail view, tables, Print button, "All cartridges") using `h()` DOM building per D2/D3; verify the e2e list and detail tests pass in both modes.

## 6. Look and feel, print, delivery

- [x] 6.1 Write the e2e tests first for app-delivery and cartridge-print (no console errors, no cross-origin or extra requests on `file://`, light/dark computed colours and contrast ≥ 4.5:1, 360 px with no horizontal scroll, tabular numerals, `window.print` called once, PDF for all 25 on A4 portrait has exactly one page, print hides controls, footer text, label font ≥ 7 pt in print); verify they fail.
- [x] 6.2 Implement `css/style.css` (themes, typography, phone layout, `@media print` per D7); verify the e2e tests pass.
- [x] 6.3 Review screenshots (light, dark, 360 px, print preview) of at least `308 Win.`, `300 Win. Mag.`, `9,3 x 74 R`, `9 mm Luger`, `22 Long Rifle`, `17 HMR` and fix visible defects; verify by re-running all tests.

## 7. Integration and docs

- [x] 7.1 Add a short `README.md` (how to open from disk, how to serve, how to run tests, how data is generated, data source and licence note) and verify every documented command runs as written.
- [x] 7.2 Run the full suite (`npm test`, `npm run test:e2e`) and `openspec validate cartridge-reference-app --strict`; verify all pass and that `index.html` makes no non-local requests.
- [x] 7.3 Review the change (`/code-review`, `/simplify` over the diff) and fix findings; verify tests still pass.

## Workflow follow-up

- Archive the change after review (`/openspec-archive-change`).
