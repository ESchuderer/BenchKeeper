const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

const fixture = fs.readFileSync(path.join(__dirname, 'fixtures/cartridges.jsonl'), 'utf8')
  .trim().split('\n').map((l) => JSON.parse(l));

test('embedded data is the 25 supplied records, unchanged', () => {
  const data = require('../js/data.js');
  assert.equal(data.length, 25);
  assert.deepEqual(data, fixture);
  assert.equal(new Set(data.map((r) => r.key)).size, 25);
});
