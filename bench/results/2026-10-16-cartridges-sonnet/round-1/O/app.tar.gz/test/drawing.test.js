const test = require('node:test');
const assert = require('node:assert/strict');
require('../js/data.js');
require('../js/format.js');
const G = require('../js/geometry.js');
const D = require('../js/drawing.js');
const data = globalThis.CIP.cartridges;
const by = (key) => data.find((r) => r.key === key);
const labels = (key) => D.buildModel(by(key)).labels.map((l) => l.text);
const near = (a, b, eps = 1e-9) => assert.ok(Math.abs(a - b) <= eps, `${a} !~ ${b}`);

test('308 Win. carries every dimension label', () => {
  const t = labels('308_win');
  for (const x of ['L3 51.18', 'L6 71.12', 'R1 12.01', 'R 1.37', 'P1 11.96', 'P2 11.53', 'H1 8.72',
    'H2 8.72', 'G1 7.85', 'L1 39.62', 'L2 43.48', 'E1 10.39', 'α 40°']) assert.ok(t.includes(x), x);
  assert.equal(t.length, 13);
});

test('unpublished dimensions are left out', () => {
  const t = labels('45_auto');
  assert.deepEqual([...t].sort(), ['E1 10.16', 'G1 11.48', 'H2 12.01', 'L3 22.81', 'L6 32.39', 'P1 12.09', 'R 1.24', 'R1 12.19'].sort());
  const r = labels('22_long_rifle');
  assert.ok(!r.some((x) => /^(E1|L1|L2|H1|P2|α)/.test(x)));
});

test('α is shown in the angle format of the detail view', () => {
  assert.ok(labels('338_lapua_mag').includes('α 39°59\'49"'));
});

test('each dimension line measures its published value (1 unit = 1 mm)', () => {
  for (const rec of data) {
    const m = D.buildModel(rec);
    const c = rec.cartridge;
    const val = { ...c.lengths, ...c.caseHead, ...c.collar, ...c.powderChamber, ...c.projectile };
    for (const [key, d] of Object.entries(m.dims)) {
      if (key === 'α') continue;
      const len = Math.hypot(d.b[0] - d.a[0], d.b[1] - d.a[1]);
      near(len, val[key], 1e-9);
    }
  }
});

test('SVG: role img, accessible name, millimetre viewBox, escaped text', () => {
  const svg = D.toSvg(by('6_5_creedmoor'));
  assert.match(svg, /<svg [^>]*role="img"/);
  assert.match(svg, /<title id="[^"]+">6,5 Creedmoor drawing<\/title>/);
  assert.match(svg, /aria-labelledby="/);
  assert.match(svg, /viewBox="-?[\d.]+ -?[\d.]+ [\d.]+ [\d.]+"/);
  assert.match(D.toSvg(by('40_s_w')), /40 S\.&amp; W\. drawing/);
  assert.doesNotMatch(D.toSvg(by('40_s_w')), /S\.& W/);
});

test('title block: name, table, revision, units, scale', () => {
  const m = D.buildModel(by('308_win'));
  const text = m.title.lines.join('\n');
  for (const s of ['308 Win.', 'Tab. I', '2008-09-23', 'Dimensions in mm', 'Scale']) assert.ok(text.includes(s), s);
  const vbW = m.viewBox[2];
  assert.ok(text.includes(`Scale ${(190 / vbW).toFixed(1)} : 1`), text);
});

test('true scale: case spans L3, bullet tip at L6; lower half mirrors the upper', () => {
  const m = D.buildModel(by('308_win'));
  near(Math.max(...m.shapes.outerUpper.map((p) => p[0])), 51.18);
  near(Math.max(...m.shapes.bulletUpper.map((p) => p[0])), 71.12);
  near(Math.min(...m.shapes.outerUpper.map((p) => p[1])), -Math.max(...m.shapes.outerLower.map((p) => p[1])));
  near(m.shapes.outerUpper.at(-1)[1], -m.shapes.outerLower.at(-1)[1]);
});

test('missing-value notes are carried to the model, none for a complete record', () => {
  assert.deepEqual(D.buildModel(by('308_win')).notes, []);
  assert.ok(D.buildModel(by('17_hmr')).notes.length >= 2);
});

// ---- label collisions over all 25 records, computed independently of the layout code
function segHitsRect(a, b, r) {
  const inside = (p) => p[0] >= r.x && p[0] <= r.x + r.w && p[1] >= r.y && p[1] <= r.y + r.h;
  if (inside(a) || inside(b)) return true;
  const edges = [[[r.x, r.y], [r.x + r.w, r.y]], [[r.x + r.w, r.y], [r.x + r.w, r.y + r.h]],
    [[r.x + r.w, r.y + r.h], [r.x, r.y + r.h]], [[r.x, r.y + r.h], [r.x, r.y]]];
  const ccw = (p, q, s) => (s[1] - p[1]) * (q[0] - p[0]) > (q[1] - p[1]) * (s[0] - p[0]);
  return edges.some(([c, d]) => ccw(a, c, d) !== ccw(b, c, d) && ccw(a, b, c) !== ccw(a, b, d));
}
const rectsOverlap = (p, q) => p.x < q.x + q.w && q.x < p.x + p.w && p.y < q.y + q.h && q.y < p.y + p.h;

test('labels overlap neither each other nor the outline (all 25)', () => {
  for (const rec of data) {
    const m = D.buildModel(rec);
    const g = G.buildDrawing(rec);
    const up = (poly) => poly.map(([z, r]) => [z, -r]);
    const lo = (poly) => poly.map(([z, r]) => [z, r]);
    const outline = [up(g.outer), lo(g.outer), up(g.bullet.exposed), lo(g.bullet.full), lo(g.inner)];
    for (let i = 0; i < m.labels.length; i++) {
      const a = m.labels[i];
      assert.ok(a.w > 0 && a.h > 0);
      for (let j = i + 1; j < m.labels.length; j++)
        assert.ok(!rectsOverlap(a, m.labels[j]), `${rec.key}: ${a.text} overlaps ${m.labels[j].text}`);
      for (const poly of outline)
        for (let k = 1; k < poly.length; k++)
          assert.ok(!segHitsRect(poly[k - 1], poly[k], a), `${rec.key}: ${a.text} touches outline`);
    }
  }
});

test('label boxes are at least as wide as real text of that length (conservative estimate)', () => {
  const m = D.buildModel(by('308_win'));
  const l = m.labels.find((x) => x.text === 'L3 51.18');
  assert.ok(l.w >= 'L3 51.18'.length * D.FONT_SIZE * 0.6);
});

test('every record renders an SVG with notes outside the drawing', () => {
  for (const rec of data) {
    const svg = D.toSvg(rec);
    assert.match(svg, /^<svg /);
    assert.ok(!/NaN|undefined|Infinity/.test(svg), rec.key);
  }
});

test('robust against incomplete records (no crash, no NaN, notes instead)', () => {
  const noShape = structuredClone(by('308_win')); noShape.annotations.defaultBulletShape = 'ogive';
  let svg = D.toSvg(noShape);
  assert.ok(!/NaN|undefined/.test(svg));
  assert.ok(D.buildModel(noShape).notes.some((n) => /Bullet/.test(n)));
  const noP2 = structuredClone(by('308_win')); delete noP2.cartridge.powderChamber.P2;
  const m = D.buildModel(noP2);
  assert.ok(!/NaN/.test(D.toSvg(noP2)));
  assert.ok(!m.labels.some((l) => /^(L1|L2|P2|H1)/.test(l.text)));
  const straightL1 = structuredClone(by('45_auto')); straightL1.cartridge.lengths.L1 = 20;
  assert.ok(!/NaN/.test(D.toSvg(straightL1)));
  const noMeta = structuredClone(by('308_win')); delete noMeta.revised; delete noMeta.annotations;
  assert.ok(!/undefined/.test(D.toSvg(noMeta)));
});

test('a cylinder ending exactly at the mouth does not break the exposed bullet', () => {
  const rec = structuredClone(by('308_win')); // pointy: zc = L3 - G1 + 0.4 * (L6 - L3 + G1)
  rec.cartridge.lengths.L6 = 51.18 + (7.85 * 0.6) / 0.4; // makes zc === L3
  const g = G.buildDrawing(rec);
  assert.ok(g.bullet.exposed.every((p) => Number.isFinite(p[0]) && Number.isFinite(p[1])));
});
