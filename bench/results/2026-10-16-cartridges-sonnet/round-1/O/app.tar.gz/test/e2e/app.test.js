const { describe, it, before, after } = require('node:test');
const assert = require('node:assert/strict');
const { launch, serve, fileUrl, records } = require('./helpers.js');

let browser, srv;
before(async () => { browser = await launch(); srv = await serve(); });
after(async () => { await browser.close(); srv.server.close(); });

for (const mode of ['file', 'http']) {
  describe(`app over ${mode}`, () => {
    let page, base, errors;
    before(async () => {
      base = mode === 'file' ? fileUrl : srv.url;
      page = await browser.newPage({ viewport: { width: 1000, height: 900 } });
      page.setDefaultTimeout(5000);
      errors = [];
      page.on('pageerror', (e) => errors.push(e.message));
      page.on('console', (m) => m.type() === 'error' && errors.push(m.text()));
    });
    after(async () => { assert.deepEqual(errors, []); await page.close(); });

    const names = () => page.locator('main table.list tbody a').allTextContents();
    const count = () => page.locator('.count').textContent();
    const goList = async () => { await page.goto(base); await page.getByRole('heading', { name: 'Cartridges', level: 1 }).waitFor(); };
    const goDetail = async (key) => {
      await page.goto(`${base}#/cartridge/${key}`);
      const name = (records.find((r) => r.key === key) || { name: 'Cartridge not found' }).name;
      await page.getByRole('heading', { name, level: 1, exact: true }).waitFor();
    };

    describe('list', () => {
      it('lists all 25 with exact names, family and L3', async () => {
        await goList();
        assert.deepEqual(await names(), records.map((r) => r.name));
        assert.equal(await count(), '25 cartridges');
        const row = page.locator('main table.list tbody tr', { has: page.getByRole('link', { name: '308 Win.', exact: true }) });
        const text = await row.textContent();
        assert.match(text, /rimless/);
        assert.match(text, /51\.18 mm/);
        assert.ok(await page.getByRole('link', { name: '6,5 Creedmoor', exact: true }).isVisible());
      });
      it('search finds alternative names as the user types', async () => {
        await goList();
        const search = page.getByLabel('Search');
        await search.pressSequentially('7,62 x 51');
        assert.ok((await names()).includes('308 Win.'));
        assert.equal(await count(), '1 cartridges');
        await search.fill('');
        await search.pressSequentially('zzz');
        assert.deepEqual(await names(), []);
        assert.equal(await count(), '0 cartridges');
        assert.ok(await search.evaluate((el) => el === document.activeElement), 'focus kept while typing');
      });
      it('family select offers the six options and filters', async () => {
        await goList();
        const sel = page.getByLabel('Family');
        assert.deepEqual(await sel.locator('option').allTextContents(), ['All', 'rimless', 'rimmed', 'belted', 'pistol', 'rimfire']);
        await sel.selectOption({ label: 'belted' });
        assert.deepEqual((await names()).sort(), ['300 Win. Mag.', '7 mm Rem. Mag.']);
        await sel.selectOption({ label: 'pistol' });
        assert.equal(await count(), '6 cartridges');
        await sel.selectOption({ label: 'rimfire' });
        await page.getByLabel('Search').fill('22');
        assert.deepEqual((await names()).sort(), ['22 Long Rifle', '22 Win. Mag. R.F.']);
        await sel.selectOption({ label: 'All' });
        await page.getByLabel('Search').fill('');
        assert.equal(await count(), '25 cartridges');
      });
      it('a name link opens the detail view', async () => {
        await goList();
        await page.getByRole('link', { name: '270 Win.', exact: true }).click();
        assert.match(page.url(), /#\/cartridge\/270_win$/);
        await page.getByRole('heading', { name: '270 Win.', level: 1 }).waitFor();
      });
    });

    describe('detail', () => {
      it('shows header facts', async () => {
        await goDetail('308_win');
        assert.equal(await page.locator('h1').first().textContent(), '308 Win.');
        const t = await page.locator('main').innerText();
        for (const s of ['308 Winchester', '7,62 x 51', 'rimless', 'rifle', 'lr', 'US', '1984-06-14', '2008-09-23', 'Transducer', '56 gr H2O'])
          assert.ok(t.includes(s), s);
        const dl = page.locator('dl.facts');
        assert.match(await dl.locator('dt', { hasText: 'C.I.P. table' }).locator('xpath=following-sibling::dd[1]').textContent(), /^I$/);
        const link = page.getByRole('link', { name: 'kwk' });
        assert.equal(await link.getAttribute('href'), 'http://kwk.us/cases.html');
        assert.equal(await page.title(), '308 Win. – C.I.P. cartridges');
      });
      it('shows "not published" for missing capacity', async () => {
        await goDetail('7_x_64');
        const dd = page.locator('dl.facts dt', { hasText: 'Water capacity' }).locator('xpath=following-sibling::dd[1]');
        assert.equal(await dd.textContent(), 'not published');
        assert.equal(await page.locator('dl.facts a').count(), 0);
      });
      it('tables have Symbol/Value/Unit and merge tolerances', async () => {
        await goDetail('270_win');
        const heads = await page.locator('main table.values thead').first().textContent();
        assert.match(heads, /Symbol\s*Value\s*Unit/);
        const l1 = page.locator('table.values tbody tr', { has: page.locator('th', { hasText: /^L1$/ }) }).first();
        assert.equal(await l1.locator('td').first().textContent(), '49.49 -0.2');
        assert.equal(await page.locator('table.values tbody th', { hasText: 'L1Tol' }).count(), 0);
        const alpha = page.locator('table.values tbody tr', { has: page.locator('th', { hasText: /^α$/ }) }).first();
        assert.equal(await alpha.locator('td').first().textContent(), '35°');
      });
      it('omits empty sections and keeps both groups', async () => {
        await goDetail('9_mm_luger');
        const caps = await page.locator('table.values caption').allTextContents();
        assert.ok(!caps.includes('Junction cone'));
        assert.ok(caps.includes('Case head') && caps.includes('Barrel'));
        const headings = await page.locator('main h2').allTextContents();
        assert.ok(headings.includes('Cartridge') && headings.includes('Chamber'));
      });
      it('has the drawing with its accessible name, Print and the back link', async () => {
        await goDetail('308_win');
        assert.ok(await page.getByRole('img', { name: '308 Win. drawing' }).isVisible());
        assert.ok(await page.getByRole('button', { name: 'Print' }).isVisible());
        assert.ok(await page.getByRole('link', { name: 'All cartridges' }).first().isVisible());
      });
      it('escapes names with special characters', async () => {
        await goDetail('40_s_w');
        assert.equal(await page.locator('h1').first().textContent(), '40 S.& W.');
        assert.ok(await page.getByRole('img', { name: '40 S.& W. drawing' }).isVisible());
      });
      it('survives a reload and navigates back', async () => {
        await goDetail('45_auto');
        await page.reload();
        assert.equal(await page.locator('h1').first().textContent(), '45 Auto');
        await page.getByRole('link', { name: 'All cartridges' }).first().click();
        await page.getByRole('heading', { name: 'Cartridges', level: 1 }).waitFor();
        assert.equal((await names()).length, 25);
      });
      it('odd addresses: bad escapes and empty keys are "not found", other anchors keep the list', async () => {
        for (const hash of ['#/cartridge/%E0%A4%A', '#/cartridge/', '#/cartridge/nope/x']) {
          await page.goto(base + hash);
          await page.getByText('Cartridge not found').waitFor();
        }
        await page.goto(base + '#/other');
        await page.getByRole('heading', { name: 'Cartridges', level: 1 }).waitFor();
      });
      it('skip link focuses the content without changing the view', async () => {
        await goDetail('308_win');
        await page.getByText('Skip to content').focus();
        await page.keyboard.press('Enter');
        assert.match(page.url(), /#\/cartridge\/308_win$/);
        assert.equal(await page.locator('h1').first().textContent(), '308 Win.');
        assert.ok(await page.locator('main').evaluate((el) => el === document.activeElement));
      });
      it('keeps search and family when coming back from a detail view', async () => {
        await goList();
        await page.getByLabel('Family').selectOption({ label: 'rimfire' });
        await page.getByLabel('Search').fill('22');
        await page.getByRole('link', { name: '22 Long Rifle', exact: true }).click();
        await page.getByRole('heading', { name: '22 Long Rifle', level: 1 }).waitFor();
        await page.goBack();
        await page.getByRole('heading', { name: 'Cartridges', level: 1 }).waitFor();
        assert.equal(await page.getByLabel('Search').inputValue(), '22');
        assert.equal(await page.getByLabel('Family').inputValue(), 'rimfire');
        assert.equal(await count(), '2 cartridges');
      });
      it('shows a message for an unknown cartridge', async () => {
        await goDetail('nope');
        assert.ok(await page.getByText('Cartridge not found').isVisible());
        assert.ok(await page.getByRole('link', { name: 'All cartridges' }).first().isVisible());
      });
    });
  });
}
