const { describe, it, before, after } = require('node:test');
const assert = require('node:assert/strict');
const { launch, serve, fileUrl, records } = require('./helpers.js');

let browser, srv;
before(async () => { browser = await launch(); srv = await serve(); });
after(async () => { await browser.close(); srv.server.close(); });

const lum = ([r, g, b]) => {
  const f = (c) => { c /= 255; return c <= 0.03928 ? c / 12.92 : ((c + 0.055) / 1.055) ** 2.4; };
  return 0.2126 * f(r) + 0.7152 * f(g) + 0.0722 * f(b);
};
const contrast = (a, b) => { const [x, y] = [lum(a), lum(b)].sort((p, q) => q - p); return (x + 0.05) / (y + 0.05); };
const rgb = (s) => s.match(/[\d.]+/g).slice(0, 3).map(Number);
const detail = (base, key) => `${base}#/cartridge/${key}`;
const newPage = async (opts) => { const p = await browser.newPage(opts); p.setDefaultTimeout(5000); return p; };
const settle = (p, name) => p.getByRole('heading', { name, level: 1, exact: true }).waitFor();

describe('app-delivery', () => {
  it('file:// and http: no errors, no request leaves the app', async () => {
    for (const [mode, base] of [['file', fileUrl], ['http', srv.url]]) {
      const page = await newPage();
      const errors = [], urls = [];
      page.on('pageerror', (e) => errors.push(e.message));
      page.on('console', (m) => m.type() === 'error' && errors.push(m.text()));
      page.on('request', (r) => urls.push(r.url()));
      await page.goto(base);
      for (const r of records) { await page.goto(detail(base, r.key)); await settle(page, r.name); await page.locator('svg.drawing').waitFor(); }
      assert.deepEqual(errors, [], mode);
      const origin = mode === 'file' ? 'file://' : new URL(srv.url).origin;
      assert.deepEqual(urls.filter((u) => !u.startsWith(origin)), [], mode);
      await page.close();
    }
  });

  it('a detail address opened directly works on the static server', async () => {
    const page = await newPage();
    await page.goto(detail(srv.url, '300_win_mag'));
    await settle(page, '300 Win. Mag.');
    await page.close();
  });

  for (const scheme of ['light', 'dark']) {
    it(`${scheme} scheme: readable contrast for text, links and the drawing`, async () => {
      const page = await newPage({ colorScheme: scheme });
      await page.goto(detail(fileUrl, '308_win')); await settle(page, '308 Win.');
      const c = await page.evaluate(() => {
        const cs = (el, p) => getComputedStyle(el)[p];
        const bg = cs(document.body, 'backgroundColor');
        return { bg, text: cs(document.body, 'color'), link: cs(document.querySelector('a.back'), 'color'),
          svg: cs(document.querySelector('svg.drawing'), 'color'), muted: cs(document.querySelector('.source'), 'color'),
          th: cs(document.querySelector('table.values th'), 'color') };
      });
      assert.notEqual(c.bg, 'rgba(0, 0, 0, 0)');
      for (const k of ['text', 'link', 'svg', 'muted', 'th']) assert.ok(contrast(rgb(c[k]), rgb(c.bg)) >= 4.5, `${scheme} ${k} ${c[k]} on ${c.bg}`);
      const dark = lum(rgb(c.bg)) < 0.2;
      assert.equal(dark, scheme === 'dark');
      await page.close();
    });
  }

  it('360 px wide: no horizontal scrolling, drawing fits', async () => {
    const page = await newPage({ viewport: { width: 360, height: 740 } });
    const overflow = () => page.evaluate(() => document.documentElement.scrollWidth - window.innerWidth);
    await page.goto(fileUrl);
    assert.ok((await overflow()) <= 0, 'list');
    for (const r of records) {
      await page.goto(detail(fileUrl, r.key)); await settle(page, r.name);
      assert.ok((await overflow()) <= 0, `${r.key} overflows by ${await overflow()}`);
      const w = await page.locator('svg.drawing').evaluate((el) => el.getBoundingClientRect().width);
      assert.ok(w <= 360 && w > 250, `${r.key} drawing ${w}`);
    }
    assert.ok(await page.getByLabel('Search').count() === 0); // not on detail view
    await page.goto(fileUrl);
    assert.ok(await page.getByLabel('Search').isVisible());
    assert.ok(await page.getByLabel('Family').isVisible());
    await page.close();
  });

  it('numbers are tabular and right-aligned', async () => {
    const page = await newPage();
    await page.goto(detail(fileUrl, '308_win')); await settle(page, '308 Win.');
    const s = await page.locator('table.values td.num').first().evaluate((el) => { const c = getComputedStyle(el); return [c.fontVariantNumeric, c.textAlign]; });
    assert.match(s[0], /tabular-nums/); assert.equal(s[1], 'right');
    await page.close();
  });
});

describe('cartridge-print', () => {
  it('Print calls window.print once', async () => {
    const page = await newPage();
    await page.addInitScript(() => { window.__prints = 0; window.print = () => { window.__prints++; }; });
    await page.goto(detail(fileUrl, '308_win')); await settle(page, '308 Win.');
    await page.getByRole('button', { name: 'Print' }).click();
    assert.equal(await page.evaluate(() => window.__prints), 1);
    await page.close();
  });

  it('prints black on white without interface, with header and footer', async () => {
    const page = await newPage({ colorScheme: 'dark' });
    await page.goto(detail(fileUrl, '308_win')); await settle(page, '308 Win.');
    await page.emulateMedia({ media: 'print', colorScheme: 'dark' });
    const c = await page.evaluate(() => ({ bg: getComputedStyle(document.body).backgroundColor, fg: getComputedStyle(document.body).color,
      svg: getComputedStyle(document.querySelector('svg.drawing')).color }));
    assert.deepEqual(rgb(c.bg), [255, 255, 255]);
    assert.ok(lum(rgb(c.fg)) < 0.02 && lum(rgb(c.svg)) < 0.02, JSON.stringify(c));
    for (const sel of ['button.print', 'a.back', 'header.site', 'footer.site', 'nav.toolbar'])
      assert.equal(await page.locator(sel).first().isVisible(), false, sel);
    assert.ok(await page.locator('h1').first().isVisible());
    assert.equal((await page.locator('.source').textContent()).trim(), 'Source: C.I.P. TDCC, revised 2008-09-23');
    assert.ok(await page.locator('.source').isVisible());
    await page.close();
  });

  it('drawing prints at full width with labels of at least 7 pt', async () => {
    const page = await newPage({ viewport: { width: 718, height: 1000 } }); // 190 mm at 96 dpi
    for (const key of ['308_win', '22_long_rifle', '9_3_x_74_r']) {
      await page.goto(detail(fileUrl, key)); await page.locator('svg.drawing').waitFor();
      await page.emulateMedia({ media: 'print' });
      const m = await page.locator('svg.drawing').evaluate((el) => {
        const vb = el.viewBox.baseVal;
        return { w: el.getBoundingClientRect().width, vbw: vb.width, fs: Math.min(...[...el.querySelectorAll('text.label')].map((t) => parseFloat(t.closest('[font-size]')?.getAttribute('font-size') || el.getAttribute('font-size')))) };
      });
      assert.ok(m.w >= 718 * 0.98, `${key} width ${m.w}`);
      const pt = m.fs * (m.w / m.vbw) * 0.75;
      assert.ok(pt >= 7, `${key} label ${pt.toFixed(1)}pt`);
    }
    await page.close();
  });

  it('each of the 25 cartridges prints on exactly one A4 portrait page', async () => {
    const page = await newPage();
    for (const r of records) {
      await page.goto(detail(fileUrl, r.key)); await settle(page, r.name);
      const pdf = await page.pdf({ format: 'A4', printBackground: true, preferCSSPageSize: true });
      const text = pdf.toString('latin1');
      const pages = (text.match(/\/Type\s*\/Page(?![s\w])/g) || []).length;
      assert.equal(pages, 1, `${r.key} prints on ${pages} pages`);
      const box = text.match(/\/MediaBox\s*\[\s*0\s+0\s+([\d.]+)\s+([\d.]+)\s*\]/);
      assert.ok(Math.abs(box[1] - 595.28) < 1 && Math.abs(box[2] - 841.89) < 1, `${r.key} ${box[0]}`);
    }
    await page.close();
  });
});
