// Shared e2e setup: launches Chromium (using dev-only library/font shims when present), serves the project statically.
const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const os = require('node:os');
const { chromium } = require('playwright');

const root = path.resolve(__dirname, '../..');
const MIME = { '.html': 'text/html', '.js': 'text/javascript', '.css': 'text/css', '.svg': 'image/svg+xml' };

function env() {
  const e = { ...process.env };
  const libs = path.join(os.homedir(), '.local/chromium-libs');
  if (fs.existsSync(libs) && !e.LD_LIBRARY_PATH)
    e.LD_LIBRARY_PATH = `${libs}/usr/lib/x86_64-linux-gnu:${libs}/lib/x86_64-linux-gnu`;
  const fonts = path.join(os.homedir(), '.fonts/fonts.conf');
  if (fs.existsSync(fonts) && !e.FONTCONFIG_FILE) e.FONTCONFIG_FILE = fonts;
  return e;
}

const launch = () => chromium.launch({ env: env() });

function serve() {
  const server = http.createServer((req, res) => {
    const file = path.join(root, decodeURIComponent(new URL(req.url, 'http://x').pathname.replace(/\/$/, '/index.html')));
    if (path.relative(root, file).startsWith('..') || !fs.existsSync(file) || fs.statSync(file).isDirectory()) { res.writeHead(404).end('not found'); return; }
    res.writeHead(200, { 'content-type': MIME[path.extname(file)] || 'application/octet-stream' }).end(fs.readFileSync(file));
  });
  return new Promise((resolve) => server.listen(0, '127.0.0.1', () =>
    resolve({ server, url: `http://127.0.0.1:${server.address().port}/index.html` })));
}

const fileUrl = `file://${path.join(root, 'index.html')}`;
const records = fs.readFileSync(path.join(root, 'test/fixtures/cartridges.jsonl'), 'utf8').trim().split('\n').map((l) => JSON.parse(l));

module.exports = { launch, serve, fileUrl, records, root };
