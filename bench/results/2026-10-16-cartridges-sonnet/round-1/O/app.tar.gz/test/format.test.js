const test = require('node:test');
const assert = require('node:assert/strict');
require('../js/data.js');
const F = require('../js/format.js');
const data = globalThis.CIP.cartridges;
const by = (key) => data.find((r) => r.key === key);
const rows = (rec, part, section) =>
  F.sections(rec, part).find((s) => s.id === section).rows;
const row = (rec, part, section, symbol) =>
  rows(rec, part, section).find((r) => r.symbol === symbol);

test('numbers are shown as published', () => {
  assert.equal(F.num(51.18), '51.18');
  assert.equal(F.num(4150.0), '4150');
  assert.equal(F.num(25), '25');
  assert.equal(F.num(0.1), '0.1');
});

test('angles: degrees, and degrees/minutes/seconds', () => {
  assert.equal(F.angle(40.0), '40°');
  assert.equal(F.angle(3), '3°');
  assert.equal(F.angle({ degrees: 39, minutes: 59, seconds: 49 }), '39°59\'49"');
  assert.equal(F.angle({ degrees: 1, minutes: 30, seconds: 0 }), '1°30\'0"');
});

test('symbols: field name, with the listed exceptions', () => {
  const expected = {
    eMin: 'e min', r1Min: 'r1 min', r1Max: 'r1 max', alpha: 'α', alpha1: 'α1',
    beta: 'β', delta: 'δ', deltaL: 'delta L', L3PlusG: 'L3 + G',
    L3: 'L3', Pmax: 'Pmax', G1: 'G1',
  };
  for (const [field, sym] of Object.entries(expected)) assert.equal(F.symbol(field), sym);
});

test('units', () => {
  const rec = by('6_5_creedmoor');
  assert.deepEqual(
    ['Pmax', 'PK', 'PE'].map((s) => row(rec, 'cartridge', 'pressures', s).unit), ['bar', 'bar', 'bar']);
  assert.equal(row(rec, 'cartridge', 'pressures', 'EE').unit, 'J');
  assert.equal(row(rec, 'cartridge', 'pressures', 'M').unit, 'g');
  assert.equal(row(rec, 'chamber', 'grooves', 'Q').unit, 'mm²');
  assert.equal(row(rec, 'chamber', 'grooves', 'N').unit, '');
  assert.equal(row(rec, 'chamber', 'grooves', 'N').value, '6');
  assert.equal(row(rec, 'cartridge', 'pressures', 'Pmax').value, '4350');
  assert.equal(row(rec, 'cartridge', 'lengths', 'L3').unit, 'mm');
  // angles carry their unit in the value
  assert.equal(row(rec, 'cartridge', 'caseHead', 'β').unit, '');
  assert.equal(row(rec, 'cartridge', 'caseHead', 'β').value, '35°');
});

test('tolerance sits in the value cell, never in a row of its own', () => {
  const rec = by('270_win');
  assert.equal(row(rec, 'cartridge', 'lengths', 'L1').text, '49.49 -0.2');
  for (const r of data) for (const part of ['cartridge', 'chamber'])
    for (const s of F.sections(r, part))
      for (const x of s.rows) assert.ok(!/Tol$/.test(x.symbol), `${r.key} ${x.symbol}`);
  assert.equal(row(by('300_win_mag'), 'cartridge', 'caseHead', 'E').text, '5.59 -0.2');
});

test('angle rows', () => {
  assert.equal(row(by('338_lapua_mag'), 'cartridge', 'junctionCone', 'α').text, '39°59\'49"');
  assert.equal(row(by('338_lapua_mag'), 'chamber', 'rifling', 'α1').text, '90°');
  assert.equal(row(by('7_mm_rem_mag'), 'chamber', 'rifling', 'i').text, '3°');
});

test('renamed symbols appear, raw names do not', () => {
  const rec = by('243_win');
  const all = ['cartridge', 'chamber'].flatMap((p) => F.sections(rec, p)).flatMap((s) => s.rows.map((r) => r.symbol));
  for (const s of ['e min', 'r1 min', 'α', 'β', 'δ', 'delta L', 'L3 + G']) assert.ok(all.includes(s), s);
  for (const s of ['eMin', 'alpha', 'L3PlusG', 'beta', 'delta']) assert.ok(!all.includes(s), s);
});

test('sections: grouped by record section, empty ones skipped', () => {
  const ids = (rec, p) => F.sections(rec, p).map((s) => s.id);
  assert.deepEqual(ids(by('223_rem'), 'cartridge'),
    ['caseHead', 'collar', 'junctionCone', 'lengths', 'misc', 'powderChamber', 'pressures', 'projectile']);
  assert.deepEqual(ids(by('223_rem'), 'chamber'),
    ['barrel', 'breech', 'collar', 'grooves', 'junctionCone', 'lengths', 'powderChamber', 'rifling']);
  assert.ok(!ids(by('9_mm_luger'), 'cartridge').includes('junctionCone'));
  assert.ok(!ids(by('9_mm_luger'), 'chamber').includes('junctionCone'));
  assert.equal(F.sections(by('223_rem'), 'cartridge')[0].title, 'Case head');
});

test('every scalar value of every record appears in exactly one row', () => {
  const count = (o) => Object.entries(o).filter(([k]) => !k.endsWith('Tol')).length;
  for (const r of data) for (const part of ['cartridge', 'chamber']) {
    const expected = Object.values(r[part]).reduce((n, sec) => n + count(sec), 0);
    const got = F.sections(r, part).reduce((n, s) => n + s.rows.length, 0);
    assert.equal(got, expected, `${r.key} ${part}`);
  }
});

test('water capacity', () => {
  const c = F.capacity(by('308_win'));
  assert.equal(c.text, '56 gr H2O');
  assert.equal(c.url, 'http://kwk.us/cases.html');
  assert.equal(c.source, 'kwk');
  assert.equal(F.capacity(by('7_x_64')), null);
});

test('search matches names and alternative names; family filter; combined', () => {
  const names = (q, f) => data.filter((r) => F.matches(r, q, f)).map((r) => r.name);
  assert.ok(names('7,62 x 51', 'all').includes('308 Win.'));
  assert.ok(names('  308 WINCHESTER ', 'all').includes('308 Win.'));
  assert.equal(names('zzz', 'all').length, 0);
  assert.equal(names('', 'all').length, 25);
  assert.deepEqual(names('', 'belted').sort(), ['300 Win. Mag.', '7 mm Rem. Mag.']);
  assert.equal(names('', 'pistol').length, 6);
  assert.deepEqual(names('22', 'rimfire').sort(), ['22 Long Rifle', '22 Win. Mag. R.F.']);
});
