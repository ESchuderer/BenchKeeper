const test = require('node:test');
const assert = require('node:assert/strict');
require('../js/data.js');
const G = require('../js/geometry.js');
const data = globalThis.CIP.cartridges;
const by = (key) => data.find((r) => r.key === key);
const near = (a, b, eps = 1e-9) => assert.ok(Math.abs(a - b) <= eps, `${a} !~ ${b}`);
const hasPt = (poly, [z, r], eps = 1e-9) =>
  poly.some((p) => Math.abs(p[0] - z) <= eps && Math.abs(p[1] - r) <= eps);
const dist = (a, b) => Math.hypot(a[0] - b[0], a[1] - b[1]);
const deg = (x) => (x * Math.PI) / 180;

test('rim type', () => {
  const t = (k) => G.rimType(by(k));
  assert.equal(t('9_3_x_74_r'), 'rimmed');
  assert.equal(t('6_5_x_55_se'), 'rimless');
  assert.equal(t('300_win_mag'), 'belted');
  assert.equal(t('22_long_rifle'), 'rimfire');
  const r = structuredClone(by('308_win')); r.cartridge.caseHead.R1 = 11.5;
  assert.equal(G.rimType(r), 'rebated');
});

test('chamfer where beta and f are published, square corner otherwise', () => {
  const d = G.buildDrawing(by('223_rem'));
  const c = Math.min(0.45 * Math.tan(deg(35)), 9.6 / 4);
  assert.ok(hasPt(d.outer, [0, 9.6 / 2 - c]));
  assert.ok(hasPt(d.outer, [0.45, 9.6 / 2]));
  assert.deepEqual(d.outer[0], [0, 0]);
  // 9,3 x 74 R: beta/f published -> chamfer too
  assert.ok(hasPt(G.buildDrawing(by('9_3_x_74_r')).outer, [0.3, 13.35 / 2]));
});

test('rimfire rim edge is a half-round, no chamfer, no pocket', () => {
  const d = G.buildDrawing(by('22_win_mag_r_f'));
  const rr = Math.min(1.27 / 2, (7.47 - 6.15) / 2);
  assert.equal(d.rimType, 'rimfire');
  assert.ok(hasPt(d.outer, [1.27 / 2, 7.47 / 2]));
  near(Math.max(...d.outer.map((p) => p[1])), 7.47 / 2);
  assert.ok(hasPt(d.outer, [0, 7.47 / 2 - rr]));
  assert.equal(d.pocket, null);
  assert.deepEqual(d.notes, []);
  const lr = G.buildDrawing(by('22_long_rifle'));
  near(Math.max(...lr.outer.map((p) => p[1])), 7.06 / 2);
  assert.equal(lr.pocket, null);
  assert.equal(G.buildDrawing(by('17_hmr')).pocket, null);
});

test('extractor groove points', () => {
  const d = G.buildDrawing(by('308_win'));
  assert.ok(hasPt(d.outer, [1.37, 12.01 / 2]));
  assert.ok(hasPt(d.outer, [1.37, 10.39 / 2]));
  assert.ok(hasPt(d.outer, [1.37 + 1.4, 10.39 / 2]));
  assert.ok(hasPt(d.outer, [3.85, 11.96 / 2]));
  assert.deepEqual(d.notes, []);
});

test('belt follows the groove on belted cases', () => {
  const rec = by('300_win_mag'); const h = rec.cartridge.caseHead;
  const d = G.buildDrawing(rec);
  const z1 = h.R + h.eMin + (h.R3 / 2 - h.E1 / 2) / Math.tan(deg(h.delta));
  assert.ok(hasPt(d.outer, [h.R + h.eMin, h.E1 / 2]));
  assert.ok(hasPt(d.outer, [z1, h.R3 / 2]));
  assert.ok(hasPt(d.outer, [h.E, h.R3 / 2]));
  assert.ok(hasPt(d.outer, [h.E, 13.03 / 2]));
  assert.equal(d.rimType, 'belted');
});

test('rimmed case without groove steps in after the rim and reports the missing values', () => {
  const d = G.buildDrawing(by('9_3_x_74_r'));
  assert.ok(hasPt(d.outer, [1.4, 13.35 / 2]));
  assert.ok(hasPt(d.outer, [1.4, 11.9 / 2]));
  assert.ok(d.notes.some((n) => /groove/i.test(n) && /E1/.test(n)));
});

test('a record lacking E1 gets no groove and a note naming E1', () => {
  const rec = structuredClone(by('308_win')); delete rec.cartridge.caseHead.E1;
  const d = G.buildDrawing(rec);
  assert.ok(!d.outer.some((p) => Math.abs(p[1] - 10.39 / 2) < 1e-9));
  assert.ok(hasPt(d.outer, [1.37, 11.96 / 2]));
  assert.equal(d.notes.length, 1);
  assert.match(d.notes[0], /E1/);
  assert.doesNotMatch(d.notes[0], /\bE\b.*\bE\b/);
});

test('bottleneck: vertices at the published points, mouth at (H2/2, L3), rounded corners', () => {
  const rec = by('243_win'); const c = rec.cartridge;
  const d = G.buildDrawing(rec);
  assert.equal(d.shape, 'bottleneck');
  assert.ok(hasPt(d.vertices, [39.62, 11.53 / 2]));
  assert.ok(hasPt(d.vertices, [45.83, 7.01 / 2]));
  assert.ok(hasPt(d.vertices, [51.94, 7.01 / 2]));
  assert.deepEqual(d.outer.at(-1), [51.94, 7.01 / 2]);
  const v = d.vertices;
  const turn = (a, b, c2) => {
    const a1 = Math.atan2(b[1] - a[1], b[0] - a[0]), a2 = Math.atan2(c2[1] - b[1], c2[0] - b[0]);
    return Math.abs(a2 - a1);
  };
  const i1 = v.findIndex((p) => p[0] === 39.62), i2 = v.findIndex((p) => p[0] === 45.83);
  const gap = (vertex, r, th) => r * (1 / Math.cos(th / 2) - 1);
  const minDist = (p) => Math.min(...d.outer.map((q) => dist(p, q)));
  const th1 = turn(v[i1 - 1], v[i1], v[i1 + 1]), th2 = turn(v[i2 - 1], v[i2], v[i2 + 1]);
  // distance from vertex to the arc's closest sample, within sampling error
  near(minDist(v[i1]), gap(v[i1], c.junctionCone.r1Min, th1), 0.01);
  near(minDist(v[i2]), gap(v[i2], c.junctionCone.r2, th2), 0.01);
  assert.deepEqual(d.notes, []);
});

test('corner radius missing: sharp corners and a note', () => {
  const d = G.buildDrawing(by('17_hmr'));
  assert.equal(d.shape, 'bottleneck');
  assert.ok(d.vertices.every((p) => hasPt(d.outer, p)));
  assert.ok(d.notes.some((n) => /r1 min/.test(n)));
  assert.ok(d.notes.some((n) => /r2/.test(n)));
  const l = G.buildDrawing(by('338_lapua_mag'));
  assert.ok(l.notes.some((n) => /r1 min/.test(n)) && !l.notes.some((n) => /r2/.test(n)));
});

test('straight case runs from the body start to (H2/2, L3)', () => {
  const d = G.buildDrawing(by('45_auto'));
  assert.equal(d.shape, 'straight');
  assert.equal(d.vertices.length, 2);
  assert.deepEqual(d.vertices[1], [22.81, 12.01 / 2]);
  assert.deepEqual(d.outer.at(-1), [22.81, 12.01 / 2]);
  assert.equal(d.cone, null);
});

test('bullet: seating, cylinder, meplat and nose per shape', () => {
  const b = (k) => G.buildDrawing(by(k)).bullet;
  // pointy / tangent ogive
  let x = b('308_win');
  near(x.s, 7.85); near(x.zb, 51.18 - 7.85); near(x.Lb, 71.12 - x.zb);
  near(x.zc, x.zb + 0.4 * x.Lb); near(x.m, 1.27);
  const hw = 7.85 / 2 - 1.27 / 2;
  near(x.rho, (hw * hw + x.n * x.n) / (2 * hw));
  assert.deepEqual(x.exposed.at(-1), [71.12, 0]);
  assert.ok(hasPt(x.exposed, [71.12, 1.27 / 2], 1e-6));
  for (const p of x.nose) near(Math.hypot(p[0] - x.center[0], p[1] - x.center[1]), x.rho, 1e-9);
  assert.equal(x.exposed[0][0], 51.18);
  // rounded pistol
  x = b('9_mm_luger');
  near(x.s, 0.4 * 9.03); near(x.zc, x.zb + 0.65 * x.Lb); near(x.m, 0.15 * 9.03);
  assert.ok(hasPt(x.nose, [29.69, 0.15 * 9.03 / 2], 1e-9));
  // rounded rifle / rimfire
  x = b('22_win_mag_r_f');
  near(x.s, 0.8 * 5.7); near(x.zc, x.zb + 0.55 * x.Lb);
  // flat pistol
  x = b('40_s_w');
  near(x.s, 0.4 * 10.17); near(x.zc, x.zb + 0.70 * x.Lb); near(x.m, 0.55 * 10.17);
  // semi wadcutter pistol
  x = b('357_magnum');
  near(x.s, 0.6 * 9.12); near(x.zc, x.zb + 0.78 * x.Lb); near(x.m, 0.6 * 9.12);
  // flat rifle: 0.8 G1 and 0.60 (none in data, synthetic)
  const rec = structuredClone(by('17_hmr')); rec.annotations.defaultBulletShape = 'flat';
  x = G.buildDrawing(rec).bullet;
  near(x.s, 0.8 * 4.38); near(x.zc, x.zb + 0.6 * x.Lb); near(x.m, 0.55 * 4.38);
});

test('heeled case: exposed bullet at the case diameter, seated heel at the inside diameter', () => {
  const d = G.buildDrawing(by('22_long_rifle'));
  const { tb } = d.walls;
  assert.equal(d.bullet.heeled, true);
  near(d.bullet.exposedRadius, 5.72 / 2);
  near(d.bullet.heelRadius, 5.72 / 2 - tb);
  assert.ok(hasPt(d.bullet.full, [15.57, 5.72 / 2 - tb]));
  assert.ok(hasPt(d.bullet.full, [15.57, 5.72 / 2]));
  assert.ok(!G.buildDrawing(by('22_win_mag_r_f')).bullet.heeled);
});

test('walls, solid head, primer pocket', () => {
  let d = G.buildDrawing(by('308_win'));
  near(d.walls.tn, (8.72 - 7.85) / 2); near(d.walls.tb, 0.6);
  assert.deepEqual(d.pocket, { d: 5.33, depth: 3.3 });
  near(d.w, Math.max(2.5, 0.25 * 11.96 / 2, 3.3 + 1.5, 3.85 + 0.6));
  assert.deepEqual(d.inner.at(-1), [51.18, 8.72 / 2 - d.walls.tn]);
  near(d.inner[0][0], d.w);
  d = G.buildDrawing(by('9_mm_luger'));
  assert.deepEqual(d.pocket, { d: 4.45, depth: 3.04 });
  near(d.w, Math.max(2.5, 0.25 * 9.93 / 2, 3.04 + 1.5, 2.98 + 0.6));
  assert.deepEqual(G.buildDrawing(by('300_win_mag')).pocket, { d: 5.33, depth: 3.3 });
  assert.equal(by('45_auto').annotations.primerType, 'lp');
  assert.deepEqual(G.buildDrawing(by('45_auto')).pocket, { d: 5.33, depth: 3.04 });
  assert.deepEqual(G.buildDrawing(by('357_magnum')).pocket, { d: 4.45, depth: 3.04 });
  assert.deepEqual(G.buildDrawing(by('44_rem_mag')).pocket, { d: 5.33, depth: 3.04 });
  assert.deepEqual(G.buildDrawing(by('223_rem')).pocket, { d: 4.45, depth: 3.04 });
  // inner wall follows the neck at tn, the body at tb
  d = G.buildDrawing(by('243_win'));
  const rIn = (z) => G.rAt(d.inner, z);
  near(rIn(30), G.rAt(d.bodyOuter, 30) - d.walls.tb, 1e-9);
  near(rIn(50), 7.01 / 2 - d.walls.tn, 1e-9);
});

test('hatch polygon encloses the head and walls (half-plane r >= 0)', () => {
  for (const r of data) {
    const d = G.buildDrawing(r);
    assert.ok(d.hatch.length > 6, r.key);
    assert.ok(d.hatch.every((p) => p[1] >= -1e-9), r.key);
    assert.deepEqual(d.hatch[0][0], 0);
  }
});

test('cone apex lies on the axis along the shoulder line', () => {
  const d = G.buildDrawing(by('308_win'));
  const [z, r] = d.cone.apex;
  assert.equal(r, 0);
  const slope = (11.53 / 2 - 8.72 / 2) / (43.48 - 39.62);
  near(z, 43.48 + (8.72 / 2) / slope, 1e-9);
});

test('all 25 records build: finite coordinates, ends at the mouth, z never decreases', () => {
  for (const rec of data) {
    const d = G.buildDrawing(rec);
    assert.equal(d.ok, true, rec.key);
    const all = [d.outer, d.inner, d.hatch, d.bullet.full, d.bullet.exposed].flat();
    assert.ok(all.every((p) => Number.isFinite(p[0]) && Number.isFinite(p[1])), rec.key);
    assert.deepEqual(d.outer[0], [0, 0]);
    near(d.outer.at(-1)[0], rec.cartridge.lengths.L3);
    for (let i = 1; i < d.outer.length; i++) assert.ok(d.outer[i][0] >= d.outer[i - 1][0] - 1e-9, `${rec.key} @${i}`);
    near(Math.max(...d.bullet.full.map((p) => p[0])), rec.cartridge.lengths.L6, 1e-6);
    assert.ok(d.bbox.maxZ >= rec.cartridge.lengths.L6 - 1e-6);
  }
});

test('a complete record has no notes; notes never invent numbers', () => {
  assert.deepEqual(G.buildDrawing(by('308_win')).notes, []);
  assert.deepEqual(G.buildDrawing(by('223_rem')).notes, []);
});

test('missing required value: no outline, a note', () => {
  const rec = structuredClone(by('308_win')); delete rec.cartridge.lengths.L3;
  const d = G.buildDrawing(rec);
  assert.equal(d.ok, false);
  assert.match(d.notes.join(' '), /L3/);
});
