# C.I.P. Cartridge Reference Constitution

## Core Principles

### I. Zero-Dependency Static App
The app is plain HTML, CSS and JavaScript. It MUST NOT use a framework, a build step, server code,
runtime dependencies or network requests (no CDNs, web fonts or analytics). It MUST work when
`index.html` is opened from disk in Chromium (`file://`) and when served by any static file server.
Development tools (test runner, browser driver) MAY exist only as npm devDependencies.
Rationale: the reference must stay usable offline, forever, with nothing to install.

### II. Data Fidelity
The 25 supplied records are the only data. Code MUST NOT add, change, invent, round or fetch values.
Values and names are shown as published. If a value a feature needs is missing, that feature is
omitted and the missing value is named; no number is ever made up.
Rationale: a technical audience relies on the numbers being the published ones.

### III. Test-First (NON-NEGOTIABLE)
Tests are written and seen failing before the code that satisfies them. Logic (formatting, search,
routing, geometry) lives in pure modules testable under Node 22. UI behaviour is verified in a real
Chromium, including from `file://`. A task is not done until its tests pass.

### IV. Accessible, Responsive, Printable
Semantic HTML, labelled controls, an accessible name on the SVG drawing, usable on a phone, light
and dark on screen following the system setting, print always light on one A4 portrait page.
Colour is never the only carrier of meaning.

### V. Simplicity
YAGNI. The smallest code that fully meets the spec wins. No abstraction, option or file that no
requirement needs. Detail views use hash routing so they survive a reload under `file://`.

## Constraints

- Node.js 22 for development; the interface is in English.
- Output files: `index.html` in the project root with its CSS and JavaScript files.
- Drawing geometry follows the written rules in the spec; where a rule is ambiguous the spec is
  amended first, then the code.

## Development Workflow

Phases, in order: specify, plan, tasks, analyze, implement (tests first), verify, review. Each
phase's artifact lives under `specs/`. Review checks the diff against this constitution and the spec.

## Governance

This constitution supersedes other practice. Amendments need a written reason and a version bump
(MAJOR: principle removed or redefined; MINOR: principle or section added or expanded; PATCH:
wording). Every plan and review MUST check compliance; deviations are recorded with justification.

**Version**: 1.0.0 | **Ratified**: 2026-10-16 | **Last Amended**: 2026-10-16
