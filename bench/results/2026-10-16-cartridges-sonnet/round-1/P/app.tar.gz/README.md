# C.I.P. cartridge reference

A static reference of 25 C.I.P. cartridges: list with search and family filter, a detail view with a true-scale
2D drawing (1 SVG unit = 1 mm) and all published values, and a one-page A4 print sheet.

**Run**: open `index.html` directly in Chromium (`file://`), or serve the folder with any static server.
There is no build step, no dependency and no network request.

**Data**: `data/cartridges.jsonl` is the verbatim source (OpenBallistics, MIT, commit e83db43);
`data/cartridges.js` is the same data as a script so it loads from `file://`. A test keeps them identical.

**Code**: `js/format.js` (values, units, symbols, search), `js/geometry.js` (rules 1-9: outline, bullet, walls),
`js/drawing.js` (SVG, dimension and label layout), `js/app.js` (hash router, views), `css/app.css`.
Routes: `#/` and `#/cartridge/<key>`.

**Tests** (dev only): `npm install`, then `npm test` (unit, Node 22) and `npm run test:ui` (Playwright + Chromium:
`file://`, served, print to PDF, dark mode, 360 px). In a container without system libraries for Chromium,
`test/ui/browser.js` uses libraries extracted to `~/chromelibs` if that folder exists.

**Where the brief left a choice** (see `specs/001-cartridge-reference/spec.md`, Assumptions): the rimfire rim
edge is a rounded rectangle that is a half-round when the radius is R/2; straight cases use wall tb up to the bullet
base and tn from there; a groove or rounding that cannot be drawn is listed under the drawing as "Not drawn".
