// Router and views. Hash routes: "#/" (list) and "#/cartridge/<key>" (detail).
(function () {
  const F = CIP.format;
  const app = document.getElementById('app');
  const FAMILIES = ['rimless', 'rimmed', 'belted', 'pistol', 'rimfire'];
  const dash = v => v === undefined || v === '' ? '—' : v;

  function el(tag, attrs, ...kids) {
    const e = document.createElement(tag);
    for (const [k, v] of Object.entries(attrs || {})) e.setAttribute(k, v);
    e.append(...kids);
    return e;
  }

  const filters = { q: '', family: '' }; // kept while the user visits a detail view and comes back

  function listView() {
    document.title = 'C.I.P. cartridges';
    const search = el('input', { type: 'search', id: 'search', autocomplete: 'off' });
    const family = el('select', { id: 'family' }, el('option', { value: '' }, 'All'), ...FAMILIES.map(f => el('option', { value: f }, f)));
    search.value = filters.q; family.value = filters.family;
    const count = el('p', { id: 'count', 'aria-live': 'polite' });
    const body = el('tbody');
    const render = () => {
      const rows = CARTRIDGES.filter(r => (!family.value || r.family === family.value) && F.matches(r, search.value));
      body.replaceChildren(...rows.map(r => el('tr', {},
        el('td', {}, el('a', { href: '#/cartridge/' + r.key }, r.name)),
        el('td', {}, r.family),
        el('td', { class: 'num' }, F.value(r.cartridge.lengths.L3)))));
      count.textContent = `${rows.length} cartridges`;
    };
    search.addEventListener('input', () => { filters.q = search.value; render(); });
    family.addEventListener('change', () => { filters.family = family.value; render(); });
    render();
    app.replaceChildren(
      el('h1', {}, 'Cartridges'),
      el('div', { class: 'controls' },
        el('label', {}, 'Search', search),
        el('label', {}, 'Family', family)),
      count,
      el('table', { id: 'list' },
        el('thead', {}, el('tr', {}, el('th', {}, 'Name'), el('th', {}, 'Family'), el('th', { class: 'num' }, 'L3 (mm)'))),
        body));
  }

  const nav = () => el('nav', { class: 'bar' }, el('a', { href: '#/' }, 'All cartridges'),
    Object.assign(el('button', { type: 'button' }, 'Print'), { onclick: () => window.print() }));

  function tables(title, group) {
    return [el('h2', {}, title), el('div', { class: 'tables' }, ...F.sections(group).map(s => el('div', {},
      el('h3', {}, s.title),
      el('table', { class: 'values' },
        el('thead', {}, el('tr', {}, el('th', {}, 'Symbol'), el('th', {}, 'Value'), el('th', {}, 'Unit'))),
        el('tbody', {}, ...s.rows.map(r => el('tr', {}, el('td', {}, r.symbol), el('td', {}, r.value), el('td', {}, r.unit))))))))];
  }

  function facts(r) {
    const cap = r.annotations.publishedCapacity;
    const capacity = cap ? [`${F.value(cap.grH2O)} gr H2O `, el('a', { href: cap.url }, cap.source), cap.note ? ` (${cap.note})` : ''] : ['not published'];
    const rows = [
      ['Alternative names', (r.alternativeNames || []).join(', ')], ['Family', r.family], ['Category', r.annotations.category],
      ['Primer type', r.annotations.primerType], ['C.I.P. table', r.tab], ['Country', r.country], ['Published', r.published],
      ['Revised', r.revised], ['Pressure method', r.pressureMethod], ['Water capacity', capacity],
    ];
    return el('dl', { id: 'facts' }, ...rows.flatMap(([k, v]) => [el('dt', {}, k), el('dd', {}, ...[].concat(dash(v)))]));
  }

  function detailView(key) {
    const r = CARTRIDGES.find(c => c.key === key);
    if (!r) {
      document.title = 'Cartridge not found';
      app.replaceChildren(nav(), el('h1', {}, 'Cartridge not found'), el('p', {}, `There is no cartridge "${key}".`));
      return;
    }
    document.title = r.name + ' – C.I.P. cartridges';
    const figure = el('figure', { id: 'drawing' });
    let notes = [];
    try {
      const d = CIP.drawing.drawing(r);
      figure.innerHTML = d.svg;
      notes = d.notes.map(x => x.text);
    } catch (e) { notes = ['Drawing not available: ' + e.message]; }
    const notesEl = notes.length ? [el('ul', { id: 'notes' }, ...notes.map(t => el('li', {}, t)))] : [];
    app.replaceChildren(nav(), el('h1', {}, r.name), facts(r), figure, ...notesEl, ...tables('Cartridge', r.cartridge), ...tables('Chamber', r.chamber),
      el('footer', { class: 'source' }, `Source: C.I.P. TDCC, revised ${dash(r.revised)}`));
  }

  function route() {
    const m = /^#\/cartridge\/(.+)$/.exec(location.hash);
    if (m) {
      let key = m[1];
      try { key = decodeURIComponent(key); } catch (e) { /* malformed escape: shown as not found */ }
      detailView(key);
    } else listView();
    window.scrollTo(0, 0);
  }

  window.addEventListener('hashchange', route);
  route();
})();
