// SVG drawing of one cartridge. 1 user unit = 1 mm; x = z (head left), y = ±r (upper half outside view, lower half section).
// Pure: returns the SVG string plus the label boxes and line segments the tests check.
(function (root) {
  const CIP = root.CIP = root.CIP || {};
  const node = typeof module !== 'undefined';
  const G = node ? require('./geometry.js') : CIP.geometry;
  const F = node ? require('./format.js') : CIP.format;

  const FS = 2.4;                 // label font size (mm)
  const CW = 0.66 * FS;           // estimated advance of one monospace character
  const LH = 1.25 * FS;           // label box height (ascent + descent of the font)
  const TIER = LH + 0.7;          // pitch of the flag rows above the part
  const PRINT_W = 186;            // A4 portrait content width (mm)
  const MIN_W = 100;              // narrower drawings are padded so short cartridges are not blown up
  const FONT = "ui-monospace, 'DejaVu Sans Mono', 'Liberation Mono', Menlo, Consolas, monospace";

  const n = v => String(+v.toFixed(3));
  const esc = s => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  const pts = a => a.map(p => n(p[0]) + ',' + n(p[1])).join(' ');
  const path = a => 'M' + a.map(p => n(p[0]) + ' ' + n(p[1])).join('L');

  function segHitsRect(s, r, pad) { // Liang-Barsky
    const [x1, y1, x2, y2] = s, dx = x2 - x1, dy = y2 - y1;
    let t0 = 0, t1 = 1;
    for (const [p, q] of [[-dx, x1 - (r.x - pad)], [dx, r.x + r.w + pad - x1], [-dy, y1 - (r.y - pad)], [dy, r.y + r.h + pad - y1]]) {
      if (p === 0) { if (q < 0) return false; } else { const t = q / p; if (p < 0) { if (t > t1) return false; if (t > t0) t0 = t; } else { if (t < t0) return false; if (t < t1) t1 = t; } }
    }
    return t0 <= t1;
  }
  const boxesHit = (a, b, pad) => a.x < b.x + b.w + pad && b.x < a.x + a.w + pad && a.y < b.y + b.h + pad && b.y < a.y + a.h + pad;

  function radiusAtZ(poly, z) { // largest radius of a [r,z] polyline at z
    let best = 0;
    for (let i = 1; i < poly.length; i++) {
      const [r0, z0] = poly[i - 1], [r1, z1] = poly[i];
      if (z < Math.min(z0, z1) - 1e-9 || z > Math.max(z0, z1) + 1e-9) continue;
      best = Math.max(best, z1 === z0 ? Math.max(r0, r1) : r0 + (r1 - r0) * (z - z0) / (z1 - z0));
    }
    return best;
  }

  function drawing(rec) {
    const g = G.build(rec), v = G.flat(rec), b = g.bullet, name = rec.name;
    const L3 = v.L3, L6 = v.L6, R = v.R, R1 = v.R1;
    const up = a => a.map(([r, z]) => [z, -r]), dn = a => a.map(([r, z]) => [z, r]);
    const rmax = Math.max(...g.outer.map(p => p[0]));
    const outline = [], lines = [], labels = [], body = [];
    const segs = (poly) => { for (let i = 1; i < poly.length; i++) outline.push([poly[i - 1][0], poly[i - 1][1], poly[i][0], poly[i][1]]); };

    // ---- part -------------------------------------------------------------------------------------------------
    const upperOuter = up(g.outer);
    const lowerOuter = dn([[g.pocket ? g.pocket.d / 2 : 0, 0], ...g.outer.slice(1)]);
    segs(upperOuter); segs(lowerOuter);
    const cut = [...(g.pocket ? [[0, g.pocket.depth], [g.pocket.d / 2, g.pocket.depth], [g.pocket.d / 2, 0]] : [[0, 0]]), ...g.outer.slice(1), ...g.inner.slice().reverse(), [0, g.w]];
    const cutXY = dn(cut);
    segs([...cutXY, cutXY[0]]);
    body.push(`<polygon class="cut" points="${pts(cutXY)}"/>`);
    if (b) {
      const r0 = radiusAtZ(b.outline, L3), lowerB = dn(b.outline), mouth = [[L3, -v.H2 / 2], [L3, -r0]];
      const exposedXY = [[L3, 0], ...up([[r0, L3], ...b.outline.filter(p => p[1] > L3 + 1e-9)])];
      segs(exposedXY); segs(lowerB); segs(mouth);
      body.push(`<polygon class="bulf" points="${pts(lowerB)}"/>`, `<polygon class="bulf" points="${pts(exposedXY)}"/>`,
        `<path class="bul" d="${path(lowerB)}"/>`, `<path class="bul" d="${path(exposedXY)}"/>`, `<path class="o" d="${path(mouth)}"/>`);
    }
    body.push(`<path id="outline" class="o" d="${path(upperOuter)}${path(lowerOuter)}"/>`);
    body.push(`<line class="axis" x1="-3" y1="0" x2="${n(L6 + 3)}" y2="0"/>`);

    // ---- dimension primitives -----------------------------------------------------------------------------------
    const dim = [];
    const arrow = (x, y, dx, dy) => { // tip at (x,y), pointing along (dx,dy)
      const L = 1.5, h = 0.42, bx = x - dx * L, by = y - dy * L;
      return `<path class="arrow" d="M${n(x)} ${n(y)}L${n(bx - dy * h)} ${n(by + dx * h)}L${n(bx + dy * h)} ${n(by - dx * h)}Z"/>`;
    };
    const line = (owner, cls, x1, y1, x2, y2) => { lines.push({ owner, x1, y1, x2, y2 }); dim.push(`<line class="${cls}" x1="${n(x1)}" y1="${n(y1)}" x2="${n(x2)}" y2="${n(y2)}"/>`); };
    const label = (id, text, box, anchor, baseline, x) => {
      labels.push({ id, text, x: box.x, y: box.y, w: box.w, h: box.h });
      dim.push(`<text class="dim" x="${n(x)}" y="${n(baseline)}" text-anchor="${anchor}">${esc(text)}</text>`);
    };
    const text = (id, val) => `${F.symbol(id)} ${F.value(val, id)}`;
    const wOf = t => t.length * CW;
    const ok = (...a) => a.every(Number.isFinite);

    // ---- lower side: R (left of head) and nested lengths ---------------------------------------------------------
    const yR = rmax + 3.0;
    let xMin = -3, xMax = L6 + 2, yBottom = rmax;
    const lengths = [];
    for (const [id, z, r] of [['L1', v.L1, v.P2 / 2], ['L2', v.L2, v.H1 / 2], ['L3', L3, v.H2 / 2], ['L6', L6, b ? b.meplat / 2 : 0]]) if (ok(z, r)) lengths.push({ id, z, r });
    const tierY = k => yR + 4.6 + k * 4.4;
    if (ok(R, R1)) {
      line('R', 'ext', R, R1 / 2 + 0.8, R, yR + 1.0);
      line('R', 'dim', -3, yR, R + 3, yR);
      dim.push(arrow(0, yR, 1, 0), arrow(R, yR, -1, 0));
      const t = text('R', R), w = wOf(t);
      label('R', t, { x: -3.6 - w, y: yR - LH / 2, w, h: LH }, 'end', yR + 0.35 * FS, -3.6);
      xMin = Math.min(xMin, -3.6 - w - 1);
    }
    lengths.forEach((d, k) => {
      const y = tierY(k);
      line(d.id, 'ext', d.z, d.r + 0.8, d.z, y + 1.0);
      line(d.id, 'dim', 0, y, d.z, y);
      dim.push(arrow(0, y, -1, 0), arrow(d.z, y, 1, 0));
      const t = text(d.id, v[d.id]), w = wOf(t), base = y - 1.0;
      label(d.id, t, { x: d.z / 2 - w / 2, y: base - 0.95 * FS, w, h: LH }, 'middle', base, d.z / 2);
    });
    if (lengths.length || ok(R, R1)) {
      const yLast = lengths.length ? tierY(lengths.length - 1) : yR;
      line('ext0', 'ext', 0, R1 / 2 + 0.8, 0, yLast + 1.0);
      yBottom = yLast + 1.0;
    }

    // ---- upper side: diameters and the shoulder angle as flags ---------------------------------------------------
    const flags = [];
    const dia = (id, z, r) => { if (ok(v[id], z, r)) flags.push({ id, text: text(id, v[id]), x: z, rTop: r, dia: true }); };
    dia('R1', R / 2, R1 / 2);
    if (g.groove) dia('E1', R + v.eMin / 2, v.E1 / 2);
    dia('P1', g.z0, v.P1 / 2);
    dia('P2', v.L1, v.P2 / 2);
    dia('H1', v.L2, v.H1 / 2);
    dia('H2', L3, v.H2 / 2);
    if (b) dia('G1', L3 + 0.5 * Math.min(Math.max(b.cylEnd - L3, 1), 3), v.G1 / 2);
    if (g.bottleneck) flags.push({ id: 'alpha', text: text('alpha', v.alpha), x: (v.L1 + v.L2) / 2, rTop: (v.P2 + v.H1) / 4, dia: false });
    const yTop = -rmax - 2.0;
    // Branch and bound over (side, tier) per flag: fewest rows first, then least total height. Collision checks are symmetric.
    const outlineTop = Math.min(...outline.map(s => Math.min(s[1], s[3])));
    const cands = flags.slice().sort((a, c) => a.x - c.x).map(f => {
      const w = wOf(f.text), out = [];
      for (let tier = 0; tier < 6; tier++) for (const side of ['right', 'left']) {
        const box = { x: side === 'right' ? f.x + 0.8 : f.x - 0.8 - w, y: yTop - tier * TIER - LH, w, h: LH };
        if (box.y + box.h + 0.3 < outlineTop || !outline.some(s => segHitsRect(s, box, 0.3))) out.push({ f, side, tier, box, lead: [f.x, -f.rTop, f.x, box.y] });
      }
      return out;
    });
    let best = null, bestScore = Infinity, budget = 300000;
    const search = (i, chosen, max, sum) => {
      if (max * 100 + sum >= bestScore || --budget < 0) return;
      if (i === cands.length) { best = chosen.slice(); bestScore = max * 100 + sum; return; }
      for (const c of cands[i]) {
        if (chosen.some(o => boxesHit(c.box, o.box, 0.5) || segHitsRect(c.lead, o.box, 0.4) || segHitsRect(o.lead, c.box, 0.4))) continue;
        chosen.push(c); search(i + 1, chosen, Math.max(max, c.tier), sum + c.tier); chosen.pop();
      }
    };
    search(0, [], 0, 0);
    if (!best) throw new Error('no free label slots for ' + name);
    let yMin = yTop - LH;
    for (const { f, box, side } of best) {
      line(f.id, 'ext', f.x, -f.rTop, f.x, box.y);
      if (f.dia) { line(f.id, 'dim', f.x, f.rTop, f.x, -f.rTop); dim.push(arrow(f.x, -f.rTop, 0, -1), arrow(f.x, f.rTop, 0, 1)); }
      else dim.push(arrow(f.x, -f.rTop, 0, 1));
      label(f.id, f.text, box, side === 'right' ? 'start' : 'end', box.y + LH - 0.3 * FS, side === 'right' ? box.x : box.x + box.w);
      yMin = Math.min(yMin, box.y); xMin = Math.min(xMin, box.x - 1); xMax = Math.max(xMax, box.x + box.w + 1);
    }

    // ---- title block and viewBox --------------------------------------------------------------------------------
    const tbLines = [`C.I.P. table ${rec.tab} · revised ${rec.revised}`, 'Dimensions in mm · Scale 0.00:1'];
    const tbW = Math.max(wOf(tbLines[0]), wOf(tbLines[1]), name.length * 1.35 * 1.4) + 4 + 16, tbH = 13.4;
    const tbY = yBottom + 3.0;
    const vbW = Math.max(xMax - xMin, tbW + 2, MIN_W), vbX = xMin - (vbW - (xMax - xMin)) / 2, vbY = yMin - 1.5, vbH = tbY + tbH + 1.5 - vbY;
    const scale = PRINT_W / vbW;
    const tbX = vbX + (vbW - tbW) / 2;
    const sbX = tbX + tbW - 14;
    const titleBlock = { x: tbX, y: tbY, w: tbW, h: tbH };
    const tb = `<g id="titleblock"><rect class="tb" x="${n(tbX)}" y="${n(tbY)}" width="${n(tbW)}" height="${tbH}"/>`
      + `<text class="tbt" x="${n(tbX + 2)}" y="${n(tbY + 4.5)}" font-size="3.4" font-weight="700">${esc(name)}</text>`
      + `<text class="tbt" x="${n(tbX + 2)}" y="${n(tbY + 8.3)}">${esc(tbLines[0])}</text>`
      + `<text class="tbt" x="${n(tbX + 2)}" y="${n(tbY + 11.6)}">Dimensions in mm · Scale ${scale.toFixed(2)}:1</text>`
      + `<g class="scalebar"><path d="M${n(sbX)} ${n(tbY + 6.6)}h10M${n(sbX)} ${n(tbY + 5.6)}v2M${n(sbX + 10)} ${n(tbY + 5.6)}v2"/>`
      + `<text class="tbt" x="${n(sbX + 5)}" y="${n(tbY + 4.6)}" text-anchor="middle">10 mm</text></g></g>`;

    const rules = `.o{fill:none;stroke:var(--outline,#111);stroke-width:.3;stroke-linejoin:round}`
      + `.cut{fill:url(#hatch);stroke:var(--outline,#111);stroke-width:.3;stroke-linejoin:round}.hl{stroke:var(--hatch,#666);stroke-width:.2}`
      + `.bulf{fill:var(--bullet-fill,#eee);stroke:none}.bul{fill:none;stroke:var(--bullet,#852);stroke-width:.25;stroke-linejoin:round}`
      + `.axis{stroke:var(--outline,#111);stroke-width:.15;stroke-dasharray:6 1.2 1 1.2}`
      + `.dim,.ext{stroke:var(--dim,#a33);stroke-width:.15}text.dim{fill:var(--dim,#a33);stroke:none}.arrow{fill:var(--dim,#a33)}`
      + `.tb{fill:none;stroke:var(--outline,#111);stroke-width:.25}.tbt{fill:var(--outline,#111)}.scalebar path{stroke:var(--outline,#111);stroke-width:.25;fill:none}`;
    const style = rules.replace(/(^|\})([^{}]+)\{/g, (m, c, sel) => c + sel.split(',').map(x => '.cip-drawing ' + x.trim()).join(',') + '{');
    const svg = `<svg xmlns="http://www.w3.org/2000/svg" class="cip-drawing" viewBox="${n(vbX)} ${n(vbY)} ${n(vbW)} ${n(vbH)}" role="img" aria-labelledby="drawing-title"`
      + ` preserveAspectRatio="xMidYMid meet" font-family="${FONT}" font-size="${FS}">`
      + `<title id="drawing-title">${esc(name)} drawing</title><style>${style}</style>`
      + `<defs><pattern id="hatch" width="0.8" height="0.8" patternUnits="userSpaceOnUse" patternTransform="rotate(45)"><line class="hl" x1="0" y1="0" x2="0" y2="0.8"/></pattern></defs>`
      + `<g id="part">${body.join('')}</g><g id="dimensions">${dim.join('')}</g>${tb}</svg>`;

    return {
      svg, labels, lines, outline, notes: g.notes, titleBlock, scale, viewBox: { x: vbX, y: vbY, w: vbW, h: vbH },
    };
  }

  CIP.drawing = { drawing };
  if (node) module.exports = CIP.drawing;
})(typeof window !== 'undefined' ? window : globalThis);
