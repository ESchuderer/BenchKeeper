// Formatting of published values, symbols, units, table sections and search. Pure; no DOM.
(function (root) {
  const CIP = root.CIP = root.CIP || {};

  const SYMBOLS = { eMin: 'e min', r1Min: 'r1 min', r1Max: 'r1 max', alpha: 'α', alpha1: 'α1', beta: 'β', delta: 'δ', deltaL: 'delta L', L3PlusG: 'L3 + G' };
  const ANGLES = new Set(['alpha', 'alpha1', 'beta', 'delta', 'i']);
  const UNITS = { Pmax: 'bar', PK: 'bar', PE: 'bar', EE: 'J', M: 'g', Q: 'mm²', N: '' };
  const TITLES = {
    caseHead: 'Case head', collar: 'Collar', junctionCone: 'Junction cone', lengths: 'Lengths', misc: 'Miscellaneous',
    powderChamber: 'Powder chamber', pressures: 'Pressures', projectile: 'Projectile',
    barrel: 'Barrel', breech: 'Breech', grooves: 'Grooves', rifling: 'Rifling',
  };

  const angle = a => typeof a === 'number' ? `${a}°` : `${a.degrees}°${a.minutes}'${a.seconds}"`;
  const value = (v, f) => typeof v === 'object' || ANGLES.has(f) ? angle(v) : String(v);
  const symbol = f => SYMBOLS[f] || f;
  const unit = f => ANGLES.has(f) ? '°' : f in UNITS ? UNITS[f] : 'mm';

  // Rows of one section; a <X>Tol field is merged into the value of X.
  function rows(section) {
    return Object.keys(section).filter(f => !(f.endsWith('Tol') && f.slice(0, -3) in section)).map(f => {
      const tol = section[f + 'Tol'];
      return { symbol: symbol(f), value: value(section[f], f) + (tol === undefined ? '' : ' ' + value(tol, f)), unit: unit(f) };
    });
  }

  const sections = group => Object.keys(group).filter(k => Object.keys(group[k]).length)
    .map(k => ({ key: k, title: TITLES[k] || k, rows: rows(group[k]) }));

  const matches = (rec, term) => {
    const t = term.trim().toLowerCase();
    return [rec.name, ...(rec.alternativeNames || [])].some(n => n.toLowerCase().includes(t));
  };

  CIP.format = { angle, value, symbol, unit, sections, matches };
  if (typeof module !== 'undefined') module.exports = CIP.format;
})(typeof window !== 'undefined' ? window : globalThis);
