// Cartridge geometry (brief rules 1-9). Pure: record in, points out. Points are [r, z]: radius, distance from the head face (mm).
(function (root) {
  const CIP = root.CIP = root.CIP || {};

  const node = typeof module !== 'undefined';
  const F = node ? require('./format.js') : CIP.format;
  const pub = v => v !== undefined && v !== null;
  const deg = a => typeof a === 'number' ? a : a.degrees + a.minutes / 60 + a.seconds / 3600;
  const rad = a => deg(a) * Math.PI / 180;
  const len = (a, b) => Math.hypot(b[0] - a[0], b[1] - a[1]);
  const flat = rec => Object.assign({}, ...Object.values(rec.cartridge));

  function rimType(rec) {
    if (rec.family === 'belted' || rec.family === 'rimfire') return rec.family;
    const v = flat(rec), ratio = v.R1 / v.P1;
    return ratio >= 1.05 ? 'rimmed' : ratio < 0.98 ? 'rebated' : 'rimless';
  }

  function arc(c, rho, t0, t1, n = 12) {
    return Array.from({ length: n + 1 }, (_, i) => { const t = t0 + (t1 - t0) * i / n; return [c[0] + rho * Math.cos(t), c[1] + rho * Math.sin(t)]; });
  }

  // Tangent arc of radius rho in the corner p1 between p0 and p2; null if it does not fit on the adjacent lines.
  function fillet(p0, p1, p2, rho) {
    const l1 = len(p1, p0), l2 = len(p1, p2);
    const u = [(p0[0] - p1[0]) / l1, (p0[1] - p1[1]) / l1], w = [(p2[0] - p1[0]) / l2, (p2[1] - p1[1]) / l2];
    const theta = Math.acos(Math.max(-1, Math.min(1, u[0] * w[0] + u[1] * w[1])));
    if (theta > Math.PI - 1e-9) return { t: 0, pts: [p1] }; // straight: nothing to round
    const t = rho / Math.tan(theta / 2);
    if (t > l1 || t > l2) return null;
    const bis = [u[0] + w[0], u[1] + w[1]], bl = Math.hypot(bis[0], bis[1]);
    const d = rho / Math.sin(theta / 2), c = [p1[0] + bis[0] / bl * d, p1[1] + bis[1] / bl * d];
    const a0 = Math.atan2(p1[1] + u[1] * t - c[1], p1[0] + u[0] * t - c[0]);
    let a1 = Math.atan2(p1[1] + w[1] * t - c[1], p1[0] + w[0] * t - c[0]);
    while (a1 - a0 > Math.PI) a1 -= 2 * Math.PI;
    while (a1 - a0 < -Math.PI) a1 += 2 * Math.PI;
    return { t, pts: arc(c, rho, a0, a1) };
  }

  const POCKET_D = { sp: 4.45, spm: 4.45, sr: 4.45, lp: 5.33, lpm: 5.33, lr: 5.33, lrm: 5.33 };
  const POCKET_H = { sp: 3.04, spm: 3.04, sr: 3.04, lp: 3.04, lpm: 3.04, lr: 3.3, lrm: 3.3 };

  function build(rec) {
    const v = flat(rec), rim = rimType(rec), belted = rim === 'belted';
    const notes = [];
    const note = (feature, missing, text) => notes.push({ feature, missing, text: text || `${feature} not drawn: ${missing.map(F.symbol).join(', ')} not published` });
    const lacking = (...f) => f.filter(x => !pub(v[x]));
    const { R1, R, P1, L3, L6, G1, H2 } = v;

    // Rules 2-3: head face, rim edge, groove -> body start.
    const outer = [[0, 0]];
    const add = (...ps) => ps.forEach(p => { const q = outer[outer.length - 1]; if (Math.abs(q[0] - p[0]) > 1e-9 || Math.abs(q[1] - p[1]) > 1e-9) outer.push(p); });
    if (rim === 'rimfire') {
      const rho = Math.min(R / 2, (R1 - P1) / 2), cr = R1 / 2 - rho;
      add([cr, 0], ...arc([cr, rho], rho, -Math.PI / 2, 0, 12), ...arc([cr, R - rho], rho, 0, Math.PI / 2, 12));
    } else {
      if (pub(v.beta) && pub(v.f) && deg(v.beta) < 90) add([R1 / 2 - Math.min(v.f * Math.tan(rad(v.beta)), R1 / 4), 0], [R1 / 2, v.f]);
      else { add([R1 / 2, 0]); if (lacking('beta', 'f').length) note('Chamfer', lacking('beta', 'f')); }
      add([R1 / 2, R]);
    }
    let z0 = R, groove = false, beltEnd = null;
    if (pub(v.E) && pub(v.E1) || rim === 'rimless' || rim === 'rebated' || belted) {
      const miss = [...lacking('E', 'E1', 'eMin'), ...(belted ? lacking('delta', 'R3') : [])];
      if (!miss.length) {
        add([v.E1 / 2, R], [v.E1 / 2, R + v.eMin]);
        if (belted) { beltEnd = R + v.eMin + (v.R3 / 2 - v.E1 / 2) / Math.tan(rad(v.delta)); add([v.R3 / 2, beltEnd], [v.R3 / 2, v.E]); }
        add([P1 / 2, v.E]);
        z0 = v.E; groove = true;
      } else note('Extractor groove', miss);
    }
    if (!groove) add([P1 / 2, R]);

    // Rules 4-6: body, shoulder, neck.
    const bottleneck = ['alpha', 'L1', 'L2', 'P2', 'H1'].every(f => pub(v[f]));
    const body = [P1 / 2, z0], mouth = [H2 / 2, L3];
    if (bottleneck) {
      const c1 = [v.P2 / 2, v.L1], c2 = [v.H1 / 2, v.L2];
      const shoulder = len(c1, c2);
      const round = (feature, key, p0, p1, p2) => {
        if (!pub(v[key])) { note(feature, [key]); return null; }
        const f = fillet(p0, p1, p2, v[key]);
        if (!f) note(feature, [], `${feature} not drawn: ${F.symbol(key)} does not fit`);
        return f;
      };
      const f1 = round('Body-side rounding', 'r1Min', body, c1, c2);
      let f2 = round('Neck-side rounding', 'r2', c1, c2, mouth);
      if (f1 && f2 && f1.t + f2.t > shoulder) { f2 = null; note('Neck-side rounding', [], `Neck-side rounding not drawn: ${F.symbol('r2')} does not fit`); }
      add(body, ...(f1 ? f1.pts : [c1]), ...(f2 ? f2.pts : [c2]), mouth);
    } else add(body, mouth);

    // Rule 7: bullet.
    const heeled = pub(H2) && pub(G1) && H2 - G1 <= 0.015;
    const shape = rec.annotations.defaultBulletShape, pistol = rec.annotations.category === 'pistol';
    const tn = (H2 - G1) / 2, tb = Math.min(Math.max(1.3 * (pub(G1) ? tn : 0), 0.6), 0.35 * P1 / 2), tnEff = heeled || !pub(G1) ? tb : tn;
    let bullet = null;
    const S = { pointy: 1.0, rounded: pistol ? 0.4 : 0.8, flat: pistol ? 0.4 : 0.8, semi_wadcutter: 0.6 }[shape];
    const K = { pointy: 0.40, rounded: pistol ? 0.65 : 0.55, flat: pistol ? 0.70 : 0.60, semi_wadcutter: 0.78 }[shape];
    const noBullet = [...lacking('G1', 'L3', 'L6', 'H2'), ...(S === undefined ? ['defaultBulletShape'] : [])];
    if (noBullet.length) note('Bullet', noBullet);
    else {
      const Dx = heeled ? H2 : G1, rs = Dx / 2, rseat = heeled ? H2 / 2 - tb : G1 / 2;
      const zb = L3 - S * G1, Lb = L6 - zb, zc = zb + K * Lb, n = L6 - zc;
      const m = { pointy: Math.max(0.08 * Dx, 1.27), rounded: 0.15 * Dx, flat: 0.55 * Dx, semi_wadcutter: 0.6 * Dx }[shape];
      const outline = [[0, zb], [rseat, zb]];
      if (heeled) outline.push([rseat, L3], [rs, L3]);
      outline.push([rs, zc]);
      let rho = null;
      const N = 24, d = rs - m / 2;
      if (shape === 'pointy') {
        rho = (d * d + n * n) / (2 * d);
        const phi = Math.atan2(n, rho - d);
        for (let i = 1; i < N; i++) { const a = phi * i / N; outline.push([rs - rho + rho * Math.cos(a), zc + rho * Math.sin(a)]); }
      } else if (shape === 'rounded') {
        for (let i = 1; i < N; i++) { const a = Math.PI / 2 * i / N; outline.push([m / 2 + d * Math.cos(a), zc + n * Math.sin(a)]); }
      }
      outline.push([m / 2, L6], [0, L6]);
      bullet = { shape, base: zb, cylEnd: zc, meplat: m, rho, shankRadius: rs, seatRadius: rseat, outline };
    }

    // Rule 8: walls, head, pocket, inner line.
    const pocket = rim === 'rimfire' || !POCKET_D[rec.annotations.primerType] ? null : { d: POCKET_D[rec.annotations.primerType], depth: POCKET_H[rec.annotations.primerType] };
    const w = Math.max(2.5, 0.25 * P1 / 2, pocket ? pocket.depth + 1.5 : 0, groove ? v.E + tb : 0, beltEnd !== null ? beltEnd + tb : 0);
    const rOuter = z => {
      for (let i = 1; i < outer.length; i++) { const [r0, za] = outer[i - 1], [r1, zb2] = outer[i]; if (zb2 > za && z > za && z <= zb2) return r0 + (r1 - r0) * (z - za) / (zb2 - za); }
      return outer[outer.length - 1][0];
    };
    const wallAt = z => bottleneck ? (z <= v.L1 ? tb : z >= v.L2 ? tnEff : tb + (tnEff - tb) * (z - v.L1) / (v.L2 - v.L1)) : (bullet && z >= bullet.base ? tnEff : tb);
    const inner = [[rOuter(w) - wallAt(w), w]];
    const zs = outer.map(p => p[1]).filter(z => z > w + 1e-9);
    const stepZ = !bottleneck && bullet && bullet.base > w && bullet.base < L3 ? bullet.base : null;
    if (stepZ !== null) zs.push(stepZ);
    zs.sort((a, b) => a - b);
    for (const z of zs.filter((z, i, a) => i === 0 || z !== a[i - 1])) {
      const r = rOuter(z);
      if (z === stepZ) inner.push([r - tb, z]);
      inner.push([r - (z === stepZ ? tnEff : wallAt(z)), z]);
    }
    return { rimType: rim, bottleneck, heeled, groove, outer, inner, w, tb, tn, pocket, bullet, notes, z0 };
  }

  CIP.geometry = { rimType, build, flat };
  if (node) module.exports = CIP.geometry;
})(typeof window !== 'undefined' ? window : globalThis);
