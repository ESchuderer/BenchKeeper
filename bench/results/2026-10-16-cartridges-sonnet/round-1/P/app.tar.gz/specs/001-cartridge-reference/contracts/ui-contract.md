# UI contract (relied on by tests)

- URL: `index.html` (list) ; `index.html#/cartridge/<key>` (detail); unknown key -> `Cartridge not found`.
- List: `h1` "Cartridges"; `input` labelled "Search"; `select` labelled "Family" (All, rimless, rimmed, belted, pistol, rimfire);
  text "<n> cartridges" (`#count`); table rows each with `a` (text = name, href `#/cartridge/<key>`), family, L3 (mm).
- Detail: `h1` = name; `dl#facts`; `svg[role=img]` with accessible name "<name> drawing" (`<title>`); `ul#notes` with "Not drawn: ..." items
  (absent when empty); tables `table.values` with `th` Symbol/Value/Unit under `h3` section captions inside `h2` "Cartridge" / "Chamber";
  `button` "Print" (calls `window.print()`), `a` "All cartridges" (`#/`).
- SVG: dimension labels are `<text class="dim">` with content `<symbol> <value>` (e.g. `L3 51.18`); title block `<g id="titleblock">`;
  outline `<path id="outline">`.
- No network: no `fetch`, `XMLHttpRequest`, remote `src`/`href` except the water-capacity source link (user click only).
