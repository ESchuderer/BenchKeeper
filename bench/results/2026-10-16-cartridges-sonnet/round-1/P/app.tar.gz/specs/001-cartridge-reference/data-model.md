# Data Model

**Record** (from `data/cartridges.js`): `key`, `name`, `alternativeNames?[]`, `family`, `tab`, `country`, `published`, `revised`,
`pressureMethod`, `annotations{category, primerType, defaultBulletShape, publishedCapacity?{grH2O, source, url, note?}}`,
`cartridge{section: {field: number|Angle}}`, `chamber{section: {field: number|Angle}}`.
`Angle = number | {degrees, minutes, seconds}`. Sections in `cartridge`: caseHead, collar, junctionCone, lengths, misc,
powderChamber, pressures, projectile. In `chamber`: barrel, breech, collar, grooves, junctionCone, lengths, powderChamber, rifling.

**Row** (derived by `CIP.format.sections(record.cartridge)`): `{symbol, value: string, unit: string}`; `<X>Tol` merged into X's value.

**Profile** (derived by `CIP.geometry.build(record)`):
```
{ rimType, bottleneck, heeled,
  outer: [[r,z]...],       // axis at head face -> mouth (upper half before mirroring)
  inner: [[r,z]...],       // section cavity line
  head:  {w, pocket|null},
  bullet:{base, tip, outline:[[r,z]...], seated:[[r,z]...], shape},
  marks: {...named points for dimensions},
  notes: ["r1 min is not published", ...] }
```

**Validation**: a field is *published* iff it is a finite number (or angle object). Missing -> `notes`, never a default.
