# Implementation Plan: C.I.P. Cartridge Reference

**Branch**: `main` | **Date**: 2026-10-16 | **Spec**: [spec.md](spec.md)

**Input**: Feature specification from `specs/001-cartridge-reference/spec.md`

## Summary

A static, dependency-free web app. Classic `<script>` files (no ES modules: Chromium blocks module
loading from `file://`) share one global namespace `CIP`. Pure logic (format, geometry, layout) is
unit-tested in Node via a UMD tail; UI, print and `file://` behaviour are tested in real Chromium
through Playwright (devDependency only).

## Technical Context

**Language/Version**: JavaScript (ES2022, classic scripts), HTML5, CSS3; Node 22 for tests

**Primary Dependencies**: none at runtime. Dev only: `playwright` (Chromium driver)

**Storage**: `data/cartridges.js` (`window.CARTRIDGES`), generated 1:1 from `data/cartridges.jsonl`

**Testing**: `node:test` (unit: `test/unit`), Playwright + `node:test` (UI: `test/ui`)

**Target Platform**: current Chromium, `file://` and any static server; phones to desktop

**Project Type**: static web app

**Performance Goals**: detail render < 50 ms; no layout work beyond one pass

**Constraints**: no network, no build, no module loading; 1 SVG unit = 1 mm; print = one A4 page

**Scale/Scope**: 25 records, 2 views

## Constitution Check

| Principle | Status |
|---|---|
| I Zero-dependency static app | PASS: classic scripts, no fetch/XHR, devDeps only |
| II Data fidelity | PASS: values rendered from records; data parity test; missing-value notes |
| III Test-first | PASS: tasks order tests before code; unit + real-Chromium UI tests |
| IV Accessible/responsive/printable | PASS: labelled controls, SVG `role=img` + `<title>`, media queries |
| V Simplicity | PASS: 4 JS files, 1 CSS, no abstraction beyond pure modules |

Re-checked after design: PASS (no violations to justify).

## Project Structure

### Documentation

```text
specs/001-cartridge-reference/
├── spec.md  plan.md  research.md  data-model.md  quickstart.md  tasks.md
├── contracts/ui-contract.md      # DOM/URL contract the UI tests rely on
└── checklists/requirements.md
```

### Source Code (repository root)

```text
index.html
css/app.css                 # screen (light/dark), mobile, @media print
js/format.js                # CIP.format: value/unit/angle/symbol/sections/search (pure)
js/geometry.js              # CIP.geometry: rim type, profile, bullet, walls, missing notes (pure)
js/drawing.js               # CIP.drawing: SVG string builder, dimensions, label layout (pure, returns string + boxes)
js/app.js                   # router, list view, detail view, print button
data/cartridges.js  data/cartridges.jsonl
test/unit/*.test.js         # format, geometry, drawing-layout, data parity
test/ui/*.test.js           # Playwright, file:// and static server
test/ui/browser.js          # launches Chromium (honours LD_LIBRARY_PATH)
package.json
```

**Structure Decision**: flat static layout; each JS file ends with
`if (typeof module !== 'undefined') module.exports = CIP.x` so Node tests `require` it.

## Design notes

- **Coordinates**: geometry works in `(r, z)` like the brief. The SVG maps `z → x`, and `r → y` with
  the axis at `y = 0`: upper half (outside view) is `y = -r`, lower half (section) is `y = +r`.
  1 user unit = 1 mm. viewBox is computed from outline + dimension area + title block.
- **Dimension layout**: dimension lines are stacked in tiers outside the outline (horizontal
  lengths above and below, diameters to the left/right as vertical dimensions), each label gets a
  bounding box (text width estimated from a fixed per-character advance of the chosen font size);
  a greedy placer shifts a label along its dimension line, then to the next tier, until it intersects
  neither earlier labels nor the outline polygon box. The same boxes are returned for the tests.
- **Missing values**: `geometry.profile()` returns `{outer, inner, bullet, notes[]}`; `notes` feeds the
  visible "Not drawn" list under the drawing.
- **Router**: `location.hash` `#/` and `#/cartridge/<key>`; `hashchange` re-renders; title updated.
- **Print**: `@page { size: A4 portrait; margin: 12mm }`, print CSS hides nav/controls, SVG `width: 100%`;
  tables use compact two-column flow so everything fits one page. Title-block scale = print width ÷ viewBox width.
- **Dev environment**: Chromium needs system libs not present in the container; they are extracted
  user-side to `~/chromelibs` and supplied by `LD_LIBRARY_PATH` (not part of the repo).

## Complexity Tracking

No constitution violations.
