# Quickstart / validation

```bash
npm install                      # dev only (playwright)
npx playwright install chromium  # once; in the container also needs the libs in ~/chromelibs:
export LD_LIBRARY_PATH=$HOME/chromelibs/root/usr/lib/x86_64-linux-gnu:$HOME/chromelibs/root/lib/x86_64-linux-gnu
npm test            # unit tests (no browser)
npm run test:ui     # Chromium: file://, search/filter, route reload, drawing overlap, print = 1 A4 page, dark, 360 px
```
Run the app: open `index.html` directly, or `python3 -m http.server` in the folder.
Expected: 25 cartridges; `#/cartridge/308_win` shows `L3 51.18`; all tests green.
