# Research

## R1 Module loading under `file://`
Decision: classic scripts + global namespace `CIP`, UMD-style tail for Node.
Rationale: Chromium refuses `<script type=module>` and `fetch` of local files from `file://` (CORS, origin `null`).
Alternatives: ES modules (fail on file://), inline everything in index.html (hard to test/maintain), JSON fetch (fails).

## R2 Data transport
Decision: `data/cartridges.js` assigns `window.CARTRIDGES`; `cartridges.jsonl` stays as the verbatim source; a unit test asserts equality.
Alternatives: only JS (loses the verbatim source), only JSONL (cannot load from file://).

## R3 Routing
Decision: hash routes `#/cartridge/<key>`. History API pushState fails on file://. Hash survives reload and bookmarks.

## R4 Tests
Decision: `node:test` for pure modules (zero dependency); Playwright (`playwright` package, Chromium) for UI, print PDF page count (`page.pdf` + PDF page counting by `/Type /Page` regex) and emulated media (`colorScheme: dark`, 360 px viewport, `file://`).
Alternatives: jsdom (no layout/print, would not prove the requirements).
Environment finding: the downloaded Chromium lacks system libs in this container (no root); resolved with user-space `.deb` extraction and `LD_LIBRARY_PATH`.

## R5 Label overlap
Decision: compute label boxes from font-size × per-character advance (monospace-ish tabular font stack; digits are fixed width with `font-variant-numeric: tabular-nums`) and verify in the browser with `getBBox()` against outline and each other.
Rationale: the layout is verified twice: pure estimate in Node, real measurement in Chromium.

## R6 Interpretation gaps in the brief
Resolved as spec Assumptions: body start, rimfire half-round centre, straight-case inner wall, missing-value note scope, angle formatting `d°m's"`, scale display.

## R7 Print scale
A4 content width 186 mm (12 mm margins); scale = 186 / viewBox width, shown as `N:1`; 10 mm scale bar for screens.
