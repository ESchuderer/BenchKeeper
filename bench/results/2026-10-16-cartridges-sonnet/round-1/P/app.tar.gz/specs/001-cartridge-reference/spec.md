# Feature Specification: C.I.P. Cartridge Reference

**Feature Branch**: `main` (single-feature project, no feature branch)

**Created**: 2026-10-16

**Status**: Draft

**Input**: User description: "Static web app: reference database of 25 C.I.P. cartridges (start page with search/family filter, detail view with scaled 2D SVG drawing, tables grouped by section, print to one A4 page)." The full, authoritative brief is `docs/brief.md`; the data is `data/cartridges.jsonl` (mirrored by `data/cartridges.js`). Where this spec and the brief differ, the brief wins and this spec is amended.

## User Scenarios & Testing *(mandatory)*

### User Story 1 - Find a cartridge (Priority: P1)

A reloader opens the app and sees the heading "Cartridges" with all 25 cartridges, each with name, family and case length L3. They type in "Search" or pick a "Family" and the list narrows live. They click a name to open it.

**Why this priority**: it is the entry point; without it nothing else is reachable.

**Independent Test**: open `index.html` from disk; 25 rows and "25 cartridges"; type `7,62 x 51` and see exactly "308 Win."; choose family "pistol" and see 6 rows.

**Acceptance Scenarios**:

1. **Given** the start page, **When** it loads, **Then** the heading "Cartridges", 25 rows (name link, family, L3) and the text "25 cartridges" are shown.
2. **Given** the start page, **When** the user types `7,62 x 51` into "Search", **Then** only "308 Win." is listed and the text reads "1 cartridges".
3. **Given** a search term, **When** it matches an alternative name (e.g. `30-06`), **Then** the cartridge is listed.
4. **Given** the select "Family", **When** the user picks "belted", **Then** only 300 Win. Mag. and 7 mm Rem. Mag. remain; "All" restores everything.
5. **Given** search and family are both set, **When** results are computed, **Then** both filters apply together; with no match the list is empty and says "0 cartridges".
6. **Given** a name link, **When** clicked, **Then** the detail view of that cartridge opens.

---

### User Story 2 - Read a cartridge's facts and values (Priority: P1)

A gunsmith opens a cartridge and reads its identity (alternative names, family, category, primer type, C.I.P. table, country, dates, pressure method, water capacity with source link) and every cartridge and chamber value in tables with "Symbol", "Value" and "Unit" columns, grouped by section. Tolerances sit beside their value. The address of the view can be bookmarked and survives a reload.

**Why this priority**: the values are the product.

**Independent Test**: open the detail of "308 Win.", compare the tables with the record; reload the page and see the same view.

**Acceptance Scenarios**:

1. **Given** a detail view, **Then** the heading is the exact `name` (e.g. `6,5 Creedmoor`).
2. **Given** "308 Win.", **Then** L1 is shown as `39.62 -0.2` in mm and Pmax as `4150` in bar; no row exists for `L1Tol`.
3. **Given** an angle given as `{degrees:39, minutes:59, seconds:49}`, **Then** it shows `39°59'49"`; a plain number 40 shows `40°`.
4. **Given** a cartridge with a published water capacity, **Then** the value (with unit) and a link to its source are shown; **Given** none, **Then** "not published" is shown.
5. **Given** a detail view, **When** the page is reloaded or the address is opened in a new tab, **Then** the same cartridge is shown, also when opened from disk.
6. **Given** an unknown address, **Then** a "Cartridge not found" message with a link "All cartridges" is shown.
7. **Given** the link "All cartridges", **When** clicked, **Then** the start page is shown.

---

### User Story 3 - See the true-scale drawing (Priority: P1)

An engineer sees a 2D drawing of the case with bullet: outside view above the axis, section below (hatched walls), centre line, dimension lines with labelled values, a title block, and a note listing anything not drawn because a value is missing.

**Why this priority**: the differentiating feature of the reference.

**Independent Test**: for each of the 25 records the drawing exists, its accessible name is "<name> drawing", its outline coordinates match the rules, labels do not overlap.

**Acceptance Scenarios**:

1. **Given** any detail view, **Then** one inline SVG with accessible name "<name> drawing" is shown; 1 user unit = 1 mm.
2. **Given** "308 Win.", **Then** the drawing shows the label `L3 51.18` on a dimension line with arrowheads and extension lines, and labels for L6, R1, R, P1, P2, H1, H2, G1, L1, L2, E1 and α (all published for this record).
3. **Given** "9 mm Luger" (no P2, H1, L1, L2, α), **Then** only the published dimensions are drawn and the case is straight.
4. **Given** "8,6 (mm) x 70" (no r1 min), **Then** the body-side shoulder corner is sharp and a note says "r1 min" is missing.
5. **Given** a belted, rimmed, rimfire, heeled (22 Long Rifle) cartridge, **Then** the profile follows rules 1–8 for that type.
6. **Given** a phone-width viewport, **Then** the drawing fits the width without horizontal scrolling.

---

### User Story 4 - Print a cartridge sheet (Priority: P2)

The user presses "Print"; the browser's print dialog opens with a one-page A4 portrait sheet: header with name, full-width drawing, tables, footer with source (C.I.P. TDCC, revised date). Black on white, no navigation, search or buttons.

**Why this priority**: valuable for workshop use but depends on P1.

**Independent Test**: print-to-PDF of three cartridges produces exactly one A4 page each.

**Acceptance Scenarios**:

1. **Given** a detail view, **When** "Print" is pressed, **Then** the print dialog opens.
2. **Given** print media (always light, even if the screen is dark), **Then** the sheet has header, drawing, tables, footer and none of: links bar, search, buttons.
3. **Given** every one of the 25 cartridges, **Then** the printed result is one A4 portrait page and every drawing label is legible (≥ 6 pt printed).

---

### User Story 5 - Comfortable technical reading (Priority: P2)

The app is dense, calm, with tabular numerals, follows the system light/dark setting on screen, and works on a phone.

**Independent Test**: emulate dark colour scheme and a 360 px viewport; no overflow, text contrast sufficient.

**Acceptance Scenarios**:

1. **Given** system dark mode, **Then** the screen uses a dark theme, **and** print remains light.
2. **Given** a 360 px wide viewport, **Then** lists, tables and drawing fit without horizontal page scroll.
3. **Given** keyboard only, **Then** search, family select, links and the Print button are reachable and have visible focus.

### Edge Cases

- Fields absent in some records (e.g. no `alternativeNames`, no `publishedCapacity`, empty `junctionCone`, no `L1`/`alpha`, no `E`/`E1`, no `beta`/`f`, no `r1Min`): shown as nothing in tables (no empty rows, empty sections omitted); identity rows show "—" or "not published"; drawing omits the feature.
- Records with fields not covered by a symbol rule use the field name as symbol (`L3PlusG` → "L3 + G").
- A tolerance field is never a row; a tolerance without its base value does not occur in the data.
- `i` may be a plain number or an angle object; `alpha1` likewise.
- Heeled case: `H2 - G1 <= 0.015` (22 Long Rifle).
- A shoulder rounding whose tangent length does not fit the adjacent line is not drawn and is reported like a missing value.
- Search with surrounding spaces or upper case still matches.
- Opening `index.html` from disk (no server) must not trigger any blocked request.

## Requirements *(mandatory)*

### Functional Requirements

**Data and formatting**

- **FR-001**: The app MUST show only the 25 supplied records, unmodified; no value is added, changed, rounded or fetched.
- **FR-002**: Numbers MUST be shown as published: decimal point, no thousands separator, no trailing `.0` for integral values (`4150`, `51.18`).
- **FR-003**: Units: mm for lengths and diameters (all fields not listed below, including `u`, `deltaL`, `Fe`, `G`, `s`, `h`, `b`, `r`, `S`, `F`, `Z`); bar for `Pmax`, `PK`, `PE`; J for `EE`; g for `M`; mm² for `Q`; none for `N`; ° for `alpha`, `alpha1`, `beta`, `delta`, `i`.
- **FR-004**: An angle is a number of degrees shown `40°`, or an object shown `d°m's"` (always all three parts, e.g. `39°59'49"`, `1°30'0"`).
- **FR-005**: A `<X>Tol` field MUST be shown in the Value cell of `X` as `<value> <tol>` (e.g. `39.62 -0.2`), never as its own row.
- **FR-006**: Symbols are the field name except: `eMin` "e min", `r1Min` "r1 min", `r1Max` "r1 max", `alpha` "α", `alpha1` "α1", `beta` "β", `delta` "δ", `deltaL` "delta L", `L3PlusG` "L3 + G".
- **FR-007**: Names (and alternative names) are shown exactly as in the record.

**Start page**

- **FR-010**: Start page: heading "Cartridges"; every cartridge with name, family, L3; each name is a link whose text is exactly the `name`.
- **FR-011**: A field labelled "Search" filters live by name and alternative names (case-insensitive substring, trimmed).
- **FR-012**: A select labelled "Family" with options All, rimless, rimmed, belted, pistol, rimfire filters by `family`; combined with search by AND.
- **FR-013**: The text "<n> cartridges" shows the number currently listed.

**Detail view and routing**

- **FR-020**: Detail view heading = `name`; then: alternative names, family, category, primer type, C.I.P. table (`tab`), country, published, revised, pressure method, water capacity (`grH2O` with a link to `url`, labelled with `source`).
- **FR-021**: Tables for all `cartridge` and all `chamber` values, grouped by their section, each with columns "Symbol", "Value", "Unit"; sections with no values are omitted.
- **FR-022**: A "Print" button and a link "All cartridges" to the start page.
- **FR-023**: Each detail view has its own address (hash route containing the record `key`) that survives reload and bookmarking, from `file://` and from a static server. Unknown address → "Cartridge not found" with the link "All cartridges".

**Drawing** (all numbers in mm; the coordinate pair `(r, z)` is radius, then distance from the head face, as in the brief)

- **FR-030**: An inline SVG, 1 user unit = 1 mm, axis horizontal, head left, accessible name "<name> drawing"; upper half outside view, lower half section with hatched cut walls; dash-dot centre line.
- **FR-031**: Dimension lines with arrowheads and extension lines for L3, L6, R1, R, P1 and, where published, P2, H1, H2, G1, L1, L2, E1 and the shoulder angle α; each labelled `<symbol> <value>` (e.g. `L3 51.18`). Labels MUST NOT overlap each other or the outline.
- **FR-032**: Title block: name, C.I.P. table, revision date, "Dimensions in mm", scale.
- **FR-033**: The drawing scales to viewport width (phone) and prints legibly.
- **FR-034**: Geometry: the outer half-profile is a list of points from the axis at the head face to the mouth, mirrored at the axis. Rules:
  1. **Rim type**: `belted` family → belted; `rimfire` → rimfire; else R1/P1 ≥ 1.05 rimmed; < 0.98 rebated; otherwise rimless.
  2. **Head face/rim edge** from (0,0): where β and f are published and β < 90°, chamfer `(R1/2 − min(f·tanβ, R1/4), 0)` → `(R1/2, f)` then `(R1/2, R)`. Rimfire: half-round of radius `min(R/2, (R1−P1)/2)` with its outermost point at R1/2. Else square corner.
  3. **Extractor groove**, where E and E1 are published: `(R1/2,R)` → `(E1/2,R)` → `(E1/2, R+e min)` → straight ramp to `(P1/2, E)`. Belted: from the floor end ramp out at angle δ to the axis up to `R3/2`, follow the belt to `z = E`, step in to `P1/2`. Without groove: step in from `(R1/2,R)` to `(P1/2,R)`.
  4. **Body**: straight from `P1/2` at the body start to `(P2/2, L1)` (bottleneck); a case without α, L1 or L2 is straight and runs to `(H2/2, L3)`.
  5. **Shoulder**: `(P2/2,L1)` → `(H1/2,L2)`; α is the included cone angle, the line lies at α/2 to the axis; drawn through the published points; labelled α. Round the body-side corner with r1 min and the neck-side corner with r2 where published.
  6. **Neck**: `(H1/2,L2)` → `(H2/2,L3)`, then the mouth face.
  7. **Bullet** from mouth to tip at `z = L6`, shank diameter G1, shape from `annotations.defaultBulletShape` (pointy, rounded, flat, semi_wadcutter), with seating depth s, cylinder fraction k, meplat m, ogive/ellipse/cone nose and heeled-case handling exactly as in `docs/brief.md` rule 7. The outside view hides the seated part; the section shows it inside the case.
  8. **Section walls**: `tn = (H2 − G1)/2`; `tb = min(max(1.3·tn, 0.6), 0.35·P1/2)`; inner line at tb along the body, tn along the neck, blended linearly across the shoulder; solid head from z = 0 to `w = max(2.5, 0.25·P1/2, pocket depth + 1.5, E + tb where a groove exists, belt ramp end + tb on belted cases)`; primer pocket on centrefire cases: Ø 4.45 for sp/spm/sr, Ø 5.33 for lp/lpm/lr/lrm; depth 3.04 for sp/spm/sr/lp/lpm, 3.3 for lr/lrm; none on rimfire.
  9. **Missing values**: if a value a rule needs is missing, the drawing omits that feature and a visible note under the drawing names the missing value; no number is ever invented.
- **FR-035**: The note of FR-034.9 is generated for these skipped features only: chamfer (β or f), extractor groove on rimless/rebated/belted cases (E, E1, and e min, δ, R3 as needed), body-side rounding (r1 min), neck-side rounding (r2), and any rounding that does not fit.

**Print**

- **FR-040**: "Print" calls the browser print dialog. Print output: one A4 portrait page, black on white, header with name, drawing at full width with all labels legible, then the tables, footer "Source: C.I.P. TDCC, revised <revised>"; no navigation, search or buttons.

**Look and feel / technology**

- **FR-050**: Dense technical typography, tabular numerals; light/dark on screen from the system setting; print always light; usable at 360 px width.
- **FR-051**: Plain HTML/CSS/JS, no framework, build step, runtime dependency or network request; `index.html` in the root with its CSS/JS; works from `file://` in Chromium and from any static server.
- **FR-052**: Interface language is English; controls have accessible labels; focus is visible.

### Key Entities

- **Cartridge record**: identity (`key`, `name`, `alternativeNames`, `family`, `tab`, `country`, `published`, `revised`, `pressureMethod`), `annotations` (category, primer type, default bullet shape, published capacity), `cartridge` values and `chamber` values, each in named sections.
- **Section**: a named group of fields (e.g. caseHead, lengths, pressures; barrel, breech, grooves, rifling).
- **Profile**: the computed outer half-profile points, section lines, bullet outline and the list of not-drawn features of one cartridge.

## Success Criteria *(mandatory)*

### Measurable Outcomes

- **SC-001**: A user finds any of the 25 cartridges by name or alternative name in one typed term and one click.
- **SC-002**: Every value shown equals the record's value for all 25 cartridges (automated comparison, 0 differences).
- **SC-003**: For all 25 cartridges the drawing is produced, has 0 label–label and 0 label–outline overlaps, and its outline matches the rules (automated geometric checks).
- **SC-004**: All 25 detail views print as exactly one A4 portrait page.
- **SC-005**: The app opens and works fully from `file://` in Chromium with zero network requests and zero console errors.
- **SC-006**: At 360 px width no view scrolls horizontally.

## Assumptions

- Hash routing (`#/cartridge/<key>`) is used because it survives reload under `file://`.
- Because Chromium blocks reading local files by script under `file://`, the data is loaded through a `<script>` file; `data/cartridges.jsonl` stays as the verbatim source and a test keeps both identical.
- The body starts at `z = E` where a groove exists (rimless, rebated, belted), otherwise at `z = R`.
- Rimfire rim edge, radius ρ = `min(R/2, (R1−P1)/2)`: flat head face to `(R1/2 − ρ, 0)`, quarter round (centre `(R1/2 − ρ, ρ)`) to `(R1/2, ρ)`, straight to `(R1/2, R − ρ)`, quarter round to `(R1/2 − ρ, R)`; it is a true half-round when ρ = R/2 (all three rimfire records). The rim then steps in to `P1/2` at z = R.
- A groove needs E, E1 and e min (and δ and R3 on belted cases); if one is missing it is not drawn and the note names it. When E and E1 are published the groove is drawn on any rim type; a missing-value note is only produced for rimless, rebated and belted cases.
- Where the body and the solid head meet, a belted case has `w ≥ E + tb`, so the head covers the belt.
- Straight cases have no neck/body distinction: the inner wall is tb up to the bullet base `zb`, and tn (the neck wall) from `zb` to the mouth, so the seated bullet exactly fills the bore. For heeled cases the wall is tb throughout (tn is ~0).
- Water capacity is shown in grains H2O as published (`grH2O`), with a note if given.
- Printed scale in the title block is computed from the print width of the drawing (full A4 content width), and a 10 mm scale bar makes the true scale readable on any screen.
- Search is a case-insensitive substring match; it does not persist in the address.
- The word "cartridges" in the count is not pluralised ("1 cartridges"), as in the brief.
- Out of scope: units conversion, editing data, comparison view, external fetching, i18n.
