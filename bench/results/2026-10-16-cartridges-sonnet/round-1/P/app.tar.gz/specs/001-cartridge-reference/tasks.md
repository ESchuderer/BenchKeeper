---

description: "Task list for the C.I.P. cartridge reference"
---

# Tasks: C.I.P. Cartridge Reference

**Input**: `specs/001-cartridge-reference/` (plan.md, spec.md, research.md, data-model.md, contracts/ui-contract.md)

**Tests**: REQUIRED (constitution III). Every test task is written and seen failing before the implementation tasks that follow it in the same phase.

**Format**: `- [ ] T### [P?] [US?] description with file path`. Run tests with
`export LD_LIBRARY_PATH=$HOME/chromelibs/root/usr/lib/x86_64-linux-gnu:$HOME/chromelibs/root/lib/x86_64-linux-gnu` for UI tests.

## Phase 1: Setup

- [X] T001 `package.json` (devDependency `playwright`, scripts `test`, `test:ui`), `.gitignore`, Chromium installed and launchable (done during planning)
- [X] T002 [P] `data/cartridges.jsonl` verbatim and `data/cartridges.js` generated from it
- [X] T003 [P] Create `test/ui/browser.js`: launch Chromium, helper `openFile(hash)` for `file:///work/index.html` and a tiny static server helper (Node `http`) for server-mode tests

## Phase 2: Foundational (blocks all stories)

- [X] T004 Test first: `test/unit/data.test.js`: 25 records, unique keys, `data/cartridges.js` equals `data/cartridges.jsonl` record by record, family counts rimless 12/rimmed 2/belted 2/pistol 6/rimfire 3
- [X] T005 Test first: `test/unit/format.test.js`: `value()` -> `51.18`, `4150`, `25`; angle `40°`, `39°59'49"`, `1°30'0"`; tolerance merge `39.62 -0.2`; symbols (`eMin`→"e min", `r1Min`, `r1Max`, `alpha`→"α", `alpha1`→"α1", `beta`→"β", `delta`→"δ", `deltaL`→"delta L", `L3PlusG`→"L3 + G"); units (mm default, bar for Pmax/PK/PE, J for EE, g for M, mm² for Q, none for N, ° for angles); `sections()` omits `*Tol` rows and empty sections; `matches(record, term)` finds `7,62 x 51` -> 308 Win., `30-06`, case-insensitive, trimmed
- [X] T006 Implement `js/format.js` (namespace `CIP.format`, UMD tail) until T004–T005 pass

## Phase 3: User Story 1 - Find a cartridge (P1) 🎯 MVP

**Independent test**: `index.html` from disk lists 25 cartridges and filters.

- [X] T007 [P] [US1] Test first: `test/ui/list.test.js` (Chromium, `file://`): heading "Cartridges"; 25 rows with link text = name, family, L3; "25 cartridges"; Search `7,62 x 51` -> only "308 Win." and "1 cartridges"; Family "belted" -> 2; combined filters; empty -> "0 cartridges"; fields found by accessible label "Search"/"Family"; no failed or external requests, no console errors
- [X] T008 [US1] Create `index.html` (head, `<main id="app">`, script tags in order: data, format, geometry, drawing, app) and `css/app.css` (base, light/dark variables via `prefers-color-scheme`, tabular numerals, list table, 360 px layout)
- [X] T009 [US1] Implement list view and hash router skeleton in `js/app.js` (`#/` list; `hashchange`; filters wired to `CIP.format.matches`)

## Phase 4: User Story 2 - Facts and values (P1)

**Independent test**: detail view for every record shows correct facts and tables; reload works.

- [X] T010 [P] [US2] Test first: `test/ui/detail.test.js`: `#/cartridge/308_win` heading "308 Win."; facts rows (alt names, family, category, primer type, C.I.P. table, country, published, revised, pressure method, water capacity with link text source and href url); table "Symbol/Value/Unit"; `L1` cell `39.62 -0.2`; no `L1Tol` row; Pmax `4150` bar; reload keeps view; new page with same URL works from `file://` and via static server; unknown key -> "Cartridge not found" + "All cartridges" link; "6,5 Creedmoor" heading exact; record without capacity shows "not published"; for all 25 records every non-Tol numeric value of the record appears in a table row (data fidelity)
- [X] T011 [US2] Implement detail view in `js/app.js`: facts `dl#facts`, "Cartridge" and "Chamber" sections from `CIP.format.sections`, link "All cartridges", button "Print" (`window.print()`), not-found view, `document.title`
- [X] T012 [US2] Style facts and tables in `css/app.css` (dense, tabular-nums, 360 px fit)

## Phase 5: User Story 3 - Drawing (P1)

**Independent test**: all 25 drawings satisfy geometry rules and have no label overlap.

- [X] T013 [P] [US3] Test first: `test/unit/geometry.test.js` covering rules 1–9 on real records: rim types (223 Rem. rimless, 7 x 65 R rimmed, 300 Win. Mag. belted, 22 LR rimfire, 38 Special rimmed although family pistol); chamfer points `(R1/2 − min(f·tanβ, R1/4), 0)`→`(R1/2, f)`; rimfire half-round radius `min(R/2,(R1−P1)/2)` outermost at R1/2; groove points for 308 Win. (E/E1/eMin ramp to `(P1/2, E)`); belt ramp at δ to `R3/2`, belt to `z=E`, step to `P1/2`; no-groove step at `z=R`; body to `(P2/2, L1)`; straight case runs to `(H2/2, L3)`; shoulder through published points; r1 min / r2 rounding tangent to both lines; bullet: seating depth, base `zb`, `Lb`, k per shape/category, meplat m, tangent-ogive ρ formula and tip at `(m/2, L6)`, heeled 22 LR exposed Ø = H2 and heel Ø `H2 − 2·tb`; walls tn/tb/w and pocket Ø/depth per primer type (none on rimfire); missing-value notes exactly: 8,6 (mm) x 70 → r1 min, 17 HMR → r1 min and r2, none for others; no NaN anywhere for all 25 records; every r1 min or r2 rounding for all 25 records is either tangent to both adjacent lines or listed in `notes`; profile monotone in z and outline never self-crossing; mirrored half-profile symmetric
- [X] T014 [US3] Implement `js/geometry.js` (`CIP.geometry`: `rimType`, `build(record)` → `{outer, inner, head, bullet, marks, notes, ...}`) until T013 passes
- [X] T015 [P] [US3] Test first: `test/unit/drawing.test.js`: SVG string for all 25 records is well-formed; `<title>` = "<name> drawing"; `role="img"`; viewBox in mm; label list contains `L3 51.18` for 308 Win., has L3/L6/R1/R/P1 for all, P2/H1/H2/G1/L1/L2/E1/α only where published; `α 40°`; boxes returned by layout: no label–label and no label–outline-box intersections for all 25; dash-dot centre line, hatch pattern, title block texts (name, C.I.P. table, revision date, "Dimensions in mm", scale `N:1`), arrowheads and extension lines present
- [X] T016 [US3] Implement `js/drawing.js` (`CIP.drawing.svg(record)` → `{svg, labels, notes}`): outer + mirrored outline, section inner line, hatched walls and head, primer pocket, bullet (outside view hides seated part; section shows it), centre line, dimensions with tiered layout and greedy label placement, title block, 10 mm scale bar, notes
- [X] T017 [P] [US3] Test first: `test/ui/drawing.test.js` (Chromium): SVG accessible name; every `text.dim` bounding box (via `getBBox`) overlaps no other label and not the `#outline` path bounding geometry sample (point-in-stroke check along the path); drawing width equals container width at 360 px and at 1280 px; no horizontal page scroll at 360 px; "Not drawn" note visible for "8,6 (mm) x 70" naming `r1 min`; screenshots of 3 cartridges saved to `test-results/` for visual review
- [X] T018 [US3] Integrate drawing and "Not drawn" list in the detail view (`js/app.js`), styles in `css/app.css`; iterate on layout until T015 and T017 pass; review screenshots visually

## Phase 6: User Story 4 - Print (P2)

- [X] T019 [P] [US4] Test first: `test/ui/print.test.js`: `page.pdf({preferCSSPageSize:true})` of every one of the 25 detail views has exactly 1 page and A4 portrait size (595×842 pt ±2); emulated print media: nav/search/buttons/links bar not displayed, header with name, footer text "C.I.P. TDCC" and revised date visible, background white and text black even with `colorScheme: dark`; drawing width ≥ 95% of the content width; smallest SVG font printed ≥ 6 pt (font-size × scale); clicking "Print" calls `window.print` (stubbed)
- [X] T020 [US4] `@media print` and `@page` in `css/app.css`; page header/footer elements in `js/app.js`; compact two-column table flow so all 25 fit one page; scale in title block matches print width

## Phase 7: User Story 5 - Look and feel (P2)

- [X] T021 [P] [US5] Test first: `test/ui/look.test.js`: `colorScheme: dark` -> dark body background and sufficient contrast (WCAG ratio ≥ 4.5 for body text computed from computed styles), `light` -> light; tabular-nums on value cells; keyboard Tab reaches Search, Family, first link, Print with visible focus outline; 360×640 viewport no horizontal overflow on list and 3 detail views
- [X] T022 [US5] Tune `css/app.css` until T021 passes (focus styles, colour tokens for both schemes, dark SVG colours via CSS variables inside the SVG)

## Phase 8: Polish

- [X] T023 [P] Run all tests, view screenshots of all 25 drawings in a contact sheet (belted, rimmed, rimfire, heeled, pistol, bottleneck) and fix visible defects (collisions, odd fillets)
- [X] T024 [P] Verify zero network requests from `file://` (Playwright `request` events) and zero console errors across all routes; serve with `python3 -m http.server` and repeat T007/T010 in server mode
- [X] T025 README.md (how to open, test, data source, geometry assumptions) — short
- [X] T026 Review (`/code-review`, `/simplify`) and fix findings

## Dependencies

Setup → Foundational → US1 → US2 → US3 → US4 → US5 → Polish. US2 needs US1's router; US3 needs US2's detail view; US4/US5 need US3's drawing. T013/T015/T017 (tests) may be written in parallel; implementation tasks within a phase are sequential.

## Parallel examples

- T004, T005 together (different files); T007 with T010 (UI test files); T013, T015 and T017 together before any drawing implementation.

## Implementation strategy

MVP = Phase 1–4 (list + detail values, no drawing); then the drawing (the hard part), then print, then polish. Commit after each phase with tests green.
