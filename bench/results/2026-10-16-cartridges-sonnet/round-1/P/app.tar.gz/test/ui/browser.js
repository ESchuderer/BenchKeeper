// Launches Chromium for UI tests. Needs LD_LIBRARY_PATH to point at the user-space libs in this container (see quickstart.md).
const { chromium } = require('playwright');
const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');

const ROOT = path.resolve(__dirname, '../..');
const FILE_URL = 'file://' + ROOT + '/index.html';
const TYPES = { '.html': 'text/html', '.js': 'text/javascript', '.css': 'text/css' };

// In this container the system libs live in ~/chromelibs (no root); elsewhere LD_LIBRARY_PATH is left alone.
function libEnv() {
  const base = path.join(require('node:os').homedir(), 'chromelibs/root');
  if (!fs.existsSync(base)) return process.env;
  const extra = [base + '/usr/lib/x86_64-linux-gnu', base + '/lib/x86_64-linux-gnu'].join(':');
  return { ...process.env, FONTCONFIG_FILE: path.join(base, '../fonts.conf'), LD_LIBRARY_PATH: extra + (process.env.LD_LIBRARY_PATH ? ':' + process.env.LD_LIBRARY_PATH : '') };
}

async function launch() { return chromium.launch({ env: libEnv() }); }

// Tiny static server so every UI test can also run in "served" mode.
function serve() {
  const server = http.createServer((req, res) => {
    const p = path.join(ROOT, decodeURIComponent(req.url.split('?')[0]).replace(/\/$/, '/index.html'));
    if (!p.startsWith(ROOT) || !fs.existsSync(p) || fs.statSync(p).isDirectory()) { res.writeHead(404).end(); return; }
    res.writeHead(200, { 'content-type': TYPES[path.extname(p)] || 'application/octet-stream' }).end(fs.readFileSync(p));
  });
  return new Promise(r => server.listen(0, '127.0.0.1', () => r({ url: `http://127.0.0.1:${server.address().port}/index.html`, close: () => server.close() })));
}

// Opens `base + hash`, collecting console errors and non-local requests.
async function open(browser, base, hash = '', ctxOpts = {}) {
  const context = await browser.newContext(ctxOpts);
  const page = await context.newPage();
  page.problems = [];
  page.on('console', m => { if (m.type() === 'error') page.problems.push('console: ' + m.text()); });
  page.on('pageerror', e => page.problems.push('pageerror: ' + e.message));
  page.on('request', r => { if (!/^(file|http:\/\/127\.0\.0\.1)/.test(r.url())) page.problems.push('request: ' + r.url()); });
  await page.goto(base + hash);
  return page;
}

const records = fs.readFileSync(path.join(ROOT, 'data/cartridges.jsonl'), 'utf8').trim().split('\n').map(l => JSON.parse(l));

module.exports = { launch, serve, open, FILE_URL, ROOT, records };
