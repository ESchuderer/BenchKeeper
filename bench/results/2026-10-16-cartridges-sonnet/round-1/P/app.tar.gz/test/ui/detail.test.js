const test = require('node:test');
const assert = require('node:assert/strict');
const B = require('./browser');

const { records } = B;
let browser, srv;
test.before(async () => { browser = await B.launch(); srv = await B.serve(); });
test.after(async () => { await browser.close(); srv.close(); });

const cellTexts = page => page.locator('table.values td').allInnerTexts();
const fact = async (page, label) => (await page.locator('#facts dt', { hasText: new RegExp('^' + label + '$') }).locator('xpath=following-sibling::dd[1]').innerText()).trim();

for (const mode of ['file', 'served']) {
  const base = () => mode === 'file' ? B.FILE_URL : srv.url;

  test(`[${mode}] detail of 308 Win.: facts, tables, reload`, async () => {
    const page = await B.open(browser, base(), '#/cartridge/308_win');
    assert.equal(await page.locator('h1').innerText(), '308 Win.');
    assert.equal(await fact(page, 'Alternative names'), '308 Winchester, 7,62 x 51');
    assert.equal(await fact(page, 'Family'), 'rimless');
    assert.equal(await fact(page, 'Category'), 'rifle');
    assert.equal(await fact(page, 'Primer type'), 'lr');
    assert.equal(await fact(page, 'C.I.P. table'), 'I');
    assert.equal(await fact(page, 'Country'), 'US');
    assert.equal(await fact(page, 'Published'), '1984-06-14');
    assert.equal(await fact(page, 'Revised'), '2008-09-23');
    assert.equal(await fact(page, 'Pressure method'), 'Transducer');
    assert.match(await fact(page, 'Water capacity'), /^56 gr H2O/);
    const link = page.locator('#facts a');
    assert.equal(await link.innerText(), 'kwk');
    assert.equal(await link.getAttribute('href'), 'http://kwk.us/cases.html');

    assert.deepEqual(await page.locator('table.values').first().locator('th').allInnerTexts(), ['Symbol', 'Value', 'Unit']);
    const row = (sym) => page.locator('table.values tr', { has: page.locator('td:first-child', { hasText: new RegExp('^' + sym + '$') }) });
    assert.deepEqual(await row('L1').first().locator('td').allInnerTexts(), ['L1', '39.62 -0.2', 'mm']);
    assert.deepEqual(await row('Pmax').first().locator('td').allInnerTexts(), ['Pmax', '4150', 'bar']);
    assert.ok(!(await page.locator('table.values td:first-child').allInnerTexts()).some(t => /Tol/.test(t)));
    assert.deepEqual(await page.locator('h2').allInnerTexts(), ['Cartridge', 'Chamber']);

    await page.reload();
    assert.equal(await page.locator('h1').innerText(), '308 Win.');
    assert.deepEqual(page.problems, []);
  });

  test(`[${mode}] navigation, bookmarks, not found`, async () => {
    const page = await B.open(browser, base(), '#/cartridge/6_5_creedmoor');
    assert.equal(await page.locator('h1').innerText(), '6,5 Creedmoor');
    assert.match(await page.title(), /6,5 Creedmoor/);
    assert.equal(await page.getByRole('button', { name: 'Print' }).count(), 1);
    await page.getByRole('link', { name: 'All cartridges' }).click();
    await page.getByRole('heading', { name: 'Cartridges', exact: true }).waitFor();
    assert.equal(await page.locator('tbody tr').count(), 25);
    await page.goto(base() + '#/cartridge/nope');
    await page.reload();
    assert.match(await page.locator('main').innerText(), /Cartridge not found/);
    await page.getByRole('link', { name: 'All cartridges' }).click();
    await page.getByRole('heading', { name: 'Cartridges', exact: true }).waitFor();
  });

  test(`[${mode}] a malformed address shows the not-found view instead of breaking`, async () => {
    const page = await B.open(browser, base(), '#/cartridge/308_win');
    await page.goto(base() + '#/cartridge/%E0%A4%A');
    assert.match(await page.locator('main').innerText(), /Cartridge not found/);
    await page.getByRole('link', { name: 'All cartridges' }).click();
    await page.getByRole('heading', { name: 'Cartridges', exact: true }).waitFor();
    assert.deepEqual(page.problems.filter(p => !/URI|Failed/.test(p)), []);
  });

  test(`[${mode}] angles, missing capacity and identity of a cartridge without alternatives`, async () => {
    const page = await B.open(browser, base(), '#/cartridge/7_x_64');
    assert.equal(await fact(page, 'Water capacity'), 'not published');
    assert.equal(await fact(page, 'Alternative names'), '—');
    const cells = await cellTexts(page);
    assert.ok(cells.includes(`36°52'12"`), 'delta as d°m\'s"');
    assert.ok(cells.includes('45°'), 'beta 45°');
    assert.ok(cells.includes(`40°25'44"`));
  });
}

test('every published value of every record is in its tables', async () => {
  const page = await B.open(browser, B.FILE_URL, '#/');
  for (const r of records) {
    await page.goto(B.FILE_URL + '#/cartridge/' + r.key);
    assert.equal(await page.locator('h1').innerText(), r.name);
    const cells = new Set(await cellTexts(page));
    const missing = [];
    for (const group of ['cartridge', 'chamber']) {
      for (const [sec, fields] of Object.entries(r[group])) {
        for (const [f, v] of Object.entries(fields)) {
          if (f.endsWith('Tol')) continue;
          const tol = fields[f + 'Tol'];
          let want = typeof v === 'object' ? `${v.degrees}°${v.minutes}'${v.seconds}"` : String(v);
          if (['alpha', 'alpha1', 'beta', 'delta', 'i'].includes(f) && typeof v === 'number') want += '°';
          if (tol !== undefined) want += ' ' + tol;
          if (!cells.has(want)) missing.push(`${group}.${sec}.${f}=${want}`);
        }
      }
    }
    assert.deepEqual(missing, [], r.name);
  }
  assert.deepEqual(page.problems, []);
});
