const test = require('node:test');
const assert = require('node:assert/strict');
const path = require('node:path');
const B = require('./browser');

const { records } = B;
let browser;
test.before(async () => { browser = await B.launch(); });
test.after(async () => { await browser.close(); });

// Measures every text.dim with the browser's own text layout and samples all drawn outlines.
const measure = () => {
  const svg = document.querySelector('figure svg');
  const texts = [...svg.querySelectorAll('text.dim')].map(t => { const b = t.getBBox(); return { text: t.textContent, x: b.x, y: b.y, w: b.width, h: b.height }; });
  const pts = [];
  for (const p of svg.querySelectorAll('#part path.o, #part path.bul, #part polygon.cut')) {
    if (p.tagName === 'polygon') { const a = p.points; for (let i = 0; i < a.numberOfItems; i++) pts.push([a.getItem(i).x, a.getItem(i).y]); continue; }
    const len = p.getTotalLength();
    for (let s = 0; s <= len; s += 0.15) { const q = p.getPointAtLength(s); pts.push([q.x, q.y]); }
  }
  return { texts, pts, vb: svg.viewBox.baseVal && { x: svg.viewBox.baseVal.x, y: svg.viewBox.baseVal.y, w: svg.viewBox.baseVal.width, h: svg.viewBox.baseVal.height } };
};

test('accessible name and drawing present on all 25 detail views; labels do not overlap (browser-measured)', async () => {
  const page = await B.open(browser, B.FILE_URL, '#/cartridge/223_rem', { viewport: { width: 1000, height: 800 } });
  for (const r of records) {
    await page.goto(B.FILE_URL + '#/cartridge/' + r.key);
    assert.equal(await page.getByRole('img', { name: r.name + ' drawing', exact: true }).count(), 1, r.name);
    const { texts, pts, vb } = await page.evaluate(measure);
    assert.ok(texts.length >= 7, r.name);
    for (let i = 0; i < texts.length; i++) {
      const a = texts[i];
      assert.ok(a.x >= vb.x && a.x + a.w <= vb.x + vb.w && a.y >= vb.y && a.y + a.h <= vb.y + vb.h, `${r.name}: ${a.text} inside viewBox`);
      for (let j = i + 1; j < texts.length; j++) {
        const b = texts[j];
        assert.ok(!(a.x < b.x + b.w && b.x < a.x + a.w && a.y < b.y + b.h && b.y < a.y + a.h), `${r.name}: ${a.text} overlaps ${b.text}`);
      }
      const hit = pts.find(([x, y]) => x > a.x && x < a.x + a.w && y > a.y && y < a.y + a.h);
      assert.ok(!hit, `${r.name}: ${a.text} overlaps the outline at ${hit}`);
    }
    // the layout estimate used by the placer covers the real text boxes
    const est = await page.evaluate(k => CIP.drawing.drawing(CARTRIDGES.find(c => c.key === k)).labels.map(l => ({ text: l.text, x: l.x, y: l.y, w: l.w, h: l.h })), r.key);
    for (const e of est) {
      const m = texts.find(t => t.text === e.text);
      assert.ok(m, r.name + ' measured ' + e.text);
      assert.ok(m.x >= e.x - 0.05 && m.x + m.w <= e.x + e.w + 0.05 && m.y >= e.y - 0.05 && m.y + m.h <= e.y + e.h + 0.05,
        `${r.name}: estimate does not cover ${e.text}: est ${JSON.stringify(e)} real ${JSON.stringify(m)}`);
    }
  }
  assert.deepEqual(page.problems, []);
});

test('drawing scales to the container width on desktop and on a phone, without horizontal scroll', async () => {
  for (const [w, h] of [[1280, 800], [360, 740]]) {
    const page = await B.open(browser, B.FILE_URL, '#/cartridge/308_win', { viewport: { width: w, height: h }, deviceScaleFactor: 2 });
    const m = await page.evaluate(() => {
      const svg = document.querySelector('figure svg'), f = document.querySelector('figure').getBoundingClientRect(), s = svg.getBoundingClientRect();
      return { fig: f.width, svg: s.width, scroll: document.documentElement.scrollWidth, inner: innerWidth };
    });
    assert.ok(Math.abs(m.svg - m.fig) < 2, `${w}: svg ${m.svg} vs figure ${m.fig}`);
    assert.ok(m.scroll <= m.inner, `${w}: horizontal scroll ${m.scroll} > ${m.inner}`);
    if (w === 360) assert.ok(m.svg <= 360 && m.svg > 300, 'fills a phone');
  }
});

test('missing values are listed under the drawing', async () => {
  const page = await B.open(browser, B.FILE_URL, '#/cartridge/338_lapua_mag');
  assert.match(await page.locator('#notes').innerText(), /Body-side rounding not drawn: r1 min not published/);
  const page2 = await B.open(browser, B.FILE_URL, '#/cartridge/17_hmr');
  const t = await page2.locator('#notes').innerText();
  assert.match(t, /r1 min/); assert.match(t, /r2/);
  const page3 = await B.open(browser, B.FILE_URL, '#/cartridge/308_win');
  assert.equal(await page3.locator('#notes').count(), 0);
});

test('screenshots for visual review', async () => {
  const page = await B.open(browser, B.FILE_URL, '#/cartridge/308_win', { viewport: { width: 1000, height: 800 }, deviceScaleFactor: 2 });
  for (const k of ['308_win', '300_win_mag', '7_x_65_r', '22_long_rifle', '9_mm_luger', '17_hmr']) {
    await page.goto(B.FILE_URL + '#/cartridge/' + k);
    await page.locator('figure svg').screenshot({ path: path.join(B.ROOT, 'test-results', k + '.png') });
  }
});
