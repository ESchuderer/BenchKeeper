const test = require('node:test');
const assert = require('node:assert/strict');
const B = require('./browser');

let browser, srv;
test.before(async () => { browser = await B.launch(); srv = await B.serve(); });
test.after(async () => { await browser.close(); srv.close(); });

for (const mode of ['file', 'served']) {
  const base = () => mode === 'file' ? B.FILE_URL : srv.url;

  test(`[${mode}] start page lists 25 cartridges`, async () => {
    const page = await B.open(browser, base());
    assert.equal(await page.locator('h1').innerText(), 'Cartridges');
    assert.equal(await page.getByText(/^\d+ cartridges$/).innerText(), '25 cartridges');
    const rows = page.locator('tbody tr');
    assert.equal(await rows.count(), 25);
    const first = rows.first();
    assert.equal(await first.locator('a').innerText(), '223 Rem.');
    assert.equal(await first.locator('a').getAttribute('href'), '#/cartridge/223_rem');
    assert.match(await first.innerText(), /rimless/);
    assert.match(await first.innerText(), /44\.7/);
    const names = await page.locator('tbody a').allInnerTexts();
    assert.ok(names.includes('6,5 Creedmoor') && names.includes('40 S.& W.'));
    assert.deepEqual(page.problems, []);
  });

  test(`[${mode}] search filters by name and alternative name`, async () => {
    const page = await B.open(browser, base());
    await page.getByLabel('Search').fill('7,62 x 51');
    assert.deepEqual(await page.locator('tbody a').allInnerTexts(), ['308 Win.']);
    assert.equal(await page.getByText(/^\d+ cartridges$/).innerText(), '1 cartridges');
    await page.getByLabel('Search').fill('30-06');
    assert.deepEqual(await page.locator('tbody a').allInnerTexts(), ['30-06 Spring.']);
    await page.getByLabel('Search').fill('zzz');
    assert.equal(await page.getByText(/^\d+ cartridges$/).innerText(), '0 cartridges');
  });

  test(`[${mode}] family select and combined filters`, async () => {
    const page = await B.open(browser, base());
    const sel = page.getByLabel('Family');
    assert.deepEqual(await sel.locator('option').allInnerTexts(), ['All', 'rimless', 'rimmed', 'belted', 'pistol', 'rimfire']);
    await sel.selectOption({ label: 'belted' });
    assert.deepEqual(await page.locator('tbody a').allInnerTexts(), ['300 Win. Mag.', '7 mm Rem. Mag.']);
    assert.equal(await page.getByText(/^\d+ cartridges$/).innerText(), '2 cartridges');
    await sel.selectOption({ label: 'pistol' });
    assert.equal(await page.getByText(/^\d+ cartridges$/).innerText(), '6 cartridges');
    await page.getByLabel('Search').fill('44');
    assert.deepEqual(await page.locator('tbody a').allInnerTexts(), ['44 Rem. Mag.']);
    await sel.selectOption({ label: 'All' });
    await page.getByLabel('Search').fill('');
    assert.equal(await page.getByText(/^\d+ cartridges$/).innerText(), '25 cartridges');
  });

  test(`[${mode}] filters survive a visit to a detail view`, async () => {
    const page = await B.open(browser, base());
    await page.getByLabel('Search').fill('win');
    await page.getByLabel('Family').selectOption({ label: 'rimless' });
    const before = await page.locator('tbody a').allInnerTexts();
    await page.getByRole('link', { name: '308 Win.', exact: true }).click();
    await page.getByRole('link', { name: 'All cartridges' }).click();
    await page.getByRole('heading', { name: 'Cartridges', exact: true }).waitFor();
    assert.equal(await page.getByLabel('Search').inputValue(), 'win');
    assert.equal(await page.getByLabel('Family').inputValue(), 'rimless');
    assert.deepEqual(await page.locator('tbody a').allInnerTexts(), before);
  });

  test(`[${mode}] name link opens the detail view`, async () => {
    const page = await B.open(browser, base());
    await page.getByRole('link', { name: '308 Win.', exact: true }).click();
    await page.getByRole('heading', { name: '308 Win.', exact: true }).waitFor();
    assert.match(page.url(), /#\/cartridge\/308_win$/);
  });
}
