const test = require('node:test');
const assert = require('node:assert/strict');
const B = require('./browser');

let browser;
test.before(async () => { browser = await B.launch(); });
test.after(async () => { await browser.close(); });

const lum = ([r, g, b]) => { const f = c => { c /= 255; return c <= 0.03928 ? c / 12.92 : ((c + 0.055) / 1.055) ** 2.4; }; return 0.2126 * f(r) + 0.7152 * f(g) + 0.0722 * f(b); };
const ratio = (a, b) => { const [x, y] = [lum(a), lum(b)].sort((p, q) => q - p); return (x + 0.05) / (y + 0.05); };
const rgb = s => s.match(/[\d.]+/g).slice(0, 3).map(Number);

for (const scheme of ['light', 'dark']) {
  test(`[${scheme}] colours follow the system setting and keep contrast`, async () => {
    const page = await B.open(browser, B.FILE_URL, '#/cartridge/308_win', { colorScheme: scheme });
    const c = await page.evaluate(() => {
      const cs = (sel, prop = 'color') => getComputedStyle(document.querySelector(sel))[prop];
      return { bg: cs('body', 'backgroundColor'), fg: cs('body'), muted: cs('#facts dt'), link: cs('a'), dim: cs('text.dim', 'fill'), svgBg: cs('figure svg', 'backgroundColor'), td: cs('table.values td', 'fontVariantNumeric') };
    });
    const bg = rgb(c.bg);
    assert.equal(lum(bg) > 0.5, scheme === 'light', 'background is ' + scheme);
    for (const k of ['fg', 'muted', 'link', 'dim']) assert.ok(ratio(rgb(c[k]), bg) >= 4.5, `${k} contrast ${ratio(rgb(c[k]), bg).toFixed(2)} ${c[k]} on ${c.bg}`);
    assert.match(c.td, /tabular-nums/);
  });
}

test('keyboard: Search, Family, first link, and Print are reachable with a visible focus ring', async () => {
  const page = await B.open(browser, B.FILE_URL, '');
  const seen = [];
  for (let i = 0; i < 3; i++) {
    await page.keyboard.press('Tab');
    seen.push(await page.evaluate(() => { const e = document.activeElement, s = getComputedStyle(e); return { tag: e.tagName, label: e.labels && e.labels[0] ? e.labels[0].textContent.trim().split('\n')[0] : e.textContent, outline: s.outlineStyle + ' ' + s.outlineWidth }; }));
  }
  assert.deepEqual(seen.map(s => s.tag), ['INPUT', 'SELECT', 'A']);
  assert.match(seen[0].label, /Search/); assert.match(seen[1].label, /Family/); assert.equal(seen[2].label, '223 Rem.');
  for (const s of seen) assert.ok(!/^none/.test(s.outline) && !/ 0px/.test(s.outline), 'focus ring ' + s.outline);
  const d = await B.open(browser, B.FILE_URL, '#/cartridge/308_win');
  await d.keyboard.press('Tab'); await d.keyboard.press('Tab');
  assert.equal(await d.evaluate(() => document.activeElement.textContent), 'Print');
  assert.ok(!/^none/.test(await d.evaluate(() => getComputedStyle(document.activeElement).outlineStyle)));
});

test('phone (360 px): no horizontal overflow on the list and on detail views', async () => {
  for (const hash of ['', '#/cartridge/308_win', '#/cartridge/338_lapua_mag', '#/cartridge/22_long_rifle', '#/cartridge/nope']) {
    const page = await B.open(browser, B.FILE_URL, hash, { viewport: { width: 360, height: 640 }, isMobile: true, hasTouch: true, deviceScaleFactor: 2 });
    const m = await page.evaluate(() => ({ sw: document.documentElement.scrollWidth, iw: innerWidth }));
    assert.ok(m.sw <= m.iw, `${hash || 'list'}: scrollWidth ${m.sw} > ${m.iw}`);
  }
});
