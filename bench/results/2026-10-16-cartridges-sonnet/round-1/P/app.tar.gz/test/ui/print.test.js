const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const B = require('./browser');

const { records } = B;
let browser;
test.before(async () => { browser = await B.launch(); });
test.after(async () => { await browser.close(); });

const pages = pdf => (pdf.toString('latin1').match(/\/Type\s*\/Page(?![s\w])/g) || []).length;
const mediaBox = pdf => pdf.toString('latin1').match(/\/MediaBox\s*\[\s*([\d.\s]+)\]/)[1].trim().split(/\s+/).map(Number);

test('every detail view prints as exactly one A4 portrait page', async () => {
  const page = await B.open(browser, B.FILE_URL, '#/cartridge/223_rem', { colorScheme: 'dark', viewport: { width: 1000, height: 800 } });
  await page.emulateMedia({ media: 'print', colorScheme: 'dark' });
  const bad = [];
  for (const r of records) {
    await page.goto(B.FILE_URL + '#/cartridge/' + r.key);
    await page.getByRole('heading', { name: r.name, exact: true }).waitFor();
    const pdf = await page.pdf({ preferCSSPageSize: true, printBackground: true });
    const n = pages(pdf), [x0, y0, x1, y1] = mediaBox(pdf);
    if (n !== 1 || Math.abs(x1 - 595.3) > 1.5 || Math.abs(y1 - 841.9) > 1.5) bad.push(`${r.name}: ${n} page(s), ${x1}x${y1}`);
    if (process.env.PDFDIR) fs.writeFileSync(path.join(process.env.PDFDIR, r.key + '.pdf'), pdf);
  }
  assert.deepEqual(bad, []);
});

test('print sheet: header, full-width drawing, tables, footer; no navigation or buttons; black on white even in dark mode', async () => {
  const page = await B.open(browser, B.FILE_URL, '#/cartridge/308_win', { colorScheme: 'dark', viewport: { width: 1000, height: 800 } });
  await page.emulateMedia({ media: 'print', colorScheme: 'dark' });
  const m = await page.evaluate(() => {
    const vis = el => !!el && getComputedStyle(el).display !== 'none' && el.getBoundingClientRect().height > 0;
    const svg = document.querySelector('figure svg'), main = document.querySelector('main');
    const vb = svg.viewBox.baseVal, pxPerUnit = svg.getBoundingClientRect().width / vb.width;
    return {
      nav: vis(document.querySelector('nav')), button: [...document.querySelectorAll('button')].some(vis), search: vis(document.querySelector('input,select')),
      h1: vis(document.querySelector('h1')) && document.querySelector('h1').textContent,
      foot: document.querySelector('footer') && vis(document.querySelector('footer')) && document.querySelector('footer').textContent,
      bg: getComputedStyle(document.body).backgroundColor, fg: getComputedStyle(document.body).color,
      svgW: svg.getBoundingClientRect().width, mainW: main.getBoundingClientRect().width,
      minFontPt: Math.min(...[...svg.querySelectorAll('text')].map(t => parseFloat(getComputedStyle(t).fontSize) * pxPerUnit * 0.75)),
      tables: document.querySelectorAll('table.values').length,
      dimColor: getComputedStyle(document.querySelector('line.dim')).stroke,
    };
  });
  assert.equal(m.nav, false); assert.equal(m.button, false); assert.equal(m.search, false);
  assert.equal(m.h1, '308 Win.');
  assert.match(m.foot, /Source: C\.I\.P\. TDCC, revised 2008-09-23/);
  assert.equal(m.bg, 'rgb(255, 255, 255)'); assert.equal(m.fg, 'rgb(0, 0, 0)');
  assert.ok(m.svgW >= 0.95 * m.mainW, `drawing width ${m.svgW} of ${m.mainW}`);
  assert.ok(m.minFontPt >= 6, `smallest label ${m.minFontPt} pt`);
  assert.ok(m.tables >= 12);
  assert.equal(m.dimColor, 'rgb(0, 0, 0)');
});

test('the Print button opens the print dialog', async () => {
  const page = await B.open(browser, B.FILE_URL, '#/cartridge/308_win');
  await page.evaluate(() => { window.__printed = 0; window.print = () => { window.__printed++; }; });
  await page.getByRole('button', { name: 'Print' }).click();
  assert.equal(await page.evaluate(() => window.__printed), 1);
});
