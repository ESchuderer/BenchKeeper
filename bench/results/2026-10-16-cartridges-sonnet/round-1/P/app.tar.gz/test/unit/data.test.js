const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

const root = path.resolve(__dirname, '../..');
const jsonl = fs.readFileSync(path.join(root, 'data/cartridges.jsonl'), 'utf8').trim().split('\n').map(l => JSON.parse(l));
global.window = global;
require(path.join(root, 'data/cartridges.js'));

test('25 records, unique keys and names', () => {
  assert.equal(jsonl.length, 25);
  assert.equal(new Set(jsonl.map(r => r.key)).size, 25);
  assert.equal(new Set(jsonl.map(r => r.name)).size, 25);
});

test('data/cartridges.js is identical to data/cartridges.jsonl', () => {
  assert.deepEqual(window.CARTRIDGES, jsonl);
});

test('family counts', () => {
  const c = {};
  for (const r of jsonl) c[r.family] = (c[r.family] || 0) + 1;
  assert.deepEqual(c, { rimless: 12, belted: 2, rimmed: 2, pistol: 6, rimfire: 3 });
});
