const test = require('node:test');
const assert = require('node:assert/strict');
const path = require('node:path');
global.window = global;
require(path.resolve(__dirname, '../../data/cartridges.js'));
const D = require('../../js/drawing.js');
const rec = key => window.CARTRIDGES.find(r => r.key === key);

// Geometry helpers independent of the implementation.
const rectOf = l => ({ x0: l.x, y0: l.y, x1: l.x + l.w, y1: l.y + l.h });
const rectsOverlap = (a, b, pad = 0) => a.x0 < b.x1 + pad && b.x0 < a.x1 + pad && a.y0 < b.y1 + pad && b.y0 < a.y1 + pad;
function segHitsRect(s, r, pad = 0) { // Liang-Barsky
  const [x1, y1, x2, y2] = s, dx = x2 - x1, dy = y2 - y1;
  let t0 = 0, t1 = 1;
  for (const [p, q] of [[-dx, x1 - (r.x0 - pad)], [dx, (r.x1 + pad) - x1], [-dy, y1 - (r.y0 - pad)], [dy, (r.y1 + pad) - y1]]) {
    if (p === 0) { if (q < 0) return false; } else { const t = q / p; if (p < 0) { if (t > t1) return false; t0 = Math.max(t0, t); } else { if (t < t0) return false; t1 = Math.min(t1, t); } }
  }
  return t0 <= t1;
}

test('structure for 308 Win.', () => {
  const d = D.drawing(rec('308_win'));
  assert.match(d.svg, /^<svg[^>]*xmlns="http:\/\/www\.w3\.org\/2000\/svg"/);
  assert.match(d.svg, /role="img"/);
  assert.match(d.svg, /<title id="drawing-title">308 Win\. drawing<\/title>/);
  assert.match(d.svg, /aria-labelledby="drawing-title"/);
  assert.ok(d.viewBox.w > 50 && d.viewBox.h > 30);
  for (const re of [/stroke-dasharray/, /<pattern id="hatch"/, /id="outline"/, /id="titleblock"/, /class="arrow"/, /class="ext"/]) assert.match(d.svg, re);
  const texts = d.labels.map(l => l.text);
  for (const t of ['L3 51.18', 'L6 71.12', 'L1 39.62', 'L2 43.48', 'R1 12.01', 'R 1.37', 'P1 11.96', 'P2 11.53', 'H1 8.72', 'H2 8.72', 'G1 7.85', 'E1 10.39', 'α 40°']) assert.ok(texts.includes(t), t + ' in ' + texts.join('|'));
  for (const t of ['308 Win.', 'C.I.P. table I', 'revised 2008-09-23', 'Dimensions in mm', 'Scale']) assert.ok(d.svg.includes(t), t);
  assert.match(d.svg, /Scale \d+\.\d\d:1/);
  assert.ok(Math.abs(d.scale - 186 / d.viewBox.w) < 1e-9, 'scale is A4 content width over drawing width');
});

test('only published dimensions are drawn (9 mm Luger, 17 HMR, 22 Long Rifle)', () => {
  const t = k => D.drawing(rec(k)).labels.map(l => l.text);
  const luger = t('9_mm_luger');
  assert.deepEqual(luger.filter(x => /^(P2|H1|L1|L2|α)/.test(x)), []);
  for (const x of ['L3 19.15', 'L6 29.69', 'R1 9.96', 'R 1.27', 'P1 9.93', 'H2 9.65', 'G1 9.03', 'E1 8.79']) assert.ok(luger.includes(x), x);
  const hmr = t('17_hmr');
  for (const x of ['P2 6.15', 'H1 4.9', 'L1 22.2', 'L2 23.54', 'α 50°']) assert.ok(hmr.includes(x), x);
  assert.ok(!hmr.some(x => /^E1/.test(x)));
  assert.ok(t('22_long_rifle').every(x => !/^E1/.test(x)));
  assert.ok(t('338_lapua_mag').includes(`α 39°59'49"`));
});

test('notes name the missing value', () => {
  assert.deepEqual(D.drawing(rec('338_lapua_mag')).notes.map(n => n.text), ['Body-side rounding not drawn: r1 min not published']);
  assert.equal(D.drawing(rec('308_win')).notes.length, 0);
});

test('all 25: accessible name, finite coordinates, 1 unit = 1 mm', () => {
  for (const r of window.CARTRIDGES) {
    const d = D.drawing(r);
    assert.ok(d.svg.includes(`>${r.name.replace(/&/g, "&amp;")} drawing</title>`), r.name);
    assert.ok(!/NaN|undefined|Infinity/.test(d.svg), r.name + ' has NaN/undefined');
    const [x, y, w, h] = d.svg.match(/viewBox="([^"]+)"/)[1].split(' ').map(Number);
    for (const [a, b] of [[x, d.viewBox.x], [y, d.viewBox.y], [w, d.viewBox.w], [h, d.viewBox.h]]) assert.ok(Math.abs(a - b) < 0.01, r.name + ' viewBox');
    // the head face is at x=0 and the tip at x=L6: the drawing is in mm
    assert.ok(d.viewBox.x <= 0 && d.viewBox.x + d.viewBox.w >= r.cartridge.lengths.L6, r.name + ' viewBox contains the part');
  }
});

test('all 25: labels do not overlap each other, the outline or foreign dimension lines', () => {
  for (const r of window.CARTRIDGES) {
    const d = D.drawing(r), L = d.labels;
    for (let i = 0; i < L.length; i++) {
      for (let j = i + 1; j < L.length; j++) assert.ok(!rectsOverlap(rectOf(L[i]), rectOf(L[j]), 0.2), `${r.name}: ${L[i].text} overlaps ${L[j].text}`);
      for (const s of d.outline) assert.ok(!segHitsRect(s, rectOf(L[i]), 0.2), `${r.name}: ${L[i].text} touches the outline`);
      for (const ln of d.lines) if (ln.owner !== L[i].id) assert.ok(!segHitsRect([ln.x1, ln.y1, ln.x2, ln.y2], rectOf(L[i]), 0.1), `${r.name}: ${L[i].text} crosses line of ${ln.owner}`);
      const v = d.viewBox, b = rectOf(L[i]);
      assert.ok(b.x0 >= v.x && b.x1 <= v.x + v.w && b.y0 >= v.y && b.y1 <= v.y + v.h, `${r.name}: ${L[i].text} inside viewBox`);
    }
  }
});

test('all 25: every dimension has arrowheads and extension/leader lines; title block does not collide', () => {
  for (const r of window.CARTRIDGES) {
    const d = D.drawing(r);
    const owners = new Set(d.lines.map(l => l.owner));
    for (const l of d.labels) assert.ok(owners.has(l.id), `${r.name}: ${l.text} has a line`);
    assert.ok((d.svg.match(/class="arrow"/g) || []).length >= 2 * d.labels.length - 1, r.name + ' arrows');
    const tb = d.titleBlock;
    for (const l of d.labels) assert.ok(!rectsOverlap(rectOf(l), { x0: tb.x, y0: tb.y, x1: tb.x + tb.w, y1: tb.y + tb.h }), `${r.name}: ${l.text} overlaps title block`);
    for (const s of d.outline) assert.ok(!segHitsRect(s, { x0: tb.x, y0: tb.y, x1: tb.x + tb.w, y1: tb.y + tb.h }), r.name + ' outline vs title block');
  }
});

test('scale bar is 10 mm long in drawing units', () => {
  const d = D.drawing(rec('223_rem'));
  assert.match(d.svg, /class="scalebar"/);
});

test('rule 9: a dimension whose value is missing is omitted, never drawn with NaN', () => {
  const r = JSON.parse(JSON.stringify(rec('308_win')));
  delete r.cartridge.powderChamber.P2; delete r.cartridge.collar.H1;
  const d = D.drawing(r);
  assert.ok(!/NaN|undefined/.test(d.svg));
  const t = d.labels.map(l => l.text);
  assert.ok(!t.some(x => /^(P2|H1)/.test(x)));
  assert.ok(t.includes('L3 51.18'));
});

test('styles are scoped to the drawing', () => {
  const d = D.drawing(rec('308_win'));
  assert.match(d.svg, /<svg[^>]*class="cip-drawing"/);
  const css = d.svg.match(/<style>([^<]*)<\/style>/)[1];
  for (const sel of css.split('}').map(x => x.split('{')[0]).filter(Boolean).flatMap(x => x.split(','))) assert.match(sel.trim(), /^\.cip-drawing /, sel);
});
