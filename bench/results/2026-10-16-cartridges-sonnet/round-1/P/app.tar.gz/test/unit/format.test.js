const test = require('node:test');
const assert = require('node:assert/strict');
const path = require('node:path');
const F = require('../../js/format.js');
global.window = global;
require(path.resolve(__dirname, '../../data/cartridges.js'));
const rec = key => window.CARTRIDGES.find(r => r.key === key);

test('numbers as published', () => {
  assert.equal(F.value(51.18), '51.18');
  assert.equal(F.value(4150.0), '4150');
  assert.equal(F.value(25), '25');
  assert.equal(F.value(0.1), '0.1');
});

test('angles', () => {
  assert.equal(F.value(40.0, 'alpha'), '40°');
  assert.equal(F.value(40.0, 'L3'), '40');
  assert.equal(F.angle({ degrees: 39, minutes: 59, seconds: 49 }), `39°59'49"`);
  assert.equal(F.angle({ degrees: 1, minutes: 30, seconds: 0 }), `1°30'0"`);
  assert.equal(F.value({ degrees: 3, minutes: 10, seconds: 36 }), `3°10'36"`);
});

test('symbols', () => {
  const s = { eMin: 'e min', r1Min: 'r1 min', r1Max: 'r1 max', alpha: 'α', alpha1: 'α1', beta: 'β', delta: 'δ', deltaL: 'delta L', L3PlusG: 'L3 + G', L3: 'L3', Pmax: 'Pmax' };
  for (const [k, v] of Object.entries(s)) assert.equal(F.symbol(k), v, k);
});

test('units', () => {
  const u = { L3: 'mm', H2: 'mm', u: 'mm', deltaL: 'mm', Pmax: 'bar', PK: 'bar', PE: 'bar', EE: 'J', M: 'g', Q: 'mm²', N: '', alpha: '°', alpha1: '°', beta: '°', delta: '°', i: '°' };
  for (const [k, v] of Object.entries(u)) assert.equal(F.unit(k), v, k);
});

test('sections merge tolerances and drop empty sections', () => {
  const secs = F.sections(rec('308_win').cartridge);
  const lengths = secs.find(s => s.key === 'lengths');
  assert.equal(lengths.title, 'Lengths');
  const l1 = lengths.rows.find(r => r.symbol === 'L1');
  assert.deepEqual(l1, { symbol: 'L1', value: '39.62 -0.2', unit: 'mm' });
  assert.ok(!secs.flatMap(s => s.rows).some(r => /Tol/.test(r.symbol)));
  const p = secs.find(s => s.key === 'pressures').rows.find(r => r.symbol === 'Pmax');
  assert.deepEqual(p, { symbol: 'Pmax', value: '4150', unit: 'bar' });
  assert.ok(!F.sections(rec('9_mm_luger').cartridge).some(s => s.key === 'junctionCone'));
  const alpha = secs.find(s => s.key === 'junctionCone').rows.find(r => r.symbol === 'α');
  assert.deepEqual(alpha, { symbol: 'α', value: '40°', unit: '°' });
});

test('search by name and alternative names', () => {
  assert.ok(F.matches(rec('308_win'), '7,62 x 51'));
  assert.ok(F.matches(rec('308_win'), '  308 WIN '));
  assert.ok(F.matches(rec('30_06_spring'), '30-06'));
  assert.ok(!F.matches(rec('223_rem'), '7,62 x 51'));
  assert.ok(F.matches(rec('223_rem'), ''));
  const hits = window.CARTRIDGES.filter(r => F.matches(r, '7,62 x 51')).map(r => r.name);
  assert.deepEqual(hits, ['308 Win.']);
});
