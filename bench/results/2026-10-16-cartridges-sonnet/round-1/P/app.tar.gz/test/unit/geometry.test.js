const test = require('node:test');
const assert = require('node:assert/strict');
const path = require('node:path');
global.window = global;
require(path.resolve(__dirname, '../../data/cartridges.js'));
const G = require('../../js/geometry.js');
const rec = key => window.CARTRIDGES.find(r => r.key === key);
const near = (a, b, msg, eps = 1e-6) => assert.ok(Math.abs(a - b) <= eps, `${msg || ''} ${a} !~ ${b}`);
const nearPt = (p, q, msg) => { near(p[0], q[0], msg + ' r'); near(p[1], q[1], msg + ' z'); };
const rad = d => d * Math.PI / 180;
const dist = (p, q) => Math.hypot(p[0] - q[0], p[1] - q[1]);

test('rule 1: rim type', () => {
  assert.equal(G.rimType(rec('223_rem')), 'rimless');
  assert.equal(G.rimType(rec('7_x_65_r')), 'rimmed');
  assert.equal(G.rimType(rec('300_win_mag')), 'belted');
  assert.equal(G.rimType(rec('22_long_rifle')), 'rimfire');
  assert.equal(G.rimType(rec('38_special')), 'rimmed'); // family pistol, R1/P1 = 1.16
  assert.equal(G.rimType(rec('9_mm_luger')), 'rimless');
  assert.equal(G.rimType({ family: 'rimless', cartridge: { caseHead: { R1: 9 }, powderChamber: { P1: 10 } } }), 'rebated');
});

test('rules 2-3: 308 Win. head, chamfer, groove', () => {
  const g = G.build(rec('308_win'));
  const R1 = 12.01, R = 1.37, f = 0.38, E = 3.85, E1 = 10.39, eMin = 1.4, P1 = 11.96;
  nearPt(g.outer[0], [0, 0], 'start');
  nearPt(g.outer[1], [R1 / 2 - Math.min(f * Math.tan(rad(35)), R1 / 4), 0], 'chamfer start');
  nearPt(g.outer[2], [R1 / 2, f], 'chamfer end');
  nearPt(g.outer[3], [R1 / 2, R], 'rim top');
  nearPt(g.outer[4], [E1 / 2, R], 'groove in');
  nearPt(g.outer[5], [E1 / 2, R + eMin], 'groove floor');
  nearPt(g.outer[6], [P1 / 2, E], 'ramp end');
});

test('rule 2: chamfer is limited to R1/4', () => {
  const r = JSON.parse(JSON.stringify(rec('308_win')));
  r.cartridge.caseHead.f = 5; // f·tanβ = 3.5 > R1/4 = 3.0025
  const g = G.build(r);
  near(g.outer[1][0], r.cartridge.caseHead.R1 / 2 - r.cartridge.caseHead.R1 / 4, 'limited');
});

test('rule 2: square corner without beta/f; rule 3: no groove steps in at z=R (7 x 65 R)', () => {
  const r = JSON.parse(JSON.stringify(rec('7_x_65_r')));
  delete r.cartridge.caseHead.f;
  const g = G.build(r);
  assert.deepEqual(g.outer.slice(0, 4).map(p => p.map(x => +x.toFixed(4))), [[0, 0], [6.66, 0], [6.66, 1.4], [11.89 / 2, 1.4]]);
  assert.ok(g.notes.some(n => n.missing.includes('f')));
  const h = G.build(rec('7_x_65_r'));
  nearPt(h.outer[3], [6.66, 1.4]);
  nearPt(h.outer[4], [11.89 / 2, 1.4], 'step in at R');
  assert.deepEqual(h.notes, [], 'rimmed case has no groove and no note');
});

test('rule 2: rimfire edge is a half-round at R1/2 (22 Long Rifle) and a rounded rectangle when thin', () => {
  const R = 1.09, R1 = 7.06, P1 = 5.74;
  const rho = Math.min(R / 2, (R1 - P1) / 2);
  const g = G.build(rec('22_long_rifle'));
  const maxR = Math.max(...g.outer.slice(0, 40).map(p => p[0]));
  near(maxR, R1 / 2, 'outermost');
  const edge = g.outer.filter(p => p[1] <= R + 1e-9 && p[0] > P1 / 2 + 1e-9);
  for (const p of edge) { if (p[1] > 0 && p[1] < R) assert.ok(dist(p, [R1 / 2 - rho, R / 2]) <= rho + 1e-6 && p[0] >= R1 / 2 - rho - 1e-9); }
  assert.ok(g.outer.some(p => Math.abs(p[0] - R1 / 2) < 1e-9 && Math.abs(p[1] - R / 2) < 1e-6), 'tip of half-round at R/2');
  assert.ok(g.outer.some(p => Math.abs(p[0] - P1 / 2) < 1e-9 && Math.abs(p[1] - R) < 1e-9), 'step in at z = R');
  const thin = JSON.parse(JSON.stringify(rec('22_long_rifle')));
  thin.cartridge.caseHead.R1 = 6.2; // (R1-P1)/2 = 0.23 < R/2
  const t = G.build(thin);
  near(Math.max(...t.outer.map(p => p[0])), 3.1, 'thin rim outer');
  assert.ok(t.outer.some(p => Math.abs(p[0] - 3.1) < 1e-9 && Math.abs(p[1] - (1.09 - 0.23)) < 1e-9), 'straight edge ends at R - rho');
  assert.equal(g.rimType, 'rimfire');
  assert.ok(!g.notes.some(n => n.missing.includes('beta')));
});

test('rule 3: belted ramp at delta to R3/2, belt to z=E, step to P1/2 (300 Win. Mag.)', () => {
  const g = G.build(rec('300_win_mag'));
  const R = 1.27, eMin = 0.94, E1 = 12.07, R3 = 13.51, d = 35, E = 5.59, P1 = 13.03;
  const i = g.outer.findIndex(p => Math.abs(p[0] - E1 / 2) < 1e-9 && Math.abs(p[1] - (R + eMin)) < 1e-9);
  assert.ok(i > 0, 'floor end');
  nearPt(g.outer[i + 1], [R3 / 2, R + eMin + (R3 / 2 - E1 / 2) / Math.tan(rad(d))], 'belt ramp end');
  nearPt(g.outer[i + 2], [R3 / 2, E], 'belt to E');
  nearPt(g.outer[i + 3], [P1 / 2, E], 'step in');
  assert.equal(g.rimType, 'belted');
});

test('rule 3: groove not drawn and named when a value is missing', () => {
  const r = JSON.parse(JSON.stringify(rec('223_rem')));
  delete r.cartridge.caseHead.eMin;
  const g = G.build(r);
  assert.ok(g.notes.some(n => /groove/i.test(n.feature) && n.missing.includes('eMin')));
  assert.ok(g.outer.some(p => Math.abs(p[0] - 9.58 / 2) < 1e-9 && Math.abs(p[1] - 1.14) < 1e-9), 'steps in at R');
});

test('rules 4-6: bottleneck points, straight case, shoulder', () => {
  const g = G.build(rec('308_win'));
  assert.equal(g.bottleneck, true);
  const last = g.outer[g.outer.length - 1];
  nearPt(last, [8.72 / 2, 51.18], 'mouth');
  // monotone z
  for (let i = 1; i < g.outer.length; i++) assert.ok(g.outer[i][1] >= g.outer[i - 1][1] - 1e-9, 'z monotone at ' + i);
  // shoulder line lies at alpha/2 to the axis through the published points: check the sharp corners against fillets
  const s = G.build(Object.assign({}, rec('7_62_x_39')));
  assert.equal(s.bottleneck, true);
  const luger = G.build(rec('9_mm_luger'));
  assert.equal(luger.bottleneck, false);
  nearPt(luger.outer[luger.outer.length - 1], [9.65 / 2, 19.15], 'straight to H2/2, L3');
  assert.ok(luger.outer.some(p => Math.abs(p[0] - 9.93 / 2) < 1e-9 && Math.abs(p[1] - 2.98) < 1e-9), 'body starts at P1/2, E');
});

test('rule 5: fillets r1 min / r2 are tangent arcs of the stated radius (223 Rem.)', () => {
  const g = G.build(rec('223_rem'));
  const P2 = 9.0, L1 = 36.52, H1 = 6.43, L2 = 39.55;
  // shoulder deflection angle: line from (P2/2,L1) to (H1/2,L2)
  const dr = H1 / 2 - P2 / 2, dz = L2 - L1;
  const shoulderAngle = Math.atan2(-dr, dz); // to axis
  near(shoulderAngle * 2 * 180 / Math.PI, 46, 'alpha is the included angle', 0.5);
  // the sharp corner (P2/2, L1) is cut: no outer point equals it, and the nearest point is r(1/cos(turn/2)-1) away
  const body = Math.atan2((P2 / 2) - (9.58 / 2), L1 - 3.13); // body line angle (negative: narrowing)
  const turn = Math.abs(shoulderAngle - Math.abs(body)) + 0; // both measured towards the axis
  const corner = [P2 / 2, L1];
  const nearest = Math.min(...g.outer.map(p => dist(p, corner)));
  const rr = 0.64, expected = rr * (1 / Math.cos(turn / 2) - 1);
  near(nearest, expected, 'fillet gap', 2e-3);
  assert.ok(nearest > 0.001, 'corner is rounded');
});

test('rule 5: a rounding with no published radius is sharp and named (8,6 (mm) x 70, 17 HMR)', () => {
  const g = G.build(rec('338_lapua_mag'));
  assert.deepEqual(g.notes.map(n => n.missing), [['r1Min']]);
  assert.ok(g.outer.some(p => Math.abs(p[0] - 13.82 / 2) < 1e-9 && Math.abs(p[1] - 54.9) < 1e-9), 'sharp body-side corner');
  const h = G.build(rec('17_hmr'));
  assert.deepEqual(h.notes.map(n => n.missing), [['r1Min'], ['r2']]);
});

test('rule 5: missing notes over all records', () => {
  const got = {};
  for (const r of window.CARTRIDGES) { const n = G.build(r).notes; if (n.length) got[r.name] = n.flatMap(x => x.missing); }
  assert.deepEqual(got, { '338 Lapua Mag.': ['r1Min'], '17 HMR': ['r1Min', 'r2'] });
});

test('rule 5: a rounding that does not fit is not drawn and is reported', () => {
  const r = JSON.parse(JSON.stringify(rec('223_rem')));
  r.cartridge.junctionCone.r2 = 40;
  const g = G.build(r);
  assert.ok(g.notes.some(n => /does not fit/.test(n.text) && /r2/.test(n.text)));
});

test('rule 5: every drawn rounding is tangent (no kinks) for all records', () => {
  for (const r of window.CARTRIDGES) {
    const g = G.build(r);
    // outside the intentional sharp corners, turning between consecutive segments of the outer profile above w stays small
    const pts = g.outer.filter(p => p[1] >= g.w);
    for (let i = 2; i < pts.length; i++) {
      const a = Math.atan2(pts[i - 1][0] - pts[i - 2][0], pts[i - 1][1] - pts[i - 2][1]);
      const b = Math.atan2(pts[i][0] - pts[i - 1][0], pts[i][1] - pts[i - 1][1]);
      let d = Math.abs(a - b); if (d > Math.PI) d = 2 * Math.PI - d;
      if (d > 0.5) { // a kink: must be a published sharp corner or the belt step (z unchanged)
        assert.ok(g.notes.length || Math.abs(pts[i][1] - pts[i - 1][1]) < 1e-9 || Math.abs(pts[i - 1][1] - pts[i - 2][1]) < 1e-9 || pts[i][1] === pts.at(-1)[1], `${r.name} kink at ${i}`);
      }
    }
  }
});

const SEAT = { // [key, s factor, k, m factor / formula]
  '308_win': ['pointy', 1.0, 0.40],
  '9_mm_luger': ['rounded', 0.4, 0.65],
  '22_win_mag_r_f': ['rounded', 0.8, 0.55],
  '223_rem': ['pointy', 1.0, 0.40],
  '40_s_w': ['flat', 0.4, 0.70],
  '357_magnum': ['semi_wadcutter', 0.6, 0.78],
};

test('rule 7: seating depth, cylinder length, nose, tip', () => {
  for (const [key, [shape, sf, k]] of Object.entries(SEAT)) {
    const r = rec(key), g = G.build(r), b = g.bullet;
    const G1 = r.cartridge.projectile.G1, L3 = r.cartridge.lengths.L3, L6 = r.cartridge.lengths.L6;
    assert.equal(b.shape, shape);
    const zb = L3 - sf * G1, Lb = L6 - zb, zc = zb + k * Lb;
    near(b.base, zb, key + ' base'); near(b.cylEnd, zc, key + ' cyl end');
    const m = { pointy: Math.max(0.08 * G1, 1.27), rounded: 0.15 * G1, flat: 0.55 * G1, semi_wadcutter: 0.6 * G1 }[shape];
    near(b.meplat, m, key + ' m');
    nearPt(b.outline[0], [0, zb], key + ' base centre');
    nearPt(b.outline[1], [G1 / 2, zb], key + ' base edge');
    nearPt(b.outline[2], [G1 / 2, zc], key + ' cyl end pt');
    nearPt(b.outline.at(-2), [m / 2, L6], key + ' meplat edge');
    nearPt(b.outline.at(-1), [0, L6], key + ' tip centre');
    const n = L6 - zc;
    if (shape === 'pointy') {
      const d = G1 / 2 - m / 2, rho = (d * d + n * n) / (2 * d), c = [G1 / 2 - rho, zc];
      near(b.rho, rho, 'rho');
      for (const p of b.outline.slice(2, -1)) near(dist(p, c), rho, key + ' ogive radius', 1e-6);
    } else if (shape === 'rounded') {
      const a = G1 / 2 - m / 2;
      for (const p of b.outline.slice(2, -1)) near(((p[0] - m / 2) / a) ** 2 + ((p[1] - zc) / n) ** 2, 1, key + ' ellipse', 1e-6);
    } else { // straight cone
      for (const p of b.outline.slice(2, -1)) near((p[0] - G1 / 2) / (m / 2 - G1 / 2), (p[1] - zc) / n, key + ' cone', 1e-6);
    }
  }
});

test('rule 7: heeled case (22 Long Rifle): exposed bullet has the case OD, seated heel the inner diameter', () => {
  const g = G.build(rec('22_long_rifle'));
  assert.equal(g.heeled, true);
  const H2 = 5.72, tb = 0.6;
  assert.equal(G.build(rec('22_win_mag_r_f')).heeled, false);
  const seated = g.bullet.outline.filter(p => p[1] > g.bullet.base && p[1] < 15.57 - 1e-9);
  assert.ok(seated.length >= 0);
  near(g.bullet.seatRadius, H2 / 2 - tb, 'heel radius');
  near(g.bullet.shankRadius, H2 / 2, 'exposed radius');
  assert.ok(g.bullet.outline.some(p => Math.abs(p[0] - (H2 / 2 - tb)) < 1e-9 && Math.abs(p[1] - 15.57) < 1e-9), 'heel reaches the mouth');
  assert.ok(g.bullet.outline.some(p => Math.abs(p[0] - H2 / 2) < 1e-9 && Math.abs(p[1] - 15.57) < 1e-9), 'then case OD');
});

test('rule 8: walls tn, tb and head w; pocket', () => {
  const g = G.build(rec('223_rem'));
  const tn = (6.43 - 5.7) / 2, tb = Math.min(Math.max(1.3 * tn, 0.6), 0.35 * 9.58 / 2);
  near(g.tn, tn); near(g.tb, tb);
  assert.deepEqual(g.pocket, { d: 4.45, depth: 3.04 });
  near(g.w, Math.max(2.5, 0.25 * 9.58 / 2, 3.04 + 1.5, 3.13 + tb), 'w');
  const c = G.build(rec('6_5_creedmoor'));
  assert.deepEqual(c.pocket, { d: 5.33, depth: 3.3 });
  near(c.w, 3.3 + 1.5);
  const pocket = { '45_auto': [5.33, 3.04], '9_mm_luger': [4.45, 3.04], '357_magnum': [4.45, 3.04], '44_rem_mag': [5.33, 3.04], '300_win_mag': [5.33, 3.3] };
  for (const [k, [d, depth]] of Object.entries(pocket)) assert.deepEqual(G.build(rec(k)).pocket, { d, depth }, k);
  for (const k of ['22_long_rifle', '22_win_mag_r_f', '17_hmr']) { assert.equal(G.build(rec(k)).pocket, null, k); }
  assert.equal(G.build(rec('22_long_rifle')).w, 2.5);
  const b = G.build(rec('300_win_mag'));
  assert.ok(b.w >= 5.59 + b.tb - 1e-9, 'belted head covers belt');
});

test('rule 8: inner line follows walls (tb on body, tn on neck)', () => {
  const r = rec('308_win'), g = G.build(r);
  const rOuter = z => { // interpolate on the outer profile (last segment with z0 < z <= z1)
    for (let i = 1; i < g.outer.length; i++) { const [r0, z0] = g.outer[i - 1], [r1, z1] = g.outer[i]; if (z1 > z0 && z > z0 && z <= z1) return r0 + (r1 - r0) * (z - z0) / (z1 - z0); }
  };
  for (const [r0, z0] of g.inner) {
    const t = rOuter(z0 - 1e-12) - r0;
    if (z0 > g.w + 1e-6 && z0 < 39.62 - 1) near(t, g.tb, 'body wall at z=' + z0, 1e-3);
    if (z0 > 43.48 + 1) near(t, g.tn, 'neck wall at z=' + z0, 1e-3);
  }
  assert.ok(g.inner[0][1] === g.w && g.inner.at(-1)[1] === 51.18);
  near(g.inner.at(-1)[0], 7.85 / 2, 'bore at mouth equals bullet radius');
});

test('rule 8: straight case: tb up to the bullet base, tn from there (9 mm Luger)', () => {
  const g = G.build(rec('9_mm_luger'));
  near(g.bullet.seatRadius, 9.03 / 2);
  near(g.inner.at(-1)[0], 9.03 / 2, 'bore at mouth');
  assert.ok(g.inner.some(p => Math.abs(p[1] - g.bullet.base) < 1e-9), 'step at base');
});

test('all 25 records: finite numbers, monotone z, inner inside outer, bullet tip at L6', () => {
  for (const r of window.CARTRIDGES) {
    const g = G.build(r);
    const all = [...g.outer, ...g.inner, ...g.bullet.outline];
    for (const p of all) assert.ok(Number.isFinite(p[0]) && Number.isFinite(p[1]), r.name + ' NaN');
    for (let i = 1; i < g.outer.length; i++) assert.ok(g.outer[i][1] >= g.outer[i - 1][1] - 1e-9, `${r.name} z monotone at ${i}`);
    nearPt(g.outer.at(-1), [r.cartridge.collar.H2 / 2, r.cartridge.lengths.L3], r.name + ' mouth');
    near(g.bullet.outline.at(-1)[1], r.cartridge.lengths.L6, r.name + ' tip');
    assert.ok(g.tn > 0 || g.heeled, r.name + ' tn');
    assert.ok(g.inner.length >= 2);
    for (const p of g.inner) assert.ok(p[0] > 0 && p[0] < Math.max(...g.outer.map(q => q[0])), r.name + ' inner radius');
    assert.ok(g.w < r.cartridge.lengths.L3, r.name + ' w');
  }
});

test('rule 9: missing values are named, never invented', () => {
  const clone = k => JSON.parse(JSON.stringify(rec(k)));
  const r = clone('9_3_x_74_r'); r.cartridge.caseHead.E = 3; r.cartridge.caseHead.E1 = 10; // groove published, e min missing
  assert.ok(G.build(r).notes.some(n => /groove/i.test(n.feature) && n.missing.includes('eMin')), 'rimmed case with E, E1 but no e min');
  const s = clone('308_win'); delete s.annotations.defaultBulletShape;
  assert.deepEqual(G.build(s).notes.filter(n => n.feature === 'Bullet').map(n => n.missing), [['defaultBulletShape']]);
  assert.equal(G.build(s).bullet, null);
});
