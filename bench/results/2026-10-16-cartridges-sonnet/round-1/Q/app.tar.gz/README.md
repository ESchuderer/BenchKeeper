# C.I.P. cartridge database

A static reference of 25 C.I.P. cartridges (cartridge and chamber dimensions) with a true-to-scale
2D drawing for each, modelled on the cartridge database of
[OpenBallistics](https://openreloading.github.io/OpenBallistics/). Data: the 25 records of
[PiMetry/OpenBallistics](https://github.com/PiMetry/OpenBallistics) (MIT, commit e83db43), used unchanged.

## Use

Open `index.html` in Chromium directly from disk, or serve the folder with any static file server.
There is no build step, no framework, no runtime dependency and no network request.

- `#/` is the list (search, family filter, count); `#/cartridge/<key>` is a detail view and survives a reload.
- "Print" prints one A4 portrait page, black on white.

## Layout

| Path | Purpose |
| --- | --- |
| `index.html`, `css/style.css` | Page, screen (light/dark) and print styles |
| `js/data.js` | The 25 records (generated from `data/cartridges.jsonl`) |
| `js/format.js` | Symbols, units, angles, tolerances, metadata, search/filter |
| `js/geometry.js` | Outer profile, bullet, section walls, pocket, missing-value notes |
| `js/drawing.js` | SVG, dimension lines, label placement, title block |
| `js/app.js` | List, detail, hash routing |
| `tests/unit`, `tests/e2e` | Node test runner; Chromium tests through Playwright |
| `openspec/` | Specification of the change (proposal, specs, design, tasks) |

Scripts are plain browser scripts (no modules, because Chromium blocks module scripts and `fetch` on
`file://`); each also exports for Node so the tests run the real code.

## Development

Only the tests need tools (`npm install`, dev dependency: Playwright).

```
npm test            # unit tests (Node 22, no browser)
npm run test:e2e    # Chromium: file://, search, routing, label overlaps, A4 print page count
npm run test:all
npm run build:data  # regenerate js/data.js after editing data/cartridges.jsonl
```

The e2e tests need Chromium (`npx playwright install chromium`) with its system libraries and at
least one font installed.

## Decisions worth knowing

- Fields not named in the brief (S, Fe, deltaL, u, G, Z, F, b, h, s, r, L4, L5, G2) are shown in mm; angle fields show unit `deg`; `N` has no unit.
- Water capacity `grH2O` is shown as `gr H2O`; a record without one shows "not published".
- The count text follows the brief literally ("1 cartridges").
- The title block scale is the scale at A4 print width (the drawing is capped at 120 mm height in print).
- If a value a drawing rule needs is missing the feature is left out and listed under the drawing.
