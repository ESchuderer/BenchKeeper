(function () {
  'use strict';

  var Format = window.CipFormat;
  var Drawing = window.CipDrawing;
  var DATA = window.CIP_DATA;
  var FAMILIES = ['all', 'rimless', 'rimmed', 'belted', 'pistol', 'rimfire'];
  var main = document.getElementById('main');
  var state = { query: '', family: 'all' };
  var firstRender = true;

  function h(tag, attrs, children) {
    var el = document.createElement(tag);
    Object.keys(attrs || {}).forEach(function (k) {
      if (attrs[k] === false || attrs[k] == null) return;
      el.setAttribute(k, attrs[k] === true ? '' : attrs[k]);
    });
    [].concat(children == null ? [] : children).forEach(function (c) {
      el.appendChild(typeof c === 'string' ? document.createTextNode(c) : c);
    });
    return el;
  }

  function lengthL3(record) {
    var rows = Format.sectionRows(record.cartridge.lengths);
    var l3 = rows.filter(function (r) { return r.field === 'L3'; })[0];
    return l3 ? l3.valueText + ' ' + l3.unit : '\u2014';
  }

  function detailHref(record) { return '#/cartridge/' + encodeURIComponent(record.key); }

  /* ---------- list ---------- */

  function renderList() {
    document.title = 'Cartridges \u2013 C.I.P. cartridge database';
    var search = h('input', { id: 'search', type: 'search', autocomplete: 'off', spellcheck: 'false', value: state.query });
    var family = h('select', { id: 'family' }, FAMILIES.map(function (f) {
      return h('option', { value: f, selected: f === state.family }, f === 'all' ? 'All' : f);
    }));
    var count = h('p', { id: 'count', class: 'count', role: 'status' });
    var tbody = h('tbody');
    var table = h('table', { class: 'list', 'aria-label': 'Cartridges' }, [
      h('thead', null, h('tr', null, [
        h('th', { scope: 'col' }, 'Name'), h('th', { scope: 'col' }, 'Family'),
        h('th', { scope: 'col', class: 'num' }, 'Case length L3')
      ])),
      tbody
    ]);
    var empty = h('p', { class: 'empty', hidden: true }, 'No cartridge matches.');

    function update() {
      var list = Format.filterCartridges(DATA, state);
      tbody.textContent = '';
      list.forEach(function (r) {
        tbody.appendChild(h('tr', null, [
          h('td', null, h('a', { href: detailHref(r) }, r.name)),
          h('td', null, r.family),
          h('td', { class: 'num' }, lengthL3(r))
        ]));
      });
      count.textContent = list.length + ' cartridges';
      table.hidden = list.length === 0;
      empty.hidden = list.length !== 0;
    }

    search.addEventListener('input', function () { state.query = search.value; update(); });
    family.addEventListener('change', function () { state.family = family.value; update(); });

    var view = h('div', { class: 'view-list' }, [
      h('h1', { id: 'page-title', tabindex: '-1' }, 'Cartridges'),
      h('form', { class: 'filters', role: 'search', 'aria-label': 'Filter cartridges' }, [
        h('div', { class: 'field' }, [h('label', { for: 'search' }, 'Search'), search]),
        h('div', { class: 'field' }, [h('label', { for: 'family' }, 'Family'), family])
      ]),
      count, table, empty
    ]);
    view.querySelector('form').addEventListener('submit', function (e) { e.preventDefault(); });
    mount(view);
    update();
  }

  /* ---------- detail ---------- */

  function metaList(record) {
    var dl = h('dl', { class: 'meta' });
    Format.metaRows(record).forEach(function (row) {
      var dd = h('dd', null, row.text);
      if (row.url && /^https?:\/\//.test(row.url)) {
        dd.appendChild(document.createTextNode(', source '));
        dd.appendChild(h('a', { href: row.url, rel: 'noopener noreferrer' }, row.source));
        if (row.note) dd.appendChild(h('span', { class: 'note' }, ' (' + row.note + ')'));
      }
      dl.appendChild(h('dt', null, row.label));
      dl.appendChild(dd);
    });
    return dl;
  }

  function drawingBlock(record) {
    var result = Drawing.buildDrawing(record);
    var figure = h('figure', { class: 'drawing' });
    if (result.svg) {
      figure.innerHTML = result.svg;
    } else {
      figure.appendChild(h('p', { class: 'drawing-missing' }, 'Drawing not available.'));
    }
    var block = h('section', { class: 'drawing-section', 'aria-labelledby': 'drawing-heading' }, [
      h('h2', { id: 'drawing-heading' }, 'Drawing'), figure
    ]);
    if (result.notes.length) {
      block.appendChild(h('ul', { class: 'drawing-notes', 'aria-label': 'Values missing from the drawing' },
        result.notes.map(function (n) { return h('li', null, n); })));
    }
    return block;
  }

  function valueTables(record) {
    var wrap = h('div', { class: 'values' });
    Format.GROUPS.forEach(function (group) {
      var sections = Format.detailSections(record).filter(function (s) { return s.group === group.id; });
      var tables = h('div', { class: 'tables' });
      sections.forEach(function (s) {
        var headingId = s.id + '-h';
        tables.appendChild(h('section', { class: 'value-section' }, [
          h('h3', { id: headingId }, s.title),
          h('table', { class: 'values-table', 'aria-labelledby': headingId }, [
            h('thead', null, h('tr', null, [
              h('th', { scope: 'col' }, 'Symbol'), h('th', { scope: 'col', class: 'num' }, 'Value'), h('th', { scope: 'col' }, 'Unit')
            ])),
            h('tbody', null, s.rows.map(function (r) {
              var value = h('td', { class: 'num' }, r.value);
              if (r.tolerance) value.appendChild(h('span', { class: 'tol', title: 'Tolerance' }, ' ' + r.tolerance));
              return h('tr', null, [h('td', { class: 'sym' }, r.symbol), value, h('td', { class: 'unit' }, r.unit)]);
            }))
          ])
        ]));
      });
      wrap.appendChild(h('section', { class: 'value-group', 'aria-labelledby': group.id + '-heading' }, [
        h('h2', { id: group.id + '-heading' }, group.title), tables
      ]));
    });
    return wrap;
  }

  function renderDetail(record) {
    document.title = record.name + ' \u2013 C.I.P. cartridge database';
    var printButton = h('button', { type: 'button', class: 'print-button' }, 'Print');
    printButton.addEventListener('click', function () { window.print(); });
    var view = h('article', { class: 'view-detail' }, [
      h('div', { class: 'toolbar no-print' }, [h('a', { href: '#/', class: 'back' }, 'All cartridges'), printButton]),
      h('header', { class: 'sheet-header' }, [
        h('h1', { id: 'page-title', tabindex: '-1' }, record.name),
        h('p', { class: 'sheet-sub' }, 'C.I.P. cartridge and chamber dimensions')
      ]),
      metaList(record),
      drawingBlock(record),
      valueTables(record),
      h('footer', { class: 'source' }, 'Source: C.I.P. TDCC, revised ' + record.revised)
    ]);
    mount(view);
  }

  function renderNotFound() {
    document.title = 'Not found \u2013 C.I.P. cartridge database';
    mount(h('div', null, [
      h('h1', { id: 'page-title', tabindex: '-1' }, 'Cartridge not found'),
      h('p', null, 'There is no cartridge with this address.'),
      h('p', null, h('a', { href: '#/' }, 'All cartridges'))
    ]));
  }

  /* ---------- routing ---------- */

  function mount(view) {
    main.textContent = '';
    main.appendChild(view);
    window.scrollTo(0, 0);
    if (!firstRender) {
      var title = document.getElementById('page-title');
      if (title) title.focus({ preventScroll: true });
    }
    firstRender = false;
  }

  function route() {
    var match = /^#\/cartridge\/([^/?]+)$/.exec(window.location.hash);
    if (match) {
      var key;
      try { key = decodeURIComponent(match[1]); } catch (e) { key = null; }
      var record = DATA.filter(function (r) { return r.key === key; })[0];
      if (record) renderDetail(record); else renderNotFound();
    } else if (window.location.hash === '' || window.location.hash === '#' || window.location.hash === '#/') {
      renderList();
    } else {
      renderNotFound();
    }
  }

  window.addEventListener('hashchange', route);
  route();
})();
