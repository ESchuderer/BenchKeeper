(function (root, factory) {
  'use strict';
  if (typeof module === 'object' && module.exports) module.exports = factory(require('./format.js'), require('./geometry.js'));
  else root.CipDrawing = factory(root.CipFormat, root.CipGeometry);
})(typeof window !== 'undefined' ? window : globalThis, function (Format, Geometry) {
  'use strict';

  // 1 user unit = 1 mm. x = z (axis, head on the left); y = -r in the outside view (upper half), +r in the section (lower half).

  var FS = 2.4;                 // label font size in user units
  var CW = 0.6 * FS;            // character width of the monospace label font
  var ARROW = 1.5;              // arrowhead length
  var LANE = 4.7;               // spacing of the length dimension lines
  var DIA_LANE = 3.0;           // spacing of the diameter dimension lines
  var BAND = 1.25 * FS + 0.9;   // spacing of the label bands below the section
  var MARGIN = 3;
  var PRINT_WIDTH_MM = 190;
  var PRINT_MAX_HEIGHT_MM = 120;
  var PAD = 0.15;

  function r3(x) { return Math.round(x * 1000) / 1000; }
  function esc(s) {
    return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  }
  function pts(list) { return list.map(function (p) { return r3(p[0]) + ',' + r3(p[1]); }).join(' '); }

  function rawValue(record, field) {
    var sections = record.cartridge || {};
    var keys = Object.keys(sections);
    for (var i = 0; i < keys.length; i++) {
      if (Object.prototype.hasOwnProperty.call(sections[keys[i]], field)) return sections[keys[i]];
    }
    return null;
  }

  function labelText(record, field) {
    var sec = rawValue(record, field);
    var row = Format.sectionRows(sec).filter(function (r) { return r.field === field; })[0];
    return Format.symbolFor(field) + ' ' + row.valueText;
  }

  function rectsIntersect(a, b) {
    return a.x < b.x + b.w && b.x < a.x + a.w && a.y < b.y + b.h && b.y < a.y + a.h;
  }

  function segmentHitsRect(s, rect) {
    var x1 = s[0], y1 = s[1], x2 = s[2], y2 = s[3];
    var xmin = rect.x, xmax = rect.x + rect.w, ymin = rect.y, ymax = rect.y + rect.h;
    var t0 = 0, t1 = 1, dx = x2 - x1, dy = y2 - y1;
    var p = [-dx, dx, -dy, dy], q = [x1 - xmin, xmax - x1, y1 - ymin, ymax - y1];
    for (var i = 0; i < 4; i++) {
      if (p[i] === 0) { if (q[i] < 0) return false; } else {
        var t = q[i] / p[i];
        if (p[i] < 0) { if (t > t1) return false; if (t > t0) t0 = t; } else { if (t < t0) return false; if (t < t1) t1 = t; }
      }
    }
    return true;
  }

  function Canvas() {
    this.segments = [];
    this.labels = [];
    this.parts = { section: [], outline: [], edges: [], centre: [], dims: [], text: [] };
  }
  Canvas.prototype.seg = function (x1, y1, x2, y2) { this.segments.push([x1, y1, x2, y2]); };
  Canvas.prototype.poly = function (list, cls, part) {
    for (var i = 1; i < list.length; i++) this.seg(list[i - 1][0], list[i - 1][1], list[i][0], list[i][1]);
    this.parts[part || 'outline'].push('<polyline class="' + cls + '" points="' + pts(list) + '"/>');
  };
  Canvas.prototype.line = function (x1, y1, x2, y2, cls, part) {
    this.seg(x1, y1, x2, y2);
    this.parts[part || 'dims'].push('<line class="' + cls + '" x1="' + r3(x1) + '" y1="' + r3(y1) + '" x2="' + r3(x2) + '" y2="' + r3(y2) + '"/>');
  };
  // Arrowhead with its tip at (x, y); (dx, dy) is the unit vector from the tip back along the dimension line.
  Canvas.prototype.arrow = function (x, y, dx, dy) {
    var bx = x + dx * ARROW, by = y + dy * ARROW, nx = -dy * ARROW * 0.17, ny = dx * ARROW * 0.17;
    this.seg(x, y, bx + nx, by + ny); this.seg(x, y, bx - nx, by - ny); this.seg(bx + nx, by + ny, bx - nx, by - ny);
    this.parts.dims.push('<path class="arrowhead" d="M' + r3(x) + ' ' + r3(y) + 'L' + r3(bx + nx) + ' ' + r3(by + ny) + 'L' + r3(bx - nx) + ' ' + r3(by - ny) + 'Z"/>');
  };
  Canvas.prototype.labelRect = function (text, x, baseline, anchor) {
    var w = text.length * CW;
    var x0 = anchor === 'middle' ? x - w / 2 : anchor === 'end' ? x - w : x;
    return { x: x0, y: baseline - 0.95 * FS, w: w, h: 1.25 * FS };
  };
  Canvas.prototype.free = function (rect, skipSegments) {
    var padded = { x: rect.x - PAD, y: rect.y - PAD, w: rect.w + 2 * PAD, h: rect.h + 2 * PAD };
    var i;
    for (i = 0; i < this.labels.length; i++) if (rectsIntersect(padded, this.labels[i].rect)) return false;
    for (i = 0; i < this.segments.length; i++) {
      if (skipSegments && skipSegments.indexOf(this.segments[i]) >= 0) continue;
      if (segmentHitsRect(this.segments[i], padded)) return false;
    }
    return true;
  };
  Canvas.prototype.addLabel = function (symbol, text, x, baseline, anchor, rect) {
    this.labels.push({ symbol: symbol, text: text, x: x, y: baseline, anchor: anchor, rect: rect });
    this.parts.text.push('<text class="dim-label" data-symbol="' + esc(symbol) + '" x="' + r3(x) + '" y="' + r3(baseline) +
      '" text-anchor="' + anchor + '">' + esc(text) + '</text>');
  };
  // Tries the candidates in order; returns true when a free position was found.
  Canvas.prototype.place = function (symbol, text, candidates) {
    for (var i = 0; i < candidates.length; i++) {
      var c = candidates[i];
      var rect = this.labelRect(text, c.x, c.y, c.anchor);
      var own = c.own || [];
      if (this.free(rect, own)) {
        this.addLabel(symbol, text, c.x, c.y, c.anchor, rect);
        if (c.leader) this.line(c.leader[0], c.leader[1], c.leader[2], c.leader[3], 'leader');
        return true;
      }
    }
    return false;
  };

  function outerRadius(G) {
    var m = 0;
    G.outer.forEach(function (p) { if (p[1] > m) m = p[1]; });
    return m;
  }

  function drawProfiles(cv, G, key) {
    var up = function (p) { return [p[0], -p[1]]; };
    var down = function (p) { return [p[0], p[1]]; };
    var b = G.bullet, s = G.section;
    var L3 = G.vals.L3, H2r = G.vals.H2 / 2;

    var upper = G.outer.map(up);
    var lower = G.outer.map(down);
    if (b) {
      var sr = b.exposed[0][1];
      if (Math.abs(sr - H2r) > 1e-9) { upper.push([L3, -sr]); }
      b.exposed.slice(1).forEach(function (p) { upper.push(up(p)); });
    }
    cv.poly(upper, 'outline case-outside');

    if (s) {
      cv.parts.section.push('<polygon class="hatch-case" fill="url(#hatch-' + key + ')" points="' + pts(s.polygon.map(down)) + '"/>');
      cv.parts.section.push('<polygon class="hatch-bullet" fill="url(#hatch-bullet-' + key + ')" points="' + pts(b.outline.map(down)) + '"/>');
      var lowerOuter = lower.slice();
      if (s.pocket) lowerOuter[0] = [0, s.pocket.diameter / 2];
      lowerOuter.push([L3, s.inner[s.inner.length - 1][1]]);
      cv.poly(lowerOuter, 'outline case-section');
      cv.poly([[s.w, 0]].concat(s.inner.map(down)), 'outline case-inner');
      if (s.pocket) cv.poly([[0, s.pocket.diameter / 2], [s.pocket.depth, s.pocket.diameter / 2], [s.pocket.depth, 0]].map(down), 'outline pocket');
      cv.poly(b.outline.map(down), 'outline bullet-section');
    } else {
      cv.poly(lower, 'outline case-section');
    }

    var seen = {};
    G.edges.forEach(function (e) {
      var k = Math.round(e.z * 1e4);
      if (e.z <= 1e-6 || e.z > L3 + 1e-6 && !b || (seen[k] !== undefined && seen[k] >= e.r)) return;
      seen[k] = e.r;
    });
    Object.keys(seen).forEach(function (k) {
      var z = k / 1e4;
      cv.line(z, 0, z, -seen[k], 'edge', 'edges');
    });
    cv.line(-3, 0, (b ? G.vals.L6 : L3) + 3, 0, 'centreline', 'centre');
    cv.parts.centre[0] = cv.parts.centre[0].replace('<line ', '<line stroke-dasharray="6 1.2 1 1.2" ');
  }

  function dimensions(cv, record, G) {
    var v = G.vals, rMax = outerRadius(G);
    var out = { top: [], left: [], right: [] };
    var L6 = G.bullet ? v.L6 : null;
    var rimTopZ = (G.outer.filter(function (p) { return Math.abs(p[1] - G.rim.rimR) < 1e-9; })[0] || [0])[0];
    var tipR = G.bullet ? G.bullet.m / 2 : 0;

    // Length dimensions from the head face, stacked above the outside view.
    var lengths = [{ f: 'R', z: v.R, from: [v.R, G.rim.rimR] }];
    if (G.bottleneck) {
      lengths.push({ f: 'L1', z: v.L1, from: [v.L1, v.P2 / 2] }, { f: 'L2', z: v.L2, from: [v.L2, v.H1 / 2] });
    }
    lengths.push({ f: 'L3', z: v.L3, from: [v.L3, v.H2 / 2] });
    if (L6) lengths.push({ f: 'L6', z: L6, from: [L6, tipR] });
    var headFaceR = G.outer[1] ? G.outer[1][1] : G.rim.rimR;
    var top0 = rMax + 4;
    lengths.forEach(function (d, i) { d.y = -(top0 + i * LANE); });
    var topMost = lengths[lengths.length - 1].y;
    cv.line(0, -headFaceR - 0.8, 0, topMost - 1.2, 'ext-line');
    lengths.forEach(function (d) {
      cv.line(d.from[0], -d.from[1] - 0.8, d.from[0], d.y - 1.2, 'ext-line');
      var small = d.z < 4 * ARROW;
      cv.line(small ? -ARROW : 0, d.y, small ? d.z + ARROW : d.z, d.y, 'dim-line');
      if (small) { cv.arrow(0, d.y, -1, 0); cv.arrow(d.z, d.y, 1, 0); } else { cv.arrow(0, d.y, 1, 0); cv.arrow(d.z, d.y, -1, 0); }
      out.top.push(d);
    });

    // Diameter dimensions: vertical lines left of the head and right of the bullet tip, smallest nearest.
    var left = [], right = [];
    if (G.rim.groove) left.push({ f: 'E1', d: v.E1, z: v.R });
    left.push({ f: 'P1', d: v.P1, z: G.rim.bodyStartZ }, { f: 'R1', d: v.R1, z: rimTopZ });
    if (G.bottleneck) {
      right.push({ f: 'P2', d: v.P2, z: v.L1 }, { f: 'H1', d: v.H1, z: v.L2 });
    }
    right.push({ f: 'H2', d: v.H2, z: v.L3 });
    if (G.bullet) right.push({ f: 'G1', d: v.G1, z: v.L3 });
    var byDia = function (a, b) { return a.d - b.d; };
    left.sort(byDia); right.sort(byDia);
    var xRight0 = (G.bullet ? v.L6 : v.L3) + 5;
    left.forEach(function (d, i) { d.x = -4.5 - i * DIA_LANE; d.side = 'left'; });
    right.forEach(function (d, i) { d.x = xRight0 + i * DIA_LANE; d.side = 'right'; });
    left.concat(right).forEach(function (d) {
      var dir = d.side === 'left' ? -1 : 1, h = d.d / 2;
      [-1, 1].forEach(function (sgn) { cv.line(d.z + dir * 0.8, sgn * h, d.x + dir * 1.0, sgn * h, 'ext-line'); });
      cv.line(d.x, -h, d.x, h, 'dim-line');
      cv.arrow(d.x, -h, 0, 1); cv.arrow(d.x, h, 0, -1);
    });
    out.left = left; out.right = right;
    out.rMax = rMax;
    return out;
  }

  function placeLengthLabels(cv, record, dims) {
    var failed = [];
    dims.top.forEach(function (d) {
      var text = labelText(record, d.f);
      var w = text.length * CW;
      var cands = [];
      if (d.f === 'R') {
        cands.push({ x: d.z + ARROW + 1.2, y: d.y - 1.2, anchor: 'start' });
      } else {
        var mid = d.z / 2, room = Math.max(0, d.z / 2 - w / 2 - 1);
        [0, 1, -1, 2, -2, 3, -3].forEach(function (k) {
          var off = Math.max(-room, Math.min(room, k * 3));
          cands.push({ x: mid + off, y: d.y - 1.2, anchor: 'middle' });
        });
      }
      cands.push({ x: -ARROW - 1.2, y: d.y + 0.35 * FS, anchor: 'end' });
      if (!cv.place(d.f, text, cands)) failed.push(d.f);
    });
    return failed;
  }

  function placeDiameterLabels(cv, record, dims) {
    var failed = [];
    var bottom0 = dims.rMax + 4.5;
    var order = [];
    var n = Math.max(dims.left.length, dims.right.length);
    for (var i = 0; i < n; i++) {
      if (dims.right[i]) order.push(dims.right[i]);
      if (dims.left[i]) order.push(dims.left[i]);
    }
    order.forEach(function (d) {
      var text = labelText(record, d.f);
      var inward = d.side === 'left' ? 1 : -1;
      var cands = [];
      for (var b = 0; b < 10; b++) {
        var yc = bottom0 + b * BAND;
        var base = yc + 0.35 * FS;
        var tail = [d.x, d.d / 2, d.x, yc];
        cands.push({ x: d.x + inward * 0.9, y: base, anchor: d.side === 'left' ? 'start' : 'end', leader: tail });
      }
      // the tail must stay clear of labels that are already placed
      var ok = false;
      for (var k = 0; k < cands.length && !ok; k++) {
        var c = cands[k];
        var tailRect = { x: d.x - 0.05, y: c.leader[1], w: 0.1, h: c.leader[3] - c.leader[1] };
        var clash = cv.labels.some(function (l) { return rectsIntersect(tailRect, l.rect); });
        if (clash) continue;
        ok = cv.place(d.f, text, [c]);
      }
      if (!ok) failed.push(d.f);
    });
    return failed;
  }

  function shoulderAngle(cv, record, G, dims) {
    var v = G.vals;
    if (!G.bottleneck || !rawValue(record, 'alpha')) return [];
    var half = v.alpha * Math.PI / 360;
    var cx = v.L1, cy = v.P2 / 2;
    var sLen = Math.hypot(v.L2 - v.L1, v.H1 / 2 - v.P2 / 2);
    var ra = Math.min(0.6 * sLen, 5);
    var da = ARROW / ra;
    var a0 = -half - da, a1 = da, steps = 24, arc = [];
    for (var i = 0; i <= steps; i++) {
      var a = a0 + (a1 - a0) * i / steps;
      arc.push([cx + ra * Math.cos(a), cy + ra * Math.sin(a)]);
    }
    cv.poly(arc, 'dim-line angle-arc', 'dims');
    cv.line(cx, cy, cx + ra + 2.5, cy, 'ext-line');
    cv.arrow(cx + ra, cy, 0, 1);
    var ex = cx + ra * Math.cos(-half), ey = cy + ra * Math.sin(-half);
    cv.arrow(ex, ey, Math.sin(-half), -Math.cos(-half));
    var mid = -half / 2;
    var mx = cx + ra * Math.cos(mid), my = cy + ra * Math.sin(mid);
    var text = labelText(record, 'alpha');
    var bottom0 = dims.rMax + 4.5, cands = [];
    for (var b = 0; b < 10; b++) {
      var yc = bottom0 + b * BAND;
      cands.push({ x: mx, y: yc + 0.35 * FS, anchor: 'middle', leader: [mx, my, mx, yc - 0.65 * FS] });
    }
    var done = false;
    for (var k = 0; k < cands.length && !done; k++) {
      var c = cands[k];
      var line = { x: mx - 0.05, y: my, w: 0.1, h: c.leader[3] - my };
      if (cv.labels.some(function (l) { return rectsIntersect(line, l.rect); })) continue;
      done = cv.place('alpha', text, [c]);
    }
    return done ? [] : ['alpha'];
  }

  function bounds(cv) {
    var b = { x0: Infinity, y0: Infinity, x1: -Infinity, y1: -Infinity };
    cv.segments.forEach(function (s) {
      b.x0 = Math.min(b.x0, s[0], s[2]); b.x1 = Math.max(b.x1, s[0], s[2]);
      b.y0 = Math.min(b.y0, s[1], s[3]); b.y1 = Math.max(b.y1, s[1], s[3]);
    });
    cv.labels.forEach(function (l) {
      b.x0 = Math.min(b.x0, l.rect.x); b.x1 = Math.max(b.x1, l.rect.x + l.rect.w);
      b.y0 = Math.min(b.y0, l.rect.y); b.y1 = Math.max(b.y1, l.rect.y + l.rect.h);
    });
    return b;
  }

  function formatScale(s) {
    return s >= 1 ? s.toFixed(1) + ':1' : '1:' + (1 / s).toFixed(1);
  }

  function titleBlock(cv, record, b, rMax) {
    var rowsOf = function (scaleText) {
      return [
        { t: record.name, big: true },
        { t: 'C.I.P. table ' + record.tab },
        { t: 'Revised ' + record.revised },
        { t: 'Dimensions in mm' },
        { t: scaleText }
      ];
    };
    var rows = rowsOf('Scale 99.9:1 (A4 print)');
    var width = Math.max.apply(null, rows.map(function (r) { return r.t.length * CW * (r.big ? 1.3 : 1); })) + 3;
    var lineH = 1.5 * FS, height = rows.length * lineH + 1.6;
    var spot = null, x, y;
    for (y = rMax + 3; y <= b.y1 + 3 && !spot; y += 0.8) {
      for (x = b.x1 - width; x >= b.x0 && !spot; x -= 1) {
        if (cv.free({ x: x - 1, y: y - 1, w: width + 2, h: height + 2 })) spot = { x: x, y: y };
      }
    }
    if (!spot) spot = { x: b.x1 - width, y: b.y1 + 3 };
    var x0 = Math.min(b.x0, spot.x), x1 = Math.max(b.x1, spot.x + width), y1 = Math.max(b.y1, spot.y + height);
    var W = x1 - x0 + 2 * MARGIN, H = y1 - b.y0 + 2 * MARGIN;
    var scale = Math.min(PRINT_WIDTH_MM / W, PRINT_MAX_HEIGHT_MM / H);
    rows = rowsOf('Scale ' + formatScale(scale) + ' (A4 print)');
    var out = ['<g class="title-block"><rect class="title-frame" x="' + r3(spot.x) + '" y="' + r3(spot.y) + '" width="' + r3(width) + '" height="' + r3(height) + '"/>'];
    rows.forEach(function (r, i) {
      out.push('<text class="' + (r.big ? 'title-name' : 'title-row') + '" x="' + r3(spot.x + 1.5) + '" y="' + r3(spot.y + 0.8 + (i + 0.78) * lineH) +
        '" font-size="' + (r.big ? r3(FS * 1.3) : FS) + '">' + esc(r.t) + '</text>');
    });
    out.push('</g>');
    return { svg: out.join(''), x0: x0, x1: x1, y1: y1, scale: scale, scaleText: rows[rows.length - 1].t };
  }

  function buildDrawing(record) {
    var G = Geometry.buildGeometry(record);
    var result = { ok: G.ok, notes: G.notes, geometry: G, svg: null, model: null };
    if (!G.ok) return result;
    var key = String(record.key).replace(/[^A-Za-z0-9_-]/g, '_');
    var cv = new Canvas();
    drawProfiles(cv, G, key);
    var dims = dimensions(cv, record, G);
    var failed = placeLengthLabels(cv, record, dims).concat(placeDiameterLabels(cv, record, dims)).concat(shoulderAngle(cv, record, G, dims));

    var b = bounds(cv);
    var tb = titleBlock(cv, record, b, dims.rMax);
    var x0 = tb.x0 - MARGIN, y0 = b.y0 - MARGIN, w = tb.x1 - tb.x0 + 2 * MARGIN, h = tb.y1 + MARGIN - y0;
    var name = record.name + ' drawing';
    var id = 'drawing-' + key;
    var desc = 'Half section of ' + record.name + ': outside view above the axis, section below. Dimensions in mm.' +
      (G.notes.length ? ' Not drawn: ' + G.notes.join('; ') + '.' : '');

    var svg = '<svg xmlns="http://www.w3.org/2000/svg" class="cartridge-drawing" role="img" aria-labelledby="' + id + '-title ' + id + '-desc"' +
      ' viewBox="' + r3(x0) + ' ' + r3(y0) + ' ' + r3(w) + ' ' + r3(h) + '" font-size="' + FS + '" preserveAspectRatio="xMidYMid meet">' +
      '<title id="' + id + '-title">' + esc(name) + '</title><desc id="' + id + '-desc">' + esc(desc) + '</desc>' +
      '<defs>' +
      '<pattern id="hatch-' + key + '" patternUnits="userSpaceOnUse" width="1" height="1" patternTransform="rotate(45)"><line class="hatch-line" x1="0" y1="0" x2="0" y2="1"/></pattern>' +
      '<pattern id="hatch-bullet-' + key + '" patternUnits="userSpaceOnUse" width="1.6" height="1.6" patternTransform="rotate(-45)"><line class="hatch-line" x1="0" y1="0" x2="0" y2="1.6"/></pattern>' +
      '</defs>' +
      '<g class="section">' + cv.parts.section.join('') + '</g>' +
      '<g class="edges">' + cv.parts.edges.join('') + '</g>' +
      '<g class="outlines">' + cv.parts.outline.join('') + '</g>' +
      '<g class="centre">' + cv.parts.centre.join('') + '</g>' +
      '<g class="dimensions">' + cv.parts.dims.join('') + cv.parts.text.join('') + '</g>' +
      tb.svg + '</svg>';

    result.svg = svg;
    result.model = {
      viewBox: [x0, y0, w, h], printScale: tb.scale, scaleText: tb.scaleText, labels: cv.labels, segments: cv.segments,
      unplaced: failed, fontSize: FS
    };
    return result;
  }

  return { buildDrawing: buildDrawing, rectsIntersect: rectsIntersect, segmentHitsRect: segmentHitsRect };
});
