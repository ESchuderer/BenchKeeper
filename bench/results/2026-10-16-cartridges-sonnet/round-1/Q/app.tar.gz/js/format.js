(function (root, factory) {
  'use strict';
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.CipFormat = factory();
})(typeof window !== 'undefined' ? window : globalThis, function () {
  'use strict';

  var SYMBOLS = {
    eMin: 'e min', r1Min: 'r1 min', r1Max: 'r1 max', alpha: '\u03b1', alpha1: '\u03b11',
    beta: '\u03b2', delta: '\u03b4', deltaL: 'delta L', L3PlusG: 'L3 + G'
  };
  var ANGLES = { alpha: 1, alpha1: 1, beta: 1, delta: 1, i: 1 };
  var UNITS = { Pmax: 'bar', PK: 'bar', PE: 'bar', EE: 'J', M: 'g', Q: 'mm\u00b2', N: '' };

  var SECTION_TITLES = {
    caseHead: 'Case head', collar: 'Collar', junctionCone: 'Junction cone', lengths: 'Lengths',
    misc: 'Misc', powderChamber: 'Powder chamber', pressures: 'Pressures', projectile: 'Projectile',
    barrel: 'Barrel', breech: 'Breech', grooves: 'Grooves', rifling: 'Rifling'
  };
  var GROUPS = [
    { id: 'cartridge', title: 'Cartridge values' },
    { id: 'chamber', title: 'Chamber values' }
  ];

  function symbolFor(field) {
    return Object.prototype.hasOwnProperty.call(SYMBOLS, field) ? SYMBOLS[field] : field;
  }

  function isAngleField(field) {
    return Object.prototype.hasOwnProperty.call(ANGLES, field);
  }

  function unitFor(field) {
    if (isAngleField(field)) return 'deg';
    return Object.prototype.hasOwnProperty.call(UNITS, field) ? UNITS[field] : 'mm';
  }

  function formatNumber(n) {
    return String(n);
  }

  function formatAngle(v) {
    if (v !== null && typeof v === 'object') {
      return formatNumber(v.degrees) + '\u00b0' + formatNumber(v.minutes) + "'" + formatNumber(v.seconds) + '"';
    }
    return formatNumber(v) + '\u00b0';
  }

  function formatTolerance(t) {
    return (t > 0 ? '+' : '') + formatNumber(t);
  }

  function sectionRows(section) {
    var rows = [];
    Object.keys(section).forEach(function (field) {
      if (/Tol$/.test(field) && Object.prototype.hasOwnProperty.call(section, field.slice(0, -3))) return;
      var raw = section[field];
      var value = isAngleField(field) ? formatAngle(raw) : formatNumber(raw);
      var tolKey = field + 'Tol';
      var tolerance = Object.prototype.hasOwnProperty.call(section, tolKey) ? formatTolerance(section[tolKey]) : '';
      rows.push({
        field: field,
        symbol: symbolFor(field),
        value: value,
        tolerance: tolerance,
        valueText: tolerance ? value + ' ' + tolerance : value,
        unit: unitFor(field)
      });
    });
    return rows;
  }

  function detailSections(record) {
    var out = [];
    GROUPS.forEach(function (group) {
      var sections = record[group.id] || {};
      Object.keys(sections).forEach(function (key) {
        var rows = sectionRows(sections[key]);
        if (rows.length === 0) return;
        out.push({
          group: group.id,
          groupTitle: group.title,
          id: group.id + '-' + key,
          title: SECTION_TITLES[key] || key,
          rows: rows
        });
      });
    });
    return out;
  }

  function metaRows(record) {
    var a = record.annotations || {};
    var cap = a.publishedCapacity;
    var rows = [
      { label: 'Alternative names', text: record.alternativeNames && record.alternativeNames.length ? record.alternativeNames.join('; ') : '\u2014' },
      { label: 'Family', text: record.family },
      { label: 'Category', text: a.category || '\u2014' },
      { label: 'Primer type', text: a.primerType || '\u2014' },
      { label: 'C.I.P. table', text: record.tab },
      { label: 'Country', text: record.country },
      { label: 'Published', text: record.published },
      { label: 'Revised', text: record.revised },
      { label: 'Pressure method', text: record.pressureMethod }
    ];
    if (cap) {
      rows.push({ label: 'Water capacity', text: formatNumber(cap.grH2O) + ' gr H2O', source: cap.source, url: cap.url, note: cap.note || '' });
    } else {
      rows.push({ label: 'Water capacity', text: 'not published' });
    }
    return rows;
  }

  function normalise(s) {
    return String(s).toLowerCase().replace(/\s+/g, '');
  }

  function filterCartridges(list, opts) {
    var q = normalise((opts && opts.query) || '');
    var family = (opts && opts.family) || 'all';
    return list.filter(function (r) {
      if (family !== 'all' && r.family !== family) return false;
      if (q === '') return true;
      return [r.name].concat(r.alternativeNames || []).some(function (n) { return normalise(n).indexOf(q) !== -1; });
    });
  }

  return {
    symbolFor: symbolFor, unitFor: unitFor, isAngleField: isAngleField, formatNumber: formatNumber,
    formatAngle: formatAngle, sectionRows: sectionRows, detailSections: detailSections,
    metaRows: metaRows, filterCartridges: filterCartridges, GROUPS: GROUPS
  };
});
