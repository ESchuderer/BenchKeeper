(function (root, factory) {
  'use strict';
  if (typeof module === 'object' && module.exports) module.exports = factory(require('./format.js'));
  else root.CipGeometry = factory(root.CipFormat);
})(typeof window !== 'undefined' ? window : globalThis, function (Format) {
  'use strict';

  // All points are [z, r]: z along the axis from the head face, r the radius.
  // The brief writes the same points as (r, z).

  var EPS = 1e-9;
  var ARC_STEP = Math.PI / 36;
  var NOSE_SEGMENTS = 48;
  var HEEL_TOLERANCE = 0.015;
  var PRIMER = {
    sp: { diameter: 4.45, depth: 3.04 }, spm: { diameter: 4.45, depth: 3.04 }, sr: { diameter: 4.45, depth: 3.04 },
    lp: { diameter: 5.33, depth: 3.04 }, lpm: { diameter: 5.33, depth: 3.04 },
    lr: { diameter: 5.33, depth: 3.3 }, lrm: { diameter: 5.33, depth: 3.3 }
  };
  var NOSE = {
    pointy: { seat: function () { return 1.0; }, k: function () { return 0.40; } },
    rounded: { seat: function (pistol) { return pistol ? 0.4 : 0.8; }, k: function (pistol) { return pistol ? 0.65 : 0.55; } },
    flat: { seat: function (pistol) { return pistol ? 0.4 : 0.8; }, k: function (pistol) { return pistol ? 0.70 : 0.60; } },
    semi_wadcutter: { seat: function () { return 0.6; }, k: function () { return 0.78; } }
  };

  function has(v) { return typeof v === 'number' && isFinite(v); }
  function rad(deg) { return deg * Math.PI / 180; }
  function angleDegrees(v) {
    if (v !== null && typeof v === 'object') return v.degrees + v.minutes / 60 + v.seconds / 3600;
    return v;
  }

  function flatten(record) {
    var vals = {};
    var cart = record.cartridge || {};
    Object.keys(cart).forEach(function (sec) {
      Object.keys(cart[sec]).forEach(function (f) {
        var v = cart[sec][f];
        vals[f] = Format.isAngleField(f) ? angleDegrees(v) : v;
      });
    });
    return vals;
  }

  function rimType(record) {
    if (record.family === 'belted') return 'belted';
    if (record.family === 'rimfire') return 'rimfire';
    var c = record.cartridge.caseHead, p = record.cartridge.powderChamber;
    var ratio = c.R1 / p.P1;
    if (ratio >= 1.05) return 'rimmed';
    if (ratio < 0.98) return 'rebated';
    return 'rimless';
  }

  function missingList(vals, names) {
    return names.filter(function (n) { return !has(vals[n]); });
  }

  function symbols(names) {
    return names.map(Format.symbolFor).join(', ');
  }

  function pushPoint(list, p) {
    var last = list[list.length - 1];
    if (last && Math.abs(last[0] - p[0]) < EPS && Math.abs(last[1] - p[1]) < EPS) return;
    list.push(p);
  }

  function fillet(a, b, c, radius, scale) {
    var u1 = [a[0] - b[0], a[1] - b[1]], u2 = [c[0] - b[0], c[1] - b[1]];
    var l1 = Math.hypot(u1[0], u1[1]), l2 = Math.hypot(u2[0], u2[1]);
    u1 = [u1[0] / l1, u1[1] / l1]; u2 = [u2[0] / l2, u2[1] / l2];
    var cosT = Math.max(-1, Math.min(1, u1[0] * u2[0] + u1[1] * u2[1]));
    var theta = Math.acos(cosT);
    var rr = radius * scale;
    var t = rr / Math.tan(theta / 2);
    var p = [b[0] + u1[0] * t, b[1] + u1[1] * t];
    var q = [b[0] + u2[0] * t, b[1] + u2[1] * t];
    var bis = [u1[0] + u2[0], u1[1] + u2[1]];
    var bl = Math.hypot(bis[0], bis[1]);
    var d = rr / Math.sin(theta / 2);
    var centre = [b[0] + bis[0] / bl * d, b[1] + bis[1] / bl * d];
    var a1 = Math.atan2(p[1] - centre[1], p[0] - centre[0]);
    var a2 = Math.atan2(q[1] - centre[1], q[0] - centre[0]);
    var sweep = a2 - a1;
    while (sweep > Math.PI) sweep -= 2 * Math.PI;
    while (sweep < -Math.PI) sweep += 2 * Math.PI;
    var n = Math.max(6, Math.ceil(Math.abs(sweep) / ARC_STEP));
    var pts = [];
    for (var i = 0; i <= n; i++) {
      var ang = a1 + sweep * i / n;
      pts.push([centre[0] + rr * Math.cos(ang), centre[1] + rr * Math.sin(ang)]);
    }
    return { points: pts, tangent: t, start: p, end: q };
  }

  function tangentLength(a, b, c, radius) {
    var u1 = [a[0] - b[0], a[1] - b[1]], u2 = [c[0] - b[0], c[1] - b[1]];
    var l1 = Math.hypot(u1[0], u1[1]), l2 = Math.hypot(u2[0], u2[1]);
    var cosT = Math.max(-1, Math.min(1, (u1[0] * u2[0] + u1[1] * u2[1]) / (l1 * l2)));
    return radius / Math.tan(Math.acos(cosT) / 2);
  }

  function lerpAt(poly, z) {
    for (var i = 1; i < poly.length; i++) {
      var a = poly[i - 1], b = poly[i];
      if (b[0] - a[0] > EPS && z >= a[0] - EPS && z <= b[0] + EPS) {
        return a[1] + (b[1] - a[1]) * (z - a[0]) / (b[0] - a[0]);
      }
    }
    return poly[poly.length - 1][1];
  }

  function buildHead(vals, type, notes, edges) {
    var R1 = vals.R1, R = vals.R, rimR = R1 / 2;
    var pts = [[0, 0]];
    var rimEndR = rimR;
    var rimEndZ = R;
    if (type === 'rimfire') {
      var rho = Math.min(R / 2, (R1 - vals.P1) / 2);
      if (rho > EPS) {
        var n = 24;
        for (var i = 0; i <= n; i++) {
          var phi = Math.PI * i / n;
          pushPoint(pts, [rho - rho * Math.cos(phi), (rimR - rho) + rho * Math.sin(phi)]);
        }
        edges.push({ z: rho, r: rimR });
        rimEndR = rimR - rho;
        rimEndZ = Math.max(R, 2 * rho);
        if (R > 2 * rho + EPS) pushPoint(pts, [R, rimEndR]);
      } else {
        pushPoint(pts, [0, rimR]); pushPoint(pts, [R, rimR]);
      }
    } else if (has(vals.beta) && has(vals.f) && vals.beta < 90) {
      var c = Math.min(vals.f * Math.tan(rad(vals.beta)), R1 / 4);
      pushPoint(pts, [0, rimR - c]);
      pushPoint(pts, [vals.f, rimR]);
      edges.push({ z: vals.f, r: rimR });
      pushPoint(pts, [R, rimR]);
    } else {
      var missing = missingList(vals, ['beta', 'f']);
      if (missing.length) notes.push(symbols(missing) + ' missing: head chamfer not drawn');
      pushPoint(pts, [0, rimR]);
      pushPoint(pts, [R, rimR]);
    }
    if (type !== 'rimfire' || R > 0) edges.push({ z: rimEndZ, r: rimEndR });
    return { pts: pts, rimEndR: rimEndR, rimEndZ: rimEndZ, rimR: rimR };
  }

  function buildGroove(vals, type, notes, pts, head) {
    var P1 = vals.P1, rimEndR = head.rimEndR, R = head.rimEndZ;
    var info = { bodyStartZ: R, rampEnd: null, grooveEndZ: null, groove: false, belt: false };
    var needed = ['E', 'E1', 'eMin'];
    var missing = missingList(vals, needed);
    if (type === 'rimfire') {
      pushPoint(pts, [R, P1 / 2]);
      return info;
    }
    if (missing.length === 0) {
      var E = vals.E, floorR = vals.E1 / 2, floorStart = vals.R, floorEnd = vals.R + vals.eMin;
      pushPoint(pts, [floorStart, rimEndR]);
      var beltOk = type === 'belted' && has(vals.R3) && has(vals.delta) && vals.delta > 0;
      if (type === 'belted' && !beltOk) {
        notes.push(symbols(missingList(vals, ['R3', 'delta'])) + ' missing: belt not drawn');
      }
      if (beltOk) {
        var dz = (vals.R3 / 2 - floorR) / Math.tan(rad(vals.delta));
        var rampEnd = floorEnd + dz;
        if (rampEnd > E + EPS) {
          notes.push('belt values inconsistent: belt not drawn');
        } else {
          pushPoint(pts, [floorStart, floorR]); pushPoint(pts, [floorEnd, floorR]);
          pushPoint(pts, [rampEnd, vals.R3 / 2]);
          pushPoint(pts, [E, vals.R3 / 2]);
          pushPoint(pts, [E, P1 / 2]);
          info.groove = true; info.belt = true; info.rampEnd = rampEnd; info.grooveEndZ = E; info.bodyStartZ = E;
          return info;
        }
      }
      if (E >= floorEnd - EPS) {
        pushPoint(pts, [floorStart, floorR]); pushPoint(pts, [floorEnd, floorR]);
        pushPoint(pts, [E, P1 / 2]);
        info.groove = true; info.grooveEndZ = E; info.bodyStartZ = E;
        return info;
      }
      notes.push('E, e min, R inconsistent: extractor groove not drawn');
    } else if (type !== 'rimmed' || missing.length < needed.length) {
      notes.push(symbols(missing) + ' missing: extractor groove not drawn');
    }
    pushPoint(pts, [R, P1 / 2]);
    info.bodyStartZ = R;
    return info;
  }

  function buildGeometry(record) {
    var vals = flatten(record);
    var notes = [];
    var a = record.annotations || {};
    var type = rimType(record);
    var result = { ok: false, name: record.name, vals: vals, rimType: type, notes: notes, bottleneck: false, heeled: false,
      outer: [], edges: [], bullet: null, section: null, shoulder: null, rim: null };

    var essential = missingList(vals, ['L3', 'P1', 'R1', 'R', 'H2']);
    if (essential.length) {
      notes.push(symbols(essential) + ' missing: drawing not available');
      return result;
    }

    var edges = result.edges;
    var head = buildHead(vals, type, notes, edges);
    var pts = head.pts;
    var rim = buildGroove(vals, type, notes, pts, head);
    rim.rimR = head.rimR;
    result.rim = rim;
    var bodyStartZ = rim.bodyStartZ;
    var P1r = vals.P1 / 2, H2r = vals.H2 / 2, L3 = vals.L3;
    edges.push({ z: bodyStartZ, r: Math.max(P1r, rim.rampEnd !== null ? vals.R3 / 2 : P1r) });

    var shoulderNeeded = ['alpha', 'L1', 'L2'];
    var anyShoulder = shoulderNeeded.some(function (n) { return has(vals[n]); });
    var shoulderMissing = missingList(vals, shoulderNeeded.concat(['P2', 'H1']));
    var bottleneck = !shoulderMissing.length && vals.L1 > bodyStartZ && vals.L2 > vals.L1 && L3 > vals.L2;
    if (!bottleneck && anyShoulder) {
      notes.push(shoulderMissing.length ? symbols(shoulderMissing) + ' missing: shoulder not drawn, case drawn straight'
        : 'L1, L2, L3 inconsistent: shoulder not drawn, case drawn straight');
    }
    result.bottleneck = bottleneck;

    if (bottleneck) {
      var A = [bodyStartZ, P1r], B = [vals.L1, vals.P2 / 2], C = [vals.L2, vals.H1 / 2], D = [L3, H2r];
      result.shoulder = { a: B, b: C, alpha: vals.alpha };
      var want1 = has(vals.r1Min) ? vals.r1Min : 0, want2 = has(vals.r2) ? vals.r2 : 0;
      if (!has(vals.r1Min)) notes.push('r1 min missing: body-side shoulder corner not rounded');
      if (!has(vals.r2)) notes.push('r2 missing: neck-side shoulder corner not rounded');
      var t1 = want1 ? tangentLength(A, B, C, want1) : 0;
      var t2 = want2 ? tangentLength(B, C, D, want2) : 0;
      var sLen = Math.hypot(C[0] - B[0], C[1] - B[1]);
      var scale = 1;
      if (t1 + t2 > 0.95 * sLen) scale = Math.min(scale, 0.95 * sLen / (t1 + t2));
      if (t1 > 0.95 * Math.hypot(B[0] - A[0], B[1] - A[1])) scale = Math.min(scale, 0.95 * Math.hypot(B[0] - A[0], B[1] - A[1]) / t1);
      if (t2 > 0.95 * Math.hypot(D[0] - C[0], D[1] - C[1])) scale = Math.min(scale, 0.95 * Math.hypot(D[0] - C[0], D[1] - C[1]) / t2);
      if (scale < 1) notes.push('r1 min, r2 reduced to fit the shoulder');
      if (want1) {
        var f1 = fillet(A, B, C, want1, scale);
        f1.points.forEach(function (p) { pushPoint(pts, p); });
        edges.push({ z: f1.start[0], r: f1.start[1] }, { z: f1.end[0], r: f1.end[1] });
      } else {
        pushPoint(pts, B);
        edges.push({ z: B[0], r: B[1] });
      }
      if (want2) {
        var f2 = fillet(B, C, D, want2, scale);
        f2.points.forEach(function (p) { pushPoint(pts, p); });
        edges.push({ z: f2.start[0], r: f2.start[1] }, { z: f2.end[0], r: f2.end[1] });
      } else {
        pushPoint(pts, C);
        edges.push({ z: C[0], r: C[1] });
      }
    }
    pushPoint(pts, [L3, H2r]);
    result.outer = pts;
    result.ok = true;

    buildBullet(record, result, vals, a);
    return result;
  }

  function buildBullet(record, result, vals, a) {
    var notes = result.notes;
    var missing = missingList(vals, ['G1', 'L6']);
    if (missing.length) {
      notes.push(symbols(missing) + ' missing: ' + (missing.indexOf('G1') >= 0 ? 'bullet and section walls not drawn' : 'bullet not drawn'));
      return;
    }
    var shape = a.defaultBulletShape;
    if (!NOSE[shape]) {
      notes.push('bullet shape missing: bullet not drawn');
      return;
    }
    var G1 = vals.G1, L3 = vals.L3, L6 = vals.L6, H2 = vals.H2, P1 = vals.P1;
    var category = a.category || (record.family === 'pistol' ? 'pistol' : record.family === 'rimfire' ? 'rimfire' : 'rifle');
    var pistol = category === 'pistol';
    var heeled = H2 - G1 <= HEEL_TOLERANCE;
    result.heeled = heeled;

    var tn = (H2 - G1) / 2;
    var tb = Math.min(Math.max(1.3 * tn, 0.6), 0.35 * P1 / 2);
    var shankR = heeled ? H2 / 2 : G1 / 2;
    var s = NOSE[shape].seat(pistol) * G1;
    var zb = L3 - s;
    var Lb = L6 - zb;
    if (!(Lb > 0)) {
      notes.push('L6 inconsistent with L3: bullet not drawn');
      return;
    }
    var k = NOSE[shape].k(pistol);
    var zn = zb + k * Lb;
    var n = L6 - zn;
    var m, rho = null, nose = [];
    if (shape === 'pointy') {
      m = Math.max(0.08 * G1, 1.27);
      var aa = shankR - m / 2;
      if (n > aa && aa > 0) {
        rho = (aa * aa + n * n) / (2 * aa);
        for (var i = 0; i <= NOSE_SEGMENTS; i++) {
          var z = zn + n * i / NOSE_SEGMENTS;
          var rr = (shankR - rho) + Math.sqrt(Math.max(0, rho * rho - (z - zn) * (z - zn)));
          nose.push([z, rr]);
        }
        nose[nose.length - 1] = [L6, m / 2];
      } else {
        nose = [[zn, shankR], [L6, m / 2]];
      }
    } else if (shape === 'rounded') {
      m = 0.15 * G1;
      var ar = shankR - m / 2;
      for (var j = 0; j <= NOSE_SEGMENTS; j++) {
        var th = (Math.PI / 2) * j / NOSE_SEGMENTS;
        nose.push([zn + n * Math.sin(th), m / 2 + ar * Math.cos(th)]);
      }
      nose[nose.length - 1] = [L6, m / 2];
    } else {
      m = (shape === 'flat' ? 0.55 : 0.6) * G1;
      nose = [[zn, shankR], [L6, m / 2]];
    }
    nose[0] = [zn, shankR];

    var heelR = H2 / 2 - tb;
    var body = heeled
      ? [[zb, heelR], [L3, heelR], [L3, H2 / 2], [zn, shankR]]
      : [[zb, shankR], [zn, shankR]];
    var outline = [[zb, 0]];
    body.forEach(function (p) { pushPoint(outline, p); });
    nose.forEach(function (p) { pushPoint(outline, p); });
    pushPoint(outline, [L6, 0]);

    var chain = [[zb, shankR]].concat(nose);
    var exposed = [[L3, heeled ? H2 / 2 : lerpAt(chain, L3)]];
    chain.forEach(function (p) { if (p[0] > L3 + EPS) pushPoint(exposed, p); });
    pushPoint(exposed, [L6, 0]);
    if (zn > L3 + EPS) result.edges.push({ z: zn, r: shankR });

    result.bullet = { shape: shape, pistol: pistol, shankR: shankR, s: s, zb: zb, Lb: Lb, k: k, zn: zn, n: n, m: m,
      rho: rho, nose: nose, outline: outline, exposed: exposed, heelR: heeled ? heelR : null };
    buildSection(result, vals, { tn: tn, tb: tb, zb: zb, heeled: heeled, type: result.rimType, record: record });
  }

  function buildSection(result, vals, p) {
    var notes = result.notes;
    var outer = result.outer, L3 = vals.L3, H2r = vals.H2 / 2;
    var tn = p.tn, tb = p.tb;
    var pocket = null;
    if (result.rimType !== 'rimfire') {
      var primer = ((p.record.annotations || {}).primerType);
      if (PRIMER[primer]) pocket = { diameter: PRIMER[primer].diameter, depth: PRIMER[primer].depth };
      else notes.push('primer type missing: primer pocket not drawn');
    }
    var w = Math.max(2.5, 0.25 * vals.P1 / 2);
    if (pocket) w = Math.max(w, pocket.depth + 1.5);
    if (result.rim.belt) w = Math.max(w, result.rim.rampEnd + tb);
    else if (result.rim.groove) w = Math.max(w, result.rim.grooveEndZ + tb);

    var tAt;
    if (p.heeled) tAt = function () { return tb; };
    else if (result.bottleneck) {
      var L1 = vals.L1, L2 = vals.L2;
      tAt = function (z) {
        if (z <= L1) return tb;
        if (z >= L2) return tn;
        return tb + (tn - tb) * (z - L1) / (L2 - L1);
      };
    } else {
      var zb = p.zb;
      tAt = function (z) {
        if (zb <= w || z >= zb) return tn;
        if (z <= w) return tb;
        return tb + (tn - tb) * (z - w) / (zb - w);
      };
    }

    var body = outer.filter(function (q) { return q[0] >= result.rim.bodyStartZ - EPS; });
    var zs = [w, L3];
    body.forEach(function (q) { zs.push(q[0]); });
    if (result.bottleneck) zs.push(vals.L1, vals.L2);
    if (!p.heeled && !result.bottleneck) zs.push(p.zb);
    zs = zs.filter(function (z) { return z >= w - EPS && z <= L3 + EPS; }).sort(function (x, y) { return x - y; });
    var inner = [];
    zs.forEach(function (z) {
      pushPoint(inner, [z, lerpAt(body, z) - tAt(z)]);
    });
    inner[inner.length - 1] = [L3, H2r - tAt(L3)];

    var poly = [];
    var startR = pocket ? pocket.diameter / 2 : 0;
    poly.push([0, startR]);
    outer.slice(1).forEach(function (q) { poly.push(q); });
    for (var i = inner.length - 1; i >= 0; i--) poly.push(inner[i]);
    poly.push([w, 0]);
    if (pocket) { poly.push([pocket.depth, 0]); poly.push([pocket.depth, startR]); }

    result.section = { tb: tb, tn: tn, w: w, pocket: pocket, inner: inner, polygon: poly, tAt: tAt };
  }

  return { buildGeometry: buildGeometry, rimType: rimType, angleDegrees: angleDegrees, flatten: flatten };
});
