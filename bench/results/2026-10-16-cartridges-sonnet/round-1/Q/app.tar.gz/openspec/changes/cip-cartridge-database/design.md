# Design

## Context

Greenfield folder. The app must open from `file://` in Chromium. Chromium blocks `fetch` and ES-module scripts on `file://`, so the data and code load as classic scripts.

## Goals / Non-Goals

**Goals:** offline static app; pure, unit-tested geometry; drawing verified in a real browser (label overlap, one-page print).

**Non-Goals:** editing data, unit conversion, fetching anything, a router library.

## Decisions

- **Classic scripts with a UMD wrapper.** `js/data.js` (generated from `data/cartridges.jsonl` by a dev script, with a sync test), `js/format.js`, `js/geometry.js`, `js/drawing.js`, `js/app.js`. Each module exports to `window.Cip*` in the browser and `module.exports` in Node, so `node --test` tests the real code.
- **Hash routing**: `#/` list, `#/cartridge/<key>`. Works from `file://` and survives reload. Unknown key shows a not-found message with a link back.
- **Geometry is pure**: `buildGeometry(record)` returns profiles (arrays of `[z, r]`), section polygons, feature points, `notes` (missing values) and `rim type`. `drawing.js` turns that into SVG markup and lays out dimensions. Coordinates in the brief are `(r, z)`; code keeps `[z, r]` and the tests name the mapping.
- **SVG mapping**: x = z, upper half y = -r (outside view), lower half y = +r (section). viewBox in mm. Fonts are in user units.
- **Scale text**: the title block states the scale at A4 print (the smaller of 190 mm / viewBox width and 120 mm / viewBox height; the print height cap keeps the page to one sheet), because on screen the scale follows the window.
- **Title block placement**: put in the first free spot below the section, found with the same collision test as the labels.
- **Print tables**: four CSS columns at 6.8 pt; measured slack of at least 15 mm on the fullest record.
- **Dimension layout**: length dimensions are stacked in lanes above the outside view (L-type above, with extension lines) and below the section; diameter dimensions are vertical lines to the right of the bullet tip, ordered small to large so extension lines do not cross. Label boxes are estimated from character counts; a Chromium test measures real `getBBox()` overlaps.
- **Unit rules**: all fields not listed in the brief (S, Fe, deltaL, u, G, Z, F, b, h, s, r, L4, L5...) are lengths in mm; angles show unit "deg"; N has no unit.
- **Straight case wall**: tb near the head, linear to tn at the bullet base `zb`, tn up to the mouth, so the seated bullet fits the bore exactly. Heeled case: tb over the full length.
- **Fillets**: tangent arcs, radius clamped when the tangent lengths do not fit; a clamp is reported as a note.
- **Rimfire half-round**: arc centred at `(z = rho, r = R1/2 - rho)`, then a straight rim face to `R` if `R > 2 rho`, then a step in to `P1/2`.
- **Rimfire/chamfer precedence**: rimfire takes the half-round even if beta and f exist.
- **"1 cartridges"**: the count text follows the brief literally.
- **Testing**: `node --test` for logic; Playwright (dev dependency) for Chromium checks on `file://`, if a browser can be installed.

## Risks / Trade-offs

- Label width estimation may differ per font; mitigated by a generous factor and the browser test.
- One-page A4 print needs dense tables (multi-column, small type); verified by PDF page count for all 25 records.
