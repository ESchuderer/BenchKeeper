# Proposal

## Why

Reloaders, gunsmiths and engineers need a dense, offline reference of C.I.P. cartridge and chamber dimensions with a true-to-scale drawing. The OpenBallistics database has the data but no printable, self-contained viewer. This change builds a static viewer for 25 supplied records.

## What Changes

- New static web app (`index.html`, CSS, classic JS) that runs from `file://` and from any static server; no framework, build step, server code or network request.
- List view with search by name/alternative names, family filter and a count.
- Detail view with record metadata, a computed 2D SVG drawing, and tables of all cartridge and chamber values grouped by section. Each detail view has a hash address.
- Print layout: one A4 portrait page, black on white.
- Light/dark theme following the system setting.

## Capabilities

### New Capabilities
- `cartridge-browser`: list, search, family filter, detail view, value formatting, routing, theming.
- `cartridge-drawing`: geometry rules and SVG rendering of the cartridge drawing, dimensions, title block and missing-value notes.
- `cartridge-print`: A4 portrait print layout of the detail view.

### Modified Capabilities

## Impact

New files only: `index.html`, `css/`, `js/` (data, format, geometry, drawing, app), `tests/`, `package.json` (dev dependencies only). The data are the 25 records of the brief, unchanged.
