## ADDED Requirements

### Requirement: Start page lists cartridges
The start page SHALL show the heading "Cartridges" and every cartridge with its name, family and case length L3. Each name SHALL be a link whose text is exactly the record's `name` and which opens the detail view.

#### Scenario: All records listed
- **WHEN** the start page opens
- **THEN** 25 links are shown, the text "25 cartridges" is shown, and the link "6,5 Creedmoor" exists

### Requirement: Search and family filter
A field labelled "Search" SHALL filter the list by name and alternative names while typing, ignoring case and whitespace. A select labelled "Family" with the options All, rimless, rimmed, belted, pistol, rimfire SHALL filter by family. The text "<n> cartridges" SHALL show the number listed.

#### Scenario: Alternative name
- **WHEN** the user types `7,62 x 51`
- **THEN** only "308 Win." is listed and "1 cartridges" is shown

#### Scenario: Family
- **WHEN** the user selects "belted"
- **THEN** "300 Win. Mag." and "7 mm Rem. Mag." are listed

### Requirement: Detail view
The detail view SHALL show the name as heading, alternative names, family, category, primer type, C.I.P. table, country, published and revised dates, pressure method and the published water capacity with its source link, the drawing, and tables of all cartridge and chamber values grouped by section with columns "Symbol", "Value" and "Unit". It SHALL offer a "Print" button and an "All cartridges" link. Its address SHALL be `#/cartridge/<key>` and survive reload.

#### Scenario: Tolerance beside value
- **WHEN** the 308 Win. detail view is open
- **THEN** the row L1 shows value `39.62 -0.2`, unit `mm`, and no row for L1Tol exists

#### Scenario: Angle formats
- **THEN** a plain angle is shown as `40°` and an angle object as `39°59'49"`

### Requirement: Values as published
Values SHALL be shown with a decimal point, no thousands separator, and as published (`4150 bar`, `6,5 Creedmoor`). Symbols are the field name except the documented mappings.

#### Scenario: Published form
- **THEN** 223 Rem. shows Pmax `4300` with unit `bar` and 6,5 Creedmoor keeps its comma

### Requirement: Offline operation
The app SHALL work from `file://` in Chromium and from a static server, with no network request and no runtime dependency.

#### Scenario: Opened from disk
- **WHEN** index.html is opened via file://
- **THEN** the list renders and no network request is made

### Requirement: Light and dark
The screen layout SHALL follow `prefers-color-scheme`; print SHALL always be light.

#### Scenario: Dark system setting
- **WHEN** the system prefers dark
- **THEN** the screen uses the dark palette; printing uses black on white
