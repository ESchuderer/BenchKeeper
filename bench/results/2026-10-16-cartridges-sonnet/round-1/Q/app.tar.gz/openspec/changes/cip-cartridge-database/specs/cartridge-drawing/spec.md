## ADDED Requirements

### Requirement: True-to-scale SVG
The drawing SHALL be an inline SVG named "<name> drawing" whose user unit is 1 mm, axis horizontal, head on the left, upper half outside view, lower half section with hatched cut walls, and a dash-dot centre line.

#### Scenario: Extents
- **WHEN** the 308 Win. drawing is built
- **THEN** the outline spans z = 0 to z = L6 = 71.12 and r up to R1/2

### Requirement: Geometry rules
The outer half-profile SHALL be built per rules 1 to 6 of the brief (rim type, head chamfer or half-round, extractor groove or belt, body, shoulder with fillets, neck), the bullet per rule 7 and section walls, solid head and primer pocket per rule 8.

#### Scenario: Rim type
- **THEN** family belted gives belted, rimfire gives rimfire, R1/P1 >= 1.05 rimmed, < 0.98 rebated, else rimless

#### Scenario: Heeled case
- **WHEN** H2 - G1 <= 0.015 (22 Long Rifle)
- **THEN** the exposed bullet has diameter H2 and the seated heel diameter H2 - 2*tb

### Requirement: Dimensions
The drawing SHALL carry dimension lines with arrowheads and extension lines for L3, L6, R1, R, P1 and, where published, P2, H1, H2, G1, L1, L2, E1 and the angle α, each labelled "<symbol> <value>". Labels SHALL NOT overlap each other or the outline.

#### Scenario: Dimension labels
- **THEN** the 308 Win. drawing has the label `L3 51.18` and labels for P2, H1, H2, G1, L1, L2, E1 and α

### Requirement: Title block
The drawing SHALL contain the name, C.I.P. table, revision date, "Dimensions in mm" and the scale.

#### Scenario: Title block
- **THEN** the drawing text contains the name, "I" as table, the revision date, "Dimensions in mm" and "Scale"

### Requirement: Missing values
If a value a rule needs is missing, the drawing SHALL omit that feature, SHALL state which value is missing next to the drawing, and SHALL NOT invent a number.

#### Scenario: Missing r1 min
- **WHEN** the 338 Lapua Mag. drawing is shown
- **THEN** a note names "r1 min" as missing and the body-side shoulder corner is not rounded
