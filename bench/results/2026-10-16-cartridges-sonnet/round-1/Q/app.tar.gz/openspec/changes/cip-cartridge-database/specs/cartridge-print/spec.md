## ADDED Requirements

### Requirement: A4 detail print
"Print" SHALL open the browser print dialog. A printed detail view SHALL be one A4 portrait page, black on white: a header with the name, the drawing at full width with legible labels, the tables, and a footer "C.I.P. TDCC, revised <date>". Navigation, search and buttons SHALL NOT print.

#### Scenario: One page
- **WHEN** any of the 25 detail views is printed to A4 portrait
- **THEN** the result is exactly one page
