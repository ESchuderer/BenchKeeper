# Tasks

## 1. Project and data

- [x] 1.1 package.json with dev dependencies only; data/cartridges.jsonl verbatim; script and test producing js/data.js
- [x] 1.2 Data tests: 25 records, unique keys, data.js in sync

## 2. Formatting (tests first)

- [x] 2.1 Tests and js/format.js: symbols, angles, tolerance, units, sections
- [x] 2.2 Tests and filter logic: search by name/alternative names, family

## 3. Geometry (tests first)

- [x] 3.1 Tests and js/geometry.js: rim type, head, groove/belt, body, shoulder, fillets, neck
- [x] 3.2 Bullet rules, heeled case
- [x] 3.3 Section walls, solid head, pocket
- [x] 3.4 Missing-value notes; all 25 records build

## 4. Drawing

- [x] 4.1 js/drawing.js: SVG, hatch, centre line, dimensions, labels, title block
- [x] 4.2 Label layout without overlaps (unit tests on boxes)

## 5. App

- [x] 5.1 index.html, css (screen light/dark, mobile), js/app.js: list, search, filter, count
- [x] 5.2 Detail view, routing by hash, print button, back link

## 6. Print

- [x] 6.1 Print CSS: one A4 page, black on white, footer

## 7. Verification

- [x] 7.1 Chromium test from file://: list, search, detail, drawing name, label overlaps, no network
- [x] 7.2 PDF page count = 1 for all 25 records
- [x] 7.3 Review (code-review-and-quality, security), README, openspec validate
