'use strict';
// Dev-only: regenerates js/data.js from data/cartridges.jsonl (the app itself has no build step).
const fs = require('node:fs');
const path = require('node:path');

const root = path.join(__dirname, '..');

function generate() {
  const lines = fs.readFileSync(path.join(root, 'data', 'cartridges.jsonl'), 'utf8')
    .split('\n').filter((l) => l.trim() !== '');
  const records = lines.map((l) => JSON.parse(l));
  const body = records.map((r) => '  ' + JSON.stringify(r)).join(',\n');
  return '/* Generated from data/cartridges.jsonl by scripts/build-data.js. Do not edit. */\n' +
    '(function (root) {\n  \'use strict\';\n  root.CIP_DATA = [\n' + body + '\n  ];\n})(typeof window !== \'undefined\' ? window : globalThis);\n';
}

if (require.main === module) {
  fs.writeFileSync(path.join(root, 'js', 'data.js'), generate());
  console.log('js/data.js written');
}
module.exports = { generate };
