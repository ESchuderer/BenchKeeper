'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const { indexUrl, launch, measureOverlaps } = require('./helpers');

require('../../js/data.js');
const DATA = globalThis.CIP_DATA;
const root = path.join(__dirname, '..', '..');

let browser;
test.before(async () => { browser = await launch(); });
test.after(async () => { await browser.close(); });

async function openPage(options) {
  const context = await browser.newContext(options);
  const page = await context.newPage();
  const problems = [];
  page.on('console', (m) => { if (['error', 'warning'].includes(m.type())) problems.push('console ' + m.type() + ': ' + m.text()); });
  page.on('pageerror', (e) => problems.push('pageerror: ' + e.message));
  const requests = [];
  page.on('request', (r) => requests.push(r.url()));
  return { context, page, problems, requests };
}

test('opened from disk: list, search, family filter and count', async () => {
  const { context, page, problems, requests } = await openPage();
  await page.goto(indexUrl);
  assert.equal(await page.getByRole('heading', { name: 'Cartridges', level: 1 }).count(), 1);
  assert.equal(await page.locator('table.list a').count(), 25);
  assert.equal(await page.getByText('25 cartridges').count(), 1);
  assert.equal(await page.getByRole('link', { name: '6,5 Creedmoor', exact: true }).count(), 1);
  assert.deepEqual(await page.getByLabel('Family').locator('option').allTextContents(),
    ['All', 'rimless', 'rimmed', 'belted', 'pistol', 'rimfire']);

  await page.getByLabel('Search').fill('7,62 x 51');
  assert.deepEqual(await page.locator('table.list a').allTextContents(), ['308 Win.']);
  assert.equal(await page.locator('#count').textContent(), '1 cartridges');

  await page.getByLabel('Search').fill('');
  await page.getByLabel('Family').selectOption('belted');
  assert.deepEqual(await page.locator('table.list a').allTextContents(), ['300 Win. Mag.', '7 mm Rem. Mag.']);
  assert.equal(await page.locator('#count').textContent(), '2 cartridges');
  await page.getByLabel('Family').selectOption('All');
  assert.equal(await page.locator('#count').textContent(), '25 cartridges');

  assert.deepEqual(requests.filter((u) => !u.startsWith('file://')), [], 'no network request');
  assert.deepEqual(problems, []);
  await context.close();
});

test('every list row shows name, family and L3', async () => {
  const { context, page } = await openPage();
  await page.goto(indexUrl);
  const row = page.locator('table.list tbody tr', { hasText: '308 Win.' });
  assert.deepEqual(await row.locator('td').allTextContents(), ['308 Win.', 'rimless', '51.18 mm']);
  await context.close();
});

test('detail view: address survives a reload, content and navigation', async () => {
  const { context, page, problems } = await openPage();
  await page.goto(indexUrl);
  await page.getByRole('link', { name: '308 Win.', exact: true }).click();
  assert.match(page.url(), /#\/cartridge\/308_win$/);
  await page.reload();
  assert.equal(await page.getByRole('heading', { level: 1 }).textContent(), '308 Win.');
  const meta = await page.locator('dl.meta').innerText();
  for (const t of ['308 Winchester; 7,62 x 51', 'rimless', 'rifle', 'lr', '1984-06-14', '2008-09-23', 'Transducer', '56 gr H2O']) {
    assert.ok(meta.includes(t), t);
  }
  assert.equal(await page.locator('dl.meta a').getAttribute('href'), 'http://kwk.us/cases.html');
  assert.equal(await page.getByRole('img', { name: '308 Win. drawing' }).count(), 1);

  const lengths = page.locator('table[aria-labelledby="chamber-lengths-h"], table[aria-labelledby="cartridge-lengths-h"]').first();
  assert.deepEqual(await lengths.locator('thead th').allTextContents(), ['Symbol', 'Value', 'Unit']);
  const l1 = lengths.locator('tbody tr').filter({ has: page.locator('td.sym', { hasText: /^L1$/ }) });
  assert.deepEqual(await l1.locator('td').allTextContents(), ['L1', '39.62 -0.2', 'mm']);
  assert.equal(await page.locator('td.sym', { hasText: /^L1Tol$/ }).count(), 0);
  assert.equal(await page.getByRole('button', { name: 'Print' }).count(), 1);
  assert.ok(await page.locator('td.num', { hasText: '4150' }).count() >= 1);
  assert.ok(await page.locator('td.num', { hasText: '71°25\'59"' }).count() >= 1);

  await page.getByRole('link', { name: 'All cartridges' }).click();
  await page.getByRole('heading', { name: 'Cartridges', level: 1 }).waitFor();
  await page.goto(indexUrl + '#/cartridge/nope');
  await page.getByRole('heading', { name: 'Cartridge not found', level: 1 }).waitFor();
  assert.deepEqual(problems, []);
  await context.close();
});

test('the Print button opens the print dialog', async () => {
  const { context, page } = await openPage();
  await page.addInitScript(() => { window.__printed = 0; window.print = () => { window.__printed++; }; });
  await page.goto(indexUrl + '#/cartridge/223_rem');
  await page.getByRole('button', { name: 'Print' }).click();
  assert.equal(await page.evaluate(() => window.__printed), 1);
  await context.close();
});

test('drawing labels never overlap each other or a line, in the real browser, for all 25', async () => {
  const { context, page } = await openPage({ viewport: { width: 1100, height: 900 } });
  for (const rec of DATA) {
    await page.goto(indexUrl + '#/cartridge/' + rec.key);
    await page.reload();
    const r = await page.evaluate(measureOverlaps);
    assert.ok(r.count >= 7, rec.name + ' labels');
    assert.deepEqual(r.problems, [], rec.name);
  }
  await context.close();
});

test('SVG user unit is 1 mm: case length in user units equals L3, bullet tip L6', async () => {
  const { context, page } = await openPage();
  await page.goto(indexUrl + '#/cartridge/308_win');
  const xs = await page.evaluate(() => {
    const pts = document.querySelector('polyline.case-outside').getAttribute('points').split(' ').map((p) => +p.split(',')[0]);
    return [Math.min(...pts), Math.max(...pts)];
  });
  assert.deepEqual(xs, [0, 71.12]);
  await context.close();
});

test('phone width: no horizontal scroll and the drawing fits the screen', async () => {
  const { context, page } = await openPage({ viewport: { width: 375, height: 700 }, hasTouch: true });
  for (const key of ['9_3_x_74_r', '308_win']) {
    await page.goto(indexUrl + '#/cartridge/' + key);
    const m = await page.evaluate(() => ({ sw: document.documentElement.scrollWidth, iw: window.innerWidth, w: document.querySelector('svg.cartridge-drawing').getBoundingClientRect().width }));
    assert.ok(m.sw <= m.iw, `scrollWidth ${m.sw} > ${m.iw}`);
    assert.ok(m.w <= m.iw);
  }
  await page.goto(indexUrl);
  assert.ok(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth));
  await context.close();
});

test('light and dark follow the system setting', async () => {
  const bg = async (scheme) => {
    const { context, page } = await openPage({ colorScheme: scheme });
    await page.goto(indexUrl);
    const c = await page.evaluate(() => getComputedStyle(document.body).backgroundColor);
    await context.close();
    return c;
  };
  assert.equal(await bg('light'), 'rgb(251, 251, 250)');
  assert.equal(await bg('dark'), 'rgb(20, 23, 26)');
});

test('works from a static file server too', async () => {
  const types = { '.html': 'text/html', '.js': 'text/javascript', '.css': 'text/css' };
  const server = http.createServer((req, res) => {
    const file = path.join(root, req.url === '/' ? 'index.html' : decodeURIComponent(req.url.split('?')[0]));
    if (!file.startsWith(root) || !fs.existsSync(file) || fs.statSync(file).isDirectory()) { res.writeHead(404); res.end(); return; }
    res.writeHead(200, { 'content-type': types[path.extname(file)] || 'application/octet-stream' });
    res.end(fs.readFileSync(file));
  });
  await new Promise((r) => server.listen(0, '127.0.0.1', r));
  const base = 'http://127.0.0.1:' + server.address().port;
  const { context, page, problems } = await openPage();
  await page.goto(base + '/#/cartridge/6_5_creedmoor');
  assert.equal(await page.getByRole('heading', { level: 1 }).textContent(), '6,5 Creedmoor');
  assert.deepEqual(problems, []);
  await context.close();
  await new Promise((r) => server.close(r));
});
