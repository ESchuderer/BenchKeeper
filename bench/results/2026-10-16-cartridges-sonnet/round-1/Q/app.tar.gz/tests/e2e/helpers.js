'use strict';
const path = require('node:path');
const { pathToFileURL } = require('node:url');
const { chromium } = require('playwright');

const indexUrl = pathToFileURL(path.join(__dirname, '..', '..', 'index.html')).href;

async function launch() {
  return chromium.launch();
}

// Geometry check in the browser: label boxes (getBBox, user units) against each other and against every drawn line.
const measureOverlaps = () => {
  const svg = document.querySelector('svg.cartridge-drawing');
  const texts = [...svg.querySelectorAll('text.dim-label')].map((t) => {
    const b = t.getBBox();
    return { text: t.textContent, x: b.x, y: b.y, w: b.width, h: b.height };
  });
  const segs = [];
  svg.querySelectorAll('line.ext-line, line.dim-line, line.leader, line.edge, line.centreline').forEach((l) => {
    segs.push([+l.getAttribute('x1'), +l.getAttribute('y1'), +l.getAttribute('x2'), +l.getAttribute('y2'), l.getAttribute('class')]);
  });
  svg.querySelectorAll('polyline').forEach((p) => {
    const pts = p.getAttribute('points').split(' ').map((s) => s.split(',').map(Number));
    for (let i = 1; i < pts.length; i++) segs.push([pts[i - 1][0], pts[i - 1][1], pts[i][0], pts[i][1], p.getAttribute('class')]);
  });
  const hits = (s, r) => {
    let t0 = 0, t1 = 1;
    const dx = s[2] - s[0], dy = s[3] - s[1];
    const p = [-dx, dx, -dy, dy], q = [s[0] - r.x, r.x + r.w - s[0], s[1] - r.y, r.y + r.h - s[1]];
    for (let i = 0; i < 4; i++) {
      if (p[i] === 0) { if (q[i] < 0) return false; } else {
        const t = q[i] / p[i];
        if (p[i] < 0) { if (t > t1) return false; if (t > t0) t0 = t; } else { if (t < t0) return false; if (t < t1) t1 = t; }
      }
    }
    return true;
  };
  const problems = [];
  texts.forEach((a, i) => {
    texts.slice(i + 1).forEach((b) => {
      if (a.x < b.x + b.w && b.x < a.x + a.w && a.y < b.y + b.h && b.y < a.y + a.h) problems.push(`${a.text} overlaps ${b.text}`);
    });
    // glyph box is tighter than the em box: shrink by 0.15 em vertically for the line test
    const inner = { x: a.x, y: a.y + a.h * 0.12, w: a.w, h: a.h * 0.76 };
    segs.forEach((s) => { if (hits(s, inner)) problems.push(`${a.text} touches ${s[4]}`); });
  });
  return { count: texts.length, problems };
};

module.exports = { indexUrl, launch, measureOverlaps };
