'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { indexUrl, launch } = require('./helpers');

require('../../js/data.js');
const DATA = globalThis.CIP_DATA;

let browser;
test.before(async () => { browser = await launch(); });
test.after(async () => { await browser.close(); });

const pageCount = (pdf) => (pdf.toString('latin1').match(/\/Type\s*\/Page[^s]/g) || []).length;

test('every detail view prints on exactly one A4 portrait page', async () => {
  const context = await browser.newContext({ colorScheme: 'dark' });
  const page = await context.newPage();
  for (const rec of DATA) {
    await page.goto(indexUrl + '#/cartridge/' + rec.key);
    await page.reload();
    const pdf = await page.pdf({ preferCSSPageSize: true, printBackground: true });
    assert.equal(pageCount(pdf), 1, rec.name + ' printed on ' + pageCount(pdf) + ' pages');
    const size = pdf.toString('latin1').match(/\/MediaBox\s*\[\s*0\s+0\s+([\d.]+)\s+([\d.]+)\s*\]/);
    assert.ok(Math.abs(size[1] - 595.28) < 1 && Math.abs(size[2] - 841.89) < 1, rec.name + ' media box ' + size.slice(1, 3));
  }
  await context.close();
});

test('print is black on white, without navigation, search or buttons; footer names the source', async () => {
  const context = await browser.newContext({ colorScheme: 'dark' });
  const page = await context.newPage();
  await page.goto(indexUrl + '#/cartridge/308_win');
  await page.emulateMedia({ media: 'print' });
  const info = await page.evaluate(() => {
    const visible = (sel) => [...document.querySelectorAll(sel)].some((e) => e.getClientRects().length > 0 && getComputedStyle(e).visibility !== 'hidden');
    const nonBlack = [...document.querySelectorAll('main *')].filter((e) => {
      const cs = getComputedStyle(e);
      return e.getClientRects().length && !e.closest('svg') && cs.color !== 'rgb(0, 0, 0)';
    }).length;
    const svg = document.querySelector('svg.cartridge-drawing');
    return {
      bg: getComputedStyle(document.body).backgroundColor, color: getComputedStyle(document.body).color,
      nav: visible('.site-header, .skip-link, .toolbar, a.back'), buttons: visible('button'), search: visible('#search, #family'),
      footer: document.querySelector('footer.source').textContent, footerVisible: visible('footer.source'),
      h1: visible('h1'), nonBlack, svgColor: getComputedStyle(svg).color,
      svgWidth: svg.getBoundingClientRect().width, mainWidth: document.querySelector('main').getBoundingClientRect().width
    };
  });
  assert.equal(info.bg, 'rgb(255, 255, 255)');
  assert.equal(info.color, 'rgb(0, 0, 0)');
  assert.equal(info.svgColor, 'rgb(0, 0, 0)');
  assert.equal(info.nonBlack, 0);
  assert.equal(info.nav || info.buttons || info.search, false);
  assert.equal(info.footer, 'Source: C.I.P. TDCC, revised 2008-09-23');
  assert.ok(info.footerVisible && info.h1);
  assert.ok(info.svgWidth > info.mainWidth * 0.9, `drawing ${info.svgWidth} of ${info.mainWidth}`);
  await context.close();
});
