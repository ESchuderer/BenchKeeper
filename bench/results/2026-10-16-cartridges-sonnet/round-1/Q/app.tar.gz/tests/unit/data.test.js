'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const { generate } = require('../../scripts/build-data.js');

const root = path.join(__dirname, '..', '..');

test('data.js is in sync with data/cartridges.jsonl', () => {
  assert.equal(fs.readFileSync(path.join(root, 'js', 'data.js'), 'utf8'), generate());
});

test('the dataset has 25 records with unique keys and names', () => {
  require('../../js/data.js');
  const data = globalThis.CIP_DATA;
  assert.equal(data.length, 25);
  assert.equal(new Set(data.map((r) => r.key)).size, 25);
  assert.equal(new Set(data.map((r) => r.name)).size, 25);
});

test('records are kept as published', () => {
  require('../../js/data.js');
  const byKey = Object.fromEntries(globalThis.CIP_DATA.map((r) => [r.key, r]));
  assert.equal(byKey['308_win'].cartridge.lengths.L3, 51.18);
  assert.deepEqual(byKey['308_win'].alternativeNames, ['308 Winchester', '7,62 x 51']);
  assert.equal(byKey['6_5_creedmoor'].name, '6,5 Creedmoor');
  assert.equal(byKey['243_win'].cartridge.pressures.Pmax, 4150);
  assert.deepEqual(byKey['223_rem'].chamber.rifling.i, { degrees: 3, minutes: 10, seconds: 36 });
  assert.equal(byKey['22_long_rifle'].family, 'rimfire');
  assert.deepEqual(globalThis.CIP_DATA.map((r) => r.family).reduce((a, f) => (a[f] = (a[f] || 0) + 1, a), {}),
    { rimless: 12, belted: 2, rimmed: 2, pistol: 6, rimfire: 3, });
});
