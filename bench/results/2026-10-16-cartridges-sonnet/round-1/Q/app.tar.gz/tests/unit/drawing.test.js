'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
require('../../js/data.js');
const D = require('../../js/drawing.js');
const byKey = Object.fromEntries(globalThis.CIP_DATA.map((r) => [r.key, r]));
const labelsOf = (d) => d.model.labels.map((l) => l.text);
const polylinePoints = (svg, cls) => {
  const m = svg.match(new RegExp('<polyline class="' + cls + '" points="([^"]+)"'));
  return m ? m[1].split(' ').map((p) => p.split(',').map(Number)) : null;
};

test('drawing is an inline SVG named "<name> drawing" with mm user units', () => {
  const d = D.buildDrawing(byKey['308_win']);
  assert.match(d.svg, /^<svg [^>]*role="img"/);
  assert.match(d.svg, /<title id="[^"]+">308 Win\. drawing<\/title>/);
  assert.match(d.svg, /aria-labelledby="drawing-308_win-title/);
  const outline = polylinePoints(d.svg, 'outline case-outside');
  const xs = outline.map((p) => p[0]);
  assert.equal(Math.min(...xs), 0);
  assert.equal(Math.max(...xs), 71.12);
  assert.equal(Math.max(...outline.map((p) => -p[1])), 12.01 / 2);
  assert.ok(outline.every((p) => p[1] <= 0), 'outside view is the upper half');
});

test('names are escaped in markup', () => {
  const d = D.buildDrawing(byKey['40_s_w']);
  assert.match(d.svg, /40 S\.&amp; W\. drawing/);
});

test('section half is hatched, with a dash-dot centre line', () => {
  const d = D.buildDrawing(byKey['308_win']);
  assert.match(d.svg, /<pattern id="hatch-308_win"/);
  assert.match(d.svg, /class="hatch-case" fill="url\(#hatch-308_win\)"/);
  assert.match(d.svg, /<line stroke-dasharray="[^"]+" class="centreline"/);
  const hatch = d.svg.match(/class="hatch-case"[^>]*points="([^"]+)"/)[1].split(' ').map((p) => p.split(',').map(Number));
  assert.ok(hatch.every((p) => p[1] >= 0), 'section is the lower half');
});

test('a bottleneck rimless case is dimensioned with L3, L6, R1, R, P1 and the optional values', () => {
  const l = labelsOf(D.buildDrawing(byKey['308_win']));
  ['L3 51.18', 'L6 71.12', 'R1 12.01', 'R 1.37', 'P1 11.96', 'P2 11.53 -0.2', 'H1 8.72', 'H2 8.72', 'G1 7.85',
    'L1 39.62 -0.2', 'L2 43.48 -0.2', 'E1 10.39', 'α 40°'].forEach((t) => assert.ok(l.includes(t), t + ' in ' + l.join('|')));
});

test('angle labels use degrees, minutes and seconds when published so', () => {
  assert.ok(labelsOf(D.buildDrawing(byKey['6_5_x_55_se'])).includes('α 50°35\'2"'));
});

test('straight and groove-less cases only carry published dimensions', () => {
  const luger = labelsOf(D.buildDrawing(byKey['9_mm_luger'])).map((t) => t.split(' ')[0]);
  ['L3', 'L6', 'R1', 'R', 'P1', 'H2', 'G1', 'E1'].forEach((s) => assert.ok(luger.includes(s), s));
  ['P2', 'H1', 'L1', 'L2', 'α'].forEach((s) => assert.ok(!luger.includes(s), s));
  const rimmed = labelsOf(D.buildDrawing(byKey['9_3_x_74_r'])).map((t) => t.split(' ')[0]);
  assert.ok(!rimmed.includes('E1'));
});

test('every dimension has arrowheads and extension lines', () => {
  const d = D.buildDrawing(byKey['308_win']);
  assert.ok((d.svg.match(/class="arrowhead"/g) || []).length >= 2 * 12);
  assert.ok((d.svg.match(/class="ext-line"/g) || []).length >= 12);
  assert.ok((d.svg.match(/class="dim-line"/g) || []).length >= 11);
});

test('title block carries name, table, revision date, unit note and scale', () => {
  const d = D.buildDrawing(byKey['308_win']);
  const block = d.svg.slice(d.svg.indexOf('<g class="title-block">'));
  ['>308 Win.<', '>C.I.P. table I<', '>Revised 2008-09-23<', '>Dimensions in mm<'].forEach((t) => assert.ok(block.includes(t), t));
  assert.match(block, />Scale \d+\.\d:1 \(A4 print\)</);
  const [, , vbWidth, vbHeight] = d.model.viewBox;
  assert.ok(Math.abs(d.model.printScale - Math.min(190 / vbWidth, 120 / vbHeight)) < 1e-9);
});

test('missing values are reported and not drawn', () => {
  const d = D.buildDrawing(byKey['338_lapua_mag']);
  assert.ok(d.notes.some((n) => /^r1 min missing/.test(n)));
  assert.match(d.svg, /Not drawn: r1 min missing/);
});

test('an unavailable drawing says why and has no markup', () => {
  const rec = JSON.parse(JSON.stringify(byKey['308_win']));
  delete rec.cartridge.powderChamber.P1;
  const d = D.buildDrawing(rec);
  assert.equal(d.ok, false);
  assert.equal(d.svg, null);
  assert.ok(d.notes.some((n) => /^P1 missing/.test(n)));
});

test('labels overlap neither each other nor any drawn line, for all 25 cartridges', () => {
  for (const rec of globalThis.CIP_DATA) {
    const d = D.buildDrawing(rec);
    assert.deepEqual(d.model.unplaced, [], rec.name + ' has unplaced labels');
    const labels = d.model.labels;
    for (let i = 0; i < labels.length; i++) {
      for (let j = i + 1; j < labels.length; j++) {
        assert.ok(!D.rectsIntersect(labels[i].rect, labels[j].rect), `${rec.name}: ${labels[i].text} overlaps ${labels[j].text}`);
      }
      const hit = d.model.segments.find((s) => D.segmentHitsRect(s, labels[i].rect));
      assert.equal(hit, undefined, `${rec.name}: ${labels[i].text} touches a line ${hit}`);
    }
  }
});

test('all 25 drawings stay inside their view box', () => {
  for (const rec of globalThis.CIP_DATA) {
    const d = D.buildDrawing(rec);
    const [x, y, w, h] = d.model.viewBox;
    for (const l of d.model.labels) {
      assert.ok(l.rect.x >= x && l.rect.x + l.rect.w <= x + w && l.rect.y >= y && l.rect.y + l.rect.h <= y + h, rec.name + ' ' + l.text);
    }
  }
});
