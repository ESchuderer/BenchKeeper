'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
require('../../js/data.js');
const F = require('../../js/format.js');
const byKey = Object.fromEntries(globalThis.CIP_DATA.map((r) => [r.key, r]));

test('symbols are the field name except the documented mappings', () => {
  assert.equal(F.symbolFor('L3'), 'L3');
  assert.equal(F.symbolFor('eMin'), 'e min');
  assert.equal(F.symbolFor('r1Min'), 'r1 min');
  assert.equal(F.symbolFor('r1Max'), 'r1 max');
  assert.equal(F.symbolFor('alpha'), 'α');
  assert.equal(F.symbolFor('alpha1'), 'α1');
  assert.equal(F.symbolFor('beta'), 'β');
  assert.equal(F.symbolFor('delta'), 'δ');
  assert.equal(F.symbolFor('deltaL'), 'delta L');
  assert.equal(F.symbolFor('L3PlusG'), 'L3 + G');
  assert.equal(F.symbolFor('Pmax'), 'Pmax');
});

test('angles show degrees or degrees, minutes and seconds', () => {
  assert.equal(F.formatAngle(40), '40°');
  assert.equal(F.formatAngle({ degrees: 39, minutes: 59, seconds: 49 }), '39°59\'49"');
  assert.equal(F.formatAngle({ degrees: 3, minutes: 10, seconds: 0 }), '3°10\'0"');
});

test('numbers use a decimal point and no thousands separator', () => {
  assert.equal(F.formatNumber(4150), '4150');
  assert.equal(F.formatNumber(51.18), '51.18');
  assert.equal(F.formatNumber(6.0), '6');
});

test('units follow the brief', () => {
  assert.equal(F.unitFor('L3'), 'mm');
  assert.equal(F.unitFor('R1'), 'mm');
  assert.equal(F.unitFor('Pmax'), 'bar');
  assert.equal(F.unitFor('PK'), 'bar');
  assert.equal(F.unitFor('PE'), 'bar');
  assert.equal(F.unitFor('EE'), 'J');
  assert.equal(F.unitFor('M'), 'g');
  assert.equal(F.unitFor('Q'), 'mm²');
  assert.equal(F.unitFor('N'), '');
  for (const a of ['alpha', 'alpha1', 'beta', 'delta', 'i']) assert.equal(F.unitFor(a), 'deg');
});

test('a tolerance is shown next to its value and never as a row', () => {
  const rows = F.sectionRows(byKey['308_win'].cartridge.lengths);
  assert.deepEqual(rows.map((r) => r.symbol), ['L1', 'L2', 'L3', 'L6']);
  const l1 = rows.find((r) => r.symbol === 'L1');
  assert.equal(l1.valueText, '39.62 -0.2');
  assert.equal(l1.value, '39.62');
  assert.equal(l1.tolerance, '-0.2');
  assert.equal(l1.unit, 'mm');
});

test('rows show angle objects in degrees, minutes and seconds', () => {
  const rows = F.sectionRows(byKey['223_rem'].chamber.rifling);
  assert.equal(rows.find((r) => r.symbol === 'i').valueText, '3°10\'36"');
  assert.equal(rows.find((r) => r.symbol === 'α1').valueText, '90°');
});

test('detail sections cover every value of cartridge and chamber and skip empty sections', () => {
  for (const rec of globalThis.CIP_DATA) {
    const sections = F.detailSections(rec);
    let expected = 0;
    for (const grp of ['cartridge', 'chamber']) {
      for (const sec of Object.values(rec[grp])) expected += Object.keys(sec).filter((k) => !k.endsWith('Tol')).length;
    }
    const got = sections.reduce((n, s) => n + s.rows.length, 0);
    assert.equal(got, expected, rec.name);
    assert.ok(sections.every((s) => s.rows.length > 0));
  }
});

test('metadata rows list the published facts', () => {
  const rows = F.metaRows(byKey['308_win']);
  const m = Object.fromEntries(rows.map((r) => [r.label, r]));
  assert.equal(m['Alternative names'].text, '308 Winchester; 7,62 x 51');
  assert.equal(m['Family'].text, 'rimless');
  assert.equal(m['Category'].text, 'rifle');
  assert.equal(m['Primer type'].text, 'lr');
  assert.equal(m['C.I.P. table'].text, 'I');
  assert.equal(m['Country'].text, 'US');
  assert.equal(m['Published'].text, '1984-06-14');
  assert.equal(m['Revised'].text, '2008-09-23');
  assert.equal(m['Pressure method'].text, 'Transducer');
  assert.equal(m['Water capacity'].text, '56 gr H2O');
  assert.equal(m['Water capacity'].url, 'http://kwk.us/cases.html');
  assert.equal(m['Water capacity'].source, 'kwk');
});

test('metadata states what is not published instead of inventing it', () => {
  const m = Object.fromEntries(F.metaRows(byKey['7_x_64']).map((r) => [r.label, r]));
  assert.equal(m['Water capacity'].text, 'not published');
  assert.equal(m['Alternative names'].text, '—');
});

test('search finds names and alternative names, ignoring case and spaces', () => {
  const all = globalThis.CIP_DATA;
  const names = (q, fam) => F.filterCartridges(all, { query: q, family: fam }).map((r) => r.name);
  assert.deepEqual(names('7,62 x 51'), ['308 Win.']);
  assert.deepEqual(names('7,62x51'), ['308 Win.']);
  assert.deepEqual(names('308 WINCHESTER'), ['308 Win.']);
  assert.deepEqual(names('creedmoor'), ['6,5 Creedmoor']);
  assert.equal(names('').length, 25);
  assert.deepEqual(names('zzz'), []);
});

test('family filter', () => {
  const all = globalThis.CIP_DATA;
  assert.equal(F.filterCartridges(all, { family: 'all' }).length, 25);
  assert.deepEqual(F.filterCartridges(all, { family: 'belted' }).map((r) => r.name), ['300 Win. Mag.', '7 mm Rem. Mag.']);
  assert.equal(F.filterCartridges(all, { family: 'rimfire', query: '22' }).length, 2);
});
