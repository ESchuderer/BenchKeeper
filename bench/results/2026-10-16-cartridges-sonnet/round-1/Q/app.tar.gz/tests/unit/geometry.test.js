'use strict';
// Coordinates in the brief are (r, z). The code and these tests use [z, r].
const test = require('node:test');
const assert = require('node:assert/strict');
require('../../js/data.js');
const Geo = require('../../js/geometry.js');
const byKey = Object.fromEntries(globalThis.CIP_DATA.map((r) => [r.key, r]));
const near = (a, b, eps = 1e-6) => assert.ok(Math.abs(a - b) <= eps, `${a} != ${b}`);
const has = (pts, z, r, eps = 1e-6) => pts.some((p) => Math.abs(p[0] - z) <= eps && Math.abs(p[1] - r) <= eps);
const clone = (o) => JSON.parse(JSON.stringify(o));
const without = (rec, section, field) => { const c = clone(rec); delete c.cartridge[section][field]; return c; };

test('rim type rules', () => {
  assert.equal(Geo.rimType(byKey['308_win']), 'rimless');
  assert.equal(Geo.rimType(byKey['300_win_mag']), 'belted');
  assert.equal(Geo.rimType(byKey['22_long_rifle']), 'rimfire');
  assert.equal(Geo.rimType(byKey['9_3_x_74_r']), 'rimmed');
  assert.equal(Geo.rimType(byKey['9_mm_luger']), 'rimless');
  const rebated = clone(byKey['9_mm_luger']); rebated.cartridge.caseHead.R1 = 9.0;
  assert.equal(Geo.rimType(rebated), 'rebated');
  const edge = clone(byKey['9_mm_luger']); edge.cartridge.caseHead.R1 = 9.93 * 1.05;
  assert.equal(Geo.rimType(edge), 'rimmed');
});

test('outer half-profile runs from the axis at the head face to the mouth', () => {
  const g = Geo.buildGeometry(byKey['308_win']);
  assert.deepEqual(g.outer[0], [0, 0]);
  assert.deepEqual(g.outer[g.outer.length - 1], [51.18, 8.72 / 2]);
  assert.ok(Math.max(...g.outer.map((p) => p[0])) <= 51.18 + 1e-9);
});

test('head chamfer: (R1/2 - min(f tan beta, R1/4), 0) to (R1/2, f), then up to (R1/2, R)', () => {
  const g = Geo.buildGeometry(byKey['308_win']);
  const c = 0.38 * Math.tan(35 * Math.PI / 180);
  assert.ok(has(g.outer, 0, 12.01 / 2 - c));
  assert.ok(has(g.outer, 0.38, 12.01 / 2));
  assert.ok(has(g.outer, 1.37, 12.01 / 2));
});

test('without beta or f the head corner is square and the missing value is reported', () => {
  const g = Geo.buildGeometry(without(byKey['308_win'], 'caseHead', 'f'));
  assert.ok(has(g.outer, 0, 12.01 / 2));
  assert.ok(g.notes.some((n) => /^f missing/.test(n)), g.notes.join('|'));
});

test('extractor groove: in to E1/2, floor e min long, ramp to (P1/2, E)', () => {
  const g = Geo.buildGeometry(byKey['308_win']);
  assert.ok(has(g.outer, 1.37, 10.39 / 2));
  assert.ok(has(g.outer, 1.37 + 1.4, 10.39 / 2));
  assert.ok(has(g.outer, 3.85, 11.96 / 2));
});

test('no groove published: step in from (R1/2, R) to (P1/2, R)', () => {
  const g = Geo.buildGeometry(byKey['9_3_x_74_r']);
  assert.ok(has(g.outer, 1.4, 13.35 / 2));
  assert.ok(has(g.outer, 1.4, 11.9 / 2));
  assert.ok(!g.notes.some((n) => /groove/.test(n)), 'a rimmed case has no groove by design');
});

test('belted: ramp at delta to the belt, along the belt to E, step in to P1/2', () => {
  const g = Geo.buildGeometry(byKey['300_win_mag']);
  const dz = (13.51 / 2 - 12.07 / 2) / Math.tan(35 * Math.PI / 180);
  assert.ok(has(g.outer, 1.27, 12.07 / 2));
  assert.ok(has(g.outer, 1.27 + 0.94, 12.07 / 2));
  assert.ok(has(g.outer, 1.27 + 0.94 + dz, 13.51 / 2));
  assert.ok(has(g.outer, 5.59, 13.51 / 2));
  assert.ok(has(g.outer, 5.59, 13.03 / 2));
  near(g.rim.rampEnd, 1.27 + 0.94 + dz);
});

test('rimfire rim edge is a half-round whose outermost point lies at R1/2', () => {
  const g = Geo.buildGeometry(byKey['22_long_rifle']);
  const rho = Math.min(1.09 / 2, (7.06 - 5.74) / 2);
  assert.ok(has(g.outer, 0, 7.06 / 2 - rho));
  assert.ok(has(g.outer, rho, 7.06 / 2));
  near(Math.max(...g.outer.map((p) => p[1])), 7.06 / 2);
  assert.ok(has(g.outer, 1.09, 5.74 / 2));
});

test('bottleneck without radii keeps the sharp shoulder points', () => {
  const g = Geo.buildGeometry(byKey['17_hmr']);
  assert.equal(g.bottleneck, true);
  assert.ok(has(g.outer, 22.2, 6.15 / 2));
  assert.ok(has(g.outer, 23.54, 4.9 / 2));
  assert.ok(has(g.outer, 27.03, 4.9 / 2));
  assert.ok(g.notes.some((n) => /r1 min/.test(n)));
  assert.ok(g.notes.some((n) => /r2/.test(n)));
});

test('shoulder corners are rounded with r1 min and r2 where published', () => {
  const g = Geo.buildGeometry(byKey['308_win']);
  assert.ok(!has(g.outer, 39.62, 11.53 / 2, 1e-3), 'body-side corner replaced by an arc');
  assert.ok(!has(g.outer, 43.48, 8.72 / 2, 1e-3), 'neck-side corner replaced by an arc');
  const near1 = Math.min(...g.outer.map((p) => Math.hypot(p[0] - 39.62, p[1] - 11.53 / 2)));
  assert.ok(near1 > 0.01 && near1 < 0.76);
  assert.ok(g.outer.length > 20);
  assert.ok(!g.notes.some((n) => /reduced/.test(n)));
});

test('missing r1 min leaves only the body-side corner sharp and says so', () => {
  const g = Geo.buildGeometry(byKey['338_lapua_mag']);
  assert.ok(has(g.outer, 54.9, 13.82 / 2));
  assert.ok(g.notes.some((n) => /^r1 min missing/.test(n)), g.notes.join('|'));
  assert.ok(!g.notes.some((n) => /^r2 missing/.test(n)));
});

test('a case without alpha, L1 or L2 is straight and runs to (H2/2, L3)', () => {
  const g = Geo.buildGeometry(byKey['9_mm_luger']);
  assert.equal(g.bottleneck, false);
  assert.deepEqual(g.outer[g.outer.length - 1], [19.15, 9.65 / 2]);
  assert.ok(has(g.outer, 2.98, 9.93 / 2));
  assert.deepEqual(g.notes, []);
});

test('pointy bullet: seat 1.0 G1, cylinder to 0.40 of the length, tangent ogive, meplat max(0.08 G1, 1.27)', () => {
  const g = Geo.buildGeometry(byKey['308_win']);
  const b = g.bullet;
  near(b.s, 7.85); near(b.zb, 51.18 - 7.85); near(b.Lb, 71.12 - b.zb);
  near(b.zn, b.zb + 0.4 * b.Lb);
  near(b.m, 1.27);
  const a = 7.85 / 2 - b.m / 2;
  const n = 71.12 - b.zn;
  const rho = (a * a + n * n) / (2 * a);
  near(b.rho, rho);
  const centre = [b.zn, 7.85 / 2 - rho];
  for (const p of b.nose) near(Math.hypot(p[0] - centre[0], p[1] - centre[1]), rho, 1e-6);
  assert.deepEqual(b.nose[0].map((x) => +x.toFixed(6)), [+b.zn.toFixed(6), 3.925]);
  const tip = b.nose[b.nose.length - 1];
  near(tip[0], 71.12); near(tip[1], b.m / 2, 1e-6);
});

test('rounded pistol bullet: seat 0.4 G1, cylinder 0.65, quarter ellipse, meplat 0.15 G1', () => {
  const g = Geo.buildGeometry(byKey['9_mm_luger']);
  const b = g.bullet;
  near(b.s, 0.4 * 9.03); near(b.m, 0.15 * 9.03);
  near(b.zn, b.zb + 0.65 * b.Lb);
  const tip = b.nose[b.nose.length - 1];
  near(tip[0], 29.69); near(tip[1], b.m / 2);
});

test('rounded rifle/rimfire bullet seats 0.8 G1 with cylinder 0.55', () => {
  const b = Geo.buildGeometry(byKey['22_win_mag_r_f']).bullet;
  near(b.s, 0.8 * 5.7);
  near(b.zn, b.zb + 0.55 * b.Lb);
});

test('flat and semi-wadcutter bullets are straight cones', () => {
  const f = Geo.buildGeometry(byKey['40_s_w']).bullet;
  near(f.s, 0.4 * 10.17); near(f.zn, f.zb + 0.7 * f.Lb); near(f.m, 0.55 * 10.17);
  assert.equal(f.nose.length, 2);
  const w = Geo.buildGeometry(byKey['357_magnum']).bullet;
  near(w.s, 0.6 * 9.12); near(w.zn, w.zb + 0.78 * w.Lb); near(w.m, 0.6 * 9.12);
  assert.equal(w.nose.length, 2);
});

test('heeled case: exposed bullet has the case OD, seated heel the case ID', () => {
  const g = Geo.buildGeometry(byKey['22_long_rifle']);
  assert.equal(g.heeled, true);
  near(g.bullet.shankR, 5.72 / 2);
  assert.ok(has(g.bullet.outline, g.bullet.zb, 5.72 / 2 - g.section.tb));
  assert.ok(has(g.bullet.outline, 15.57, 5.72 / 2));
  assert.equal(Geo.buildGeometry(byKey['22_win_mag_r_f']).heeled, false);
});

test('outside view hides the seated part', () => {
  const g = Geo.buildGeometry(byKey['308_win']);
  assert.ok(g.bullet.exposed.every((p) => p[0] >= 51.18 - 1e-9));
  assert.ok(g.bullet.outline.some((p) => p[0] < 51.18 - 1));
});

test('section walls, solid head and primer pocket', () => {
  const g = Geo.buildGeometry(byKey['308_win']);
  const s = g.section;
  near(s.tn, (8.72 - 7.85) / 2);
  near(s.tb, Math.min(Math.max(1.3 * s.tn, 0.6), 0.35 * 11.96 / 2));
  assert.deepEqual(s.pocket, { diameter: 5.33, depth: 3.3 });
  near(s.w, Math.max(2.5, 0.25 * 11.96 / 2, 3.3 + 1.5, 3.85 + s.tb));
  const mouth = s.inner[s.inner.length - 1];
  near(mouth[0], 51.18); near(mouth[1], 7.85 / 2);
  assert.ok(s.inner.every((p) => p[0] >= s.w - 1e-9));
});

test('primer pocket sizes by primer type, none for rimfire', () => {
  assert.deepEqual(Geo.buildGeometry(byKey['223_rem']).section.pocket, { diameter: 4.45, depth: 3.04 });
  assert.deepEqual(Geo.buildGeometry(byKey['45_auto']).section.pocket, { diameter: 5.33, depth: 3.04 });
  assert.deepEqual(Geo.buildGeometry(byKey['44_rem_mag']).section.pocket, { diameter: 5.33, depth: 3.04 });
  assert.deepEqual(Geo.buildGeometry(byKey['300_win_mag']).section.pocket, { diameter: 5.33, depth: 3.3 });
  assert.equal(Geo.buildGeometry(byKey['22_long_rifle']).section.pocket, null);
});

test('belted solid head ends after the belt ramp end plus tb', () => {
  const g = Geo.buildGeometry(byKey['300_win_mag']);
  assert.ok(g.section.w >= g.rim.rampEnd + g.section.tb - 1e-9);
});

test('missing G1 draws no bullet and no section walls and names the value', () => {
  const g = Geo.buildGeometry(without(byKey['308_win'], 'projectile', 'G1'));
  assert.equal(g.bullet, null);
  assert.equal(g.section, null);
  assert.ok(g.notes.some((n) => /^G1 missing/.test(n)));
});

test('missing essential value makes the drawing unavailable and says which', () => {
  const g = Geo.buildGeometry(without(byKey['308_win'], 'lengths', 'L3'));
  assert.equal(g.ok, false);
  assert.ok(g.notes.some((n) => /^L3 missing/.test(n)));
});

test('all 25 records build; the bullet always fits the bore; no radius is clamped', () => {
  for (const rec of globalThis.CIP_DATA) {
    const g = Geo.buildGeometry(rec);
    assert.equal(g.ok, true, rec.name);
    assert.ok(g.bullet && g.section, rec.name);
    assert.ok(!g.notes.some((n) => /reduced|inconsistent/.test(n)), rec.name + ': ' + g.notes.join('|'));
    const body = g.outer.filter((p) => p[0] >= g.rim.bodyStartZ);
    for (let i = 1; i < body.length; i++) assert.ok(body[i][0] >= body[i - 1][0] - 1e-9, rec.name);
    if (!g.heeled) {
      for (const p of g.section.inner) {
        if (p[0] >= g.bullet.zb) assert.ok(p[1] >= g.bullet.shankR - 1e-6, `${rec.name} z=${p[0]} inner ${p[1]} < bullet ${g.bullet.shankR}`);
      }
    }
    assert.ok(g.bullet.zn >= g.bullet.zb);
    assert.ok(g.section.w < g.vals.L3, rec.name);
  }
});
