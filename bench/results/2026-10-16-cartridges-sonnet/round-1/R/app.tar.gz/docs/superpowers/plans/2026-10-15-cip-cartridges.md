# C.I.P. cartridge reference - plan

> Executed inline (executing-plans). Spec: docs/superpowers/specs/2026-10-15-cip-cartridges-design.md and the brief.

Global constraints: plain HTML/CSS/JS, no network, `index.html` opens via file://, hash routes, Node 22 tests.

Tasks (each: failing test, run red, implement, run green):
1. Data + sync test (25 records, keys unique).
2. format.js: `formatNumber`, `formatAngle`, `angleDegrees`, `symbolLabel`, `unitOf`, `valueWithTol(obj,key)`, `buildSections(part, kind)`, `matchesQuery`, `filterCartridges`.
3. geometry.js: `rimType`, `wallThicknesses`, `pocket`, `outerRadiusAt`, `innerRadiusAt`, `build(rec)` (outer/inner profiles, bullet, w, notes of missing values).
4. drawing.js: `render(rec)` -> `{svg, notes, layout}`, `findCollisions(layout)`; tests: aria-label, scale 1 unit = 1 mm, labels present (`L3 51.18`), no label overlaps (all 25 records), notes.
5. app.js/index.html/css: list, filter, count, detail, print, routing.
6. Browser verification (Playwright, file://), review.

Review focus: records with missing fields (rimfire 22 WMR, pistols), heeled 22 LR bullet, belted ramp, tolerance display, unknown route, empty search.
