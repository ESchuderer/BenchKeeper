# C.I.P. cartridge reference - design

Source of truth: the project brief (25 records, geometry rules 1-9, UI, print, technology). This note records only the decisions the brief left open.

## Intent
Dense, calm technical reference for reloaders/gunsmiths/engineers. Opens from `file://`, no network, no build step.

## Decisions (builder's calls)
- Classic scripts only (ES modules and `fetch` fail on `file://`). Modules use a UMD wrapper so Node tests `require()` them and the browser gets `window.CIP.*`.
- Data: `data/cartridges.jsonl` (verbatim from the brief) -> `scripts/build-data.js` -> `js/data.js` (`window.CIP_DATA`). A test keeps both in sync.
- Routing: hash routes `#/` and `#/cartridge/<key>` (works on file:// and static servers, survives reload).
- Files: `js/format.js` (values, angles, symbols, search), `js/geometry.js` (pure profile/bullet/wall maths, notes for missing values), `js/drawing.js` (SVG string + dimension/label layout with collision avoidance), `js/app.js` (views, router), `css/style.css` (screen light/dark + print).
- Tests: `node:test` (built in) for logic; a Playwright script (dev dependency only) for browser checks.
- Count text is literally "<n> cartridges" (also for 1).
- Search normalises case, diacritics, whitespace and decimal comma/point.
- Rule tuples in the brief are `(r, z)`; code uses `{z, r}`.
- Drawing: horizontal dims (R, L1, L2, L3, L6) in tiers above; diameter dims are vertical lines across the part at the feature z, extended below the part to staggered label rows; alpha is shown at the shoulder start with the shoulder line mirrored about the axis-parallel through that point (included angle arc). Labels are placed by a collision-checked layout (against labels, outline and dimension lines).
- Missing values: the feature is skipped and named in a "Drawing notes" list under the drawing (HTML, printed too).
- Angle unit cell shows "deg"; N has an empty unit.
- Bullet in section is lightly filled, not hatched; case walls and head are hatched.
