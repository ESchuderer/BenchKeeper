'use strict';
const SHOTS = require('node:path').join(require('node:os').tmpdir(), 'cip-shots');
require('node:fs').mkdirSync(SHOTS, { recursive: true });
// Browser acceptance checks (dev only): opens index.html from disk (file://) and from a static server.
// Run: node e2e/check.js   (needs Playwright's Chromium)
const { chromium } = require('playwright');
const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const root = path.join(__dirname, '..');
const DATA = require('../js/data.js');

let failures = 0;
function ok(cond, msg) { if (!cond) { failures++; console.log('FAIL', msg); } else console.log('ok  ', msg); }

function serve() {
  const types = { '.html': 'text/html', '.js': 'text/javascript', '.css': 'text/css' };
  const srv = http.createServer((req, res) => {
    const p = path.join(root, decodeURIComponent(req.url.split('?')[0]).replace(/\/$/, '/index.html'));
    if (!p.startsWith(root) || !fs.existsSync(p) || fs.statSync(p).isDirectory()) { res.writeHead(404); return res.end(); }
    res.writeHead(200, { 'content-type': types[path.extname(p)] || 'application/octet-stream' });
    fs.createReadStream(p).pipe(res);
  });
  return new Promise((r) => srv.listen(0, () => r(srv)));
}

async function suite(browser, base, label) {
  console.log(`--- ${label}`);
  const ctx = await browser.newContext({ viewport: { width: 1100, height: 900 } });
  const page = await ctx.newPage();
  const errors = [], requests = [];
  page.on('pageerror', (e) => errors.push(String(e)));
  page.on('console', (m) => { if (m.type() === 'error') errors.push(m.text()); });
  page.on('request', (r) => requests.push(r.url()));
  await page.goto(base);

  ok(await page.getByRole('heading', { level: 1, name: 'Cartridges' }).count() === 1, 'start page heading "Cartridges"');
  ok((await page.locator('#count').textContent()) === '25 cartridges', 'count shows "25 cartridges"');
  const names = await page.locator('#cartridge-list tbody a').allTextContents();
  ok(names.length === 25 && DATA.every((r, i) => names[i] === r.name), 'every link text is exactly the record name');
  ok(await page.getByRole('link', { name: '6,5 Creedmoor', exact: true }).count() === 1, 'link "6,5 Creedmoor" by role/name');
  const row = await page.locator('#cartridge-list tbody tr', { hasText: '9 mm Luger' }).first().textContent();
  ok(/pistol/.test(row) && /19\.15 -0\.25 mm/.test(row), 'row has family and L3 with tolerance');

  await page.getByLabel('Search').fill('7,62 x 51');
  ok((await page.locator('#cartridge-list tbody a').allTextContents()).join() === '308 Win.', 'search "7,62 x 51" finds 308 Win.');
  ok((await page.locator('#count').textContent()) === '1 cartridges', 'count follows the filter');
  await page.getByLabel('Family').selectOption('pistol');
  ok((await page.locator('#count').textContent()) === '0 cartridges' && await page.locator('#empty').isVisible(), 'search + family combine, empty state shown');
  await page.getByLabel('Search').fill('');
  ok((await page.locator('#count').textContent()) === '6 cartridges', 'family pistol lists 6');
  const opts = await page.getByLabel('Family').locator('option').allTextContents();
  ok(opts.join() === 'All,rimless,rimmed,belted,pistol,rimfire', 'family options ' + opts.join());
  await page.getByLabel('Family').selectOption('all');

  // detail
  await page.getByRole('link', { name: '308 Win.', exact: true }).click();
  ok(/#\/cartridge\/308_win$/.test(page.url()), 'detail has its own address ' + page.url());
  await page.getByRole('heading', { level: 1, name: '308 Win.' }).waitFor();
  ok(await page.getByRole('heading', { level: 1, name: '308 Win.' }).isVisible(), 'detail heading is the name');
  await page.reload();
  ok(await page.getByRole('heading', { level: 1, name: '308 Win.' }).isVisible(), 'detail survives a reload');
  const meta = await page.locator('dl.meta').textContent();
  for (const s of ['308 Winchester, 7,62 x 51', 'rimless', 'rifle', 'lr', 'US', '1984-06-14', '2008-09-23', 'Transducer', '56 gr H2O']) ok(meta.includes(s), 'meta contains ' + s);
  ok((await page.locator('dl.meta dt').allTextContents()).join('|') === 'Alternative names|Family|Category|Primer type|C.I.P. table|Country|Published|Revised|Pressure method|Water capacity', 'meta labels');
  ok(await page.locator('dl.meta a[href="http://kwk.us/cases.html"]').count() === 1, 'water capacity source link');
  ok(await page.getByRole('img', { name: '308 Win. drawing' }).count() === 1, 'svg accessible name');
  const heads = await page.locator('table.values').first().locator('thead th').allTextContents();
  ok(heads.join() === 'Symbol,Value,Unit', 'table columns ' + heads.join());
  const l1 = await page.locator('table.values tbody tr', { has: page.locator('th', { hasText: /^L1$/ }) }).first().textContent();
  ok(/39\.62 -0\.2/.test(l1) && /mm/.test(l1), 'L1 row shows tolerance next to value: ' + l1);
  const allSyms = await page.locator('table.values tbody th').allTextContents();
  ok(!allSyms.some((s) => /Tol$/.test(s)), 'no tolerance row');
  ok(allSyms.includes('e min') && allSyms.includes('α') && allSyms.includes('r1 min') && allSyms.includes('L3 + G') && allSyms.includes('delta L'), 'special symbols');
  ok(await page.getByRole('button', { name: 'Print' }).count() === 1, 'Print button');
  await page.evaluate(() => { window.__printed = 0; window.print = () => { window.__printed++; }; });
  await page.getByRole('button', { name: 'Print' }).click();
  ok(await page.evaluate(() => window.__printed) === 1, 'Print calls window.print');
  await page.getByRole('link', { name: 'All cartridges' }).click();
  await page.getByRole('heading', { level: 1, name: 'Cartridges' }).waitFor();
  ok(await page.getByRole('heading', { level: 1, name: 'Cartridges' }).isVisible(), 'back to the list');
  await page.goto(base + '#/cartridge/nope');
  ok(await page.getByText('Cartridge not found').count() > 0, 'unknown key handled');

  // every detail view: drawing exists, labels do not overlap in the real browser, fits width
  let bad = 0;
  for (const r of DATA) {
    await page.goto(base + '#/cartridge/' + r.key);
    const res = await page.evaluate(() => {
      const svg = document.querySelector('svg.cartridge-drawing');
      const labels = [...svg.querySelectorAll('text.dim-label')].map((t) => { const b = t.getBBox(); return { t: t.textContent, x: b.x, y: b.y, w: b.width, h: b.height }; });
      const out = [];
      for (let i = 0; i < labels.length; i++) for (let j = i + 1; j < labels.length; j++) {
        const a = labels[i], b = labels[j];
        if (a.x < b.x + b.w && b.x < a.x + a.w && a.y < b.y + b.h && b.y < a.y + a.h) out.push(a.t + ' x ' + b.t);
      }
      const vb = svg.viewBox.baseVal;
      const oob = labels.filter((l) => l.x < vb.x || l.x + l.w > vb.x + vb.width || l.y < vb.y || l.y + l.h > vb.y + vb.height).map((l) => l.t);
      return { out, oob, n: labels.length, label: svg.getAttribute('aria-label') };
    });
    if (res.out.length || res.oob.length || res.label !== r.name + ' drawing') { bad++; console.log('   ', r.key, JSON.stringify(res)); }
  }
  ok(bad === 0, 'all 25 drawings: no overlapping labels (browser getBBox), inside viewBox, named');

  ok(errors.length === 0, 'no console/page errors ' + JSON.stringify(errors));
  const external = requests.filter((u) => !/^file:|^http:\/\/127\.0\.0\.1|^about:|^data:/.test(u));
  ok(external.length === 0, 'no network requests beyond the app itself ' + JSON.stringify(external));
  await ctx.close();
}

async function phoneAndDark(browser, base) {
  console.log('--- phone, dark');
  const ctx = await browser.newContext({ viewport: { width: 360, height: 740 }, deviceScaleFactor: 2, colorScheme: 'dark', isMobile: true });
  const page = await ctx.newPage();
  await page.goto(base);
  ok(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth), 'list: no horizontal scroll at 360 px');
  const bg = await page.evaluate(() => getComputedStyle(document.body).backgroundColor);
  ok(bg === 'rgb(18, 22, 26)', 'dark scheme background ' + bg);
  await page.goto(base + '#/cartridge/338_lapua_mag');
  ok(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth), 'detail: no horizontal scroll at 360 px');
  const w = await page.evaluate(() => document.querySelector('svg.cartridge-drawing').getBoundingClientRect().width);
  ok(w > 300 && w <= 360, 'drawing scales to the phone width: ' + w);
  await page.screenshot({ path: SHOTS + '/phone-dark.png', fullPage: false });
  await ctx.close();
}

async function printChecks(browser, base) {
  console.log('--- print (A4, one page each)');
  const ctx = await browser.newContext({ viewport: { width: 718, height: 1047 } }); // 190 mm printable width
  const page = await ctx.newPage();
  let multi = [];
  let minPt = 99;
  for (const r of DATA) {
    await page.goto(base + '#/cartridge/' + r.key);
    await page.emulateMedia({ media: 'print' });
    const pdf = await page.pdf({ preferCSSPageSize: true, printBackground: true });
    const pages = (pdf.toString('latin1').match(/\/Type\s*\/Page[^s]/g) || []).length;
    if (pages !== 1) multi.push(r.key + ':' + pages);
    const info = await page.evaluate(() => {
      const svg = document.querySelector('svg.cartridge-drawing');
      const b = svg.getBoundingClientRect();
      const pageW = 190 / 25.4 * 96; // printable width in css px
      const vb = svg.viewBox.baseVal;
      const mmPerUnit = (b.width * 25.4 / 96) / vb.width;
      const hidden = ['.toolbar', '#list-view', '.controls', '#print-btn'].map((s) => { const e = document.querySelector(s); return !e || getComputedStyle(e).display === 'none' || e.offsetParent === null; });
      const bgc = getComputedStyle(document.body).backgroundColor, col = getComputedStyle(document.body).color;
      return { widthMm: b.width * 25.4 / 96, labelPt: 3 * mmPerUnit * 72 / 25.4, hidden, bgc, col, pageW };
    });
    minPt = Math.min(minPt, info.labelPt);
    if (!info.hidden.every(Boolean) || info.bgc !== 'rgb(255, 255, 255)' || info.col !== 'rgb(0, 0, 0)') multi.push(r.key + ' print style ' + JSON.stringify(info));
    if (info.widthMm < 185) multi.push(r.key + ' drawing width ' + info.widthMm);
    await page.emulateMedia({ media: 'screen' });
    if (r.key === '308_win' || r.key === '300_win_mag') { await page.emulateMedia({ media: 'print' }); fs.writeFileSync(SHOTS + '/print-' + r.key + '.pdf', pdf); await page.emulateMedia({ media: 'screen' }); }
  }
  ok(multi.length === 0, 'all 25 print as one A4 page, black on white, drawing full width, no controls ' + JSON.stringify(multi));
  ok(minPt >= 8, 'smallest dimension label in print is ' + minPt.toFixed(1) + ' pt');
  await ctx.close();
}

(async () => {
  const browser = await chromium.launch();
  await suite(browser, 'file://' + path.join(root, 'index.html'), 'file://');
  const srv = await serve();
  const base = 'http://127.0.0.1:' + srv.address().port + '/index.html';
  await suite(browser, base, 'static server');
  await phoneAndDark(browser, 'file://' + path.join(root, 'index.html'));
  await printChecks(browser, 'file://' + path.join(root, 'index.html'));
  srv.close();
  await browser.close();
  console.log(failures ? `\n${failures} FAILED` : '\nALL OK');
  process.exit(failures ? 1 : 0);
})();
