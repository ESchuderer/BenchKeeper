'use strict';
const SHOTS = require('node:path').join(require('node:os').tmpdir(), 'cip-shots');
require('node:fs').mkdirSync(SHOTS, { recursive: true });
const { chromium } = require('playwright');
const path = require('node:path');
(async () => {
  const key = process.argv[2] || '308_win';
  const browser = await chromium.launch();
  const page = await browser.newPage({ viewport: { width: 718, height: 1047 } });
  await page.goto('file://' + path.join(__dirname, '..', 'index.html') + '#/cartridge/' + key);
  await page.emulateMedia({ media: 'print' });
  const mm = (px) => (px * 25.4 / 96).toFixed(1);
  const r = await page.evaluate(() => {
    const q = (s) => { const e = document.querySelector(s); return e ? e.getBoundingClientRect().height : 0; };
    return { header: q('.detail-header'), meta: q('dl.meta'), fig: q('figure.drawing'), svg: q('svg.cartridge-drawing'), sections: [...document.querySelectorAll('#detail-view > section')].map((s) => s.getBoundingClientRect().height), footer: q('footer.source'), total: document.getElementById('detail-view').getBoundingClientRect().height };
  });
  console.log(key, 'mm:', Object.fromEntries(Object.entries(r).map(([k, v]) => [k, Array.isArray(v) ? v.map(mm) : mm(v)])), 'limit 277');
  await page.screenshot({ path: SHOTS + '/print-' + key + '.png', fullPage: true });
  await browser.close();
})();
