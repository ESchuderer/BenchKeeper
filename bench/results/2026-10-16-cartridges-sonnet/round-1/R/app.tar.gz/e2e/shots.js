'use strict';
const SHOTS = require('node:path').join(require('node:os').tmpdir(), 'cip-shots');
require('node:fs').mkdirSync(SHOTS, { recursive: true });
// Dev helper: screenshots of the app opened from disk (file://).
const { chromium } = require('playwright');
const path = require('node:path');
const url = 'file://' + path.join(__dirname, '..', 'index.html');
(async () => {
  const browser = await chromium.launch();
  const keys = process.argv.slice(2);
  const ctx = await browser.newContext({ viewport: { width: 1100, height: 900 } });
  const page = await ctx.newPage();
  const errors = [];
  page.on('pageerror', (e) => errors.push(String(e)));
  page.on('console', (m) => { if (m.type() === 'error') errors.push(m.text()); });
  await page.goto(url);
  await page.screenshot({ path: SHOTS + '/list.png' });
  for (const k of keys) {
    await page.goto(url + '#/cartridge/' + k);
    await page.reload();
    await page.locator('figure.drawing').screenshot({ path: `${SHOTS}/draw-${k}.png` });
  }
  console.log('errors:', errors);
  await browser.close();
})();
