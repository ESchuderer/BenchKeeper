'use strict';
const SHOTS = require('node:path').join(require('node:os').tmpdir(), 'cip-shots');
require('node:fs').mkdirSync(SHOTS, { recursive: true });
// Dev helper: zoomed screenshot of a region of the drawing, given in SVG user units (mm).
const { chromium } = require('playwright');
const path = require('node:path');
const url = 'file://' + path.join(__dirname, '..', 'index.html');
(async () => {
  const [key, x, y, w, h, out] = process.argv.slice(2);
  const browser = await chromium.launch();
  const ctx = await browser.newContext({ viewport: { width: 1100, height: 900 }, deviceScaleFactor: 3 });
  const page = await ctx.newPage();
  await page.goto(url + '#/cartridge/' + key);
  const clip = await page.evaluate(([x, y, w, h]) => {
    const svg = document.querySelector('svg.cartridge-drawing');
    const r = svg.getBoundingClientRect();
    const vb = svg.viewBox.baseVal;
    const s = r.width / vb.width;
    return { x: r.left + (x - vb.x) * s, y: r.top + window.scrollY + (y - vb.y) * s, width: w * s, height: h * s };
  }, [+x, +y, +w, +h]);
  await page.screenshot({ path: out || SHOTS + '/zoom.png', clip, fullPage: true });
  await browser.close();
})();
