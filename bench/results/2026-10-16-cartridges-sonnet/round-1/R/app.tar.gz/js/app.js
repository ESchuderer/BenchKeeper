'use strict';
// Views and hash router. Routes: "#/" (list) and "#/cartridge/<key>" (detail).
(function () {
  var Format = window.CIP.Format, Drawing = window.CIP.Drawing, DATA = window.CIP_DATA;
  var $ = function (id) { return document.getElementById(id); };
  var listView = $('list-view'), detailView = $('detail-view');
  var search = $('search'), family = $('family'), count = $('count'), tbody = $('cartridge-list').querySelector('tbody'), empty = $('empty');
  var listScroll = 0;

  function el(tag, attrs, children) {
    var e = document.createElement(tag);
    Object.keys(attrs || {}).forEach(function (k) {
      if (k === 'text') e.textContent = attrs[k]; else e.setAttribute(k, attrs[k]);
    });
    (children || []).forEach(function (c) { if (c) e.appendChild(c); });
    return e;
  }

  // ---------- list ----------
  function renderList() {
    var rows = Format.filterCartridges(DATA, search.value, family.value);
    tbody.textContent = '';
    rows.forEach(function (r) {
      var l3 = el('td', { 'class': 'num' });
      l3.textContent = Format.valueWithTol(r.cartridge.lengths, 'L3') + ' mm';
      tbody.appendChild(el('tr', {}, [
        el('td', {}, [el('a', { href: '#/cartridge/' + encodeURIComponent(r.key), text: r.name })]),
        el('td', { text: r.family }),
        l3
      ]));
    });
    count.textContent = rows.length + ' cartridges';
    empty.hidden = rows.length > 0;
    $('cartridge-list').hidden = rows.length === 0;
  }

  // ---------- detail ----------
  function valueCell(text) {
    var td = el('td', { 'class': 'num' });
    var parts = text.split(' ');
    td.appendChild(el('span', { 'class': 'val', text: parts[0] }));
    if (parts[1]) { td.appendChild(document.createTextNode(' ')); td.appendChild(el('span', { 'class': 'tol', text: parts[1] })); }
    return td;
  }

  function sectionTable(sec) {
    var table = el('table', { 'class': 'values' });
    table.appendChild(el('caption', { text: sec.title }));
    table.appendChild(el('thead', {}, [el('tr', {}, [
      el('th', { scope: 'col', text: 'Symbol' }), el('th', { scope: 'col', 'class': 'num', text: 'Value' }), el('th', { scope: 'col', text: 'Unit' })
    ])]));
    var body = el('tbody');
    sec.rows.forEach(function (r) {
      body.appendChild(el('tr', {}, [el('th', { scope: 'row', text: r.symbol }), valueCell(r.value), el('td', { 'class': 'unit', text: r.unit })]));
    });
    table.appendChild(body);
    return table;
  }

  function metaRow(dl, label, content) {
    var dd = el('dd');
    if (typeof content === 'string') dd.textContent = content; else dd.appendChild(content);
    dl.appendChild(el('div', {}, [el('dt', { text: label }), dd]));
  }

  function capacityNode(rec) {
    var cap = rec.annotations && rec.annotations.publishedCapacity;
    if (!cap) return document.createTextNode('not published');
    var span = el('span');
    span.appendChild(document.createTextNode(Format.formatNumber(cap.grH2O) + ' gr H2O, source: '));
    span.appendChild(el('a', { href: cap.url, rel: 'noopener noreferrer', text: cap.source }));
    if (cap.note) span.appendChild(el('small', { 'class': 'note', text: ' (' + cap.note + ')' }));
    return span;
  }

  function renderDetail(rec) {
    var a = rec.annotations || {};
    detailView.textContent = '';
    var toolbar = el('nav', { 'class': 'toolbar no-print', 'aria-label': 'Cartridge actions' }, [
      el('a', { href: '#/', 'class': 'back', text: 'All cartridges' }),
      el('button', { type: 'button', id: 'print-btn', text: 'Print' })
    ]);
    var header = el('header', { 'class': 'detail-header' }, [
      el('h1', { id: 'detail-title', tabindex: '-1', text: rec.name }),
      el('p', { 'class': 'print-only kicker', text: 'C.I.P. cartridge reference' })
    ]);
    var dl = el('dl', { 'class': 'meta' });
    metaRow(dl, 'Alternative names', rec.alternativeNames && rec.alternativeNames.length ? rec.alternativeNames.join(', ') : 'none');
    metaRow(dl, 'Family', rec.family);
    metaRow(dl, 'Category', a.category || '–');
    metaRow(dl, 'Primer type', a.primerType || '–');
    metaRow(dl, 'C.I.P. table', rec.tab);
    metaRow(dl, 'Country', rec.country);
    metaRow(dl, 'Published', rec.published);
    metaRow(dl, 'Revised', rec.revised);
    metaRow(dl, 'Pressure method', rec.pressureMethod);
    metaRow(dl, 'Water capacity', capacityNode(rec));

    var fig = el('figure', { 'class': 'drawing' });
    var holder = el('div', { 'class': 'drawing-svg' });
    var out;
    try { out = Drawing.render(rec); } catch (err) { out = { svg: '', notes: [], missingRequired: [], error: String(err && err.message || err) }; }
    var cap = el('figcaption');
    if (out.svg) {
      holder.innerHTML = out.svg;
      cap.appendChild(el('p', { 'class': 'drawing-meta', text: 'Rim type: ' + out.geometry.rimType + '. Upper half: outside view. Lower half: section, cut walls hatched.' }));
      if (out.notes.length) {
        var ul = el('ul', { 'class': 'drawing-notes', 'aria-label': 'Drawing notes' });
        out.notes.forEach(function (n) { ul.appendChild(el('li', { text: n.text })); });
        cap.appendChild(el('p', { 'class': 'notes-title', text: 'Drawing notes' }));
        cap.appendChild(ul);
      }
    } else {
      holder.appendChild(el('p', { 'class': 'empty', text: out.error ? 'The drawing could not be made.' : 'The drawing cannot be made: ' + out.missingRequired.join(', ') + ' not published.' }));
    }
    fig.appendChild(holder); fig.appendChild(cap);

    var tablesA = el('div', { 'class': 'tables' });
    Format.buildSections(rec.cartridge, 'cartridge').forEach(function (s) { tablesA.appendChild(sectionTable(s)); });
    var tablesB = el('div', { 'class': 'tables' });
    Format.buildSections(rec.chamber, 'chamber').forEach(function (s) { tablesB.appendChild(sectionTable(s)); });

    detailView.appendChild(toolbar);
    detailView.appendChild(header);
    detailView.appendChild(dl);
    detailView.appendChild(fig);
    detailView.appendChild(el('div', { 'class': 'all-tables' }, [
      el('section', { 'aria-labelledby': 'h-cartridge' }, [el('h2', { id: 'h-cartridge', text: 'Cartridge values' }), tablesA]),
      el('section', { 'aria-labelledby': 'h-chamber' }, [el('h2', { id: 'h-chamber', text: 'Chamber values' }), tablesB])
    ]));
    detailView.appendChild(el('footer', { 'class': 'source', text: 'Source: C.I.P. TDCC, revised ' + rec.revised + '.' }));
    $('print-btn').addEventListener('click', function () { window.print(); });
  }

  function renderNotFound(key) {
    detailView.textContent = '';
    detailView.appendChild(el('nav', { 'class': 'toolbar no-print' }, [el('a', { href: '#/', 'class': 'back', text: 'All cartridges' })]));
    detailView.appendChild(el('h1', { id: 'detail-title', tabindex: '-1', text: 'Cartridge not found' }));
    detailView.appendChild(el('p', { text: 'There is no cartridge with the key "' + key + '".' }));
  }

  // ---------- router ----------
  var first = true, current = null;
  function route() {
    var hash = window.location.hash.replace(/\/+$/, '');
    var m = /^#\/cartridge\/(.+)$/.exec(hash);
    var wasList = !listView.hidden;
    if (!m && hash !== '' && hash !== '#' && hash !== '#/' && window.history && window.history.replaceState) {
      window.history.replaceState(null, '', '#/'); // unknown address: show the list under its own address
    }
    if (m) {
      var key;
      try { key = decodeURIComponent(m[1]); } catch (e) { key = m[1]; }
      var rec = DATA.filter(function (r) { return r.key === key || r.key.toLowerCase() === key.toLowerCase(); })[0];
      if (wasList) listScroll = window.scrollY;
      listView.hidden = true; detailView.hidden = false;
      if (rec) { renderDetail(rec); document.title = rec.name + ' – C.I.P. cartridge reference'; } else { renderNotFound(key); document.title = 'Cartridge not found – C.I.P. cartridge reference'; }
      window.scrollTo(0, 0);
      if (!first) $('detail-title').focus({ preventScroll: true });
      current = 'detail';
    } else {
      detailView.hidden = true; detailView.textContent = ''; listView.hidden = false;
      document.title = 'Cartridges – C.I.P. cartridge reference';
      if (current === 'detail') window.scrollTo(0, listScroll);
      if (!first) $('list-title').focus({ preventScroll: true });
      current = 'list';
    }
    first = false;
  }

  search.addEventListener('input', renderList);
  family.addEventListener('change', renderList);
  window.addEventListener('hashchange', route);
  renderList();
  route();
})();
