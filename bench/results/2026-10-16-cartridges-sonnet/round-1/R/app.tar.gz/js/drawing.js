'use strict';
// SVG drawing of a cartridge: 1 user unit = 1 mm, axis horizontal, head on the left, outside view above the
// axis, section below. Pure string output (no DOM) so it is testable in Node. Labels are placed by a small
// collision-checked layout (labels vs labels, outline and dimension lines).
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory(require('./format.js'), require('./geometry.js'));
  else { root.CIP = root.CIP || {}; root.CIP.Drawing = factory(root.CIP.Format, root.CIP.Geometry); }
})(typeof self !== 'undefined' ? self : this, function (Format, Geometry) {
  var FS = 3;              // label font size (mm)
  var CW = 0.6;            // glyph advance as a fraction of the font size (monospace; enforced with textLength)
  var ARROW_L = 2, ARROW_W = 0.55;
  var A4_WIDTH = 190;      // printable width of an A4 portrait page with 10 mm margins
  var PAD = 4;
  var ROW_GAP = 4.6;     // pitch of the diameter label rows

  function isNum(v) { return typeof v === 'number' && isFinite(v); }
  function fmt(n) { var v = Math.round(n * 1000) / 1000; return String(v === 0 ? 0 : v); }
  function escapeXml(s) {
    return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  }
  function textW(s, fs) { return s.length * CW * (fs || FS); }

  // ---------- geometry helpers for collisions ----------
  function rectsOverlap(a, b, pad) {
    return a.x < b.x + b.w + pad && b.x < a.x + a.w + pad && a.y < b.y + b.h + pad && b.y < a.y + a.h + pad;
  }
  function segHitsRect(s, r, pad) {
    var x0 = r.x - pad, x1 = r.x + r.w + pad, y0 = r.y - pad, y1 = r.y + r.h + pad;
    var dx = s.x2 - s.x1, dy = s.y2 - s.y1, t0 = 0, t1 = 1;
    var p = [-dx, dx, -dy, dy], q = [s.x1 - x0, x1 - s.x1, s.y1 - y0, y1 - s.y1];
    for (var i = 0; i < 4; i++) {
      if (p[i] === 0) { if (q[i] < 0) return false; } else {
        var t = q[i] / p[i];
        if (p[i] < 0) { if (t > t1) return false; if (t > t0) t0 = t; } else { if (t < t0) return false; if (t < t1) t1 = t; }
      }
    }
    return true;
  }

  // ---------- SVG snippets ----------
  function line(cls, x1, y1, x2, y2) {
    return '<line class="' + cls + '" x1="' + fmt(x1) + '" y1="' + fmt(y1) + '" x2="' + fmt(x2) + '" y2="' + fmt(y2) + '"/>';
  }
  // arrowhead with its tip at (x, y) pointing along (dx, dy)
  function arrow(x, y, dx, dy, len, wid) {
    var al = len || ARROW_L, aw = wid || ARROW_W;
    var l = Math.hypot(dx, dy) || 1; dx /= l; dy /= l;
    var bx = x - dx * al, by = y - dy * al, px = -dy * aw, py = dx * aw;
    return '<path class="arrow" d="M' + fmt(x) + ' ' + fmt(y) + ' L' + fmt(bx + px) + ' ' + fmt(by + py) + ' L' + fmt(bx - px) + ' ' + fmt(by - py) + ' Z"/>';
  }
  function textEl(cls, x, y, str, fs, extra) {
    return '<text class="' + cls + '"' + (extra || '') + ' x="' + fmt(x) + '" y="' + fmt(y) + '" font-size="' + fs + '" textLength="' + fmt(textW(str, fs)) + '" lengthAdjust="spacingAndGlyphs">' + escapeXml(str) + '</text>';
  }
  function pathD(pts, close) {
    return 'M' + pts.map(function (p) { return fmt(p.x) + ' ' + fmt(p.y); }).join(' L') + (close ? ' Z' : '');
  }
  function toXY(pts, sign) { return pts.map(function (p) { return { x: p.z, y: sign * p.r }; }); }
  function polySegs(pts, kind, owner) {
    var out = [];
    for (var i = 1; i < pts.length; i++) out.push({ x1: pts[i - 1].x, y1: pts[i - 1].y, x2: pts[i].x, y2: pts[i].y, kind: kind, owner: owner });
    return out;
  }

  // ---------- layout engine ----------
  function Engine() { this.labels = []; this.segs = []; }
  Engine.prototype.addSegs = function (list) { for (var i = 0; i < list.length; i++) this.segs.push(list[i]); };
  Engine.prototype.conflicts = function (c) {
    var n = 0, i, j;
    for (i = 0; i < this.labels.length; i++) if (rectsOverlap(c.box, this.labels[i].box, 0.8)) n++;
    for (i = 0; i < this.segs.length; i++) if (this.segs[i].kind !== 'leader' && segHitsRect(this.segs[i], c.box, 0.4)) n++;
    var mine = (c.segs || []).concat(c.leader || []);
    for (j = 0; j < mine.length; j++) for (i = 0; i < this.labels.length; i++) if (segHitsRect(mine[j], this.labels[i].box, 0.4)) n++;
    return n;
  };
  // Picks the first candidate without conflicts (else the one with the fewest); registers its label and segments.
  Engine.prototype.place = function (id, text, cands) {
    var best = null, bestN = Infinity;
    for (var i = 0; i < cands.length; i++) {
      var n = this.conflicts(cands[i]);
      if (n < bestN) { best = cands[i]; bestN = n; }
      if (n === 0) break;
    }
    this.labels.push({ id: id, text: text, box: best.box, x: best.x, y: best.y });
    this.addSegs(best.segs || []);
    this.addSegs(best.leader || []);
    return best;
  };

  function labelBox(x, baseline, text) {
    return { x: x, y: baseline - 0.8 * FS, w: textW(text, FS), h: FS };
  }

  function dimValue(rec, id) {
    var c = rec.cartridge;
    var map = {
      R: ['caseHead', 'R'], R1: ['caseHead', 'R1'], E1: ['caseHead', 'E1'],
      L1: ['lengths', 'L1'], L2: ['lengths', 'L2'], L3: ['lengths', 'L3'], L6: ['lengths', 'L6'],
      P1: ['powderChamber', 'P1'], P2: ['powderChamber', 'P2'], H1: ['collar', 'H1'], H2: ['collar', 'H2'],
      G1: ['projectile', 'G1']
    };
    var m = map[id];
    var obj = c[m[0]];
    if (!obj || !isNum(obj[m[1]])) return null;
    return Format.valueWithTol(obj, m[1]);
  }

  function render(rec) {
    var g = Geometry.build(rec);
    if (!g.ok) return { svg: '', layout: null, notes: [], missingRequired: g.missingRequired, geometry: g };
    var c = rec.cartridge, ch = c.caseHead, ln = c.lengths;
    var eng = new Engine();
    var outer = g.outer, bullet = g.bullet, marks = g.marks;
    var L3 = ln.L3;

    // ----- outlines -----
    var upper = toXY(outer, -1);
    var upperBullet = [];
    if (bullet) {
      upperBullet = toXY(bullet.exposed, -1);
      upperBullet.push({ x: ln.L6, y: 0 });
      upper = upper.concat(upperBullet);
    }
    var pk = g.pocket;
    var lowerOuter = toXY(outer, 1);
    var lowerCase = [];
    if (pk) { lowerCase.push({ x: pk.depth, y: 0 }, { x: pk.depth, y: pk.d / 2 }, { x: 0, y: pk.d / 2 }); } else lowerCase.push(lowerOuter[0]);
    lowerCase = lowerCase.concat(lowerOuter.slice(1));
    var inner = toXY(g.inner, 1);
    lowerCase.push({ x: L3, y: inner[inner.length - 1].y });
    for (var i = inner.length - 1; i >= 0; i--) lowerCase.push(inner[i]);
    lowerCase.push({ x: g.w, y: 0 });
    var lowerBullet = bullet ? toXY(bullet.profile, 1) : [];

    eng.addSegs(polySegs(upper, 'outline', 'outline'));
    eng.addSegs(polySegs(lowerCase, 'outline', 'outline'));
    eng.addSegs(polySegs(lowerBullet, 'outline', 'outline'));

    var rmax = 0;
    outer.forEach(function (p) { if (p.r > rmax) rmax = p.r; });

    // ----- dimensions -----
    var dims = [];              // svg fragments per dimension
    var drawn = {};
    var topAt0 = 0;
    outer.forEach(function (p) { if (p.z === 0 && p.r > topAt0) topAt0 = p.r; });
    var rTop = function (z) { return Geometry.outerRadiusAt(outer, z); };

    // horizontal (length) dimensions in tiers above the part
    var hdims = [{ id: 'R', z0: 0, a0: topAt0, z1: ch.R, a1: marks.rimBack.r }];
    if (isNum(ln.L1)) hdims.push({ id: 'L1', z0: 0, a0: topAt0, z1: ln.L1, a1: rTop(ln.L1) });
    if (isNum(ln.L2)) hdims.push({ id: 'L2', z0: 0, a0: topAt0, z1: ln.L2, a1: rTop(ln.L2) });
    hdims.push({ id: 'L3', z0: 0, a0: topAt0, z1: L3, a1: marks.mouth.r });
    if (bullet) hdims.push({ id: 'L6', z0: 0, a0: topAt0, z1: ln.L6, a1: bullet.m / 2 });
    var tierGap = 5.2, tier0 = rmax + 4.5;
    var hl = hdims.map(function (d, idx) {
      var y = -(tier0 + idx * tierGap);
      var text = d.id + ' ' + dimValue(rec, d.id);
      var span = d.z1 - d.z0;
      var inside = span >= 2 * ARROW_L + 1.5;
      var tail = inside ? 0 : 3;
      var parts = [];
      var segs = [];
      [[d.z0, d.a0], [d.z1, d.a1]].forEach(function (e) {
        var s = { x1: e[0], y1: -(e[1] + 0.8), x2: e[0], y2: y - 1.2, kind: 'ext', owner: d.id };
        segs.push(s); parts.push(line('ext', s.x1, s.y1, s.x2, s.y2));
      });
      var dl = { x1: d.z0 - tail, y1: y, x2: d.z1 + tail, y2: y, kind: 'dim-line', owner: d.id };
      segs.push(dl); parts.push(line('dim-line', dl.x1, dl.y1, dl.x2, dl.y2));
      if (inside) { parts.push(arrow(d.z0, y, -1, 0), arrow(d.z1, y, 1, 0)); } else { parts.push(arrow(d.z0, y, 1, 0), arrow(d.z1, y, -1, 0)); }
      eng.addSegs(segs);
      var w = textW(text, FS);
      var cands = [];
      var onLine = y + 0.3 * FS;
      if (inside && w + 2 <= span - 2 * ARROW_L) {
        var x = (d.z0 + d.z1) / 2 - w / 2;
        cands.push({ x: x, y: y - 1.6, box: labelBox(x, y - 1.6, text) });
      }
      var xr = d.z1 + tail + 2.5;
      cands.push({ x: xr, y: onLine, box: labelBox(xr, onLine, text) });
      var xl = d.z0 - tail - 2.5 - w;
      cands.push({ x: xl, y: onLine, box: labelBox(xl, onLine, text) });
      return { d: d, parts: parts, text: text, cands: cands };
    });

    // vertical (diameter) dimensions, labels in rows below the part
    var f0 = isNum(ch.f) ? ch.f : 0;
    var vdims = [{ id: 'R1', z: f0 + 0.35 * (ch.R - f0) }];
    if (g.features.groove) vdims.push({ id: 'E1', z: ch.R + 0.7 * ch.eMin });
    vdims.push({ id: 'P1', z: marks.bodyStart.z + 1 });
    if (g.features.shoulder) vdims.push({ id: 'P2', z: ln.L1 });
    if (g.features.shoulder) vdims.push({ id: 'H1', z: ln.L2 });
    vdims.push({ id: 'H2', z: L3 - 1 });
    if (bullet) vdims.push({ id: 'G1', z: bullet.zc });
    var DIAM = {
      R1: ch.R1, E1: ch.E1, P1: c.powderChamber.P1, P2: c.powderChamber.P2, H1: (c.collar || {}).H1,
      H2: c.collar.H2, G1: bullet ? bullet.G1 : null
    };
    var vl = vdims.map(function (d) {
      var D = DIAM[d.id], text = d.id + ' ' + dimValue(rec, d.id);
      var dlseg = { x1: d.z, y1: -D / 2, x2: d.z, y2: D / 2, kind: 'dim-line', owner: d.id };
      eng.addSegs([dlseg]);
      return { d: d, D: D, text: text, dl: dlseg };
    }).sort(function (a, b) { return a.d.z - b.d.z; });
    // Labels sit in rows below the part, joined to the part by an extension line. For every combination of
    // anchors (centre, right-flowing, left-flowing) the rows follow from one rule: a label that covers another
    // label's extension line must lie in a deeper row. The combination with the fewest rows that also clears
    // all other geometry wins.
    var rows = 0;
    var vInfo = vl.map(function (v) { return { v: v, w: textW(v.text, FS) }; });
    function anchorX(info, a) {
      var z = info.v.d.z;
      return a === 0 ? z - info.w / 2 : a === 1 ? z - 0.25 : z + 0.25 - info.w;
    }
    function assignRows(it) {
      var n = it.length, adj = [], i, j;
      for (i = 0; i < n; i++) adj.push([]);
      for (i = 0; i < n; i++) for (j = 0; j < n; j++) {
        if (i !== j && it[j].z >= it[i].x0 - 0.4 && it[j].z <= it[i].x1 + 0.4) adj[i].push(j);
      }
      function longest() {
        var memo = [], state = [];
        function rowOf(k) {
          if (state[k] === 2) return memo[k];
          if (state[k] === 1) return -1;
          state[k] = 1;
          var r = 0;
          for (var q = 0; q < adj[k].length; q++) { var x = rowOf(adj[k][q]); if (x < 0) return -1; if (x + 1 > r) r = x + 1; }
          state[k] = 2; memo[k] = r; return r;
        }
        var out = [];
        for (var k = 0; k < n; k++) { var r = rowOf(k); if (r < 0 || r > 11) return null; out.push(r); }
        return out;
      }
      var rowsNow = longest();
      for (var guard = 0; guard < 40 && rowsNow; guard++) {
        var pair = null;
        for (i = 0; i < n && !pair; i++) for (j = i + 1; j < n; j++) {
          if (rowsNow[i] === rowsNow[j] && it[i].x0 < it[j].x1 + 0.8 && it[j].x0 < it[i].x1 + 0.8) { pair = [i, j]; break; }
        }
        if (!pair) return rowsNow;
        adj[pair[0]].push(pair[1]);
        var r1 = longest();
        if (r1) { rowsNow = r1; continue; }
        adj[pair[0]].pop(); adj[pair[1]].push(pair[0]);
        rowsNow = longest();
      }
      return null;
    }
    function rowCand(info, anchor, row) {
      var x = anchorX(info, anchor), top = rmax + 4.5 + row * ROW_GAP, base = top + 0.8 * FS, z = info.v.d.z;
      return { x: x, y: base, box: labelBox(x, base, info.v.text), row: row,
        segs: [{ x1: z, y1: info.v.D / 2 + 0.8, x2: z, y2: top - 0.6, kind: 'ext', owner: info.v.d.id }] };
    }
    var n3 = Math.pow(3, vInfo.length), plans = [];
    for (var code = 0; code < n3; code++) {
      var anchors = [], cc = code;
      for (var q = 0; q < vInfo.length; q++) { anchors.push(cc % 3); cc = Math.floor(cc / 3); }
      var items = vInfo.map(function (info, idx) { var x = anchorX(info, anchors[idx]); return { x0: x, x1: x + info.w, z: info.v.d.z }; });
      var rs = assignRows(items);
      if (!rs) continue;
      var nonCentre = anchors.filter(function (a) { return a !== 0; }).length;
      plans.push({ anchors: anchors, rows: rs, maxRow: Math.max.apply(null, rs), nonCentre: nonCentre });
    }
    plans.sort(function (a, b) { return a.maxRow - b.maxRow || a.nonCentre - b.nonCentre; });
    var chosen = null;
    for (var pi = 0; pi < plans.length && !chosen; pi++) {
      var plan = plans[pi], placed = [], okPlan = true;
      for (var di = 0; di < vInfo.length; di++) {
        var cd = rowCand(vInfo[di], plan.anchors[di], plan.rows[di]);
        if (eng.conflicts(cd) > 0) { okPlan = false; break; }
        eng.labels.push({ id: vInfo[di].v.d.id, text: vInfo[di].v.text, box: cd.box, x: cd.x, y: cd.y });
        cd.segs.forEach(function (sg) { eng.segs.push(sg); });
        placed.push(cd);
      }
      if (okPlan) { chosen = placed; break; }
      placed.forEach(function (cd) { eng.labels.pop(); eng.segs.length -= cd.segs.length; });
    }
    if (!chosen) { // not expected: fall back to one row per label so that the output stays valid
      chosen = vInfo.map(function (info, idx) {
        var cd = rowCand(info, 0, idx);
        eng.labels.push({ id: info.v.d.id, text: info.v.text, box: cd.box, x: cd.x, y: cd.y });
        cd.segs.forEach(function (sg) { eng.segs.push(sg); });
        return cd;
      });
    }
    vl.forEach(function (v, i) { v.best = chosen[i]; rows = Math.max(rows, chosen[i].row + 1); });

    // alpha: shoulder line mirrored about the axis-parallel through the shoulder start (included angle)
    var alphaFrag = null;
    if (g.features.shoulder) {
      var S1 = { x: marks.shoulderStart.z, y: -marks.shoulderStart.r }, S2 = { x: marks.shoulderEnd.z, y: -marks.shoulderEnd.r };
      var th = Math.atan2(S2.y - S1.y, S2.x - S1.x); // downwards (screen y) angle of the shoulder line
      var slen = Math.hypot(S2.x - S1.x, S2.y - S1.y);
      var rho = Math.min(0.8 * slen, 6);
      var ray = Math.min(rho + 0.8, slen);
      var lower = { x: S1.x + rho * Math.cos(th), y: S1.y + rho * Math.sin(th) };
      var upperE = { x: S1.x + rho * Math.cos(th), y: S1.y - rho * Math.sin(th) };
      var aSegs = [
        { x1: S1.x, y1: S1.y, x2: S1.x + ray * Math.cos(th), y2: S1.y - ray * Math.sin(th), kind: 'ext', owner: 'alpha' },
        { x1: S1.x, y1: S1.y, x2: S1.x + ray * 1.0, y2: S1.y, kind: 'ext', owner: 'alpha' }
      ];
      var arcPts = [];
      for (var k = 0; k <= 8; k++) { var a = -th + 2 * th * k / 8; arcPts.push({ x: S1.x + rho * Math.cos(a), y: S1.y - rho * Math.sin(a) }); }
      // arc from the shoulder leg (lower) to its mirror (upper), through the horizontal
      var arcSegs = polySegs(arcPts.slice().reverse(), 'dim-line', 'alpha');
      eng.addSegs(aSegs.concat(arcSegs));
      var aText = 'α ' + Format.formatAngle(g.alphaRaw);
      var aw = textW(aText, FS);
      var tipU = { x: -Math.sin(th), y: -Math.cos(th) };       // direction leaving the arc at the upper end (counter-clockwise)
      var tipL = { x: -Math.sin(th), y: Math.cos(th) };        // direction leaving the arc at the lower end
      var cands2 = [];
      var arcTop = { x: upperE.x, y: upperE.y };
      var xr2 = arcTop.x + 2, br2 = arcTop.y - 0.5;
      cands2.push({ x: xr2, y: br2, box: labelBox(xr2, br2, aText) });
      for (var j = 0; j < 8; j++) {
        var xl2 = S1.x - 2.5 - aw, bl2 = S1.y - 2 - j * 4.2;
        var box = labelBox(xl2, bl2, aText);
        cands2.push({
          x: xl2, y: bl2, box: box,
          leader: [{ x1: xl2 + aw + 0.4, y1: bl2 - 0.3 * FS, x2: arcTop.x, y2: arcTop.y, kind: 'leader', owner: 'alpha' }]
        });
      }
      var bestA = eng.place('alpha', aText, cands2);
      var parts = aSegs.map(function (s) { return line('ext', s.x1, s.y1, s.x2, s.y2); });
      parts.push('<path class="dim-line" d="M' + fmt(lower.x) + ' ' + fmt(lower.y) + ' A' + fmt(rho) + ' ' + fmt(rho) + ' 0 0 0 ' + fmt(upperE.x) + ' ' + fmt(upperE.y) + '"/>');
      parts.push(arrow(lower.x, lower.y, tipL.x, tipL.y, 1.2, 0.35), arrow(upperE.x, upperE.y, tipU.x, tipU.y, 1.2, 0.35));
      if (bestA.leader) bestA.leader.forEach(function (s) { parts.push(line('leader', s.x1, s.y1, s.x2, s.y2)); });
      parts.push(textEl('dim-label', bestA.x, bestA.y, aText, FS));
      alphaFrag = '<g class="dim" data-dim="alpha">' + parts.join('') + '</g>';
      drawn.alpha = true;
    }

    // place horizontal labels (their lines are already registered)
    hl.forEach(function (h) {
      var best = eng.place(h.d.id, h.text, h.cands);
      h.parts.push(textEl('dim-label', best.x, best.y, h.text, FS));
      dims.push('<g class="dim" data-dim="' + h.d.id + '">' + h.parts.join('') + '</g>');
      drawn[h.d.id] = true;
    });
    vl.forEach(function (v) {
      var z = v.d.z, parts = [];
      parts.push(line('ext', v.best.segs[0].x1, v.best.segs[0].y1, v.best.segs[0].x2, v.best.segs[0].y2));
      parts.push(line('dim-line', z, -v.D / 2, z, v.D / 2));
      parts.push(arrow(z, -v.D / 2, 0, -1), arrow(z, v.D / 2, 0, 1));
      parts.push(textEl('dim-label', v.best.x, v.best.y, v.text, FS));
      dims.push('<g class="dim" data-dim="' + v.d.id + '">' + parts.join('') + '</g>');
      drawn[v.d.id] = true;
    });
    if (alphaFrag) dims.push(alphaFrag);

    // ----- extents, title block, scale -----
    var minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity;
    function grow(x, y) { if (x < minX) minX = x; if (x > maxX) maxX = x; if (y < minY) minY = y; if (y > maxY) maxY = y; }
    eng.segs.forEach(function (s) { grow(s.x1, s.y1); grow(s.x2, s.y2); });
    eng.labels.forEach(function (l) { grow(l.box.x, l.box.y); grow(l.box.x + l.box.w, l.box.y + l.box.h); });
    grow(-4, 0); grow(ln.L6 + 4, 0); // centre line overhang
    var rowsTop = rmax + 4.5;
    var rowsBottom = rowsTop + (rows - 1) * ROW_GAP + FS;
    if (maxY < rowsBottom) maxY = rowsBottom;

    // title block: name, table, revision, units, scale. Placed below the drawing, or beside the label rows
    // when that gives a flatter drawing (the drawing is printed at full page width).
    var tFs = 2.6, nameFs = 3.8, rowH = 4.2, headH = 6.6;
    var scaleWorst = 'Scale 9.99 : 1 (A4 print)';
    var tbW = Math.max(textW(rec.name, nameFs), textW(scaleWorst, tFs), textW('C.I.P. table ' + rec.tab, tFs), 36) + 6;
    var tbH = headH + 5 * rowH + 2.4;
    var contentW = maxX - minX + 2 * PAD;
    var wA = Math.max(contentW, tbW + 2 * PAD);
    var hA = maxY + 5 + tbH + PAD - (minY - PAD);
    var yTopB = rowsTop - 0.5, xStartB = minX;
    eng.segs.forEach(function (s) {
      if (Math.max(s.y1, s.y2) >= yTopB - 1 && Math.min(s.y1, s.y2) <= yTopB + tbH + 1) xStartB = Math.max(xStartB, s.x1, s.x2);
    });
    eng.labels.forEach(function (l) {
      if (l.box.y + l.box.h >= yTopB - 1 && l.box.y <= yTopB + tbH + 1) xStartB = Math.max(xStartB, l.box.x + l.box.w);
    });
    xStartB += 4;
    var wB = Math.max(contentW, xStartB + tbW + PAD - (minX - PAD));
    var hB = Math.max(maxY, yTopB + tbH) + PAD - (minY - PAD);
    // A (below) keeps the drawing narrow, which matters on phones; B (beside) is only used when A would be
    // too tall for one printed page (about 0.92 of the page width).
    var useB = hA / wA > 0.92 && hB / wB < hA / wA && wB <= 165;
    var tbX, tbY, vbX, vbW, vbY, vbH;
    if (useB) {
      vbW = wB; vbX = minX - PAD; tbX = xStartB; tbY = yTopB;
      vbY = minY - PAD; vbH = hB;
    } else {
      vbW = wA; vbX = minX - PAD - (wA - contentW) / 2; tbX = vbX + vbW - PAD - tbW; tbY = maxY + 5;
      vbY = minY - PAD; vbH = hA;
    }
    var scale = A4_WIDTH / vbW;
    var scaleText = 'Scale ' + (scale >= 1 ? fmt(Math.round(scale * 100) / 100) + ' : 1' : '1 : ' + fmt(Math.round(100 / scale) / 100)) + ' (A4 print)';
    var tb = [];
    tb.push('<rect class="tb-frame" x="' + fmt(tbX) + '" y="' + fmt(tbY) + '" width="' + fmt(tbW) + '" height="' + fmt(tbH) + '"/>');
    tb.push(textEl('tb-name', tbX + 3, tbY + 4.8, rec.name, nameFs));
    var yy = tbY + headH;
    tb.push(line('tb-rule', tbX, yy, tbX + tbW, yy));
    [ 'C.I.P. table ' + rec.tab, 'revised ' + rec.revised, 'Dimensions in mm', scaleText ].forEach(function (t, i) {
      tb.push(textEl('tb-text', tbX + 3, yy + 3.4 + i * rowH, t, tFs));
    });
    var by = yy + 3.4 + 4 * rowH - 1.2;
    tb.push(line('tb-rule', tbX + 3, by, tbX + 13, by), line('tb-rule', tbX + 3, by - 1, tbX + 3, by + 1), line('tb-rule', tbX + 13, by - 1, tbX + 13, by + 1));
    tb.push(textEl('tb-text', tbX + 15, by + 0.9, '10 mm', tFs));

    // ----- notes -----
    var notes = g.notes.slice();
    var optional = {
      P2: c.powderChamber.P2, H1: (c.collar || {}).H1, H2: c.collar.H2, G1: (c.projectile || {}).G1,
      L1: ln.L1, L2: ln.L2, E1: ch.E1, alpha: (c.junctionCone || {}).alpha
    };
    var label = function (k) { return k === 'alpha' ? 'α' : k; };
    var absent = Object.keys(optional).filter(function (k) { return !drawn[k]; });
    var unpublished = absent.filter(function (k) { return optional[k] === undefined || optional[k] === null; }).map(label);
    var notDrawn = absent.filter(function (k) { return optional[k] !== undefined && optional[k] !== null; }).map(label);
    if (unpublished.length) notes.push({ feature: 'dimensions', missing: unpublished, text: 'Not dimensioned (not published): ' + unpublished.join(', ') + '.' });
    if (notDrawn.length) notes.push({ feature: 'dimensions-feature', missing: [], text: 'Not dimensioned (feature not drawn): ' + notDrawn.join(', ') + '.' });

    // ----- assemble -----
    var wallPoly = pk
      ? [{ x: pk.depth, y: 0 }, { x: pk.depth, y: pk.d / 2 }, { x: 0, y: pk.d / 2 }]
      : [lowerOuter[0]];
    var parts = [];
    parts.push('<title>' + escapeXml(rec.name) + ' drawing</title>');
    parts.push('<defs><pattern id="hatch" patternUnits="userSpaceOnUse" width="0.9" height="0.9" patternTransform="rotate(45)"><line class="hatch-line" x1="0" y1="0" x2="0" y2="0.9"/></pattern></defs>');
    parts.push('<g class="section">');
    parts.push('<path class="wall" fill="url(#hatch)" d="' + pathD(lowerCase, true) + '"/>');
    if (bullet) {
      parts.push('<path class="bullet-fill" d="' + pathD(lowerBullet, true) + '"/>');
      parts.push('<path class="bullet-fill" d="' + pathD(upperBullet.concat([{ x: bullet.exposed[0].z, y: 0 }]), true) + '"/>');
    }
    parts.push('</g>');
    parts.push('<g class="outlines">');
    parts.push('<path class="outline" d="' + pathD(upper, false) + '"/>');
    parts.push('<path class="outline" d="' + pathD(lowerCase, false) + '"/>');
    if (bullet) parts.push('<path class="outline" d="' + pathD(lowerBullet.slice(0, -1), false) + '"/>');
    parts.push('</g>');
    parts.push('<line class="centre" stroke-dasharray="6 1.2 1 1.2" x1="-4" y1="0" x2="' + fmt(ln.L6 + 4) + '" y2="0"/>');
    parts.push(dims.join(''));
    parts.push('<g class="title-block">' + tb.join('') + '</g>');

    var vb = [Math.round(vbX * 100) / 100, Math.round(vbY * 100) / 100, Math.round(vbW * 100) / 100, Math.round(vbH * 100) / 100];
    var svg = '<svg xmlns="http://www.w3.org/2000/svg" class="cartridge-drawing" role="img" aria-label="' + escapeXml(rec.name) + ' drawing" viewBox="' + vb.join(' ') + '" preserveAspectRatio="xMidYMid meet">' + parts.join('') + '</svg>';

    return {
      svg: svg, notes: notes, geometry: g, missingRequired: [], scale: scale,
      layout: {
        viewBox: vb, labels: eng.labels, segments: eng.segs, upper: upper, bulletUpper: upperBullet, bulletLower: lowerBullet
      }
    };
  }

  // Overlaps between labels, and between a label and any line other than leaders (own leader excluded).
  function findCollisions(layout) {
    var bad = [], L = layout.labels, S = layout.segments, i, j;
    for (i = 0; i < L.length; i++) {
      for (j = i + 1; j < L.length; j++) if (rectsOverlap(L[i].box, L[j].box, 0.2)) bad.push('label ' + L[i].text + ' overlaps label ' + L[j].text);
      for (j = 0; j < S.length; j++) if (S[j].kind !== 'leader' && segHitsRect(S[j], L[i].box, 0.2)) bad.push('label ' + L[i].text + ' touches ' + S[j].kind + ' of ' + S[j].owner);
      for (j = 0; j < S.length; j++) if (S[j].kind === 'leader' && S[j].owner !== L[i].id && segHitsRect(S[j], L[i].box, 0.2)) bad.push('leader of ' + S[j].owner + ' crosses label ' + L[i].text);
    }
    return bad;
  }

  return { render: render, findCollisions: findCollisions, escapeXml: escapeXml };
});
