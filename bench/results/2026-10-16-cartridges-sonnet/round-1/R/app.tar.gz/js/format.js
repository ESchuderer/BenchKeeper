'use strict';
// Value formatting, symbols, units, table sections and search. Pure functions, no DOM.
(function (root, factory) {
  var api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  else { root.CIP = root.CIP || {}; root.CIP.Format = api; }
})(typeof self !== 'undefined' ? self : this, function () {
  var SYMBOLS = {
    eMin: 'e min', r1Min: 'r1 min', r1Max: 'r1 max', alpha: 'α', alpha1: 'α1',
    beta: 'β', delta: 'δ', deltaL: 'delta L', L3PlusG: 'L3 + G'
  };
  var ANGLE_FIELDS = { alpha: 1, alpha1: 1, beta: 1, delta: 1, i: 1 };
  var UNITS = { Pmax: 'bar', PK: 'bar', PE: 'bar', EE: 'J', M: 'g', Q: 'mm²', N: '' };

  var SECTION_TITLES = {
    cartridge: {
      caseHead: 'Case head', collar: 'Collar', junctionCone: 'Shoulder (junction cone)', lengths: 'Lengths',
      misc: 'Miscellaneous', powderChamber: 'Powder chamber', pressures: 'Pressures', projectile: 'Projectile'
    },
    chamber: {
      barrel: 'Barrel', breech: 'Breech', collar: 'Collar', grooves: 'Grooves', junctionCone: 'Shoulder (junction cone)',
      lengths: 'Lengths', powderChamber: 'Powder chamber', rifling: 'Rifling'
    }
  };
  var SECTION_ORDER = {
    cartridge: ['caseHead', 'collar', 'junctionCone', 'lengths', 'powderChamber', 'projectile', 'pressures', 'misc'],
    chamber: ['barrel', 'breech', 'collar', 'junctionCone', 'lengths', 'powderChamber', 'grooves', 'rifling']
  };
  var FIELD_ORDER = {
    caseHead: ['R1', 'R3', 'R', 'E1', 'E', 'eMin', 'f', 'beta', 'delta'],
    collar: ['H1', 'H2'],
    junctionCone: ['S', 'alpha', 'r1Min', 'r1Max', 'r2'],
    lengths: ['L1', 'L2', 'L3', 'L4', 'L5', 'L6'],
    misc: ['Fe', 'deltaL'],
    powderChamber: ['P1', 'P2', 'E'],
    pressures: ['Pmax', 'PK', 'PE', 'EE', 'M'],
    projectile: ['G1', 'G2', 'L3PlusG'],
    barrel: ['F', 'Z'],
    breech: ['R1', 'R3', 'R', 'r'],
    grooves: ['N', 'Q', 'b', 'u'],
    rifling: ['G', 'G1', 'alpha1', 'h', 'i', 's']
  };

  function formatNumber(n) {
    if (n === 0) return '0';
    return String(n);
  }

  function angleDegrees(a) {
    if (a && typeof a === 'object') return a.degrees + a.minutes / 60 + a.seconds / 3600;
    return a;
  }

  function formatAngle(a) {
    if (a && typeof a === 'object') return formatNumber(a.degrees) + '°' + formatNumber(a.minutes) + "'" + formatNumber(a.seconds) + '"';
    return formatNumber(a) + '°';
  }

  function symbolLabel(field) { return SYMBOLS[field] || field; }
  function isAngleField(field) { return ANGLE_FIELDS[field] === 1; }
  function unitOf(field) {
    if (isAngleField(field)) return 'deg';
    return Object.prototype.hasOwnProperty.call(UNITS, field) ? UNITS[field] : 'mm';
  }

  function tolText(tol) {
    if (typeof tol !== 'number') return '';
    return (tol > 0 ? '+' : '') + formatNumber(tol);
  }

  // Value of obj[key] as text, with its tolerance (obj[key + 'Tol']) next to it.
  function valueWithTol(obj, key) {
    var v = obj[key];
    if (isAngleField(key)) return formatAngle(v);
    var t = tolText(obj[key + 'Tol']);
    return formatNumber(v) + (t ? ' ' + t : '');
  }

  function isTolKey(key, obj) {
    return /Tol$/.test(key) && key.length > 3;
  }

  // Sections of one part ('cartridge' | 'chamber') as [{id, title, rows:[{key, symbol, value, unit}]}].
  function buildSections(part, kind) {
    var ids = Object.keys(part);
    var order = SECTION_ORDER[kind] || [];
    ids.sort(function (a, b) {
      var ia = order.indexOf(a), ib = order.indexOf(b);
      return (ia < 0 ? 99 : ia) - (ib < 0 ? 99 : ib);
    });
    var out = [];
    ids.forEach(function (id) {
      var obj = part[id];
      var keys = Object.keys(obj).filter(function (k) { return !isTolKey(k, obj); });
      if (!keys.length) return;
      var fo = FIELD_ORDER[id] || [];
      keys.sort(function (a, b) {
        var ia = fo.indexOf(a), ib = fo.indexOf(b);
        return (ia < 0 ? 99 : ia) - (ib < 0 ? 99 : ib);
      });
      out.push({
        id: id,
        title: (SECTION_TITLES[kind] && SECTION_TITLES[kind][id]) || id,
        rows: keys.map(function (k) {
          return { key: k, symbol: symbolLabel(k), value: valueWithTol(obj, k), unit: unitOf(k) };
        })
      });
    });
    return out;
  }

  function normalize(s) {
    return String(s).normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().replace(/×/g, 'x').replace(/,/g, '.').replace(/\s+/g, '');
  }

  function matchesQuery(rec, q) {
    var n = normalize(q || '');
    if (!n) return true;
    var names = [rec.name].concat(rec.alternativeNames || []);
    return names.some(function (nm) { return normalize(nm).indexOf(n) >= 0; });
  }

  function filterCartridges(list, q, family) {
    return list.filter(function (r) {
      return (!family || family === 'all' || r.family === family) && matchesQuery(r, q);
    });
  }

  return {
    formatNumber: formatNumber, formatAngle: formatAngle, angleDegrees: angleDegrees, symbolLabel: symbolLabel,
    unitOf: unitOf, isAngleField: isAngleField, valueWithTol: valueWithTol, buildSections: buildSections,
    matchesQuery: matchesQuery, filterCartridges: filterCartridges, normalize: normalize
  };
});
