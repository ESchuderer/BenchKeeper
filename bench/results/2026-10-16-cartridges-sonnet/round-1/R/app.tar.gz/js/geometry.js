'use strict';
// Pure geometry of a cartridge drawing (brief rules 1-9). Points are {z, r}: z along the axis from the
// head face (z = 0) to the mouth, r the radius. No DOM. Missing values never get replaced by numbers:
// the feature is skipped and recorded in `notes`.
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory(require('./format.js'));
  else { root.CIP = root.CIP || {}; root.CIP.Geometry = factory(root.CIP.Format); }
})(typeof self !== 'undefined' ? self : this, function (Format) {
  var RAD = Math.PI / 180;
  function isNum(v) { return typeof v === 'number' && isFinite(v); }
  function isAngle(v) { return isNum(v) || (v && typeof v === 'object' && isNum(v.degrees)); }
  function pt(z, r) { return { z: z, r: r }; }
  function sym(k) { return Format.symbolLabel(k); }

  function rimType(rec) {
    if (rec.family === 'belted') return 'belted';
    if (rec.family === 'rimfire') return 'rimfire';
    var ch = rec.cartridge.caseHead || {}, pc = rec.cartridge.powderChamber || {};
    var ratio = ch.R1 / pc.P1;
    if (ratio >= 1.05) return 'rimmed';
    if (ratio < 0.98) return 'rebated';
    return 'rimless';
  }

  // Rule 8 / heeled case: tn = (H2 - G1)/2, tb = min(max(1.3 tn, 0.6), 0.35 P1/2).
  function wallThicknesses(v) {
    var heeled = v.H2 - v.G1 <= 0.015;
    var tn = (v.H2 - v.G1) / 2;
    var tb = Math.min(Math.max(1.3 * tn, 0.6), 0.35 * v.P1 / 2);
    return { tn: tn, tb: tb, heeled: heeled };
  }

  var POCKET_D = { sp: 4.45, spm: 4.45, sr: 4.45, lp: 5.33, lpm: 5.33, lr: 5.33, lrm: 5.33 };
  var POCKET_DEPTH = { sp: 3.04, spm: 3.04, sr: 3.04, lp: 3.04, lpm: 3.04, lr: 3.3, lrm: 3.3 };
  function pocket(rec) {
    var t = rec.annotations && rec.annotations.primerType;
    if (!t || !POCKET_D[t]) return null;
    return { d: POCKET_D[t], depth: POCKET_DEPTH[t] };
  }

  // Radius of a z-ordered polyline at z (last segment wins at a vertical step).
  function outerRadiusAt(points, z) {
    for (var i = points.length - 1; i > 0; i--) {
      var a = points[i - 1], b = points[i];
      if (b.z > a.z && z >= a.z && z <= b.z) return a.r + (b.r - a.r) * (z - a.z) / (b.z - a.z);
    }
    return z <= points[0].z ? points[0].r : points[points.length - 1].r;
  }

  // Rounds the corner B between A and C with radius r (clamped so neighbours keep a straight part).
  function fillet(A, B, C, r) {
    var u1 = unit(A, B), u2 = unit(C, B);
    var dot = Math.max(-1, Math.min(1, u1.z * u2.z + u1.r * u2.r));
    var psi = Math.acos(dot); // angle between the two legs
    var defl = Math.PI - psi;
    if (defl < 1e-4) return [B];
    var t = r * Math.tan(defl / 2);
    var lim = 0.45 * Math.min(dist(A, B), dist(C, B));
    if (t > lim) { t = lim; r = t / Math.tan(defl / 2); }
    var T1 = pt(B.z + u1.z * t, B.r + u1.r * t), T2 = pt(B.z + u2.z * t, B.r + u2.r * t);
    var bis = unit2(u1.z + u2.z, u1.r + u2.r);
    var d = r / Math.sin(psi / 2);
    var O = pt(B.z + bis.z * d, B.r + bis.r * d);
    var a1 = Math.atan2(T1.r - O.r, T1.z - O.z), a2 = Math.atan2(T2.r - O.r, T2.z - O.z);
    var da = a2 - a1;
    while (da > Math.PI) da -= 2 * Math.PI;
    while (da < -Math.PI) da += 2 * Math.PI;
    var n = 10, out = [];
    for (var i = 0; i <= n; i++) {
      var a = a1 + da * i / n;
      out.push(pt(O.z + r * Math.cos(a), O.r + r * Math.sin(a)));
    }
    return out;
  }
  function dist(a, b) { return Math.hypot(a.z - b.z, a.r - b.r); }
  function unit(to, from) { return unit2(to.z - from.z, to.r - from.r); }
  function unit2(z, r) { var l = Math.hypot(z, r) || 1; return { z: z / l, r: r / l }; }

  // Outer half-profile from the axis at the head face to the mouth (rules 2-6).
  function outerProfile(rec, notes) {
    var c = rec.cartridge, ch = c.caseHead || {}, col = c.collar || {}, jc = c.junctionCone || {};
    var ln = c.lengths || {}, pc = c.powderChamber || {};
    var type = rimType(rec);
    var R1 = ch.R1, R = ch.R, P1 = pc.P1, H2 = col.H2, L3 = ln.L3;
    var feat = { chamfer: false, groove: false, belt: false, shoulder: false, halfRound: false };
    var marks = {};
    var pts = [pt(0, 0)];
    var rBack = R1 / 2;

    // head face and rim edge
    if (type === 'rimfire') {
      var rho = Math.min(R / 2, (R1 - P1) / 2), rc = R1 / 2 - rho, zc = R / 2;
      feat.halfRound = true;
      pts.push(pt(0, rc));
      if (zc - rho > 1e-9) pts.push(pt(zc - rho, rc));
      for (var i = 1; i <= 16; i++) {
        var t = Math.PI * i / 16;
        pts.push(pt(zc - rho * Math.cos(t), rc + rho * Math.sin(t)));
      }
      if (zc + rho < R - 1e-9) pts.push(pt(R, rc));
      rBack = rc;
    } else {
      var missChamfer = [];
      if (!isAngle(ch.beta)) missChamfer.push(sym('beta'));
      if (!isNum(ch.f)) missChamfer.push(sym('f'));
      if (!missChamfer.length && Format.angleDegrees(ch.beta) < 90) {
        var cc = Math.min(ch.f * Math.tan(Format.angleDegrees(ch.beta) * RAD), R1 / 4);
        feat.chamfer = true;
        pts.push(pt(0, R1 / 2 - cc), pt(ch.f, R1 / 2), pt(R, R1 / 2));
      } else {
        pts.push(pt(0, R1 / 2), pt(R, R1 / 2));
        if (missChamfer.length) notes.push({ feature: 'chamfer', missing: missChamfer, text: 'Head chamfer not drawn (square corner): ' + missChamfer.join(', ') + ' not published.' });
      }
    }
    marks.rimBack = pt(R, rBack);

    // extractor groove / belt
    var needG = [];
    if (!isNum(ch.E)) needG.push(sym('E'));
    if (!isNum(ch.E1)) needG.push(sym('E1'));
    if (!isNum(ch.eMin)) needG.push(sym('eMin'));
    var bodyStartZ = R;
    if (!needG.length) {
      feat.groove = true;
      pts.push(pt(R, ch.E1 / 2), pt(R + ch.eMin, ch.E1 / 2));
      marks.grooveFloor = pt(R, ch.E1 / 2);
      marks.floorEnd = pt(R + ch.eMin, ch.E1 / 2);
      var belted = false;
      if (type === 'belted') {
        var needB = [];
        if (!isNum(ch.R3)) needB.push(sym('R3'));
        if (!isAngle(ch.delta)) needB.push(sym('delta'));
        if (needB.length) {
          notes.push({ feature: 'belt', missing: needB, text: 'Belt not drawn (plain groove ramp instead): ' + needB.join(', ') + ' not published.' });
        } else {
          var dr = ch.R3 / 2 - ch.E1 / 2;
          var dz = dr / Math.tan(Format.angleDegrees(ch.delta) * RAD);
          var zEnd = R + ch.eMin + dz;
          if (dr > 0 && isFinite(dz) && zEnd < ch.E) {
            belted = true; feat.belt = true;
            marks.rampEndZ = zEnd;
            pts.push(pt(zEnd, ch.R3 / 2), pt(ch.E, ch.R3 / 2), pt(ch.E, P1 / 2));
          } else {
            notes.push({ feature: 'belt', missing: [], text: 'Belt not drawn (plain groove ramp instead): R3, δ and E do not form a ramp.' });
          }
        }
      }
      if (!belted) pts.push(pt(ch.E, P1 / 2));
      bodyStartZ = ch.E;
    } else {
      pts.push(pt(R, P1 / 2));
      if (type !== 'rimfire') notes.push({ feature: 'groove', missing: needG, text: 'Extractor groove not drawn: ' + needG.join(', ') + ' not published.' });
    }
    var bodyStart = pts[pts.length - 1];
    marks.bodyStart = pt(bodyStart.z, bodyStart.r);

    // body, shoulder, neck
    var mouth = pt(L3, H2 / 2);
    marks.mouth = mouth;
    var missShoulder = [];
    if (!isAngle(jc.alpha)) missShoulder.push(sym('alpha'));
    if (!isNum(ln.L1)) missShoulder.push(sym('L1'));
    if (!isNum(ln.L2)) missShoulder.push(sym('L2'));
    var needN = [];
    if (!missShoulder.length) {
      if (!isNum(pc.P2)) needN.push(sym('P2'));
      if (!isNum(col.H1)) needN.push(sym('H1'));
    }
    if (!missShoulder.length && !needN.length) {
      feat.shoulder = true;
      var S1 = pt(ln.L1, pc.P2 / 2), S2 = pt(ln.L2, col.H1 / 2);
      marks.shoulderStart = pt(S1.z, S1.r);
      marks.shoulderEnd = pt(S2.z, S2.r);
      if (isNum(jc.r1Min)) pts = pts.concat(fillet(bodyStart, S1, S2, jc.r1Min)); else {
        pts.push(S1);
        notes.push({ feature: 'fillet', missing: [sym('r1Min')], text: 'Body-side shoulder corner not rounded: ' + sym('r1Min') + ' not published.' });
      }
      if (isNum(jc.r2)) pts = pts.concat(fillet(S1, S2, mouth, jc.r2)); else {
        pts.push(S2);
        notes.push({ feature: 'fillet', missing: [sym('r2')], text: 'Neck-side shoulder corner not rounded: r2 not published.' });
      }
      pts.push(mouth);
    } else {
      pts.push(mouth);
      if (missShoulder.length) notes.push({ feature: 'shoulder', missing: missShoulder, text: 'Straight case, no shoulder drawn: ' + missShoulder.join(', ') + ' not published.' });
      else notes.push({ feature: 'shoulder', missing: needN, text: 'Straight case, no shoulder drawn: ' + needN.join(', ') + ' not published.' });
    }
    return { points: pts, features: feat, marks: marks, bodyStartZ: bodyStartZ };
  }

  // Rule 7. Returns null (with a note) when G1 or L6 is missing.
  var K = {
    pointy: function () { return 0.40; },
    rounded: function (pistol) { return pistol ? 0.65 : 0.55; },
    flat: function (pistol) { return pistol ? 0.70 : 0.60; },
    semi_wadcutter: function () { return 0.78; }
  };
  function bulletGeometry(rec, walls, notes) {
    var c = rec.cartridge, ln = c.lengths || {}, G1 = (c.projectile || {}).G1, H2 = (c.collar || {}).H2;
    var L3 = ln.L3, L6 = ln.L6;
    var miss = [];
    if (!isNum(G1)) miss.push('G1');
    if (!isNum(L6)) miss.push('L6');
    if (miss.length) {
      notes.push({ feature: 'bullet', missing: miss, text: 'Bullet not drawn: ' + miss.join(', ') + ' not published.' });
      return null;
    }
    var shape = (rec.annotations && rec.annotations.defaultBulletShape) || null;
    if (!K[shape]) {
      notes.push({ feature: 'bullet', missing: ['bullet shape'], text: 'Bullet not drawn: bullet shape not known.' });
      return null;
    }
    var pistol = rec.annotations.category === 'pistol';
    if (!rec.annotations.category && (shape === 'rounded' || shape === 'flat')) {
      notes.push({ feature: 'bullet-class', missing: ['category'], text: 'Bullet seating assumes a rifle or rimfire cartridge: category not published.' });
    }
    var sf = shape === 'pointy' ? 1.0 : shape === 'semi_wadcutter' ? 0.6 : pistol ? 0.4 : 0.8;
    var s = sf * G1;
    var zb = L3 - s, Lb = L6 - zb;
    var zc = zb + K[shape](pistol) * Lb;
    var heeled = walls.heeled;
    var rExp = (heeled ? H2 : G1) / 2;
    var rSeat = heeled ? H2 / 2 - walls.tb : G1 / 2;
    var m = shape === 'pointy' ? Math.max(0.08 * G1, 1.27) : shape === 'rounded' ? 0.15 * G1 : shape === 'flat' ? 0.55 * G1 : 0.6 * G1;
    var n = L6 - zc, rho = null;
    var prof = [pt(zb, 0), pt(zb, rSeat)];
    if (heeled && zc > L3) prof.push(pt(L3, rSeat), pt(L3, rExp));
    prof.push(pt(zc, rExp));
    var N = 24, a = rExp - m / 2;
    if (shape === 'pointy') {
      rho = (a * a + n * n) / (2 * a);
      var phiE = Math.asin(n / rho);
      for (var i = 1; i <= N; i++) {
        var phi = phiE * i / N;
        prof.push(pt(zc + rho * Math.sin(phi), rExp - rho + rho * Math.cos(phi)));
      }
    } else if (shape === 'rounded') {
      for (var j = 1; j <= N; j++) {
        var t = Math.PI / 2 * j / N;
        prof.push(pt(zc + n * Math.sin(t), m / 2 + a * Math.cos(t)));
      }
    } else {
      prof.push(pt(L6, m / 2));
    }
    // make the tip exact
    prof[prof.length - 1] = pt(L6, m / 2);
    prof.push(pt(L6, 0));
    var exposed = clipFrom(prof.slice(0, prof.length - 1), L3);
    return {
      shape: shape, s: s, zb: zb, Lb: Lb, zc: zc, m: m, n: n, rho: rho, heeled: heeled,
      rExp: rExp, rSeat: rSeat, G1: G1, profile: prof, exposed: exposed
    };
  }

  // Part of a z-increasing polyline at or beyond z, starting with the interpolated point at z.
  function clipFrom(points, z) {
    var out = [];
    for (var i = 0; i < points.length; i++) {
      var p = points[i];
      if (p.z >= z - 1e-12) {
        if (!out.length && i > 0 && p.z > z + 1e-12) {
          var a = points[i - 1];
          out.push(pt(z, a.r + (p.r - a.r) * (z - a.z) / (p.z - a.z)));
        } else if (!out.length && p.z > z + 1e-12) {
          out.push(pt(z, p.r));
        }
        out.push(p);
      }
    }
    // heel step at the mouth: the exposed outline begins at the exposed radius
    if (out.length > 1 && Math.abs(out[0].z - out[1].z) < 1e-12) out.shift();
    return out;
  }

  // Wall thickness at z along the inner line (rule 8).
  function wallAt(g, z) {
    var tb = g.tb, tn = g.tn;
    if (g.walls.heeled) return tb;
    if (g.features.shoulder) {
      var L1 = g.marks.shoulderStart.z, L2 = g.marks.shoulderEnd.z;
      if (z <= L1) return tb;
      if (z >= L2) return tn;
      return tb + (tn - tb) * (z - L1) / (L2 - L1);
    }
    if (!g.bullet) return tb;
    var z1 = g.bullet.zb, z0 = z1 - Math.max(tb - tn, 1e-9);
    if (z <= z0) return tb;
    if (z >= z1) return tn;
    return tb + (tn - tb) * (z - z0) / (z1 - z0);
  }

  function innerRadiusAt(g, z) {
    if (z < g.marks.bodyStart.z) return g.marks.bodyStart.r - g.tb;
    return outerRadiusAt(g.outer, z) - wallAt(g, z);
  }

  function build(rec) {
    var c = rec.cartridge;
    var need = { L3: (c.lengths || {}).L3, H2: (c.collar || {}).H2, P1: (c.powderChamber || {}).P1, R1: (c.caseHead || {}).R1, R: (c.caseHead || {}).R };
    var missingRequired = Object.keys(need).filter(function (k) { return !isNum(need[k]); });
    if (missingRequired.length) return { ok: false, missingRequired: missingRequired, notes: [] };

    var notes = [];
    var op = outerProfile(rec, notes);
    var G1 = (c.projectile || {}).G1;
    var walls = isNum(G1) ? wallThicknesses({ H2: need.H2, G1: G1, P1: need.P1 })
      : { tn: NaN, tb: Math.min(0.6, 0.35 * need.P1 / 2), heeled: false };
    if (!isNum(G1)) walls.tn = walls.tb;
    var g = {
      ok: true, missingRequired: [], rimType: rimType(rec), outer: op.points, marks: op.marks, features: op.features,
      notes: notes, walls: walls, tn: walls.tn, tb: walls.tb
    };
    g.bullet = bulletGeometry(rec, walls, notes);
    g.pocket = pocket(rec);
    if (!g.pocket && g.rimType !== 'rimfire' && !(rec.annotations && rec.annotations.primerType === 'rimfire')) {
      notes.push({ feature: 'pocket', missing: ['primer type'], text: 'Primer pocket not drawn: primer type not published or not known.' });
    }
    // solid head length w
    var cands = [2.5, 0.25 * need.P1 / 2];
    if (g.pocket) cands.push(g.pocket.depth + 1.5);
    if (g.features.belt) cands.push(op.marks.rampEndZ + g.tb);
    else if (g.features.groove) cands.push(rec.cartridge.caseHead.E + g.tb);
    g.w = Math.max.apply(null, cands);
    g.w = Math.max(g.w, 0);
    var a = rec.cartridge.junctionCone || {};
    g.alpha = g.features.shoulder ? Format.angleDegrees(a.alpha) : null;
    g.alphaRaw = g.features.shoulder ? a.alpha : null;

    // inner line from the cavity floor to the mouth
    var zs = [g.w, op.marks.bodyStart.z, need.L3];
    op.points.forEach(function (p) { zs.push(p.z); });
    if (g.features.shoulder) zs.push(op.marks.shoulderStart.z, op.marks.shoulderEnd.z);
    if (!g.features.shoulder && g.bullet) zs.push(g.bullet.zb, g.bullet.zb - Math.max(g.tb - g.tn, 1e-9));
    zs = zs.filter(function (z) { return z >= g.w - 1e-12 && z <= need.L3 + 1e-12; }).sort(function (x, y) { return x - y; });
    g.inner = [];
    zs.forEach(function (z) {
      if (g.inner.length && Math.abs(g.inner[g.inner.length - 1].z - z) < 1e-9) return;
      g.inner.push(pt(z, innerRadiusAt(g, z)));
    });
    return g;
  }

  return {
    rimType: rimType, wallThicknesses: wallThicknesses, pocket: pocket, outerRadiusAt: outerRadiusAt,
    innerRadiusAt: innerRadiusAt, wallAt: wallAt, build: build, fillet: fillet
  };
});
