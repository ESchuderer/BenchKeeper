'use strict';
const test = require('node:test');
const assert = require('node:assert');
const fs = require('node:fs');
const path = require('node:path');

const root = path.join(__dirname, '..');

test('data/cartridges.jsonl holds 25 records with unique keys', () => {
  const lines = fs.readFileSync(path.join(root, 'data/cartridges.jsonl'), 'utf8').split('\n').filter(Boolean);
  assert.strictEqual(lines.length, 25);
  const recs = lines.map((l) => JSON.parse(l));
  assert.strictEqual(new Set(recs.map((r) => r.key)).size, 25);
});

test('js/data.js exposes exactly the records of the jsonl file', () => {
  const lines = fs.readFileSync(path.join(root, 'data/cartridges.jsonl'), 'utf8').split('\n').filter(Boolean);
  const expected = lines.map((l) => JSON.parse(l));
  const data = require(path.join(root, 'js/data.js'));
  assert.deepStrictEqual(data, expected);
});
