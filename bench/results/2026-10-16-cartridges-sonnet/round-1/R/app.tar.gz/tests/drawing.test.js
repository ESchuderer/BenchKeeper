'use strict';
const test = require('node:test');
const assert = require('node:assert');
const D = require('../js/drawing.js');
const DATA = require('../js/data.js');
const rec = (k) => structuredClone(DATA.find((r) => r.key === k));

function texts(svg) {
  return [...svg.matchAll(/<text[^>]*>([^<]*)<\/text>/g)].map((m) => m[1].replace(/&quot;/g, '"').replace(/&amp;/g, '&'));
}
function groups(svg) {
  const out = {};
  for (const m of svg.matchAll(/<g class="dim" data-dim="([^"]+)">([\s\S]*?)<\/g>/g)) out[m[1]] = m[2];
  return out;
}

test('svg root: accessible name, viewBox in mm, centre line, hatching', () => {
  const out = D.render(rec('308_win'));
  const svg = out.svg;
  assert.match(svg, /^<svg [^>]*xmlns="http:\/\/www\.w3\.org\/2000\/svg"/);
  assert.match(svg, /role="img"/);
  assert.match(svg, /aria-label="308 Win\. drawing"/);
  assert.match(svg, /viewBox="-?[\d.]+ -?[\d.]+ [\d.]+ [\d.]+"/);
  assert.match(svg, /class="centre"[^>]*stroke-dasharray="[\d. ]+"/);
  assert.match(svg, /<pattern id="hatch"/);
  assert.match(svg, /fill="url\(#hatch\)"/);
});

test('dimension labels carry symbol and value; tolerance next to its value', () => {
  const t = texts(D.render(rec('308_win')).svg);
  for (const s of ['L3 51.18', 'L6 71.12', 'R1 12.01', 'R 1.37', 'P1 11.96', 'P2 11.53 -0.2', 'H1 8.72', 'H2 8.72', 'G1 7.85', 'E1 10.39', 'α 40°', 'L1 39.62 -0.2', 'L2 43.48 -0.2']) {
    assert.ok(t.includes(s), `label "${s}" in ${JSON.stringify(t)}`);
  }
});

test('angle in degrees/minutes/seconds is labelled as published', () => {
  const t = texts(D.render(rec('338_lapua_mag')).svg);
  assert.ok(t.includes('α 39°59\'49"'), JSON.stringify(t));
});

test('each dimension has two arrowheads and extension lines', () => {
  const g = groups(D.render(rec('308_win')).svg);
  for (const id of ['L3', 'L6', 'R1', 'R', 'P1', 'P2', 'H1', 'H2', 'G1', 'L1', 'L2', 'E1']) {
    assert.ok(g[id], `dim ${id}`);
    assert.ok((g[id].match(/class="arrow"/g) || []).length >= 2, `${id} arrows`);
    assert.ok((g[id].match(/class="ext"/g) || []).length >= 1, `${id} extension line`);
    assert.ok(/class="dim-line"/.test(g[id]), `${id} dimension line`);
  }
  assert.ok(g['alpha'] && /class="arrow"/.test(g['alpha']) && /<path[^>]*class="dim-line"/.test(g['alpha']));
});

test('unpublished dimensions are not drawn and are reported', () => {
  const out = D.render(rec('22_win_mag_r_f'));
  const g = groups(out.svg);
  for (const id of ['L3', 'L6', 'R1', 'R', 'P1', 'H2', 'G1']) assert.ok(g[id], id);
  for (const id of ['P2', 'H1', 'L1', 'L2', 'E1', 'alpha']) assert.ok(!g[id], id);
  assert.ok(!texts(out.svg).some((s) => s.startsWith('α')));
  const notes = out.notes.map((n) => n.text).join(' | ');
  assert.match(notes, /α, L1, L2/);
  assert.match(notes, /Not dimensioned \(not published\): P2, H1, L1, L2, E1, α\./);
});

test('title block: name, table, revision, units and scale', () => {
  const t = texts(D.render(rec('308_win')).svg);
  assert.ok(t.includes('308 Win.'));
  assert.ok(t.includes('C.I.P. table I'), JSON.stringify(t));
  assert.ok(t.some((s) => /revised 2008-09-23/.test(s)), JSON.stringify(t));
  assert.ok(t.includes('Dimensions in mm'));
  assert.ok(t.some((s) => /^Scale \d+(\.\d+)? : 1/.test(s)), JSON.stringify(t));
});

test('1 user unit = 1 mm: outline spans z = 0 .. L6 and r = P1/2.. in mm', () => {
  const out = D.render(rec('308_win'));
  const up = out.layout.upper;
  const xs = up.map((p) => p.x), ys = up.map((p) => p.y);
  assert.ok(Math.abs(Math.min(...xs) - 0) < 1e-9);
  assert.ok(Math.abs(Math.max(...xs) - 71.12) < 1e-9);
  assert.ok(Math.abs(Math.min(...ys) - -12.01 / 2) < 1e-9, 'top of the rim at -R1/2');
  assert.ok(out.svg.includes('51.18 -4.36'), 'mouth corner in mm');
  const [, , w, h] = out.layout.viewBox;
  assert.ok(w >= 71.12 && h > 12.01);
});

test('outside view hides the seated bullet, section shows it', () => {
  const out = D.render(rec('308_win'));
  const exposed = out.layout.bulletUpper;
  assert.ok(Math.abs(exposed[0].x - 51.18) < 1e-9);
  assert.ok(exposed.every((p) => p.y <= 0));
  const lower = out.layout.bulletLower;
  assert.ok(Math.abs(lower[0].x - (51.18 - 7.85)) < 1e-9);
  assert.ok(lower.every((p) => p.y >= 0));
});

test('labels never overlap each other, the outline or other dimension lines (all 25)', () => {
  for (const r of DATA) {
    const out = D.render(r);
    const bad = D.findCollisions(out.layout);
    assert.deepStrictEqual(bad, [], `${r.key}: ${JSON.stringify(bad)}`);
    const [x, y, w, h] = out.layout.viewBox;
    for (const l of out.layout.labels) {
      assert.ok(l.box.x >= x && l.box.x + l.box.w <= x + w && l.box.y >= y && l.box.y + l.box.h <= y + h, `${r.key} ${l.text} inside viewBox`);
    }
  }
});

test('every record draws the mandatory dimensions', () => {
  for (const r of DATA) {
    const g = groups(D.render(r).svg);
    for (const id of ['L3', 'L6', 'R1', 'R', 'P1']) assert.ok(g[id], `${r.key} ${id}`);
  }
});

test('escape helper', () => {
  assert.strictEqual(D.escapeXml('40 S.& W. <x> "q"'), '40 S.&amp; W. &lt;x&gt; &quot;q&quot;');
  assert.match(D.render(rec('40_s_w')).svg, /aria-label="40 S\.&amp; W\. drawing"/);
});

test('record that cannot be drawn reports the missing required values', () => {
  const r = rec('308_win'); delete r.cartridge.lengths.L3;
  const out = D.render(r);
  assert.strictEqual(out.svg, '');
  assert.deepStrictEqual(out.missingRequired, ['L3']);
});

test('a dimension that is published but cannot be drawn is not reported as unpublished', () => {
  const r = rec('308_win'); delete r.cartridge.caseHead.eMin; // E1 published, groove not drawn
  const out = D.render(r);
  const notes = out.notes.map((n) => n.text).join(' | ');
  assert.match(notes, /Extractor groove not drawn: e min not published/);
  assert.match(notes, /Not dimensioned \(feature not drawn\): E1/);
  assert.ok(!/not published\): [^|]*E1/.test(notes));
});
