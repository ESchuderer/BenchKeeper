'use strict';
const test = require('node:test');
const assert = require('node:assert');
const F = require('../js/format.js');
const DATA = require('../js/data.js');
const byKey = (k) => DATA.find((r) => r.key === k);

test('formatNumber shows values as published', () => {
  assert.strictEqual(F.formatNumber(51.18), '51.18');
  assert.strictEqual(F.formatNumber(4150.0), '4150');
  assert.strictEqual(F.formatNumber(1825), '1825');
  assert.strictEqual(F.formatNumber(0.1), '0.1');
});

test('formatAngle: degrees number and degrees/minutes/seconds object', () => {
  assert.strictEqual(F.formatAngle(40), '40°');
  assert.strictEqual(F.formatAngle({ degrees: 39, minutes: 59, seconds: 49 }), "39°59'49\"");
  assert.strictEqual(F.formatAngle({ degrees: 1, minutes: 30, seconds: 0 }), "1°30'0\"");
});

test('angleDegrees converts to decimal degrees', () => {
  assert.strictEqual(F.angleDegrees(40), 40);
  assert.ok(Math.abs(F.angleDegrees({ degrees: 39, minutes: 59, seconds: 49 }) - 39.99694444) < 1e-6);
});

test('symbolLabel maps special fields and keeps the others', () => {
  const m = { eMin: 'e min', r1Min: 'r1 min', r1Max: 'r1 max', alpha: 'α', alpha1: 'α1', beta: 'β', delta: 'δ', deltaL: 'delta L', L3PlusG: 'L3 + G', L3: 'L3', Pmax: 'Pmax' };
  for (const [k, v] of Object.entries(m)) assert.strictEqual(F.symbolLabel(k), v);
});

test('unitOf', () => {
  assert.strictEqual(F.unitOf('Pmax'), 'bar');
  assert.strictEqual(F.unitOf('PK'), 'bar');
  assert.strictEqual(F.unitOf('PE'), 'bar');
  assert.strictEqual(F.unitOf('EE'), 'J');
  assert.strictEqual(F.unitOf('M'), 'g');
  assert.strictEqual(F.unitOf('Q'), 'mm²');
  assert.strictEqual(F.unitOf('N'), '');
  assert.strictEqual(F.unitOf('L3'), 'mm');
  assert.strictEqual(F.unitOf('alpha'), 'deg');
  assert.strictEqual(F.unitOf('i'), 'deg');
});

test('buildSections attaches tolerance to its value and has no Tol rows', () => {
  const secs = F.buildSections(byKey('308_win').cartridge, 'cartridge');
  const lengths = secs.find((s) => s.id === 'lengths');
  assert.ok(lengths);
  const l1 = lengths.rows.find((r) => r.symbol === 'L1');
  assert.strictEqual(l1.value, '39.62 -0.2');
  assert.strictEqual(l1.unit, 'mm');
  for (const s of secs) for (const r of s.rows) assert.ok(!/Tol$/.test(r.symbol), r.symbol);
});

test('buildSections formats pressures, angles, count and drops empty sections', () => {
  const rec = byKey('308_win');
  const cart = F.buildSections(rec.cartridge, 'cartridge');
  const pmax = cart.find((s) => s.id === 'pressures').rows.find((r) => r.symbol === 'Pmax');
  assert.deepStrictEqual([pmax.value, pmax.unit], ['4150', 'bar']);
  const alpha = cart.find((s) => s.id === 'junctionCone').rows.find((r) => r.symbol === 'α');
  assert.strictEqual(alpha.value, '40°');
  const ch = F.buildSections(rec.chamber, 'chamber');
  const n = ch.find((s) => s.id === 'grooves').rows.find((r) => r.symbol === 'N');
  assert.deepStrictEqual([n.value, n.unit], ['4', '']);
  const luger = F.buildSections(byKey('9_mm_luger').cartridge, 'cartridge');
  assert.ok(!luger.some((s) => s.id === 'junctionCone'));
});

test('buildSections covers every non-Tol field of every record (nothing lost)', () => {
  for (const rec of DATA) for (const part of ['cartridge', 'chamber']) {
    const secs = F.buildSections(rec[part], part);
    for (const [sec, obj] of Object.entries(rec[part])) {
      const keys = Object.keys(obj).filter((k) => !/Tol$/.test(k));
      const got = (secs.find((s) => s.id === sec) || { rows: [] }).rows.map((r) => r.key).sort();
      assert.deepStrictEqual(got, keys.sort(), `${rec.key} ${part}.${sec}`);
    }
  }
});

test('formatLength and valueWithTol for the list column', () => {
  assert.strictEqual(F.valueWithTol(byKey('9_mm_luger').cartridge.lengths, 'L3'), '19.15 -0.25');
  assert.strictEqual(F.valueWithTol(byKey('223_rem').cartridge.lengths, 'L3'), '44.7');
});

test('matchesQuery searches name and alternative names tolerant of case, spaces, decimal comma', () => {
  assert.ok(F.matchesQuery(byKey('308_win'), '7,62 x 51'));
  assert.ok(F.matchesQuery(byKey('308_win'), '7.62x51'));
  assert.ok(F.matchesQuery(byKey('308_win'), '308 WINCHESTER'));
  assert.ok(F.matchesQuery(byKey('22_long_rifle'), '22 lang fur buchsen'));
  assert.ok(!F.matchesQuery(byKey('223_rem'), '7,62'));
  assert.ok(F.matchesQuery(byKey('223_rem'), ''));
  assert.ok(F.matchesQuery(byKey('223_rem'), '   '));
});

test('filterCartridges combines query and family', () => {
  assert.strictEqual(F.filterCartridges(DATA, '', 'all').length, 25);
  assert.strictEqual(F.filterCartridges(DATA, '', 'belted').length, 2);
  assert.strictEqual(F.filterCartridges(DATA, '', 'rimfire').length, 3);
  assert.deepStrictEqual(F.filterCartridges(DATA, '7,62 x 51', 'all').map((r) => r.name), ['308 Win.']);
  assert.strictEqual(F.filterCartridges(DATA, '7,62 x 51', 'pistol').length, 0);
});

test('search treats the multiplication sign like x', () => {
  assert.ok(F.matchesQuery(byKey('308_win'), '7,62×51'));
  assert.ok(F.matchesQuery(byKey('308_win'), '7,62 × 51'));
});
