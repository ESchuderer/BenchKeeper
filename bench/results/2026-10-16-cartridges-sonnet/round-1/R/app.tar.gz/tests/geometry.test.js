'use strict';
const test = require('node:test');
const assert = require('node:assert');
const G = require('../js/geometry.js');
const DATA = require('../js/data.js');
const rec = (k) => structuredClone(DATA.find((r) => r.key === k));
const near = (a, b, eps = 1e-3, msg) => assert.ok(Math.abs(a - b) <= eps, `${msg || ''} ${a} != ${b}`);
const has = (pts, z, r, eps = 1e-3) => pts.some((p) => Math.abs(p.z - z) <= eps && Math.abs(p.r - r) <= eps);
const TAN35 = Math.tan((35 * Math.PI) / 180);

test('rimType follows rule 1', () => {
  assert.strictEqual(G.rimType(rec('300_win_mag')), 'belted');
  assert.strictEqual(G.rimType(rec('22_long_rifle')), 'rimfire');
  assert.strictEqual(G.rimType(rec('9_3_x_74_r')), 'rimmed');
  assert.strictEqual(G.rimType(rec('223_rem')), 'rimless');
  const r = rec('223_rem');
  const p1 = r.cartridge.powderChamber.P1;
  r.cartridge.caseHead.R1 = p1 * 0.97;
  assert.strictEqual(G.rimType(r), 'rebated');
  r.cartridge.caseHead.R1 = p1 * 0.98;
  assert.strictEqual(G.rimType(r), 'rimless');
  r.cartridge.caseHead.R1 = p1 * 1.05;
  assert.strictEqual(G.rimType(r), 'rimmed');
});

test('outer profile of 308 Win.: chamfer, groove, ramp, mouth (rules 2, 3, 6)', () => {
  const g = G.build(rec('308_win'));
  const o = g.outer;
  assert.deepStrictEqual(o[0], { z: 0, r: 0 });
  const c = Math.min(0.38 * TAN35, 12.01 / 4);
  assert.ok(has(o, 0, 12.01 / 2 - c), 'chamfer start on the head face');
  assert.ok(has(o, 0.38, 12.01 / 2), 'chamfer end (R1/2, f)');
  assert.ok(has(o, 1.37, 12.01 / 2), 'rim back (R1/2, R)');
  assert.ok(has(o, 1.37, 10.39 / 2), 'groove in to E1/2 at z = R');
  assert.ok(has(o, 1.37 + 1.4, 10.39 / 2), 'floor to R + e min');
  assert.ok(has(o, 3.85, 11.96 / 2), 'ramp out to (P1/2, E)');
  const last = o[o.length - 1];
  near(last.z, 51.18); near(last.r, 8.72 / 2);
  for (let i = 1; i < o.length; i++) assert.ok(o[i].z >= o[i - 1].z - 1e-9, 'z never decreases');
});

test('shoulder: published points reached within the fillet radii, line at alpha/2 (rule 5)', () => {
  const g = G.build(rec('308_win'));
  assert.deepStrictEqual(g.marks.shoulderStart, { z: 39.62, r: 11.53 / 2 });
  assert.deepStrictEqual(g.marks.shoulderEnd, { z: 43.48, r: 8.72 / 2 });
  // rounded corners: no vertex lies exactly on the sharp corners, but all are within 1 mm of them
  const near1 = (p, q) => Math.hypot(p.z - q.z, p.r - q.r);
  const o = g.outer;
  assert.ok(o.some((p) => near1(p, g.marks.shoulderStart) < 1));
  assert.ok(o.some((p) => near1(p, g.marks.shoulderEnd) < 1));
  assert.ok(!o.some((p) => near1(p, g.marks.shoulderStart) < 1e-6), 'body-side corner is rounded');
  // slope of the straight part of the shoulder
  let seg = null;
  for (let i = 1; i < o.length; i++) if (o[i - 1].z > 39 && o[i].z < 44 && o[i].z - o[i - 1].z > 1.5) seg = [o[i - 1], o[i]];
  assert.ok(seg, 'straight shoulder segment between the two fillets');
  const slope = (seg[0].r - seg[1].r) / (seg[1].z - seg[0].z);
  near(Math.atan(slope) * 180 / Math.PI, 20, 0.1);
});

test('rimfire rim edge is a half-round whose outermost point lies at R1/2 (rule 2)', () => {
  const g = G.build(rec('22_long_rifle'));
  const rho = Math.min(1.09 / 2, (7.06 - 5.74) / 2);
  const rim = g.outer.filter((p) => p.z <= 1.09 + 1e-9);
  near(Math.max(...rim.map((p) => p.r)), 7.06 / 2);
  const tip = rim.find((p) => Math.abs(p.r - 7.06 / 2) < 1e-6);
  near(tip.z, 1.09 / 2);
  assert.ok(has(g.outer, 0, 7.06 / 2 - rho), 'face reaches the arc start');
  assert.ok(has(g.outer, 1.09, 7.06 / 2 - rho), 'arc ends at z = R');
  assert.ok(has(g.outer, 1.09, 5.74 / 2), 'step in to P1/2 at z = R (no groove)');
});

test('belted: ramp at delta to the belt, belt to z = E, step in (rule 3)', () => {
  const g = G.build(rec('300_win_mag'));
  const rampEnd = 1.27 + 0.94 + (13.51 / 2 - 12.07 / 2) / TAN35;
  near(g.marks.rampEndZ, rampEnd);
  assert.ok(has(g.outer, rampEnd, 13.51 / 2));
  assert.ok(has(g.outer, 5.59, 13.51 / 2));
  assert.ok(has(g.outer, 5.59, 13.03 / 2));
  near(g.w, Math.max(2.5, 0.25 * 13.03 / 2, 3.3 + 1.5, rampEnd + g.tb));
});

test('straight case (no alpha, L1, L2): body runs to (H2/2, L3) and the note names the missing values', () => {
  const g = G.build(rec('9_mm_luger'));
  assert.ok(has(g.outer, 2.98, 9.93 / 2), 'body starts where the groove ramp ends (E, P1/2)');
  const last = g.outer[g.outer.length - 1];
  near(last.z, 19.15); near(last.r, 9.65 / 2);
  assert.strictEqual(g.features.shoulder, false);
  const n = g.notes.find((x) => x.feature === 'shoulder');
  assert.deepStrictEqual(n.missing, ['α', 'L1', 'L2']);
  assert.match(n.text, /α, L1, L2/);
});

test('missing value drops only its feature and is reported', () => {
  const a = rec('308_win'); delete a.cartridge.caseHead.E1;
  const ga = G.build(a);
  assert.strictEqual(ga.features.groove, false);
  assert.ok(has(ga.outer, 1.37, 11.96 / 2), 'plain step-in without a groove');
  assert.deepStrictEqual(ga.notes.find((x) => x.feature === 'groove').missing, ['E1']);
  const b = rec('308_win'); delete b.cartridge.caseHead.eMin;
  assert.deepStrictEqual(G.build(b).notes.find((x) => x.feature === 'groove').missing, ['e min']);
  const c = rec('308_win'); delete c.cartridge.caseHead.beta;
  const gc = G.build(c);
  assert.deepStrictEqual(gc.notes.find((x) => x.feature === 'chamfer').missing, ['β']);
  assert.ok(has(gc.outer, 0, 12.01 / 2), 'square corner');
  const d = rec('300_win_mag'); delete d.cartridge.caseHead.R3;
  const gd = G.build(d);
  assert.strictEqual(gd.features.belt, false);
  assert.deepStrictEqual(gd.notes.find((x) => x.feature === 'belt').missing, ['R3']);
  const e = rec('308_win'); delete e.cartridge.lengths.L3;
  const ge = G.build(e);
  assert.strictEqual(ge.ok, false);
  assert.deepStrictEqual(ge.missingRequired, ['L3']);
});

test('no number is invented: a record without alpha has no alpha in the output', () => {
  const g = G.build(rec('22_win_mag_r_f'));
  assert.strictEqual(g.alpha, null);
});

test('wall thicknesses (rule 8)', () => {
  const g = G.build(rec('308_win'));
  near(g.tn, (8.72 - 7.85) / 2);
  near(g.tb, 0.6);
  assert.deepStrictEqual(G.wallThicknesses({ H2: 8, G1: 6, P1: 20 }), { tn: 1, tb: 1.3, heeled: false });
  assert.strictEqual(G.wallThicknesses({ H2: 8, G1: 6, P1: 2 }).tb, 0.35);
  const heeled = G.wallThicknesses({ H2: 5.72, G1: 5.72, P1: 5.74 });
  assert.strictEqual(heeled.heeled, true);
});

test('solid head length w and primer pocket (rule 8)', () => {
  const g = G.build(rec('223_rem'));
  assert.deepStrictEqual(g.pocket, { d: 4.45, depth: 3.04 });
  near(g.w, Math.max(2.5, 0.25 * 9.58 / 2, 3.04 + 1.5, 3.13 + g.tb));
  assert.deepStrictEqual(G.build(rec('308_win')).pocket, { d: 5.33, depth: 3.3 });
  assert.deepStrictEqual(G.build(rec('45_auto')).pocket, { d: 5.33, depth: 3.04 });
  assert.deepStrictEqual(G.build(rec('9_mm_luger')).pocket, { d: 4.45, depth: 3.04 });
  assert.deepStrictEqual(G.build(rec('357_magnum')).pocket, { d: 4.45, depth: 3.04 });
  assert.strictEqual(G.build(rec('22_long_rifle')).pocket, null);
  assert.strictEqual(G.build(rec('22_long_rifle')).w, 2.5);
});

test('bullet: pointy tangent ogive on 308 Win. (rule 7)', () => {
  const b = G.build(rec('308_win')).bullet;
  const G1 = 7.85;
  near(b.s, G1); near(b.zb, 51.18 - G1);
  near(b.zc, b.zb + 0.4 * (71.12 - b.zb));
  near(b.m, 1.27);
  const a = G1 / 2 - b.m / 2, n = 71.12 - b.zc;
  near(b.rho, (a * a + n * n) / (2 * a), 1e-9);
  const tip = b.profile[b.profile.length - 2];
  near(tip.z, 71.12); near(tip.r, b.m / 2, 1e-6);
  assert.deepStrictEqual(b.profile[b.profile.length - 1], { z: 71.12, r: 0 });
  assert.deepStrictEqual(b.profile[0], { z: b.zb, r: 0 });
});

test('bullet shapes: seating depth, cylinder fraction, meplat per shape and class', () => {
  const rounded = G.build(rec('9_mm_luger')).bullet; // pistol
  near(rounded.s, 0.4 * 9.03); near(rounded.m, 0.15 * 9.03);
  near(rounded.zc, rounded.zb + 0.65 * (29.69 - rounded.zb));
  const rifleRounded = G.build(rec('22_long_rifle')).bullet; // rimfire
  near(rifleRounded.s, 0.8 * 5.72);
  near(rifleRounded.zc, rifleRounded.zb + 0.55 * (25.4 - rifleRounded.zb));
  const flat = G.build(rec('40_s_w')).bullet; // pistol flat
  near(flat.s, 0.4 * 10.17); near(flat.m, 0.55 * 10.17);
  near(flat.zc, flat.zb + 0.7 * (28.83 - flat.zb));
  const sw = G.build(rec('357_magnum')).bullet;
  near(sw.s, 0.6 * 9.12); near(sw.m, 0.6 * 9.12);
  near(sw.zc, sw.zb + 0.78 * (40.39 - sw.zb));
  const f2 = rec('308_win'); f2.annotations.defaultBulletShape = 'flat'; f2.annotations.category = 'rifle';
  const fr = G.build(f2).bullet;
  near(fr.s, 0.8 * 7.85); near(fr.zc, fr.zb + 0.6 * (71.12 - fr.zb));
  const hmr = G.build(rec('17_hmr')).bullet;
  near(hmr.m, Math.max(0.08 * 4.38, 1.27)); near(hmr.s, 4.38);
});

test('heeled case (22 Long Rifle): exposed bullet has the case outside diameter, seated heel the inside diameter', () => {
  const g = G.build(rec('22_long_rifle'));
  const b = g.bullet;
  assert.strictEqual(b.heeled, true);
  near(b.rExp, 5.72 / 2);
  near(b.rSeat, 5.72 / 2 - g.tb);
  const exposed = b.exposed;
  assert.ok(exposed.every((p) => p.r <= 5.72 / 2 + 1e-9));
  near(exposed[0].z, 15.57);
  assert.ok(has(b.profile, 15.57, 5.72 / 2 - g.tb));
});

test('exposed bullet starts at the mouth and ends at the tip', () => {
  const b = G.build(rec('308_win')).bullet;
  near(b.exposed[0].z, 51.18);
  near(b.exposed[0].r, 7.85 / 2);
  near(b.exposed[b.exposed.length - 1].z, 71.12);
});

test('every record builds; inner wall stays inside the outer wall; seated bullet fits the cavity', () => {
  for (const r of DATA) {
    const g = G.build(r);
    assert.ok(g.ok, r.key);
    for (const p of g.outer.concat(g.inner, g.bullet.profile)) {
      assert.ok(Number.isFinite(p.z) && Number.isFinite(p.r), `${r.key} NaN`);
    }
    const L3 = r.cartridge.lengths.L3;
    for (const p of g.inner) {
      assert.ok(p.z >= g.w - 1e-9 && p.z <= L3 + 1e-9, `${r.key} inner z range ${p.z}`);
      assert.ok(p.r < G.outerRadiusAt(g.outer, p.z) - 0.2, `${r.key} wall at z=${p.z}`);
    }
    for (const p of g.bullet.profile) {
      if (p.z < L3 - 1e-9 && p.z > g.w) {
        assert.ok(p.r <= G.innerRadiusAt(g, p.z) + 1e-6, `${r.key} bullet r=${p.r} at z=${p.z} exceeds cavity ${G.innerRadiusAt(g, p.z)}`);
      }
    }
    assert.ok(g.bullet.zb > g.w, `${r.key} bullet base ahead of the head`);
  }
});

test('rule 9: unknown primer type and missing category are reported, not guessed', () => {
  const a = rec('308_win'); delete a.annotations.primerType;
  const ga = G.build(a);
  assert.strictEqual(ga.pocket, null);
  assert.deepStrictEqual(ga.notes.find((n) => n.feature === 'pocket').missing, ['primer type']);
  const b = rec('9_mm_luger'); delete b.annotations.category;
  const gb = G.build(b);
  assert.deepStrictEqual(gb.notes.find((n) => n.feature === 'bullet-class').missing, ['category']);
  assert.ok(!G.build(rec('22_long_rifle')).notes.some((n) => n.feature === 'pocket'), 'rimfire has no pocket and no note');
});

test('meplat follows G1 as written in rule 7 even on a heeled case', () => {
  const r = rec('22_long_rifle'); r.cartridge.collar.H2 = 5.725; // still heeled (<= 0.015)
  const b = G.build(r).bullet;
  near(b.m, 0.15 * 5.72, 1e-9);
  near(b.rExp, 5.725 / 2, 1e-9);
});
