# C.I.P. cartridge reference

A static reference database of 25 C.I.P. cartridges for reloaders, gunsmiths and engineers, modelled on the cartridge database of [OpenBallistics](https://openreloading.github.io/OpenBallistics/). Each cartridge has a detail view with all published cartridge and chamber values and a true-scale 2D drawing (outside view above the axis, section below, dimensions in mm).

Data: the 25 records from [OpenBallistics](https://github.com/PiMetry/OpenBallistics) (MIT, commit e83db43), used as given in `data.js`.

## Run

Open `index.html` directly in Chromium (`file://`), or serve the folder with any static file server. There is no build step, no runtime dependency and no network request.

Addresses: `#/` is the list, `#/cartridge/<key>` (for example `#/cartridge/223_rem`) is a detail view. They survive a reload and can be bookmarked.

## Files

| File | Purpose |
| --- | --- |
| `index.html`, `style.css`, `app.js` | page, screen/print styles, list + detail views, hash router |
| `data.js` | the records as a script (JSON cannot be fetched on `file://`) |
| `format.js` | angles, tolerances, symbols, units, table model |
| `catalog.js` | search (name and alternative names) and family filter |
| `geometry.js` | cartridge profile, bullet, walls, section (pure, no DOM) |
| `drawing.js` | dimension layout without overlaps, SVG output |

## Tests

```
npm install        # dev dependency only: playwright-core
npm test           # unit tests (node:test) for format, catalog, geometry, drawing
npx playwright-core install chromium
npm run test:e2e   # headless Chromium on file://index.html, incl. print to PDF (one A4 page)
```

See `docs/testing.md`.

## Drawing notes

- Features whose value is missing from a record are left out and listed under the drawing ("Not drawn, value missing in the record").
- Rimmed cases have no extractor groove by definition, so a missing `E`/`E1` is not reported for them.
- Straight cases: the wall blends linearly from `tb` to `tn` between the head and the bullet base, so that the seated shank fits the bore.
- The shoulder angle alpha is shown as a leader with arrowhead on the shoulder and a labelled value.
- Print: A4 portrait, black on white. The scale in the title block is the scale on that print.
