/* Views and hash router. Addresses: #/ (list) and #/cartridge/<key> (detail). */
(function () {
  'use strict';
  var CIP = window.CIP, DATA = window.CIP_DATA;
  var F = CIP.format, C = CIP.catalog, D = CIP.drawing;
  var FAMILIES = ['rimless', 'rimmed', 'belted', 'pistol', 'rimfire'];
  var state = { query: '', family: 'all' };
  var app = document.getElementById('app');

  function h(tag, props) {
    var node = document.createElement(tag);
    Object.keys(props || {}).forEach(function (k) {
      var v = props[k];
      if (v === null || v === undefined || v === false) return;
      if (k === 'class') node.className = v;
      else if (k === 'text') node.textContent = v;
      else if (k.slice(0, 2) === 'on') node.addEventListener(k.slice(2), v);
      else node.setAttribute(k, v === true ? '' : v);
    });
    (function add(list) {
      for (var i = 0; i < list.length; i++) {
        var ch = list[i];
        if (ch === null || ch === undefined || ch === false) continue;
        if (Array.isArray(ch)) add(ch);
        else node.appendChild(typeof ch === 'string' ? document.createTextNode(ch) : ch);
      }
    })(Array.prototype.slice.call(arguments, 2));
    return node;
  }

  function href(key) { return '#/cartridge/' + encodeURIComponent(key); }

  /* ---------- list ---------- */
  function renderList() {
    document.title = 'C.I.P. cartridges';
    var count = h('p', { id: 'count', class: 'count', role: 'status' });
    var tbody = h('tbody');
    var empty = h('p', { class: 'empty', hidden: true, text: 'No cartridge matches.' });

    function update() {
      var list = C.filter(DATA, state);
      count.textContent = C.countLabel(list.length);
      tbody.textContent = '';
      list.forEach(function (r) {
        tbody.appendChild(h('tr', {},
          h('th', { scope: 'row', class: 'name' }, h('a', { href: href(r.key), text: r.name })),
          h('td', { text: r.family }),
          h('td', { class: 'num', text: String(r.cartridge.lengths.L3) + ' mm' })));
      });
      empty.hidden = list.length > 0;
    }

    var search = h('input', { id: 'search', type: 'search', autocomplete: 'off', spellcheck: 'false', value: state.query,
      oninput: function (e) { state.query = e.target.value; update(); } });
    var family = h('select', { id: 'family', onchange: function (e) { state.family = e.target.value; update(); } },
      h('option', { value: 'all', text: 'All' }));
    FAMILIES.forEach(function (f) { family.appendChild(h('option', { value: f, text: f })); });
    family.value = state.family;

    app.textContent = '';
    app.appendChild(h('h1', { text: 'Cartridges' }));
    app.appendChild(h('form', { class: 'filters', role: 'search', onsubmit: function (e) { e.preventDefault(); } },
      h('div', { class: 'field' }, h('label', { for: 'search', text: 'Search' }), search),
      h('div', { class: 'field' }, h('label', { for: 'family', text: 'Family' }), family),
      count));
    app.appendChild(h('table', { class: 'list' },
      h('caption', { class: 'sr-only', text: 'C.I.P. cartridges' }),
      h('thead', {}, h('tr', {},
        h('th', { scope: 'col', text: 'Name' }), h('th', { scope: 'col', text: 'Family' }),
        h('th', { scope: 'col', class: 'num', text: 'Case length L3' }))),
      tbody));
    app.appendChild(empty);
    update();
  }

  /* ---------- detail ---------- */
  function fact(term, value) {
    return h('div', { class: 'fact' }, h('dt', { text: term }), h('dd', {}, value));
  }

  function capacity(rec) {
    var cap = rec.annotations && rec.annotations.publishedCapacity;
    if (!cap) return 'not published';
    var bits = [String(cap.grH2O) + ' gr H\u2082O'];
    var out = h('span', {}, bits[0] + ' ');
    if (cap.url) out.appendChild(h('a', { href: cap.url, rel: 'noopener noreferrer', text: '(source: ' + cap.source + ')' }));
    else if (cap.source) out.appendChild(document.createTextNode('(source: ' + cap.source + ')'));
    if (cap.note) out.appendChild(h('span', { class: 'note', text: ' ' + cap.note }));
    return out;
  }

  function tables(rec, group, title) {
    var wrap = h('section', { class: 'values ' + group, 'aria-labelledby': 'h-' + group }, h('h2', { id: 'h-' + group, text: title }));
    var grid = h('div', { class: 'table-grid' });
    F.sectionTables(rec, group).forEach(function (sec) {
      var tb = h('tbody');
      sec.rows.forEach(function (row) {
        tb.appendChild(h('tr', {},
          h('th', { scope: 'row', text: row.symbol }),
          h('td', { class: 'num', text: row.value }),
          h('td', { class: 'unit', text: row.unit })));
      });
      grid.appendChild(h('table', { class: 'values-table' },
        h('caption', { text: sec.title }),
        h('thead', {}, h('tr', {}, h('th', { scope: 'col', text: 'Symbol' }), h('th', { scope: 'col', class: 'num', text: 'Value' }), h('th', { scope: 'col', text: 'Unit' }))),
        tb));
    });
    wrap.appendChild(grid);
    return wrap;
  }

  function renderDetail(rec) {
    document.title = rec.name + ' \u2013 C.I.P. cartridges';
    var a = rec.annotations || {};
    var drawing = D.buildDrawing(rec);
    var figure = h('figure', { class: 'drawing-figure' });
    figure.innerHTML = drawing.svg;
    var notes = drawing.notes.length
      ? h('div', { class: 'notes' }, h('p', { text: 'Not drawn, value missing in the record:' }),
        h('ul', {}, drawing.notes.map(function (n) { return h('li', { text: n }); })))
      : null;

    app.textContent = '';
    app.appendChild(h('div', { class: 'toolbar no-print' },
      h('a', { class: 'back', href: '#/', text: 'All cartridges' }),
      h('button', { type: 'button', class: 'print', onclick: function () { window.print(); }, text: 'Print' })));
    app.appendChild(h('h1', { id: 'title', tabindex: '-1', text: rec.name }));
    var facts = h('dl', { class: 'facts' });
    if (rec.alternativeNames && rec.alternativeNames.length) facts.appendChild(fact('Alternative names', rec.alternativeNames.join(', ')));
    facts.appendChild(fact('Family', rec.family));
    facts.appendChild(fact('Category', a.category || ''));
    facts.appendChild(fact('Primer type', a.primerType || ''));
    facts.appendChild(fact('C.I.P. table', rec.tab));
    facts.appendChild(fact('Country', rec.country));
    facts.appendChild(fact('Published', rec.published));
    facts.appendChild(fact('Revised', rec.revised));
    facts.appendChild(fact('Pressure method', rec.pressureMethod));
    facts.appendChild(fact('Water capacity', capacity(rec)));
    app.appendChild(facts);
    var sec = h('section', { class: 'drawing-section', 'aria-labelledby': 'h-drawing' },
      h('h2', { id: 'h-drawing', text: 'Drawing' }), figure, notes);
    app.appendChild(sec);
    app.appendChild(h('div', { class: 'all-values' },
      tables(rec, 'cartridge', 'Cartridge values'), tables(rec, 'chamber', 'Chamber values')));
    app.appendChild(h('footer', { class: 'source' }, 'Source: C.I.P. TDCC, revised ' + rec.revised));
  }

  function renderNotFound(key) {
    document.title = 'Not found \u2013 C.I.P. cartridges';
    app.textContent = '';
    app.appendChild(h('h1', { text: 'Cartridge not found' }));
    app.appendChild(h('p', { text: 'There is no cartridge "' + key + '".' }));
    app.appendChild(h('p', {}, h('a', { href: '#/', text: 'All cartridges' })));
  }

  /* ---------- router ---------- */
  var first = true;
  function route() {
    var m = /^#\/cartridge\/([^/?#]+)/.exec(window.location.hash);
    if (m) {
      var key = decodeURIComponent(m[1]);
      var rec = C.findByKey(DATA, key);
      if (rec) renderDetail(rec); else renderNotFound(key);
    } else {
      renderList();
    }
    if (!first) { window.scrollTo(0, 0); app.focus({ preventScroll: true }); }
    first = false;
  }
  window.addEventListener('hashchange', route);
  route();
})();
