/* Search and filter of the cartridge list. */
(function (root) {
  'use strict';

  function normalise(s) {
    return String(s).toLowerCase().replace(/,/g, '.').replace(/\s+/g, '');
  }

  function matches(record, q) {
    if (!q) return true;
    var names = [record.name].concat(record.alternativeNames || []);
    return names.some(function (n) { return normalise(n).indexOf(q) >= 0; });
  }

  /** opts: { query: string, family: 'all' | family } */
  function filter(records, opts) {
    opts = opts || {};
    var q = normalise(opts.query || '');
    var fam = opts.family && opts.family !== 'all' ? opts.family : null;
    return records.filter(function (r) { return (!fam || r.family === fam) && matches(r, q); });
  }

  function countLabel(n) { return n + ' cartridges'; }

  function findByKey(records, key) {
    for (var i = 0; i < records.length; i++) if (records[i].key === key) return records[i];
    return undefined;
  }

  var api = { filter: filter, countLabel: countLabel, findByKey: findByKey, normalise: normalise };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  else { root.CIP = root.CIP || {}; root.CIP.catalog = api; }
})(typeof window !== 'undefined' ? window : globalThis);
