# C.I.P. cartridge reference - implementation plan

> For agentic workers: executed inline with TDD (RED -> GREEN -> REFACTOR).

**Goal:** static app per the brief. **Tech:** plain HTML/CSS/JS; dev-only `playwright-core`.

Tasks (each: failing test, minimal code, green):
1. `format.js` - angle, tolerance, symbol, unit, row model.
2. `catalog.js` - search incl. alternative names, family filter, count.
3. `geometry.js` - rim type, profile (head, groove, belt, body, shoulder fillets, neck), bullet shapes, heeled, walls/head/pocket, notes for missing values.
4. `drawing.js` - dimensions, collision-free labels, title block, SVG with accessible name.
5. `app.js`, `index.html`, `style.css` - list, detail, router, print.
6. E2E on `file://` with Chromium; print PDF check (one A4 page).
7. Docs (README, testing), review, verification.
