# C.I.P. cartridge reference - design

Approved by the user's instruction to proceed without a design-approval round; the brief itself is the requirements source.

## Architecture
Plain classic scripts (no ES modules: they are blocked on `file://`). Each file is a UMD-style IIFE that attaches to `window.CIP` and, under Node, to `module.exports`, so the pure logic is unit-testable.

| File | Responsibility |
| --- | --- |
| `data.js` | the 25 records as a script (fetch of JSON is blocked on `file://`) |
| `format.js` | angles, tolerances, symbols, units, value formatting, table model |
| `geometry.js` | rim type, outer profile, bullet, inner profile, section polygons, missing-value notes |
| `drawing.js` | dimension layout (lanes, collision-free labels) and the SVG string |
| `catalog.js` | search / family filter |
| `app.js` | hash router (`#/cartridge/<key>`), list and detail views, print |
| `style.css` | screen (light/dark) and print (A4 portrait, light) |

## Decisions
- Routing by `location.hash` (`#/cartridge/223_rem`): survives reload, bookmarkable, works on `file://` and any static server.
- Rule 9: every feature whose value is missing is omitted and listed in `drawing.notes`; shown under the drawing. Rimmed cases have no groove by design and get no note for it.
- Dimension layout: length dimensions (R, L1, L2, L3, L6) are horizontal lines in lanes above the outside view; diameter dimensions (R1, E1, P1, P2, H1, H2, G1) are vertical lines through the part at the feature position, continued below as extension lines to labels in packed lanes; alpha uses a leader from the shoulder. Labels are placed by a collision search against all lines and other labels.
- Fonts in drawing scale with drawing width so text stays legible when the SVG is shrunk to a phone or fitted to A4.
- Straight cases: wall blends from tb to tn up to the bullet base so the seated shank fits; heeled cases keep tb and a heel of radius H2/2 - tb.

## Testing
`node --test tests/unit` (format, geometry for all 25 records, drawing overlap check, catalog). `node tests/e2e/run.js` drives headless Chromium on `file://index.html` (list, search, filter, routing, reload, print media, no network requests).
