# Testing

- `npm test` runs `tests/unit/*.test.js` with the Node.js built-in runner (Node 22). The pure modules (`format.js`, `catalog.js`, `geometry.js`, `drawing.js`) are loaded with `require`; in the browser they attach to `window.CIP`.
- `npm run test:e2e` runs `tests/e2e/e2e.test.js` with `playwright-core` against `file://.../index.html`: list, search, family filter, detail views for all 25 records, reload, phone width, light/dark, no network requests, label overlap with real font metrics, and print to PDF (every detail view must be one A4 page).
- Chromium: `npx playwright-core install chromium`. In a container without system libraries, set `LD_LIBRARY_PATH` (and `FONTCONFIG_FILE`) to a directory with the Chromium runtime libraries and one font.
