/*
 * 2D drawing: builds an inline SVG (1 user unit = 1 mm) from a record.
 * Upper half = outside view, lower half = section. Dimension layout is computed
 * with a collision search so labels never overlap lines, outline or each other.
 */
(function (root) {
  'use strict';
  var G = typeof require === 'function' && typeof module !== 'undefined' ? require('./geometry.js') : root.CIP.geometry;
  var F = typeof require === 'function' && typeof module !== 'undefined' ? require('./format.js') : root.CIP.format;

  var PRINT_WIDTH_MM = 190; // A4 portrait, 10 mm margins
  var PRINT_MAX_HEIGHT_MM = 140; // keeps a printed detail view on one page
  function has(v) { return v !== undefined && v !== null; }
  function n(x) { return String(Math.round(x * 1000) / 1000); }
  function esc(s) {
    return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  }

  function segRect(s, r) {
    var t0 = 0, t1 = 1, dx = s.x2 - s.x1, dy = s.y2 - s.y1;
    var p = [-dx, dx, -dy, dy];
    var q = [s.x1 - r.x, r.x + r.w - s.x1, s.y1 - r.y, r.y + r.h - s.y1];
    for (var i = 0; i < 4; i++) {
      if (p[i] === 0) { if (q[i] < 0) return false; }
      else {
        var t = q[i] / p[i];
        if (p[i] < 0) { if (t > t1) return false; if (t > t0) t0 = t; }
        else { if (t < t0) return false; if (t < t1) t1 = t; }
      }
    }
    return true;
  }
  function rectRect(a, b) { return a.x < b.x + b.w && b.x < a.x + a.w && a.y < b.y + b.h && b.y < a.y + a.h; }
  function inflate(r, p) { return { x: r.x - p, y: r.y - p, w: r.w + 2 * p, h: r.h + 2 * p }; }

  function maxRAt(path, z) {
    var best = 0;
    for (var i = 1; i < path.length; i++) {
      var a = path[i - 1], b = path[i];
      if (z >= Math.min(a.z, b.z) - 1e-9 && z <= Math.max(a.z, b.z) + 1e-9) {
        var r = b.z - a.z < 1e-9 ? Math.max(a.r, b.r) : a.r + ((z - a.z) / (b.z - a.z)) * (b.r - a.r);
        if (r > best) best = r;
      }
    }
    return best;
  }

  function layout(rec, geo, fs) {
    var c = rec.cartridge, head = c.caseHead || {}, collar = c.collar || {}, cone = c.junctionCone || {};
    var len = c.lengths || {}, pc = c.powderChamber || {}, proj = c.projectile || {};
    var notes = geo.notes.slice();
    var segs = [], rects = [], dims = [];
    var gSec = [], gOut = [], gDim = [], gLab = [];
    var bullet = geo.bullet;
    var arrowLen = 0.8 * fs, arrowHalf = 0.28 * fs;
    var textH = fs, charW = 0.58 * fs, pad = 0.25 * fs;

    function seg(x1, y1, x2, y2, kind, dim) { segs.push({ x1: x1, y1: y1, x2: x2, y2: y2, kind: kind, dim: dim }); }
    function polySegs(pts, kind, closed) {
      for (var i = 1; i < pts.length; i++) seg(pts[i - 1].x, pts[i - 1].y, pts[i].x, pts[i].y, kind);
      if (closed) seg(pts[pts.length - 1].x, pts[pts.length - 1].y, pts[0].x, pts[0].y, kind);
    }
    function up(path) { return path.map(function (p) { return { x: p.z, y: -p.r }; }); }
    function down(path) { return path.map(function (p) { return { x: p.z, y: p.r }; }); }
    function pts(a) { return a.map(function (p) { return n(p.x) + ',' + n(p.y); }).join(' '); }

    // ---- outline: outside view (upper) and section (lower) ----
    var L3 = len.L3, H2 = collar.H2;
    var upper = up(geo.outer);
    gOut.push('<polyline class="outline" points="' + pts(upper) + '"/>');
    polySegs(upper, 'outline');
    if (bullet) {
      var ex = up(bullet.exposed);
      var sh = bullet.exposed[0].r;
      if (sh < H2 / 2 - 1e-6) {
        gOut.push('<line class="outline" x1="' + n(L3) + '" y1="' + n(-H2 / 2) + '" x2="' + n(L3) + '" y2="' + n(-sh) + '"/>');
        seg(L3, -H2 / 2, L3, -sh, 'outline');
      }
      gOut.push('<polyline class="outline" points="' + pts(ex) + '"/>');
      polySegs(ex, 'outline');
    }
    var sec = down(geo.section);
    gSec.push('<polygon class="cut" fill="url(#hatch)" points="' + pts(sec) + '"/>');
    polySegs(sec, 'outline', true);
    if (bullet) {
      var bl = down(bullet.full);
      gSec.push('<polygon class="bullet-cut" points="' + pts(bl) + '"/>');
      polySegs(bl, 'outline', true);
    }
    var xEnd = has(len.L6) ? len.L6 : L3;
    var centre = '<line class="centre" x1="' + n(-1.5 * fs) + '" y1="0" x2="' + n(xEnd + 1.5 * fs) + '" y2="0"/>';
    seg(-1.5 * fs, 0, xEnd + 1.5 * fs, 0, 'centre');

    var rTop = 0;
    geo.outer.forEach(function (p) { if (p.r > rTop) rTop = p.r; });
    if (bullet) bullet.exposed.forEach(function (p) { if (p.r > rTop) rTop = p.r; });

    // ---- drawing primitives ----
    function arrow(x, y, dx, dy) {
      var bx = x - dx * arrowLen, by = y - dy * arrowLen, px = -dy * arrowHalf, py = dx * arrowHalf;
      return '<polygon class="arrow" points="' + n(x) + ',' + n(y) + ' ' + n(bx + px) + ',' + n(by + py) + ' ' + n(bx - px) + ',' + n(by - py) + '"/>';
    }
    function line(cls, x1, y1, x2, y2, kind, dim) {
      gDim.push('<line class="' + cls + '" x1="' + n(x1) + '" y1="' + n(y1) + '" x2="' + n(x2) + '" y2="' + n(y2) + '"/>');
      seg(x1, y1, x2, y2, kind, dim);
    }
    function free(r, ignoreDim) {
      var big = inflate(r, pad);
      var small = inflate(r, 0.1 * fs);
      var i;
      for (i = 0; i < rects.length; i++) if (rectRect(big, rects[i])) return false;
      for (i = 0; i < segs.length; i++) {
        if (segs[i].kind === 'centre') continue;
        if (ignoreDim && segs[i].dim === ignoreDim && segs[i].kind === 'dim') continue;
        if (segRect(segs[i], segs[i].kind === "outline" ? big : small)) return false;
      }
      return true;
    }
    function addLabel(id, text, r) {
      var rect = { id: id, text: text, x: r.x, y: r.y, w: r.w, h: r.h };
      rects.push(rect);
      gLab.push('<text class="label" x="' + n(r.x) + '" y="' + n(r.y + 0.8 * fs) + '" textLength="' + n(r.w) +
        '" lengthAdjust="spacingAndGlyphs">' + esc(text) + '</text>');
      return rect;
    }
    function textW(t) { return t.length * charW; }

    // ---- length dimensions above the outside view (horizontal, in lanes) ----
    var zdims = [];
    function addZ(id, field, z, rAt) { if (has(z)) zdims.push({ id: id, field: field, z: z, rAt: rAt }); }
    addZ('R', 'R', head.R, maxRAt(geo.outer, head.R));
    addZ('L1', 'L1', len.L1, has(len.L1) ? maxRAt(geo.outer, len.L1) : 0);
    addZ('L2', 'L2', len.L2, has(len.L2) ? maxRAt(geo.outer, len.L2) : 0);
    addZ('L3', 'L3', len.L3, H2 / 2);
    addZ('L6', 'L6', len.L6, bullet ? bullet.m / 2 : 0);
    zdims.sort(function (a, b) { return a.z - b.z; });
    var pitchT = 1.9 * fs, laneT0 = rTop + 2 * fs;
    var gap = 0.4 * fs, over = 0.7 * fs;
    var topLaneY = -(laneT0 + Math.max(0, zdims.length - 1) * pitchT);
    var headR = head.R1 / 2;
    if (zdims.length) {
      line('ext', 0, -(maxRAt(geo.outer, 0) + gap), 0, topLaneY - over, 'ext', 'shared');
    }
    zdims.forEach(function (d, i) {
      d.y = -(laneT0 + i * pitchT);
      line('ext', d.z, -(d.rAt + gap), d.z, d.y - over, 'ext', d.id);
      var short = d.z < 3 * arrowLen;
      if (short) {
        line('dim', -2 * arrowLen, d.y, d.z + 2 * arrowLen, d.y, 'dim', d.id);
        gDim.push(arrow(0, d.y, 1, 0), arrow(d.z, d.y, -1, 0));
      } else {
        line('dim', 0, d.y, d.z, d.y, 'dim', d.id);
        gDim.push(arrow(0, d.y, -1, 0), arrow(d.z, d.y, 1, 0));
      }
      dims.push({ id: d.id, arrows: 2 });
    });
    zdims.forEach(function (d) {
      var text = F.symbol(d.field) + ' ' + String(has(len[d.field]) ? len[d.field] : head[d.field]);
      var w = textW(text), h = textH, y = d.y - 0.35 * fs - h;
      var cands = [], k, base = d.z < 3 * arrowLen ? d.z + 0.4 * fs : d.z / 2 - w / 2;
      for (k = 0; k < 160; k++) {
        var s = k % 2 ? 1 : -1, off = Math.ceil(k / 2) * 0.5 * fs;
        cands.push(base + (k ? s * off : 0));
      }
      if (d.z < 3 * arrowLen) cands = cands.filter(function (x) { return x >= d.z; }).concat(cands.filter(function (x) { return x < d.z; }));
      var placed = false;
      for (k = 0; k < cands.length && !placed; k++) {
        var r = { x: cands[k], y: y, w: w, h: h };
        if (free(r)) { addLabel(d.id, text, r); placed = true; }
      }
      if (!placed) addLabel(d.id, text, { x: base, y: y, w: w, h: h });
    });

    // ---- diameter dimensions and angle: vertical lines, labels in packed lanes below ----
    var items = [];
    var bodyZ = geo.bodyStartZ, f = geo.features;
    var rimZ = geo.rimType === 'rimfire' ? Math.min(head.R / 2, (head.R1 - pc.P1) / 2)
      : (has(head.beta) && has(head.f) && G.deg(head.beta) < 90 ? (head.f + head.R) / 2 : head.R / 2);
    if (has(head.R1)) items.push({ id: 'R1', field: 'R1', z: rimZ, r: head.R1 / 2, text: 'R1 ' + head.R1 });
    if (has(head.E1) && f.groove) items.push({ id: 'E1', field: 'E1', z: head.R + (has(head.eMin) ? head.eMin / 2 : 0), r: head.E1 / 2, text: 'E1 ' + head.E1 });
    if (has(pc.P1)) items.push({ id: 'P1', field: 'P1', z: bodyZ + 0.6, r: pc.P1 / 2, text: 'P1 ' + pc.P1 });
    if (has(pc.P2) && has(len.L1)) items.push({ id: 'P2', field: 'P2', z: Math.max(bodyZ + 1, len.L1 - 2), r: pc.P2 / 2, text: 'P2 ' + pc.P2 });
    if (geo.bottleneck && has(collar.H1)) {
      var nl = len.L3 - len.L2;
      items.push({ id: 'H1', field: 'H1', z: len.L2 + 0.3 * nl, r: collar.H1 / 2, text: 'H1 ' + collar.H1 });
    }
    if (has(H2)) {
      var zH2 = geo.bottleneck ? len.L3 - 0.2 * (len.L3 - len.L2) : len.L3 - 0.6;
      items.push({ id: 'H2', field: 'H2', z: zH2, r: H2 / 2, text: 'H2 ' + H2 });
    }
    if (has(proj.G1)) {
      if (bullet && bullet.cylEnd > L3 + 0.3) {
        items.push({ id: 'G1', field: 'G1', z: (L3 + Math.min(bullet.cylEnd, len.L6)) / 2, r: bullet.shankR, text: 'G1 ' + proj.G1 });
      } else notes.push('G1 not dimensioned: the shank is not visible outside the case');
    }
    if (geo.bottleneck && has(cone.alpha)) {
      var za = (len.L1 + len.L2) / 2;
      var ra = pc.P2 / 2 + ((collar.H1 / 2 - pc.P2 / 2) * (za - len.L1)) / (len.L2 - len.L1);
      items.push({ id: 'alpha', field: 'alpha', z: za, r: ra, text: 'α ' + F.formatAngle(cone.alpha), angle: true });
    }
    var pitchB = 1.7 * fs, laneB0 = rTop + 2 * fs;
    items.sort(function (a, b) { return b.z - a.z; });
    items.forEach(function (it) {
      it.w = textW(it.text);
      it.y0 = it.angle ? it.r + 1.6 * fs : it.r;
    });
    // Depth-first search with iterative deepening over (lane, side) for every item,
    // so that the fewest lanes are used and no label meets a line or another label.
    var s0 = segs.length, r0 = rects.length;
    function place(i, maxLane) {
      if (i === items.length) return true;
      var it = items[i];
      for (var d = 0; d < maxLane; d++) {
        var y = laneB0 + d * pitchB;
        for (var side = 0; side < 2; side++) {
          var x = side === 0 ? it.z + 0.5 * fs : it.z - 0.5 * fs - it.w;
          var r = { x: x, y: y - textH / 2, w: it.w, h: textH };
          var extSeg = { x1: it.z, y1: it.y0, x2: it.z, y2: y, kind: 'ext', dim: it.id };
          var ok = free(r);
          for (var k = 0; ok && k < rects.length; k++) if (segRect(extSeg, inflate(rects[k], 0.1 * fs))) ok = false;
          if (!ok) continue;
          it.lane = y; it.rect = r;
          rects.push({ x: r.x, y: r.y, w: r.w, h: r.h });
          segs.push(extSeg);
          if (place(i + 1, maxLane)) return true;
          rects.pop(); segs.pop();
        }
      }
      return false;
    }
    var solved = false;
    for (var maxLane = 1; maxLane <= 12 && !solved; maxLane++) solved = place(0, maxLane);
    if (!solved) {
      items.forEach(function (it, i) {
        it.lane = laneB0 + i * pitchB;
        it.rect = { x: it.z + 0.5 * fs, y: it.lane - textH / 2, w: it.w, h: textH };
      });
      notes.push('Dimension labels could not be fully separated');
    }
    segs.length = s0; rects.length = r0;
    items.forEach(function (it) {
      if (it.angle) {
        var tail = it.r + 1.6 * fs;
        line('dim', it.z, it.r, it.z, tail, 'dim', it.id);
        line('ext', it.z, tail, it.z, it.lane, 'ext', it.id);
        gDim.push(arrow(it.z, it.r, 0, -1));
        dims.push({ id: 'alpha', arrows: 1 });
      } else {
        line('dim', it.z, -it.r, it.z, it.r, 'dim', it.id);
        line('ext', it.z, it.r, it.z, it.lane, 'ext', it.id);
        gDim.push(arrow(it.z, -it.r, 0, -1), arrow(it.z, it.r, 0, 1));
        dims.push({ id: it.id, arrows: 2 });
      }
      addLabel(it.id, it.text, it.rect);
    });

    // ---- extents ----
    var minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity;
    function ext(x, y) { if (x < minX) minX = x; if (x > maxX) maxX = x; if (y < minY) minY = y; if (y > maxY) maxY = y; }
    segs.forEach(function (s) { ext(s.x1, s.y1); ext(s.x2, s.y2); });
    rects.forEach(function (r) { ext(r.x, r.y); ext(r.x + r.w, r.y + r.h); });
    var m = 1.5 * fs;
    var bandX = minX - m, bandW = maxX - minX + 2 * m;

    // ---- title block ----
    var colW = Math.max(bandW / 2, 11 * fs);
    var totalW = Math.max(bandW, 2 * colW);
    var tbFs = 0.9 * fs, rowH = 1.7 * fs;
    var tbTop = maxY + 1.5 * fs;
    var tbX = bandX, tbH = 3 * rowH;
    var vbH = tbTop + tbH + m - (minY - m);
    var printScale = Math.min(PRINT_WIDTH_MM / totalW, PRINT_MAX_HEIGHT_MM / vbH);
    var scaleText = 'Scale ' + (Math.round(printScale * 10) / 10).toFixed(1) + ' : 1 (A4 print)';
    var rows = [
      [rec.name, 'C.I.P. table ' + rec.tab],
      ['Revised ' + rec.revised, 'Dimensions in mm'],
      [scaleText, '']
    ];
    var tb = ['<g class="title-block">',
      '<rect class="tb-frame" x="' + n(tbX) + '" y="' + n(tbTop) + '" width="' + n(totalW) + '" height="' + n(tbH) + '"/>'];
    for (var ri = 1; ri < 3; ri++) tb.push('<line class="tb-line" x1="' + n(tbX) + '" y1="' + n(tbTop + ri * rowH) + '" x2="' + n(tbX + totalW) + '" y2="' + n(tbTop + ri * rowH) + '"/>');
    tb.push('<line class="tb-line" x1="' + n(tbX + colW) + '" y1="' + n(tbTop) + '" x2="' + n(tbX + colW) + '" y2="' + n(tbTop + 2 * rowH) + '"/>');
    rows.forEach(function (row, ri2) {
      row.forEach(function (t, ci) {
        if (!t) return;
        var cls = ri2 === 0 && ci === 0 ? 'tb-name' : 'tb-text';
        var size = cls === 'tb-name' ? 1.25 * fs : tbFs;
        tb.push('<text class="' + cls + '" x="' + n(tbX + ci * colW + 0.6 * fs) + '" y="' + n(tbTop + ri2 * rowH + rowH / 2 + size * 0.35) + '" font-size="' + n(size) + '">' + esc(t) + '</text>');
      });
    });
    tb.push('</g>');

    var vb = { x: bandX, y: minY - m, w: totalW, h: vbH };
    return {
      notes: notes, segs: segs, rects: rects, dims: dims, vb: vb, fs: fs, printScale: printScale,
      parts: { sec: gSec, out: gOut, centre: centre, dim: gDim, lab: gLab, tb: tb }
    };
  }

  function render(rec, L) {
    var vb = L.vb, id = 'hatch-' + rec.key;
    var name = esc(rec.name + ' drawing');
    var hs = 0.6;
    var out = [];
    out.push('<svg xmlns="http://www.w3.org/2000/svg" class="drawing" role="img" aria-label="' + name + '" viewBox="' +
      n(vb.x) + ' ' + n(vb.y) + ' ' + n(vb.w) + ' ' + n(vb.h) + '" preserveAspectRatio="xMidYMin meet">');
    out.push('<title>' + name + '</title>');
    out.push('<defs><pattern id="' + id + '" patternUnits="userSpaceOnUse" width="' + hs + '" height="' + hs +
      '" patternTransform="rotate(45)"><line class="hatch" x1="0" y1="0" x2="0" y2="' + hs + '"/></pattern></defs>');
    out.push('<g class="section">' + L.parts.sec.join('').replace(/url\(#hatch\)/g, 'url(#' + id + ')') + '</g>');
    out.push('<g class="outside">' + L.parts.out.join('') + '</g>');
    out.push(L.parts.centre);
    out.push('<g class="dims">' + L.parts.dim.join('') + '</g>');
    out.push('<g class="labels" font-size="' + n(L.fs) + '">' + L.parts.lab.join('') + '</g>');
    out.push(L.parts.tb.join(''));
    out.push('</svg>');
    return out.join('');
  }

  function buildDrawing(rec) {
    var geo = G.buildGeometry(rec);
    if (!geo.outer.length) {
      return { svg: '', labels: [], segments: [], dimensions: [], notes: geo.notes, width: 0, height: 0, viewBox: { x: 0, y: 0, w: 0, h: 0 }, fontSize: 0, printScale: 0 };
    }
    var fs = 1.8, L = layout(rec, geo, fs);
    for (var pass = 0; pass < 3; pass++) {
      var want = Math.min(3.6, Math.max(1.8, L.vb.w / 42));
      if (Math.abs(want - fs) < 0.05) break;
      fs = want;
      L = layout(rec, geo, fs);
    }
    return {
      svg: render(rec, L), labels: L.rects, segments: L.segs, dimensions: L.dims, notes: L.notes,
      width: L.vb.w, height: L.vb.h, viewBox: L.vb, fontSize: L.fs, printScale: L.printScale
    };
  }

  var api = { buildDrawing: buildDrawing };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  else { root.CIP = root.CIP || {}; root.CIP.drawing = api; }
})(typeof window !== 'undefined' ? window : globalThis);
