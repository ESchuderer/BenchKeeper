/* Formatting helpers: angles, tolerances, symbols, units and the table model. */
(function (root) {
  'use strict';

  var ANGLE_FIELDS = { alpha: 1, alpha1: 1, beta: 1, delta: 1, i: 1 };
  var SYMBOLS = {
    eMin: 'e min', r1Min: 'r1 min', r1Max: 'r1 max', alpha: 'α', alpha1: 'α1',
    beta: 'β', delta: 'δ', deltaL: 'delta L', L3PlusG: 'L3 + G'
  };
  var UNITS = { Pmax: 'bar', PK: 'bar', PE: 'bar', EE: 'J', M: 'g', Q: 'mm²', N: '' };
  var SECTION_TITLES = {
    caseHead: 'Case head', collar: 'Collar', junctionCone: 'Junction cone', lengths: 'Lengths',
    misc: 'Miscellaneous', powderChamber: 'Powder chamber', pressures: 'Pressures', projectile: 'Projectile',
    barrel: 'Barrel', breech: 'Breech', grooves: 'Grooves', rifling: 'Rifling'
  };
  var SECTION_ORDER = {
    cartridge: ['caseHead', 'powderChamber', 'junctionCone', 'collar', 'lengths', 'projectile', 'pressures', 'misc'],
    chamber: ['breech', 'powderChamber', 'junctionCone', 'collar', 'lengths', 'barrel', 'grooves', 'rifling']
  };

  function isAngleField(field) { return Object.prototype.hasOwnProperty.call(ANGLE_FIELDS, field); }
  function symbol(field) { return Object.prototype.hasOwnProperty.call(SYMBOLS, field) ? SYMBOLS[field] : field; }
  function unit(field) {
    if (isAngleField(field)) return '°';
    return Object.prototype.hasOwnProperty.call(UNITS, field) ? UNITS[field] : 'mm';
  }

  function formatAngle(a) {
    if (a !== null && typeof a === 'object') {
      return a.degrees + '°' + a.minutes + "'" + a.seconds + '"';
    }
    return String(a) + '°';
  }

  function formatTolerance(t) { return (t > 0 ? '+' : '') + String(t); }

  /** Value as published, with the tolerance next to it. */
  function formatValue(field, value, tol) {
    var s = isAngleField(field) ? formatAngle(value) : String(value);
    return tol === undefined || tol === null ? s : s + ' ' + formatTolerance(tol);
  }

  function isToleranceKey(key, section) {
    return /Tol$/.test(key) && Object.prototype.hasOwnProperty.call(section, key.slice(0, -3));
  }

  /** Sections of a record group ('cartridge' | 'chamber') as table models. */
  function sectionTables(record, group) {
    var data = record[group] || {};
    var order = SECTION_ORDER[group].filter(function (k) { return data[k]; });
    Object.keys(data).forEach(function (k) { if (order.indexOf(k) < 0) order.push(k); });
    var out = [];
    order.forEach(function (name) {
      var sec = data[name];
      var rows = [];
      Object.keys(sec).forEach(function (field) {
        if (isToleranceKey(field, sec)) return;
        rows.push({
          field: field,
          symbol: symbol(field),
          value: formatValue(field, sec[field], sec[field + 'Tol']),
          unit: unit(field)
        });
      });
      if (rows.length) out.push({ key: name, title: SECTION_TITLES[name] || name, rows: rows });
    });
    return out;
  }

  var api = {
    formatAngle: formatAngle, formatValue: formatValue, formatTolerance: formatTolerance,
    symbol: symbol, unit: unit, isAngleField: isAngleField, sectionTables: sectionTables
  };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  else { root.CIP = root.CIP || {}; root.CIP.format = api; }
})(typeof window !== 'undefined' ? window : globalThis);
