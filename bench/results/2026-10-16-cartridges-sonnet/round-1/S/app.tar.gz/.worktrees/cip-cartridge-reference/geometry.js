/*
 * Cartridge geometry (pure, no DOM). Coordinates are {z, r}:
 * z along the axis from the head face (0) to the mouth, r the radius.
 * All outputs are for the upper half (r >= 0); the drawing mirrors them.
 */
(function (root) {
  'use strict';

  var DEG = Math.PI / 180;

  function has(v) { return v !== undefined && v !== null; }
  function deg(a) {
    if (a !== null && typeof a === 'object') return a.degrees + a.minutes / 60 + a.seconds / 3600;
    return a;
  }
  function dist(a, b) { return Math.hypot(a.z - b.z, a.r - b.r); }

  function rimType(rec) {
    if (rec.family === 'belted') return 'belted';
    if (rec.family === 'rimfire') return 'rimfire';
    var c = rec.cartridge || {};
    var R1 = c.caseHead && c.caseHead.R1;
    var P1 = c.powderChamber && c.powderChamber.P1;
    if (!has(R1) || !has(P1)) return 'rimless';
    var q = R1 / P1;
    if (q >= 1.05) return 'rimmed';
    if (q < 0.98) return 'rebated';
    return 'rimless';
  }

  /** Points of a round of radius `radius` between the lines p0-c and c-p2. */
  function fillet(p0, c, p2, radius) {
    var d1 = dist(p0, c), d2 = dist(p2, c);
    var u1 = { z: (p0.z - c.z) / d1, r: (p0.r - c.r) / d1 };
    var u2 = { z: (p2.z - c.z) / d2, r: (p2.r - c.r) / d2 };
    var cos = Math.max(-1, Math.min(1, u1.z * u2.z + u1.r * u2.r));
    var theta = Math.acos(cos);
    if (!(radius > 0) || theta > Math.PI - 1e-6) return [c];
    var t = radius / Math.tan(theta / 2);
    var tmax = 0.5 * Math.min(d1, d2);
    if (t > tmax) t = tmax;
    var R = t * Math.tan(theta / 2);
    var t1 = { z: c.z + u1.z * t, r: c.r + u1.r * t };
    var t2 = { z: c.z + u2.z * t, r: c.r + u2.r * t };
    var bx = u1.z + u2.z, br = u1.r + u2.r, bl = Math.hypot(bx, br);
    var k = R / Math.sin(theta / 2);
    var ctr = { z: c.z + (bx / bl) * k, r: c.r + (br / bl) * k };
    var a1 = Math.atan2(t1.r - ctr.r, t1.z - ctr.z);
    var a2 = Math.atan2(t2.r - ctr.r, t2.z - ctr.z);
    var d = a2 - a1;
    while (d > Math.PI) d -= 2 * Math.PI;
    while (d < -Math.PI) d += 2 * Math.PI;
    var out = [], n = 8;
    for (var i = 0; i <= n; i++) {
      var a = a1 + (d * i) / n;
      out.push({ z: ctr.z + R * Math.cos(a), r: ctr.r + R * Math.sin(a) });
    }
    return out;
  }

  var PRIMER = {
    sp: { d: 4.45, depth: 3.04 }, spm: { d: 4.45, depth: 3.04 }, sr: { d: 4.45, depth: 3.04 },
    lp: { d: 5.33, depth: 3.04 }, lpm: { d: 5.33, depth: 3.04 },
    lr: { d: 5.33, depth: 3.3 }, lrm: { d: 5.33, depth: 3.3 }
  };

  var BULLET = {
    pointy: function () { return { seat: 1.0, k: 0.40 }; },
    rounded: function (cat) { return { seat: cat === 'pistol' ? 0.4 : 0.8, k: cat === 'pistol' ? 0.65 : 0.55 }; },
    flat: function (cat) { return { seat: cat === 'pistol' ? 0.4 : 0.8, k: cat === 'pistol' ? 0.70 : 0.60 }; },
    semi_wadcutter: function () { return { seat: 0.6, k: 0.78 }; }
  };

  function interpolateR(path, z) {
    for (var i = 1; i < path.length; i++) {
      var a = path[i - 1], b = path[i];
      if (z >= a.z - 1e-12 && z <= b.z + 1e-12) {
        if (b.z - a.z < 1e-12) return Math.max(a.r, b.r);
        return a.r + ((z - a.z) / (b.z - a.z)) * (b.r - a.r);
      }
    }
    return path[path.length - 1].r;
  }

  function clipFrom(path, z0) {
    var out = [];
    for (var i = 0; i < path.length; i++) {
      var p = path[i];
      if (p.z >= z0 - 1e-12) {
        if (!out.length && i > 0 && path[i - 1].z < z0 - 1e-12) {
          var a = path[i - 1];
          out.push({ z: z0, r: a.r + ((z0 - a.z) / (p.z - a.z)) * (p.r - a.r) });
        }
        out.push(p);
      }
    }
    return out;
  }

  function buildBullet(rec, c, ctx) {
    var shape = rec.annotations && rec.annotations.defaultBulletShape;
    var cat = rec.annotations && rec.annotations.category;
    var G1 = c.projectile && c.projectile.G1;
    var L3 = c.lengths.L3, L6 = c.lengths.L6;
    if (!has(L6) || !has(G1)) {
      ctx.notes.push('Bullet not drawn: ' + (!has(L6) ? 'L6' : 'G1') + ' missing');
      return null;
    }
    if (!shape || !BULLET[shape]) {
      ctx.notes.push('Bullet not drawn: bullet shape missing');
      return null;
    }
    var spec = BULLET[shape](cat);
    var shankR = ctx.heeled ? c.collar.H2 / 2 : G1 / 2;
    var Gd = 2 * shankR;
    var s = spec.seat * G1;
    var zb = L3 - s;
    var Lb = L6 - zb;
    var cylEnd = zb + spec.k * Lb;
    var n = L6 - cylEnd;
    var m;
    if (shape === 'pointy') m = Math.max(0.08 * Gd, 1.27);
    else if (shape === 'rounded') m = 0.15 * Gd;
    else if (shape === 'flat') m = 0.55 * Gd;
    else m = 0.6 * Gd;
    var nose = [], i, N;
    if (shape === 'pointy') {
      var a = shankR - m / 2;
      var rho = (a * a + n * n) / (2 * a);
      var rc = shankR - rho;
      N = 32;
      for (i = 0; i <= N; i++) {
        var dz = (n * i) / N;
        nose.push({ z: cylEnd + dz, r: i === N ? m / 2 : rc + Math.sqrt(Math.max(0, rho * rho - dz * dz)) });
      }
    } else if (shape === 'rounded') {
      N = 24;
      for (i = 0; i <= N; i++) {
        var f = i / N;
        nose.push({ z: cylEnd + n * f, r: i === N ? m / 2 : m / 2 + (shankR - m / 2) * Math.sqrt(Math.max(0, 1 - f * f)) });
      }
    } else {
      nose.push({ z: cylEnd, r: shankR }, { z: L6, r: m / 2 });
    }
    var full = [{ z: zb, r: 0 }];
    var upper;
    if (ctx.heeled) {
      var heel = c.collar.H2 / 2 - ctx.walls.tb;
      full.push({ z: zb, r: heel }, { z: L3, r: heel }, { z: L3, r: shankR });
      upper = [{ z: L3, r: shankR }];
    } else {
      full.push({ z: zb, r: shankR });
      upper = [{ z: zb, r: shankR }];
    }
    if (cylEnd > full[full.length - 1].z + 1e-9) {
      full.push({ z: cylEnd, r: shankR });
      upper.push({ z: cylEnd, r: shankR });
    }
    nose.slice(1).forEach(function (p) { full.push(p); upper.push(p); });
    full.push({ z: L6, r: 0 });
    upper.push({ z: L6, r: 0 });
    return {
      shape: shape, s: s, zb: zb, Lb: Lb, cylEnd: cylEnd, m: m, shankR: shankR,
      nose: nose, full: full, exposed: clipFrom(upper, L3)
    };
  }

  function buildGeometry(rec) {
    var c = rec.cartridge || {};
    var head = c.caseHead || {}, collar = c.collar || {}, cone = c.junctionCone || {};
    var len = c.lengths || {}, pc = c.powderChamber || {}, proj = c.projectile || {};
    var notes = [];
    var type = rimType(rec);
    var out = { rimType: type, bottleneck: false, heeled: false, outer: [], inner: [], section: [], bullet: null,
      walls: null, notes: notes, features: {}, bodyStartZ: 0 };

    var required = { R: head.R, R1: head.R1, P1: pc.P1, H2: collar.H2, L3: len.L3 };
    var missingReq = Object.keys(required).filter(function (k) { return !has(required[k]); });
    if (missingReq.length) {
      notes.push('Drawing not possible: ' + missingReq.join(', ') + ' missing');
      return out;
    }
    var R = head.R, R1 = head.R1, P1 = pc.P1, H2 = collar.H2, L3 = len.L3;
    var outer = [{ z: 0, r: 0 }];
    function push(z, r) {
      var l = outer[outer.length - 1];
      if (Math.abs(l.z - z) < 1e-9 && Math.abs(l.r - r) < 1e-9) return;
      outer.push({ z: z, r: r });
    }

    // Rule 2: head face and rim edge
    if (type === 'rimfire') {
      var rho = Math.min(R / 2, (R1 - P1) / 2);
      var cr = R1 / 2 - rho;
      push(0, cr);
      for (var k = 1; k <= 12; k++) {
        var th = Math.PI * (1 - k / 12);
        push(rho + rho * Math.cos(th), cr + rho * Math.sin(th));
      }
      push(R, cr);
    } else {
      var chamfer = has(head.beta) && has(head.f) && deg(head.beta) < 90;
      if (chamfer) {
        var cw = Math.min(head.f * Math.tan(deg(head.beta) * DEG), R1 / 4);
        push(0, R1 / 2 - cw);
        push(head.f, R1 / 2);
      } else {
        push(0, R1 / 2);
        if (!has(head.beta) || !has(head.f)) {
          notes.push('Head chamfer not drawn: ' + [!has(head.beta) ? 'beta' : null, !has(head.f) ? 'f' : null].filter(Boolean).join(', ') + ' missing');
        }
      }
      push(R, R1 / 2);
    }

    // Rule 3: extractor groove / belt / step in
    var groove = false, beltEnd = null;
    var grooveExpected = type === 'rimless' || type === 'rebated' || type === 'belted';
    var hasGroove = has(head.E) && has(head.E1);
    if (grooveExpected && !hasGroove) {
      notes.push('Extractor groove not drawn: ' + [!has(head.E) ? 'E' : null, !has(head.E1) ? 'E1' : null].filter(Boolean).join(', ') + ' missing');
      if (type === 'belted') notes.push('Belt not drawn: groove values missing');
    }
    if (type !== 'rimfire' && hasGroove) {
      groove = true;
      push(R, head.E1 / 2);
      var zFloor = R;
      if (has(head.eMin)) { zFloor = R + head.eMin; push(zFloor, head.E1 / 2); }
      else notes.push('Groove floor not drawn: e min missing');
      var drawBelt = false;
      if (type === 'belted') {
        if (!has(head.R3) || !has(head.delta)) {
          notes.push('Belt not drawn: ' + (!has(head.R3) ? 'R3' : 'delta') + ' missing');
        } else drawBelt = head.R3 / 2 > head.E1 / 2;
      }
      if (drawBelt) {
        beltEnd = zFloor + (head.R3 / 2 - head.E1 / 2) / Math.tan(deg(head.delta) * DEG);
        if (beltEnd > head.E) {
          notes.push('Belt not drawn: the ramp (delta, R3) would end beyond E');
          beltEnd = null;
          drawBelt = false;
        }
      }
      if (drawBelt) {
        push(beltEnd, head.R3 / 2);
        push(head.E, head.R3 / 2);
        push(head.E, P1 / 2);
      } else {
        push(head.E, P1 / 2);
      }
      out.bodyStartZ = head.E;
    } else {
      push(R, P1 / 2);
      out.bodyStartZ = R;
    }
    var bodyIdx = outer.length - 1;
    var start = outer[bodyIdx];

    // Rules 4-6: body, shoulder, neck
    var shoulderGiven = has(cone.alpha) && has(len.L1) && has(len.L2);
    var shoulderAny = has(cone.alpha) || has(len.L1) || has(len.L2);
    var bottleneck = false;
    if (shoulderAny && !shoulderGiven) {
      notes.push('Shoulder not drawn (case drawn straight): ' + [!has(cone.alpha) ? 'alpha' : null, !has(len.L1) ? 'L1' : null, !has(len.L2) ? 'L2' : null].filter(Boolean).join(', ') + ' missing');
    }
    if (shoulderGiven) {
      var miss = [!has(pc.P2) ? 'P2' : null, !has(collar.H1) ? 'H1' : null].filter(Boolean);
      if (miss.length) notes.push('Shoulder not drawn (case drawn straight): ' + miss.join(', ') + ' missing');
      else bottleneck = true;
    }
    var mouth = { z: L3, r: H2 / 2 };
    if (bottleneck) {
      var A = { z: len.L1, r: pc.P2 / 2 }, B = { z: len.L2, r: collar.H1 / 2 };
      var arc1 = has(cone.r1Min) ? fillet(start, A, B, cone.r1Min) : [A];
      var arc2 = has(cone.r2) ? fillet(A, B, mouth, cone.r2) : [B];
      if (!has(cone.r1Min)) notes.push('Body-side corner round not drawn: r1 min missing');
      if (!has(cone.r2)) notes.push('Neck-side corner round not drawn: r2 missing');
      arc1.forEach(function (p) { push(p.z, p.r); });
      arc2.forEach(function (p) { push(p.z, p.r); });
      out.features.shoulderStart = A;
      out.features.shoulderEnd = B;
    }
    push(mouth.z, mouth.r);
    out.bottleneck = bottleneck;
    out.outer = outer;
    out.features.mouth = mouth;
    out.features.bodyStart = start;
    out.features.groove = groove;
    out.features.beltEnd = beltEnd;

    // Rule 8: walls, head, pocket
    var G1 = proj.G1;
    var tn = has(G1) ? (H2 - G1) / 2 : null;
    if (tn === null) notes.push('Neck wall not drawn thinner than the body wall: G1 missing');
    var tb = Math.min(Math.max(tn === null ? 0.6 : 1.3 * tn, 0.6), 0.35 * P1 / 2);
    out.heeled = has(G1) && H2 - G1 <= 0.015;
    var pocket = null;
    if (type !== 'rimfire') {
      var pt = rec.annotations && rec.annotations.primerType;
      if (pt && PRIMER[pt]) pocket = { d: PRIMER[pt].d, depth: PRIMER[pt].depth };
      else notes.push('Primer pocket not drawn: primer type ' + (pt ? 'unknown' : 'missing'));
    }
    var w = Math.max(2.5, 0.25 * P1 / 2);
    if (pocket) w = Math.max(w, pocket.depth + 1.5);
    if (groove) w = Math.max(w, head.E + tb);
    if (beltEnd !== null) w = Math.max(w, beltEnd + tb);
    out.walls = { tn: tn, tb: tb, w: w, pocket: pocket };

    out.bullet = buildBullet(rec, c, out);
    var zSeat = out.bullet ? out.bullet.zb : L3;

    var body = outer.slice(bodyIdx);
    function ro(z) { return z <= start.z ? start.r : interpolateR(body, z); }
    function wall(z) {
      if (out.heeled || tn === null) return tb;
      if (bottleneck) {
        if (z <= len.L1) return tb;
        if (z >= len.L2) return tn;
        return tb + ((z - len.L1) / (len.L2 - len.L1)) * (tn - tb);
      }
      if (zSeat <= w) return tn;
      if (z <= w) return tb;
      if (z >= zSeat) return tn;
      return tb + ((z - w) / (zSeat - w)) * (tn - tb);
    }
    var zs = [w, L3];
    if (bottleneck) [len.L1, len.L2].forEach(function (z) { if (z > w && z < L3) zs.push(z); });
    body.forEach(function (p) { if (p.z > w && p.z < L3) zs.push(p.z); });
    if (!bottleneck && out.bullet && zSeat > w && zSeat < L3) zs.push(zSeat);
    zs.sort(function (a, b) { return a - b; });
    var inner = [];
    zs.forEach(function (z, i) {
      if (i && Math.abs(z - zs[i - 1]) < 1e-9) return;
      inner.push({ z: z, r: ro(z) - wall(z) });
    });
    out.inner = inner;

    // Section polygon of the cut case (upper-half coordinates)
    var sec = [];
    if (pocket) { sec.push({ z: 0, r: pocket.d / 2 }); outer.slice(1).forEach(function (p) { sec.push(p); }); }
    else outer.forEach(function (p) { sec.push(p); });
    for (var j = inner.length - 1; j >= 0; j--) sec.push(inner[j]);
    sec.push({ z: w, r: 0 });
    if (pocket) { sec.push({ z: pocket.depth, r: 0 }, { z: pocket.depth, r: pocket.d / 2 }); }
    out.section = sec;
    return out;
  }

  var api = { rimType: rimType, buildGeometry: buildGeometry, fillet: fillet, deg: deg };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  else { root.CIP = root.CIP || {}; root.CIP.geometry = api; }
})(typeof window !== 'undefined' ? window : globalThis);
