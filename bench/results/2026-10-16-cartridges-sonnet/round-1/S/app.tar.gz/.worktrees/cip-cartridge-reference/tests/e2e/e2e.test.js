'use strict';
// End-to-end checks on file:// (no web server) with headless Chromium.
// Run: npm run test:e2e   (needs `npx playwright-core install chromium`)
const test = require('node:test');
const assert = require('node:assert/strict');
const path = require('path');
const http = require('http');
const fs = require('fs');
const { chromium } = require('playwright-core');
const DATA = require('../../data.js');

const ROOT = path.resolve(__dirname, '../..');
const FILE_URL = 'file://' + path.join(ROOT, 'index.html');
let browser;

test.before(async () => { browser = await chromium.launch(); });
test.after(async () => { await browser.close(); });

async function open(opts, hash) {
  const ctx = await browser.newContext(opts || { viewport: { width: 1100, height: 900 } });
  const page = await ctx.newPage();
  page.errors = [];
  page.requests = [];
  page.on('pageerror', (e) => page.errors.push(String(e)));
  page.on('console', (m) => { if (m.type() === 'error') page.errors.push(m.text()); });
  page.on('request', (r) => page.requests.push(r.url()));
  await page.goto(FILE_URL + (hash || ''));
  return page;
}

test('start page: heading, count, one link per cartridge with the exact name', async () => {
  const page = await open();
  assert.equal(await page.getByRole('heading', { level: 1 }).textContent(), 'Cartridges');
  assert.equal(await page.getByText('25 cartridges', { exact: true }).count(), 1);
  for (const r of DATA) {
    const link = page.getByRole('link', { name: r.name, exact: true });
    assert.equal(await link.count(), 1, r.name);
  }
  const row = page.getByRole('row', { name: /308 Win\./ });
  const text = await row.textContent();
  assert.match(text, /rimless/);
  assert.match(text, /51\.18/);
  assert.deepEqual(page.errors, []);
  assert.deepEqual(page.requests.filter((u) => !u.startsWith('file://')), []);
});

test('search by name and by alternative name, with live count', async () => {
  const page = await open();
  await page.getByLabel('Search').fill('7,62 x 51');
  assert.equal(await page.locator('#count').textContent(), '1 cartridges');
  assert.ok(await page.getByRole('link', { name: '308 Win.', exact: true }).isVisible());
  await page.getByLabel('Search').fill('creed');
  assert.equal(await page.locator('#count').textContent(), '1 cartridges');
  await page.getByLabel('Search').fill('zzz');
  assert.equal(await page.locator('#count').textContent(), '0 cartridges');
  await page.getByLabel('Search').fill('');
  assert.equal(await page.locator('#count').textContent(), '25 cartridges');
});

test('family select', async () => {
  const page = await open();
  const options = await page.getByLabel('Family').locator('option').allTextContents();
  assert.deepEqual(options, ['All', 'rimless', 'rimmed', 'belted', 'pistol', 'rimfire']);
  await page.getByLabel('Family').selectOption('belted');
  assert.equal(await page.locator('#count').textContent(), '2 cartridges');
  await page.getByLabel('Family').selectOption('rimfire');
  assert.equal(await page.locator('#count').textContent(), '3 cartridges');
  await page.getByLabel('Search').fill('22');
  assert.equal(await page.locator('#count').textContent(), '2 cartridges');
});

test('detail view: heading, facts, drawing name, tables, own address, reload', async () => {
  const page = await open();
  await page.getByRole('link', { name: '308 Win.', exact: true }).click();
  await page.getByRole('heading', { level: 1, name: '308 Win.' }).waitFor();
  assert.match(page.url(), /#\/cartridge\/308_win$/);
  assert.equal(await page.getByRole('heading', { level: 1 }).textContent(), '308 Win.');
  const body = await page.locator('main').innerText();
  for (const s of ['308 Winchester, 7,62 x 51', 'rimless', 'rifle', 'lr', 'Transducer', '1984-06-14', '2008-09-23', 'US']) {
    assert.ok(body.includes(s), s);
  }
  const cap = page.getByRole('link', { name: /kwk/ });
  assert.equal(await cap.getAttribute('href'), 'http://kwk.us/cases.html');
  assert.equal(await page.getByRole('img', { name: '308 Win. drawing' }).count(), 1);
  assert.ok(await page.getByRole('button', { name: 'Print' }).isVisible());
  assert.ok(await page.getByRole('link', { name: 'All cartridges', exact: true }).isVisible());
  // tables: columns, tolerance next to the value, unit
  const lengths = page.getByRole('table', { name: 'Lengths' }).first();
  assert.deepEqual(await lengths.getByRole('columnheader').allTextContents(), ['Symbol', 'Value', 'Unit']);
  const l1 = await lengths.getByRole('row', { name: /^L1 / }).innerText();
  assert.match(l1.replace(/\s+/g, ' '), /L1 39\.62 -0\.2 mm/);
  // reload keeps the view
  await page.reload();
  await page.getByRole('heading', { level: 1, name: '308 Win.' }).waitFor();
  assert.equal(await page.getByRole('heading', { level: 1 }).textContent(), '308 Win.');
  assert.equal(await page.getByRole('img', { name: '308 Win. drawing' }).count(), 1);
  // back to the list keeps the filter state
  await page.getByRole('link', { name: 'All cartridges', exact: true }).click();
  await page.getByRole('heading', { level: 1, name: 'Cartridges' }).waitFor();
  assert.equal(await page.getByRole('heading', { level: 1 }).textContent(), 'Cartridges');
  assert.deepEqual(page.errors, []);
});

test('every detail view opens directly, has the drawing, no errors, no network', async () => {
  const page = await open();
  for (const r of DATA) {
    await page.goto(FILE_URL + '#/cartridge/' + r.key);
    await page.reload();
    await page.getByRole('heading', { level: 1, name: r.name, exact: true }).waitFor();
    assert.equal(await page.getByRole('heading', { level: 1 }).textContent(), r.name, r.key);
    assert.equal(await page.getByRole('img', { name: r.name + ' drawing' }).count(), 1, r.key);
    const rows = await page.locator('table.values-table tbody tr').count();
    assert.ok(rows >= 25, r.key + ' rows ' + rows);
  }
  assert.deepEqual(page.errors, []);
  assert.deepEqual(page.requests.filter((u) => !u.startsWith('file://')), []);
});

test('unknown address shows a not-found page with a way back', async () => {
  const page = await open(null, '#/cartridge/nope');
  assert.equal(await page.getByRole('heading', { level: 1 }).textContent(), 'Cartridge not found');
  assert.ok(await page.getByRole('link', { name: 'All cartridges' }).isVisible());
});

test('names with a decimal comma and special characters are shown as published', async () => {
  const page = await open(null, '#/cartridge/6_5_creedmoor');
  assert.equal(await page.getByRole('heading', { level: 1 }).textContent(), '6,5 Creedmoor');
  await page.goto(FILE_URL + '#/cartridge/40_s_w');
  assert.equal(await page.getByRole('heading', { level: 1 }).textContent(), '40 S.& W.');
});

test('drawing: label boxes in the browser do not overlap (real font metrics)', async () => {
  const page = await open();
  for (const r of DATA) {
    await page.goto(FILE_URL + '#/cartridge/' + r.key);
    const res = await page.evaluate(() => {
      const boxes = [...document.querySelectorAll('svg.drawing .labels text')].map((t) => {
        const b = t.getBBox();
        return { t: t.textContent, x: b.x, y: b.y, w: b.width, h: b.height };
      });
      const bad = [];
      boxes.forEach((a, i) => boxes.slice(i + 1).forEach((b) => {
        if (a.x < b.x + b.w && b.x < a.x + a.w && a.y < b.y + b.h && b.y < a.y + a.h) bad.push(a.t + ' / ' + b.t);
      }));
      const segs = [];
      document.querySelectorAll('svg.drawing line.outline, svg.drawing line.dim, svg.drawing line.ext').forEach((l) => {
        segs.push([+l.getAttribute('x1'), +l.getAttribute('y1'), +l.getAttribute('x2'), +l.getAttribute('y2')]);
      });
      document.querySelectorAll('svg.drawing polyline.outline, svg.drawing polygon.cut, svg.drawing polygon.bullet-cut').forEach((pl) => {
        const p = pl.getAttribute('points').trim().split(/\s+/).map((q) => q.split(',').map(Number));
        for (let i = 1; i < p.length; i++) segs.push([p[i - 1][0], p[i - 1][1], p[i][0], p[i][1]]);
        if (pl.tagName === 'polygon') segs.push([p[p.length - 1][0], p[p.length - 1][1], p[0][0], p[0][1]]);
      });
      const hit = (s, r) => {
        let t0 = 0, t1 = 1; const dx = s[2] - s[0], dy = s[3] - s[1];
        const pp = [-dx, dx, -dy, dy], q = [s[0] - r.x, r.x + r.w - s[0], s[1] - r.y, r.y + r.h - s[1]];
        for (let i = 0; i < 4; i++) {
          if (pp[i] === 0) { if (q[i] < 0) return false; } else {
            const t = q[i] / pp[i];
            if (pp[i] < 0) { if (t > t1) return false; if (t > t0) t0 = t; } else { if (t < t0) return false; if (t < t1) t1 = t; }
          }
        }
        return true;
      };
      boxes.forEach((b) => segs.forEach((sg) => { if (hit(sg, b)) bad.push(b.t + ' on a line'); }));
      return { n: boxes.length, bad };
    });
    assert.deepEqual(res.bad, [], r.key);
    assert.ok(res.n >= 6, r.key);
  }
});

test('phone width: no horizontal scroll, drawing fits the width', async () => {
  const page = await open({ viewport: { width: 360, height: 740 }, deviceScaleFactor: 2, isMobile: true, hasTouch: true });
  for (const hash of ['', '#/cartridge/9_3_x_74_r', '#/cartridge/22_long_rifle']) {
    await page.goto(FILE_URL + hash);
    const m = await page.evaluate(() => ({
      sw: document.documentElement.scrollWidth, cw: document.documentElement.clientWidth,
      svg: (document.querySelector('svg.drawing') || { getBoundingClientRect: () => ({ width: 0 }) }).getBoundingClientRect().width,
    }));
    assert.ok(m.sw <= m.cw, hash + ' scroll ' + m.sw + '>' + m.cw);
    if (hash) assert.ok(m.svg > 300 && m.svg <= 360, hash + ' svg ' + m.svg);
  }
});

test('dark and light colour schemes both render', async () => {
  for (const scheme of ['light', 'dark']) {
    const page = await open({ viewport: { width: 1000, height: 800 }, colorScheme: scheme }, '#/cartridge/223_rem');
    const bg = await page.evaluate(() => getComputedStyle(document.body).backgroundColor);
    assert.equal(bg, scheme === 'dark' ? 'rgb(20, 24, 28)' : 'rgb(246, 247, 248)');
  }
});

test('print: one A4 page per detail view, black on white, no navigation or buttons', async () => {
  const page = await open();
  for (const r of DATA) {
    await page.goto(FILE_URL + '#/cartridge/' + r.key);
    await page.emulateMedia({ media: 'print' });
    const vis = await page.evaluate(() => {
      const shown = (sel) => [...document.querySelectorAll(sel)].some((e) => e.getClientRects().length > 0);
      return {
        nav: shown('.site, .toolbar, button, input, select'),
        bg: getComputedStyle(document.body).backgroundColor,
        fg: getComputedStyle(document.body).color,
        footer: document.querySelector('.source').innerText,
      };
    });
    assert.equal(vis.nav, false, r.key);
    assert.equal(vis.bg, 'rgb(255, 255, 255)');
    assert.equal(vis.fg, 'rgb(0, 0, 0)');
    assert.equal(vis.footer, 'Source: C.I.P. TDCC, revised ' + r.revised);
    const pdf = await page.pdf({ format: 'A4', printBackground: true, preferCSSPageSize: true });
    const pages = (pdf.toString('latin1').match(/\/Type\s*\/Page[^s]/g) || []).length;
    assert.equal(pages, 1, r.key + ' prints on ' + pages + ' pages');
    await page.emulateMedia({ media: 'screen' });
  }
});

test('works when served by a static file server too', async () => {
  const types = { '.html': 'text/html', '.js': 'text/javascript', '.css': 'text/css' };
  const server = http.createServer((req, res) => {
    const f = path.join(ROOT, req.url === '/' ? 'index.html' : req.url.split('?')[0]);
    if (!f.startsWith(ROOT) || !fs.existsSync(f)) { res.statusCode = 404; return res.end(); }
    res.setHeader('content-type', types[path.extname(f)] || 'application/octet-stream');
    res.end(fs.readFileSync(f));
  });
  await new Promise((r) => server.listen(0, r));
  const page = await (await browser.newContext()).newPage();
  await page.goto('http://127.0.0.1:' + server.address().port + '/#/cartridge/223_rem');
  assert.equal(await page.getByRole('heading', { level: 1 }).textContent(), '223 Rem.');
  server.close();
});
