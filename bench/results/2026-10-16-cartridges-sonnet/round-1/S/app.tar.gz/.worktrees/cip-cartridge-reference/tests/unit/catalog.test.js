'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const C = require('../../catalog.js');
const DATA = require('../../data.js');

const names = (list) => list.map((r) => r.name);

test('no filter lists everything', () => {
  assert.equal(C.filter(DATA, {}).length, 25);
  assert.equal(C.filter(DATA, { query: '', family: 'all' }).length, 25);
});

test('search finds alternative names', () => {
  assert.deepEqual(names(C.filter(DATA, { query: '7,62 x 51' })), ['308 Win.']);
  assert.deepEqual(names(C.filter(DATA, { query: '30-06' })), ['30-06 Spring.']);
});

test('search ignores case and spacing', () => {
  assert.deepEqual(names(C.filter(DATA, { query: '22LR' })), ['22 Long Rifle']);
  assert.deepEqual(names(C.filter(DATA, { query: 'creed' })), ['6,5 Creedmoor']);
  assert.deepEqual(names(C.filter(DATA, { query: '7,62x51' })), ['308 Win.']);
});

test('search treats decimal comma and point alike', () => {
  assert.deepEqual(names(C.filter(DATA, { query: '6.5 creedmoor' })), ['6,5 Creedmoor']);
});

test('family filter', () => {
  assert.equal(C.filter(DATA, { family: 'belted' }).length, 2);
  assert.equal(C.filter(DATA, { family: 'rimmed' }).length, 2);
  assert.equal(C.filter(DATA, { family: 'rimfire' }).length, 3);
  assert.equal(C.filter(DATA, { family: 'pistol' }).length, 6);
  assert.equal(C.filter(DATA, { family: 'rimless' }).length, 12);
});

test('search and family combine', () => {
  assert.deepEqual(names(C.filter(DATA, { query: '22', family: 'rimfire' })), ['22 Long Rifle', '22 Win. Mag. R.F.']);
  assert.equal(C.filter(DATA, { query: '22', family: 'pistol' }).length, 0);
});

test('countLabel', () => {
  assert.equal(C.countLabel(25), '25 cartridges');
  assert.equal(C.countLabel(1), '1 cartridges');
  assert.equal(C.countLabel(0), '0 cartridges');
});

test('findByKey', () => {
  assert.equal(C.findByKey(DATA, '308_win').name, '308 Win.');
  assert.equal(C.findByKey(DATA, 'nope'), undefined);
});
