'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const D = require('../../drawing.js');
const DATA = require('../../data.js');

const rec = (k) => DATA.find((r) => r.key === k);
const labelTexts = (d) => d.labels.map((l) => l.text);

function segRect(s, r) {
  // Liang-Barsky segment / rectangle intersection (closed)
  let t0 = 0, t1 = 1;
  const dx = s.x2 - s.x1, dy = s.y2 - s.y1;
  const p = [-dx, dx, -dy, dy];
  const q = [s.x1 - r.x, r.x + r.w - s.x1, s.y1 - r.y, r.y + r.h - s.y1];
  for (let i = 0; i < 4; i++) {
    if (p[i] === 0) { if (q[i] < 0) return false; }
    else {
      const t = q[i] / p[i];
      if (p[i] < 0) { if (t > t1) return false; if (t > t0) t0 = t; }
      else { if (t < t0) return false; if (t < t1) t1 = t; }
    }
  }
  return true;
}
const rectRect = (a, b) => a.x < b.x + b.w && b.x < a.x + a.w && a.y < b.y + b.h && b.y < a.y + a.h;

test('svg has the accessible name "<name> drawing" and a true-scale viewBox', () => {
  const d = D.buildDrawing(rec('6_5_creedmoor'));
  assert.match(d.svg, /^<svg\b/);
  assert.match(d.svg, /role="img"/);
  assert.match(d.svg, /aria-label="6,5 Creedmoor drawing"/);
  assert.match(d.svg, /viewBox="[-\d. ]+"/);
  assert.ok(d.width > 40 && d.height > 30);
});

test('1 user unit = 1 mm: the case length L3 spans 51.18 units on the axis', () => {
  const d = D.buildDrawing(rec('308_win'));
  const outline = d.segments.filter((s) => s.kind === 'outline');
  const xs = outline.flatMap((s) => [s.x1, s.x2]);
  assert.ok(Math.min(...xs) >= -1e-9 && Math.abs(Math.max(...xs) - 71.12) < 1e-6, 'head at 0, tip at L6');
  assert.ok(outline.some((s) => Math.abs(s.x1 - 51.18) < 1e-9 || Math.abs(s.x2 - 51.18) < 1e-9));
});

test('required dimensions carry symbol and value', () => {
  const d = D.buildDrawing(rec('308_win'));
  const t = labelTexts(d);
  for (const x of ['L3 51.18', 'L6 71.12', 'R1 12.01', 'R 1.37', 'P1 11.96', 'P2 11.53', 'H1 8.72', 'H2 8.72', 'G1 7.85',
    'L1 39.62', 'L2 43.48', 'E1 10.39', 'α 40°']) assert.ok(t.includes(x), x + ' in ' + t.join('|'));
});

test('angles with minutes and seconds', () => {
  const t = labelTexts(D.buildDrawing(rec('6_5_x_55_se')));
  assert.ok(t.includes('α 50°35\'2"'), t.join('|'));
});

test('published-only dimensions: pistol drawings have no shoulder dimensions', () => {
  const t = labelTexts(D.buildDrawing(rec('9_mm_luger')));
  for (const x of ['L3 19.15', 'L6 29.69', 'R1 9.96', 'R 1.27', 'P1 9.93', 'H2 9.65', 'G1 9.03', 'E1 8.79']) assert.ok(t.includes(x), x);
  assert.ok(!t.some((s) => /^(L1|L2|P2|H1|α)\b/.test(s)));
});

test('rimmed case without groove values has no E1 dimension', () => {
  const t = labelTexts(D.buildDrawing(rec('7_x_65_r')));
  assert.ok(!t.some((s) => /^E1/.test(s)));
  assert.ok(t.includes('R1 13.32'));
});

test('title block: name, table, revision, units, scale', () => {
  const d = D.buildDrawing(rec('223_rem'));
  assert.match(d.svg, />223 Rem\.</);
  assert.match(d.svg, /C\.I\.P\. table I</);
  assert.match(d.svg, /Revised 2017-05-17</);
  assert.match(d.svg, /Dimensions in mm</);
  assert.match(d.svg, /Scale [\d.]+ : 1/);
});

test('dash-dot centre line, hatched cut walls, arrowheads and extension lines exist', () => {
  const d = D.buildDrawing(rec('223_rem'));
  assert.match(d.svg, /class="centre"/);
  assert.match(d.svg, /<pattern\b/);
  assert.match(d.svg, /class="cut"/);
  assert.ok((d.svg.match(/class="arrow"/g) || []).length >= 20);
  assert.ok(d.segments.filter((s) => s.kind === 'ext').length >= 8);
});

test('every dimension has arrowheads, a dimension line and extension lines', () => {
  for (const r of DATA) {
    const d = D.buildDrawing(r);
    for (const dim of d.dimensions) {
      assert.ok(dim.arrows >= 1, r.key + ' ' + dim.id + ' arrows');
      assert.ok(d.segments.some((s) => s.dim === dim.id && s.kind === 'dim'), r.key + ' ' + dim.id + ' line');
      assert.ok(d.segments.some((s) => s.dim === dim.id && s.kind === 'ext'), r.key + ' ' + dim.id + ' ext');
    }
    for (const id of ['L3', 'L6', 'R1', 'R', 'P1']) assert.ok(d.dimensions.some((x) => x.id === id), r.key + ' ' + id);
  }
});

test('labels overlap neither each other nor any line or outline (all 25 records)', () => {
  for (const r of DATA) {
    const d = D.buildDrawing(r);
    assert.ok(d.labels.length >= 5, r.key);
    d.labels.forEach((a, i) => {
      d.labels.slice(i + 1).forEach((b) => assert.ok(!rectRect(a, b), `${r.key}: ${a.text} overlaps ${b.text}`));
      d.segments.forEach((s) => {
        if (s.kind === 'centre') return;
        assert.ok(!segRect(s, a), `${r.key}: ${a.text} overlaps ${s.kind} ${s.dim || ''}`);
      });
      assert.ok(a.x >= d.viewBox.x && a.x + a.w <= d.viewBox.x + d.viewBox.w, r.key + ' label inside viewBox x');
      assert.ok(a.y >= d.viewBox.y && a.y + a.h <= d.viewBox.y + d.viewBox.h, r.key + ' label inside viewBox y');
    });
  }
});

test('font size is legible when scaled to a phone width', () => {
  for (const r of DATA) {
    const d = D.buildDrawing(r);
    const px = (d.fontSize * 360) / d.width;
    assert.ok(px >= 6.5, `${r.key}: ${px.toFixed(1)}px`);
  }
});

test('missing values are reported with the drawing', () => {
  assert.ok(D.buildDrawing(rec('338_lapua_mag')).notes.some((n) => /r1 min/.test(n)));
  assert.deepEqual(D.buildDrawing(rec('223_rem')).notes, []);
});

test('svg is well-formed enough: balanced tags, no NaN', () => {
  for (const r of DATA) {
    const d = D.buildDrawing(r);
    assert.ok(!/NaN|undefined|Infinity/.test(d.svg), r.key);
    assert.equal((d.svg.match(/<g\b/g) || []).length, (d.svg.match(/<\/g>/g) || []).length, r.key);
    assert.ok(d.svg.endsWith('</svg>'));
  }
});
