'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const F = require('../../format.js');
const DATA = require('../../data.js');

const byKey = (k) => DATA.find((r) => r.key === k);

test('formatAngle shows plain degrees', () => {
  assert.equal(F.formatAngle(40), '40°');
  assert.equal(F.formatAngle(22.5), '22.5°');
});

test('formatAngle shows degrees, minutes and seconds', () => {
  assert.equal(F.formatAngle({ degrees: 39, minutes: 59, seconds: 49 }), '39°59\'49"');
  assert.equal(F.formatAngle({ degrees: 1, minutes: 30, seconds: 0 }), '1°30\'0"');
});

test('formatValue puts the tolerance next to the value', () => {
  assert.equal(F.formatValue('L1', 39.62, -0.2), '39.62 -0.2');
  assert.equal(F.formatValue('L1', 39.62), '39.62');
  assert.equal(F.formatValue('x', 0.2, 0.2), '0.2 +0.2');
});

test('formatValue keeps published decimals and has no thousands separator', () => {
  assert.equal(F.formatValue('Pmax', 4150), '4150');
  assert.equal(F.formatValue('L3', 51.18), '51.18');
  assert.equal(F.formatValue('alpha', 46), '46°');
  assert.equal(F.formatValue('i', { degrees: 3, minutes: 10, seconds: 36 }), '3°10\'36"');
});

test('symbols follow the brief', () => {
  const exp = {
    eMin: 'e min', r1Min: 'r1 min', r1Max: 'r1 max', alpha: 'α', alpha1: 'α1',
    beta: 'β', delta: 'δ', deltaL: 'delta L', L3PlusG: 'L3 + G', L3: 'L3', Pmax: 'Pmax', r: 'r',
  };
  for (const [k, v] of Object.entries(exp)) assert.equal(F.symbol(k), v, k);
});

test('units', () => {
  assert.equal(F.unit('L3'), 'mm');
  assert.equal(F.unit('Pmax'), 'bar');
  assert.equal(F.unit('PK'), 'bar');
  assert.equal(F.unit('PE'), 'bar');
  assert.equal(F.unit('EE'), 'J');
  assert.equal(F.unit('M'), 'g');
  assert.equal(F.unit('Q'), 'mm²');
  assert.equal(F.unit('N'), '');
  for (const a of ['alpha', 'alpha1', 'beta', 'delta', 'i']) assert.equal(F.unit(a), '°');
});

test('isAngleField', () => {
  assert.ok(F.isAngleField('alpha1'));
  assert.ok(!F.isAngleField('L1'));
});

test('sectionTables: tolerance never becomes a row of its own', () => {
  for (const rec of DATA) {
    for (const group of ['cartridge', 'chamber']) {
      for (const sec of F.sectionTables(rec, group)) {
        for (const row of sec.rows) assert.ok(!/Tol$/.test(row.field), rec.key + ' ' + row.field);
      }
    }
  }
});

test('sectionTables: 308 Win. lengths', () => {
  const secs = F.sectionTables(byKey('308_win'), 'cartridge');
  const lengths = secs.find((s) => s.title === 'Lengths');
  const l1 = lengths.rows.find((r) => r.symbol === 'L1');
  assert.deepEqual([l1.value, l1.unit], ['39.62 -0.2', 'mm']);
  const l3 = lengths.rows.find((r) => r.symbol === 'L3');
  assert.deepEqual([l3.value, l3.unit], ['51.18', 'mm']);
  const press = secs.find((s) => s.title === 'Pressures');
  assert.deepEqual(press.rows.find((r) => r.symbol === 'Pmax').value, '4150');
  assert.equal(press.rows.find((r) => r.symbol === 'EE').unit, 'J');
});

test('sectionTables: empty sections are skipped, every value appears', () => {
  const rec = byKey('9_mm_luger');
  const secs = F.sectionTables(rec, 'cartridge');
  assert.ok(!secs.some((s) => s.title === 'Junction cone'));
  const n = (obj) => Object.values(obj).reduce((a, s) => a + Object.keys(s).filter((k) => !/Tol$/.test(k)).length, 0);
  for (const r of DATA) {
    for (const g of ['cartridge', 'chamber']) {
      const rows = F.sectionTables(r, g).reduce((a, s) => a + s.rows.length, 0);
      assert.equal(rows, n(r[g]), r.key + ' ' + g);
    }
  }
});

test('names are shown as published', () => {
  assert.equal(byKey('6_5_creedmoor').name, '6,5 Creedmoor');
});
