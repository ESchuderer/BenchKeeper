'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const G = require('../../geometry.js');
const DATA = require('../../data.js');

const rec = (k) => DATA.find((r) => r.key === k);
const near = (a, b, e) => Math.abs(a - b) <= (e === undefined ? 1e-6 : e);
const has = (pts, z, r, e) => pts.some((p) => near(p.z, z, e) && near(p.r, r, e));

test('rimType follows rule 1', () => {
  const exp = {
    '223_rem': 'rimless', '308_win': 'rimless', '7_62_x_39': 'rimless', '338_lapua_mag': 'rimless',
    '300_win_mag': 'belted', '7_mm_rem_mag': 'belted',
    '9_3_x_74_r': 'rimmed', '7_x_65_r': 'rimmed', '38_special': 'rimmed', '357_magnum': 'rimmed', '44_rem_mag': 'rimmed',
    '9_mm_luger': 'rimless', '45_auto': 'rimless', '40_s_w': 'rimless',
    '22_long_rifle': 'rimfire', '22_win_mag_r_f': 'rimfire', '17_hmr': 'rimfire',
  };
  for (const [k, v] of Object.entries(exp)) assert.equal(G.rimType(rec(k)), v, k);
});

test('rimType: rebated when R1/P1 < 0.98, rimmed when >= 1.05', () => {
  const mk = (r1, p1) => ({ family: 'rimless', cartridge: { caseHead: { R1: r1 }, powderChamber: { P1: p1 } } });
  assert.equal(G.rimType(mk(9.7, 10)), 'rebated');
  assert.equal(G.rimType(mk(10.5, 10)), 'rimmed');
  assert.equal(G.rimType(mk(10.2, 10)), 'rimless');
  assert.equal(G.rimType(mk(9.8, 10)), 'rimless');
});

test('223 Rem. head: chamfer, rim edge, extractor groove', () => {
  const g = G.buildGeometry(rec('223_rem'));
  const o = g.outer;
  assert.deepEqual(o[0], { z: 0, r: 0 });
  const cw = 0.45 * Math.tan((35 * Math.PI) / 180);
  assert.ok(has(o, 0, 4.8 - cw), 'chamfer start');
  assert.ok(has(o, 0.45, 4.8), 'chamfer end');
  assert.ok(has(o, 1.14, 4.8), 'rim corner');
  assert.ok(has(o, 1.14, 8.43 / 2), 'groove top');
  assert.ok(has(o, 1.14 + 0.76, 8.43 / 2), 'groove floor end');
  assert.ok(has(o, 3.13, 9.58 / 2), 'ramp end at P1/2, E');
});

test('9,3 x 74 R (rimmed, no groove values): step in from the rim to P1/2', () => {
  const g = G.buildGeometry(rec('9_3_x_74_r'));
  assert.ok(has(g.outer, 1.4, 13.35 / 2));
  assert.ok(has(g.outer, 1.4, 11.9 / 2));
  assert.equal(g.bodyStartZ, 1.4);
  assert.ok(!g.notes.some((n) => /groove/i.test(n)), 'rimmed cases have no groove: no note');
});

test('belted 300 Win. Mag.: ramp at delta to the belt, belt to E, step in to P1/2', () => {
  const g = G.buildGeometry(rec('300_win_mag'));
  const dr = 13.51 / 2 - 12.07 / 2;
  const zEnd = 1.27 + 0.94 + dr / Math.tan((35 * Math.PI) / 180);
  assert.ok(has(g.outer, zEnd, 13.51 / 2), 'belt ramp end');
  assert.ok(has(g.outer, 5.59, 13.51 / 2), 'belt to E');
  assert.ok(has(g.outer, 5.59, 13.03 / 2), 'step in');
  assert.ok(near(g.walls.w, Math.max(5.59 + g.walls.tb, zEnd + g.walls.tb, 3.3 + 1.5)));
});

test('rimfire 22 LR: half-round rim edge, outermost point at R1/2', () => {
  const g = G.buildGeometry(rec('22_long_rifle'));
  const rho = Math.min(1.09 / 2, (7.06 - 5.74) / 2);
  assert.ok(has(g.outer, rho, 7.06 / 2), 'outermost');
  assert.ok(g.outer.every((p) => p.r <= 7.06 / 2 + 1e-9));
  assert.ok(has(g.outer, 0, 7.06 / 2 - rho));
  assert.ok(has(g.outer, 1.09, 5.74 / 2), 'step in at R');
  assert.equal(g.walls.pocket, null);
});

test('bottleneck 223 Rem.: shoulder corners are rounded, straight 9 mm is not a bottleneck', () => {
  const g = G.buildGeometry(rec('223_rem'));
  assert.equal(g.bottleneck, true);
  assert.ok(!has(g.outer, 36.52, 4.5, 1e-4), 'corner replaced by the round');
  assert.ok(g.outer.some((p) => p.z > 36.0 && p.z < 36.52));
  assert.ok(has(g.outer, 44.7, 6.43 / 2));
  const n = G.buildGeometry(rec('9_mm_luger'));
  assert.equal(n.bottleneck, false);
  assert.ok(has(n.outer, 19.15, 9.65 / 2));
});

test('338 Lapua Mag. has no r1 min: sharp body-side corner, noted', () => {
  const g = G.buildGeometry(rec('338_lapua_mag'));
  assert.ok(has(g.outer, 54.9, 13.82 / 2), 'sharp corner');
  assert.ok(g.notes.some((n) => /r1 min/.test(n)));
  assert.ok(!g.notes.some((n) => /r2/.test(n)));
});

test('17 HMR notes both missing rounds; 22 Win. Mag. is straight without a note', () => {
  const g = G.buildGeometry(rec('17_hmr'));
  assert.ok(g.notes.some((n) => /r1 min/.test(n)));
  assert.ok(g.notes.some((n) => /r2/.test(n)));
  const w = G.buildGeometry(rec('22_win_mag_r_f'));
  assert.equal(w.bottleneck, false);
  assert.deepEqual(w.notes, []);
});

test('rule 9: missing values are reported, nothing invented', () => {
  const r = JSON.parse(JSON.stringify(rec('308_win')));
  delete r.cartridge.caseHead.E1;
  delete r.cartridge.caseHead.f;
  const g = G.buildGeometry(r);
  assert.ok(g.notes.some((n) => /groove/i.test(n) && /E1/.test(n)));
  assert.ok(g.notes.some((n) => /chamfer/i.test(n) && /\bf\b/.test(n)));
  assert.ok(has(g.outer, 1.37, 12.01 / 2));
  assert.ok(has(g.outer, 1.37, 11.96 / 2));
});

test('well-formed outer profile for every record', () => {
  for (const r of DATA) {
    const g = G.buildGeometry(r);
    const o = g.outer;
    const c = r.cartridge;
    assert.deepEqual(o[0], { z: 0, r: 0 }, r.key);
    const last = o[o.length - 1];
    assert.ok(near(last.z, c.lengths.L3) && near(last.r, c.collar.H2 / 2), r.key + ' mouth');
    for (let i = 1; i < o.length; i++) {
      assert.ok(o[i].z >= o[i - 1].z - 1e-9, r.key + ' z monotone at ' + i);
      assert.ok(Number.isFinite(o[i].r) && Number.isFinite(o[i].z));
    }
  }
});

test('pointy bullet (223 Rem.): seating, cylinder, tangent ogive and meplat', () => {
  const g = G.buildGeometry(rec('223_rem'));
  const b = g.bullet;
  assert.equal(b.shape, 'pointy');
  assert.ok(near(b.s, 5.7) && near(b.zb, 44.7 - 5.7) && near(b.Lb, 57.4 - 39));
  assert.ok(near(b.cylEnd, 39 + 0.4 * 18.4));
  assert.ok(near(b.m, 1.27));
  const tip = b.full[b.full.length - 1];
  assert.ok(near(tip.z, 57.4) && near(tip.r, 0));
  assert.ok(has(b.full, 57.4, 0.635, 1e-6), 'meplat edge');
  // tangent ogive: radius of the arc is rho
  const a = 2.85 - 0.635;
  const n = 57.4 - b.cylEnd;
  const rho = (a * a + n * n) / (2 * a);
  const mid = b.nose[Math.floor(b.nose.length / 2)];
  const rc = 2.85 - rho;
  assert.ok(near(Math.hypot(mid.z - b.cylEnd, mid.r - rc), rho, 1e-6));
});

test('rounded, flat and semi-wadcutter bullets', () => {
  const r = G.buildGeometry(rec('9_mm_luger')).bullet; // rounded pistol
  assert.ok(near(r.s, 0.4 * 9.03) && near(r.m, 0.15 * 9.03));
  assert.ok(near(r.cylEnd, r.zb + 0.65 * r.Lb));
  const f = G.buildGeometry(rec('40_s_w')).bullet; // flat pistol
  assert.ok(near(f.s, 0.4 * 10.17) && near(f.m, 0.55 * 10.17));
  assert.ok(near(f.cylEnd, f.zb + 0.7 * f.Lb));
  const w = G.buildGeometry(rec('357_magnum')).bullet; // swc
  assert.ok(near(w.s, 0.6 * 9.12) && near(w.m, 0.6 * 9.12));
  assert.ok(near(w.cylEnd, w.zb + 0.78 * w.Lb));
  const rf = G.buildGeometry(rec('22_win_mag_r_f')).bullet; // rounded rimfire
  assert.ok(near(rf.s, 0.8 * 5.7));
  assert.ok(near(rf.cylEnd, rf.zb + 0.55 * rf.Lb));
});

test('heeled 22 LR: exposed bullet has the case outside diameter, heel the inside diameter', () => {
  const g = G.buildGeometry(rec('22_long_rifle'));
  assert.equal(g.heeled, true);
  const tb = g.walls.tb;
  assert.ok(has(g.bullet.full, g.bullet.zb, 5.72 / 2 - tb));
  assert.ok(has(g.bullet.full, 15.57, 5.72 / 2 - tb));
  assert.ok(has(g.bullet.exposed, 15.57, 5.72 / 2));
  assert.equal(G.buildGeometry(rec('223_rem')).heeled, false);
});

test('outside view hides the seated part', () => {
  const g = G.buildGeometry(rec('223_rem'));
  assert.ok(g.bullet.exposed.every((p) => p.z >= 44.7 - 1e-9));
  assert.ok(near(g.bullet.exposed[0].r, 5.7 / 2));
});

test('walls: tn, tb, solid head w and primer pocket', () => {
  const g = G.buildGeometry(rec('223_rem'));
  assert.ok(near(g.walls.tn, (6.43 - 5.7) / 2));
  assert.ok(near(g.walls.tb, Math.min(Math.max(1.3 * g.walls.tn, 0.6), (0.35 * 9.58) / 2)));
  assert.deepEqual(g.walls.pocket, { d: 4.45, depth: 3.04 });
  assert.ok(near(g.walls.w, Math.max(2.5, 0.25 * 9.58 / 2, 3.04 + 1.5, 3.13 + g.walls.tb)));
  assert.deepEqual(G.buildGeometry(rec('243_win')).walls.pocket, { d: 5.33, depth: 3.3 });
  assert.deepEqual(G.buildGeometry(rec('45_auto')).walls.pocket, { d: 5.33, depth: 3.04 });
  assert.deepEqual(G.buildGeometry(rec('9_mm_luger')).walls.pocket, { d: 4.45, depth: 3.04 });
  assert.deepEqual(G.buildGeometry(rec('338_lapua_mag')).walls.pocket, { d: 5.33, depth: 3.3 });
});

test('inner line follows the walls: tb on the body, tn on the neck, linear on the shoulder', () => {
  const g = G.buildGeometry(rec('223_rem'));
  const { tb, tn } = g.walls;
  const innerAt = (z) => {
    const i = g.inner;
    for (let k = 1; k < i.length; k++) if (z >= i[k - 1].z && z <= i[k].z) {
      const t = (z - i[k - 1].z) / (i[k].z - i[k - 1].z || 1);
      return i[k - 1].r + t * (i[k].r - i[k - 1].r);
    }
    return NaN;
  };
  assert.ok(near(innerAt(20), 9.58 / 2 + (9.0 / 2 - 9.58 / 2) * ((20 - 3.13) / (36.52 - 3.13)) - tb, 0.02));
  assert.ok(near(innerAt(44.0), 6.43 / 2 - tn, 0.03));
  assert.ok(near(g.inner[g.inner.length - 1].r, 6.43 / 2 - tn));
});

test('section polygon is a valid hatched region for every record', () => {
  for (const r of DATA) {
    const g = G.buildGeometry(r);
    assert.ok(g.section.length > 8, r.key);
    for (const p of g.section) assert.ok(Number.isFinite(p.z) && p.r >= -1e-9, r.key);
    for (const p of g.inner) assert.ok(p.r > 0, r.key + ' inner positive');
    // inner never outside the outer
    const outerAt = (z) => {
      let best = -Infinity;
      for (let k = 1; k < g.outer.length; k++) {
        const a = g.outer[k - 1], b = g.outer[k];
        if (z >= a.z - 1e-9 && z <= b.z + 1e-9 && b.z > a.z) best = Math.max(best, a.r + ((z - a.z) / (b.z - a.z)) * (b.r - a.r));
      }
      return best;
    };
    for (const p of g.inner) if (p.z > g.bodyStartZ + 1e-6) assert.ok(p.r < outerAt(p.z) + 1e-6, r.key + ' inner<outer at ' + p.z);
  }
});

test('bullets for every record: tip at L6, radii finite and non-negative, shank fits the neck', () => {
  for (const r of DATA) {
    const g = G.buildGeometry(r);
    const b = g.bullet;
    const tip = b.full[b.full.length - 1];
    assert.ok(near(tip.z, r.cartridge.lengths.L6) && near(tip.r, 0), r.key);
    for (const p of b.full) assert.ok(Number.isFinite(p.z) && p.r >= 0, r.key);
    const mouthInner = g.inner[g.inner.length - 1].r;
    const shank = g.heeled ? r.cartridge.collar.H2 / 2 - g.walls.tb : r.cartridge.projectile.G1 / 2;
    assert.ok(near(mouthInner, shank, 1e-6), r.key + ' bullet fills the neck');
  }
});

test('rule 9: partial shoulder values are reported and the case is drawn straight', () => {
  const r = JSON.parse(JSON.stringify(rec('308_win')));
  delete r.cartridge.lengths.L2;
  const g = G.buildGeometry(r);
  assert.equal(g.bottleneck, false);
  assert.ok(g.notes.some((n) => /shoulder/i.test(n) && /L2/.test(n)), g.notes.join('|'));
  assert.ok(has(g.outer, 51.18, 8.72 / 2));
});

test('rule 9: missing beta and f on a non-rimfire case is reported', () => {
  const r = JSON.parse(JSON.stringify(rec('308_win')));
  delete r.cartridge.caseHead.beta;
  delete r.cartridge.caseHead.f;
  const g = G.buildGeometry(r);
  assert.ok(g.notes.some((n) => /chamfer/i.test(n) && /beta/.test(n) && /\bf\b/.test(n)), g.notes.join('|'));
});

test('rule 9: belted case without groove values reports the belt, missing G1 reports the wall', () => {
  const r = JSON.parse(JSON.stringify(rec('300_win_mag')));
  delete r.cartridge.caseHead.E1;
  delete r.cartridge.projectile.G1;
  const g = G.buildGeometry(r);
  assert.ok(g.notes.some((n) => /belt/i.test(n)), g.notes.join('|'));
  assert.ok(g.notes.some((n) => /wall/i.test(n) && /G1/.test(n)), g.notes.join('|'));
});

test('belt that would end beyond E is not drawn', () => {
  const r = JSON.parse(JSON.stringify(rec('300_win_mag')));
  r.cartridge.caseHead.E = 2.5;
  const g = G.buildGeometry(r);
  for (let i = 1; i < g.outer.length; i++) assert.ok(g.outer[i].z >= g.outer[i - 1].z - 1e-9);
  assert.ok(g.notes.some((n) => /belt/i.test(n)));
});
