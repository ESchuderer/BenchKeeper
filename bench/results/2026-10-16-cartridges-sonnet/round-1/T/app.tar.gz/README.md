# C.I.P. cartridge reference

Static, offline reference of 25 C.I.P. cartridges: searchable list, detail view with a computed true-to-scale 2D drawing (outside view above, section below), value tables and an A4 print layout.

- Open `index.html` directly from disk (Chromium `file://`) or serve the folder with any static file server. No build step, no dependencies, no network requests.
- Detail views live at `index.html#/cartridge/<key>` (for example `#/cartridge/308_win`).
- Data: `js/data.js` (the 25 records as given; OpenBallistics, MIT, commit e83db43).
- Design decisions and acceptance criteria: `SPEC.md`; plan and tasks: `tasks/`.

## Development

```
npm install            # dev dependency: playwright (browser tests only)
npm test               # unit tests, Node 22, no dependencies
npm run test:e2e       # Chromium tests from file:// and http (needs `npx playwright install chromium`)
npm run serve          # optional static server on http://localhost:8080/
```

Source layout: `js/format.js` (formatting, tables, search), `js/geometry.js` (drawing model, rules 1-9), `js/drawing.js` (label layout and SVG), `js/app.js` (router and views), `css/app.css` (screen, dark, print).
