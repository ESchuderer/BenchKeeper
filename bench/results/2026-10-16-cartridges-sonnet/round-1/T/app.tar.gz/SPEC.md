# Spec: C.I.P. Cartridge Reference

Source of truth: the project brief (25 C.I.P. records, rules for list, detail, drawing, print, look and technology). This file records the decisions taken where the brief leaves room, and how each requirement is verified.

## Objective
A static, offline reference database of 25 C.I.P. cartridges for reloaders, gunsmiths and engineers, modelled on the OpenBallistics cartridge database. List with search and family filter; detail view with metadata, a computed true-to-scale 2D drawing, value tables and an A4 print layout.

## Commands
- Run app: open `index.html` from disk, or `npm run serve` (static file server, dev helper only)
- Unit tests: `npm test` (node:test, no dependencies)
- Browser tests: `npm run test:e2e` (Playwright + Chromium, dev dependency only; `file://` and http)
- All: `npm run test:all`

## Project structure
```
index.html            app shell (classic scripts, no modules: works on file://)
css/app.css           screen + print styles, light/dark tokens
js/data.js            the 25 records, verbatim, as CIP_DATA
js/format.js          number/angle/tolerance formatting, symbols, units, table sections, search
js/geometry.js        pure drawing model: profile, bullet, walls, dimensions (no DOM)
js/drawing.js         layout of labels + SVG string rendering
js/app.js             router (hash), list view, detail view, print button
tests/unit/*.test.js  pure-logic tests;  tests/e2e/*.test.js  real-browser tests
tools/serve.js        tiny static server for tests
tasks/plan.md, tasks/todo.md
```
Every browser script is a classic script exposing one global namespace (`CIP.format`, `CIP.geometry`, ...) and `module.exports` under Node, so the same code is unit-tested and runs from `file://`.

## Decisions on open points
1. **Routing**: hash routes (`#/` list, `#/cartridge/<key>`), because only the hash survives reload on `file://`. Unknown key shows a "not found" message with link to the list.
2. **Data as JS**: `fetch` of JSON is blocked on `file://`, so records live in `js/data.js` unmodified (one record per line). A test asserts 25 records and that key set equals the brief.
3. **Numbers** are printed with `String(number)` (`4150`, `51.18`, `25`). Tolerance is printed as `value ±tol` using the sign of the number with ASCII hyphen (`39.62 -0.2`), in the Value cell, never as a row.
4. **Units**: mm default; bar (Pmax, PK, PE), J (EE), g (M), mm² (Q), none (N); angles have the unit `deg` in the Unit column and `°` or `D°M'S"` in the value.
5. **Search** is a case/diacritic-insensitive substring match on name and alternative names. Only when that finds nothing, a fallback treats comma and point as the same decimal mark and ignores spaces (`7.62x51` finds `7,62 x 51`). Count text is literally `<n> cartridges`.
6. **Rim type** (rule 1) is exposed in the drawing model, `data-rim-type`, and `<desc>`.
7. **Straight cases** (no neck) blend the wall linearly from `tb` at the solid head to `tn` at the bullet's seat base, and keep `tn` from there to the mouth, so the seated bullet never intrudes into the wall (a test checks this for all 25). Heeled cases use `tb` at the mouth (the heel diameter is `H2 - 2·tb`).
8. **Dimensioning layout** (all text horizontal, all labels outside the silhouette): length dimensions (R, L1, L2, L3, L6) below, stacked by span; diameter dimensions (R1, E1, P1, P2, H1, H2, G1) run from the outline to the centre line (ISO 129 half-view convention, stated in the figure caption), in columns left and right of the cartridge, labels in free rows above connected by a leader extension; α as an auxiliary included-angle symbol above the shoulder. A greedy collision solver places labels; tests assert no overlaps for all 25 records, in Node and in the rendered page.
9. **Scale**: the drawing is padded so that printed at the full A4 text width (190 mm) its scale is a one-decimal ratio; title block states it (`Scale 1.7:1 (A4 print)`).
10. **Missing values** (rule 9) are listed under the drawing (`.drawing-notes`), one note per feature, e.g. `Body-side shoulder rounding not drawn: r1 min not published.`; nothing is invented. Half-published pairs (β/f, E/E1) and a missing category are reported too.
11. **Phone legibility**: the SVG scales with the width (as required); dimension text is about 7.5-8.5 CSS px on a 360 px phone, readable with pinch-zoom (the vector drawing stays sharp).

## Code style
Plain ES2020, `'use strict'`, small pure functions, 2-space indent, no globals except the `CIP` namespace.
```js
function formatNumber(n) { return String(n); }
```

## Testing strategy
- Unit (small): formatting, tables/tol folding, search, geometry rules 1-9 (rim type, chamfer, groove, belt, shoulder, bullet shapes, heeled, walls, `w`, pocket), label overlap for all 25.
- E2E (browser, from `file://` and http): list, search, family filter, count, link text, detail headings, tables, hash reload, accessible name, print emulation (A4 one page, colours, hidden chrome), console clean, no network requests, mobile width.

## Boundaries
- Always: tests before code, use only the given data, English UI, no network.
- Ask first: new runtime dependency (never expected).
- Never: change/add data, fetch anything, lower a test to pass.

## Success criteria
All brief requirements are met and each is covered by an automated test or a recorded visual check (screenshots light, dark, phone, print PDF).
