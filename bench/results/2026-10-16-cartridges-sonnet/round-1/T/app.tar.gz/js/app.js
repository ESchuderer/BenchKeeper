'use strict';
/* UI: hash router, list view with search and family filter, detail view with drawing and tables. */
(function () {
  const { format, geometry, drawing } = CIP;
  const records = CIP_DATA;
  const app = document.getElementById('app');
  const state = { query: '', family: 'all' };
  const FAMILIES = ['rimless', 'rimmed', 'belted', 'pistol', 'rimfire'];
  const PRIMER_NAMES = { sp: 'small pistol', spm: 'small pistol magnum', sr: 'small rifle', lp: 'large pistol', lpm: 'large pistol magnum', lr: 'large rifle', lrm: 'large rifle magnum' };

  function el(tag, attrs, ...children) {
    const node = document.createElement(tag);
    for (const [k, v] of Object.entries(attrs || {})) {
      if (v === false || v === null || v === undefined) continue;
      if (k === 'class') node.className = v;
      else node.setAttribute(k, v === true ? '' : v);
    }
    for (const c of children.flat()) if (c !== null && c !== undefined && c !== false) node.append(c);
    return node;
  }

  const hrefFor = (record) => `#/cartridge/${record.key}`;

  // ---- list view ----------------------------------------------------------------------------------------------
  function renderList() {
    document.title = 'Cartridges – C.I.P. reference';
    const search = el('input', { id: 'search', type: 'search', name: 'search', autocomplete: 'off', spellcheck: 'false', placeholder: 'Name or alternative name', value: state.query });
    const select = el('select', { id: 'family', name: 'family' },
      el('option', { value: 'all' }, 'All'),
      FAMILIES.map((f) => el('option', { value: f }, f)));
    select.value = state.family;
    const count = el('p', { id: 'count', class: 'count', role: 'status', 'aria-live': 'polite' });
    const body = el('tbody');
    const empty = el('p', { class: 'empty', hidden: true }, 'No cartridge matches the search.');

    const table = el('table', { class: 'cartridge-list' },
      el('caption', { class: 'visually-hidden' }, 'Cartridges'),
      el('thead', {}, el('tr', {},
        el('th', { scope: 'col' }, 'Name'), el('th', { scope: 'col' }, 'Family'), el('th', { scope: 'col', class: 'num' }, 'Case length L3'))),
      body);

    function update() {
      const shown = format.filterCartridges(records, state);
      body.replaceChildren(...shown.map((r) => el('tr', {},
        el('th', { scope: 'row', class: 'name' },
          el('a', { href: hrefFor(r) }, r.name),
          r.alternativeNames ? el('span', { class: 'alt' }, r.alternativeNames.join(', ')) : null),
        el('td', {}, r.family),
        el('td', { class: 'num' }, `${format.formatNumber(r.cartridge.lengths.L3)} mm`))));
      count.textContent = format.formatCount(shown.length);
      empty.hidden = shown.length > 0;
      table.hidden = shown.length === 0;
    }
    search.addEventListener('input', () => { state.query = search.value; update(); });
    select.addEventListener('change', () => { state.family = select.value; update(); });

    app.replaceChildren(
      el('h1', {}, 'Cartridges'),
      el('form', { class: 'filters', role: 'search', 'aria-label': 'Filter cartridges' },
        el('div', { class: 'field' }, el('label', { for: 'search' }, 'Search'), search),
        el('div', { class: 'field' }, el('label', { for: 'family' }, 'Family'), select)),
      count, table, empty);
    app.querySelector('form').addEventListener('submit', (e) => e.preventDefault());
    update();
  }

  // ---- detail view --------------------------------------------------------------------------------------------
  function fact(label, ...value) {
    return [el('dt', {}, label), el('dd', {}, ...value)];
  }

  function capacityNode(capacity) {
    const text = format.formatCapacity(capacity);
    if (!text) return 'not published';
    return [
      text, ' (source: ',
      /^https?:\/\//.test(capacity.url || '') ? el('a', { href: capacity.url, rel: 'noopener noreferrer', target: '_blank' }, capacity.source) : capacity.source,
      ')', capacity.note ? el('span', { class: 'note' }, ` ${capacity.note}`) : null,
    ];
  }

  function valueTable(section) {
    return el('table', { class: 'values' },
      el('caption', {}, section.title),
      el('thead', {}, el('tr', {}, el('th', { scope: 'col' }, 'Symbol'), el('th', { scope: 'col', class: 'num' }, 'Value'), el('th', { scope: 'col' }, 'Unit'))),
      el('tbody', {}, section.rows.map((row) => el('tr', {},
        el('th', { scope: 'row' }, row.symbol),
        el('td', { class: 'num' }, row.value, row.tol ? el('span', { class: 'tol' }, ` ${row.tol}`) : null),
        el('td', { class: 'unit' }, row.unit)))));
  }

  function renderDetail(record) {
    document.title = `${record.name} – C.I.P. cartridge reference`;
    const a = record.annotations || {};
    const model = geometry.buildModel(record);
    const sections = format.buildSections(record);
    const figure = el('figure', { class: 'drawing' });
    figure.innerHTML = drawing.renderSvg(model);
    const notes = drawing.describeMissing(model);
    figure.append(el('figcaption', { class: 'drawing-legend' }, 'Upper half: outside view. Lower half: section. Diameters are dimensioned from the outline to the centre line.'));
    if (notes.length) figure.append(el('figcaption', { class: 'drawing-notes' }, notes.map((n) => el('span', {}, n))));

    const printButton = el('button', { type: 'button', class: 'print-button' }, 'Print');
    printButton.addEventListener('click', () => window.print());

    app.replaceChildren(el('article', { class: 'detail' },
      el('nav', { class: 'detail-nav', 'aria-label': 'Cartridge navigation' },
        el('a', { href: '#/' }, 'All cartridges'), printButton),
      el('h1', {}, record.name),
      el('dl', { class: 'facts' },
        record.alternativeNames ? fact('Alternative names', record.alternativeNames.join(', ')) : null,
        fact('Family', record.family),
        fact('Category', a.category),
        fact('Primer type', PRIMER_NAMES[a.primerType] ? el('abbr', { title: PRIMER_NAMES[a.primerType] }, a.primerType) : a.primerType),
        fact('C.I.P. table', record.tab),
        fact('Country', record.country),
        fact('Published', record.published),
        fact('Revised', record.revised),
        fact('Pressure method', record.pressureMethod),
        fact('Water capacity', capacityNode(a.publishedCapacity))),
      figure,
      el('section', { class: 'value-part', 'aria-labelledby': 'h-cartridge' },
        el('h2', { id: 'h-cartridge' }, 'Cartridge values'),
        el('div', { class: 'value-groups' }, sections.cartridge.map(valueTable))),
      el('section', { class: 'value-part', 'aria-labelledby': 'h-chamber' },
        el('h2', { id: 'h-chamber' }, 'Chamber values'),
        el('div', { class: 'value-groups' }, sections.chamber.map(valueTable))),
      el('p', { class: 'source' }, `Source: C.I.P. TDCC, revised ${record.revised}`)));
  }

  function renderNotFound() {
    document.title = 'Not found – C.I.P. cartridge reference';
    app.replaceChildren(el('h1', {}, 'Cartridge not found'), el('p', {}, 'No cartridge has this address. ', el('a', { href: '#/' }, 'All cartridges')));
  }

  // ---- router -------------------------------------------------------------------------------------------------
  function keyFromHash(hash) {
    const match = /^#\/cartridge\/([^/?#]+)\/?$/.exec(hash);
    if (!match) return null;
    try { return decodeURIComponent(match[1]); } catch { return ''; }
  }

  let current = { kind: null, listScroll: 0 };
  function onRoute() {
    const key = keyFromHash(location.hash);
    const leavingList = current.kind === 'list';
    if (leavingList) current.listScroll = window.scrollY;
    if (key === null) {
      renderList();
      window.scrollTo(0, current.kind === 'detail' ? current.listScroll : 0);
      current.kind = 'list';
    } else {
      const record = records.find((r) => r.key === key);
      if (record) renderDetail(record); else renderNotFound();
      window.scrollTo(0, 0);
      current.kind = 'detail';
    }
    const heading = app.querySelector('h1');
    if (current.firstDone && heading) { heading.tabIndex = -1; heading.focus({ preventScroll: true }); }
    current.firstDone = true;
  }
  window.addEventListener('hashchange', onRoute);
  onRoute();
})();
