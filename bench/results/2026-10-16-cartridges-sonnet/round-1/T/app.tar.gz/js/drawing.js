'use strict';
/*
 * Drawing layout and SVG rendering. 1 SVG user unit = 1 mm; x = z (head on the left), y = radius (upper half
 * outside view: y = -r, lower half section: y = +r). All text is horizontal and every label is placed outside the
 * silhouette; labels are placed by a small greedy collision solver. No DOM needed: the SVG is built as a string.
 */
(function (root) {
  const CIP = (root.CIP = root.CIP || {});

  const PRINT_WIDTH_MM = 190; // A4 portrait text width (10 mm margins)
  const CHAR_WIDTH = 0.62; // average glyph width / font size, deliberately generous

  const fmt = (n) => String(Math.round(n * 1000) / 1000);
  const esc = (s) => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');

  function scaleText(scale) {
    if (scale >= 1) return `${fmt(scale)}:1`;
    return `1:${fmt(Math.round((1 / scale) * 10) / 10)}`;
  }

  const overlaps = (a, b) => a.x0 < b.x1 && b.x0 < a.x1 && a.y0 < b.y1 && b.y0 < a.y1;
  const inflate = (b, p) => ({ x0: b.x0 - p, x1: b.x1 + p, y0: b.y0 - p, y1: b.y1 + p });
  const verticalHitsBox = (seg, box) => seg.x > box.x0 && seg.x < box.x1 && seg.yTop < box.y1 && seg.yBottom > box.y0;

  function textBox(text, f, x, baseline, anchor) {
    const w = text.length * CHAR_WIDTH * f;
    const x0 = anchor === 'start' ? x : anchor === 'end' ? x - w : x - w / 2;
    return { x0, x1: x0 + w, y0: baseline - 0.8 * f, y1: baseline + 0.22 * f };
  }

  class Bounds {
    constructor() { this.x0 = Infinity; this.y0 = Infinity; this.x1 = -Infinity; this.y1 = -Infinity; }
    point(x, y) { this.x0 = Math.min(this.x0, x); this.x1 = Math.max(this.x1, x); this.y0 = Math.min(this.y0, y); this.y1 = Math.max(this.y1, y); }
    box(b) { this.point(b.x0, b.y0); this.point(b.x1, b.y1); }
  }

  function buildLayout(model) {
    const v = model.values;
    const maxZ = model.extent.maxZ;
    const f = Math.max(1.7, 0.04 * maxZ);
    const arrowLen = 0.8 * f;
    const arrowWid = 0.3 * f;
    const gap = 0.3 * f;
    const bullet = model.bullet;
    const maxR = Math.max(model.extent.maxR, bullet ? bullet.rExposed : 0);

    const lines = [];
    const arrows = [];
    const labels = [];
    const bounds = new Bounds();
    const silhouette = { x0: 0, x1: maxZ, y0: -maxR, y1: maxR };
    bounds.box(silhouette);
    bounds.point(-1.5 * f, 0);
    bounds.point(maxZ + 1.5 * f, 0);

    const addLine = (symbol, cls, x1, y1, x2, y2) => {
      lines.push({ symbol, cls, x1, y1, x2, y2 });
      bounds.point(x1, y1); bounds.point(x2, y2);
    };
    const addArrow = (symbol, x, y, dx, dy, len = arrowLen) => {
      arrows.push({ symbol, x, y, dx, dy, len, wid: arrowWid });
      bounds.point(x - dx * len, y - dy * len);
    };
    const addLabel = (symbol, text, x, baseline, anchor, extra) => {
      const box = textBox(text, f, x, baseline, anchor);
      const label = Object.assign({ symbol, text, x, y: baseline, anchor, box }, extra);
      labels.push(label);
      bounds.box(box);
      return label;
    };

    // ---- length dimensions below the section, stacked by span --------------------------------------------
    const lengthDims = model.dimensions.filter((d) => d.kind === 'length').sort((a, b) => (a.z1 - a.z0) - (b.z1 - b.z0));
    let rowY = maxR + 1.4 * f;
    for (const d of lengthDims) {
      const text = `${d.label} ${d.valueText}`;
      const span = d.z1 - d.z0;
      const w = text.length * CHAR_WIDTH * f;
      const inside = span >= 2.4 * arrowLen && span >= w + 2 * arrowLen + 0.8 * f;
      addLine(d.symbol, 'ext', d.z0, maxR + gap, d.z0, rowY + 0.5 * f);
      addLine(d.symbol, 'ext', d.z1, d.featureR + gap, d.z1, rowY + 0.5 * f);
      if (inside) {
        addLine(d.symbol, 'dim', d.z0, rowY, d.z1, rowY);
        addArrow(d.symbol, d.z0, rowY, -1, 0);
        addArrow(d.symbol, d.z1, rowY, 1, 0);
        addLabel(d.symbol, text, (d.z0 + d.z1) / 2, rowY - 0.3 * f, 'middle', { kind: 'length' });
      } else {
        addLine(d.symbol, 'dim', d.z0 - arrowLen - 0.4 * f, rowY, d.z1 + arrowLen + 0.4 * f, rowY);
        addArrow(d.symbol, d.z0, rowY, 1, 0, arrowLen);
        addArrow(d.symbol, d.z1, rowY, -1, 0, arrowLen);
        addLabel(d.symbol, text, d.z1 + arrowLen + 0.7 * f, rowY - 0.3 * f, 'start', { kind: 'length' });
      }
      rowY += 2.1 * f;
    }
    const rowsBottom = rowY - 2.1 * f;

    // ---- diameter dimensions and the angle: columns beside the cartridge, labels in free rows above ---------
    const diameters = model.dimensions.filter((d) => d.kind === 'diameter');
    const right = diameters.filter((d) => d.side === 'right').sort((a, b) => a.r - b.r);
    const left = diameters.filter((d) => d.side === 'left');
    const inline = diameters.filter((d) => d.side === 'inline');
    const items = [];
    const columnStart = maxZ + 1.9 * f;
    right.forEach((d, i) => items.push({ d, x: columnStart + i * 1.4 * f, anchor: 'end', extStartX: d.z + gap }));
    left.forEach((d, i) => items.push({ d, x: -1.9 * f - i * 1.4 * f, anchor: 'start', extStartX: -gap }));
    inline.forEach((d) => items.push({ d, x: d.z, anchor: 'start', extStartX: null }));

    const angle = model.dimensions.find((d) => d.kind === 'angle');
    if (angle) {
      items.push({ d: angle, x: angle.at[1], anchor: 'start', angle: true });
    }
    // start-anchored items: right to left (leftmost label ends up highest); end-anchored: left to right
    items.sort((a, b) => (a.anchor === b.anchor ? (a.anchor === 'start' ? b.x - a.x : a.x - b.x) : a.anchor === 'start' ? -1 : 1));

    const placed = [];
    const clear = (box, leader) => placed.every((p) =>
      !overlaps(box, p.box) && !(p.leader && verticalHitsBox(p.leader, box)) && !(leader && verticalHitsBox(leader, p.box)));

    for (const it of items) {
      const d = it.d;
      const text = `${d.label} ${d.valueText}`;
      let makeBox;
      let leaderBottom;
      if (it.angle) {
        const half = (d.degrees / 2) * (Math.PI / 180);
        const leg = 3.4 * f;
        const legUp = Math.max(leg * Math.sin(half), 0.9 * f);
        const textW = text.length * CHAR_WIDTH * f;
        makeBox = (yc) => ({
          x0: it.x - leg * Math.cos(half) - 0.3 * f, x1: it.x + 0.6 * f + textW,
          y0: yc - legUp - 0.3 * f, y1: yc + legUp + 0.3 * f,
        });
        leaderBottom = -d.at[0];
        it.leg = leg; it.half = half;
      } else {
        const baseOffset = 0.3 * f;
        makeBox = (yc) => {
          const x = it.anchor === 'end' ? it.x - 0.5 * f : it.x + 0.5 * f;
          return textBox(text, f, x, yc + baseOffset, it.anchor);
        };
        leaderBottom = -d.r;
      }
      const box0 = makeBox(0);
      let yc = -maxR - 0.8 * f - box0.y1;
      let box;
      for (let guard = 0; guard < 400; guard++, yc -= 0.4 * f) {
        box = inflate(makeBox(yc), 0.12 * f);
        const leader = { x: it.x, yTop: yc, yBottom: leaderBottom };
        if (clear(box, leader)) { placed.push({ box, leader }); break; }
      }
      it.yc = yc;
      it.box = makeBox(yc);
      bounds.box(it.box);
    }

    for (const it of items) {
      const d = it.d;
      if (it.angle) {
        const [rMid, zMid] = d.at;
        addLine('alpha', 'ext', zMid, -rMid - gap, zMid, it.yc);
        const dx = Math.cos(it.half), dy = Math.sin(it.half);
        const leg = it.leg;
        addLine('alpha', 'dim', zMid, it.yc, zMid - leg * dx, it.yc - leg * dy);
        addLine('alpha', 'dim', zMid, it.yc, zMid - leg * dx, it.yc + leg * dy);
        const arcR = 0.7 * leg;
        arrows.push({ symbol: 'alpha', x: zMid - arcR * dx, y: it.yc - arcR * dy, dx: dy, dy: -dx, len: arrowLen * 0.8, wid: arrowWid, arc: true });
        arrows.push({ symbol: 'alpha', x: zMid - arcR * dx, y: it.yc + arcR * dy, dx: dy, dy: dx, len: arrowLen * 0.8, wid: arrowWid, arc: true });
        lines.push({ symbol: 'alpha', cls: 'arc', arc: { cx: zMid, cy: it.yc, r: arcR, half: it.half } });
        labels.push({ symbol: 'alpha', text: `${d.label} ${d.valueText}`, x: zMid + 0.6 * f, y: it.yc + 0.3 * f, anchor: 'start', box: textBox(`${d.label} ${d.valueText}`, f, zMid + 0.6 * f, it.yc + 0.3 * f, 'start') });
        continue;
      }
      const x = it.x;
      if (it.extStartX !== null) addLine(d.symbol, 'ext', it.extStartX, -d.r, x + 0.4 * f, -d.r);
      addLine(d.symbol, 'ext', x, -d.r, x, it.yc);
      addLine(d.symbol, 'dim', x, -d.r, x, 0);
      const len = Math.min(arrowLen, 0.4 * d.r);
      addArrow(d.symbol, x, -d.r, 0, -1, len);
      addArrow(d.symbol, x, 0, 0, 1, len);
      const lx = it.anchor === 'end' ? x - 0.5 * f : x + 0.5 * f;
      const text = `${d.label} ${d.valueText}`;
      labels.push({ symbol: d.symbol, text, x: lx, y: it.yc + 0.3 * f, anchor: it.anchor, box: textBox(text, f, lx, it.yc + 0.3 * f, it.anchor) });
    }

    // ---- title block -------------------------------------------------------------------------------------------
    const contentBottom = Math.max(rowsBottom + 0.8 * f, maxR + 1 * f);
    const pad = 1.2 * f;
    const nameSize = 1.25 * f;
    const tabLine = `C.I.P. table ${model.tab}, revised ${model.revised}`;
    const unitLine = 'Dimensions in mm';
    const leftW = Math.max(model.name.length * CHAR_WIDTH * nameSize, tabLine.length * CHAR_WIDTH * f);
    const scaleReserve = 'Scale 00.0:1 (A4 print)'.length * CHAR_WIDTH * f;
    const titleMinW = leftW + scaleReserve + 3 * f;

    let contentW = bounds.x1 - bounds.x0;
    if (titleMinW > contentW) { bounds.x1 = bounds.x0 + titleMinW; contentW = titleMinW; }
    const titleY = contentBottom + 0.6 * f;
    const titleH = 3.5 * f;
    const titleX = bounds.x0;
    bounds.point(titleX, titleY + titleH);
    bounds.point(titleX + contentW, titleY + titleH);

    // ---- view box and scale ----------------------------------------------------------------------------------
    const vbX0 = bounds.x0 - pad;
    const naturalW = bounds.x1 - bounds.x0 + 2 * pad;
    const scale = Math.max(0.1, Math.floor((PRINT_WIDTH_MM / naturalW) * 10 + 1e-9) / 10);
    const vbW = PRINT_WIDTH_MM / scale;
    const extra = vbW - naturalW;
    const viewBox = { x: vbX0 - extra / 2, y: bounds.y0 - pad, w: vbW, h: bounds.y1 - bounds.y0 + 2 * pad };
    const titleBlock = {
      x: titleX, y: titleY, w: contentW, h: titleH, nameSize, name: model.name, tabLine, unitLine,
      scaleLine: `Scale ${scaleText(scale)} (A4 print)`,
    };
    return { f, scale, viewBox, silhouette, lines, arrows, labels, titleBlock, maxR, maxZ };
  }

  // ---- notes for missing values (rule 9) ------------------------------------------------------------------
  function describeMissing(model) {
    return model.missing.map((m) => `${m.feature} not drawn: ${m.values.join(', ')} not published.`);
  }

  // ---- SVG rendering --------------------------------------------------------------------------------------
  const pathOf = (pts, sign) => pts.map((p, i) => `${i ? 'L' : 'M'}${fmt(p[1])} ${fmt(sign * p[0])}`).join('');

  function arrowPath(a) {
    const bx = a.x - a.dx * a.len, by = a.y - a.dy * a.len;
    const px = -a.dy * (a.wid / 2), py = a.dx * (a.wid / 2);
    return `M${fmt(a.x)} ${fmt(a.y)}L${fmt(bx + px)} ${fmt(by + py)}L${fmt(bx - px)} ${fmt(by - py)}Z`;
  }

  function renderSvg(model) {
    const label = `${model.name} drawing`;
    if (!model.outer) {
      return `<svg viewBox="0 0 100 20" role="img" aria-label="${esc(label)}"><title>${esc(label)}</title><text x="2" y="12" font-size="4">Drawing not available</text></svg>`;
    }
    const l = buildLayout(model);
    const { f, viewBox: vb } = l;
    const spacing = 0.4 * f;
    const patternId = `hatch-${esc(String(model.key))}`;
    const out = [];
    out.push(`<svg viewBox="${fmt(vb.x)} ${fmt(vb.y)} ${fmt(vb.w)} ${fmt(vb.h)}" preserveAspectRatio="xMidYMid meet" role="img" aria-label="${esc(label)}" data-rim-type="${esc(model.rimType)}" data-scale="${l.scale}" class="cartridge-drawing">`);
    out.push(`<title>${esc(label)}</title>`);
    out.push(`<desc>${esc(`Rim type ${model.rimType}. Upper half outside view, lower half section. Dimensions in mm. Scale ${scaleText(l.scale)} when printed at full A4 width.`)}</desc>`);
    out.push(`<defs><pattern id="${patternId}" patternUnits="userSpaceOnUse" width="${fmt(spacing)}" height="${fmt(spacing)}" patternTransform="rotate(45)"><line x1="0" y1="0" x2="0" y2="${fmt(spacing)}" class="hatch-line" stroke-width="${fmt(spacing * 0.16)}"/></pattern></defs>`);

    // upper half: outside view
    const outside = model.outer.slice();
    const upper = outside.concat(model.bullet ? model.bullet.outline : []);
    const mouthR = model.values.H2 / 2;
    if (model.bullet && model.bullet.rExposed < mouthR) upper.splice(outside.length, 0, [model.bullet.rExposed, model.values.L3]);
    const tipZ = model.bullet ? model.values.L6 : model.values.L3;
    out.push(`<g class="outside" data-view="outside"><path class="outline case-outline" d="${pathOf(upper, -1)}L${fmt(tipZ)} 0" fill="var(--draw-paper)"/></g>`);

    // lower half: section
    out.push('<g class="section" data-view="section">');
    if (model.walls) {
      out.push(`<path class="outline cut-walls" d="${pathOf(model.walls.polygon, 1)}Z" fill="url(#${patternId})" fill-rule="evenodd"/>`);
    } else {
      out.push(`<path class="outline" d="${pathOf(model.outer, 1)}L${fmt(model.values.L3)} 0Z" fill="none"/>`);
    }
    if (model.bullet) out.push(`<path class="outline bullet-section" d="${pathOf(model.bullet.section, 1)}Z"/>`);
    out.push('</g>');

    out.push(`<line class="centerline" x1="${fmt(-1.5 * f)}" y1="0" x2="${fmt(l.maxZ + 1.5 * f)}" y2="0" stroke-dasharray="${fmt(2.4 * f)} ${fmt(0.5 * f)} ${fmt(0.4 * f)} ${fmt(0.5 * f)}"/>`);

    // dimensions
    const symbols = [...new Set(l.labels.map((x) => x.symbol))];
    for (const s of symbols) {
      out.push(`<g class="dimension" data-symbol="${esc(s)}">`);
      for (const ln of l.lines.filter((x) => x.symbol === s)) {
        if (ln.arc) {
          const a = ln.arc;
          const x1 = a.cx - a.r * Math.cos(a.half), y1 = a.cy - a.r * Math.sin(a.half);
          const x2 = a.cx - a.r * Math.cos(a.half), y2 = a.cy + a.r * Math.sin(a.half);
          out.push(`<path class="dim arc" d="M${fmt(x1)} ${fmt(y1)}A${fmt(a.r)} ${fmt(a.r)} 0 0 0 ${fmt(x2)} ${fmt(y2)}" fill="none"/>`);
        } else {
          out.push(`<line class="${ln.cls}" x1="${fmt(ln.x1)}" y1="${fmt(ln.y1)}" x2="${fmt(ln.x2)}" y2="${fmt(ln.y2)}"/>`);
        }
      }
      for (const a of l.arrows.filter((x) => x.symbol === s)) out.push(`<path class="arrow" d="${arrowPath(a)}"/>`);
      for (const lab of l.labels.filter((x) => x.symbol === s)) {
        out.push(`<text class="dim-label" data-symbol="${esc(s)}" x="${fmt(lab.x)}" y="${fmt(lab.y)}" font-size="${fmt(f)}" text-anchor="${lab.anchor}">${esc(lab.text)}</text>`);
      }
      out.push('</g>');
    }

    // title block
    const t = l.titleBlock;
    const mid = t.x + t.w - Math.max(t.scaleLine.length * CHAR_WIDTH * f, t.unitLine.length * CHAR_WIDTH * f) - 1.2 * f;
    out.push('<g class="title-block">');
    out.push(`<rect class="frame" x="${fmt(t.x)}" y="${fmt(t.y)}" width="${fmt(t.w)}" height="${fmt(t.h)}" fill="none"/>`);
    out.push(`<line class="frame" x1="${fmt(mid)}" y1="${fmt(t.y)}" x2="${fmt(mid)}" y2="${fmt(t.y + t.h)}"/>`);
    out.push(`<text class="title-name" x="${fmt(t.x + 0.8 * f)}" y="${fmt(t.y + 1.45 * f)}" font-size="${fmt(t.nameSize)}">${esc(t.name)}</text>`);
    out.push(`<text class="title-text" x="${fmt(t.x + 0.8 * f)}" y="${fmt(t.y + 2.85 * f)}" font-size="${fmt(f)}">${esc(t.tabLine)}</text>`);
    out.push(`<text class="title-text" x="${fmt(mid + 0.8 * f)}" y="${fmt(t.y + 1.45 * f)}" font-size="${fmt(f)}">${esc(t.unitLine)}</text>`);
    out.push(`<text class="title-text" x="${fmt(mid + 0.8 * f)}" y="${fmt(t.y + 2.85 * f)}" font-size="${fmt(f)}">${esc(t.scaleLine)}</text>`);
    out.push('</g>');
    out.push('</svg>');
    return out.join('');
  }

  CIP.drawing = { buildLayout, renderSvg, describeMissing, scaleText };
  if (typeof module !== 'undefined') module.exports = CIP.drawing;
})(globalThis);
