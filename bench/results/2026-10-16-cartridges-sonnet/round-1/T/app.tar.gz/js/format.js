'use strict';
/* Formatting, table model and search. Pure functions, no DOM. */
(function (root) {
  const CIP = (root.CIP = root.CIP || {});

  const SYMBOLS = {
    eMin: 'e min', r1Min: 'r1 min', r1Max: 'r1 max', alpha: 'α', alpha1: 'α1', beta: 'β', delta: 'δ',
    deltaL: 'delta L', L3PlusG: 'L3 + G',
  };
  const ANGLES = new Set(['alpha', 'alpha1', 'beta', 'delta', 'i']);
  const UNITS = { Pmax: 'bar', PK: 'bar', PE: 'bar', EE: 'J', M: 'g', Q: 'mm²', N: '' };
  const SECTION_TITLES = {
    caseHead: 'Case head', collar: 'Collar', junctionCone: 'Junction cone', lengths: 'Lengths',
    misc: 'Miscellaneous', powderChamber: 'Powder chamber', pressures: 'Pressures', projectile: 'Projectile',
    barrel: 'Barrel', breech: 'Breech', grooves: 'Grooves', rifling: 'Rifling',
  };

  const formatNumber = (n) => String(n);
  const isTolField = (field) => /Tol$/.test(field);
  const symbolOf = (field) => SYMBOLS[field] || field;
  const isAngleField = (field) => ANGLES.has(field);
  const unitOf = (field) => (isAngleField(field) ? 'deg' : field in UNITS ? UNITS[field] : 'mm');

  function formatAngle(angle) {
    if (typeof angle === 'number') return formatNumber(angle) + '°';
    return `${formatNumber(angle.degrees)}°${formatNumber(angle.minutes)}'${formatNumber(angle.seconds)}"`;
  }

  const formatTolerance = (tol) => (tol > 0 ? '+' : '') + formatNumber(tol);

  function formatValue(field, value) {
    return isAngleField(field) ? formatAngle(value) : formatNumber(value);
  }

  function buildRows(section) {
    return Object.keys(section)
      .filter((field) => !isTolField(field))
      .map((field) => {
        const value = formatValue(field, section[field]);
        const tolRaw = section[field + 'Tol'];
        const tol = tolRaw === undefined ? null : formatTolerance(tolRaw);
        return { field, symbol: symbolOf(field), value, tol, text: tol ? `${value} ${tol}` : value, unit: unitOf(field) };
      });
  }

  function buildSections(record) {
    const build = (part) =>
      Object.keys(part)
        .map((id) => ({ id, title: SECTION_TITLES[id] || id, rows: buildRows(part[id]) }))
        .filter((section) => section.rows.length > 0);
    return { cartridge: build(record.cartridge), chamber: build(record.chamber) };
  }

  function formatCapacity(capacity) {
    return capacity && typeof capacity.grH2O === 'number' ? `${formatNumber(capacity.grH2O)} gr H2O` : null;
  }

  const formatCount = (n) => `${n} cartridges`;

  const fold = (text) => text.normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().replace(/\s+/g, ' ').trim();
  // Fallback form: comma and point are interchangeable (decimal marks), spaces are ignored.
  const compact = (text) => fold(text).replace(/,/g, '.').replace(/ /g, '');

  const namesOf = (record) => [record.name, ...(record.alternativeNames || [])];
  const matchesLiteral = (record, query) => namesOf(record).some((name) => fold(name).includes(fold(query)));
  const matchesCompact = (record, query) => namesOf(record).some((name) => compact(name).includes(compact(query)));

  // Literal match first; only when it finds nothing, ignore punctuation and spacing ("7.62x51" finds "7,62 x 51").
  function filterCartridges(records, { query = '', family = 'all' } = {}) {
    const inFamily = records.filter((r) => family === 'all' || r.family === family);
    if (!fold(query)) return inFamily;
    const literal = inFamily.filter((r) => matchesLiteral(r, query));
    if (literal.length > 0 || !compact(query)) return literal;
    return inFamily.filter((r) => matchesCompact(r, query));
  }

  CIP.format = {
    formatNumber, formatAngle, formatTolerance, formatValue, formatCapacity, formatCount,
    symbolOf, unitOf, isAngleField, buildSections, filterCartridges,
  };
  if (typeof module !== 'undefined') module.exports = CIP.format;
})(globalThis);
