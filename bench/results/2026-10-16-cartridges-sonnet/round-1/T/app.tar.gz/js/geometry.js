'use strict';
/*
 * Drawing model: pure geometry from one cartridge record, following the brief's rules 1-9.
 * Coordinates are [r, z]: r = radius (half the diameter), z = distance from the head face along the axis, in mm.
 * The model never invents a number: a missing input removes the feature and is reported in `missing`.
 */
(function (root) {
  const CIP = (root.CIP = root.CIP || {});
  const { formatValue, symbolOf } = CIP.format || (typeof require !== 'undefined' ? require('./format.js') : {});

  const RAD = Math.PI / 180;
  const has = (x) => typeof x === 'number' && Number.isFinite(x);
  const toDegrees = (a) => (typeof a === 'number' ? a : a.degrees + a.minutes / 60 + a.seconds / 3600);
  const samePoint = (a, b) => Math.abs(a[0] - b[0]) < 1e-12 && Math.abs(a[1] - b[1]) < 1e-12;

  const ARC_STEPS = 10;
  const NOSE_STEPS = 32;

  // ---- rule 1 ---------------------------------------------------------------------------------------------
  function rimTypeOf(record, { R1, P1 }) {
    if (record.family === 'belted') return 'belted';
    if (record.family === 'rimfire') return 'rimfire';
    const ratio = R1 / P1;
    if (ratio >= 1.05) return 'rimmed';
    if (ratio < 0.98) return 'rebated';
    return 'rimless';
  }

  // ---- rule 8 helpers -------------------------------------------------------------------------------------
  const bodyWall = (tn, P1) => Math.min(Math.max(1.3 * tn, 0.6), (0.35 * P1) / 2);

  function pocketFor(primerType) {
    const diameter = { sp: 4.45, spm: 4.45, sr: 4.45, lp: 5.33, lpm: 5.33, lr: 5.33, lrm: 5.33 }[primerType];
    const depth = { sp: 3.04, spm: 3.04, sr: 3.04, lp: 3.04, lpm: 3.04, lr: 3.3, lrm: 3.3 }[primerType];
    return diameter === undefined ? null : { diameter, depth };
  }

  function headLength({ P1, pocketDepth = 0, E, beltRampEnd, tb }) {
    const candidates = [2.5, 0.25 * (P1 / 2), pocketDepth + 1.5];
    if (has(beltRampEnd)) candidates.push(beltRampEnd + tb);
    else if (has(E)) candidates.push(E + tb);
    return Math.max(...candidates);
  }

  // ---- outline helpers ------------------------------------------------------------------------------------
  function pushPoint(points, p) {
    if (!points.length || !samePoint(points[points.length - 1], p)) points.push(p);
  }

  // Tangent arc (fillet) of radius rho at corner b between segments a-b and b-c. Returns arc points, or null.
  function fillet(a, b, c, rho, maxTangent) {
    const unit = (p, q) => {
      const l = Math.hypot(q[0] - p[0], q[1] - p[1]);
      return [(q[0] - p[0]) / l, (q[1] - p[1]) / l];
    };
    const u1 = unit(a, b);
    const u2 = unit(b, c);
    const cross = u1[0] * u2[1] - u1[1] * u2[0];
    const turn = Math.acos(Math.max(-1, Math.min(1, u1[0] * u2[0] + u1[1] * u2[1])));
    if (turn < 1e-6) return null;
    const tangent = Math.min(rho * Math.tan(turn / 2), maxTangent);
    const radius = tangent / Math.tan(turn / 2);
    const p1 = [b[0] - u1[0] * tangent, b[1] - u1[1] * tangent];
    const side = cross > 0 ? 1 : -1;
    const center = [p1[0] - u1[1] * radius * side, p1[1] + u1[0] * radius * side];
    const a1 = Math.atan2(p1[1] - center[1], p1[0] - center[0]);
    const pts = [];
    for (let i = 0; i <= ARC_STEPS; i++) {
      const t = a1 + side * turn * (i / ARC_STEPS);
      pts.push([center[0] + radius * Math.cos(t), center[1] + radius * Math.sin(t)]);
    }
    return { points: pts, tangent, radius };
  }

  // ---- rules 2 and 3: head face, rim, extractor groove, belt ------------------------------------------------
  function headProfile(v, rimType, missing) {
    const pts = [[0, 0]];
    const rimR = v.R1 / 2;
    let beltRampEnd;

    if (rimType === 'rimfire') {
      const rho = Math.min(v.R / 2, (v.R1 - v.P1) / 2);
      const rc = rimR - rho;
      const zc = v.R / 2;
      pushPoint(pts, [rc, 0]);
      const steps = ARC_STEPS * 2;
      for (let i = 0; i <= steps; i++) {
        const t = -Math.PI / 2 + (Math.PI * i) / steps;
        pushPoint(pts, [rc + rho * Math.cos(t), zc + rho * Math.sin(t)]);
      }
      pushPoint(pts, [rc, v.R]);
    } else {
      const hasChamfer = has(v.beta) && has(v.f) && v.beta < 90;
      if (has(v.beta) !== has(v.f)) missing.push({ feature: 'Head chamfer', values: [has(v.beta) ? 'f' : 'β'] });
      if (hasChamfer) {
        const d = Math.min(v.f * Math.tan(v.beta * RAD), v.R1 / 4);
        pushPoint(pts, [rimR - d, 0]);
        pushPoint(pts, [rimR, v.f]);
      } else {
        pushPoint(pts, [rimR, 0]);
      }
      pushPoint(pts, [rimR, v.R]);
    }

    let bodyStart = v.R;
    if (has(v.E) && has(v.E1)) {
      const floorStart = [v.E1 / 2, v.R];
      pushPoint(pts, floorStart);
      let floorEnd = floorStart;
      if (has(v.eMin)) {
        floorEnd = [v.E1 / 2, v.R + v.eMin];
        pushPoint(pts, floorEnd);
      } else {
        missing.push({ feature: 'Extractor groove floor', values: ['e min'] });
      }
      if (rimType === 'belted' && has(v.R3) && has(v.delta) && v.delta > 0 && v.R3 > v.E1) {
        const rampEnd = [v.R3 / 2, floorEnd[1] + (v.R3 / 2 - v.E1 / 2) / Math.tan(v.delta * RAD)];
        pushPoint(pts, rampEnd);
        beltRampEnd = rampEnd[1];
        pushPoint(pts, [v.R3 / 2, v.E]);
        pushPoint(pts, [v.P1 / 2, v.E]);
      } else {
        if (rimType === 'belted') {
          missing.push({ feature: 'Belt', values: [has(v.R3) ? null : 'R3', has(v.delta) ? null : 'δ'].filter(Boolean) });
        }
        pushPoint(pts, [v.P1 / 2, v.E]);
      }
      bodyStart = v.E;
    } else {
      if (has(v.E) !== has(v.E1)) missing.push({ feature: 'Extractor groove', values: [has(v.E) ? 'E1' : 'E'] });
      if (rimType === 'belted') missing.push({ feature: 'Belt', values: [has(v.E) ? null : 'E', has(v.E1) ? null : 'E1'].filter(Boolean) });
      pushPoint(pts, [v.P1 / 2, v.R]);
    }
    return { points: pts, bodyStart, beltRampEnd };
  }

  // ---- rules 4-6: body, shoulder, neck ----------------------------------------------------------------------
  function bodyProfile(v, bodyStart, missing) {
    const start = [v.P1 / 2, bodyStart];
    const mouth = [v.H2 / 2, v.L3];
    const anyShoulder = [v.alpha, v.L1, v.L2].some(has);
    const needed = { alpha: 'α', L1: 'L1', L2: 'L2', P2: 'P2', H1: 'H1' };
    const absent = Object.keys(needed).filter((k) => !has(v[k])).map((k) => needed[k]);

    if (!anyShoulder || absent.length > 0) {
      if (anyShoulder) missing.push({ feature: 'Shoulder', values: absent });
      return { points: [mouth], shoulder: null };
    }
    const b = [v.P2 / 2, v.L1];
    const n = [v.H1 / 2, v.L2];
    const shoulderLen = Math.hypot(b[0] - n[0], b[1] - n[1]);
    const bodyLen = Math.hypot(b[0] - start[0], b[1] - start[1]);
    const neckLen = Math.hypot(mouth[0] - n[0], mouth[1] - n[1]);
    const rounded = {};
    if (!has(v.r1Min)) missing.push({ feature: 'Body-side shoulder rounding', values: ['r1 min'] });
    if (!has(v.r2)) missing.push({ feature: 'Neck-side shoulder rounding', values: ['r2'] });

    const pts = [];
    const f1 = has(v.r1Min) ? fillet(start, b, n, v.r1Min, 0.45 * Math.min(bodyLen, shoulderLen)) : null;
    const f2 = has(v.r2) ? fillet(b, n, mouth, v.r2, 0.45 * Math.min(shoulderLen, neckLen)) : null;
    if (f1) { f1.points.forEach((p) => pts.push(p)); rounded.r1Min = f1.radius; } else pts.push(b);
    if (f2) { f2.points.forEach((p) => pts.push(p)); rounded.r2 = f2.radius; } else pts.push(n);
    pts.push(mouth);
    return {
      points: pts,
      shoulder: { start: b, end: n, alpha: v.alphaRaw, rounded },
    };
  }

  // ---- rule 7: bullet -------------------------------------------------------------------------------------
  const SEAT = { pointy: () => 1.0, semi_wadcutter: () => 0.6, rounded: (p) => (p ? 0.4 : 0.8), flat: (p) => (p ? 0.4 : 0.8) };
  const CYL = { pointy: () => 0.4, semi_wadcutter: () => 0.78, rounded: (p) => (p ? 0.65 : 0.55), flat: (p) => (p ? 0.7 : 0.6) };

  function bulletModel(v, shape, isPistol, heeled, tb) {
    const G1 = v.G1;
    const seatDepth = SEAT[shape](isPistol) * G1;
    const zb = v.L3 - seatDepth;
    const length = v.L6 - zb;
    const k = CYL[shape](isPistol);
    const zCylinderEnd = zb + k * length;
    const n = v.L6 - zCylinderEnd;
    const rShank = G1 / 2;
    const rExposed = heeled ? v.H2 / 2 : rShank;
    const rSeated = heeled ? (v.H2 - 2 * tb) / 2 : rShank;
    const meplat = { pointy: Math.max(0.08 * G1, 1.27), rounded: 0.15 * G1, flat: 0.55 * G1, semi_wadcutter: 0.6 * G1 }[shape];
    const m2 = meplat / 2;
    const nose = [];
    let ogiveRadius;
    if (shape === 'pointy') {
      const a = rShank - m2;
      ogiveRadius = (a * a + n * n) / (2 * a);
      for (let i = 1; i < NOSE_STEPS; i++) {
        const dz = (n * i) / NOSE_STEPS;
        nose.push([rShank - ogiveRadius + Math.sqrt(ogiveRadius * ogiveRadius - dz * dz), zCylinderEnd + dz]);
      }
    } else if (shape === 'rounded') {
      for (let i = 1; i < NOSE_STEPS; i++) {
        const t = i / NOSE_STEPS;
        nose.push([m2 + (rShank - m2) * Math.sqrt(1 - t * t), zCylinderEnd + n * t]);
      }
    }
    const tip = [m2, v.L6];
    const shankEnd = [rShank, Math.max(zCylinderEnd, v.L3)];
    const outline = [[rExposed, v.L3], shankEnd];
    nose.forEach((p) => { if (p[1] > v.L3) outline.push(p); });
    outline.push(tip);
    const section = [[0, zb], [rSeated, zb], [rSeated, v.L3], [rExposed, v.L3], shankEnd];
    nose.forEach((p) => { if (p[1] > v.L3) section.push(p); });
    section.push(tip, [0, v.L6]);
    return { shape, seatDepth, zb, length, zCylinderEnd, meplat, ogiveRadius, rShank, rExposed, rSeated, outline, section };
  }

  // ---- rule 8: walls, head, section polygon -----------------------------------------------------------------
  function interpolateRadius(points, z) {
    for (let i = 1; i < points.length; i++) {
      const [r0, z0] = points[i - 1];
      const [r1, z1] = points[i];
      if (z1 > z0 && z >= z0 && z <= z1) return r0 + ((r1 - r0) * (z - z0)) / (z1 - z0);
    }
    return points[points.length - 1][0];
  }

  function wallModel(v, outer, bottleneck, heeled, pocket, beltRampEnd, seatBase) {
    const tn = (v.H2 - v.G1) / 2;
    const tb = bodyWall(tn, v.P1);
    const tnEff = heeled ? tb : tn;
    const w = headLength({ P1: v.P1, pocketDepth: pocket ? pocket.depth : 0, E: has(v.E) && has(v.E1) ? v.E : undefined, beltRampEnd, tb });
    const wallAt = bottleneck
      ? (z) => (z <= v.L1 ? tb : z >= v.L2 ? tnEff : tb + ((tnEff - tb) * (z - v.L1)) / (v.L2 - v.L1))
      : (z) => tb + ((tnEff - tb) * Math.min(1, Math.max(0, (z - w) / (seatBase - w))));
    // the wall changes slope at these z; make sure the inner line has a vertex there
    const breaks = [seatBase, ...(bottleneck ? [v.L1, v.L2] : [])].filter((z) => z > w + 1e-9 && z < v.L3 - 1e-9);
    const points = outer.filter(([, z]) => z > w + 1e-12);
    for (const z of breaks) {
      if (points.some((p) => Math.abs(p[1] - z) < 1e-9)) continue;
      const at = points.findIndex((p) => p[1] > z);
      points.splice(at, 0, [interpolateRadius(outer, z), z]);
    }
    const inner = [[interpolateRadius(outer, w) - wallAt(w), w]];
    for (const [r, z] of points) inner.push([Math.max(0, r - wallAt(z)), z]);
    const polygon = [];
    if (pocket) polygon.push([0, pocket.depth], [pocket.diameter / 2, pocket.depth], [pocket.diameter / 2, 0]);
    else polygon.push([0, 0]);
    for (let i = 1; i < outer.length; i++) polygon.push(outer[i]);
    for (let i = inner.length - 1; i >= 0; i--) polygon.push(inner[i]);
    polygon.push([0, w]);
    return { tn, tb, tnEff, w, inner, polygon };
  }

  // ---- model ------------------------------------------------------------------------------------------------
  function buildModel(record) {
    const c = record.cartridge;
    const ch = c.caseHead || {};
    const jc = c.junctionCone || {};
    const v = {
      R: ch.R, R1: ch.R1, R3: ch.R3, E: ch.E, E1: ch.E1, eMin: ch.eMin, f: ch.f,
      beta: ch.beta !== undefined ? toDegrees(ch.beta) : undefined,
      delta: ch.delta !== undefined ? toDegrees(ch.delta) : undefined,
      H1: (c.collar || {}).H1, H2: (c.collar || {}).H2,
      alpha: jc.alpha !== undefined ? toDegrees(jc.alpha) : undefined, alphaRaw: jc.alpha, r1Min: jc.r1Min, r2: jc.r2,
      L1: (c.lengths || {}).L1, L2: (c.lengths || {}).L2, L3: (c.lengths || {}).L3, L6: (c.lengths || {}).L6,
      P1: (c.powderChamber || {}).P1, P2: (c.powderChamber || {}).P2, G1: (c.projectile || {}).G1,
    };
    const missing = [];
    const model = {
      key: record.key, name: record.name, tab: record.tab, revised: record.revised,
      values: v, missing, outer: null, walls: null, bullet: null, pocket: null, shoulder: null,
      bottleneck: false, heeled: false, rimType: null, dimensions: [], extent: null,
      bodyStart: undefined, beltRampEnd: undefined,
    };

    const core = { R1: 'R1', R: 'R', P1: 'P1', L3: 'L3', H2: 'H2' };
    const absentCore = Object.keys(core).filter((k) => !has(v[k]));
    if (absentCore.length) {
      missing.push({ feature: 'Case outline', values: absentCore });
      return model;
    }

    const rimType = rimTypeOf(record, v);
    const head = headProfile(v, rimType, missing);
    const body = bodyProfile(v, head.bodyStart, missing);
    const outer = head.points.slice();
    body.points.forEach((p) => pushPoint(outer, p));

    Object.assign(model, {
      rimType, outer, bodyStart: head.bodyStart, beltRampEnd: head.beltRampEnd,
      shoulder: body.shoulder, bottleneck: body.shoulder !== null,
    });

    // primer pocket
    const primerType = (record.annotations || {}).primerType;
    if (rimType !== 'rimfire') {
      model.pocket = pocketFor(primerType);
      if (!model.pocket) missing.push({ feature: 'Primer pocket', values: ['primer type'] });
    }

    // walls and bullet
    const canWall = has(v.G1);
    if (!canWall) missing.push({ feature: 'Section walls', values: ['G1'] });
    model.heeled = canWall && v.H2 - v.G1 <= 0.015;
    const category = (record.annotations || {}).category;
    const shape = (record.annotations || {}).defaultBulletShape;
    if (canWall) {
      const seatDepth = SEAT[shape] && category ? SEAT[shape](category === 'pistol') * v.G1 : 0;
      model.walls = wallModel(v, outer, model.bottleneck, model.heeled, model.pocket, head.beltRampEnd, v.L3 - seatDepth);
    }
    const bulletMissing = [];
    if (!has(v.L6)) bulletMissing.push('L6');
    if (!has(v.G1)) bulletMissing.push('G1');
    if (!SEAT[shape]) bulletMissing.push('bullet shape');
    if (!category) bulletMissing.push('category');
    if (bulletMissing.length) missing.push({ feature: 'Bullet', values: bulletMissing });
    else model.bullet = bulletModel(v, shape, category === 'pistol', model.heeled, model.walls.tb);

    model.dimensions = buildDimensions(model, v);
    model.extent = {
      maxR: Math.max(...outer.map((p) => p[0])),
      maxZ: Math.max(v.L3, has(v.L6) ? v.L6 : 0),
    };
    return model;
  }

  // ---- dimensions (anchors only; layout lives in drawing.js) ------------------------------------------------
  function buildDimensions(m, v) {
    const dims = [];
    const raw = m.values;
    const text = (field, value) => formatValue(field, value);
    const add = (field, d) => dims.push(Object.assign({ symbol: field, label: symbolOf(field) }, d));
    const tipR = m.bullet ? m.bullet.meplat / 2 : 0;

    add('R', { kind: 'length', z0: 0, z1: v.R, featureR: v.R1 / 2, value: v.R, valueText: text('R', v.R) });
    if (m.bottleneck) {
      add('L1', { kind: 'length', z0: 0, z1: v.L1, featureR: v.P2 / 2, value: v.L1, valueText: text('L1', v.L1) });
      add('L2', { kind: 'length', z0: 0, z1: v.L2, featureR: v.H1 / 2, value: v.L2, valueText: text('L2', v.L2) });
    }
    add('L3', { kind: 'length', z0: 0, z1: v.L3, featureR: v.H2 / 2, value: v.L3, valueText: text('L3', v.L3) });
    if (has(v.L6)) add('L6', { kind: 'length', z0: 0, z1: v.L6, featureR: tipR, value: v.L6, valueText: text('L6', v.L6) });

    add('R1', { kind: 'diameter', side: 'left', r: v.R1 / 2, z: 0, value: v.R1, valueText: text('R1', v.R1) });
    if (has(v.E) && has(v.E1)) {
      add('E1', { kind: 'diameter', side: 'inline', r: v.E1 / 2, z: v.R + (has(v.eMin) ? v.eMin / 2 : 0), value: v.E1, valueText: text('E1', v.E1) });
    }
    add('P1', { kind: 'diameter', side: 'right', r: v.P1 / 2, z: m.bodyStart, value: v.P1, valueText: text('P1', v.P1) });
    if (m.bottleneck) {
      add('P2', { kind: 'diameter', side: 'right', r: v.P2 / 2, z: v.L1, value: v.P2, valueText: text('P2', v.P2) });
      add('H1', { kind: 'diameter', side: 'right', r: v.H1 / 2, z: v.L2, value: v.H1, valueText: text('H1', v.H1) });
    }
    add('H2', { kind: 'diameter', side: 'right', r: v.H2 / 2, z: v.L3, value: v.H2, valueText: text('H2', v.H2) });
    if (has(v.G1)) {
      const zg = m.bullet && m.bullet.zCylinderEnd > v.L3 ? (v.L3 + m.bullet.zCylinderEnd) / 2 : v.L3;
      add('G1', { kind: 'diameter', side: 'right', r: v.G1 / 2, z: zg, value: v.G1, valueText: text('G1', v.G1) });
    }
    if (m.bottleneck) {
      const s = m.shoulder;
      add('alpha', {
        kind: 'angle', value: raw.alpha, degrees: raw.alpha, valueText: formatValue('alpha', s.alpha),
        at: [(s.start[0] + s.end[0]) / 2, (s.start[1] + s.end[1]) / 2],
      });
    }
    return dims;
  }

  CIP.geometry = { buildModel, rimTypeOf, toDegrees, bodyWall, headLength, pocketFor };
  if (typeof module !== 'undefined') module.exports = CIP.geometry;
})(globalThis);
