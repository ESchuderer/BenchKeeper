# Implementation plan

Vertical slices, pure logic first (unit tested in Node), then DOM, then browser verification.

1. Foundation: package.json, data.js (25 records verbatim), data integrity test.
2. format.js: numbers, angles, tolerance, symbols/units, table sections, search/filter.
3. App shell: list view (heading, search, family select, count, links), hash routing, detail skeleton (metadata, tables, buttons).
4. geometry.js: profile (rules 1-6), bullet (7), walls/head/pocket (8), missing values (9), dimension anchors.
5. drawing.js: label solver, SVG render, title block, scale, hatch, accessibility.
6. Print CSS + dark/light + phone.
7. E2E in Chromium (file:// and http), screenshots, PDF check, review.

Risks: label collisions (mitigated by solver + test over all 25), file:// limits (classic scripts, hash routing, data as JS), print one page (verified via PDF page count).
