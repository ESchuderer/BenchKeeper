# Tasks
- [x] T1 data.js + integrity test (Verify: npm test)
- [x] T2 format.js (numbers, angles, tol, symbols, sections, search) with tests
- [x] T3 list view + router + detail metadata/tables (e2e)
- [x] T4 geometry.js rules 1-9 with tests
- [x] T5 drawing.js layout/render + overlap tests for all 25
- [x] T6 CSS: dark/light, phone, print A4 one page
- [x] T7 e2e suite, visual checks, code review pass
