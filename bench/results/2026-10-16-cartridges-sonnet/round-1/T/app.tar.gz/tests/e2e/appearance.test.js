'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { start, open, MODES } = require('./helpers');
require('../unit/load');
const data = globalThis.CIP_DATA;

let ctx;
test.before(async () => { ctx = await start(); });
test.after(async () => { await ctx.stop(); });

const luminance = (rgb) => {
  const [r, g, b] = rgb.match(/\d+(\.\d+)?/g).map(Number);
  return (0.2126 * r + 0.7152 * g + 0.0722 * b) / 255;
};

for (const mode of MODES) {
  test(`[${mode}] light and dark follow the system setting`, async () => {
    const light = await open(ctx, mode, '', { colorScheme: 'light' });
    const dark = await open(ctx, mode, '', { colorScheme: 'dark' });
    const bg = (p) => p.page.evaluate(() => getComputedStyle(document.body).backgroundColor);
    assert.ok(luminance(await bg(light)) > 0.8);
    assert.ok(luminance(await bg(dark)) < 0.2);
    await light.context.close(); await dark.context.close();
  });

  test(`[${mode}] usable on a phone: no horizontal scrolling, drawing fits the width`, async () => {
    const { page, context } = await open(ctx, mode, '', { viewport: { width: 360, height: 740 } });
    const overflow = () => page.evaluate(() => document.documentElement.scrollWidth - window.innerWidth);
    assert.ok((await overflow()) <= 0, 'list');
    for (const key of ['308_win', '9_3_x_74_r', '22_long_rifle']) {
      await page.goto(page.url().split('#')[0] + '#/cartridge/' + key);
      assert.ok((await overflow()) <= 0, key);
      const box = await page.locator('svg.cartridge-drawing').boundingBox();
      assert.ok(box.width <= 360 && box.width > 300, `${key} svg width ${box.width}`);
    }
    await context.close();
  });

  test(`[${mode}] labels of the drawing are not tiny on a phone`, async () => {
    const { page, context } = await open(ctx, mode, '#/cartridge/308_win', { viewport: { width: 360, height: 740 } });
    const px = await page.locator('svg.cartridge-drawing text.dim-label').first().evaluate((t) => t.getBoundingClientRect().height);
    assert.ok(px >= 7, `label height ${px}px`);
    await context.close();
  });

  test(`[${mode}] print: one A4 portrait page for every cartridge, black on white, no chrome`, async () => {
    const { page, context } = await open(ctx, mode, '', { colorScheme: 'dark' });
    for (const r of data) {
      await page.goto(page.url().split('#')[0] + '#/cartridge/' + r.key);
      await page.emulateMedia({ media: 'print', colorScheme: 'dark' });
      const pdf = await page.pdf({ preferCSSPageSize: true, printBackground: true });
      const pages = (pdf.toString('latin1').match(/\/Type\s*\/Page[^s]/g) || []).length;
      assert.equal(pages, 1, `${r.name} prints on ${pages} pages`);
      const styles = await page.evaluate(() => {
        const vis = (s) => { const e = document.querySelector(s); return e ? e.getClientRects().length > 0 : false; };
        return {
          body: getComputedStyle(document.body).backgroundColor, color: getComputedStyle(document.body).color,
          header: vis('.site-header'), nav: vis('.detail-nav'), button: vis('.print-button'), filters: vis('.filters'),
          footer: vis('.source'), siteFooter: vis('.site-footer'), source: document.querySelector('.source').textContent,
          h1: document.querySelector('h1').textContent,
        };
      });
      assert.equal(styles.body, 'rgb(255, 255, 255)');
      assert.equal(styles.color, 'rgb(0, 0, 0)');
      assert.deepEqual([styles.header, styles.nav, styles.button, styles.filters, styles.siteFooter], [false, false, false, false, false]);
      assert.equal(styles.footer, true);
      assert.equal(styles.source, `Source: C.I.P. TDCC, revised ${r.revised}`);
      assert.equal(styles.h1, r.name);
      await page.emulateMedia({ media: 'screen' });
    }
    await context.close();
  });

  test(`[${mode}] print: content ends well above the footer for every cartridge (slack for other fonts)`, async () => {
    const { page, context } = await open(ctx, mode, '', { viewport: { width: 718, height: 1000 } });
    await page.emulateMedia({ media: 'print' });
    for (const r of data) {
      await page.goto(page.url().split('#')[0] + '#/cartridge/' + r.key);
      const bottomMm = await page.evaluate(() => (Math.max(...[...document.querySelectorAll('table.values')].map((t) => t.getBoundingClientRect().bottom)) + scrollY) * 25.4 / 96);
      assert.ok(bottomMm <= 258, `${r.name}: tables end at ${bottomMm.toFixed(0)} mm of 277 mm`);
    }
    await context.close();
  });

  test(`[${mode}] print: the drawing is full width and its labels are legible`, async () => {
    const { page, context } = await open(ctx, mode, '#/cartridge/308_win');
    await page.emulateMedia({ media: 'print' });
    const m = await page.evaluate(() => {
      const svg = document.querySelector('svg.cartridge-drawing');
      const main = document.querySelector('main');
      const mm = (px) => (px * 25.4) / 96;
      const b = svg.getBoundingClientRect();
      const label = [...svg.querySelectorAll('text.dim-label')].map((t) => mm(t.getBoundingClientRect().height));
      return { w: mm(b.width), main: mm(main.getBoundingClientRect().width), minLabelMm: Math.min(...label), colors: [...svg.querySelectorAll('.outline, .dim, .ext, .arrow')].map((e) => getComputedStyle(e).stroke + getComputedStyle(e).fill),
        opacities: [...svg.querySelectorAll('.ext')].map((e) => getComputedStyle(e).strokeOpacity),
        rules: [...document.querySelectorAll('table.values td, h1, h2')].map((e) => getComputedStyle(e).borderTopColor + getComputedStyle(e).borderBottomColor) };
    });
    assert.ok(m.w >= m.main - 0.5, `drawing ${m.w}mm of ${m.main}mm`);
    assert.ok(m.minLabelMm >= 2.2, `label ${m.minLabelMm}mm tall`);
    assert.ok(m.colors.every((c) => !/rgb\((?!0, 0, 0|255, 255, 255)/.test(c.replace(/rgba\(0, 0, 0, 0\)/g, ''))), 'drawing is black and white');
    assert.ok(m.opacities.every((o) => o === '1'), 'extension lines are solid in print');
    assert.ok(m.rules.every((c) => !/rgb\((?!0, 0, 0)/.test(c)), 'rules are black in print');
    await context.close();
  });
}
