'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { start, open, MODES } = require('./helpers');
require('../unit/load');
const data = globalThis.CIP_DATA;

let ctx;
test.before(async () => { ctx = await start(); });
test.after(async () => { await ctx.stop(); });

for (const mode of MODES) {
  test(`[${mode}] detail view shows the metadata`, async () => {
    const { page, problems, context } = await open(ctx, mode, '#/cartridge/308_win');
    const facts = await page.locator('dl.facts').evaluate((dl) => {
      const out = {};
      dl.querySelectorAll('dt').forEach((dt) => { out[dt.textContent] = dt.nextElementSibling.textContent; });
      return out;
    });
    assert.equal(facts['Alternative names'], '308 Winchester, 7,62 x 51');
    assert.equal(facts.Family, 'rimless');
    assert.equal(facts.Category, 'rifle');
    assert.equal(facts['Primer type'], 'lr');
    assert.equal(facts['C.I.P. table'], 'I');
    assert.equal(facts.Country, 'US');
    assert.equal(facts.Published, '1984-06-14');
    assert.equal(facts.Revised, '2008-09-23');
    assert.equal(facts['Pressure method'], 'Transducer');
    assert.match(facts['Water capacity'], /^56 gr H2O \(source: kwk\)/);
    assert.equal(await page.locator('dl.facts a').getAttribute('href'), 'http://kwk.us/cases.html');
    assert.equal(await page.getByRole('button', { name: 'Print' }).count(), 1);
    assert.equal(await page.getByRole('link', { name: 'All cartridges', exact: true }).count(), 1);
    assert.deepEqual(problems, []);
    await context.close();
  });

  test(`[${mode}] a cartridge without alternative names or capacity says so quietly`, async () => {
    const { page, context } = await open(ctx, mode, '#/cartridge/7_x_64');
    assert.equal(await page.locator('dl.facts dt', { hasText: 'Alternative names' }).count(), 0);
    assert.match(await page.locator('dl.facts').innerText(), /Water capacity\s+not published/);
    await context.close();
  });

  test(`[${mode}] tables are grouped by section with Symbol, Value and Unit; tolerances sit beside values`, async () => {
    const { page, context } = await open(ctx, mode, '#/cartridge/308_win');
    const headers = await page.locator('table.values').first().locator('thead th').allInnerTexts();
    assert.deepEqual(headers.map((h) => h.toLowerCase()), ['symbol', 'value', 'unit']);
    const captions = await page.locator('table.values caption').allInnerTexts();
    assert.deepEqual(captions.slice(0, 8), ['Case head', 'Collar', 'Junction cone', 'Lengths', 'Miscellaneous', 'Powder chamber', 'Pressures', 'Projectile']);
    const lengths = page.locator('table.values', { has: page.locator('caption', { hasText: 'Lengths' }) }).first();
    const cells = await lengths.locator('tbody tr').evaluateAll((rows) => rows.map((r) => [...r.children].map((c) => c.textContent)));
    assert.deepEqual(cells, [['L1', '39.62 -0.2', 'mm'], ['L2', '43.48 -0.2', 'mm'], ['L3', '51.18', 'mm'], ['L6', '71.12', 'mm']]);
    const symbols = await page.locator('table.values tbody th').allInnerTexts();
    assert.ok(!symbols.some((s) => /Tol/.test(s)));
    assert.ok(symbols.includes('r1 min') && symbols.includes('r1 max') && symbols.includes('L3 + G') && symbols.includes('δ') && symbols.includes('α1'));
    const pressures = await page.locator('table.values', { has: page.locator('caption', { hasText: 'Pressures' }) }).locator('tbody tr').evaluateAll((rows) => rows.map((r) => [...r.children].map((c) => c.textContent)));
    assert.deepEqual(pressures.find((r) => r[0] === 'Pmax'), ['Pmax', '4150', 'bar']);
    assert.deepEqual(pressures.find((r) => r[0] === 'EE'), ['EE', '3920', 'J']);
    await context.close();
  });

  test(`[${mode}] angles in degrees-minutes-seconds are shown as published`, async () => {
    const { page, context } = await open(ctx, mode, '#/cartridge/338_lapua_mag');
    assert.ok((await page.locator('table.values td').allInnerTexts()).includes('39°59\'49"'));
    await context.close();
  });

  test(`[${mode}] every detail view renders drawing and tables without errors`, async () => {
    const { page, problems, context } = await open(ctx, mode);
    for (const r of data) {
      await page.goto(page.url().split('#')[0] + '#/cartridge/' + r.key);
      assert.equal(await page.getByRole('heading', { level: 1 }).innerText(), r.name);
      assert.equal(await page.getByRole('img', { name: `${r.name} drawing` }).count(), 1, r.name);
      assert.ok((await page.locator('table.values').count()) >= 12, r.name);
    }
    assert.deepEqual(problems, []);
    await context.close();
  });

  test(`[${mode}] drawing: labels, title block, dimension symbols`, async () => {
    const { page, context } = await open(ctx, mode, '#/cartridge/308_win');
    const svg = page.getByRole('img', { name: '308 Win. drawing' });
    const texts = await svg.locator('text').evaluateAll((els) => els.map((e) => e.textContent));
    for (const t of ['L3 51.18', 'L6 71.12', 'R1 12.01', 'R 1.37', 'P1 11.96', 'P2 11.53', 'H1 8.72', 'H2 8.72', 'G1 7.85', 'L1 39.62', 'L2 43.48', 'E1 10.39', 'α 40°', 'Dimensions in mm', '308 Win.', 'C.I.P. table I, revised 2008-09-23']) {
      assert.ok(texts.includes(t), t);
    }
    assert.ok(texts.some((t) => /^Scale \d+(\.\d)?:1/.test(t)));
    const vb = (await svg.getAttribute('viewBox')).split(' ').map(Number);
    assert.ok(vb[2] > 80 && vb[2] < 190, 'viewBox is in mm');
    await context.close();
  });

  test(`[${mode}] drawing: in the rendered page no label overlaps another label or the case`, async () => {
    const { page, context } = await open(ctx, mode);
    for (const r of data) {
      await page.goto(page.url().split('#')[0] + '#/cartridge/' + r.key);
      const result = await page.evaluate(() => {
        const rect = (e) => { const b = e.getBoundingClientRect(); return { x0: b.left, x1: b.right, y0: b.top, y1: b.bottom }; };
        const hit = (a, b) => a.x0 < b.x1 && b.x0 < a.x1 && a.y0 < b.y1 && b.y0 < a.y1;
        const labels = [...document.querySelectorAll('svg.cartridge-drawing text.dim-label')];
        const solids = [...document.querySelectorAll('svg.cartridge-drawing .case-outline, svg.cartridge-drawing .cut-walls, svg.cartridge-drawing .bullet-section')].map(rect);
        const rects = labels.map(rect);
        const errors = labels.length < 6 ? ['too few labels'] : [];
        rects.forEach((a, i) => {
          rects.forEach((b, j) => { if (j > i && hit(a, b)) errors.push(`${labels[i].textContent} / ${labels[j].textContent}`); });
          solids.forEach((s) => { if (hit(a, s)) errors.push(`${labels[i].textContent} on outline`); });
        });
        return errors;
      });
      assert.deepEqual(result, [], r.name);
    }
    await context.close();
  });

  test(`[${mode}] Print button opens the print dialog`, async () => {
    const { page, context } = await open(ctx, mode, '#/cartridge/308_win');
    await page.evaluate(() => { window.__printed = 0; window.print = () => { window.__printed += 1; }; });
    await page.getByRole('button', { name: 'Print' }).click();
    assert.equal(await page.evaluate(() => window.__printed), 1);
    await context.close();
  });

  test(`[${mode}] missing values are reported under the drawing`, async () => {
    const { page, context } = await open(ctx, mode, '#/cartridge/17_hmr');
    const notes = await page.locator('.drawing-notes').innerText();
    assert.match(notes, /Body-side shoulder rounding not drawn: r1 min not published/);
    assert.match(notes, /Neck-side shoulder rounding not drawn: r2 not published/);
    await page.goto(page.url().split('#')[0] + '#/cartridge/308_win');
    assert.equal(await page.locator('.drawing-notes').count(), 0);
    assert.match(await page.locator('.drawing-legend').innerText(), /Diameters are dimensioned from the outline to the centre line/);
    await context.close();
  });
}
