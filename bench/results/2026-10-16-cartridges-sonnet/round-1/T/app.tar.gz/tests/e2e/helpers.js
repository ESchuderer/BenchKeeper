'use strict';
const path = require('node:path');
const { chromium } = require('playwright');
const { createServer } = require('../../tools/serve');

const FILE_URL = 'file://' + path.join(__dirname, '..', '..', 'index.html');

async function start() {
  const server = createServer();
  await new Promise((resolve) => server.listen(0, '127.0.0.1', resolve));
  const browser = await chromium.launch();
  return {
    browser,
    base: { file: FILE_URL, http: `http://127.0.0.1:${server.address().port}/index.html` },
    async stop() { await browser.close(); await new Promise((r) => server.close(r)); },
  };
}

// Opens a page and records console problems and every network request.
async function open(ctx, mode, hash = '', options = {}) {
  const context = await ctx.browser.newContext(options);
  const page = await context.newPage();
  const problems = [];
  const requests = [];
  page.on('console', (m) => { if (['error', 'warning'].includes(m.type())) problems.push(m.text()); });
  page.on('pageerror', (e) => problems.push(e.message));
  page.on('request', (r) => requests.push(r.url()));
  await page.goto(ctx.base[mode] + hash);
  return { page, context, problems, requests };
}

module.exports = { start, open, MODES: ['file', 'http'] };
