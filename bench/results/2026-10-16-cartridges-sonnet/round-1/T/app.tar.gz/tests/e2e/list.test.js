'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { start, open, MODES } = require('./helpers');
require('../unit/load');
const names = globalThis.CIP_DATA.map((r) => r.name);

let ctx;
test.before(async () => { ctx = await start(); });
test.after(async () => { await ctx.stop(); });

for (const mode of MODES) {
  test(`[${mode}] start page lists all 25 cartridges with name links, family and L3`, async () => {
    const { page, problems, context } = await open(ctx, mode);
    assert.equal(await page.getByRole('heading', { level: 1 }).innerText(), 'Cartridges');
    assert.equal(await page.locator('#count').innerText(), '25 cartridges');
    const links = await page.locator('table.cartridge-list a').allInnerTexts();
    assert.deepEqual(links, names);
    const row = page.locator('table.cartridge-list tbody tr', { has: page.getByRole('link', { name: '308 Win.', exact: true }) });
    assert.match(await row.innerText(), /rimless/);
    assert.match(await row.innerText(), /51\.18 mm/);
    const row2 = page.locator('table.cartridge-list tbody tr', { has: page.getByRole('link', { name: '6,5 Creedmoor', exact: true }) });
    assert.match(await row2.innerText(), /rimless/);
    assert.deepEqual(problems, []);
    await context.close();
  });

  test(`[${mode}] search filters by name and alternative names as the user types`, async () => {
    const { page, context } = await open(ctx, mode);
    const search = page.getByLabel('Search');
    await search.pressSequentially('7,62 x 51');
    assert.deepEqual(await page.locator('table.cartridge-list a').allInnerTexts(), ['308 Win.']);
    assert.equal(await page.locator('#count').innerText(), '1 cartridges');
    await search.fill('22');
    assert.deepEqual(await page.locator('table.cartridge-list a').allInnerTexts(), ['223 Rem.', '22 Long Rifle', '22 Win. Mag. R.F.']);
    await search.fill('zzzz');
    assert.equal(await page.locator('#count').innerText(), '0 cartridges');
    assert.match(await page.locator('main').innerText(), /No cartridge matches/);
    await search.fill('');
    assert.equal(await page.locator('#count').innerText(), '25 cartridges');
    await context.close();
  });

  test(`[${mode}] family select offers All and the five families and filters the list`, async () => {
    const { page, context } = await open(ctx, mode);
    const select = page.getByLabel('Family');
    assert.deepEqual(await select.locator('option').allInnerTexts(), ['All', 'rimless', 'rimmed', 'belted', 'pistol', 'rimfire']);
    const expected = { rimless: 12, rimmed: 2, belted: 2, pistol: 6, rimfire: 3 };
    for (const [family, n] of Object.entries(expected)) {
      await select.selectOption({ label: family });
      assert.equal(await page.locator('#count').innerText(), `${n} cartridges`);
      assert.equal(await page.locator('table.cartridge-list tbody tr').count(), n);
    }
    await select.selectOption({ label: 'rimfire' });
    await page.getByLabel('Search').fill('22');
    assert.equal(await page.locator('#count').innerText(), '2 cartridges');
    await select.selectOption({ label: 'All' });
    await page.getByLabel('Search').fill('');
    assert.equal(await page.locator('#count').innerText(), '25 cartridges');
    await context.close();
  });

  test(`[${mode}] a name link opens the detail view at its own address, which survives reload`, async () => {
    const { page, context } = await open(ctx, mode);
    const heading = (name) => page.getByRole('heading', { level: 1, name, exact: true }).waitFor();
    await page.getByRole('link', { name: '6,5 Creedmoor', exact: true }).click();
    await heading('6,5 Creedmoor');
    assert.match(page.url(), /#\/cartridge\/6_5_creedmoor$/);
    await page.reload();
    await heading('6,5 Creedmoor');
    await page.getByRole('link', { name: 'All cartridges', exact: true }).click();
    await heading('Cartridges');
    await page.goBack();
    await heading('6,5 Creedmoor');
    await context.close();
  });

  test(`[${mode}] an unknown address says so and links back`, async () => {
    const { page, context } = await open(ctx, mode, '#/cartridge/nope');
    assert.equal(await page.getByRole('heading', { level: 1 }).innerText(), 'Cartridge not found');
    await page.getByRole('link', { name: 'All cartridges' }).last().click();
    assert.equal(await page.locator('#count').innerText(), '25 cartridges');
    await context.close();
  });

  test(`[${mode}] a malformed or slightly different address never blanks the app`, async () => {
    const bad = await open(ctx, mode, '#/cartridge/%E0%A4%A');
    assert.equal(await bad.page.getByRole('heading', { level: 1 }).innerText(), 'Cartridge not found');
    assert.deepEqual(bad.problems, []);
    await bad.context.close();
    const slash = await open(ctx, mode, '#/cartridge/308_win/');
    assert.equal(await slash.page.getByRole('heading', { level: 1 }).innerText(), '308 Win.');
    await slash.context.close();
  });

  test(`[${mode}] returning to the list restores the scroll position`, async () => {
    const { page, context } = await open(ctx, mode, '', { viewport: { width: 900, height: 500 } });
    await page.getByRole('link', { name: '357 Magnum', exact: true }).scrollIntoViewIfNeeded();
    const before = await page.evaluate(() => scrollY);
    assert.ok(before > 100);
    await page.getByRole('link', { name: '357 Magnum', exact: true }).click();
    await page.getByRole('heading', { level: 1, name: '357 Magnum' }).waitFor();
    assert.equal(await page.evaluate(() => scrollY), 0);
    await page.goBack();
    await page.getByRole('heading', { level: 1, name: 'Cartridges' }).waitFor();
    assert.equal(await page.evaluate(() => scrollY), before);
    await context.close();
  });

  test(`[${mode}] no network requests beyond the app's own files`, async () => {
    const { page, requests, context } = await open(ctx, mode, '#/cartridge/308_win');
    await page.getByRole('link', { name: 'All cartridges' }).click();
    for (const url of requests) {
      assert.ok(mode === 'file' ? url.startsWith('file://') : url.startsWith('http://127.0.0.1'), url);
    }
    await context.close();
  });
}
