'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { data } = require('./load');

test('the data set holds the 25 records of the brief, in order', () => {
  assert.equal(data.length, 25);
  assert.deepEqual(data.map((r) => r.key), [
    '223_rem', '243_win', '6_5_creedmoor', '6_5_x_55_se', '270_win', '7_x_64', '308_win', '30_06_spring',
    '8_x_57_is', '9_3_x_62', '7_62_x_39', '338_lapua_mag', '300_win_mag', '7_mm_rem_mag', '9_3_x_74_r',
    '7_x_65_r', '9_mm_luger', '45_auto', '40_s_w', '38_special', '357_magnum', '44_rem_mag', '22_long_rifle',
    '22_win_mag_r_f', '17_hmr',
  ]);
});

test('records are published verbatim (spot checks)', () => {
  const r = data.find((x) => x.key === '308_win');
  assert.equal(r.name, '308 Win.');
  assert.deepEqual(r.alternativeNames, ['308 Winchester', '7,62 x 51']);
  assert.equal(r.cartridge.lengths.L3, 51.18);
  assert.equal(r.cartridge.pressures.Pmax, 4150);
  assert.equal(data.find((x) => x.key === '6_5_creedmoor').name, '6,5 Creedmoor');
  assert.deepEqual(data.find((x) => x.key === '22_long_rifle').alternativeNames.includes('22 lang für Büchsen'), true);
});

test('family counts match the brief', () => {
  const count = (f) => data.filter((r) => r.family === f).length;
  assert.deepEqual(['rimless', 'rimmed', 'belted', 'pistol', 'rimfire'].map(count), [12, 2, 2, 6, 3]);
});
