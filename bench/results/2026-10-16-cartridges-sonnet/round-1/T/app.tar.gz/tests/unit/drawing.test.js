'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { CIP, data, byKey } = require('./load');

const layoutOf = (rec) => CIP.drawing.buildLayout(CIP.geometry.buildModel(rec));
const overlaps = (a, b) => a.x0 < b.x1 && b.x0 < a.x1 && a.y0 < b.y1 && b.y0 < a.y1;
const REQUIRED = ['L3', 'L6', 'R1', 'R', 'P1'];

test('every label reads "<symbol> <value>" and the required dimensions are present', () => {
  const l = layoutOf(byKey('308_win'));
  const text = (s) => l.labels.find((x) => x.symbol === s).text;
  assert.equal(text('L3'), 'L3 51.18');
  assert.equal(text('L6'), 'L6 71.12');
  assert.equal(text('R1'), 'R1 12.01');
  assert.equal(text('P1'), 'P1 11.96');
  assert.equal(text('alpha'), 'α 40°');
  for (const s of ['P2', 'H1', 'H2', 'G1', 'L1', 'L2', 'E1', 'R']) assert.ok(l.labels.some((x) => x.symbol === s), s);
  assert.equal(CIP.drawing.buildLayout(CIP.geometry.buildModel(byKey('338_lapua_mag'))).labels.find((x) => x.symbol === 'alpha').text, 'α 39°59\'49"');
});

test('no labels overlap each other or the silhouette, for all 25 records', () => {
  for (const r of data) {
    const l = layoutOf(r);
    for (const s of REQUIRED) assert.ok(l.labels.some((x) => x.symbol === s), `${r.key} has ${s}`);
    for (let i = 0; i < l.labels.length; i++) {
      assert.ok(!overlaps(l.labels[i].box, l.silhouette), `${r.key}: ${l.labels[i].text} touches the outline`);
      for (let j = i + 1; j < l.labels.length; j++) {
        assert.ok(!overlaps(l.labels[i].box, l.labels[j].box), `${r.key}: "${l.labels[i].text}" overlaps "${l.labels[j].text}"`);
      }
    }
  }
});

test('labels do not sit on other labels\' leader or extension lines', () => {
  for (const r of data) {
    const l = layoutOf(r);
    for (const label of l.labels) {
      for (const line of l.lines.filter((x) => x.cls === 'ext' && x.symbol !== label.symbol)) {
        const seg = { x0: Math.min(line.x1, line.x2), x1: Math.max(line.x1, line.x2), y0: Math.min(line.y1, line.y2), y1: Math.max(line.y1, line.y2) };
        assert.ok(!overlaps(label.box, seg), `${r.key}: ${label.text} crosses ${line.symbol} extension`);
      }
    }
  }
});

test('all labels and the title block lie inside the view box', () => {
  for (const r of data) {
    const l = layoutOf(r);
    const vb = l.viewBox;
    const inside = (b) => b.x0 >= vb.x - 1e-6 && b.x1 <= vb.x + vb.w + 1e-6 && b.y0 >= vb.y - 1e-6 && b.y1 <= vb.y + vb.h + 1e-6;
    for (const x of l.labels) assert.ok(inside(x.box), `${r.key} ${x.text}`);
    assert.ok(inside({ x0: l.titleBlock.x, x1: l.titleBlock.x + l.titleBlock.w, y0: l.titleBlock.y, y1: l.titleBlock.y + l.titleBlock.h }), `${r.key} title block`);
    assert.ok(inside(l.silhouette), `${r.key} silhouette`);
  }
});

test('each dimension has extension lines, a dimension line and arrowheads', () => {
  for (const r of data) {
    const l = layoutOf(r);
    for (const label of l.labels.filter((x) => x.symbol !== 'alpha')) {
      assert.ok(l.lines.some((x) => x.symbol === label.symbol && x.cls === 'ext'), `${r.key} ${label.symbol} ext`);
      assert.ok(l.lines.some((x) => x.symbol === label.symbol && x.cls === 'dim'), `${r.key} ${label.symbol} dim`);
      assert.ok(l.arrows.filter((x) => x.symbol === label.symbol).length >= 2, `${r.key} ${label.symbol} arrows`);
    }
  }
});

test('dimension lines are to scale: 1 user unit = 1 mm', () => {
  const l = layoutOf(byKey('308_win'));
  const dimLine = (s) => l.lines.find((x) => x.symbol === s && x.cls === 'dim');
  const lengthOf = (s) => { const d = dimLine(s); return Math.abs(d.x2 - d.x1); };
  near(lengthOf('L3'), 51.18, 0.8); // narrow-style lines may extend beyond the measured span
  const L3 = l.lines.filter((x) => x.symbol === 'L3' && x.cls === 'ext').map((x) => x.x1);
  assert.deepEqual([...new Set(L3.map((x) => +x.toFixed(3)))].sort((a, b) => a - b), [0, 51.18]);
  const L6 = l.lines.filter((x) => x.symbol === 'L6' && x.cls === 'ext').map((x) => +x.x1.toFixed(3));
  assert.deepEqual([...new Set(L6)].sort((a, b) => a - b), [0, 71.12]);
  const d = l.lines.filter((x) => x.symbol === 'P1' && x.cls === 'dim')[0];
  near(Math.abs(d.y2 - d.y1), 11.96 / 2, 1e-6);
});

function near(a, b, eps) { assert.ok(Math.abs(a - b) <= eps, `expected ${b}, got ${a}`); }

test('scale: printed at 190 mm width the drawing has a one-decimal scale and the view box matches it', () => {
  for (const r of data) {
    const l = layoutOf(r);
    near(l.viewBox.w * l.scale, 190, 1e-6);
    assert.equal(l.scale, Math.round(l.scale * 10) / 10);
    assert.ok(l.scale >= 1, `${r.key} scale ${l.scale}`);
  }
  assert.equal(CIP.drawing.scaleText(2), '2:1');
  assert.equal(CIP.drawing.scaleText(1.7), '1.7:1');
  assert.equal(CIP.drawing.scaleText(0.5), '1:2');
});

test('SVG: accessible name, title block, centre line, hatching, unit view box', () => {
  const svg = CIP.drawing.renderSvg(CIP.geometry.buildModel(byKey('308_win')));
  assert.match(svg, /<svg[^>]*role="img"/);
  assert.match(svg, /aria-label="308 Win\. drawing"/);
  assert.match(svg, /viewBox="[-\d. ]+"/);
  assert.match(svg, /Dimensions in mm/);
  assert.match(svg, /C\.I\.P\. table I, revised 2008-09-23/);
  assert.match(svg, /Scale \d+(\.\d)?:1/);
  assert.match(svg, />308 Win\.</);
  assert.match(svg, /class="centerline"/);
  assert.match(svg, /<pattern/);
  assert.doesNotMatch(svg, /<script|http:|https:/);
});

test('SVG: names are escaped', () => {
  const svg = CIP.drawing.renderSvg(CIP.geometry.buildModel(byKey('40_s_w')));
  assert.match(svg, /aria-label="40 S\.&amp; W\. drawing"/);
});

test('SVG: missing values are described in plain words', () => {
  const notes = CIP.drawing.describeMissing(CIP.geometry.buildModel(byKey('17_hmr')));
  assert.deepEqual(notes, ['Body-side shoulder rounding not drawn: r1 min not published.', 'Neck-side shoulder rounding not drawn: r2 not published.']);
  assert.deepEqual(CIP.drawing.describeMissing(CIP.geometry.buildModel(byKey('308_win'))), []);
});

test('SVG draws every record without NaN', () => {
  for (const r of data) {
    const svg = CIP.drawing.renderSvg(CIP.geometry.buildModel(r));
    assert.doesNotMatch(svg, /NaN|undefined|Infinity/, r.key);
  }
});

test('SVG: strings taken from data are escaped everywhere', () => {
  const model = CIP.geometry.buildModel(byKey('308_win'));
  model.key = '"><script>x</script>';
  model.name = '<b>&"';
  const svg = CIP.drawing.renderSvg(model);
  assert.doesNotMatch(svg, /<script|<b>/);
});
