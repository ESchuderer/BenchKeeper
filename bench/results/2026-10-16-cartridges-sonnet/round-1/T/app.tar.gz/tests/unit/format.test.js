'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { CIP, data, byKey } = require('./load');

const rowOf = (rec, part, section, field) =>
  CIP.format.buildSections(rec)[part].find((s) => s.id === section).rows.find((r) => r.field === field);

test('formatNumber prints numbers as published: decimal point, no thousands separator, no trailing .0', () => {
  assert.equal(CIP.format.formatNumber(51.18), '51.18');
  assert.equal(CIP.format.formatNumber(4150.0), '4150');
  assert.equal(CIP.format.formatNumber(0.1), '0.1');
  assert.equal(CIP.format.formatNumber(5375), '5375');
});

test('formatAngle shows degrees or degrees-minutes-seconds', () => {
  assert.equal(CIP.format.formatAngle(40), '40°');
  assert.equal(CIP.format.formatAngle({ degrees: 39, minutes: 59, seconds: 49 }), '39°59\'49"');
  assert.equal(CIP.format.formatAngle({ degrees: 34, minutes: 30, seconds: 0 }), '34°30\'0"');
  assert.equal(CIP.format.formatAngle(3), '3°');
});

test('symbols are the field names except the specified ones', () => {
  const s = CIP.format.symbolOf;
  assert.deepEqual(
    ['eMin', 'r1Min', 'r1Max', 'alpha', 'alpha1', 'beta', 'delta', 'deltaL', 'L3PlusG', 'L3', 'Pmax', 'r'].map(s),
    ['e min', 'r1 min', 'r1 max', 'α', 'α1', 'β', 'δ', 'delta L', 'L3 + G', 'L3', 'Pmax', 'r'],
  );
});

test('units: mm by default, bar, J, g, mm², none for N, deg for angles', () => {
  const u = CIP.format.unitOf;
  assert.deepEqual(
    ['L3', 'P1', 'Pmax', 'PK', 'PE', 'EE', 'M', 'Q', 'N', 'alpha', 'alpha1', 'beta', 'delta', 'i', 'u', 'G1'].map(u),
    ['mm', 'mm', 'bar', 'bar', 'bar', 'J', 'g', 'mm²', '', 'deg', 'deg', 'deg', 'deg', 'deg', 'mm', 'mm'],
  );
});

test('a tolerance is shown next to its value and never as a row of its own', () => {
  const rec = byKey('308_win');
  assert.equal(rowOf(rec, 'cartridge', 'lengths', 'L1').text, '39.62 -0.2');
  assert.equal(rowOf(rec, 'cartridge', 'lengths', 'L3').text, '51.18');
  for (const r of data) {
    for (const part of ['cartridge', 'chamber']) {
      for (const sec of CIP.format.buildSections(r)[part]) {
        assert.equal(sec.rows.filter((x) => /Tol$/.test(x.field)).length, 0, `${r.key} ${sec.id}`);
      }
    }
  }
});

test('every Tol field in the data has a base value to attach to', () => {
  for (const r of data) {
    for (const part of ['cartridge', 'chamber']) {
      for (const [sid, sec] of Object.entries(r[part])) {
        for (const k of Object.keys(sec).filter((x) => /Tol$/.test(x))) {
          assert.ok(k.slice(0, -3) in sec, `${r.key} ${part}.${sid}.${k}`);
        }
      }
    }
  }
});

test('positive tolerances carry an explicit plus sign', () => {
  assert.equal(CIP.format.formatTolerance(0.25), '+0.25');
  assert.equal(CIP.format.formatTolerance(-0.2), '-0.2');
});

test('table rows carry symbol, value text and unit', () => {
  const rec = byKey('308_win');
  assert.deepEqual(
    (({ symbol, text, unit }) => ({ symbol, text, unit }))(rowOf(rec, 'cartridge', 'pressures', 'Pmax')),
    { symbol: 'Pmax', text: '4150', unit: 'bar' },
  );
  assert.equal(rowOf(rec, 'cartridge', 'junctionCone', 'alpha').text, '40°');
  assert.equal(rowOf(rec, 'cartridge', 'junctionCone', 'r1Min').symbol, 'r1 min');
  assert.equal(rowOf(rec, 'chamber', 'rifling', 'i').text, '1°45\'0"');
  assert.equal(rowOf(rec, 'chamber', 'grooves', 'N').unit, '');
  assert.equal(rowOf(byKey('338_lapua_mag'), 'cartridge', 'junctionCone', 'alpha').text, '39°59\'49"');
});

test('sections are titled and empty sections are omitted', () => {
  const s = CIP.format.buildSections(byKey('9_mm_luger'));
  assert.ok(!s.cartridge.some((x) => x.id === 'junctionCone'));
  assert.equal(s.cartridge.find((x) => x.id === 'caseHead').title, 'Case head');
  assert.equal(s.chamber.find((x) => x.id === 'powderChamber').title, 'Powder chamber');
});

test('all cartridge and all chamber values appear in the sections', () => {
  for (const r of data) {
    for (const part of ['cartridge', 'chamber']) {
      const expected = Object.values(r[part]).flatMap((sec) => Object.keys(sec).filter((k) => !/Tol$/.test(k))).length;
      const actual = CIP.format.buildSections(r)[part].reduce((n, s) => n + s.rows.length, 0);
      assert.equal(actual, expected, `${r.key} ${part}`);
    }
  }
});

test('search finds by name and alternative names, ignoring case and punctuation differences', () => {
  const find = (q) => CIP.format.filterCartridges(data, { query: q, family: 'all' }).map((r) => r.key);
  assert.deepEqual(find('7,62 x 51'), ['308_win']);
  assert.deepEqual(find('7.62x51'), ['308_win']);
  assert.ok(find('308 win').includes('308_win'));
  assert.deepEqual(find('creed'), ['6_5_creedmoor']);
  assert.deepEqual(find('22 lang fur buchsen'), ['22_long_rifle']);
  assert.equal(find('').length, 25);
  assert.equal(find('   ').length, 25);
  assert.deepEqual(find('zzz'), []);
});

test('family filter and search combine', () => {
  const f = (family, query = '') => CIP.format.filterCartridges(data, { query, family }).length;
  assert.equal(f('all'), 25);
  assert.equal(f('rimless'), 12);
  assert.equal(f('rimmed'), 2);
  assert.equal(f('belted'), 2);
  assert.equal(f('pistol'), 6);
  assert.equal(f('rimfire'), 3);
  assert.equal(f('pistol', '22'), 0);
  assert.equal(f('rimfire', '22'), 2);
});

test('count text is "<n> cartridges"', () => {
  assert.equal(CIP.format.formatCount(25), '25 cartridges');
  assert.equal(CIP.format.formatCount(0), '0 cartridges');
});

test('capacity and metadata helpers', () => {
  assert.equal(CIP.format.formatCapacity(byKey('223_rem').annotations.publishedCapacity), '30.5 gr H2O');
  assert.equal(CIP.format.formatCapacity(undefined), null);
});

test('punctuation-insensitive matching is only a fallback when the literal text finds nothing', () => {
  const find = (q) => CIP.format.filterCartridges(data, { query: q, family: 'all' }).map((r) => r.key);
  assert.deepEqual(find('3-0'), []);
  assert.deepEqual(find('30-0'), ['30_06_spring']);
  assert.deepEqual(find('7,62x51'), ['308_win']);
  assert.deepEqual(find('7.62 X 51'), ['308_win']);
  assert.deepEqual(find('.8'), data.filter((r) => [r.name, ...(r.alternativeNames || [])].some((n) => n.toLowerCase().includes('.8'))).map((r) => r.key));
});
