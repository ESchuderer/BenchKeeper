'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { CIP, data, byKey } = require('./load');

const near = (actual, expected, eps = 1e-6, msg = '') =>
  assert.ok(Math.abs(actual - expected) <= eps, `${msg} expected ${expected}, got ${actual}`);
const model = (key) => CIP.geometry.buildModel(byKey(key));
const rad = (deg) => (deg * Math.PI) / 180;

test('rule 1: rim type from family and R1/P1', () => {
  assert.equal(model('300_win_mag').rimType, 'belted');
  assert.equal(model('22_long_rifle').rimType, 'rimfire');
  assert.equal(model('308_win').rimType, 'rimless');
  assert.equal(model('9_3_x_74_r').rimType, 'rimmed');
  assert.equal(model('38_special').rimType, 'rimmed');
  assert.equal(CIP.geometry.rimTypeOf({ family: 'rimless' }, { R1: 9.0, P1: 10 }), 'rebated');
  assert.equal(CIP.geometry.rimTypeOf({ family: 'rimless' }, { R1: 10.5, P1: 10 }), 'rimmed');
  assert.equal(CIP.geometry.rimTypeOf({ family: 'rimless' }, { R1: 10.49, P1: 10 }), 'rimless');
  assert.equal(CIP.geometry.rimTypeOf({ family: 'rimless' }, { R1: 9.8, P1: 10 }), 'rimless');
});

test('profile starts on the axis at the head face and ends at the mouth radius H2/2 at L3', () => {
  for (const r of data) {
    const m = CIP.geometry.buildModel(r);
    assert.deepEqual(m.outer[0], [0, 0], r.key);
    const last = m.outer[m.outer.length - 1];
    near(last[0], r.cartridge.collar.H2 / 2, 1e-9, r.key);
    near(last[1], r.cartridge.lengths.L3, 1e-9, r.key);
  }
});

test('rule 2: chamfer at the head face where beta and f are published', () => {
  const m = model('308_win'); // R1 12.01, f 0.38, beta 35
  const d = Math.min(0.38 * Math.tan(rad(35)), 12.01 / 4);
  near(m.outer[1][0], 12.01 / 2 - d, 1e-9);
  assert.equal(m.outer[1][1], 0);
  assert.deepEqual(m.outer[2], [12.01 / 2, 0.38]);
  assert.deepEqual(m.outer[3], [12.01 / 2, 1.37]);
});

test('rule 2: square corner when beta/f are missing or beta is not below 90 degrees', () => {
  const rec = structuredClone(byKey('308_win'));
  delete rec.cartridge.caseHead.f;
  const m = CIP.geometry.buildModel(rec);
  assert.deepEqual(m.outer.slice(0, 3), [[0, 0], [12.01 / 2, 0], [12.01 / 2, 1.37]]);
  const rec2 = structuredClone(byKey('308_win'));
  rec2.cartridge.caseHead.beta = 90;
  assert.deepEqual(CIP.geometry.buildModel(rec2).outer.slice(0, 3), [[0, 0], [12.01 / 2, 0], [12.01 / 2, 1.37]]);
});

test('rule 2: chamfer length is capped at R1/4', () => {
  const rec = structuredClone(byKey('308_win'));
  rec.cartridge.caseHead.f = 5; // f tan(35deg) = 3.5 > R1/4 = 3.0
  rec.cartridge.caseHead.beta = 35;
  near(CIP.geometry.buildModel(rec).outer[1][0], 12.01 / 2 - 12.01 / 4, 1e-9);
});

test('rule 2: a beta given as degrees-minutes-seconds is understood', () => {
  assert.equal(CIP.geometry.toDegrees({ degrees: 39, minutes: 59, seconds: 49 }), 39 + 59 / 60 + 49 / 3600);
  assert.equal(CIP.geometry.toDegrees(35), 35);
});

test('rule 2: rimfire rim edge is a half-round whose outermost point lies at R1/2', () => {
  const m = model('22_long_rifle'); // R 1.09, R1 7.06, P1 5.74
  const rimR = 7.06 / 2;
  const maxR = Math.max(...m.outer.filter((p) => p[1] <= 1.09 + 1e-9).map((p) => p[0]));
  near(maxR, rimR, 1e-9);
  const rho = Math.min(1.09 / 2, (7.06 - 5.74) / 2);
  const center = [rimR - rho, 1.09 / 2];
  const arc = m.outer.filter((p) => p[0] > center[0] + 1e-9);
  assert.ok(arc.length >= 5);
  for (const p of arc) near(Math.hypot(p[0] - center[0], p[1] - center[1]), rho, 1e-6, 'on the half-round');
  assert.deepEqual(m.outer[0], [0, 0]);
});

test('rule 3: extractor groove goes in, along the floor and ramps out to P1/2 at E', () => {
  const m = model('308_win');
  const idx = m.outer.findIndex((p) => p[0] === 12.01 / 2 && p[1] === 1.37);
  assert.deepEqual(m.outer[idx + 1], [10.39 / 2, 1.37]);
  assert.deepEqual(m.outer[idx + 2], [10.39 / 2, 1.37 + 1.4]);
  assert.deepEqual(m.outer[idx + 3], [11.96 / 2, 3.85]);
  assert.equal(m.bodyStart, 3.85);
});

test('rule 3: without a groove the profile steps in from (R1/2, R) to (P1/2, R)', () => {
  const m = model('9_3_x_74_r'); // no E, E1
  const idx = m.outer.findIndex((p) => p[0] === 13.35 / 2 && p[1] === 1.4);
  assert.deepEqual(m.outer[idx + 1], [11.9 / 2, 1.4]);
  assert.equal(m.bodyStart, 1.4);
});

test('rule 3: belted case ramps out at delta to the belt, follows it to E and steps in to P1/2', () => {
  const m = model('300_win_mag'); // R3 13.51, E1 12.07, R 1.27, eMin 0.94, delta 35, E 5.59, P1 13.03
  const floorEnd = [12.07 / 2, 1.27 + 0.94];
  const iFloor = m.outer.findIndex((p) => p[0] === floorEnd[0] && Math.abs(p[1] - floorEnd[1]) < 1e-9);
  assert.ok(iFloor > 0);
  const rampEnd = m.outer[iFloor + 1];
  near(rampEnd[0], 13.51 / 2, 1e-9);
  near(rampEnd[1], floorEnd[1] + (13.51 / 2 - 12.07 / 2) / Math.tan(rad(35)), 1e-9);
  assert.deepEqual(m.outer[iFloor + 2], [13.51 / 2, 5.59]);
  assert.deepEqual(m.outer[iFloor + 3], [13.03 / 2, 5.59]);
  near(m.beltRampEnd, rampEnd[1], 1e-9);
  assert.equal(m.bodyStart, 5.59);
});

test('rule 4: a case without alpha, L1 or L2 is straight, running from P1/2 to (H2/2, L3)', () => {
  const m = model('9_mm_luger');
  assert.equal(m.bottleneck, false);
  assert.deepEqual(m.outer.slice(-2), [[9.93 / 2, 2.98], [9.65 / 2, 19.15]]);
  assert.equal(m.shoulder, null);
  assert.equal(model('22_win_mag_r_f').bottleneck, false);
});

test('rules 4-6: bottleneck passes through the published shoulder points', () => {
  const m = model('308_win');
  assert.equal(m.bottleneck, true);
  const has = (r, z) => m.outer.some((p) => Math.abs(p[0] - r) < 1e-9 && Math.abs(p[1] - z) < 1e-9);
  // the rounded corners replace the sharp corners; tangent points lie on the published lines
  assert.deepEqual(m.shoulder.start, [11.53 / 2, 39.62]);
  assert.deepEqual(m.shoulder.end, [8.72 / 2, 43.48]);
  assert.ok(m.shoulder.rounded.r1Min && m.shoulder.rounded.r2);
  assert.ok(!has(11.53 / 2, 39.62), 'body-side corner is rounded');
  assert.ok(!has(8.72 / 2, 43.48), 'neck-side corner is rounded');
});

test('rule 5: corners are sharp where r1 min or r2 are not published, and the missing values are named', () => {
  const m = model('17_hmr');
  const has = (r, z) => m.outer.some((p) => Math.abs(p[0] - r) < 1e-9 && Math.abs(p[1] - z) < 1e-9);
  assert.ok(has(6.15 / 2, 22.2));
  assert.ok(has(4.9 / 2, 23.54));
  assert.deepEqual(m.missing.find((x) => x.feature === 'Body-side shoulder rounding').values, ['r1 min']);
  assert.deepEqual(m.missing.find((x) => x.feature === 'Neck-side shoulder rounding').values, ['r2']);
  const lapua = model('338_lapua_mag').missing.map((x) => x.feature);
  assert.deepEqual(lapua.filter((f) => /rounding/.test(f)), ['Body-side shoulder rounding']);
});

test('rule 5: the shoulder line lies at alpha/2 to the axis in the published data', () => {
  const m = model('308_win');
  const [r1, z1] = m.shoulder.start;
  const [r2, z2] = m.shoulder.end;
  const angle = (Math.atan2(r1 - r2, z2 - z1) * 180) / Math.PI;
  near(angle, 20, 0.2, 'half angle');
  assert.equal(m.shoulder.alpha, 40);
});

test('rounded corners are tangent arcs that never leave the corner region', () => {
  for (const r of data.filter((x) => (x.cartridge.junctionCone || {}).alpha !== undefined)) {
    const m = CIP.geometry.buildModel(r);
    const zs = m.outer.map((p) => p[1]);
    for (let i = 1; i < zs.length; i++) assert.ok(zs[i] >= zs[i - 1] - 1e-9, `${r.key}: z is monotone`);
  }
});

test('rule 7: pointy bullet, tangent ogive (308 Win.)', () => {
  const b = model('308_win').bullet;
  const G1 = 7.85, L3 = 51.18, L6 = 71.12;
  near(b.seatDepth, 1.0 * G1, 1e-9);
  near(b.zb, L3 - G1, 1e-9);
  near(b.length, L6 - (L3 - G1), 1e-9);
  near(b.zCylinderEnd, b.zb + 0.4 * b.length, 1e-9);
  near(b.meplat, Math.max(0.08 * G1, 1.27), 1e-9);
  const n = L6 - b.zCylinderEnd;
  const a = G1 / 2 - b.meplat / 2;
  near(b.ogiveRadius, (a * a + n * n) / (2 * a), 1e-9);
  const center = [G1 / 2 - b.ogiveRadius, b.zCylinderEnd];
  const arc = b.outline.filter((p) => p[1] > b.zCylinderEnd + 1e-9 && p[1] < L6 - 1e-9);
  assert.ok(arc.length > 10);
  for (const p of arc) near(Math.hypot(p[0] - center[0], p[1] - center[1]), b.ogiveRadius, 1e-6, 'on the ogive arc');
  const tip = b.outline[b.outline.length - 1];
  near(tip[0], b.meplat / 2, 1e-6);
  near(tip[1], L6, 1e-9);
});

test('rule 7: meplat of a small pointy bullet is the larger of 0.08 G1 and 1.27', () => {
  near(model('223_rem').bullet.meplat, 1.27, 1e-9);
});

test('rule 7: rounded pistol bullet, quarter ellipse (9 mm Luger)', () => {
  const b = model('9_mm_luger').bullet;
  const G1 = 9.03;
  near(b.seatDepth, 0.4 * G1, 1e-9);
  near(b.zCylinderEnd, b.zb + 0.65 * b.length, 1e-9);
  near(b.meplat, 0.15 * G1, 1e-9);
  const n = 29.69 - b.zCylinderEnd;
  const a = G1 / 2 - b.meplat / 2;
  for (const p of b.outline.filter((q) => q[1] > b.zCylinderEnd + 1e-9 && q[1] < 29.69 - 1e-9)) {
    const t = (p[1] - b.zCylinderEnd) / n;
    near(p[0], b.meplat / 2 + a * Math.sqrt(1 - t * t), 1e-6, 'on the ellipse');
  }
});

test('rule 7: rounded bullet seats 0.8 G1 deep with k = 0.55 on a rimfire case', () => {
  const b = model('22_win_mag_r_f').bullet;
  near(b.seatDepth, 0.8 * 5.7, 1e-9);
  near(b.zCylinderEnd, b.zb + 0.55 * b.length, 1e-9);
});

test('rule 7: flat pistol bullet is a straight cone with m = 0.55 G1 and k = 0.70', () => {
  const b = model('40_s_w').bullet;
  near(b.seatDepth, 0.4 * 10.17, 1e-9);
  near(b.zCylinderEnd, b.zb + 0.7 * b.length, 1e-9);
  near(b.meplat, 0.55 * 10.17, 1e-9);
  const cone = b.outline.filter((p) => p[1] >= b.zCylinderEnd - 1e-9);
  assert.equal(cone.length, 2, 'two points: a straight line');
});

test('rule 7: semi-wadcutter seats 0.6 G1, k = 0.78, m = 0.6 G1', () => {
  const b = model('357_magnum').bullet;
  near(b.seatDepth, 0.6 * 9.12, 1e-9);
  near(b.zCylinderEnd, b.zb + 0.78 * b.length, 1e-9);
  near(b.meplat, 0.6 * 9.12, 1e-9);
});

test('rule 7: flat rifle bullets use 0.8 G1 and k = 0.60, flat rifle k table', () => {
  const rec = structuredClone(byKey('308_win'));
  rec.annotations.defaultBulletShape = 'flat';
  const b = CIP.geometry.buildModel(rec).bullet;
  near(b.seatDepth, 0.8 * 7.85, 1e-9);
  near(b.zCylinderEnd, b.zb + 0.6 * b.length, 1e-9);
  rec.annotations.defaultBulletShape = 'rounded';
  near(CIP.geometry.buildModel(rec).bullet.zCylinderEnd - CIP.geometry.buildModel(rec).bullet.zb, 0.55 * CIP.geometry.buildModel(rec).bullet.length, 1e-9);
});

test('rule 7: heeled case (22 Long Rifle): exposed bullet has the outside diameter, the heel the inside diameter', () => {
  const m = model('22_long_rifle');
  assert.equal(m.heeled, true);
  const tb = m.walls.tb;
  near(m.bullet.rSeated, (5.72 - 2 * tb) / 2, 1e-9);
  near(m.bullet.rExposed, 5.72 / 2, 1e-9);
  assert.equal(model('308_win').heeled, false);
  assert.equal(model('22_win_mag_r_f').heeled, false);
});

test('rule 7: the outside view hides the seated part, the section shows it', () => {
  const m = model('308_win');
  assert.ok(m.bullet.outline.every((p) => p[1] >= 51.18 - 1e-9));
  assert.ok(m.bullet.section.some((p) => p[1] <= m.bullet.zb + 1e-9));
  assert.deepEqual(m.bullet.section[0], [0, m.bullet.zb]);
});

test('rule 8: wall thicknesses and head length for the 308 Win. (lr primer)', () => {
  const w = model('308_win').walls;
  near(w.tn, (8.72 - 7.85) / 2, 1e-9);
  near(w.tb, 0.6, 1e-9);
  near(w.w, 3.3 + 1.5, 1e-9);
  assert.deepEqual(model('308_win').pocket, { diameter: 5.33, depth: 3.3 });
});

test('rule 8: tb = min(max(1.3 tn, 0.6), 0.35 P1/2) with the cap active on a thin case', () => {
  assert.equal(CIP.geometry.bodyWall(0.1, 2.0), 0.35 * 1.0);
  assert.equal(CIP.geometry.bodyWall(1.0, 20), 1.3);
  assert.equal(CIP.geometry.bodyWall(0.2, 20), 0.6);
});

test('rule 8: w is the largest of 2.5, P1/8, pocket depth + 1.5, E + tb, belt ramp end + tb', () => {
  near(model('223_rem').walls.w, 3.04 + 1.5, 1e-9);
  near(CIP.geometry.headLength({ P1: 5, pocketDepth: 0, E: 0, tb: 0.6 }), 2.5, 1e-9);
  near(CIP.geometry.headLength({ P1: 80, pocketDepth: 0, E: 0, tb: 0.6 }), 10, 1e-9);
  near(CIP.geometry.headLength({ P1: 5, pocketDepth: 3.04, E: 0, tb: 0.6 }), 4.54, 1e-9);
  near(CIP.geometry.headLength({ P1: 5, pocketDepth: 0, E: 6, tb: 0.6 }), 6.6, 1e-9);
  near(CIP.geometry.headLength({ P1: 5, pocketDepth: 0, E: 6, beltRampEnd: 7, tb: 0.6 }), 7.6, 1e-9);
});

test('rule 8: primer pockets by primer type; rimfire has none', () => {
  const p = CIP.geometry.pocketFor;
  assert.deepEqual(['sp', 'spm', 'sr'].map(p), Array(3).fill({ diameter: 4.45, depth: 3.04 }));
  assert.deepEqual(['lp', 'lpm'].map(p), Array(2).fill({ diameter: 5.33, depth: 3.04 }));
  assert.deepEqual(['lr', 'lrm'].map(p), Array(2).fill({ diameter: 5.33, depth: 3.3 }));
  assert.equal(p('rimfire'), null);
  assert.equal(model('22_long_rifle').pocket, null);
  assert.deepEqual(model('9_mm_luger').pocket, { diameter: 4.45, depth: 3.04 });
});

test('rule 8: the inner line follows tb on the body and tn on the neck, blended across the shoulder', () => {
  const m = model('308_win');
  const { tn, tb } = m.walls;
  const outerAt = (z) => {
    for (let i = 1; i < m.outer.length; i++) {
      const [r0, z0] = m.outer[i - 1], [r1, z1] = m.outer[i];
      if (z >= z0 && z <= z1 && z1 > z0) return r0 + ((r1 - r0) * (z - z0)) / (z1 - z0);
    }
    return NaN;
  };
  const innerAt = (z) => {
    const pts = m.walls.inner;
    for (let i = 1; i < pts.length; i++) {
      const [r0, z0] = pts[i - 1], [r1, z1] = pts[i];
      if (z >= z0 && z <= z1 && z1 > z0) return r0 + ((r1 - r0) * (z - z0)) / (z1 - z0);
    }
    return NaN;
  };
  near(outerAt(20) - innerAt(20), tb, 1e-6, 'body wall');
  near(outerAt(47) - innerAt(47), tn, 1e-6, 'neck wall');
  const mid = outerAt(41.5) - innerAt(41.5);
  assert.ok(mid < tb && mid > tn - 1e-9 || Math.abs(tb - tn) < 1e-9, 'blended wall');
  near(m.walls.inner[0][1], m.walls.w, 1e-9);
});

test('rule 8: the inner radius at the mouth equals the bullet radius for every case with a bullet', () => {
  for (const r of data) {
    const m = CIP.geometry.buildModel(r);
    if (!m.walls || !m.bullet) continue;
    const last = m.walls.inner[m.walls.inner.length - 1];
    near(last[1], r.cartridge.lengths.L3, 1e-9, r.key);
    near(last[0], m.bullet.rSeated, 1e-6, r.key + ' inner radius at mouth');
  }
});

test('rule 8: the section polygon includes the primer pocket as a void', () => {
  const m = model('308_win');
  const poly = m.walls.polygon;
  assert.deepEqual(poly[0], [0, 3.3]);
  assert.deepEqual(poly[1], [5.33 / 2, 3.3]);
  assert.deepEqual(poly[2], [5.33 / 2, 0]);
  const rimfire = model('22_long_rifle').walls.polygon;
  assert.deepEqual(rimfire[0], [0, 0]);
});

test('rule 9: missing values are named and nothing is invented', () => {
  const rec = structuredClone(byKey('308_win'));
  delete rec.annotations.primerType;
  delete rec.cartridge.lengths.L6;
  const m = CIP.geometry.buildModel(rec);
  assert.equal(m.pocket, null);
  assert.equal(m.bullet, null);
  assert.deepEqual(m.missing.find((x) => x.feature === 'Primer pocket').values, ['primer type']);
  assert.deepEqual(m.missing.find((x) => x.feature === 'Bullet').values, ['L6']);
  assert.ok(!m.dimensions.some((d) => d.symbol === 'L6'));
});

test('rule 9: a partly published shoulder is drawn straight and the missing values are named', () => {
  const rec = structuredClone(byKey('308_win'));
  delete rec.cartridge.lengths.L2;
  const m = CIP.geometry.buildModel(rec);
  assert.equal(m.bottleneck, false);
  assert.deepEqual(m.missing.find((x) => x.feature === 'Shoulder').values, ['L2']);
});

test('rule 9: a case that lacks a core value cannot be drawn and says which', () => {
  const rec = structuredClone(byKey('308_win'));
  delete rec.cartridge.powderChamber.P1;
  const m = CIP.geometry.buildModel(rec);
  assert.equal(m.outer, null);
  assert.deepEqual(m.missing.find((x) => x.feature === 'Case outline').values, ['P1']);
});

test('no record needs a shoulder note, a bullet note or a pocket note (all inputs published)', () => {
  for (const r of data) {
    const feats = CIP.geometry.buildModel(r).missing.map((x) => x.feature);
    for (const f of ['Case outline', 'Shoulder', 'Bullet', 'Primer pocket', 'Section walls']) {
      assert.ok(!feats.includes(f), `${r.key}: ${f}`);
    }
  }
});

test('dimensions: L3, L6, R1, R and P1 always; the others where published', () => {
  const symbols = (k) => model(k).dimensions.map((d) => d.symbol);
  const always = ['L3', 'L6', 'R1', 'R', 'P1'];
  for (const r of data) for (const s of always) assert.ok(symbols(r.key).includes(s), `${r.key} ${s}`);
  for (const s of ['P2', 'H1', 'H2', 'G1', 'L1', 'L2', 'E1', 'alpha']) assert.ok(symbols('308_win').includes(s), s);
  for (const s of ['P2', 'H1', 'L1', 'L2', 'alpha']) assert.ok(!symbols('9_mm_luger').includes(s), s);
  assert.ok(symbols('9_mm_luger').includes('E1'));
  assert.ok(!symbols('38_special').includes('E1'));
  assert.ok(!symbols('22_long_rifle').includes('E1'));
});

test('dimension values are the published values and angles keep their notation', () => {
  const d = (k, s) => model(k).dimensions.find((x) => x.symbol === s);
  assert.equal(d('308_win', 'L3').valueText, '51.18');
  assert.equal(d('308_win', 'alpha').valueText, '40°');
  assert.equal(d('338_lapua_mag', 'alpha').valueText, '39°59\'49"');
});

test('every record yields a drawable model with a bounded silhouette', () => {
  for (const r of data) {
    const m = CIP.geometry.buildModel(r);
    assert.ok(m.outer && m.walls && m.bullet, r.key);
    assert.ok(m.extent.maxZ >= r.cartridge.lengths.L6 - 1e-9);
    assert.ok(m.extent.maxR >= r.cartridge.caseHead.R1 / 2 - 1e-9);
  }
});

test('rule 8: the bullet never intrudes into the case wall over its seated length, for every record', () => {
  const radiusAt = (pts, z) => {
    for (let i = 1; i < pts.length; i++) {
      const [r0, z0] = pts[i - 1], [r1, z1] = pts[i];
      if (z1 > z0 && z >= z0 - 1e-12 && z <= z1 + 1e-12) return r0 + ((r1 - r0) * (z - z0)) / (z1 - z0);
    }
    return NaN;
  };
  for (const r of data) {
    const m = CIP.geometry.buildModel(r);
    const L3 = r.cartridge.lengths.L3;
    for (let i = 0; i <= 40; i++) {
      const z = m.bullet.zb + ((L3 - m.bullet.zb) * i) / 40;
      const inner = radiusAt(m.walls.inner, z);
      assert.ok(inner >= m.bullet.rSeated - 1e-9, `${r.key}: inner ${inner.toFixed(3)} < bullet ${m.bullet.rSeated.toFixed(3)} at z ${z.toFixed(2)}`);
    }
  }
});

test('rule 9: half-published pairs are reported, not silently dropped', () => {
  const clone = () => structuredClone(byKey('308_win'));
  const noF = clone(); delete noF.cartridge.caseHead.f;
  assert.deepEqual(CIP.geometry.buildModel(noF).missing.find((x) => x.feature === 'Head chamfer').values, ['f']);
  const noE1 = clone(); delete noE1.cartridge.caseHead.E1;
  assert.deepEqual(CIP.geometry.buildModel(noE1).missing.find((x) => x.feature === 'Extractor groove').values, ['E1']);
  const noCategory = clone(); delete noCategory.annotations.category;
  const bullet = CIP.geometry.buildModel(noCategory);
  assert.equal(bullet.bullet, null);
  assert.deepEqual(bullet.missing.find((x) => x.feature === 'Bullet').values, ['category']);
  const noBelt = structuredClone(byKey('300_win_mag')); delete noBelt.cartridge.caseHead.R3;
  assert.deepEqual(CIP.geometry.buildModel(noBelt).missing.find((x) => x.feature === 'Belt').values, ['R3']);
  const rimfire = CIP.geometry.buildModel(byKey('22_long_rifle'));
  assert.ok(!rimfire.missing.some((x) => x.feature === 'Head chamfer'), 'rimfire has a half-round, no chamfer');
});
