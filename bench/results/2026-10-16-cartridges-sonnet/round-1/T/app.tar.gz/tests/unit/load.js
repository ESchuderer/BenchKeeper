'use strict';
// Loads the browser scripts into Node the same way a browser does (classic scripts, one global namespace).
const path = require('node:path');
const root = path.join(__dirname, '..', '..');
for (const f of ['data', 'format', 'geometry', 'drawing']) {
  try { require(path.join(root, 'js', f + '.js')); } catch (e) { if (e.code !== 'MODULE_NOT_FOUND') throw e; }
}
module.exports = { CIP: globalThis.CIP, data: globalThis.CIP_DATA, byKey: (k) => globalThis.CIP_DATA.find((r) => r.key === k) };
