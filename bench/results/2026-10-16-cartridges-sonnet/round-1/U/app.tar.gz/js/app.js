/* Views and routing: start page (list, search, family filter) and detail view. Hash routes work from file://. */
(function () {
  var CIP = window.CIP;
  var app = document.getElementById('app');
  var FAMILIES = ['All', 'rimless', 'rimmed', 'belted', 'pistol', 'rimfire'];
  var state = { query: '', family: 'All' };

  function el(tag, attrs, children) {
    var e = document.createElement(tag);
    Object.keys(attrs || {}).forEach(function (k) {
      if (k === 'text') e.textContent = attrs[k];
      else if (attrs[k] !== false && attrs[k] !== null && attrs[k] !== undefined) e.setAttribute(k, attrs[k] === true ? '' : attrs[k]);
    });
    (children || []).forEach(function (c) { if (c) e.appendChild(typeof c === 'string' ? document.createTextNode(c) : c); });
    return e;
  }

  function show(node, title) {
    app.textContent = '';
    app.appendChild(node);
    document.title = title ? title + ' \u2013 C.I.P. cartridge reference' : 'C.I.P. cartridge reference';
  }

  /* ---------- start page ---------- */
  function listView() {
    var wrap = el('div', { 'class': 'list-view' });
    wrap.appendChild(el('h1', { text: 'Cartridges', tabindex: '-1' }));

    var search = el('input', { id: 'search', type: 'search', autocomplete: 'off', spellcheck: 'false', placeholder: 'Name or alternative name' });
    search.value = state.query;
    var family = el('select', { id: 'family' }, FAMILIES.map(function (f) { return el('option', { value: f, text: f }); }));
    family.value = state.family;
    var count = el('p', { 'class': 'count', role: 'status', 'aria-live': 'polite' });
    wrap.appendChild(el('div', { 'class': 'filters' }, [
      el('div', { 'class': 'field' }, [el('label', { 'for': 'search', text: 'Search' }), search]),
      el('div', { 'class': 'field' }, [el('label', { 'for': 'family', text: 'Family' }), family]),
      count
    ]));

    var tbody = el('tbody');
    var table = el('table', { 'class': 'list' }, [
      el('thead', {}, [el('tr', {}, [
        el('th', { scope: 'col', text: 'Name' }), el('th', { scope: 'col', text: 'Family' }),
        el('th', { scope: 'col', 'class': 'num', text: 'Case length L3 (mm)' })])]),
      tbody
    ]);
    wrap.appendChild(table);
    var empty = el('p', { 'class': 'empty', text: 'No cartridge matches.', hidden: true });
    wrap.appendChild(empty);

    function refresh() {
      state.query = search.value; state.family = family.value;
      var rows = CIP.data.filter(function (r) {
        return (state.family === 'All' || r.family === state.family) && CIP.format.matchesQuery(r, state.query);
      });
      tbody.textContent = '';
      rows.forEach(function (r) {
        var alt = (r.alternativeNames || []).length ? el('span', { 'class': 'alt', text: ' ' + r.alternativeNames.join(', ') }) : null;
        tbody.appendChild(el('tr', {}, [
          el('td', {}, [el('a', { href: '#/cartridge/' + encodeURIComponent(r.key), text: r.name }), alt]),
          el('td', { text: r.family }),
          el('td', { 'class': 'num', text: CIP.format.formatNumber(r.cartridge.lengths.L3) })
        ]));
      });
      count.textContent = rows.length + ' cartridges';
      empty.hidden = rows.length !== 0;
      table.hidden = rows.length === 0;
    }
    search.addEventListener('input', refresh);
    family.addEventListener('change', refresh);
    refresh();
    return wrap;
  }

  /* ---------- detail view ---------- */
  function fact(term, valueNode) {
    return [el('dt', { text: term }), el('dd', {}, [valueNode])];
  }
  function textNode(t) { return document.createTextNode(t); }

  function valueTables(heading, tables) {
    var sec = el('section', { 'class': 'values' }, [el('h2', { text: heading })]);
    var grid = el('div', { 'class': 'table-grid' });
    tables.forEach(function (t) {
      var table = el('table', { 'class': 'values-table' }, [
        el('caption', { text: t.title }),
        el('thead', {}, [el('tr', {}, [el('th', { scope: 'col', text: 'Symbol' }), el('th', { scope: 'col', 'class': 'num', text: 'Value' }), el('th', { scope: 'col', text: 'Unit' })])]),
        el('tbody', {}, t.rows.map(function (r) {
          return el('tr', {}, [el('th', { scope: 'row', text: r.symbol }), el('td', { 'class': 'num', text: r.value }), el('td', { 'class': 'unit', text: r.unit })]);
        }))
      ]);
      grid.appendChild(table);
    });
    sec.appendChild(grid);
    return sec;
  }

  function detailView(rec) {
    var an = rec.annotations || {};
    var art = el('article', { 'class': 'detail' });
    art.appendChild(el('h1', { text: rec.name, tabindex: '-1' }));

    var cap = an.publishedCapacity;
    var capNode = textNode('not published');
    if (cap) {
      capNode = el('span', {}, [
        textNode(CIP.format.formatNumber(cap.grH2O) + ' grH2O'),
        cap.note ? textNode(' (' + cap.note + ')') : null,
        textNode(', source: '),
        cap.url ? el('a', { href: cap.url, rel: 'noopener noreferrer', text: cap.source }) : textNode(cap.source)
      ].filter(Boolean));
    }
    var facts = [];
    if (rec.alternativeNames && rec.alternativeNames.length) facts = facts.concat(fact('Alternative names', textNode(rec.alternativeNames.join(', '))));
    facts = facts.concat(
      fact('Family', textNode(rec.family)),
      fact('Category', textNode(an.category || '')),
      fact('Primer type', textNode(an.primerType || '')),
      fact('C.I.P. table', textNode(rec.tab)),
      fact('Country', textNode(rec.country)),
      fact('Published', textNode(rec.published)),
      fact('Revised', textNode(rec.revised)),
      fact('Pressure method', textNode(rec.pressureMethod)),
      fact('Water capacity', capNode)
    );
    art.appendChild(el('dl', { 'class': 'facts' }, facts));

    var drawing = CIP.drawing.render(rec);
    var fig = el('figure', { 'class': 'drawing' });
    var holder = el('div', { 'class': 'drawing-svg' });
    holder.innerHTML = drawing.svg;
    fig.appendChild(holder);
    var notes = el('figcaption', { 'class': 'drawing-notes' });
    notes.appendChild(el('p', { 'class': 'drawing-legend', text: 'Outside view above the axis, section below (cut walls hatched). Bullet shown as the default shape.' }));
    drawing.missing.forEach(function (m) { notes.appendChild(el('p', { 'class': 'missing', text: CIP.drawing.missingText(m) })); });
    fig.appendChild(notes);
    art.appendChild(fig);

    art.appendChild(el('nav', { 'class': 'actions', 'aria-label': 'Actions' }, [
      el('a', { 'class': 'back', href: '#/', text: 'All cartridges' }),
      el('button', { type: 'button', 'class': 'print-button', text: 'Print' })
    ]));
    art.querySelector('.print-button').addEventListener('click', function () { window.print(); });

    art.appendChild(valueTables('Cartridge values', CIP.format.cartridgeTables(rec)));
    art.appendChild(valueTables('Chamber values', CIP.format.chamberTables(rec)));
    art.appendChild(el('footer', { 'class': 'print-footer', text: 'Source: C.I.P. TDCC, revised ' + rec.revised }));
    return art;
  }

  function notFound() {
    return el('div', {}, [el('h1', { text: 'Cartridge not found', tabindex: '-1' }), el('p', {}, [el('a', { href: '#/', text: 'All cartridges' })])]);
  }

  /* ---------- router ---------- */
  function route() {
    var m = /^#\/cartridge\/([^/?#]+)/.exec(location.hash);
    var node, title = '';
    if (m) {
      var key = decodeURIComponent(m[1]);
      var rec = CIP.data.filter(function (r) { return r.key === key; })[0];
      node = rec ? detailView(rec) : notFound();
      title = rec ? rec.name : 'Not found';
    } else {
      node = listView();
    }
    show(node, title);
    window.scrollTo(0, 0);
    var h1 = node.querySelector('h1');
    if (h1 && m) h1.focus({ preventScroll: true });
  }

  window.addEventListener('hashchange', route);
  route();
})();
