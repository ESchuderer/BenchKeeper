/* SVG drawing of a cartridge: outside view above the axis, section below, dimensions, title block.
   1 SVG user unit = 1 mm. Returns markup plus the computed label boxes (used by the tests). */
(function (root) {
  var CIP = root.CIP = root.CIP || {};
  var fmt = CIP.format || (typeof require !== 'undefined' ? require('./format.js') : null);
  var geometry = CIP.geometry || (typeof require !== 'undefined' ? require('./geometry.js') : null);

  var FS = 2.5;                 // label font size (mm)
  var CHAR_W = 0.62 * FS;       // monospace advance, upper estimate
  var PAD = 0.35;               // padding inside a label box
  var BOX_H = 1.1 * FS + 2 * PAD;
  var ROW = 4.6;                // pitch of the length-dimension rows
  var ARROW_L = 1.3, ARROW_W = 0.42;
  var MIN_W = 60;               // minimum viewBox width, for the title block
  var MAX_ASPECT = 0.62;        // height / width of the viewBox
  var PRINT_W = 180;            // A4 portrait text width (mm)

  function esc(s) { return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;'); }
  function n(x) { return Math.round(x * 1000) / 1000; }
  function pt(p, sign) { return n(p[0]) + ',' + n(sign * p[1]); }
  function path(points, sign, close) { return 'M' + points.map(function (p) { return pt(p, sign); }).join(' L') + (close ? ' Z' : ''); }
  function textWidth(t) { return t.length * CHAR_W; }

  function arrow(tip, d) {
    var nx = -d[1], ny = d[0];
    var a = [tip[0] + d[0] * ARROW_L + nx * ARROW_W, tip[1] + d[1] * ARROW_L + ny * ARROW_W];
    var b = [tip[0] + d[0] * ARROW_L - nx * ARROW_W, tip[1] + d[1] * ARROW_L - ny * ARROW_W];
    return '<polygon class="arrowhead" points="' + n(tip[0]) + ',' + n(tip[1]) + ' ' + n(a[0]) + ',' + n(a[1]) + ' ' + n(b[0]) + ',' + n(b[1]) + '"/>';
  }
  function line(cls, x1, y1, x2, y2) {
    return '<line class="' + cls + '" x1="' + n(x1) + '" y1="' + n(y1) + '" x2="' + n(x2) + '" y2="' + n(y2) + '"/>';
  }

  function segTop(a, b, z0, z1) {
    var lo = Math.min(a[0], b[0]), hi = Math.max(a[0], b[0]);
    if (hi < z0 || lo > z1) return 0;
    if (hi - lo < 1e-12) return Math.max(a[1], b[1]);
    function at(z) { return a[1] + (b[1] - a[1]) * (z - a[0]) / (b[0] - a[0]); }
    return Math.max(at(Math.max(lo, z0)), at(Math.min(hi, z1)));
  }
  function polyTop(poly, z0, z1) {
    var m = 0;
    for (var i = 1; i < poly.length; i++) m = Math.max(m, segTop(poly[i - 1], poly[i], z0, z1));
    return m;
  }

  function overlap(a, b, m) { return a.x0 < b.x1 + m && b.x0 < a.x1 + m && a.y0 < b.y1 + m && b.y0 < a.y1 + m; }

  function crosses(lead, box) {
    return lead.x > box.x0 - 0.15 && lead.x < box.x1 + 0.15 && lead.y0 < box.y1 + 0.3 && lead.y1 > box.y0 - 0.3;
  }
  function compatible(a, b) {
    return !overlap(a.box, b.box, 0.3) && !crosses(a.lead, b.box) && !crosses(b.lead, a.box) && Math.abs(a.lead.x - b.lead.x) >= 0.4;
  }

  /** Place diameter-type labels above the part, each tied to its dimension by a vertical extension line.
      Depth-first search over (anchor, level) per label, with the number of levels increased until a layout without
      any collision exists, so labels never overlap each other, an extension line or the outline. */
  function placeUpper(items, silhouette) {
    items = items.slice().sort(function (a, b) { return a.z - b.z; });
    function candidate(it, a, j) {
      var w = textWidth(it.text) + 2 * PAD;
      var x0 = a === 0 ? it.z - w / 2 : a === 1 ? it.z - 0.1 : it.z - w + 0.1;
      var top = polyTopAll(silhouette, Math.min(x0, it.z), Math.max(x0 + w, it.z));
      var y1 = -(top + 1.2) - j * (BOX_H + 0.6);
      return { item: it, box: { x0: x0, x1: x0 + w, y0: y1 - BOX_H, y1: y1 }, lead: { x: it.z, y0: y1, y1: -it.r } };
    }
    var budget;
    function dfs(i, maxL, chosen) {
      if (i === items.length) return chosen;
      if (--budget < 0) return null;
      for (var j = 0; j <= maxL; j++) {
        for (var a = 0; a < 3; a++) {
          var c = candidate(items[i], a, j);
          if (c.lead.y1 - c.lead.y0 < 0.8) continue;
          if (chosen.every(function (p) { return compatible(c, p); })) {
            var r = dfs(i + 1, maxL, chosen.concat([c]));
            if (r) return r;
          }
        }
      }
      return null;
    }
    for (var maxL = 0; maxL < 14; maxL++) {
      budget = 20000;
      var res = dfs(0, maxL, []);
      if (res) return res;
    }
    return items.map(function (it, k) { return candidate(it, 0, k); });
  }
  function polyTopAll(polys, z0, z1) {
    var m = 0;
    polys.forEach(function (p) { m = Math.max(m, polyTop(p, z0, z1)); });
    return m;
  }

  function rAt(poly, z) {
    for (var i = 1; i < poly.length; i++) {
      var a = poly[i - 1], b = poly[i];
      if (z >= a[0] && z <= b[0] && b[0] - a[0] > 1e-12) return a[1] + (b[1] - a[1]) * (z - a[0]) / (b[0] - a[0]);
    }
    return poly[poly.length - 1][1];
  }

  /** Text alternative: every dimension that is labelled in the drawing. */
  function descText(rows, items) {
    return items.concat(rows).map(function (x) { return x.text; }).join(', ') + ' (mm unless angle)';
  }

  function fmtScale(s) { return String(parseFloat(s.toFixed(2))); }

  function render(rec, geo) {
    geo = geo || geometry.build(rec);
    var name = rec.name;
    if (!geo.ok) {
      return { ok: false, svg: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 60 12" role="img" aria-label="' + esc(name) + ' drawing"><title>' + esc(name) + ' drawing</title><text x="2" y="7" font-size="3">Drawing not available</text></svg>',
        labels: [], missing: geo.missing, scale: 1, printWidthMm: 60 };
    }
    var rf = geo.refs, b = geo.bullet, outer = geo.outer;
    var sil = [outer];
    if (b) {
      sil.push(b.exposed);
      sil.push([[rf.L3, rf.H2 / 2], [rf.L3, b.Re]]);
    }
    var rMax = geo.extents.rMax;
    var zRight = geo.extents.zMax;

    /* ---- upper (diameter) dimensions ---- */
    var up = [];
    function addUp(id, symbol, value, z, r) { up.push({ id: id, symbol: symbol, text: symbol + ' ' + value, z: z, r: r }); }
    addUp('R1', 'R1', fmt.formatNumber(rf.R1), rf.rimZ, rf.R1 / 2);
    if (geo.groove) addUp('E1', 'E1', fmt.formatNumber(rf.E1), rf.groove.z, rf.E1 / 2);
    var zP1 = rf.bodyStart[0] + 1.0;
    addUp('P1', 'P1', fmt.formatNumber(rf.P1), zP1, rAt(outer, zP1));
    if (geo.bottleneck) {
      addUp('P2', 'P2', fmt.formatNumber(rf.P2), rf.L1, rf.P2 / 2);
      addUp('H1', 'H1', fmt.formatNumber(rf.H1), rf.L2, rf.H1 / 2);
    }
    addUp('H2', 'H2', fmt.formatNumber(rf.H2), rf.L3, rf.H2 / 2);
    if (b) addUp('G1', 'G1', fmt.formatNumber(rf.G1), Math.max(rf.L3 + 0.4, b.zc), b.Re);
    var alphaText = null;
    var alphaMid = null;
    if (geo.shoulder) {
      var sA = geo.shoulder.A, sB = geo.shoulder.B;
      alphaMid = [(sA[0] + sB[0]) / 2, (sA[1] + sB[1]) / 2];
      alphaText = fmt.formatAngle(rec.cartridge.junctionCone.alpha);
      addUp('alpha', '\u03b1', alphaText, alphaMid[0], alphaMid[1]);
    }
    var upper = placeUpper(up, sil);

    /* ---- lower (length) dimensions ---- */
    var lowTop = rMax + 4.4;
    var rows = [];
    rows.push({ id: 'R', symbol: 'R', value: fmt.formatNumber(rf.R), z0: 0, z1: rf.R, r0: rf.headFaceR, r1: rMaxAt(outer, rf.R), small: true });
    if (has(rf.L1) && geo.bottleneck) rows.push({ id: 'L1', symbol: 'L1', value: fmt.formatNumber(rf.L1), z0: 0, z1: rf.L1, r0: rf.headFaceR, r1: rf.P2 / 2 });
    if (has(rf.L2) && geo.bottleneck) rows.push({ id: 'L2', symbol: 'L2', value: fmt.formatNumber(rf.L2), z0: 0, z1: rf.L2, r0: rf.headFaceR, r1: rf.H1 / 2 });
    rows.push({ id: 'L3', symbol: 'L3', value: fmt.formatNumber(rf.L3), z0: 0, z1: rf.L3, r0: rf.headFaceR, r1: rf.H2 / 2 });
    if (b) rows.push({ id: 'L6', symbol: 'L6', value: fmt.formatNumber(rf.L6), z0: 0, z1: rf.L6, r0: rf.headFaceR, r1: b.m / 2 });
    rows.forEach(function (r, i) {
      r.y = lowTop + i * ROW;
      r.text = r.symbol + ' ' + r.value;
      var w = textWidth(r.text) + 2 * PAD;
      var cx = r.small ? r.z1 + 2.8 + w / 2 : (r.z0 + r.z1) / 2;
      r.box = { x0: cx - w / 2, x1: cx + w / 2, y0: r.y - 0.5 - BOX_H, y1: r.y - 0.5 };
    });
    var lastY = rows[rows.length - 1].y;

    /* ---- extents ---- */
    var x0 = -3.2, x1 = zRight + 3, yTop = -(rMax + 1);
    upper.forEach(function (p) { x0 = Math.min(x0, p.box.x0); x1 = Math.max(x1, p.box.x1); yTop = Math.min(yTop, p.box.y0); });
    rows.forEach(function (r) { x0 = Math.min(x0, r.box.x0); x1 = Math.max(x1, r.box.x1); });
    var M = 2.5;
    var contentW = x1 - x0 + 2 * M;
        var tbY = lastY + 4.5, tbH = 15;
    var vy = yTop - M, H = tbY + tbH + M - vy;
    // Width: content, title block, and an aspect limit so that the drawing printed at full A4 width stays short enough
    // for the tables to follow on the same page.
    var W = Math.max(contentW, MIN_W, H / MAX_ASPECT);
    var vx = x0 - M - (W - contentW) / 2;
    var printScale = Math.floor(PRINT_W / W * 100) / 100;
    var scaleText = 'Scale ' + fmtScale(printScale) + ' : 1 (A4 print)';

    /* ---- markup ---- */
    var o = [];
    o.push('<svg xmlns="http://www.w3.org/2000/svg" class="cartridge-drawing" role="img" aria-label="' + esc(name) + ' drawing"' +
      ' viewBox="' + n(vx) + ' ' + n(vy) + ' ' + n(W) + ' ' + n(H) + '" preserveAspectRatio="xMidYMin meet"' +
      ' style="--print-width:' + n(W * printScale) + 'mm">');
    o.push('<title>' + esc(name) + ' drawing</title>');
    o.push('<desc>' + esc(name + ': ' + descText(rows, up)) + '</desc>');
    o.push('<defs><pattern id="cip-hatch" patternUnits="userSpaceOnUse" width="0.9" height="0.9" patternTransform="rotate(45)"><line class="hatch-line" x1="0" y1="0" x2="0" y2="0.9"/></pattern></defs>');

    // section (lower half): cut walls hatched
    var pr = geo.head.pocket ? geo.head.pocket.d / 2 : 0;
    var poly = [[0, pr]].concat(outer.slice(1)).concat([[rf.L3, geo.inner[geo.inner.length - 1][1]]]);
    for (var i = geo.inner.length - 2; i >= 0; i--) poly.push(geo.inner[i]);
    poly.push([geo.head.w, 0]);
    if (geo.head.pocket) { poly.push([geo.head.pocket.depth, 0]); poly.push([geo.head.pocket.depth, pr]); }
    o.push('<g class="section" data-view="section">');
    o.push('<path class="cut" d="' + path(poly, 1, true) + '" fill="url(#cip-hatch)"/>');
    if (b) o.push('<path class="bullet bullet-section" d="' + path(b.section, 1, true) + '"/>');
    o.push('</g>');

    // outside view (upper half)
    o.push('<g class="outside" data-view="outside">');
    o.push('<path class="outline case-outline" d="' + path(outer, -1, false) + '"/>');
    if (b) {
      o.push(line('outline', rf.L3, -rf.H2 / 2, rf.L3, -b.Re));
      o.push('<path class="outline bullet bullet-outside" d="' + path(b.exposed.concat([[rf.L6, 0]]), -1, false) + '"/>');
    } else {
      o.push(line('outline', rf.L3, -rf.H2 / 2, rf.L3, 0));
    }
    o.push('</g>');
    o.push(line('centerline', x0 + 0.2, 0, zRight + 2.6, 0));

    // diameter dimensions
    upper.forEach(function (p) {
      var it = p.item, z = it.z, r = it.r;
      o.push('<g class="dimension diameter" data-dim="' + it.id + '">');
      if (it.id !== 'alpha') {
        o.push(line('dim', z, -r, z, r));
        o.push(arrow([z, -r], [0, 1]));
        o.push(arrow([z, r], [0, -1]));
      } else {
        // arc across the axis, centred on the cone apex, ending on the shoulder lines (which are the extension lines)
        var apx = geo.shoulder.apex[0];
        var rho = Math.hypot(apx - alphaMid[0], alphaMid[1]);
        var gam = Math.atan2(alphaMid[1], apx - alphaMid[0]);
        var arc = [];
        for (var k = 0; k <= 16; k++) { var t = -gam + 2 * gam * k / 16; arc.push([apx - rho * Math.cos(t), rho * Math.sin(t)]); }
        o.push('<path class="dim alpha-arc" d="' + path(arc, 1, false) + '"/>');
        o.push(arrow(arc[0], tangent(-gam, 1)));
        o.push(arrow(arc[16], tangent(gam, -1)));
      }
      o.push(line('ext', z, -r, z, p.box.y1));
      o.push('<text class="label" data-label="' + it.id + '" x="' + n(p.box.x0 + PAD) + '" y="' + n(p.box.y1 - PAD - 0.2 * FS) + '">' + esc(it.text) + '</text>');
      o.push('</g>');
    });

    // length dimensions
    rows.forEach(function (r) {
      o.push('<g class="dimension length" data-dim="' + r.id + '">');
      o.push(line('ext', r.z0, r.r0 + 0.8, r.z0, r.y + 1.2));
      o.push(line('ext', r.z1, r.r1 + 0.8, r.z1, r.y + 1.2));
      if (r.small) {
        o.push(line('dim', r.z0 - 2.4, r.y, r.z1 + 2.4, r.y));
        o.push(arrow([r.z0, r.y], [-1, 0]));
        o.push(arrow([r.z1, r.y], [1, 0]));
        o.push('<text class="label" data-label="' + r.id + '" x="' + n(r.box.x0 + PAD) + '" y="' + n(r.box.y1 - PAD - 0.2 * FS) + '">' + esc(r.text) + '</text>');
      } else {
        o.push(line('dim', r.z0, r.y, r.z1, r.y));
        o.push(arrow([r.z0, r.y], [1, 0]));
        o.push(arrow([r.z1, r.y], [-1, 0]));
        o.push('<text class="label" data-label="' + r.id + '" x="' + n(r.box.x0 + PAD) + '" y="' + n(r.box.y1 - PAD - 0.2 * FS) + '">' + esc(r.text) + '</text>');
      }
      o.push('</g>');
    });

    // title block
    var tbx = vx + M, tbw = W - 2 * M;
    o.push('<g class="titleblock">');
    o.push('<rect class="tb-frame" x="' + n(tbx) + '" y="' + n(tbY) + '" width="' + n(tbw) + '" height="' + tbH + '"/>');
    o.push('<text class="tb-name" x="' + n(tbx + 2) + '" y="' + n(tbY + 5.4) + '">' + esc(name) + '</text>');
    o.push('<text class="tb-line" x="' + n(tbx + 2) + '" y="' + n(tbY + 9.4) + '">C.I.P. table ' + esc(rec.tab) + ', revised ' + esc(rec.revised) + '</text>');
    o.push('<text class="tb-line" x="' + n(tbx + 2) + '" y="' + n(tbY + 13) + '">Dimensions in mm, ' + esc(scaleText) + '</text>');
    o.push('</g>');
    o.push('</svg>');

    var labels = upper.map(function (p) { return { id: p.item.id, text: p.item.text, box: p.box }; })
      .concat(rows.map(function (r) { return { id: r.id, text: r.text, box: r.box }; }));
    return { ok: true, svg: o.join(''), labels: labels, missing: geo.missing, scale: printScale, scaleText: scaleText,
      printWidthMm: W * printScale, viewBox: [vx, vy, W, H] };
  }

  function has(x) { return typeof x === 'number' && isFinite(x); }
  function rMaxAt(poly, z) { return polyTop(poly, z, z); }
  /* Unit tangent at arc parameter t (arc point = apex + rho*(-cos t, sin t)), direction `sgn` along increasing t. */
  function tangent(t, sgn) { return [Math.sin(t) * sgn, Math.cos(t) * sgn]; }

  function missingText(m) {
    return 'Not published: ' + m.symbols.join(', ') + ' (' + m.effect + ')';
  }

  CIP.drawing = { render: render, missingText: missingText };
  if (typeof module !== 'undefined' && module.exports) module.exports = CIP.drawing;
})(typeof window !== 'undefined' ? window : globalThis);
