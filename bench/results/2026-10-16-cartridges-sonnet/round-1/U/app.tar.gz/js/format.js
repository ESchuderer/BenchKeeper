/* Formatting of record values: angles, numbers with tolerance, symbols, units, section tables, search. No DOM. */
(function (root) {
  var CIP = root.CIP = root.CIP || {};

  var SYMBOLS = {
    eMin: 'e min', r1Min: 'r1 min', r1Max: 'r1 max',
    alpha: '\u03b1', alpha1: '\u03b11', beta: '\u03b2', delta: '\u03b4',
    deltaL: 'delta L', L3PlusG: 'L3 + G'
  };
  var ANGLES = { alpha: 1, alpha1: 1, beta: 1, delta: 1, i: 1 };
  var UNITS = { Pmax: 'bar', PK: 'bar', PE: 'bar', EE: 'J', M: 'g', Q: 'mm\u00b2', N: '' };

  var CARTRIDGE_SECTIONS = [
    ['caseHead', 'Case head'], ['collar', 'Collar'], ['junctionCone', 'Junction cone'],
    ['lengths', 'Lengths'], ['misc', 'Miscellaneous'], ['powderChamber', 'Powder chamber'],
    ['pressures', 'Pressures'], ['projectile', 'Projectile']
  ];
  var CHAMBER_SECTIONS = [
    ['barrel', 'Barrel'], ['breech', 'Breech'], ['collar', 'Collar'], ['grooves', 'Grooves'],
    ['junctionCone', 'Junction cone'], ['lengths', 'Lengths'], ['powderChamber', 'Powder chamber'],
    ['rifling', 'Rifling']
  ];

  function isAngleObject(v) { return v !== null && typeof v === 'object'; }

  /** Angle in degrees as a number (minutes and seconds folded in). */
  function angleToDegrees(a) {
    if (isAngleObject(a)) return (a.degrees || 0) + (a.minutes || 0) / 60 + (a.seconds || 0) / 3600;
    return a;
  }

  /** `40°` or `39°59'49"` exactly as published. */
  function formatAngle(a) {
    if (isAngleObject(a)) return a.degrees + '\u00b0' + a.minutes + "'" + a.seconds + '"';
    return a + '\u00b0';
  }

  function formatNumber(n) { return String(n); }

  function formatTol(t) { return (t > 0 ? '+' : '') + formatNumber(t); }

  function symbolFor(field) { return Object.prototype.hasOwnProperty.call(SYMBOLS, field) ? SYMBOLS[field] : field; }

  function unitFor(field) {
    if (ANGLES[field]) return 'deg';
    return Object.prototype.hasOwnProperty.call(UNITS, field) ? UNITS[field] : 'mm';
  }

  /** Value text for a field of a section object, with its tolerance appended. */
  function formatValue(field, section) {
    var v = section[field];
    var s = ANGLES[field] ? formatAngle(v) : formatNumber(v);
    var tol = section[field + 'Tol'];
    if (typeof tol === 'number') s += ' ' + formatTol(tol);
    return s;
  }

  /** Rows of one section: tolerance fields are merged into their base field, never listed. */
  function sectionRows(section) {
    var rows = [];
    Object.keys(section || {}).forEach(function (field) {
      if (/Tol$/.test(field) && Object.prototype.hasOwnProperty.call(section, field.slice(0, -3))) return;
      rows.push({ field: field, symbol: symbolFor(field), value: formatValue(field, section), unit: unitFor(field) });
    });
    return rows;
  }

  /** Sections with at least one row: [{id, title, rows}] */
  function tables(group, defs) {
    var out = [];
    defs.forEach(function (d) {
      var rows = sectionRows(group && group[d[0]]);
      if (rows.length) out.push({ id: d[0], title: d[1], rows: rows });
    });
    return out;
  }
  function cartridgeTables(rec) { return tables(rec.cartridge, CARTRIDGE_SECTIONS); }
  function chamberTables(rec) { return tables(rec.chamber, CHAMBER_SECTIONS); }

  function norm(s) { return String(s).toLowerCase().replace(/\s+/g, ' ').trim(); }

  /** True if the query occurs in the name or any alternative name. */
  function matchesQuery(rec, query) {
    var q = norm(query);
    if (!q) return true;
    var qc = q.replace(/ /g, '');
    return [rec.name].concat(rec.alternativeNames || []).some(function (n) {
      var t = norm(n);
      return t.indexOf(q) !== -1 || t.replace(/ /g, '').indexOf(qc) !== -1;
    });
  }

  CIP.format = {
    angleToDegrees: angleToDegrees, formatAngle: formatAngle, formatNumber: formatNumber,
    formatValue: formatValue, sectionRows: sectionRows, symbolFor: symbolFor, unitFor: unitFor,
    cartridgeTables: cartridgeTables, chamberTables: chamberTables, matchesQuery: matchesQuery
  };
  if (typeof module !== 'undefined' && module.exports) module.exports = CIP.format;
})(typeof window !== 'undefined' ? window : globalThis);
