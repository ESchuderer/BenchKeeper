/* Geometry of a cartridge drawing, computed from a record. Pure: no DOM.
   Points are [z, r]: z along the axis from the head face (z = 0) to the mouth, r the radius.
   The outer half-profile runs from the axis at the head face to the mouth; drawing mirrors it. */
(function (root) {
  var CIP = root.CIP = root.CIP || {};
  var fmt = CIP.format || (typeof require !== 'undefined' ? require('./format.js') : null);

  var RAD = Math.PI / 180;
  var POCKET_D = { sp: 4.45, spm: 4.45, sr: 4.45, lp: 5.33, lpm: 5.33, lr: 5.33, lrm: 5.33 };
  var POCKET_DEPTH = { sp: 3.04, spm: 3.04, sr: 3.04, lp: 3.04, lpm: 3.04, lr: 3.3, lrm: 3.3 };
  var SEAT = { pointy: 1.0, semi_wadcutter: 0.6 };
  var CYL = { pointy: 0.40, semi_wadcutter: 0.78 };
  var MEPLAT = { rounded: 0.15, flat: 0.55, semi_wadcutter: 0.6 };

  function has(x) { return typeof x === 'number' && isFinite(x); }
  function deg(a) { return a === undefined || a === null ? undefined : fmt.angleToDegrees(a); }
  function clamp(x, lo, hi) { return Math.max(lo, Math.min(hi, x)); }
  function dist(a, b) { return Math.hypot(a[0] - b[0], a[1] - b[1]); }

  function addPoint(pts, p) {
    var q = pts[pts.length - 1];
    if (q && Math.abs(q[0] - p[0]) < 1e-9 && Math.abs(q[1] - p[1]) < 1e-9) return;
    pts.push([p[0], p[1]]);
  }

  /** Points of the arc that rounds `corner` between the lines prev->corner and corner->next. */
  function fillet(corner, d1, d2, t, phi) {
    var rEff = t / Math.tan(phi / 2);
    var t1 = [corner[0] - d1[0] * t, corner[1] - d1[1] * t];
    var cross = d1[0] * d2[1] - d1[1] * d2[0];
    var n = cross > 0 ? [-d1[1], d1[0]] : [d1[1], -d1[0]];
    var c = [t1[0] + n[0] * rEff, t1[1] + n[1] * rEff];
    var a0 = Math.atan2(t1[1] - c[1], t1[0] - c[0]);
    var sweep = cross > 0 ? phi : -phi;
    var steps = Math.max(4, Math.ceil(phi / (Math.PI / 24)));
    var out = [];
    for (var i = 0; i <= steps; i++) {
      var a = a0 + sweep * i / steps;
      out.push([c[0] + rEff * Math.cos(a), c[1] + rEff * Math.sin(a)]);
    }
    return out;
  }

  function unit(a, b) { var d = dist(a, b); return [(b[0] - a[0]) / d, (b[1] - a[1]) / d]; }
  function deflection(d1, d2) { return Math.acos(clamp(d1[0] * d2[0] + d1[1] * d2[1], -1, 1)); }

  /** Polyline clipped to z >= zMin (polyline z must be non-decreasing). */
  function clipFrom(pts, zMin) {
    var out = [];
    for (var i = 0; i < pts.length; i++) {
      var p = pts[i];
      if (p[0] >= zMin) {
        if (!out.length && i > 0 && pts[i - 1][0] < zMin) {
          var q = pts[i - 1], u = (zMin - q[0]) / (p[0] - q[0]);
          addPoint(out, [zMin, q[1] + u * (p[1] - q[1])]);
        }
        addPoint(out, p);
      }
    }
    return out;
  }

  function nose(shape, zc, L6, Re, m) {
    var n = L6 - zc, a = Re - m / 2, out = [], i, N = 24;
    if (shape === 'pointy') {
      var rho = (a * a + n * n) / (2 * a);
      var th = Math.asin(clamp(n / rho, -1, 1));
      for (i = 0; i <= N; i++) {
        var t = th * i / N;
        out.push([zc + rho * Math.sin(t), Re - rho + rho * Math.cos(t)]);
      }
      out[out.length - 1] = [L6, m / 2];
    } else if (shape === 'rounded') {
      for (i = 0; i <= N; i++) {
        var u = (Math.PI / 2) * i / N;
        out.push([zc + n * Math.sin(u), m / 2 + a * Math.cos(u)]);
      }
      out[out.length - 1] = [L6, m / 2];
    } else {
      out.push([zc, Re], [L6, m / 2]);
    }
    return out;
  }

  /** Builds everything the drawing needs. `missing` lists values that were not published. */
  function build(rec) {
    var c = rec.cartridge || {}, ch = c.caseHead || {}, col = c.collar || {}, jc = c.junctionCone || {};
    var len = c.lengths || {}, pc = c.powderChamber || {}, pj = c.projectile || {}, an = rec.annotations || {};
    var P1 = pc.P1, P2 = pc.P2, E = ch.E, E1 = ch.E1, R = ch.R, R1 = ch.R1, R3 = ch.R3, f = ch.f, eMin = ch.eMin;
    var H1 = col.H1, H2 = col.H2, L1 = len.L1, L2 = len.L2, L3 = len.L3, L6 = len.L6, G1 = pj.G1;
    var beta = deg(ch.beta), delta = deg(ch.delta), alpha = deg(jc.alpha);
    var missing = [];
    function miss(symbols, effect) { missing.push({ symbols: symbols, effect: effect }); }

    var required = [['L3', L3], ['R1', R1], ['P1', P1], ['R', R], ['H2', H2]].filter(function (x) { return !has(x[1]); });
    if (required.length) {
      miss(required.map(function (x) { return x[0]; }), 'the case outline cannot be drawn');
      return { ok: false, missing: missing };
    }

    var family = rec.family;
    var rimType = family === 'belted' ? 'belted' : family === 'rimfire' ? 'rimfire'
      : R1 / P1 >= 1.05 ? 'rimmed' : R1 / P1 < 0.98 ? 'rebated' : 'rimless';

    /* ---- head face and rim edge ---- */
    var pts = [[0, 0]];
    var headFaceR, rimZ;
    if (rimType === 'rimfire') {
      var rho = Math.min(R / 2, (R1 - P1) / 2), re = R1 / 2 - rho, i;
      addPoint(pts, [0, re]);
      for (i = 1; i < 16; i++) {
        var ph = Math.PI * i / 16;
        addPoint(pts, [rho * (1 - Math.cos(ph)), re + rho * Math.sin(ph)]);
      }
      addPoint(pts, [2 * rho, re]);
      addPoint(pts, [R, re]);
      headFaceR = re;
      rimZ = rho;
    } else {
      var chamfer = has(beta) && has(f) && beta > 0 && beta < 90 && f > 0 && f < R;
      if (chamfer) {
        var cc = Math.min(f * Math.tan(beta * RAD), R1 / 4);
        addPoint(pts, [0, R1 / 2 - cc]);
        addPoint(pts, [f, R1 / 2]);
        headFaceR = R1 / 2 - cc;
        rimZ = (f + R) / 2;
      } else {
        addPoint(pts, [0, R1 / 2]);
        headFaceR = R1 / 2;
        rimZ = R / 2;
        if (!(has(beta) && has(f))) miss(['beta', 'f'].filter(function (k) { return !has(ch[k]); }).map(function (k) { return fmt.symbolFor(k); }), 'head chamfer not drawn');
      }
      addPoint(pts, [R, R1 / 2]);
    }

    /* ---- extractor groove, belt or step ---- */
    var grooveApplies = rimType === 'rimless' || rimType === 'rebated' || rimType === 'belted';
    var groove = false, beltRampEnd = null, grooveRef = null;
    if (grooveApplies) {
      var need = [['E', E], ['E1', E1], ['e min', eMin]];
      if (rimType === 'belted') need.push(['R3', R3], ['\u03b4', delta]);
      var gm = need.filter(function (x) { return !has(x[1]); }).map(function (x) { return x[0]; });
      if (gm.length) miss(gm, 'extractor groove not drawn');
      else groove = true;
    }
    if (groove) {
      addPoint(pts, [R, E1 / 2]);
      addPoint(pts, [R + eMin, E1 / 2]);
      grooveRef = { z: R + eMin / 2, r: E1 / 2 };
      if (rimType === 'belted') {
        beltRampEnd = R + eMin + (R3 / 2 - E1 / 2) / Math.tan(delta * RAD);
        addPoint(pts, [beltRampEnd, R3 / 2]);
        addPoint(pts, [E, R3 / 2]);
      }
      addPoint(pts, [E, P1 / 2]);
    } else {
      addPoint(pts, [R, P1 / 2]);
    }
    var bodyStart = pts[pts.length - 1].slice();
    var iBody = pts.length - 1;

    /* ---- body, shoulder, neck ---- */
    var any = has(alpha) || has(L1) || has(L2);
    var bottle = has(alpha) && has(L1) && has(L2) && has(P2) && has(H1);
    if (any && !bottle) {
      var bm = [['\u03b1', alpha], ['L1', L1], ['L2', L2], ['P2', P2], ['H1', H1]].filter(function (x) { return !has(x[1]); }).map(function (x) { return x[0]; });
      miss(bm, 'drawn as a straight case');
    }
    var shoulder = null;
    if (bottle) {
      var A = [L1, P2 / 2], B = [L2, H1 / 2], C = [L3, H2 / 2];
      var dBody = unit(bodyStart, A), dSh = unit(A, B), dNeck = unit(B, C);
      var phiA = deflection(dBody, dSh), phiB = deflection(dSh, dNeck);
      var rA = has(jc.r1Min) ? jc.r1Min : 0, rB = has(jc.r2) ? jc.r2 : 0;
      if (!has(jc.r1Min)) miss(['r1 min'], 'body-side shoulder corner not rounded');
      if (!has(jc.r2)) miss(['r2'], 'neck-side shoulder corner not rounded');
      var tA = phiA > 1e-6 ? rA * Math.tan(phiA / 2) : 0, tB = phiB > 1e-6 ? rB * Math.tan(phiB / 2) : 0;
      tA = Math.min(tA, 0.9 * dist(bodyStart, A));
      tB = Math.min(tB, 0.9 * dist(B, C));
      var Ls = dist(A, B);
      if (tA + tB > 0.95 * Ls) { var sc = 0.95 * Ls / (tA + tB); tA *= sc; tB *= sc; }
      (tA > 0 ? fillet(A, dBody, dSh, tA, phiA) : [A]).forEach(function (p) { addPoint(pts, p); });
      (tB > 0 ? fillet(B, dSh, dNeck, tB, phiB) : [B]).forEach(function (p) { addPoint(pts, p); });
      addPoint(pts, C);
      var slope = (B[1] - A[1]) / (B[0] - A[0]);
      shoulder = { A: A, B: B, apex: [B[0] - B[1] / slope, 0], alpha: alpha };
    } else {
      addPoint(pts, [L3, H2 / 2]);
    }
    var outer = pts;

    /* ---- walls, head, pocket ---- */
    var heeled = has(G1) && H2 - G1 <= 0.015;
    var tn = has(G1) ? Math.max(0, (H2 - G1) / 2) : null;
    if (tn === null) miss(['G1'], 'neck wall thickness and bullet not drawn');
    var tb = Math.min(Math.max(1.3 * (tn || 0), 0.6), 0.35 * P1 / 2);
    var primer = an.primerType, pocket = null;
    if (rimType !== 'rimfire') {
      if (POCKET_D[primer]) pocket = { d: POCKET_D[primer], depth: POCKET_DEPTH[primer] };
      else miss(['primer type'], 'primer pocket not drawn');
    }
    var w = Math.max(2.5, 0.25 * P1 / 2, pocket ? pocket.depth + 1.5 : 0,
      groove && rimType !== 'belted' ? E + tb : 0, groove && rimType === 'belted' ? beltRampEnd + tb : 0);

    function wallAt(z) {
      if (heeled || tn === null) return tb;
      if (bottle) {
        if (z <= L1) return tb;
        if (z >= L2) return tn;
        return tb + (tn - tb) * (z - L1) / (L2 - L1);
      }
      return tb + (tn - tb) * clamp((z - w) / (L3 - w), 0, 1);
    }
    function bodyR(z) {
      var b = outer.slice(iBody);
      if (z <= b[0][0]) return b[0][1];
      for (var k = 1; k < b.length; k++) {
        if (z <= b[k][0]) {
          var d = b[k][0] - b[k - 1][0];
          return d < 1e-12 ? b[k][1] : b[k - 1][1] + (b[k][1] - b[k - 1][1]) * (z - b[k - 1][0]) / d;
        }
      }
      return b[b.length - 1][1];
    }
    var inner = [[w, bodyR(w) - wallAt(w)]];
    outer.slice(iBody).forEach(function (p) { if (p[0] > w + 1e-9) addPoint(inner, [p[0], p[1] - wallAt(p[0])]); });

    /* ---- bullet ---- */
    var bullet = null;
    var shape = an.defaultBulletShape;
    if (has(G1) && has(L6)) {
      if (!(shape in MEPLAT) && shape !== 'pointy') miss(['defaultBulletShape'], 'bullet not drawn');
      else {
        var pistol = an.category === 'pistol';
        var D = heeled ? H2 : G1, Re = D / 2;
        var seatF = SEAT[shape] !== undefined ? SEAT[shape] : (pistol ? 0.4 : 0.8);
        var k = shape === 'pointy' || shape === 'semi_wadcutter' ? CYL[shape]
          : shape === 'rounded' ? (pistol ? 0.65 : 0.55) : (pistol ? 0.70 : 0.60);
        var m = shape === 'pointy' ? Math.max(0.08 * G1, 1.27) : MEPLAT[shape] * G1;
        var s = seatF * G1, zb = L3 - s, Lb = L6 - zb, zc = zb + k * Lb;
        var full = [[zb, Re], [zc, Re]].concat(nose(shape, zc, L6, Re, m).slice(1));
        var exposed = clipFrom(full, L3);
        var rh = heeled ? H2 / 2 - tb : null;
        var sec = [[zb, 0]];
        if (heeled) { addPoint(sec, [zb, rh]); addPoint(sec, [L3, rh]); addPoint(sec, [L3, Re]); }
        else addPoint(sec, [zb, Re]);
        full.slice(1).forEach(function (p) { addPoint(sec, p); });
        addPoint(sec, [L6, 0]);
        bullet = { shape: shape, category: pistol ? 'pistol' : 'rifle', s: s, zb: zb, Lb: Lb, zc: zc, k: k, m: m, Re: Re,
          heeled: heeled, heelR: rh, exposed: exposed, section: sec };
      }
    }
    if (!bullet && has(G1) && !has(L6)) miss(['L6'], 'bullet not drawn');

    var tip = bullet ? [L6, bullet.m / 2] : null;
    var rMax = Math.max.apply(null, outer.map(function (p) { return p[1]; }));
    return {
      ok: true, rimType: rimType, bottleneck: !!bottle, heeled: heeled, groove: groove,
      outer: outer, inner: inner, head: { w: w, pocket: pocket }, walls: { tn: tn, tb: tb },
      bullet: bullet, shoulder: shoulder, missing: missing,
      refs: { L1: L1, L2: L2, L3: L3, L6: L6, R: R, R1: R1, P1: P1, P2: P2, H1: H1, H2: H2, G1: G1, E1: E1, E: E,
        headFaceR: headFaceR, bodyStart: bodyStart, groove: grooveRef, tip: tip,
        rimZ: rimZ },
      extents: { zMax: Math.max(L3, bullet ? L6 : L3), rMax: rMax }
    };
  }

  CIP.geometry = { build: build, clipFrom: clipFrom };
  if (typeof module !== 'undefined' && module.exports) module.exports = CIP.geometry;
})(typeof window !== 'undefined' ? window : globalThis);
