# Design

## Context
Greenfield. Brief: plain HTML/CSS/JS, `file://` in Chromium. See proposal.md.

## Goals / Non-Goals
**Goals:** pure, unit-testable geometry; works from disk; deterministic non-overlapping labels.
**Non-Goals:** editing data, i18n, pan/zoom, ES modules.

## Decisions
- **Data as a classic script** (`js/data.js` sets `CIP.data`): `fetch` of JSON and `<script type=module>` fail on `file://` in Chromium. Alternative (JSON + fetch) rejected.
- **Hash routing** (`#/cartridge/<key>`): works on `file://`, survives reload, bookmarkable. Alternative (History API paths) needs server rewrites.
- **Modules as UMD-style IIFEs** attaching to `CIP` and `module.exports` under Node, so unit tests run with `node --test` with no bundler.
- **Layers:** `format.js` (angles, values, symbols, tables), `geometry.js` (record -> points, pure, no DOM), `drawing.js` (geometry -> SVG string, dimension/label layout), `app.js` (views, router, search).
- **Geometry as points**: arcs (fillets, half-round, ogive, ellipse) are sampled into polylines; the outer half-profile is built head to mouth and mirrored. Hatching via SVG `pattern`; section = outer polygon minus cavity minus primer pocket.
- **Straight-case wall:** tb at the solid head blending linearly to tn at the mouth; heeled cases keep tb throughout (so the heel has ID H2 - 2tb). Documented assumption, since the brief only defines tb/tn for body/neck.
- **Dimension layout:** lengths (R, L1, L2, L3, L6) in lanes below the part, extension lines dropping from the outline points. Diameters (R1, E1, P1, P2, H1, H2, G1) are vertical dimension lines at their feature position with arrowheads touching the outline; an extension line continues above the part to a label placed in a lane. Lanes are assigned by a staircase rule so labels never overlap and leaders never cross labels. α is labelled with an arc at the shoulder, label in a free lane.
- **Scale:** SVG viewBox is in mm. Print width is full text width (180 mm); title block states the resulting scale computed from viewBox width. On screen the SVG is `width:100%`.
- **Tests:** unit (node:test) for format/geometry/data; browser (Playwright Chromium, `file://`) for routing, search, labels non-overlap via `getBBox`, phone width, print emulation.

## Risks / Trade-offs
- Labels small on a phone (scale ~2.5 px/mm) -> mitigated by tight cropping; pinch zoom works.
- Sampled arcs are polylines -> enough points that the deviation is far below print resolution.
