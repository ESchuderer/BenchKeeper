## Why

Reloaders, gunsmiths and engineers need a quick, offline reference for C.I.P. cartridge and chamber dimensions, including a scale drawing. OpenBallistics has such a database; this change builds a self-contained static version for 25 cartridges.

## What Changes

- New static web app (`index.html` + CSS + JS, no framework, no build, no network) that opens from `file://` and from any static server.
- Start page: list of 25 cartridges with search and family filter.
- Detail view per cartridge with a bookmarkable address, grouped value tables (cartridge and chamber) and print support.
- Computed 2D inline-SVG drawing (outside view + section, dimension lines, title block) from the record values.
- A4 print layout.
- Dev-only tooling: Node test runner (unit) and Playwright (browser, `file://`).

## Capabilities

### New Capabilities
- `cartridge-reference`: list, search, filter, detail view, value tables, routing, print, offline/file:// operation, look and feel.
- `cartridge-drawing`: geometry rules, dimensions, labels, title block and scaling of the computed SVG drawing.

### Modified Capabilities
(none)

## Impact

- New files in the project root: `index.html`, `css/`, `js/` (data, format, geometry, drawing, app), `tests/`, `package.json`.
- Data is the 25 supplied records, embedded unchanged in `js/data.js` (a classic script, because `fetch` and ES modules are blocked on `file://`).
- Out of scope: more cartridges, data editing, unit conversion, server code.
