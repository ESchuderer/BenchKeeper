## ADDED Requirements

### Requirement: Scale drawing
The detail view SHALL contain an inline SVG named "<name> drawing", computed from the record, with 1 user unit = 1 mm, axis horizontal, head on the left, outside view above the axis, section (cut walls hatched) below, and a dash-dot centre line.

#### Scenario: True to scale
- **WHEN** the 308 Win. drawing is shown
- **THEN** the case outline spans z = 0 to 51.18 and the bullet tip lies at z = 71.12

### Requirement: Case geometry
The outline SHALL follow the supplied rules: rim type, head chamfer or rimfire half-round, extractor groove or step, belt, body, shoulder (through the published points, with r1 min / r2 fillets), neck and mouth; wall thickness, solid head and primer pocket in the section.

#### Scenario: Rim types
- **THEN** 300 Win. Mag. is belted, 22 Long Rifle rimfire, 38 Special rimmed, 223 Rem. rimless

### Requirement: Bullet
The bullet SHALL be drawn from G1, L6 and `defaultBulletShape` (pointy, rounded, flat, semi_wadcutter) with the given seating depth, cylinder fraction and meplat; heeled cases use the case outside diameter for the exposed bullet and the inside diameter for the seated heel. The outside view hides the seated part; the section shows it.

#### Scenario: Heeled
- **THEN** 22 Long Rifle shows an exposed bullet of diameter 5.72 and a seated heel of diameter H2 - 2·tb

### Requirement: Dimensions and labels
Dimension lines with arrowheads and extension lines SHALL be drawn for L3, L6, R1, R and P1 and, where published, P2, H1, H2, G1, L1, L2, E1 and α, each labelled with symbol and value (`L3 51.18`). Labels SHALL NOT overlap each other or the outline.

#### Scenario: No overlaps
- **THEN** for all 25 cartridges no two label boxes intersect and none intersects the outline

### Requirement: Missing values
If a value needed by a rule is missing, the feature SHALL be left out and the drawing SHALL list which value is missing. No number SHALL be invented.

#### Scenario: 7 x 65 R
- **THEN** no extractor groove is drawn and E, E1, e min are listed as not published

### Requirement: Title block and scaling
A title block SHALL show the name, C.I.P. table and revision date, "Dimensions in mm" and the scale. The drawing SHALL scale to the width of a phone screen and print legibly.

#### Scenario: Phone
- **WHEN** the viewport is 360 px wide
- **THEN** the drawing fits without horizontal scrolling
