## ADDED Requirements

### Requirement: Cartridge list
The start page SHALL show the heading "Cartridges" and every cartridge with its name, family and case length L3. Each name SHALL be a link whose text is exactly the record's `name` and which opens the detail view.

#### Scenario: All cartridges listed
- **WHEN** the start page is opened
- **THEN** "25 cartridges" is shown and 25 name links are listed, e.g. a link "6,5 Creedmoor"

### Requirement: Search and family filter
A field labelled "Search" SHALL filter the list by name and alternative names while typing. A select labelled "Family" with options All, rimless, rimmed, belted, pistol, rimfire SHALL filter by family. The text "<n> cartridges" SHALL show the number listed.

#### Scenario: Alternative name
- **WHEN** the user types `7,62 x 51`
- **THEN** "308 Win." is listed and "1 cartridges" is shown

#### Scenario: Family
- **WHEN** Family is set to rimfire
- **THEN** only the 3 rimfire cartridges are listed

### Requirement: Detail view
The detail view SHALL show the name as heading, then alternative names, family, category, primer type, C.I.P. table, country, published and revised dates, pressure method and published water capacity with its source link; the drawing; all cartridge values and all chamber values in section-grouped tables with columns "Symbol", "Value", "Unit"; a "Print" button and a link "All cartridges". Each detail view SHALL have its own address that survives a reload.

#### Scenario: Reload
- **WHEN** a detail view is opened and the page is reloaded
- **THEN** the same detail view is shown

### Requirement: Value formatting
Values SHALL be shown as published with a decimal point and no thousands separator. A `<X>Tol` field SHALL be shown next to X and never as its own row. Angles given as `{degrees, minutes, seconds}` SHALL be shown as `39°59'49"`, plain numbers as `40°`. Symbols SHALL be the field name except the mapped ones (e min, r1 min, r1 max, α, α1, β, δ, delta L, L3 + G). Units: mm for lengths and diameters, bar for Pmax/PK/PE, J for EE, g for M, mm² for Q, none for N.

#### Scenario: Tolerance
- **WHEN** the 308 Win. detail is shown
- **THEN** the L1 row value reads `39.62 -0.2` with unit mm and no row "L1Tol" exists

### Requirement: Print
"Print" SHALL open the print dialog. A printed detail view SHALL be one A4 portrait page, black on white: header with the name, drawing at full width, then the tables, a footer "C.I.P. TDCC, revised <date>", and no navigation, search or buttons.

#### Scenario: Print emulation
- **WHEN** print media is emulated
- **THEN** navigation, search and buttons are hidden and the footer is shown

### Requirement: Offline and technology
The app SHALL need no framework, build step, server code, runtime dependency or network request, and SHALL work when `index.html` is opened from disk in Chromium and when served statically. It SHALL follow the system light/dark setting on screen, print always light, and be usable on a phone.

#### Scenario: Opened from disk
- **WHEN** `index.html` is opened via `file://`
- **THEN** the list renders, detail views open and no network request is made
