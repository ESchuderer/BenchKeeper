# Tasks

## 1. Setup and data
- [x] 1.1 Create `package.json` (dev deps only), `index.html` skeleton; verify `npm test` runs
- [x] 1.2 Embed the 25 records unchanged in `js/data.js`; verify a unit test checks 25 unique keys and key fields

## 2. Formatting (tests first)
- [x] 2.1 `js/format.js`: angles, values, tolerance, symbols, units, section tables; verify unit tests (`39°59'49"`, `39.62 -0.2`)

## 3. Geometry (tests first)
- [x] 3.1 `js/geometry.js`: rim type, head, groove/belt, body, shoulder fillets, neck; verify unit tests on known points (223 Rem., 308 Win., 300 Win. Mag.)
- [x] 3.2 Bullet profiles, heeled case, walls, head, pocket, missing-value list; verify unit tests for all 25 records (finite, monotone z, no throw)

## 4. Drawing
- [x] 4.1 `js/drawing.js`: SVG with outline, section hatching, centre line, bullet; verify via browser test (name, scale, spans)
- [x] 4.2 Dimensions, extension lines, arrowheads, label lanes, alpha, title block, missing notes; verify browser test that no label bboxes overlap each other/outline for all 25

## 5. App
- [x] 5.1 List, search, family filter, count, hash routing, detail view and tables; verify browser tests from the spec scenarios
- [x] 5.2 Styles: light/dark, phone, print A4; verify phone width has no horizontal overflow, print emulation hides nav and fits one page

## 6. Verification
- [x] 6.1 Run all tests from `file://` and via static server; run `openspec validate`; review the diff

## Workflow follow-up

- Run browser tests with Chromium: `npx playwright install chromium`, then `npm test` (unit: `node --test`, browser: Playwright on `file://` and a static server).
- Archive the change with `openspec archive` after review.
