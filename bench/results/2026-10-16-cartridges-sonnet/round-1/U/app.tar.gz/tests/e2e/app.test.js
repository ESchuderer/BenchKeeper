const test = require('node:test');
const assert = require('node:assert');
const { launch, serve, FILE_URL } = require('./helper');
require('../../js/data.js');
const data = globalThis.CIP.data;

let browser, srv;
test.before(async () => { browser = await launch(); srv = await serve(); });
test.after(async () => { await browser.close(); srv.server.close(); });

for (const [mode, getUrl] of [['file://', () => FILE_URL], ['http://', () => srv.url]]) {
  test('start page and detail view work over ' + mode, async () => {
    const page = await browser.newPage();
    const errors = [];
    const requests = [];
    page.on('pageerror', (e) => errors.push(e.message));
    page.on('console', (m) => { if (m.type() === 'error') errors.push(m.text()); });
    page.on('request', (r) => requests.push(r.url()));
    await page.goto(getUrl());

    await page.getByRole('heading', { name: 'Cartridges', level: 1 }).waitFor();
    assert.equal(await page.getByText('25 cartridges', { exact: true }).count(), 1);
    assert.equal(await page.locator('table.list tbody a').count(), 25);
    await page.getByRole('link', { name: '6,5 Creedmoor', exact: true }).waitFor();

    // list rows: name, family, L3
    const row = page.locator('table.list tbody tr', { has: page.getByRole('link', { name: '308 Win.', exact: true }) });
    assert.match(await row.innerText(), /rimless/);
    assert.match(await row.innerText(), /51\.18/);

    // search by alternative name
    await page.getByLabel('Search').fill('7,62 x 51');
    assert.deepEqual(await page.locator('table.list tbody a').allInnerTexts(), ['308 Win.']);
    await page.getByText('1 cartridges', { exact: true }).waitFor();
    await page.getByLabel('Search').fill('');

    // family filter
    const expected = { rimless: 12, rimmed: 2, belted: 2, pistol: 6, rimfire: 3 };
    for (const [fam, n] of Object.entries(expected)) {
      await page.getByLabel('Family').selectOption(fam);
      assert.equal(await page.locator('table.list tbody a').count(), n, fam);
      await page.getByText(n + ' cartridges', { exact: true }).waitFor();
    }
    assert.deepEqual(await page.getByLabel('Family').locator('option').allInnerTexts(), ['All', 'rimless', 'rimmed', 'belted', 'pistol', 'rimfire']);
    await page.getByLabel('Family').selectOption('All');

    // open detail
    await page.getByRole('link', { name: '308 Win.', exact: true }).click();
    await page.getByRole('heading', { name: '308 Win.', level: 1 }).waitFor();
    const url = page.url();
    assert.match(url, /#\/cartridge\/308_win$/);
    await page.reload();
    await page.getByRole('heading', { name: '308 Win.', level: 1 }).waitFor();
    assert.equal(page.url(), url);

    const text = await page.locator('article.detail').innerText();
    for (const s of ['308 Winchester, 7,62 x 51', 'rimless', 'rifle', 'lr', 'US', '1984-06-14', '2008-09-23', 'Transducer', '56 grH2O']) assert.ok(text.includes(s), s);
    assert.equal(await page.getByRole('link', { name: 'kwk' }).getAttribute('href'), 'http://kwk.us/cases.html');
    assert.ok(!/L1Tol/.test(text));

    // tables
    assert.ok((await page.locator('table.values-table').count()) >= 12);
    const heads = await page.locator('table.values-table').first().locator('thead th').evaluateAll((els) => els.map((e) => e.textContent));
    assert.deepEqual(heads, ['Symbol', 'Value', 'Unit']);
    const l1 = page.locator('table.values-table tbody tr', { has: page.locator('th', { hasText: /^L1$/ }) }).first();
    assert.deepEqual(await l1.locator('th,td').evaluateAll((e) => e.map((x) => x.textContent)), ['L1', '39.62 -0.2', 'mm']);
    assert.match(await page.locator('table.values-table tbody tr', { has: page.locator('th', { hasText: /^Pmax$/ }) }).first().innerText(), /4150\s+bar/);
    assert.match(await page.locator('tbody tr', { has: page.locator('th', { hasText: /^α$/ }) }).first().innerText(), /40°/);
    assert.match(await page.locator('tbody tr', { has: page.locator('th', { hasText: /^i$/ }) }).first().innerText(), /1°45'0"/);

    // actions
    await page.getByRole('button', { name: 'Print' }).waitFor();
    await page.evaluate(() => { window.__printed = 0; window.print = () => { window.__printed++; }; });
    await page.getByRole('button', { name: 'Print' }).click();
    assert.equal(await page.evaluate(() => window.__printed), 1);
    await page.getByRole('link', { name: 'All cartridges' }).click();
    await page.getByRole('heading', { name: 'Cartridges', level: 1 }).waitFor();

    // unknown address
    await page.goto(getUrl() + '#/cartridge/nope');
    await page.getByRole('heading', { name: 'Cartridge not found' }).waitFor();

    assert.deepEqual(errors, []);
    const external = requests.filter((u) => !u.startsWith('file://') && !u.startsWith(srv.url));
    assert.deepEqual(external, []);
    await page.close();
  });
}

test('every cartridge has a detail view with heading, drawing and tables', async () => {
  const page = await browser.newPage();
  for (const rec of data) {
    await page.goto(FILE_URL + '#/cartridge/' + rec.key);
    await page.getByRole('heading', { name: rec.name, level: 1, exact: true }).waitFor();
    await page.getByRole('img', { name: rec.name + ' drawing', exact: true }).waitFor();
    assert.ok((await page.locator('table.values-table').count()) >= 8, rec.key);
    for (const f of ['Family', 'Category', 'Primer type', 'C.I.P. table', 'Country', 'Published', 'Revised', 'Pressure method', 'Water capacity']) {
      assert.ok(await page.locator('dl.facts dt', { hasText: new RegExp('^' + f.replace('.', '\\.') + '$') }).count(), rec.key + ' ' + f);
    }
  }
  await page.close();
});

test('dark and light follow the system setting; phone has no horizontal overflow', async () => {
  const page = await browser.newPage({ viewport: { width: 360, height: 740 } });
  await page.emulateMedia({ colorScheme: 'dark' });
  await page.goto(FILE_URL + '#/cartridge/300_win_mag');
  const dark = await page.evaluate(() => getComputedStyle(document.body).backgroundColor);
  await page.emulateMedia({ colorScheme: 'light' });
  const light = await page.evaluate(() => getComputedStyle(document.body).backgroundColor);
  assert.notEqual(dark, light);
  assert.ok(await page.evaluate(() => document.documentElement.scrollWidth) <= 360);
  const w = await page.locator('svg.cartridge-drawing').evaluate((e) => e.getBoundingClientRect().width);
  assert.ok(w <= 360 && w > 300, 'svg width ' + w);
  await page.goto(FILE_URL);
  assert.ok(await page.evaluate(() => document.documentElement.scrollWidth) <= 360);
  await page.close();
});
