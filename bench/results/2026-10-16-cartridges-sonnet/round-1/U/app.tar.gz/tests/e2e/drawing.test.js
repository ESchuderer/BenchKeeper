const test = require('node:test');
const assert = require('node:assert');
const { launch, FILE_URL } = require('./helper');
require('../../js/data.js');
const data = globalThis.CIP.data;

let browser;
test.before(async () => { browser = await launch(); });
test.after(async () => { await browser.close(); });

/** Runs in the page: label boxes, outline samples, dimension structure. */
function inspect() {
  const svg = document.querySelector('svg.cartridge-drawing');
  const labels = [...svg.querySelectorAll('text.label')].map((t) => {
    const b = t.getBBox();
    return { id: t.dataset.label, text: t.textContent, x0: b.x, y0: b.y, x1: b.x + b.width, y1: b.y + b.height };
  });
  const outline = [];
  svg.querySelectorAll('path.case-outline, path.bullet-outside, path.cut, path.bullet-section, line.outline, line.centerline').forEach((p) => {
    if (p.tagName === 'line') {
      for (let i = 0; i <= 20; i++) outline.push([p.x1.baseVal.value + (p.x2.baseVal.value - p.x1.baseVal.value) * i / 20, p.y1.baseVal.value + (p.y2.baseVal.value - p.y1.baseVal.value) * i / 20, p.getAttribute('class')]);
      return;
    }
    const L = p.getTotalLength();
    const n = Math.max(40, Math.ceil(L / 0.15));
    for (let i = 0; i <= n; i++) { const q = p.getPointAtLength(L * i / n); outline.push([q.x, q.y, p.getAttribute('class')]); }
  });
  const dims = [...svg.querySelectorAll('g.dimension')].map((g) => ({
    id: g.dataset.dim, arrows: g.querySelectorAll('polygon.arrowhead').length,
    ext: g.querySelectorAll('line.ext').length, lines: g.querySelectorAll('line.dim, path.dim').length
  }));
  const vb = svg.viewBox.baseVal;
  return { labels, outline, dims, vb: [vb.x, vb.y, vb.width, vb.height], title: svg.querySelector('title').textContent, label: svg.getAttribute('aria-label') };
}

test('labels never overlap each other or the outline (all 25)', async () => {
  const page = await browser.newPage();
  for (const rec of data) {
    await page.goto(FILE_URL + '#/cartridge/' + rec.key);
    await page.locator('svg.cartridge-drawing').waitFor();
    const r = await page.evaluate(inspect);
    assert.equal(r.label, rec.name + ' drawing');
    for (let i = 0; i < r.labels.length; i++) {
      const a = r.labels[i];
      assert.ok(a.x0 >= r.vb[0] && a.x1 <= r.vb[0] + r.vb[2] && a.y0 >= r.vb[1] && a.y1 <= r.vb[1] + r.vb[3], rec.key + ' ' + a.id + ' inside viewBox');
      for (let j = i + 1; j < r.labels.length; j++) {
        const b = r.labels[j];
        const overlap = a.x0 < b.x1 && b.x0 < a.x1 && a.y0 < b.y1 && b.y0 < a.y1;
        assert.ok(!overlap, rec.key + ': ' + a.text + ' overlaps ' + b.text);
      }
      for (const [x, y, cls] of r.outline) {
        if (cls === 'centerline') continue;
        assert.ok(!(x > a.x0 - 0.1 && x < a.x1 + 0.1 && y > a.y0 - 0.1 && y < a.y1 + 0.1), rec.key + ': ' + a.text + ' touches outline (' + cls + ')');
      }
    }
  }
  await page.close();
});

test('dimensions: arrowheads, extension lines and labels with symbol and value', async () => {
  const page = await browser.newPage();
  for (const rec of data) {
    await page.goto(FILE_URL + '#/cartridge/' + rec.key);
    await page.locator('svg.cartridge-drawing').waitFor();
    const r = await page.evaluate(inspect);
    const c = rec.cartridge;
    const expectIds = ['L3', 'L6', 'R1', 'R', 'P1', 'H2'];
    if (c.caseHead.E1 !== undefined && c.caseHead.E !== undefined && rec.family !== 'rimmed' && rec.family !== 'rimfire') expectIds.push('E1');
    if (c.junctionCone && c.junctionCone.alpha !== undefined && c.lengths.L1 !== undefined) expectIds.push('L1', 'L2', 'P2', 'H1', 'alpha');
    if (c.projectile.G1 !== undefined) expectIds.push('G1');
    for (const id of expectIds) {
      const d = r.dims.find((x) => x.id === id);
      assert.ok(d, rec.key + ' dimension ' + id);
      assert.ok(d.arrows >= 1 && d.ext >= 1, rec.key + ' ' + id + ' arrows/extension lines');
      assert.ok(r.labels.some((l) => l.id === id), rec.key + ' label ' + id);
    }
    assert.ok(r.labels.some((l) => l.text === 'L3 ' + c.lengths.L3), rec.key + ' L3 label');
    assert.ok(r.labels.some((l) => l.text === 'L6 ' + c.lengths.L6), rec.key + ' L6 label');
  }
  await page.close();
});

test('true to scale: 1 unit = 1 mm (308 Win.)', async () => {
  const page = await browser.newPage();
  await page.goto(FILE_URL + '#/cartridge/308_win');
  const r = await page.evaluate(() => {
    const svg = document.querySelector('svg.cartridge-drawing');
    const caseBox = svg.querySelector('path.case-outline').getBBox();
    const bul = svg.querySelector('path.bullet-outside').getBBox();
    const cl = svg.querySelector('line.centerline');
    return { caseX: [caseBox.x, caseBox.x + caseBox.width], caseH: caseBox.height, bulX: [bul.x, bul.x + bul.width], hasHatch: !!svg.querySelector('pattern'), dash: getComputedStyle(cl).strokeDasharray,
      cutFill: svg.querySelector('path.cut').getAttribute('fill'), title: svg.querySelector('.titleblock').textContent };
  });
  assert.ok(Math.abs(r.caseX[0]) < 1e-3 && Math.abs(r.caseX[1] - 51.18) < 1e-3, 'case spans ' + r.caseX);
  assert.ok(Math.abs(r.caseH - 12.01 / 2) < 0.01, 'outside half height (R1/2) ' + r.caseH);
  assert.ok(Math.abs(r.bulX[1] - 71.12) < 1e-3, 'tip at ' + r.bulX[1]);
  assert.ok(r.hasHatch && /url\(#/.test(r.cutFill));
  assert.notEqual(r.dash, 'none');
  assert.match(r.title, /308 Win\./);
  assert.match(r.title, /C\.I\.P\. table I/);
  assert.match(r.title, /2008-09-23/);
  assert.match(r.title, /Dimensions in mm/);
  assert.match(r.title, /Scale [\d.]+ : 1/);
  await page.close();
});

test('missing values are named, not invented', async () => {
  const page = await browser.newPage();
  await page.goto(FILE_URL + '#/cartridge/17_hmr');
  const t = await page.locator('.drawing-notes .missing').allInnerTexts();
  assert.ok(t.some((s) => /r1 min/.test(s)) && t.some((s) => /r2/.test(s)), t.join('|'));
  await page.goto(FILE_URL + '#/cartridge/223_rem');
  assert.equal(await page.locator('.drawing-notes .missing').count(), 0);
  await page.close();
});

test('print: one A4 portrait page for every cartridge, no navigation, footer shown', async () => {
  const page = await browser.newPage();
  await page.emulateMedia({ media: 'print', colorScheme: 'dark' });
  for (const rec of data) {
    await page.goto(FILE_URL + '#/cartridge/' + rec.key);
    await page.locator('svg.cartridge-drawing').waitFor();
    const vis = await page.evaluate(() => {
      const shown = (sel) => [...document.querySelectorAll(sel)].some((e) => getComputedStyle(e).display !== 'none' && e.getClientRects().length);
      return { header: shown('.site-header'), actions: shown('.actions'), button: shown('button'), search: shown('input'), footer: shown('.print-footer'),
        footerText: document.querySelector('.print-footer').textContent, bg: getComputedStyle(document.body).backgroundColor,
        svgW: document.querySelector('svg.cartridge-drawing').getBoundingClientRect().width / 96 * 25.4 };
    });
    assert.deepEqual([vis.header, vis.actions, vis.button, vis.search, vis.footer], [false, false, false, false, true], rec.key);
    assert.equal(vis.footerText, 'Source: C.I.P. TDCC, revised ' + rec.revised);
    assert.equal(vis.bg, 'rgb(255, 255, 255)');
    assert.ok(vis.svgW > 165 && vis.svgW <= 180.5, rec.key + ' drawing width mm ' + vis.svgW);
    const pdf = await page.pdf({ format: 'A4', printBackground: true, preferCSSPageSize: true });
    const pages = (pdf.toString('latin1').match(/\/Type\s*\/Page[^s]/g) || []).length;
    assert.equal(pages, 1, rec.key + ' prints on ' + pages + ' pages');
  }
  await page.close();
});
