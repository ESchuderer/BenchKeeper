const test = require('node:test');
const assert = require('node:assert');
require('../../js/data.js');
const data = globalThis.CIP.data;

test('25 records with unique keys and names', () => {
  assert.equal(data.length, 25);
  assert.equal(new Set(data.map((r) => r.key)).size, 25);
  assert.equal(new Set(data.map((r) => r.name)).size, 25);
});

test('names kept as published', () => {
  const names = data.map((r) => r.name);
  assert.ok(names.includes('6,5 Creedmoor'));
  assert.ok(names.includes('40 S.& W.'));
  assert.ok(names.includes('22 Win. Mag. R.F.'));
  assert.deepEqual(data.find((r) => r.key === '22_long_rifle').alternativeNames[1], '22 lang f\u00fcr B\u00fcchsen');
});

test('families', () => {
  const count = (f) => data.filter((r) => r.family === f).length;
  assert.deepEqual(['rimless', 'rimmed', 'belted', 'pistol', 'rimfire'].map(count), [12, 2, 2, 6, 3]);
  assert.equal(count('rimfire'), 3);
  assert.equal(count('pistol'), 6);
  assert.equal(data.length, count('rimless') + count('rimmed') + count('belted') + count('pistol') + count('rimfire'));
});

test('spot values equal the brief', () => {
  const r = data.find((x) => x.key === '308_win');
  assert.equal(r.cartridge.lengths.L3, 51.18);
  assert.equal(r.cartridge.pressures.Pmax, 4150);
  assert.equal(r.cartridge.lengths.L1Tol, -0.2);
  assert.deepEqual(data.find((x) => x.key === '223_rem').chamber.rifling.i, { degrees: 3, minutes: 10, seconds: 36 });
});

test('records are internally consistent (guards against typos in the data)', () => {
  const F = require('../../js/format.js');
  for (const r of data) {
    const c = r.cartridge, k = r.chamber, p = c.pressures;
    const factor = r.family === 'rimless' || r.family === 'rimmed' || r.family === 'belted' ? 1.25 : 1.3;
    assert.ok(Math.abs(p.PE / p.Pmax - factor) < 0.002, r.key + ' PE/Pmax');
    assert.ok(Math.abs(p.PK / p.Pmax - 1.15) < 0.002, r.key + ' PK/Pmax');
    assert.ok(Math.abs(c.caseHead.R1 - k.breech.R1) < 0.3, r.key + ' R1');
    const jc = c.junctionCone;
    if (jc && jc.alpha !== undefined && c.lengths.L1 !== undefined) {
      const a = F.angleToDegrees(jc.alpha);
      const half = Math.atan((c.powderChamber.P2 - c.collar.H1) / 2 / (c.lengths.L2 - c.lengths.L1)) * 180 / Math.PI;
      assert.ok(Math.abs(half - a / 2) < 0.6, r.key + ' shoulder angle ' + half + ' vs ' + a / 2);
      const apex = c.lengths.L2 + c.collar.H1 / 2 / Math.tan(a / 2 * Math.PI / 180);
      assert.ok(Math.abs(apex - jc.S) < 0.4, r.key + ' S');
    }
  }
});
