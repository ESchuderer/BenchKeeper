const test = require('node:test');
const assert = require('node:assert');
require('../../js/data.js');
const D = require('../../js/drawing.js');
const data = globalThis.CIP.data;

test('markup: accessible name, title block, scale for A4', () => {
  for (const rec of data) {
    const r = D.render(rec);
    assert.ok(r.ok, rec.key);
    assert.ok(r.svg.includes('aria-label="' + rec.name.replace(/&/g, '&amp;') + ' drawing"'), rec.key);
    assert.ok(r.svg.includes('Dimensions in mm'), rec.key);
    assert.ok(r.svg.includes('C.I.P. table ' + rec.tab + ', revised ' + rec.revised), rec.key);
    assert.match(r.scaleText, /^Scale [\d.]+ : 1 \(A4 print\)$/);
    assert.ok(r.printWidthMm <= 180 && r.printWidthMm >= 0.97 * 180, rec.key + ' ' + r.printWidthMm);
    const [, , w, h] = r.viewBox;
    assert.ok(h / w <= 0.62 + 1e-9, rec.key + ' aspect');
  }
});

test('label boxes: inside the viewBox and pairwise disjoint', () => {
  for (const rec of data) {
    const r = D.render(rec);
    const [vx, vy, w, h] = r.viewBox;
    r.labels.forEach((a, i) => {
      assert.ok(a.box.x0 >= vx && a.box.x1 <= vx + w && a.box.y0 >= vy && a.box.y1 <= vy + h, rec.key + ' ' + a.id);
      r.labels.slice(i + 1).forEach((b) => {
        assert.ok(!(a.box.x0 < b.box.x1 && b.box.x0 < a.box.x1 && a.box.y0 < b.box.y1 && b.box.y0 < a.box.y1), rec.key + ' ' + a.text + ' / ' + b.text);
      });
    });
  }
});

test('labels carry symbol and value as published', () => {
  const r = D.render(data.find((x) => x.key === '308_win'));
  const texts = r.labels.map((l) => l.text);
  for (const t of ['L3 51.18', 'L6 71.12', 'R1 12.01', 'R 1.37', 'P1 11.96', 'P2 11.53', 'H1 8.72', 'H2 8.72', 'G1 7.85', 'L1 39.62', 'L2 43.48', 'E1 10.39', '\u03b1 40\u00b0']) {
    assert.ok(texts.includes(t), t);
  }
  const hms = D.render(data.find((x) => x.key === '338_lapua_mag')).labels.map((l) => l.text);
  assert.ok(hms.includes('\u03b1 39\u00b059\'49"'));
});

test('missing values are reported', () => {
  assert.equal(D.missingText({ symbols: ['r1 min'], effect: 'x' }), 'Not published: r1 min (x)');
});
