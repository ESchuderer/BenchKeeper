const test = require('node:test');
const assert = require('node:assert');
require('../../js/data.js');
const F = require('../../js/format.js');
const byKey = (k) => globalThis.CIP.data.find((r) => r.key === k);

test('angles: degrees, and degrees/minutes/seconds', () => {
  assert.equal(F.formatAngle(40), '40\u00b0');
  assert.equal(F.formatAngle({ degrees: 39, minutes: 59, seconds: 49 }), '39\u00b059\'49"');
  assert.equal(F.formatAngle({ degrees: 0, minutes: 42, seconds: 29 }), '0\u00b042\'29"');
  assert.ok(Math.abs(F.angleToDegrees({ degrees: 39, minutes: 59, seconds: 49 }) - 39.99694) < 1e-4);
});

test('symbols follow the brief', () => {
  const m = { eMin: 'e min', r1Min: 'r1 min', r1Max: 'r1 max', alpha: '\u03b1', alpha1: '\u03b11', beta: '\u03b2',
    delta: '\u03b4', deltaL: 'delta L', L3PlusG: 'L3 + G', P1: 'P1', Pmax: 'Pmax' };
  for (const k of Object.keys(m)) assert.equal(F.symbolFor(k), m[k]);
});

test('units', () => {
  assert.equal(F.unitFor('Pmax'), 'bar');
  assert.equal(F.unitFor('PK'), 'bar');
  assert.equal(F.unitFor('PE'), 'bar');
  assert.equal(F.unitFor('EE'), 'J');
  assert.equal(F.unitFor('M'), 'g');
  assert.equal(F.unitFor('Q'), 'mm\u00b2');
  assert.equal(F.unitFor('N'), '');
  assert.equal(F.unitFor('L3'), 'mm');
});

test('tolerance is shown next to its value, never as a row', () => {
  const rec = byKey('308_win');
  const lengths = F.cartridgeTables(rec).find((t) => t.id === 'lengths');
  const l1 = lengths.rows.find((r) => r.symbol === 'L1');
  assert.equal(l1.value, '39.62 -0.2');
  assert.ok(!lengths.rows.some((r) => /Tol$/.test(r.symbol)));
  const all = [...F.cartridgeTables(rec), ...F.chamberTables(rec)].flatMap((t) => t.rows);
  assert.ok(!all.some((r) => /Tol$/.test(r.field)));
});

test('values as published: no thousands separator, decimal point', () => {
  const rows = F.cartridgeTables(byKey('6_5_x_55_se')).flatMap((t) => t.rows);
  assert.equal(rows.find((r) => r.field === 'Pmax').value, '3800');
  assert.equal(rows.find((r) => r.field === 'alpha').value, '50\u00b035\'2"');
  assert.equal(rows.find((r) => r.field === 'L3').value, '55');
  assert.equal(F.cartridgeTables(byKey('308_win')).flatMap((t) => t.rows).find((r) => r.field === 'L3').value, '51.18');
});

test('every field of every record appears once (except tolerances)', () => {
  for (const rec of globalThis.CIP.data) {
    for (const [group, tabs] of [['cartridge', F.cartridgeTables(rec)], ['chamber', F.chamberTables(rec)]]) {
      const expected = Object.values(rec[group]).reduce((n, sec) => n + Object.keys(sec).filter((k) => !/Tol$/.test(k)).length, 0);
      assert.equal(tabs.reduce((n, t) => n + t.rows.length, 0), expected, rec.key + ' ' + group);
    }
  }
});

test('search matches names and alternative names', () => {
  const hit = globalThis.CIP.data.filter((r) => F.matchesQuery(r, '7,62 x 51')).map((r) => r.name);
  assert.deepEqual(hit, ['308 Win.']);
  assert.ok(F.matchesQuery(byKey('223_rem'), '  223 '));
  assert.ok(F.matchesQuery(byKey('22_long_rifle'), '22LR'));
  assert.ok(!F.matchesQuery(byKey('223_rem'), 'zzz'));
});
