const test = require('node:test');
const assert = require('node:assert');
require('../../js/data.js');
const G = require('../../js/geometry.js');
const data = globalThis.CIP.data;
const rec = (k) => data.find((r) => r.key === k);
const near = (a, b, eps = 1e-6) => assert.ok(Math.abs(a - b) < eps, a + ' != ' + b);
const has = (pts, z, r, eps = 1e-6) => pts.some((p) => Math.abs(p[0] - z) < eps && Math.abs(p[1] - r) < eps);

test('rim types', () => {
  const t = (k) => G.build(rec(k)).rimType;
  assert.equal(t('300_win_mag'), 'belted');
  assert.equal(t('22_long_rifle'), 'rimfire');
  assert.equal(t('38_special'), 'rimmed');
  assert.equal(t('9_3_x_74_r'), 'rimmed');
  assert.equal(t('223_rem'), 'rimless');
  assert.equal(t('9_mm_luger'), 'rimless');
});

test('223 Rem.: head chamfer, groove, body, shoulder, neck points', () => {
  const g = G.build(rec('223_rem'));
  const o = g.outer;
  assert.deepEqual(o[0], [0, 0]);
  const c = Math.min(0.45 * Math.tan(35 * Math.PI / 180), 9.6 / 4);
  assert.ok(has(o, 0, 4.8 - c));
  assert.ok(has(o, 0.45, 4.8));
  assert.ok(has(o, 1.14, 4.8));
  assert.ok(has(o, 1.14, 8.43 / 2));
  assert.ok(has(o, 1.14 + 0.76, 8.43 / 2));
  assert.ok(has(o, 3.13, 9.58 / 2));
  assert.deepEqual(o[o.length - 1], [44.7, 6.43 / 2]);
  assert.equal(g.bottleneck, true);
  // shoulder rounded: no sharp corner point at (36.52, 4.5)
  assert.ok(!has(o, 36.52, 4.5, 1e-9));
});

test('308 Win.: shoulder angle through published points is about alpha/2', () => {
  const g = G.build(rec('308_win'));
  const { A, B } = g.shoulder;
  const half = Math.atan((A[1] - B[1]) / (B[0] - A[0])) * 180 / Math.PI;
  assert.ok(Math.abs(half - 20) < 0.5, 'half angle ' + half);
});

test('belted: ramp at delta to the belt, belt to E, step in to P1/2', () => {
  const g = G.build(rec('300_win_mag'));
  const o = g.outer;
  const zEnd = 1.27 + 0.94 + (13.51 / 2 - 12.07 / 2) / Math.tan(35 * Math.PI / 180);
  assert.ok(has(o, zEnd, 13.51 / 2));
  assert.ok(has(o, 5.59, 13.51 / 2));
  assert.ok(has(o, 5.59, 13.03 / 2));
  near(g.head.w, Math.max(zEnd + g.walls.tb, 3.3 + 1.5));
});

test('rimfire: half-round edge reaches R1/2', () => {
  const g = G.build(rec('22_long_rifle'));
  const maxR = Math.max(...g.outer.map((p) => p[1]));
  near(maxR, 7.06 / 2);
  assert.equal(g.head.pocket, null);
  assert.equal(g.heeled, true);
});

test('rimmed without groove steps in at z = R', () => {
  const g = G.build(rec('7_x_65_r'));
  assert.ok(has(g.outer, 1.4, 13.32 / 2));
  assert.ok(has(g.outer, 1.4, 11.89 / 2));
  assert.equal(g.groove, false);
});

test('straight case runs to (H2/2, L3); no shoulder', () => {
  const g = G.build(rec('9_mm_luger'));
  assert.equal(g.bottleneck, false);
  assert.deepEqual(g.outer[g.outer.length - 1], [19.15, 9.65 / 2]);
  assert.equal(g.shoulder, null);
  assert.deepEqual(g.missing, []);
});

test('walls and head: 223 Rem.', () => {
  const g = G.build(rec('223_rem'));
  near(g.walls.tn, (6.43 - 5.7) / 2);
  near(g.walls.tb, 0.6);
  near(g.head.w, Math.max(2.5, 0.25 * 9.58 / 2, 3.04 + 1.5, 3.13 + 0.6));
  assert.deepEqual(g.head.pocket, { d: 4.45, depth: 3.04 });
  assert.deepEqual(G.build(rec('243_win')).head.pocket, { d: 5.33, depth: 3.3 });
  assert.deepEqual(G.build(rec('45_auto')).head.pocket, { d: 5.33, depth: 3.04 });
});

test('bullet: pointy 223 Rem.', () => {
  const b = G.build(rec('223_rem')).bullet;
  near(b.s, 5.7); near(b.zb, 44.7 - 5.7); near(b.Lb, 57.4 - 39);
  near(b.zc, 39 + 0.4 * 18.4);
  near(b.m, 1.27);
  assert.deepEqual(b.exposed[0], [44.7, 2.85]);
  const tip = b.exposed[b.exposed.length - 1];
  near(tip[0], 57.4); near(tip[1], 0.635);
});

test('bullet: shapes and seating', () => {
  const s = (k) => G.build(rec(k)).bullet;
  near(s('9_mm_luger').s, 0.4 * 9.03);
  near(s('9_mm_luger').k, 0.65);
  near(s('22_win_mag_r_f').s, 0.8 * 5.7);
  near(s('22_win_mag_r_f').k, 0.55);
  near(s('40_s_w').k, 0.70);
  near(s('40_s_w').m, 0.55 * 10.17);
  near(s('357_magnum').s, 0.6 * 9.12);
  near(s('357_magnum').k, 0.78);
  near(s('357_magnum').m, 0.6 * 9.12);
});

test('heeled 22 Long Rifle: exposed OD = case OD, seated heel = ID', () => {
  const g = G.build(rec('22_long_rifle'));
  const b = g.bullet;
  assert.equal(b.heeled, true);
  near(b.Re, 5.72 / 2);
  near(b.heelR, 5.72 / 2 - g.walls.tb);
  assert.ok(has(b.section, 15.57, b.heelR));
  assert.ok(b.exposed.every((p) => p[1] <= 5.72 / 2 + 1e-9));
});

test('ogive tangent to the cylinder and ends at the meplat', () => {
  const b = G.build(rec('308_win')).bullet;
  const n = b.section.findIndex((p) => Math.abs(p[0] - b.zc) < 1e-9);
  const p1 = b.section[n], p2 = b.section[n + 1];
  assert.ok(Math.abs(p2[1] - p1[1]) < 0.02 * Math.abs(p2[0] - p1[0]));
});

test('missing values are reported, nothing invented', () => {
  const sym = (k) => G.build(rec(k)).missing.flatMap((m) => m.symbols);
  assert.deepEqual(sym('338_lapua_mag'), ['r1 min']);
  assert.deepEqual(sym('17_hmr'), ['r1 min', 'r2']);
  assert.deepEqual(sym('223_rem'), []);
  const copy = JSON.parse(JSON.stringify(rec('223_rem')));
  delete copy.cartridge.caseHead.E1;
  const g = G.build(copy);
  assert.equal(g.groove, false);
  assert.deepEqual(g.missing[0].symbols, ['E1']);
  delete copy.cartridge.lengths.L3;
  assert.equal(G.build(copy).ok, false);
});

test('all 25 records: finite, z non-decreasing after the head, inner inside outer', () => {
  for (const r of data) {
    const g = G.build(r);
    assert.ok(g.ok, r.key);
    for (const p of [...g.outer, ...g.inner, ...(g.bullet ? g.bullet.section : [])]) {
      assert.ok(isFinite(p[0]) && isFinite(p[1]), r.key);
    }
    for (let i = 1; i < g.outer.length; i++) assert.ok(g.outer[i][0] >= g.outer[i - 1][0] - 1e-9, r.key + ' z order at ' + i);
    for (const p of g.inner) {
      assert.ok(p[1] > 0, r.key + ' inner radius');
      assert.ok(p[1] < Math.max(...g.outer.map((q) => q[1])), r.key);
    }
    assert.ok(g.head.w < r.cartridge.lengths.L1 || !g.bottleneck, r.key);
    if (g.bullet) {
      assert.ok(g.bullet.zc > r.cartridge.lengths.L3 - 1e-9, r.key + ' nose starts outside the case');
      assert.ok(g.bullet.exposed[0][0] === r.cartridge.lengths.L3, r.key);
    }
  }
});
