# Brief: C.I.P. cartridge database (original requirements)

Static web app: reference database of 25 C.I.P. cartridges for reloaders, gunsmiths and engineers, modelled on the cartridge database of OpenBallistics. The 25 records (see `js/data.js`) are the only data; use as given, do not add, change or fetch data.

## Units and display

- Lengths and diameters in mm. Pmax, PK, PE in bar; EE in J; M in g; Q in mm²; N is a count without unit; alpha, alpha1, beta, delta and i are angles. An angle is a number of degrees or `{degrees, minutes, seconds}`; show as `40°` or `39°59'49"`.
- A field `<X>Tol` is the tolerance of `X`: show it next to the value of X (`39.62 -0.2`), never as a row of its own.
- Show values as published, decimal point, no thousands separator (`51.18 mm`, `4150 bar`). Show names as published (`6,5 Creedmoor`).
- Symbols: the field name, except `eMin` "e min", `r1Min` "r1 min", `r1Max` "r1 max", `alpha` "α", `alpha1` "α1", `beta` "β", `delta` "δ", `deltaL` "delta L", `L3PlusG` "L3 + G".

## Start page

- Heading "Cartridges", then every cartridge with its name, family and case length L3. Each name is a link whose text is exactly the record's `name`; it opens the detail view.
- A field labelled "Search" filters by name and alternative names as the user types (`7,62 x 51` finds "308 Win."). A select labelled "Family" (All, rimless, rimmed, belted, pistol, rimfire) filters by family. The text "<n> cartridges" shows how many are listed.

## Detail view

- Heading: the cartridge's name. Then alternative names, family, category, primer type, C.I.P. table (`tab`), country, published and revised dates, pressure method, and the published water capacity with its source link.
- The 2D drawing.
- All cartridge values and all chamber values in tables grouped by section, with columns "Symbol", "Value" and "Unit".
- A "Print" button and a link "All cartridges" back to the list.
- Each detail view has its own address that survives a reload and can be bookmarked.

## Drawing

- Inline SVG computed from the record's values, true to scale: 1 SVG user unit = 1 mm, axis horizontal, head on the left. Accessible name "<name> drawing".
- Upper half is the outside view; lower half is a section (cut walls hatched). A dash-dot centre line.
- Dimension lines with arrowheads and extension lines for L3, L6, R1, R and P1, and, where published, P2, H1, H2, G1, L1, L2, E1 and the shoulder angle α. Each labelled with its symbol and value (`L3 51.18`). Labels do not overlap each other or the outline.
- A title block with the name, C.I.P. table and revision date, "Dimensions in mm", and the scale.
- Scales to the width of a phone screen and prints legibly.

## Geometry rules

`z` runs along the axis from the head face (`z = 0`) to the mouth; `r` is the radius (half the diameter). Points are (r, z). Build the outer half-profile from the axis at the head face to the mouth, then mirror it at the axis.

1. Rim type: family `belted` is belted, `rimfire` is rimfire; otherwise R1/P1 >= 1.05 is rimmed, R1/P1 < 0.98 is rebated, anything else is rimless.
2. Head face and rim edge, from `(0, 0)` outward: where beta and f are published and beta < 90°, a chamfer `(R1/2 - min(f·tan β, R1/4), 0)` to `(R1/2, f)`, then up to `(R1/2, R)`. Rimfire: the rim edge is a half-round of radius `min(R/2, (R1 - P1)/2)` whose outermost point lies at `R1/2`. Otherwise a square corner.
3. Extractor groove, where E and E1 are published: from `(R1/2, R)` in to `(E1/2, R)`, along the floor to `(E1/2, R + e min)`, then a straight ramp out to `(P1/2, E)`. Belted: from the floor end, ramp out at angle δ to the axis up to the belt `R3/2`, follow the belt to `z = E`, then step in to `P1/2`. Without a groove: step in from `(R1/2, R)` to `(P1/2, R)`.
4. Body: a straight line from P1/2 at the body start to `(P2/2, L1)` on a bottleneck case. A case without alpha, L1 or L2 is straight: the body runs to `(H2/2, L3)`.
5. Shoulder: `(P2/2, L1)` to `(H1/2, L2)`. α is the included cone angle (the line lies at α/2 to the axis); draw through the published points and label α. Round the body-side corner with r1 min and the neck-side corner with r2 where published.
6. Neck: `(H1/2, L2)` to `(H2/2, L3)`, then the mouth face.
7. Bullet, from the mouth to the tip at `z = L6`, shank diameter G1, nose shape from `annotations.defaultBulletShape`:
   - Seating depth below the mouth `s`: 1.0·G1 pointy; 0.8·G1 rounded or flat on rifle and rimfire cartridges; 0.4·G1 rounded or flat on pistol cartridges; 0.6·G1 semi_wadcutter. Base at `zb = L3 - s`, bullet length `Lb = L6 - zb`.
   - The cylinder runs from the base to `zb + k·Lb`: k = 0.40 pointy; 0.55 rounded rifle or rimfire, 0.65 rounded pistol; 0.60 flat rifle, 0.70 flat pistol; 0.78 semi_wadcutter.
   - The nose runs to the tip with a flat tip (meplat) of diameter m. Pointy: tangent ogive, `m = max(0.08·G1, 1.27)`, arc radius `ρ = ((G1/2 - m/2)² + n²) / (2·(G1/2 - m/2))` with nose length n, centre at `r = G1/2 - ρ` on the radial line where the nose starts. Rounded: quarter ellipse, `m = 0.15·G1`. Flat: straight cone, `m = 0.55·G1`. Semi_wadcutter: straight cone, `m = 0.6·G1`.
   - Heeled case (H2 - G1 <= 0.015, e.g. 22 Long Rifle): the exposed bullet has the case's outside diameter; the seated heel has the case's inside diameter `H2 - 2·tb`.
   - The outside view hides the seated part; the section shows it inside the case.
8. Section walls: neck wall `tn = (H2 - G1)/2`; body wall `tb = min(max(1.3·tn, 0.6), 0.35·P1/2)`. The inner line follows the outer body, shoulder and neck at these walls (tb along the body, tn along the neck, blended linearly across the shoulder). The solid head runs from the head face to `z = w`, with `w = max(2.5, 0.25·P1/2, pocket depth + 1.5, E + tb where a groove exists, or the belt ramp end + tb on belted cases)`. Primer pocket on centrefire cases: diameter 4.45 for `sp`, `spm`, `sr` and 5.33 for `lp`, `lpm`, `lr`, `lrm`; depth 3.04 for `sp`, `spm`, `sr`, `lp`, `lpm` and 3.3 for `lr`, `lrm`. Rimfire cases have no pocket.
9. If a value a rule needs is missing, draw without that feature and say which value is missing; never invent a number.

## Print

"Print" opens the browser's print dialog. A printed detail view is one A4 portrait page, black on white: page header with the name, the drawing at full width with every label legible, then the tables; no navigation, search or buttons; a footer with the source (C.I.P. TDCC, revised date).

## Look and feel

A technical reference: dense, calm, precise typography, tabular numbers. Light and dark on screen following the system setting; print is always light. Usable on a phone.

## Technology

Plain HTML, CSS and JavaScript. No framework, no build step, no server code, no runtime dependencies, no network requests (no CDNs, web fonts or analytics). `index.html` in the project root with its CSS and JS files. Works fully when opened directly from disk in Chromium (`file://`) and when served by any static file server. Dev tools (e.g. test runner) may be npm dev dependencies. Interface in English.

## Process

Work through the full development process: use installed skills/agents (understand, specify, plan, tests first, build, verify, review), and follow global and project rules.
