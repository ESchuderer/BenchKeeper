# Cartridge database

Status: ready-for-agent

Static web app: reference database of 25 C.I.P. cartridges (modelled on OpenBallistics). Source of truth for requirements is the original brief; this file records the decisions made while specifying it.

## Constraints

- Plain HTML/CSS/JS, no framework, no build, no network requests, no runtime deps.
- `index.html` works from `file://` in Chromium and from any static server. Consequences:
  - Data ships as a script (`window.CARTRIDGES = [...]`), not fetched JSON (fetch of `file://` is blocked).
  - No ES module `<script type="module">` (blocked on `file://`); classic scripts with one global namespace; the same files are loadable in Node for tests (UMD-style `module.exports` guard).
  - Detail view address uses the URL hash: `#/cartridge/<key>`; survives reload, bookmarkable, works on `file://`.
- Dev tools (test runner) are npm devDependencies only.

## Modules (seams)

1. `format` — pure: angle, value+tolerance, symbol labels, unit rows.
2. `geometry` — pure: record -> drawing model (rim type, half-profile points, section, bullet, dimension features, missing-value list). No DOM.
3. `drawing` — record -> SVG string (labels placed without overlap).
4. `app` — list/search/filter, hash routing, detail view, print.

## Decisions

- Missing-value notices are shown under the drawing ("Not drawn: <feature> — missing <value>"), never invented numbers.
- Angle display: `40°` for numbers, `39°59'49"` for objects (zero minutes/seconds still printed as given for objects).
- `<X>Tol` is rendered next to X as `value tol` (`39.62 -0.2`); never a row.
- Search matches `name` and `alternativeNames`, case-insensitive, whitespace-insensitive-ish substring.
- Detail view for unknown key shows a "not found" message with link back.

- Heeled case (22 Long Rifle): the formula gives a neck wall of 0, so the wall along the neck is tb; the seated heel then has diameter H2 - 2·tb as the brief says.
- Straight cases have no shoulder to blend across: the inner wall thins from tb to tn over tb - tn mm ending at the bullet base, so the seated bullet fits the bore. Without a bullet it thins linearly to the mouth.
- Fillets use at most half of each adjacent segment; where that limits the radius, the arc is smaller than r1 min or r2.
- Shoulder angle α is a callout with a leader and arrowhead on the shoulder (the cone apex lies inside or beyond the bullet, so angle lines would clutter the drawing).
- Scale in the title block is the A4 print scale: min(190 mm / drawing width, 105 mm / drawing height).

## Acceptance

See the brief; every rule in "Geometry rules" 1-9 is covered by a geometry test with a literal expected value computed by hand from a record.
