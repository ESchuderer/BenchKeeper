# Cartridge reference

A static reference database of C.I.P. cartridges for reloaders, gunsmiths and engineers, with a dimensioned drawing of each cartridge.

## Language

**Cartridge**:
One published C.I.P. record: names, classification, cartridge values, chamber values.
_Avoid_: Round, load, ammo

**Cartridge values**:
The dimensions and pressures of the cartridge itself (the `cartridge` part of a record).
_Avoid_: Case dimensions

**Chamber values**:
The dimensions of the chamber and barrel that the cartridge must fit (the `chamber` part of a record).
_Avoid_: Gun values

**Symbol**:
The short label of a value in a table or on the drawing (`L3`, `α`, `r1 min`).
_Avoid_: Code, abbreviation

**Tolerance**:
The published deviation of a value, shown beside that value and never as a row of its own.
_Avoid_: Error, variance

**Family**:
The case form class: rimless, rimmed, belted, pistol or rimfire.
_Avoid_: Type, class

**Rim type**:
How the head is drawn: rimless, rimmed, rebated, belted or rimfire. Derived from family and R1/P1.
_Avoid_: Head style

**Drawing**:
The to-scale 2D outline of a cartridge, outside view above the axis and section below.
_Avoid_: Diagram, figure

**Half-profile**:
The outer outline from the axis at the head face to the mouth, mirrored at the axis to form the drawing.
_Avoid_: Contour

**Section**:
The lower half of the drawing, with cut walls hatched.
_Avoid_: Cutaway

**Missing value**:
A value a drawing rule needs that the record does not publish. The feature is left out and the gap is stated.
_Avoid_: Default, fallback

**Detail view**:
The page of one cartridge, with its own address.
_Avoid_: Card, profile page
