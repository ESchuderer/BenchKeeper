# C.I.P. cartridges

A static reference database of 25 C.I.P. cartridges with a dimensioned, to-scale drawing of each.
Open `index.html` directly from disk, or serve the folder with any static file server. No build step, no network access.

- `index.html`, `css/styles.css`, `js/*.js`: the app. Plain HTML, CSS and JavaScript.
- `js/data.js`: the 25 records (OpenBallistics, MIT, commit e83db43), used as given.
- `js/format.js`: display rules (symbols, units, angles, tolerances, table sections).
- `js/geometry.js`: record to drawing model (profile, bullet, section walls); no DOM.
- `js/drawing.js`: dimension layout and the inline SVG; 1 SVG user unit = 1 mm.
- `js/app.js`: list, detail view, hash routing (`#/cartridge/<key>`), print.
- `GLOSSARY.md`: domain vocabulary. `.scratch/cartridge-database/`: brief and spec.

## Tests (development only)

```
npm install
npm test               # unit tests (node:test), no browser
npx playwright install chromium
npm run test:e2e       # browser tests: file://, static server, print to PDF, phone width, dark mode
```

The app itself has no dependencies.
