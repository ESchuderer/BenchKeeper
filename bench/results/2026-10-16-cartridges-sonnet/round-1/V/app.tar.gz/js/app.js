/* Cartridge reference: list, detail view, hash routing, print. */
(function () {
  'use strict';

  var F = window.CipFormat;
  var D = window.CipDrawing;
  var CARTRIDGES = window.CARTRIDGES;
  var FAMILIES = ['rimless', 'rimmed', 'belted', 'pistol', 'rimfire'];
  var main = document.getElementById('main');
  var footer = document.getElementById('footer');
  var state = { query: '', family: 'all' };

  function esc(s) {
    return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  }

  function normal(s) {
    return String(s).toLowerCase().replace(/\s+/g, ' ').trim();
  }

  function find(key) {
    for (var i = 0; i < CARTRIDGES.length; i++) if (CARTRIDGES[i].key === key) return CARTRIDGES[i];
    return null;
  }

  function matches(rec, query, family) {
    if (family !== 'all' && rec.family !== family) return false;
    if (!query) return true;
    return [rec.name].concat(rec.alternativeNames || []).some(function (n) { return normal(n).indexOf(query) >= 0; });
  }

  // "39.62 -0.2" -> value with the tolerance set apart in a span; the text stays "39.62 -0.2".
  function valueHtml(text) {
    var m = /^(\S+) ([+-][\d.]+)$/.exec(text);
    return m ? esc(m[1]) + ' <span class="tol">' + esc(m[2]) + '</span>' : esc(text);
  }

  // ---- list ------------------------------------------------------------------------------

  function rowsHtml(list) {
    if (!list.length) return '<tr><td colspan="3" class="empty">No cartridge matches.</td></tr>';
    return list.map(function (r) {
      return '<tr><th scope="row"><a href="#/cartridge/' + encodeURIComponent(r.key) + '">' + esc(r.name) + '</a></th>' +
        '<td>' + esc(r.family) + '</td>' +
        '<td class="num">' + valueHtml(F.valueWithTolerance(r.cartridge.lengths, 'L3')) + '</td></tr>';
    }).join('');
  }

  function renderList() {
    document.title = 'C.I.P. cartridges';
    main.className = 'view-list';
    main.innerHTML =
      '<h1 id="title" tabindex="-1">Cartridges</h1>' +
      '<div class="filters" role="search">' +
        '<div class="field"><label for="search">Search</label>' +
        '<input id="search" type="search" autocomplete="off" spellcheck="false" placeholder="Name or alternative name"></div>' +
        '<div class="field"><label for="family">Family</label><select id="family"><option value="all">All</option>' +
        FAMILIES.map(function (f) { return '<option value="' + f + '">' + f + '</option>'; }).join('') + '</select></div>' +
        '<p id="count" class="count" role="status" aria-live="polite"></p>' +
      '</div>' +
      '<table class="list"><thead><tr><th scope="col">Name</th><th scope="col">Family</th><th scope="col" class="num">L3 <span class="unit">mm</span></th></tr></thead><tbody id="rows"></tbody></table>';
    var search = document.getElementById('search');
    var family = document.getElementById('family');
    search.value = state.query;
    family.value = state.family;
    function update() {
      state.query = search.value;
      state.family = family.value;
      var list = CARTRIDGES.filter(function (r) { return matches(r, normal(state.query), state.family); });
      document.getElementById('rows').innerHTML = rowsHtml(list);
      document.getElementById('count').textContent = list.length + ' cartridges';
    }
    search.addEventListener('input', update);
    family.addEventListener('change', update);
    update();
    footer.innerHTML = 'Data: C.I.P. TDCC via <a href="https://github.com/PiMetry/OpenBallistics">OpenBallistics</a> (MIT).';
  }

  // ---- detail ----------------------------------------------------------------------------

  function factsHtml(r) {
    var cap = r.annotations && r.annotations.publishedCapacity;
    var capacity = cap
      ? esc(F.number(cap.grH2O)) + ' gr H<sub>2</sub>O, source: <a href="' + esc(cap.url) + '" target="_blank" rel="noopener noreferrer">' + esc(cap.source) + '</a>' +
        (cap.note ? ' <span class="note">(' + esc(cap.note) + ')</span>' : '')
      : 'not published';
    var items = [
      ['Alternative names', r.alternativeNames && r.alternativeNames.length ? r.alternativeNames.map(esc).join(', ') : 'none'],
      ['Family', esc(r.family)],
      ['Category', esc(r.annotations.category)],
      ['Primer type', esc(r.annotations.primerType)],
      ['C.I.P. table', esc(r.tab)],
      ['Country', esc(r.country)],
      ['Published', esc(r.published)],
      ['Revised', esc(r.revised)],
      ['Pressure method', esc(r.pressureMethod)],
      ['Water capacity', capacity]
    ];
    return '<dl class="facts">' + items.map(function (i) {
      return '<div><dt>' + i[0] + '</dt><dd>' + i[1] + '</dd></div>';
    }).join('') + '</dl>';
  }

  function tablesHtml(part, partName) {
    return F.sections(part, partName).map(function (s) {
      return '<table class="values"><caption>' + esc(s.title) + '</caption>' +
        '<thead><tr><th scope="col">Symbol</th><th scope="col" class="num">Value</th><th scope="col">Unit</th></tr></thead><tbody>' +
        s.rows.map(function (row) {
          return '<tr><th scope="row">' + esc(row.symbol) + '</th><td class="num">' + valueHtml(row.value) + '</td><td class="unit">' + esc(row.unit) + '</td></tr>';
        }).join('') + '</tbody></table>';
    }).join('');
  }

  function renderDetail(r) {
    document.title = r.name + ' – C.I.P. cartridges';
    main.className = 'view-detail';
    var lay = D.layout(r);
    var notes = lay.missing.length
      ? '<div class="drawing-notes"><h3>Not drawn</h3><ul>' + lay.missing.map(function (m) { return '<li>' + esc(m.message) + '</li>'; }).join('') + '</ul></div>'
      : '';
    main.innerHTML =
      '<header class="page-header"><h1 id="title" tabindex="-1">' + esc(r.name) + '</h1>' +
      '<p class="kicker">C.I.P. cartridge, table ' + esc(r.tab) + '</p></header>' +
      '<nav class="toolbar" aria-label="Cartridge actions"><a class="button" href="#/">All cartridges</a>' +
      '<button type="button" id="print">Print</button></nav>' +
      factsHtml(r) +
      '<figure class="drawing-figure">' + D.svg(r) + notes + '</figure>' +
      '<section class="values-section" aria-labelledby="cv"><h2 id="cv">Cartridge values</h2><div class="tables">' + tablesHtml(r.cartridge, 'cartridge') + '</div></section>' +
      '<section class="values-section" aria-labelledby="chv"><h2 id="chv">Chamber values</h2><div class="tables">' + tablesHtml(r.chamber, 'chamber') + '</div></section>';
    document.getElementById('print').addEventListener('click', function () { window.print(); });
    footer.innerHTML = 'Source: C.I.P. TDCC, revised ' + esc(r.revised);
  }

  function renderNotFound() {
    document.title = 'Cartridge not found – C.I.P. cartridges';
    main.className = 'view-missing';
    main.innerHTML = '<h1 id="title" tabindex="-1">Cartridge not found</h1><p>There is no cartridge with this address.</p>' +
      '<nav class="toolbar"><a class="button" href="#/">All cartridges</a></nav>';
    footer.textContent = '';
  }

  // ---- routing ---------------------------------------------------------------------------

  function route() {
    var m = /^#\/cartridge\/(.+)$/.exec(window.location.hash);
    if (m) {
      var key;
      try { key = decodeURIComponent(m[1]); } catch (e) { key = m[1]; }
      var rec = find(key);
      if (rec) renderDetail(rec); else renderNotFound();
    } else {
      renderList();
    }
  }

  var first = true;
  function onRoute() {
    route();
    if (!first) {
      window.scrollTo(0, 0);
      var t = document.getElementById('title');
      if (t) t.focus({ preventScroll: true });
    }
    first = false;
  }

  window.addEventListener('hashchange', onRoute);
  onRoute();
})();
