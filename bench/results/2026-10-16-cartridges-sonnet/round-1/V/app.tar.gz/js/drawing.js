/* Drawing: record -> layout (dimension lines, labels, outline) -> inline SVG string.
   SVG user units are millimetres: x = z along the axis (head on the left), y = -r in the outside view
   (upper half) and y = +r in the section (lower half). */
(function (root) {
  'use strict';

  var F = typeof require === 'function' && typeof module !== 'undefined' ? require('./format.js') : root.CipFormat;
  var G = typeof require === 'function' && typeof module !== 'undefined' ? require('./geometry.js') : root.CipGeometry;

  var CHAR_W = 0.62; // label width per character, in font sizes (the drawing uses a monospace font)
  var A4_PRINT_WIDTH = 190; // mm of A4 portrait inside 10 mm margins
  var A4_PRINT_HEIGHT = 105; // mm the printed drawing may take, so that drawing and tables share one page

  function round(n) {
    return Math.round(n * 1000) / 1000;
  }

  function esc(s) {
    return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  }

  function has(v) {
    return v !== undefined && v !== null;
  }

  function labelRect(text, fs, x, yBase, anchor) {
    var w = text.length * CHAR_W * fs;
    var x0 = anchor === 'middle' ? x - w / 2 : anchor === 'end' ? x - w : x;
    return { x: x0, y: yBase - 0.8 * fs, w: w, h: 1.05 * fs };
  }

  function labelText(rec, partName, key) {
    var sec = rec.cartridge[partName];
    return F.symbol(key) + ' ' + F.valueWithTolerance(sec, key);
  }

  function rectsOverlap(a, b, pad) {
    pad = pad || 0;
    return a.x < b.x + b.w + pad && b.x < a.x + a.w + pad && a.y < b.y + b.h + pad && b.y < a.y + a.h + pad;
  }

  function segmentHitsRect(a, b, r) {
    var t0 = 0, t1 = 1;
    var dx = b[0] - a[0], dy = b[1] - a[1];
    var p = [-dx, dx, -dy, dy];
    var q = [a[0] - r.x, r.x + r.w - a[0], a[1] - r.y, r.y + r.h - a[1]];
    for (var i = 0; i < 4; i++) {
      if (p[i] === 0) { if (q[i] < 0) return false; continue; }
      var t = q[i] / p[i];
      if (p[i] < 0) { if (t > t1) return false; if (t > t0) t0 = t; } else { if (t < t0) return false; if (t < t1) t1 = t; }
    }
    return true;
  }

  function polylineHitsRect(poly, r) {
    for (var i = 1; i < poly.length; i++) if (segmentHitsRect(poly[i - 1], poly[i], r)) return true;
    return false;
  }

  // ---- layout ----------------------------------------------------------------------------

  function layout(rec) {
    var model = G.build(rec);
    var c = rec.cartridge;
    var ch = c.caseHead || {}, pc = c.powderChamber || {}, co = c.collar || {}, L = c.lengths || {}, pj = c.projectile || {};
    var bullet = model.bullet;

    // outlines in SVG coordinates
    var outsideCase = model.outer.map(function (p) { return [p[1], -p[0]]; });
    var mouthR = co.H2 / 2;
    var outside = outsideCase.slice();
    if (bullet) {
      var ex = bullet.exposed;
      if (ex[0][0] !== mouthR) outside.push([L.L3, -ex[0][0]]);
      outside = outside.concat(ex.map(function (p) { return [p[1], -p[0]]; }));
    }
    var sectionOutline;
    var hatch = null;
    var bulletSection = bullet ? bullet.outline.map(function (p) { return [p[1], p[0]]; }) : null;
    if (model.inner) {
      var poly = [];
      var pocket = model.head.pocket;
      var pr = pocket ? pocket.diameter / 2 : 0;
      poly.push([0, pr]);
      model.outer.slice(1).forEach(function (p) { poly.push([p[1], p[0]]); });
      model.inner.slice().reverse().forEach(function (p) { poly.push([p[1], p[0]]); });
      poly.push([model.head.w, 0]);
      if (pocket) poly.push([pocket.depth, 0], [pocket.depth, pr]);
      poly.push(poly[0]);
      hatch = poly;
      sectionOutline = poly;
    } else {
      sectionOutline = model.outer.map(function (p) { return [p[1], p[0]]; });
      sectionOutline.unshift([0, 0]);
    }
    if (bulletSection) sectionOutline = sectionOutline.concat([[NaN, NaN]]);

    var rMax = Math.max.apply(null, model.outer.map(function (p) { return p[0]; }));
    var zEnd = bullet ? L.L6 : L.L3;
    var fs = Math.max(2.6, (zEnd + 60) / 23);
    var a = 0.6 * fs; // arrow length
    var step = 1.75 * fs;
    var gap = 1.6 * fs;

    var dims = [];
    var lines = []; // every drawn thin line: [x1, y1, x2, y2]
    var arrows = []; // {x, y, dx, dy}: tip and direction
    var rects = [];

    function addLabel(dim, text, x, yBase, anchor) {
      dim.label = { text: text, x: x, y: yBase, anchor: anchor, rect: labelRect(text, fs, x, yBase, anchor) };
      rects.push(dim.label.rect);
    }

    // length dimensions from the head face, stacked above the outside view
    var rows = [];
    if (has(L.L1) && model.shoulder) rows.push({ key: 'L1', z: L.L1, r: model.shoulder.from[0] });
    if (has(L.L2) && model.shoulder) rows.push({ key: 'L2', z: L.L2, r: model.shoulder.to[0] });
    if (has(L.L3)) rows.push({ key: 'L3', z: L.L3, r: mouthR });
    if (has(L.L6) && bullet) rows.push({ key: 'L6', z: L.L6, r: bullet.meplat / 2 });
    rows.sort(function (p, q) { return p.z - q.z; });
    var headTop = model.outer[1][0];
    rows.forEach(function (row, i) {
      var y = -(rMax + gap + i * step);
      var d = { id: row.key, kind: 'length' };
      lines.push([0, -headTop - 0.3 * fs, 0, y - 0.5 * fs]);
      lines.push([row.z, -row.r - 0.3 * fs, row.z, y - 0.5 * fs]);
      lines.push([0, y, row.z, y]);
      arrows.push({ x: 0, y: y, dx: 1, dy: 0 }, { x: row.z, y: y, dx: -1, dy: 0 });
      addLabel(d, labelText(rec, 'lengths', row.key), row.z / 2, y - 0.3 * fs, 'middle');
      dims.push(d);
    });
    var topY = -(rMax + gap + Math.max(rows.length - 1, 0) * step);

    // rim thickness R below the head, with the arrows outside because the dimension is short
    var lowerRows = 0;
    if (has(ch.R)) {
      var yR = rMax + gap;
      var rimR = ch.R1 / 2;
      var dR = { id: 'R', kind: 'length' };
      lines.push([0, headTop + 0.3 * fs, 0, yR + 0.5 * fs]);
      lines.push([ch.R, rimR + 0.3 * fs, ch.R, yR + 0.5 * fs]);
      lines.push([-2.2 * a, yR, 0, yR]);
      lines.push([ch.R, yR, ch.R + 2.2 * a, yR]);
      arrows.push({ x: 0, y: yR, dx: 1, dy: 0 }, { x: ch.R, y: yR, dx: -1, dy: 0 });
      addLabel(dR, labelText(rec, 'caseHead', 'R'), ch.R + 2.2 * a + 0.4 * fs, yR + 0.3 * fs, 'start');
      dims.push(dR);
      lowerRows = 1;
    }

    // diameter dimensions in columns left of the head and right of the bullet tip
    function columns(items, side) {
      items.sort(function (p, q) { return p.d - q.d; });
      var up = 0, down = 0;
      var nUp = Math.ceil(items.length / 2), nDown = Math.floor(items.length / 2);
      items.forEach(function (it, i) {
        var x = side < 0 ? -(i + 1) * step : zEnd + (i + 1) * step;
        var r = it.d / 2;
        var d = { id: it.key, kind: 'diameter' };
        var toward = side < 0 ? -1 : 1;
        // extension lines run from the feature to just past the column
        lines.push([it.z - toward * 0.3 * fs, -r, x + toward * 0.5 * fs, -r]);
        lines.push([it.z - toward * 0.3 * fs, r, x + toward * 0.5 * fs, r]);
        lines.push([x, -r, x, r]);
        arrows.push({ x: x, y: -r, dx: 0, dy: 1 }, { x: x, y: r, dx: 0, dy: -1 });
        var upward = i % 2 === 0;
        var k = upward ? up++ : down++;
        var count = upward ? nUp : nDown;
        var level = count - 1 - k; // the nearest column gets the outermost level
        var yBase;
        if (upward) yBase = -(rMax + gap + level * step) - 0.3 * fs;
        else yBase = rMax + gap + (level + (side < 0 ? lowerRows : 0)) * step + 0.3 * fs;
        var anchor = side < 0 ? 'end' : 'start';
        var lx = x + (side < 0 ? 0.3 : -0.3) * fs;
        var stemEnd = upward ? yBase + 0.2 * fs : yBase - 0.8 * fs - 0.2 * fs;
        lines.push([x, upward ? -r : r, x, stemEnd]);
        addLabel(d, labelText(rec, it.part, it.key), lx, yBase, anchor);
        dims.push(d);
      });
    }

    var left = [], right = [];
    if (has(ch.R1)) left.push({ key: 'R1', part: 'caseHead', d: ch.R1, z: (ch.R || 0) / 2 });
    if (has(pc.P1)) left.push({ key: 'P1', part: 'powderChamber', d: pc.P1, z: model.bodyStart });
    if (model.head.groove && has(ch.E1)) left.push({ key: 'E1', part: 'caseHead', d: ch.E1, z: ch.R + ch.eMin / 2 });
    if (bullet && has(pj.G1)) right.push({ key: 'G1', part: 'projectile', d: bullet.heeled ? co.H2 : pj.G1, z: Math.max(bullet.cylinderEnd, L.L3) });
    if (has(co.H2)) right.push({ key: 'H2', part: 'collar', d: co.H2, z: L.L3 });
    if (model.shoulder && has(co.H1)) right.push({ key: 'H1', part: 'collar', d: co.H1, z: L.L2 });
    if (model.shoulder && has(pc.P2)) right.push({ key: 'P2', part: 'powderChamber', d: pc.P2, z: L.L1 });
    columns(left, -1);
    columns(right, 1);

    // shoulder angle: a leader from the shoulder to a label below the section
    if (model.shoulder && has(model.shoulder.alpha)) {
      var s = model.shoulder;
      var zm = (s.from[1] + s.to[1]) / 2;
      var rm = (s.from[0] + s.to[0]) / 2;
      var text = F.symbol('alpha') + ' ' + F.angle(c.junctionCone.alpha);
      var dA = { id: 'alpha', kind: 'angle' };
      var yBase2 = rMax + gap + 0.8 * fs + 0.3 * fs;
      addLabel(dA, text, zm, yBase2, 'middle');
      var tries = 0;
      while (tries++ < 20 && rects.slice(0, -1).some(function (r) { return rectsOverlap(r, dA.label.rect, 0.2 * fs); })) {
        yBase2 += step;
        dA.label.y = yBase2;
        dA.label.rect = labelRect(text, fs, zm, yBase2, 'middle');
        rects[rects.length - 1] = dA.label.rect;
      }
      lines.push([zm, rm, zm, dA.label.rect.y - 0.2 * fs]);
      arrows.push({ x: zm, y: rm, dx: 0, dy: -1 });
      dims.push(dA);
    }

    // title block below everything
    var minX = 0, maxX = zEnd, minY = Math.min(topY - 1.2 * fs, -rMax), maxY = rMax;
    function grow(x, y) {
      if (x < minX) minX = x;
      if (x > maxX) maxX = x;
      if (y < minY) minY = y;
      if (y > maxY) maxY = y;
    }
    lines.forEach(function (l) { grow(l[0], l[1]); grow(l[2], l[3]); });
    rects.forEach(function (r) { grow(r.x, r.y); grow(r.x + r.w, r.y + r.h); });
    var pad = 1.2 * fs;
    minX -= pad; maxX += pad; minY -= pad;

    var tbLines = [rec.name, 'C.I.P. table ' + rec.tab, 'Revised ' + rec.revised, 'Dimensions in mm', null];
    var tbW = 25 * fs;
    var tbH = 4.9 * fs;
    var width = Math.max(maxX - minX, tbW + 2 * pad);
    var tb = { x: minX + pad, y: maxY + 1.4 * fs, w: tbW, h: tbH };
    var bounds = { x: minX, y: minY, w: width, h: tb.y + tb.h + pad - minY };
    var scale = Math.min(A4_PRINT_WIDTH / bounds.w, A4_PRINT_HEIGHT / bounds.h);
    tbLines[4] = 'Scale ' + (scale >= 1 ? round(Math.round(scale * 10) / 10) + ' : 1' : '1 : ' + round(Math.round(10 / scale) / 10)) + ' (A4 print)';

    return {
      model: model, fontSize: fs, arrow: a, bounds: bounds, dims: dims, zEnd: zEnd,
      lines: lines, arrows: arrows,
      outline: { outside: outside, section: sectionOutline.filter(function (p) { return !isNaN(p[0]); }).concat(bulletSection || []) },
      hatch: hatch, bulletSection: bulletSection, outsideCase: outsideCase,
      titleBlock: { rect: tb, lines: tbLines },
      missing: model.missing
    };
  }

  // ---- SVG -------------------------------------------------------------------------------

  function pathOf(points, close) {
    var d = '';
    var pen = false;
    points.forEach(function (p) {
      if (isNaN(p[0])) { pen = false; return; }
      d += (pen ? 'L' : 'M') + round(p[0]) + ' ' + round(p[1]);
      pen = true;
    });
    return d + (close ? 'Z' : '');
  }

  function svg(rec) {
    var lay = layout(rec);
    var b = lay.bounds;
    var fs = lay.fontSize;
    var o = [];
    o.push('<svg class="drawing" role="img" aria-label="' + esc(rec.name) + ' drawing" viewBox="' +
      [b.x, b.y, b.w, b.h].map(round).join(' ') + '" preserveAspectRatio="xMidYMid meet" font-size="' + round(fs) + '">');
    o.push('<defs><pattern id="hatch" class="hatch" patternUnits="userSpaceOnUse" width="0.9" height="0.9" patternTransform="rotate(45)">' +
      '<line x1="0" y1="0" x2="0" y2="0.9"/></pattern>' +
      '<pattern id="hatch-bullet" class="hatch hatch-bullet" patternUnits="userSpaceOnUse" width="1.2" height="1.2" patternTransform="rotate(-45)">' +
      '<line x1="0" y1="0" x2="0" y2="1.2"/></pattern></defs>');
    if (lay.hatch) o.push('<path class="cut" d="' + pathOf(lay.hatch, true) + '" fill="url(#hatch)"/>');
    if (lay.bulletSection) o.push('<path class="bullet-cut" d="' + pathOf(lay.bulletSection, true) + '" fill="url(#hatch-bullet)"/>');
    o.push('<path class="outline" d="' + pathOf(lay.outline.outside) + '"/>');
    var s = lay.model.inner ? lay.hatch : lay.outline.section;
    o.push('<path class="outline" d="' + pathOf(s) + '"/>');
    if (lay.bulletSection) o.push('<path class="outline" d="' + pathOf(lay.bulletSection, true) + '"/>');
    o.push('<line class="centre" x1="' + round(-1.1 * fs) + '" y1="0" x2="' + round(lay.zEnd + 1.1 * fs) + '" y2="0"/>');
    o.push('<g class="dims">');
    lay.lines.forEach(function (l) {
      o.push('<line class="dim" x1="' + round(l[0]) + '" y1="' + round(l[1]) + '" x2="' + round(l[2]) + '" y2="' + round(l[3]) + '"/>');
    });
    var a = lay.arrow;
    lay.arrows.forEach(function (ar) {
      var bx = ar.x - ar.dx * a, by = ar.y - ar.dy * a;
      var nx = -ar.dy * a * 0.17, ny = ar.dx * a * 0.17;
      o.push('<path class="arrow" d="M' + round(ar.x) + ' ' + round(ar.y) + 'L' + round(bx + nx) + ' ' + round(by + ny) + 'L' + round(bx - nx) + ' ' + round(by - ny) + 'Z"/>');
    });
    o.push('</g><g class="labels">');
    lay.dims.forEach(function (d) {
      var l = d.label;
      o.push('<text class="label" x="' + round(l.x) + '" y="' + round(l.y) + '" text-anchor="' + l.anchor + '">' + esc(l.text) + '</text>');
    });
    o.push('</g>');
    var tb = lay.titleBlock.rect;
    var tbLines = lay.titleBlock.lines;
    o.push('<g class="title-block"><rect x="' + round(tb.x) + '" y="' + round(tb.y) + '" width="' + round(tb.w) + '" height="' + round(tb.h) + '"/>');
    // name on top, then a 2 x 2 grid: table | revision, units | scale
    var small = 0.85 * fs;
    o.push('<text class="title-name" x="' + round(tb.x + 0.6 * fs) + '" y="' + round(tb.y + 1.4 * fs) + '">' + esc(tbLines[0]) + '</text>');
    [[1, 0, 0], [2, 1, 0], [3, 0, 1], [4, 1, 1]].forEach(function (c) {
      o.push('<text class="title-line" font-size="' + round(small) + '" x="' + round(tb.x + 0.6 * fs + c[1] * 11.2 * fs) + '" y="' + round(tb.y + 2.9 * fs + c[2] * 1.2 * fs) + '">' + esc(tbLines[c[0]]) + '</text>');
    });
    o.push('</g></svg>');
    return o.join('');
  }

  var api = { layout: layout, svg: svg, rectsOverlap: rectsOverlap, polylineHitsRect: polylineHitsRect };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  else root.CipDrawing = api;
})(typeof window !== 'undefined' ? window : globalThis);
