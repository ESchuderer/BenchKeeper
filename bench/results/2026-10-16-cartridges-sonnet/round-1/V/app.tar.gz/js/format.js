/* Display rules for cartridge values: symbols, units, angles, tolerances, table sections. */
(function (root) {
  'use strict';

  var ANGLE_KEYS = { alpha: 1, alpha1: 1, beta: 1, delta: 1, i: 1 };
  var UNITS = { Pmax: 'bar', PK: 'bar', PE: 'bar', EE: 'J', M: 'g', Q: 'mm²', N: '' };
  var SYMBOLS = {
    eMin: 'e min', r1Min: 'r1 min', r1Max: 'r1 max',
    alpha: 'α', alpha1: 'α1', beta: 'β', delta: 'δ',
    deltaL: 'delta L', L3PlusG: 'L3 + G'
  };
  var SECTION_TITLES = {
    caseHead: 'Case head', collar: 'Collar', junctionCone: 'Junction cone', lengths: 'Lengths',
    misc: 'Miscellaneous', powderChamber: 'Powder chamber', pressures: 'Pressures', projectile: 'Projectile',
    barrel: 'Barrel', breech: 'Breech', grooves: 'Grooves', rifling: 'Rifling'
  };
  var SECTION_ORDER = {
    cartridge: ['caseHead', 'powderChamber', 'collar', 'junctionCone', 'lengths', 'projectile', 'pressures', 'misc'],
    chamber: ['breech', 'powderChamber', 'collar', 'junctionCone', 'lengths', 'barrel', 'grooves', 'rifling']
  };

  function number(n) {
    return String(n);
  }

  function isAngleObject(a) {
    return a !== null && typeof a === 'object' && 'degrees' in a;
  }

  function angle(a) {
    if (isAngleObject(a)) return a.degrees + '°' + a.minutes + "'" + a.seconds + '"';
    return number(a) + '°';
  }

  function symbol(key) {
    return Object.prototype.hasOwnProperty.call(SYMBOLS, key) ? SYMBOLS[key] : key;
  }

  function unit(key) {
    if (ANGLE_KEYS[key]) return '';
    return Object.prototype.hasOwnProperty.call(UNITS, key) ? UNITS[key] : 'mm';
  }

  function isTolerance(key, section) {
    return /Tol$/.test(key) && Object.prototype.hasOwnProperty.call(section, key.slice(0, -3));
  }

  function value(key, v) {
    return ANGLE_KEYS[key] ? angle(v) : number(v);
  }

  // The value of `key` in `section` with its tolerance next to it ("39.62 -0.2").
  function valueWithTolerance(section, key) {
    var text = value(key, section[key]);
    var tol = section[key + 'Tol'];
    if (tol !== undefined) text += ' ' + (tol > 0 ? '+' : '') + number(tol);
    return text;
  }

  function rows(section) {
    return Object.keys(section)
      .filter(function (key) { return !isTolerance(key, section); })
      .map(function (key) {
        return { symbol: symbol(key), value: valueWithTolerance(section, key), unit: unit(key) };
      });
  }

  // Grouped rows of `record.cartridge` or `record.chamber`; empty groups are left out.
  function sections(part, partName) {
    var order = SECTION_ORDER[partName] || [];
    var keys = order.filter(function (k) { return part[k]; })
      .concat(Object.keys(part).filter(function (k) { return order.indexOf(k) < 0; }));
    return keys
      .map(function (k) { return { key: k, title: SECTION_TITLES[k] || k, rows: rows(part[k]) }; })
      .filter(function (s) { return s.rows.length > 0; });
  }

  var api = {
    number: number, angle: angle, symbol: symbol, unit: unit,
    valueWithTolerance: valueWithTolerance, rows: rows, sections: sections
  };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  else root.CipFormat = api;
})(typeof window !== 'undefined' ? window : globalThis);
