/* Cartridge geometry: record -> drawing model. No DOM.
   Points are [r, z]: r is the radius, z runs along the axis from the head face (z = 0) to the mouth.
   Arcs are sampled into short segments so the same points serve drawing, clipping and overlap tests. */
(function (root) {
  'use strict';

  var F = typeof require === 'function' && typeof module !== 'undefined' ? require('./format.js') : root.CipFormat;
  var RAD = Math.PI / 180;

  function degrees(a) {
    if (a === undefined || a === null) return undefined;
    if (typeof a === 'object') return a.degrees + a.minutes / 60 + a.seconds / 3600;
    return a;
  }

  function has(v) {
    return v !== undefined && v !== null;
  }

  function section(rec, name) {
    return (rec.cartridge && rec.cartridge[name]) || {};
  }

  function rimType(rec) {
    if (rec.family === 'belted') return 'belted';
    if (rec.family === 'rimfire') return 'rimfire';
    var ratio = section(rec, 'caseHead').R1 / section(rec, 'powderChamber').P1;
    if (ratio >= 1.05) return 'rimmed';
    if (ratio < 0.98) return 'rebated';
    return 'rimless';
  }

  function missing(list, feature, values, consequence) {
    list.push({
      feature: feature,
      values: values,
      message: feature + ': ' + values.map(F.symbol).join(', ') + ' not published, ' + consequence
    });
  }

  function absent(obj, keys) {
    return keys.filter(function (k) { return !has(obj[k]); });
  }

  // Head face and rim edge, the extractor groove and the belt: from the axis to the body start.
  function headProfile(rec, type, notes) {
    var ch = section(rec, 'caseHead');
    var pc = section(rec, 'powderChamber');
    var R = ch.R, R1 = ch.R1, P1 = pc.P1;
    var pts = [[0, 0]];
    var info = { beltRampEnd: null, groove: false };

    if (type === 'rimfire') {
      var rho = Math.min(R / 2, (R1 - P1) / 2);
      var cz = R / 2;
      var cr = R1 / 2 - rho;
      pts.push([cr, 0]);
      if (cz - rho > 0) pts.push([cr, cz - rho]);
      var n = 16;
      for (var i = cz - rho > 0 ? 0 : 1; i <= n; i++) {
        var t = -Math.PI / 2 + Math.PI * i / n;
        pts.push([cr + rho * Math.cos(t), cz + rho * Math.sin(t)]);
      }
      if (cz + rho < R) pts.push([cr, R]);
      pts.push([P1 / 2, R]);
      info.bodyStart = R;
      return { points: pts, info: info };
    }

    var beta = degrees(ch.beta);
    if (has(ch.beta) && has(ch.f) && beta < 90) {
      var c = Math.min(ch.f * Math.tan(beta * RAD), R1 / 4);
      pts.push([R1 / 2 - c, 0], [R1 / 2, ch.f], [R1 / 2, R]);
    } else {
      var lack = absent(ch, ['beta', 'f']);
      if (lack.length) missing(notes, 'Head chamfer', lack, 'the rim edge is drawn with a square corner');
      pts.push([R1 / 2, 0], [R1 / 2, R]);
    }

    var grooveExpected = type !== 'rimmed';
    var grooveValues = absent(ch, ['E', 'E1', 'eMin']);
    var hasGroove = grooveValues.length === 0;
    if (grooveExpected && !hasGroove) missing(notes, 'Extractor groove', grooveValues, 'no groove is drawn');

    if (hasGroove) {
      info.groove = true;
      pts.push([ch.E1 / 2, R], [ch.E1 / 2, R + ch.eMin]);
      var beltValues = type === 'belted' ? absent(ch, ['R3', 'delta']) : [];
      if (type === 'belted' && beltValues.length) missing(notes, 'Belt', beltValues, 'the belt is drawn as an ordinary groove ramp');
      if (type === 'belted' && !beltValues.length) {
        var dz = (ch.R3 / 2 - ch.E1 / 2) / Math.tan(degrees(ch.delta) * RAD);
        info.beltRampEnd = R + ch.eMin + dz;
        pts.push([ch.R3 / 2, info.beltRampEnd], [ch.R3 / 2, ch.E], [P1 / 2, ch.E]);
      } else {
        pts.push([P1 / 2, ch.E]);
      }
      info.bodyStart = ch.E;
    } else {
      pts.push([P1 / 2, R]);
      info.bodyStart = R;
    }
    return { points: pts, info: info };
  }

  // Rounds the corner `p` (between the segments a-p and p-b) with an arc of radius r; the arc is
  // limited so that it uses at most half of either segment. Returns the points replacing p.
  function fillet(a, p, b, r) {
    var d1 = [p[0] - a[0], p[1] - a[1]];
    var d2 = [b[0] - p[0], b[1] - p[1]];
    var l1 = Math.hypot(d1[0], d1[1]);
    var l2 = Math.hypot(d2[0], d2[1]);
    d1 = [d1[0] / l1, d1[1] / l1];
    d2 = [d2[0] / l2, d2[1] / l2];
    var cross = d1[0] * d2[1] - d1[1] * d2[0];
    var theta = Math.acos(Math.max(-1, Math.min(1, d1[0] * d2[0] + d1[1] * d2[1])));
    if (theta < 1e-6) return [p];
    var t = Math.min(r * Math.tan(theta / 2), l1 / 2, l2 / 2);
    var rr = t / Math.tan(theta / 2);
    var t1 = [p[0] - d1[0] * t, p[1] - d1[1] * t];
    var side = cross > 0 ? 1 : -1; // which side of d1 the centre lies on
    var c = [t1[0] + side * (-d1[1]) * rr, t1[1] + side * d1[0] * rr];
    var a0 = Math.atan2(t1[1] - c[1], t1[0] - c[0]);
    var steps = Math.max(4, 2 * Math.ceil(theta / (6 * RAD) / 2));
    var out = [];
    for (var i = 0; i <= steps; i++) {
      var ang = a0 + side * theta * i / steps;
      out.push([c[0] + rr * Math.cos(ang), c[1] + rr * Math.sin(ang)]);
    }
    return out;
  }

  // Body, shoulder and neck from the body start to the mouth. Returns the points after the start point.
  function bodyProfile(rec, start, notes) {
    var pc = section(rec, 'powderChamber');
    var co = section(rec, 'collar');
    var jc = section(rec, 'junctionCone');
    var L = section(rec, 'lengths');
    var mouth = [co.H2 / 2, L.L3];
    var bottleneck = has(jc.alpha) && has(L.L1) && has(L.L2);
    if (bottleneck) {
      var lack = absent(pc, ['P2']).concat(absent(co, ['H1']));
      if (lack.length) {
        missing(notes, 'Shoulder', lack, 'the case is drawn straight');
        bottleneck = false;
      }
    }
    if (!bottleneck) return { points: [mouth], shoulder: null };

    var c1 = [pc.P2 / 2, L.L1];
    var c2 = [co.H1 / 2, L.L2];
    var pts = [];
    if (has(jc.r1Min)) pts = pts.concat(fillet(start, c1, c2, jc.r1Min));
    else {
      pts.push(c1);
      missing(notes, 'Body-side shoulder corner', ['r1Min'], 'the corner is drawn sharp');
    }
    if (has(jc.r2)) pts = pts.concat(fillet(c1, c2, mouth, jc.r2));
    else {
      pts.push(c2);
      missing(notes, 'Neck-side shoulder corner', ['r2'], 'the corner is drawn sharp');
    }
    pts.push(mouth);
    return { points: pts, shoulder: { from: c1, to: c2, alpha: degrees(jc.alpha) } };
  }

  var POCKETS = {
    sp: { diameter: 4.45, depth: 3.04 }, spm: { diameter: 4.45, depth: 3.04 }, sr: { diameter: 4.45, depth: 3.04 },
    lp: { diameter: 5.33, depth: 3.04 }, lpm: { diameter: 5.33, depth: 3.04 },
    lr: { diameter: 5.33, depth: 3.3 }, lrm: { diameter: 5.33, depth: 3.3 }
  };

  // Radius of the polyline `pts` (z nondecreasing, [r, z]) at height z.
  function radiusAt(pts, z) {
    if (z <= pts[0][1]) return pts[0][0];
    for (var i = 1; i < pts.length; i++) {
      var a = pts[i - 1], b = pts[i];
      if (z >= a[1] && z <= b[1] && b[1] > a[1]) return a[0] + (b[0] - a[0]) * (z - a[1]) / (b[1] - a[1]);
    }
    return pts[pts.length - 1][0];
  }

  // The part of the polyline (z nondecreasing) at or above z, starting exactly at z.
  function clipFrom(pts, z) {
    var out = [];
    for (var i = 0; i < pts.length; i++) {
      var p = pts[i];
      if (p[1] < z) continue;
      if (!out.length && i > 0 && p[1] > z) {
        var a = pts[i - 1];
        out.push([a[0] + (p[0] - a[0]) * (z - a[1]) / (p[1] - a[1]), z]);
      }
      out.push(p);
    }
    return out;
  }

  var SHAPES = {
    // depth factor, cylinder fraction (pistol / otherwise), meplat factor
    pointy: { depth: [1.0, 1.0], k: [0.40, 0.40] },
    rounded: { depth: [0.4, 0.8], k: [0.65, 0.55], m: 0.15 },
    flat: { depth: [0.4, 0.8], k: [0.70, 0.60], m: 0.55 },
    semi_wadcutter: { depth: [0.6, 0.6], k: [0.78, 0.78], m: 0.6 }
  };

  function bulletModel(rec, walls, notes) {
    var L = section(rec, 'lengths');
    var co = section(rec, 'collar');
    var G1 = section(rec, 'projectile').G1;
    var shape = rec.annotations && rec.annotations.defaultBulletShape;
    var lack = [];
    if (!has(G1)) lack.push('G1');
    if (!has(L.L6)) lack.push('L6');
    if (!has(L.L3)) lack.push('L3');
    if (!has(shape) || !SHAPES[shape]) lack.push('defaultBulletShape');
    if (lack.length) {
      missing(notes, 'Bullet', lack, 'the bullet is not drawn');
      return null;
    }
    var spec = SHAPES[shape];
    var pistol = rec.annotations.category === 'pistol';
    var which = pistol ? 0 : 1;
    var heeled = has(co.H2) && co.H2 - G1 <= 0.015;
    if (heeled && !walls) {
      missing(notes, 'Bullet heel', absent({ P1: section(rec, 'powderChamber').P1 }, ['P1']), 'the bullet is not drawn');
      return null;
    }
    var Rs = (heeled ? co.H2 : G1) / 2; // exposed shank radius
    var s = spec.depth[which] * G1;
    var zb = L.L3 - s;
    var Lb = L.L6 - zb;
    var ce = zb + spec.k[which] * Lb;
    var n = L.L6 - ce;
    var m = shape === 'pointy' ? Math.max(0.08 * G1, 1.27) : spec.m * G1;
    var path = [[Rs, heeled ? L.L3 : zb], [Rs, ce]];
    var rho = null;
    var steps = 24;
    var i;
    if (shape === 'pointy') {
      var a = Rs - m / 2;
      rho = (a * a + n * n) / (2 * a);
      var phiEnd = Math.atan2(n, m / 2 - Rs + rho);
      for (i = 1; i < steps; i++) {
        var phi = phiEnd * i / steps;
        path.push([Rs - rho + rho * Math.cos(phi), ce + rho * Math.sin(phi)]);
      }
    } else if (shape === 'rounded') {
      for (i = 1; i < steps; i++) {
        var th = Math.PI / 2 * i / steps;
        path.push([m / 2 + (Rs - m / 2) * Math.cos(th), ce + n * Math.sin(th)]);
      }
    }
    path.push([m / 2, L.L6]);
    var outline = [[0, zb]];
    if (heeled) outline.push([co.H2 / 2 - walls.tb, zb], [co.H2 / 2 - walls.tb, L.L3]);
    outline = outline.concat(path, [[0, L.L6]]);
    return {
      shape: shape, heeled: heeled, seatingDepth: s, base: zb, length: Lb, cylinderEnd: ce,
      meplat: m, rho: rho, outline: outline, exposed: clipFrom(path, L.L3).concat([[0, L.L6]])
    };
  }

  // Wall thicknesses, the solid head with its primer pocket, and the inner line.
  function sectionModel(rec, outer, head, shoulder, notes) {
    var pc = section(rec, 'powderChamber');
    var co = section(rec, 'collar');
    var ch = section(rec, 'caseHead');
    var L = section(rec, 'lengths');
    var G1 = section(rec, 'projectile').G1;
    var primer = rec.annotations && rec.annotations.primerType;
    var pocket = primer && POCKETS[primer] ? POCKETS[primer] : null;
    if (!has(primer)) missing(notes, 'Primer pocket', ['primerType'], 'the pocket is not drawn');
    var lack = absent({ G1: G1, H2: co.H2, P1: pc.P1 }, ['G1', 'H2', 'P1']);
    if (lack.length) {
      missing(notes, 'Section walls', lack, 'the section is not hatched');
      return { walls: null, head: { pocket: pocket, w: null }, inner: null };
    }
    var tn = (co.H2 - G1) / 2;
    var tb = Math.min(Math.max(1.3 * tn, 0.6), 0.35 * pc.P1 / 2);
    var heeled = co.H2 - G1 <= 0.015;
    if (heeled) tn = tb;
    var w = Math.max(2.5, 0.25 * pc.P1 / 2);
    if (pocket) w = Math.max(w, pocket.depth + 1.5);
    if (head.beltRampEnd !== null) w = Math.max(w, head.beltRampEnd + tb);
    else if (head.groove) w = Math.max(w, ch.E + tb);
    return { walls: { tn: tn, tb: tb }, head: { pocket: pocket, w: w }, inner: null, heeled: heeled };
  }

  function innerLine(outer, head, walls, shoulder, rec, bullet) {
    var co = section(rec, 'collar');
    var L = section(rec, 'lengths');
    var w = head.w;
    var from = outer.slice(head.bodyStartIndex);
    var line = [[radiusAt(from, w) - walls.tb, w]];
    if (shoulder) {
      line.push([shoulder.from[0] - walls.tb, shoulder.from[1]], [shoulder.to[0] - walls.tn, shoulder.to[1]]);
    } else if (bullet && walls.tn !== walls.tb) {
      var zb = bullet.base;
      var z1 = Math.max(w, zb - (walls.tb - walls.tn));
      if (z1 > w) line.push([radiusAt(from, z1) - walls.tb, z1]);
      line.push([radiusAt(from, zb) - walls.tn, zb]);
    }
    line.push([co.H2 / 2 - walls.tn, L.L3]);
    return line;
  }

  function build(rec) {
    var notes = [];
    var type = rimType(rec);
    var head = headProfile(rec, type, notes);
    var start = head.points[head.points.length - 1];
    var body = bodyProfile(rec, start, notes);
    var outer = head.points.concat(body.points);
    var sec = sectionModel(rec, outer, head.info, body.shoulder, notes);
    var bullet = bulletModel(rec, sec.walls, notes);
    var headModel = {
      beltRampEnd: head.info.beltRampEnd, groove: head.info.groove,
      pocket: sec.head.pocket, w: sec.head.w, bodyStartIndex: head.points.length - 1
    };
    var inner = sec.walls ? innerLine(outer, headModel, sec.walls, body.shoulder, rec, bullet) : null;
    return {
      rimType: type,
      outer: outer,
      bodyStart: head.info.bodyStart,
      shoulder: body.shoulder,
      head: headModel,
      walls: sec.walls,
      inner: inner,
      bullet: bullet,
      missing: notes
    };
  }

  var api = { rimType: rimType, build: build, degrees: degrees };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  else root.CipGeometry = api;
})(typeof window !== 'undefined' ? window : globalThis);
