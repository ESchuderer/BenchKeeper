const test = require('node:test');
const assert = require('node:assert/strict');
const { launch, watch, serve, FILE_URL, DATA } = require('./helpers.js');

let browser;
test.before(async () => { browser = await launch(); });
test.after(async () => { await browser.close(); });

// navigation by hash is asynchronous: wait for the heading instead of reading it at once
const h1 = (page, name) => page.getByRole('heading', { level: 1, name, exact: true }).waitFor();

async function open(url, opts) {
  const ctx = await browser.newContext(opts || { viewport: { width: 1100, height: 800 } });
  const page = await ctx.newPage();
  const problems = watch(page, new URL(url).protocol === 'http:' ? new URL(url).origin : null);
  await page.goto(url);
  return { page, ctx, problems };
}

test('opens from disk: heading, 25 cartridges, every name a link, no network, no errors', async () => {
  const { page, ctx, problems } = await open(FILE_URL);
  assert.equal(await page.getByRole('heading', { level: 1 }).innerText(), 'Cartridges');
  assert.equal(await page.locator('#count').innerText(), '25 cartridges');
  for (const r of DATA) assert.equal(await page.getByRole('link', { name: r.name, exact: true }).count(), 1, r.name);
  const row = await page.getByRole('row', { name: /^308 Win\./ }).innerText();
  assert.match(row, /rimless/);
  assert.match(row, /51\.18/);
  assert.deepEqual(problems, []);
  await ctx.close();
});

test('search finds names and alternative names as the user types', async () => {
  const { page, ctx } = await open(FILE_URL);
  await page.getByLabel('Search').pressSequentially('7,62 x 51');
  assert.equal(await page.locator('#count').innerText(), '1 cartridges');
  assert.equal(await page.getByRole('link', { name: '308 Win.', exact: true }).count(), 1);
  await page.getByLabel('Search').fill('mag');
  const names = await page.locator('tbody a').allInnerTexts();
  assert.deepEqual(names.sort(), ['300 Win. Mag.', '338 Lapua Mag.', '357 Magnum', '44 Rem. Mag.', '7 mm Rem. Mag.', '22 Win. Mag. R.F.'].sort());
  await page.getByLabel('Search').fill('zzz');
  assert.equal(await page.locator('#count').innerText(), '0 cartridges');
  await ctx.close();
});

test('family filter and search combine; options are All plus the five families', async () => {
  const { page, ctx } = await open(FILE_URL);
  const opts = await page.getByLabel('Family').locator('option').allInnerTexts();
  assert.deepEqual(opts, ['All', 'rimless', 'rimmed', 'belted', 'pistol', 'rimfire']);
  const counts = {};
  for (const f of opts.slice(1)) {
    await page.getByLabel('Family').selectOption({ label: f });
    counts[f] = await page.locator('#count').innerText();
  }
  assert.deepEqual(counts, { rimless: '12 cartridges', rimmed: '2 cartridges', belted: '2 cartridges', pistol: '6 cartridges', rimfire: '3 cartridges' });
  await page.getByLabel('Family').selectOption({ label: 'pistol' });
  await page.getByLabel('Search').fill('mag');
  assert.equal(await page.locator('#count').innerText(), '2 cartridges');
  await page.getByLabel('Family').selectOption({ label: 'All' });
  await page.getByLabel('Search').fill('');
  assert.equal(await page.locator('#count').innerText(), '25 cartridges');
  await ctx.close();
});

test('a name opens the detail view with its own address that survives a reload', async () => {
  const { page, ctx } = await open(FILE_URL);
  await page.getByRole('link', { name: '6,5 Creedmoor', exact: true }).click();
  await h1(page, '6,5 Creedmoor');
  assert.match(page.url(), /#\/cartridge\/6_5_creedmoor$/);
  await page.reload();
  await h1(page, '6,5 Creedmoor');
  await page.getByRole('link', { name: 'All cartridges' }).click();
  await h1(page, 'Cartridges');
  await page.goBack();
  await h1(page, '6,5 Creedmoor');
  await page.goto(FILE_URL + '#/cartridge/nonsense');
  await h1(page, 'Cartridge not found');
  await ctx.close();
});

test('list state is kept when coming back from a detail view', async () => {
  const { page, ctx } = await open(FILE_URL);
  await page.getByLabel('Search').fill('win');
  await page.getByRole('link', { name: '308 Win.', exact: true }).click();
  await h1(page, '308 Win.');
  await page.getByRole('link', { name: 'All cartridges' }).click();
  await h1(page, 'Cartridges');
  assert.equal(await page.getByLabel('Search').inputValue(), 'win');
  await ctx.close();
});

test('detail view: facts, drawing, tables with Symbol/Value/Unit, tolerance beside the value', async () => {
  const { page, ctx, problems } = await open(FILE_URL + '#/cartridge/308_win');
  const facts = await page.locator('.facts').innerText();
  for (const s of ['308 Winchester, 7,62 x 51', 'rimless', 'rifle', 'lr', 'US', '1984-06-14', '2008-09-23', 'Transducer', '56 gr H2O']) assert.ok(facts.includes(s), s);
  const link = page.locator('.facts a');
  assert.equal(await link.getAttribute('href'), 'http://kwk.us/cases.html');
  assert.equal(await link.innerText(), 'kwk');
  assert.equal(await page.getByRole('img', { name: '308 Win. drawing' }).count(), 1);
  const lengths = page.getByRole('table', { name: 'Lengths' }).first();
  assert.deepEqual(await lengths.locator('thead th').allInnerTexts(), ['SYMBOL', 'VALUE', 'UNIT'].map((s) => s)); // uppercase by CSS
  const l1 = lengths.getByRole('row', { name: /^L1/ });
  assert.equal((await l1.locator('td').nth(0).innerText()).trim(), '39.62 -0.2');
  assert.equal((await l1.locator('td').nth(1).innerText()).trim(), 'mm');
  const all = await page.locator('table.values tbody th').allInnerTexts();
  assert.ok(!all.some((s) => /Tol/.test(s)), 'no tolerance rows');
  for (const s of ['α', 'β', 'δ', 'e min', 'r1 min', 'r1 max', 'α1', 'delta L', 'L3 + G']) assert.ok(all.includes(s), s);
  const body = await page.locator('main').innerText();
  assert.match(body, /cartridge values/i);
  assert.match(body, /chamber values/i);
  assert.match(body, /1°45'0"/);
  assert.match(body, /71°25'59"/);
  assert.match(body, /4150\s+bar/);
  assert.deepEqual(problems, []);
  await ctx.close();
});

test('Print opens the print dialog', async () => {
  const { page, ctx } = await open(FILE_URL + '#/cartridge/308_win');
  await page.evaluate(() => { window.__printed = 0; window.print = () => { window.__printed++; }; });
  await page.getByRole('button', { name: 'Print' }).click();
  assert.equal(await page.evaluate(() => window.__printed), 1);
  await ctx.close();
});

test('missing values are named under the drawing (338 Lapua Mag. has no r1 min)', async () => {
  const { page, ctx } = await open(FILE_URL + '#/cartridge/338_lapua_mag');
  const notes = await page.locator('.drawing-notes').innerText();
  assert.match(notes, /r1 min not published/);
  await ctx.close();
});

test('works from a static file server too', async () => {
  const { server, url } = await serve();
  try {
    const { page, ctx, problems } = await open(url + '#/cartridge/223_rem');
    assert.equal(await page.getByRole('heading', { level: 1 }).innerText(), '223 Rem.');
    await page.getByRole('link', { name: 'All cartridges' }).click();
    await h1(page, 'Cartridges');
    assert.equal(await page.locator('#count').innerText(), '25 cartridges');
    assert.deepEqual(problems, []);
    await ctx.close();
  } finally { server.close(); }
});

test('light and dark follow the system setting', async () => {
  const lum = async (scheme) => {
    const { page, ctx } = await open(FILE_URL, { viewport: { width: 800, height: 600 }, colorScheme: scheme });
    const bg = await page.evaluate(() => getComputedStyle(document.body).backgroundColor);
    await ctx.close();
    return bg;
  };
  assert.notEqual(await lum('light'), await lum('dark'));
  const d = (await lum('dark')).match(/\d+/g).map(Number);
  assert.ok(d[0] < 60 && d[1] < 60 && d[2] < 60, 'dark background');
});

test('phone: no horizontal scrolling and drawing text stays legible (all 25)', async () => {
  const { page, ctx } = await open(FILE_URL, { viewport: { width: 360, height: 700 }, deviceScaleFactor: 2 });
  for (const r of DATA) {
    await page.goto(FILE_URL + '#/cartridge/' + r.key);
    await h1(page, r.name);
    const m = await page.evaluate(() => {
      const svg = document.querySelector('svg.drawing');
      const rect = svg.getBoundingClientRect();
      const label = svg.querySelector('.label');
      const scale = rect.width / svg.viewBox.baseVal.width;
      return { scroll: document.documentElement.scrollWidth, inner: window.innerWidth, w: rect.width, font: parseFloat(getComputedStyle(label).fontSize) * scale };
    });
    assert.ok(m.scroll <= m.inner, r.key + ' scrolls horizontally: ' + m.scroll);
    assert.ok(m.w <= m.inner, r.key);
    assert.ok(m.font >= 8, r.key + ' drawing text is ' + m.font.toFixed(1) + 'px');
  }
  await page.goto(FILE_URL);
  assert.ok(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth), 'list does not scroll');
  await ctx.close();
});

test('drawing in the real DOM: labels overlap neither each other nor the outline, and stay inside the view (all 25)', async () => {
  const { page, ctx } = await open(FILE_URL);
  for (const r of DATA) {
    await page.goto(FILE_URL + '#/cartridge/' + r.key);
    await h1(page, r.name);
    const res = await page.evaluate(() => {
      const svg = document.querySelector('svg.drawing');
      const vb = svg.viewBox.baseVal;
      const rects = [...svg.querySelectorAll('.labels text')].map((t) => { const b = t.getBBox(); return { text: t.textContent, x: b.x, y: b.y, w: b.width, h: b.height }; });
      const pts = [];
      svg.querySelectorAll('path.outline').forEach((p) => {
        const len = p.getTotalLength();
        for (let d = 0; d <= len; d += 0.05) { const q = p.getPointAtLength(d); pts.push([q.x, q.y]); }
      });
      const out = [];
      for (let i = 0; i < rects.length; i++) {
        const a = rects[i];
        if (a.x < vb.x || a.y < vb.y || a.x + a.w > vb.x + vb.width || a.y + a.h > vb.y + vb.height) out.push('outside view: ' + a.text);
        for (let j = i + 1; j < rects.length; j++) {
          const b = rects[j];
          if (a.x < b.x + b.w && b.x < a.x + a.w && a.y < b.y + b.h && b.y < a.y + a.h) out.push('overlap: ' + a.text + ' / ' + b.text);
        }
        if (pts.some((p) => p[0] > a.x && p[0] < a.x + a.w && p[1] > a.y && p[1] < a.y + a.h)) out.push('covers outline: ' + a.text);
      }
      return { out, n: rects.length };
    });
    assert.deepEqual(res.out, [], r.key);
    assert.ok(res.n >= 7, r.key);
  }
  await ctx.close();
});
