const path = require('node:path');
const http = require('node:http');
const fs = require('node:fs');
const { chromium } = require('playwright');
const DATA = require('../../js/data.js');

const ROOT = path.resolve(__dirname, '../..');
exports.FILE_URL = 'file://' + path.join(ROOT, 'index.html');
exports.DATA = DATA;

exports.launch = () => chromium.launch();

// every request that is not file:, data: or to the test's own server is a network request
exports.watch = (page, origin) => {
  const problems = [];
  page.on('console', (m) => { if (m.type() === 'error') problems.push('console: ' + m.text()); });
  page.on('pageerror', (e) => problems.push('pageerror: ' + e));
  page.on('request', (r) => { if (!/^(file|data|blob):/.test(r.url()) && !(origin && r.url().startsWith(origin))) problems.push('network: ' + r.url()); });
  return problems;
};

const TYPES = { '.html': 'text/html', '.js': 'text/javascript', '.css': 'text/css' };
exports.serve = () => new Promise((resolve) => {
  const server = http.createServer((req, res) => {
    const file = path.join(ROOT, req.url === '/' ? 'index.html' : decodeURIComponent(req.url.split('?')[0]));
    if (!file.startsWith(ROOT) || !fs.existsSync(file)) { res.writeHead(404); res.end(); return; }
    res.writeHead(200, { 'content-type': TYPES[path.extname(file)] || 'application/octet-stream' });
    fs.createReadStream(file).pipe(res);
  });
  server.listen(0, '127.0.0.1', () => resolve({ server, url: 'http://127.0.0.1:' + server.address().port + '/' }));
});
