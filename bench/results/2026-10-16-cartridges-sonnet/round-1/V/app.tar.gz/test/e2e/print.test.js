const test = require('node:test');
const assert = require('node:assert/strict');
const { launch, watch, FILE_URL, DATA } = require('./helpers.js');

let browser;
test.before(async () => { browser = await launch(); });
test.after(async () => { await browser.close(); });

test('a printed detail view is exactly one A4 portrait page (all 25), even when the system is dark', async () => {
  const ctx = await browser.newContext({ viewport: { width: 1100, height: 800 }, colorScheme: 'dark' });
  const page = await ctx.newPage();
  for (const r of DATA) {
    await page.goto(FILE_URL + '#/cartridge/' + r.key);
    await page.getByRole('heading', { level: 1, name: r.name, exact: true }).waitFor();
    await page.emulateMedia({ media: 'print', colorScheme: 'dark' });
    const pdf = await page.pdf({ preferCSSPageSize: true, printBackground: true });
    const text = pdf.toString('latin1');
    const pages = (text.match(/\/Type\s*\/Page[^s]/g) || []).length;
    assert.equal(pages, 1, r.key + ' prints on ' + pages + ' pages');
    const size = /\/MediaBox\s*\[\s*0\s+0\s+([\d.]+)\s+([\d.]+)/.exec(text);
    assert.ok(Math.abs(size[1] - 595.28) < 1 && Math.abs(size[2] - 841.89) < 1, r.key + ' page size ' + size.slice(1, 3));
  }
  await ctx.close();
});

test('print: no navigation, search or buttons; black on white; header, drawing, tables, footer', async () => {
  const ctx = await browser.newContext({ viewport: { width: 800, height: 1100 }, colorScheme: 'dark' });
  const page = await ctx.newPage();
  await page.goto(FILE_URL + '#/cartridge/308_win');
  await page.emulateMedia({ media: 'print', colorScheme: 'dark' });
  assert.equal(await page.locator('.toolbar').isVisible(), false);
  assert.equal(await page.getByRole('button', { name: 'Print' }).isVisible(), false);
  assert.equal(await page.getByRole('link', { name: 'All cartridges' }).isVisible(), false);
  const style = await page.evaluate(() => {
    const cs = getComputedStyle(document.body);
    const h = getComputedStyle(document.querySelector('h1'));
    return { bg: cs.backgroundColor, fg: cs.color, h1: h.color, footer: document.getElementById('footer').innerText };
  });
  assert.equal(style.bg, 'rgb(255, 255, 255)');
  assert.equal(style.fg, 'rgb(0, 0, 0)');
  assert.equal(style.h1, 'rgb(0, 0, 0)');
  assert.equal(style.footer.trim(), 'Source: C.I.P. TDCC, revised 2008-09-23');
  assert.equal(await page.getByRole('heading', { level: 1 }).innerText(), '308 Win.');
  // the drawing spans the full content width (A4 minus 2 x 10 mm = 190 mm = 718 px) and the tables follow it
  const g = await page.evaluate(() => {
    const s = document.querySelector('svg.drawing').getBoundingClientRect();
    const t = document.querySelector('.values-section').getBoundingClientRect();
    const main = document.querySelector('main').getBoundingClientRect();
    return { sw: s.width, mw: main.width, sBottom: s.bottom, tTop: t.top };
  });
  assert.ok(Math.abs(g.sw - g.mw) < 1, 'drawing at full width');
  assert.ok(g.tTop >= g.sBottom, 'tables below the drawing');
  await ctx.close();
});

test('print: every drawing label is at least 6 pt on the page (all 25)', async () => {
  const ctx = await browser.newContext({ viewport: { width: 800, height: 1100 } });
  const page = await ctx.newPage();
  await page.emulateMedia({ media: 'print' });
  for (const r of DATA) {
    await page.goto(FILE_URL + '#/cartridge/' + r.key);
    await page.getByRole('heading', { level: 1, name: r.name, exact: true }).waitFor();
    const pt = await page.evaluate(() => {
      const svg = document.querySelector('svg.drawing');
      const scale = svg.getBoundingClientRect().width / svg.viewBox.baseVal.width; // px per mm
      return parseFloat(getComputedStyle(svg.querySelector('.label')).fontSize) * scale * 0.75; // px -> pt
    });
    assert.ok(pt >= 6, r.key + ' label size ' + pt.toFixed(1) + ' pt');
  }
  await ctx.close();
});
