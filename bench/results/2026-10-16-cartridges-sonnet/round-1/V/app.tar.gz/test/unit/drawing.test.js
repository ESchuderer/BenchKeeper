const test = require('node:test');
const assert = require('node:assert/strict');
const D = require('../../js/drawing.js');
const { DATA, rec, near, nearPoint } = require('./helpers.js');

const texts = (lay) => lay.dims.map((d) => d.label.text);

test('308 Win. is labelled with symbol and value for every required and published dimension', () => {
  const t = texts(D.layout(rec('308_win')));
  for (const want of ['L3 51.18', 'L6 71.12', 'R1 12.01', 'R 1.37', 'P1 11.96', 'P2 11.53 -0.2', 'H1 8.72', 'H2 8.72', 'G1 7.85',
    'L1 39.62 -0.2', 'L2 43.48 -0.2', 'E1 10.39', 'α 40°']) assert.ok(t.includes(want), want + ' in ' + t.join(' | '));
  assert.equal(t.length, 13);
});

test('a straight pistol case only shows what is published (9 mm Luger)', () => {
  const t = texts(D.layout(rec('9_mm_luger')));
  assert.deepEqual(t.slice().sort(), ['E1 8.79', 'G1 9.03', 'H2 9.65', 'L3 19.15 -0.25', 'L6 29.69', 'P1 9.93', 'R 1.27', 'R1 9.96'].sort());
});

test('angles with minutes and seconds in the label (338 Lapua Mag.)', () => {
  assert.ok(texts(D.layout(rec('338_lapua_mag'))).includes('α 39°59\'49"'));
});

test('true to scale: 1 user unit = 1 mm, axis horizontal, head on the left (308 Win.)', () => {
  const lay = D.layout(rec('308_win'));
  const up = lay.outline.outside; // upper half: y = -r
  const at = (z) => up.filter((p) => Math.abs(p[0] - z) < 1e-6).map((p) => p[1]);
  assert.ok(at(0).includes(0), 'head face starts on the axis at x = 0');
  assert.ok(at(51.18).some((y) => Math.abs(y + 4.36) < 1e-6), 'mouth outer corner (L3, -H2/2)');
  assert.ok(at(71.12).some((y) => Math.abs(y) < 1e-6), 'tip on the axis at x = L6');
  assert.ok(at(71.12).some((y) => Math.abs(y + 0.635) < 1e-6), 'meplat radius at the tip');
  const maxX = Math.max.apply(null, up.map((p) => p[0]));
  near(maxX, 71.12);
  const minY = Math.min.apply(null, up.map((p) => p[1]));
  near(minY, -6.005); // rim radius R1/2
  assert.ok(lay.outline.section.length > 0);
  assert.ok(Math.max.apply(null, lay.outline.section.map((p) => p[1])) <= 6.005 + 1e-6);
});

test('the section is the lower half: positive y', () => {
  const lay = D.layout(rec('308_win'));
  assert.ok(lay.outline.section.every((p) => p[1] >= -1e-9));
  assert.ok(lay.outline.outside.every((p) => p[1] <= 1e-9));
});

test('the SVG has the accessible name, a viewBox, hatching and a centre line', () => {
  const svg = D.svg(rec('6_5_creedmoor'));
  assert.match(svg, /^<svg[^>]*role="img"/);
  assert.match(svg, /aria-label="6,5 Creedmoor drawing"/);
  assert.match(svg, /viewBox="[-\d.]+ [-\d.]+ [\d.]+ [\d.]+"/);
  assert.match(svg, /<pattern/);
  assert.match(svg, /class="centre"/);
  assert.doesNotMatch(svg, /https?:/);
});

test('names are escaped in the SVG', () => {
  const r = rec('308_win');
  r.name = '5 <x> & "y"';
  const svg = D.svg(r);
  assert.match(svg, /aria-label="5 &lt;x&gt; &amp; &quot;y&quot; drawing"/);
  assert.ok(!svg.includes('<x>'));
});

test('title block: name, table, revision date, units and scale', () => {
  const lay = D.layout(rec('223_rem'));
  const lines = lay.titleBlock.lines;
  assert.equal(lines[0], '223 Rem.');
  assert.ok(lines.some((l) => l === 'C.I.P. table I'));
  assert.ok(lines.some((l) => l === 'Revised 2017-05-17'));
  assert.ok(lines.includes('Dimensions in mm'));
  assert.ok(lines.some((l) => /^Scale \d+(\.\d)? : 1 \(A4 print\)$|^Scale 1 : \d+(\.\d)? \(A4 print\)$/.test(l)), lines.join('|'));
});

// ---- no overlap, checked independently by sampling ----
function sample(poly, step) {
  const pts = [];
  for (let i = 1; i < poly.length; i++) {
    const [a, b] = [poly[i - 1], poly[i]];
    const n = Math.max(1, Math.ceil(Math.hypot(b[0] - a[0], b[1] - a[1]) / step));
    for (let k = 0; k <= n; k++) pts.push([a[0] + (b[0] - a[0]) * k / n, a[1] + (b[1] - a[1]) * k / n]);
  }
  return pts;
}
const inside = (r, p) => p[0] > r.x && p[0] < r.x + r.w && p[1] > r.y && p[1] < r.y + r.h;
const overlap = (a, b) => a.x < b.x + b.w && b.x < a.x + a.w && a.y < b.y + b.h && b.y < a.y + a.h;

test('labels overlap neither each other nor the outline (all 25 cartridges)', () => {
  for (const r of DATA) {
    const lay = D.layout(r);
    const rects = lay.dims.map((d) => d.label.rect);
    for (let i = 0; i < rects.length; i++)
      for (let j = i + 1; j < rects.length; j++) assert.ok(!overlap(rects[i], rects[j]), r.key + ': labels ' + i + ' and ' + j + ' overlap');
    const outline = sample(lay.outline.outside, 0.05).concat(sample(lay.outline.section, 0.05));
    for (const rect of rects) for (const p of outline) assert.ok(!inside(rect, p), r.key + ': a label covers the outline at ' + p);
  }
});

test('every label lies inside the drawing bounds and the title block does not overlap the labels', () => {
  for (const r of DATA) {
    const lay = D.layout(r);
    const b = lay.bounds;
    const tb = lay.titleBlock.rect;
    for (const d of lay.dims) {
      const q = d.label.rect;
      assert.ok(q.x >= b.x && q.y >= b.y && q.x + q.w <= b.x + b.w && q.y + q.h <= b.y + b.h, r.key + ' ' + d.label.text + ' outside bounds');
      assert.ok(!overlap(q, tb), r.key + ' ' + d.label.text + ' overlaps the title block');
    }
    assert.ok(tb.x >= b.x && tb.x + tb.w <= b.x + b.w && tb.y + tb.h <= b.y + b.h, r.key + ' title block inside bounds');
  }
});

test('the drawing is not oversized: aspect and size suit a phone and A4', () => {
  for (const r of DATA) {
    const b = D.layout(r).bounds;
    assert.ok(b.w / b.h < 3.2 && b.w / b.h > 1.0, r.key + ' aspect ' + (b.w / b.h).toFixed(2));
    assert.ok(D.layout(r).fontSize >= 2.2, r.key);
  }
});

test('missing values are exposed for the page', () => {
  const lay = D.layout(rec('338_lapua_mag'));
  assert.ok(lay.missing.some((m) => m.values.includes('r1Min')));
});
