const test = require('node:test');
const assert = require('node:assert/strict');
const F = require('../../js/format.js');
const DATA = require('../../js/data.js');
const rec = (key) => DATA.find((r) => r.key === key);

test('angle: a number of degrees is shown as degrees', () => {
  assert.equal(F.angle(40), '40°');
  assert.equal(F.angle(35.0), '35°');
  assert.equal(F.angle(22.5), '22.5°');
});

test('angle: an object is shown as degrees, minutes and seconds', () => {
  assert.equal(F.angle({ degrees: 39, minutes: 59, seconds: 49 }), '39°59\'49"');
  assert.equal(F.angle({ degrees: 3, minutes: 10, seconds: 36 }), '3°10\'36"');
  assert.equal(F.angle({ degrees: 0, minutes: 17, seconds: 11 }), '0°17\'11"');
});

test('number: shown as published, decimal point, no thousands separator, no padding', () => {
  assert.equal(F.number(51.18), '51.18');
  assert.equal(F.number(4150), '4150');
  assert.equal(F.number(4150.0), '4150');
  assert.equal(F.number(9.6), '9.6');
  assert.equal(F.number(-0.2), '-0.2');
});

test('symbol: field name, except the published exceptions', () => {
  assert.equal(F.symbol('L3'), 'L3');
  assert.equal(F.symbol('Pmax'), 'Pmax');
  assert.equal(F.symbol('eMin'), 'e min');
  assert.equal(F.symbol('r1Min'), 'r1 min');
  assert.equal(F.symbol('r1Max'), 'r1 max');
  assert.equal(F.symbol('alpha'), 'α');
  assert.equal(F.symbol('alpha1'), 'α1');
  assert.equal(F.symbol('beta'), 'β');
  assert.equal(F.symbol('delta'), 'δ');
  assert.equal(F.symbol('deltaL'), 'delta L');
  assert.equal(F.symbol('L3PlusG'), 'L3 + G');
});

test('unit: mm by default, bar for pressures, J, g, mm², angle degrees, none for N', () => {
  assert.equal(F.unit('L3'), 'mm');
  assert.equal(F.unit('Pmax'), 'bar');
  assert.equal(F.unit('PK'), 'bar');
  assert.equal(F.unit('PE'), 'bar');
  assert.equal(F.unit('EE'), 'J');
  assert.equal(F.unit('M'), 'g');
  assert.equal(F.unit('Q'), 'mm²');
  assert.equal(F.unit('N'), '');
  for (const k of ['alpha', 'alpha1', 'beta', 'delta', 'i']) assert.equal(F.unit(k), '', k + ' is an angle; the unit is part of the value');
});

test('rows: a tolerance is shown next to its value and is never a row of its own', () => {
  const rows = F.rows(rec('308_win').cartridge.lengths);
  assert.deepEqual(rows.map((r) => r.symbol), ['L1', 'L2', 'L3', 'L6']);
  assert.deepEqual(rows.find((r) => r.symbol === 'L1'), { symbol: 'L1', value: '39.62 -0.2', unit: 'mm' });
  assert.deepEqual(rows.find((r) => r.symbol === 'L3'), { symbol: 'L3', value: '51.18', unit: 'mm' });
});

test('rows: angles in objects and numbers, pressures, count', () => {
  const c = rec('223_rem');
  const cone = F.rows(c.cartridge.junctionCone);
  assert.deepEqual(cone.find((r) => r.symbol === 'α'), { symbol: 'α', value: '46°', unit: '' });
  const rif = F.rows(c.chamber.rifling);
  assert.equal(rif.find((r) => r.symbol === 'i').value, '3°10\'36"');
  assert.equal(F.rows(c.chamber.grooves).find((r) => r.symbol === 'N').value, '6');
  assert.equal(F.rows(c.cartridge.pressures).find((r) => r.symbol === 'Pmax').value, '4300');
});

test('sections: grouped with titles, empty groups left out', () => {
  const secs = F.sections(rec('9_mm_luger').cartridge, 'cartridge');
  const titles = secs.map((s) => s.title);
  assert.ok(titles.includes('Case head'));
  assert.ok(titles.includes('Pressures'));
  assert.ok(!titles.includes('Junction cone'), 'empty junctionCone is not a section');
  for (const s of secs) for (const r of s.rows) assert.ok(r.symbol && r.value !== undefined);
});

test('sections: a field named like a tolerance never becomes a row (every record)', () => {
  for (const r of DATA) for (const part of ['cartridge', 'chamber'])
    for (const s of F.sections(r[part], part)) for (const row of s.rows) assert.ok(!/Tol$/.test(row.symbol), r.key + ' ' + row.symbol);
});
