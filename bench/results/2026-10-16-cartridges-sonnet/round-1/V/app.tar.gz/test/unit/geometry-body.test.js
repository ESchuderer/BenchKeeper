const test = require('node:test');
const assert = require('node:assert/strict');
const G = require('../../js/geometry.js');
const { rec, near, nearPoint, hasPoint } = require('./helpers.js');

const dist = (p, q) => Math.hypot(p[0] - q[0], p[1] - q[1]);
const closest = (pts, q) => Math.min.apply(null, pts.map((p) => dist(p, q)));

test('bottleneck: body, shoulder and neck run through the published points; corners rounded with r1 min and r2 (308 Win.)', () => {
  const m = G.build(rec('308_win'));
  const o = m.outer;
  // tangent points of the two fillets, worked out by hand from the corners
  // (5.765, 39.62) r 0.76 and (4.36, 43.48) r 3.18
  hasPoint(o, [5.7658, 39.4883], 0.003);
  hasPoint(o, [5.72, 39.7437], 0.003);
  hasPoint(o, [4.5518, 42.9531], 0.003);
  hasPoint(o, [4.36, 44.0407], 0.003);
  nearPoint(o[o.length - 1], [4.36, 51.18]); // the neck runs to the mouth
  // the corners themselves are cut off by the rounding, by r*(1/cos(theta/2) - 1)
  near(closest(o, [5.765, 39.62]), 0.0113, 0.004, 'body-side corner');
  near(closest(o, [4.36, 43.48]), 0.0491, 0.004, 'neck-side corner');
  assert.deepEqual(m.missing, []);
});

test('bottleneck: the shoulder is exposed for the angle label with its published points', () => {
  const m = G.build(rec('308_win'));
  nearPoint(m.shoulder.from, [5.765, 39.62]);
  nearPoint(m.shoulder.to, [4.36, 43.48]);
  near(m.shoulder.alpha, 40);
  const t = G.build(rec('338_lapua_mag')); // alpha given as degrees, minutes, seconds
  near(t.shoulder.alpha, 39 + 59 / 60 + 49 / 3600, 1e-6);
});

test('bottleneck: a corner radius that is not published is left sharp and named (338 Lapua Mag. has no r1 min)', () => {
  const m = G.build(rec('338_lapua_mag'));
  hasPoint(m.outer, [13.82 / 2, 54.9]); // the sharp body-side corner (P2/2, L1)
  assert.ok(m.missing.some((x) => x.values.includes('r1Min')));
  assert.ok(!m.missing.some((x) => x.values.includes('r2')));
});

test('missing values are named with their published symbols in the message', () => {
  const m = G.build(rec('338_lapua_mag'));
  assert.ok(m.missing.some((x) => /r1 min not published/.test(x.message)), JSON.stringify(m.missing));
});

test('bottleneck: 17 HMR lacks both radii', () => {
  const m = G.build(rec('17_hmr'));
  hasPoint(m.outer, [6.15 / 2, 22.2]);
  hasPoint(m.outer, [4.9 / 2, 23.54]);
  const named = m.missing.reduce((a, x) => a.concat(x.values), []);
  assert.ok(named.includes('r1Min') && named.includes('r2'));
});

test('straight case: the body runs from P1/2 at the body start to (H2/2, L3) (9 mm Luger)', () => {
  const o = G.build(rec('9_mm_luger')).outer;
  nearPoint(o[o.length - 2], [9.93 / 2, 2.98]);
  nearPoint(o[o.length - 1], [9.65 / 2, 19.15]);
});

test('straight case without groove: rimfire 22 Win. Mag. R.F.', () => {
  const m = G.build(rec('22_win_mag_r_f'));
  const o = m.outer;
  nearPoint(o[o.length - 2], [6.15 / 2, 1.27]);
  nearPoint(o[o.length - 1], [6.15 / 2, 26.8]);
  assert.equal(m.shoulder, null);
  assert.deepEqual(m.missing, []);
});

test('a bottleneck case missing a value the shoulder needs is drawn straight and the value is named', () => {
  const r = rec('308_win');
  delete r.cartridge.powderChamber.P2;
  const m = G.build(r);
  assert.equal(m.shoulder, null);
  nearPoint(m.outer[m.outer.length - 1], [8.72 / 2, 51.18]);
  assert.ok(m.missing.some((x) => x.values.includes('P2')));
});
