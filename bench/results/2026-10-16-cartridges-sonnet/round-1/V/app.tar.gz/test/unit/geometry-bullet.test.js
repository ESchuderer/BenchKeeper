const test = require('node:test');
const assert = require('node:assert/strict');
const G = require('../../js/geometry.js');
const { DATA, rec, near, nearPoint, hasPoint } = require('./helpers.js');

test('pointy: seated 1.0 G1 deep, cylinder to 40 % of the bullet, tangent ogive to a 1.27 mm meplat (308 Win.)', () => {
  const b = G.build(rec('308_win')).bullet;
  assert.equal(b.shape, 'pointy');
  near(b.seatingDepth, 7.85);
  near(b.base, 43.33);
  near(b.cylinderEnd, 54.446);
  near(b.meplat, 1.27);
  near(b.rho, 43.8976, 0.002); // ((G1/2 - m/2)^2 + n^2) / (2 (G1/2 - m/2)), n = 16.674
  nearPoint(b.outline[0], [0, 43.33]);
  nearPoint(b.outline[1], [3.925, 43.33]);
  nearPoint(b.outline[2], [3.925, 54.446]);
  const tip = b.outline.slice(-2);
  nearPoint(tip[0], [0.635, 71.12]);
  nearPoint(tip[1], [0, 71.12]);
  // every ogive point lies on the circle of radius rho around (G1/2 - rho, z where the nose starts)
  const nose = b.outline.slice(2, -1);
  assert.ok(nose.length > 8);
  for (const p of nose) near(Math.hypot(p[0] - (3.925 - 43.8976), p[1] - 54.446), 43.8976, 0.003, 'on the ogive arc');
});

test('pointy: the exposed part starts at the mouth with the shank radius', () => {
  const b = G.build(rec('308_win')).bullet;
  nearPoint(b.exposed[0], [3.925, 51.18]);
  nearPoint(b.exposed[b.exposed.length - 1], [0, 71.12]);
  assert.ok(b.exposed.every((p) => p[1] >= 51.18 - 1e-9));
});

test('rounded pistol: 0.4 G1 deep, cylinder to 65 %, quarter ellipse to a 0.15 G1 meplat (9 mm Luger)', () => {
  const b = G.build(rec('9_mm_luger')).bullet;
  assert.equal(b.shape, 'rounded');
  near(b.base, 15.538);
  near(b.cylinderEnd, 24.7368);
  near(b.meplat, 1.3545);
  // ellipse centred at (m/2, nose start) with semi-axes G1/2 - m/2 = 3.8378 and n = 4.9532
  const nose = b.outline.slice(2, -1);
  assert.ok(nose.length > 8);
  for (const p of nose) near(Math.pow((p[0] - 0.67725) / 3.83775, 2) + Math.pow((p[1] - 24.7368) / 4.9532, 2), 1, 0.002, 'on the ellipse');
  nearPoint(b.outline[b.outline.length - 2], [0.67725, 29.69]);
});

test('rounded rifle/rimfire: 0.8 G1 deep, cylinder to 55 % (22 Win. Mag. R.F.)', () => {
  const b = G.build(rec('22_win_mag_r_f')).bullet;
  near(b.seatingDepth, 4.56);
  near(b.base, 22.24);
  near(b.cylinderEnd, 22.24 + 0.55 * (34.29 - 22.24), 0.002);
});

test('flat pistol: 0.4 G1 deep, cylinder to 70 %, straight cone to a 0.55 G1 meplat (40 S.& W.)', () => {
  const b = G.build(rec('40_s_w')).bullet;
  assert.equal(b.shape, 'flat');
  near(b.base, 21.59 - 0.4 * 10.17);
  near(b.cylinderEnd, b.base + 0.7 * (28.83 - b.base), 0.002);
  near(b.meplat, 5.5935);
  nearPoint(b.outline[b.outline.length - 2], [2.79675, 28.83]);
  // straight cone: the nose points are collinear
  const [a, c] = [b.outline[2], b.outline[b.outline.length - 2]];
  for (const p of b.outline.slice(3, -2)) near((c[0] - a[0]) * (p[1] - a[1]) - (c[1] - a[1]) * (p[0] - a[0]), 0, 1e-6);
});

test('semi_wadcutter: 0.6 G1 deep, cylinder to 78 %, cone to a 0.6 G1 meplat (357 Magnum)', () => {
  const b = G.build(rec('357_magnum')).bullet;
  assert.equal(b.shape, 'semi_wadcutter');
  near(b.seatingDepth, 0.6 * 9.12);
  near(b.base, 32.77 - 0.6 * 9.12);
  near(b.cylinderEnd, b.base + 0.78 * (40.39 - b.base), 0.002);
  near(b.meplat, 0.6 * 9.12);
});

test('heeled case: exposed bullet has the case outside diameter, the seated heel the inside diameter (22 Long Rifle)', () => {
  const m = G.build(rec('22_long_rifle'));
  const b = m.bullet;
  assert.equal(b.heeled, true);
  near(b.base, 10.994);
  near(b.cylinderEnd, 10.994 + 0.55 * (25.4 - 10.994), 0.002);
  nearPoint(b.outline[1], [2.86 - 0.6, 10.994]); // heel: H2/2 - tb
  nearPoint(b.outline[2], [2.26, 15.57]);
  nearPoint(b.outline[3], [2.86, 15.57]); // steps out to the case outside diameter at the mouth
  nearPoint(b.outline[4], [2.86, 18.9173], 0.002);
  nearPoint(b.exposed[0], [2.86, 15.57]);
});

test('only 22 Long Rifle is heeled (H2 - G1 <= 0.015)', () => {
  assert.deepEqual(DATA.filter((r) => G.build(r).bullet.heeled).map((r) => r.key), ['22_long_rifle']);
});

test('a missing bullet value leaves the bullet out and is named', () => {
  const r = rec('308_win');
  delete r.cartridge.lengths.L6;
  const m = G.build(r);
  assert.equal(m.bullet, null);
  assert.ok(m.missing.some((x) => x.values.includes('L6')));
  const r2 = rec('308_win');
  delete r2.annotations.defaultBulletShape;
  const m2 = G.build(r2);
  assert.equal(m2.bullet, null);
  assert.ok(m2.missing.some((x) => x.values.includes('defaultBulletShape')));
});
