const test = require('node:test');
const assert = require('node:assert/strict');
const G = require('../../js/geometry.js');
const { rec, near, nearPoint, hasPoint } = require('./helpers.js');

test('rim type: family belted and rimfire decide first', () => {
  assert.equal(G.rimType(rec('300_win_mag')), 'belted');
  assert.equal(G.rimType(rec('22_long_rifle')), 'rimfire');
});

test('rim type: R1/P1 >= 1.05 rimmed, < 0.98 rebated, otherwise rimless', () => {
  assert.equal(G.rimType(rec('9_3_x_74_r')), 'rimmed'); // 13.35 / 11.9
  assert.equal(G.rimType(rec('308_win')), 'rimless'); // 12.01 / 11.96
  const r = rec('308_win');
  r.cartridge.powderChamber.P1 = 10;
  r.cartridge.caseHead.R1 = 10.5;
  assert.equal(G.rimType(r), 'rimmed', '1.05 exactly is rimmed');
  r.cartridge.caseHead.R1 = 10.49;
  assert.equal(G.rimType(r), 'rimless', '1.049');
  r.cartridge.caseHead.R1 = 9.8;
  assert.equal(G.rimType(r), 'rimless', '0.98 exactly is rimless');
  r.cartridge.caseHead.R1 = 9.79;
  assert.equal(G.rimType(r), 'rebated', '0.979');
});

test('head: the profile starts on the axis at the head face and chamfers the rim edge (308 Win.)', () => {
  const m = G.build(rec('308_win'));
  nearPoint(m.outer[0], [0, 0]);
  nearPoint(m.outer[1], [5.7389, 0]); // R1/2 - f*tan(35°) = 6.005 - 0.2661
  nearPoint(m.outer[2], [6.005, 0.38]);
  nearPoint(m.outer[3], [6.005, 1.37]); // up the rim edge to (R1/2, R)
});

test('head: the chamfer is limited to R1/4', () => {
  const r = rec('308_win');
  r.cartridge.caseHead.f = 5; // f*tan(35°) = 3.5 > R1/4 = 3.0025
  const m = G.build(r);
  nearPoint(m.outer[1], [6.005 - 3.0025, 0]);
});

test('head: without beta and f, or with beta >= 90°, the corner is square and the missing values are named', () => {
  const r = rec('308_win');
  delete r.cartridge.caseHead.beta;
  const m = G.build(r);
  nearPoint(m.outer[1], [6.005, 0]);
  nearPoint(m.outer[2], [6.005, 1.37]);
  assert.ok(m.missing.some((x) => x.values.includes('beta')), 'beta reported missing');
  const r2 = rec('308_win');
  r2.cartridge.caseHead.beta = 90;
  nearPoint(G.build(r2).outer[1], [6.005, 0]);
});

test('head: a rimfire rim edge is a half-round whose outermost point lies at R1/2 (22 Long Rifle)', () => {
  const m = G.build(rec('22_long_rifle'));
  // R1/2 = 3.53, rho = min(R/2 = 0.545, (R1 - P1)/2 = 0.66) = 0.545
  nearPoint(m.outer[0], [0, 0]);
  nearPoint(m.outer[1], [3.53 - 0.545, 0]);
  hasPoint(m.outer, [3.53, 0.545]);
  const maxR = Math.max.apply(null, m.outer.slice(0, 40).map((p) => p[0]));
  near(maxR, 3.53);
  hasPoint(m.outer, [3.53 - 0.545, 1.09]); // the half-round ends at z = R
  hasPoint(m.outer, [5.74 / 2, 1.09]); // then steps in to P1/2
  for (const p of m.outer.slice(2, 20)) { // on the circle of radius rho around (R1/2 - rho, rho)
    if (p[1] > 0 && p[1] < 1.09 && p[0] > 3.0) near(Math.hypot(p[0] - 2.985, p[1] - 0.545), 0.545, 0.003, 'on the half-round');
  }
});

test('groove: in to E1/2 at z = R, along the floor to R + e min, ramp out to (P1/2, E) (308 Win.)', () => {
  const m = G.build(rec('308_win'));
  nearPoint(m.outer[4], [5.195, 1.37]);
  nearPoint(m.outer[5], [5.195, 2.77]);
  nearPoint(m.outer[6], [5.98, 3.85]);
});

test('no groove: step in from (R1/2, R) to (P1/2, R) (9,3 x 74 R)', () => {
  const m = G.build(rec('9_3_x_74_r'));
  // chamfer: R1/2 = 6.675, f = 0.3, beta 45
  nearPoint(m.outer[3], [6.675, 1.4]);
  nearPoint(m.outer[4], [5.95, 1.4]);
  assert.equal(m.missing.filter((x) => /groove/i.test(x.feature)).length, 0, 'a rimmed case has no groove to miss');
});

test('groove: values missing for a case that should have one are named', () => {
  const r = rec('308_win');
  delete r.cartridge.caseHead.eMin;
  const m = G.build(r);
  assert.ok(m.missing.some((x) => /groove/i.test(x.feature) && x.values.includes('eMin')));
  nearPoint(m.outer[4], [5.98, 1.37], 0.002, 'groove left out: step in to P1/2 at z = R');
});

test('belted: ramp out at δ to the belt R3/2, follow the belt to z = E, step in to P1/2 (300 Win. Mag.)', () => {
  const m = G.build(rec('300_win_mag'));
  nearPoint(m.outer[1], [6.4679, 0]);
  nearPoint(m.outer[3], [6.755, 1.27]);
  nearPoint(m.outer[4], [6.035, 1.27]);
  nearPoint(m.outer[5], [6.035, 2.21]);
  nearPoint(m.outer[6], [6.755, 3.2383]); // dz = (6.755 - 6.035) / tan(35°)
  nearPoint(m.outer[7], [6.755, 5.59]);
  nearPoint(m.outer[8], [6.515, 5.59]);
  near(m.head.beltRampEnd, 3.2383);
});

test('belted: a missing belt value is named and the case is drawn as an ordinary groove', () => {
  const r = rec('300_win_mag');
  delete r.cartridge.caseHead.R3;
  const m = G.build(r);
  assert.ok(m.missing.some((x) => x.values.includes('R3')));
  nearPoint(m.outer[6], [6.515, 5.59]);
});
