const test = require('node:test');
const assert = require('node:assert/strict');
const G = require('../../js/geometry.js');
const { DATA, rec, near, nearPoint, hasPoint } = require('./helpers.js');

test('walls: neck wall (H2 - G1)/2, body wall limited to [0.6, 0.35 P1/2] (308 Win.)', () => {
  const m = G.build(rec('308_win'));
  near(m.walls.tn, 0.435);
  near(m.walls.tb, 0.6);
});

test('solid head: w is the largest of 2.5, P1/8, pocket depth + 1.5, E + tb (308 Win. lr pocket)', () => {
  const m = G.build(rec('308_win'));
  assert.deepEqual(m.head.pocket, { diameter: 5.33, depth: 3.3 });
  near(m.head.w, 4.8); // 3.3 + 1.5 beats E + tb = 4.45
});

test('solid head: small-primer pocket (223 Rem. sr)', () => {
  const m = G.build(rec('223_rem'));
  assert.deepEqual(m.head.pocket, { diameter: 4.45, depth: 3.04 });
  near(m.head.w, 4.54);
});

test('solid head: E + tb can win (45 Auto, lp pocket)', () => {
  const m = G.build(rec('45_auto'));
  assert.deepEqual(m.head.pocket, { diameter: 5.33, depth: 3.04 });
  near(m.head.w, 4.11 + 0.6);
});

test('solid head: belted cases use the belt ramp end + tb (300 Win. Mag.)', () => {
  const m = G.build(rec('300_win_mag'));
  assert.deepEqual(m.head.pocket, { diameter: 5.33, depth: 3.3 });
  near(m.head.w, 4.8); // beats 3.2383 + 0.6
});

test('belted: the cavity starts at P1/2 - tb even though the solid head ends inside the belt (300 Win. Mag.)', () => {
  const m = G.build(rec('300_win_mag'));
  nearPoint(m.inner[0], [13.03 / 2 - 0.6, 4.8]);
});

test('solid head: rimfire has no pocket and w is at least 2.5 (22 Long Rifle)', () => {
  const m = G.build(rec('22_long_rifle'));
  assert.equal(m.head.pocket, null);
  near(m.head.w, 2.5);
});

test('primer pocket sizes by primer type', () => {
  const sizes = {};
  for (const r of DATA) {
    const p = G.build(r).head.pocket;
    sizes[r.annotations.primerType] = p ? p.diameter + '/' + p.depth : null;
  }
  assert.deepEqual(sizes, {
    sr: '4.45/3.04', sp: '4.45/3.04', spm: '4.45/3.04',
    lp: '5.33/3.04', lpm: '5.33/3.04', lr: '5.33/3.3', lrm: '5.33/3.3', rimfire: null
  });
});

test('inner line follows body, shoulder and neck at tb and tn (308 Win.)', () => {
  const m = G.build(rec('308_win'));
  nearPoint(m.inner[0], [5.3743, 4.8]); // outer body radius at z = w, minus tb
  hasPoint(m.inner, [5.765 - 0.6, 39.62]);
  hasPoint(m.inner, [4.36 - 0.435, 43.48]);
  nearPoint(m.inner[m.inner.length - 1], [4.36 - 0.435, 51.18]); // = G1/2: the bullet fits
});

test('straight case: the wall thins from tb to tn where the bullet is seated (9 mm Luger)', () => {
  const m = G.build(rec('9_mm_luger'));
  near(m.walls.tn, 0.31);
  near(m.walls.tb, 0.6);
  nearPoint(m.inner[0], [4.3515, 4.54]);
  nearPoint(m.inner[m.inner.length - 1], [4.515, 19.15]); // G1/2
  // the wall thins over tb - tn = 0.29 mm and is tn from the bullet base z = 15.538 to the mouth
  hasPoint(m.inner, [4.2588, 15.248], 0.003);
  hasPoint(m.inner, [4.5463, 15.538], 0.003);
});

test('heeled case: the neck wall equals the body wall (22 Long Rifle)', () => {
  const m = G.build(rec('22_long_rifle'));
  near(m.walls.tb, 0.6);
  near(m.walls.tn, 0.6);
  nearPoint(m.inner[m.inner.length - 1], [2.26, 15.57]);
});

test('without G1 or H2 there are no walls and the missing value is named', () => {
  const r = rec('308_win');
  delete r.cartridge.projectile.G1;
  const m = G.build(r);
  assert.equal(m.walls, null);
  assert.equal(m.inner, null);
  assert.ok(m.missing.some((x) => x.values.includes('G1')));
});

test('every record builds without throwing and never reports a value that is published', () => {
  for (const r of DATA) {
    const m = G.build(r);
    for (const n of m.missing) for (const v of n.values) {
      const found = Object.keys(r.cartridge).some((s) => r.cartridge[s][v] !== undefined) || (r.annotations && r.annotations[v] !== undefined);
      assert.ok(!found, r.key + ' reports ' + v + ' missing but it is published');
    }
    for (const p of m.outer) assert.ok(p.every(Number.isFinite), r.key);
  }
});
