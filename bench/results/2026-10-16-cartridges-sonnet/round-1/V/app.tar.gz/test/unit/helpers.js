const assert = require('node:assert/strict');
const DATA = require('../../js/data.js');
exports.DATA = DATA;
exports.rec = (key) => JSON.parse(JSON.stringify(DATA.find((r) => r.key === key)));
// deep-ish clone so a test can delete a value
exports.near = (actual, expected, tol, msg) => {
  assert.ok(Math.abs(actual - expected) <= (tol === undefined ? 0.002 : tol), `${msg || ''} expected ${expected}, got ${actual}`);
};
exports.nearPoint = (p, e, tol, msg) => {
  exports.near(p[0], e[0], tol, (msg || '') + ' r');
  exports.near(p[1], e[1], tol, (msg || '') + ' z');
};
exports.hasPoint = (points, e, tol) => {
  const t = tol === undefined ? 0.002 : tol;
  assert.ok(points.some((p) => Math.abs(p[0] - e[0]) <= t && Math.abs(p[1] - e[1]) <= t), `no point near (${e}) in ${JSON.stringify(points.slice(0, 12))}…`);
};
