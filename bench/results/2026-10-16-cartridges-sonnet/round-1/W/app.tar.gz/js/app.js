/* Page behaviour: the list view (search, family filter) and the routing between list and detail views.
   Navigation uses the address fragment (#/cartridge/<key>) so that it works from file:// and any server. */
(function () {
  'use strict';

  const CIP = window.CIP;
  const records = window.CIP_DATA;

  function h(tag, attrs, ...children) {
    const e = document.createElement(tag);
    for (const [k, v] of Object.entries(attrs || {})) {
      if (v === undefined || v === null || v === false) continue;
      if (k === 'text') e.textContent = v;
      else e.setAttribute(k, v === true ? '' : v);
    }
    for (const c of children) if (c !== null && c !== undefined) e.append(c);
    return e;
  }

  const els = {
    list: document.getElementById('list-view'),
    detail: document.getElementById('detail-view'),
    search: document.getElementById('search'),
    family: document.getElementById('family'),
    count: document.getElementById('count'),
    noMatch: document.getElementById('no-match'),
    body: document.getElementById('list-body'),
    listHeading: document.getElementById('list-heading'),
  };

  function l3Text(record) {
    const L3 = ((record.cartridge || {}).lengths || {}).L3;
    return typeof L3 === 'number' ? CIP.format.formatNumber(L3) : '—';
  }

  // ---- list view -------------------------------------------------------------

  function setupList() {
    for (const f of CIP.catalogue.FAMILIES) els.family.append(h('option', { value: f, text: f }));
    const rows = new Map();
    for (const r of records) {
      const row = h('tr', {},
        h('td', {}, h('a', { href: '#/cartridge/' + encodeURIComponent(r.key), text: r.name })),
        h('td', { text: r.family }),
        h('td', { class: 'num', text: l3Text(r) }));
      rows.set(r.key, row);
    }
    function update() {
      const shown = CIP.catalogue.filter(records, { query: els.search.value, family: els.family.value });
      els.body.replaceChildren(...shown.map((r) => rows.get(r.key)));
      els.count.textContent = CIP.catalogue.countText(shown.length);
      els.noMatch.hidden = shown.length > 0;
    }
    els.search.addEventListener('input', update);
    els.family.addEventListener('change', update);
    update();
  }

  // ---- detail view -------------------------------------------------------

  function factRow(f) {
    const dd = h('dd', {});
    dd.append(f.text);
    if (f.note) dd.append(' ', h('span', { class: 'note', text: '(' + f.note + ')' }));
    if (f.link) dd.append(' ', h('span', { class: 'source' }, 'source: ', h('a', { href: f.link.href, rel: 'noopener noreferrer', target: '_blank', text: f.link.text })));
    return [h('dt', { text: f.label }), dd];
  }

  function valueTable(groupKey, sec) {
    const id = 'sec-' + groupKey + '-' + sec.key;
    const body = h('tbody', {});
    for (const row of sec.rows) {
      body.append(h('tr', {},
        h('th', { scope: 'row', text: row.symbol }),
        h('td', { class: 'num', text: row.value }),
        h('td', { class: 'unit', text: row.unit })));
    }
    return h('section', { class: 'value-table', 'aria-labelledby': id },
      h('h3', { id, text: sec.title }),
      h('table', { class: 'values' },
        h('thead', {}, h('tr', {}, h('th', { scope: 'col', text: 'Symbol' }), h('th', { scope: 'col', class: 'num', text: 'Value' }), h('th', { scope: 'col', text: 'Unit' }))),
        body));
  }

  function valueGroup(key, title, sections) {
    return h('section', { class: 'value-group', 'data-group': key },
      h('h2', { text: title }),
      h('div', { class: 'tables' }, ...sections.map((sec) => valueTable(key, sec))));
  }

  function toolbar() {
    const print = h('button', { type: 'button', class: 'button', text: 'Print' });
    print.addEventListener('click', () => window.print());
    return h('div', { class: 'toolbar' }, h('a', { class: 'button', href: '#/', text: 'All cartridges' }), print);
  }

  function renderDetail(record) {
    const facts = h('dl', { class: 'facts' });
    for (const f of CIP.format.buildFacts(record)) facts.append(...factRow(f));

    const { svg, notes } = CIP.drawing.render(record, document);
    const figure = h('figure', { class: 'drawing-figure' }, svg);
    if (notes.length) {
      figure.append(h('figcaption', { class: 'drawing-notes' },
        h('p', { text: 'Drawing notes' }),
        h('ul', {}, ...notes.map((n) => h('li', { text: n })))));
    }

    const tables = CIP.format.buildTables(record);
    return [
      toolbar(),
      h('h1', { tabindex: '-1', text: record.name }),
      facts,
      figure,
      h('div', { class: 'value-groups' },
        valueGroup('cartridge', 'Cartridge', tables.cartridge),
        valueGroup('chamber', 'Chamber', tables.chamber)),
      h('p', { class: 'print-footer', text: 'Source: C.I.P. TDCC, revised ' + record.revised }),
    ];
  }

  function renderNotFound() {
    return [
      toolbar(),
      h('h1', { tabindex: '-1', text: 'Cartridge not found' }),
      h('p', { text: 'There is no cartridge with this address. Choose one from the list.' }),
    ];
  }

  function showDetail(record, moveFocus) {
    if (!els.list.hidden) listScrollY = window.scrollY;
    els.detail.replaceChildren(...(record ? renderDetail(record) : renderNotFound()));
    els.list.hidden = true;
    els.detail.hidden = false;
    document.title = (record ? record.name : 'Cartridge not found') + ' – C.I.P. cartridges';
    window.scrollTo(0, 0);
    if (moveFocus) els.detail.querySelector('h1').focus({ preventScroll: true });
  }

  // ---- routing ---------------------------------------------------------------

  let listScrollY = 0;

  function showList(moveFocus) {
    const wasHidden = els.list.hidden;
    els.detail.hidden = true;
    els.list.hidden = false;
    document.title = 'Cartridges – C.I.P. reference';
    if (moveFocus) els.listHeading.focus({ preventScroll: true });
    window.scrollTo(0, wasHidden ? listScrollY : 0);   // coming back from a cartridge restores the list position
  }

  function route(moveFocus) {
    const m = /^#\/cartridge\/([^/]+)$/.exec(window.location.hash);
    if (!m) { showList(moveFocus); return; }
    let key = m[1];
    try { key = decodeURIComponent(key); } catch (e) { /* keep the raw text; it will not match a record */ }
    showDetail(CIP.catalogue.findByKey(records, key), moveFocus);
  }

  setupList();
  route(false);
  window.addEventListener('hashchange', () => route(true));
})();
