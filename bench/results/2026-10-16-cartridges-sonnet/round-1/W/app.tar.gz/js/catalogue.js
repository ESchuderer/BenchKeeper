/* Search and filter over the cartridge records. */
(function (root) {
  'use strict';

  const FAMILIES = ['All', 'rimless', 'rimmed', 'belted', 'pistol', 'rimfire'];

  // Case-insensitive, whitespace collapsed, decimal comma equals decimal point.
  function normalise(s) {
    return String(s).toLowerCase().replace(/,/g, '.').replace(/\s+/g, ' ').trim();
  }

  function matchesQuery(record, q) {
    if (!q) return true;
    const names = [record.name].concat(record.alternativeNames || []);
    return names.some((n) => normalise(n).includes(q));
  }

  function filter(records, opts) {
    const o = opts || {};
    const q = normalise(o.query || '');
    const family = o.family && o.family !== 'All' ? o.family : null;
    return records.filter((r) => (!family || r.family === family) && matchesQuery(r, q));
  }

  function countText(n) {
    return n + ' cartridges';
  }

  function findByKey(records, key) {
    return records.find((r) => r.key === key);
  }

  const api = { FAMILIES, normalise, filter, countText, findByKey };
  root.CIP = root.CIP || {};
  root.CIP.catalogue = api;
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
})(typeof window !== 'undefined' ? window : globalThis);
