/* Builds the inline SVG drawing of one cartridge from its record. 1 SVG user unit = 1 mm.
   x runs along the axis from the head face (z = 0) to the tip; the axis is y = 0; the upper half (y < 0) is
   the outside view and the lower half (y > 0) the section. */
(function (root) {
  'use strict';

  const SVG_NS = 'http://www.w3.org/2000/svg';
  const G = root.CIP && root.CIP.geometry ? root.CIP.geometry : (typeof require !== 'undefined' ? require('./geometry.js') : null);
  const L = root.CIP && root.CIP.layout ? root.CIP.layout : (typeof require !== 'undefined' ? require('./layout.js') : null);

  const HATCH_ID = 'cip-hatch';
  const STROKE = { outline: 0.3, thin: 0.18, hatch: 0.14 };

  const num = (v) => String(Math.round(v * 1000) / 1000);

  function el(doc, name, attrs, children) {
    const e = doc.createElementNS(SVG_NS, name);
    for (const [k, v] of Object.entries(attrs || {})) if (v !== undefined && v !== null) e.setAttribute(k, String(v));
    for (const c of children || []) e.appendChild(c);
    return e;
  }

  // model points {r, z} -> svg points "x,y" with y = sign * r
  const pointList = (poly, sign) => poly.map((p) => num(p.z) + ',' + num(sign * p.r)).join(' ');

  function polyline(doc, part, poly, sign, cls) {
    return el(doc, 'polyline', { 'data-part': part, class: cls, points: pointList(poly, sign), fill: 'none', 'stroke-width': STROKE.outline, 'stroke-linejoin': 'round', 'stroke-linecap': 'round' });
  }

  function arrowPath(a) {
    // triangle with its tip at (x, y), pointing against (dx, dy), i.e. its body lies along the dimension line
    const bx = a.x + a.dx * a.len, by = a.y + a.dy * a.len;
    const px = -a.dy * a.half, py = a.dx * a.half;
    return 'M' + num(a.x) + ',' + num(a.y) + ' L' + num(bx + px) + ',' + num(by + py) + ' L' + num(bx - px) + ',' + num(by - py) + ' Z';
  }

  function render(record, doc) {
    doc = doc || document;
    const model = G.buildModel(record);
    const lay = L.layoutDimensions(model, record);
    const vb = lay.viewBox;

    const svg = el(doc, 'svg', {
      xmlns: SVG_NS,
      class: 'drawing',
      role: 'img',
      'aria-label': record.name + ' drawing',
      viewBox: [vb.x, vb.y, vb.w, vb.h].map(num).join(' '),
      preserveAspectRatio: 'xMidYMid meet',
      focusable: 'false',
    });

    svg.appendChild(el(doc, 'defs', {}, [
      el(doc, 'pattern', { id: HATCH_ID, width: 0.9, height: 0.9, patternUnits: 'userSpaceOnUse', patternTransform: 'rotate(45)' }, [
        el(doc, 'line', { class: 'hatch-line', x1: 0, y1: 0, x2: 0, y2: 0.9, 'stroke-width': STROKE.hatch }),
      ]),
    ]));

    svg.appendChild(el(doc, 'rect', { class: 'frame', x: num(lay.frame.x), y: num(lay.frame.y), width: num(lay.frame.w), height: num(lay.frame.h), fill: 'none', 'stroke-width': STROKE.thin }));

    // bullet: outside view above (seated part hidden), section below (seated part shown)
    const bullet = model.bullet;
    if (bullet) {
      const g = el(doc, 'g', { class: 'bullet' });
      const closed = bullet.exposed.slice();
      g.appendChild(el(doc, 'polygon', { class: 'bullet-fill', 'data-part': 'bullet-fill-upper', points: pointList([{ r: 0, z: model.mouth.z }].concat(closed), -1), stroke: 'none' }));
      g.appendChild(polyline(doc, 'bullet-outline-upper', bullet.exposed, -1, 'bullet-line'));
      g.appendChild(el(doc, 'polygon', { class: 'bullet-fill', 'data-part': 'bullet-section', points: pointList(bullet.full, 1), stroke: 'none' }));
      g.appendChild(polyline(doc, 'bullet-outline-lower', bullet.full, 1, 'bullet-line'));
      svg.appendChild(g);
    }

    if (model.outer) {
      // section: hatched solid head and wall
      if (model.hatch) {
        svg.appendChild(el(doc, 'polygon', { class: 'hatch', 'data-part': 'hatch', points: pointList(model.hatch, 1), fill: 'url(#' + HATCH_ID + ')', stroke: 'none' }));
        svg.appendChild(polyline(doc, 'section-outline', model.hatch, 1, 'cut-line'));
      } else {
        svg.appendChild(polyline(doc, 'case-outline-lower', model.outer, 1, 'case-line'));
      }
      // outside view of the case
      svg.appendChild(polyline(doc, 'case-outline-upper', model.outer, -1, 'case-line'));
      // head face across the axis and the mouth faces
      const first = model.outer[1];
      svg.appendChild(el(doc, 'line', { class: 'case-line', 'data-part': 'head-face', x1: 0, y1: num(-first.r), x2: 0, y2: num(first.r), 'stroke-width': STROKE.outline, 'stroke-linecap': 'round' }));
      if (model.mouth) {
        const t = model.walls ? (model.walls.heeled ? model.walls.tb : model.walls.tn) : 0;
        const rIn = bullet ? Math.min(bullet.rExposed, model.mouth.r - (model.walls ? t : 0)) : model.mouth.r - t;
        const rOut = model.mouth.r;
        svg.appendChild(el(doc, 'line', { class: 'case-line', 'data-part': 'mouth-face-upper', x1: num(model.mouth.z), y1: num(-rOut), x2: num(model.mouth.z), y2: num(-rIn), 'stroke-width': STROKE.outline, 'stroke-linecap': 'round' }));
      }
    }

    svg.appendChild(el(doc, 'line', { class: 'centre-line', x1: num(lay.centreLine.x1 - 1), y1: 0, x2: num(lay.centreLine.x2 + 1), y2: 0, 'stroke-width': STROKE.thin, 'stroke-dasharray': '6 1 1 1' }));

    // dimensions
    const dg = el(doc, 'g', { class: 'dimensions' });
    for (const d of lay.dims) {
      const g = el(doc, 'g', { class: 'dim dim-' + d.kind, 'data-id': d.id });
      for (const l of d.lines) {
        g.appendChild(el(doc, 'line', { class: l.kind, x1: num(l.x1), y1: num(l.y1), x2: num(l.x2), y2: num(l.y2), 'stroke-width': STROKE.thin }));
      }
      for (const a of d.arrows) g.appendChild(el(doc, 'path', { class: 'arrow', d: arrowPath(a) }));
      const t = el(doc, 'text', { class: 'dim-label', x: num(d.label.x), y: num(d.label.y), 'text-anchor': d.label.anchor, 'font-size': lay.fontSize });
      t.textContent = d.label.text;
      g.appendChild(t);
      dg.appendChild(g);
    }
    svg.appendChild(dg);

    // title block
    const tb = lay.titleBlock;
    const tg = el(doc, 'g', { class: 'title-block' });
    tg.appendChild(el(doc, 'line', { class: 'title-rule', x1: num(tb.x), y1: num(tb.y), x2: num(tb.x + tb.w), y2: num(tb.y), 'stroke-width': STROKE.thin }));
    tg.appendChild(el(doc, 'line', { class: 'title-rule', x1: num(tb.x + tb.w / 2), y1: num(tb.y), x2: num(tb.x + tb.w / 2), y2: num(tb.y + tb.h), 'stroke-width': STROKE.thin }));
    for (const line of tb.lines) {
      const t = el(doc, 'text', { x: num(line.x), y: num(line.y), 'font-size': line.size, 'font-weight': line.weight || 'normal' });
      t.textContent = line.text;
      tg.appendChild(t);
    }
    svg.appendChild(tg);

    return { svg, notes: model.notes.slice(), model, layout: lay };
  }

  const api = { render };
  root.CIP = root.CIP || {};
  root.CIP.drawing = api;
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
})(typeof window !== 'undefined' ? window : globalThis);
