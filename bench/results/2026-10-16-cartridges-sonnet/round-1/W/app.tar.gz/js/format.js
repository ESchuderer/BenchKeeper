/* Formatting of record values: numbers, angles, units, symbols, tolerances, facts, tables.
   Classic script (works from file://). In Node it is also loadable with require(). */
(function (root) {
  'use strict';

  const ANGLE_FIELDS = new Set(['alpha', 'alpha1', 'beta', 'delta', 'i']);
  const PRESSURE_FIELDS = new Set(['Pmax', 'PK', 'PE']);

  const SYMBOLS = {
    eMin: 'e min', r1Min: 'r1 min', r1Max: 'r1 max',
    alpha: 'α', alpha1: 'α1', beta: 'β', delta: 'δ',
    deltaL: 'delta L', L3PlusG: 'L3 + G',
  };

  // Numbers keep the record's own digits: JSON already yields the shortest decimal.
  function formatNumber(n) {
    return String(n);
  }

  // A number of degrees, or {degrees, minutes, seconds}; parts that are absent are left out.
  function formatAngle(a) {
    if (typeof a === 'number') return formatNumber(a) + '°';
    if (!a || typeof a !== 'object' || typeof a.degrees !== 'number') return '';
    let out = a.degrees + '°';
    if (a.minutes !== undefined) out += a.minutes + "'";
    if (a.seconds !== undefined) out += a.seconds + '"';
    return out;
  }

  // A usable value is a finite number or an angle object with degrees.
  function isValue(v) {
    return (typeof v === 'number' && isFinite(v)) || (!!v && typeof v === 'object' && typeof v.degrees === 'number');
  }

  function isAngleField(field) {
    return ANGLE_FIELDS.has(field);
  }

  function unitFor(field) {
    if (isAngleField(field)) return 'deg';
    if (PRESSURE_FIELDS.has(field)) return 'bar';
    if (field === 'EE') return 'J';
    if (field === 'M') return 'g';
    if (field === 'Q') return 'mm²';
    if (field === 'N') return '';
    return 'mm';
  }

  function symbolFor(field) {
    return Object.prototype.hasOwnProperty.call(SYMBOLS, field) ? SYMBOLS[field] : field;
  }

  function formatValue(field, value) {
    return isAngleField(field) ? formatAngle(value) : formatNumber(value);
  }

  function formatWithTolerance(field, value, tol) {
    const v = formatValue(field, value);
    if (tol === undefined || tol === null) return v;
    return v + ' ' + (tol > 0 ? '+' : '') + formatNumber(tol);
  }

  function buildFacts(record) {
    const ann = record.annotations || {};
    const alt = record.alternativeNames && record.alternativeNames.length
      ? record.alternativeNames.join(', ') : '—';
    const cap = ann.publishedCapacity;
    const capacity = { label: 'Water capacity', text: 'not published' };
    if (cap) {
      capacity.text = formatNumber(cap.grH2O) + ' gr H2O';
      if (cap.note) capacity.note = cap.note;
      if (cap.url) capacity.link = { text: cap.source, href: cap.url };
    }
    return [
      { label: 'Alternative names', text: alt },
      { label: 'Family', text: record.family },
      { label: 'Category', text: ann.category || '—' },
      { label: 'Primer type', text: ann.primerType || '—' },
      { label: 'C.I.P. table', text: record.tab },
      { label: 'Country', text: record.country },
      { label: 'Published', text: record.published },
      { label: 'Revised', text: record.revised },
      { label: 'Pressure method', text: record.pressureMethod },
      capacity,
    ];
  }

  const SECTION_TITLES = {
    caseHead: 'Case head', collar: 'Collar', junctionCone: 'Junction cone', lengths: 'Lengths',
    misc: 'Miscellaneous', powderChamber: 'Powder chamber', pressures: 'Pressures',
    projectile: 'Projectile', barrel: 'Barrel', breech: 'Breech', grooves: 'Grooves', rifling: 'Rifling',
  };

  const SECTION_ORDER = {
    cartridge: ['caseHead', 'powderChamber', 'collar', 'junctionCone', 'lengths', 'projectile', 'pressures', 'misc'],
    chamber: ['breech', 'powderChamber', 'collar', 'junctionCone', 'lengths', 'barrel', 'grooves', 'rifling'],
  };

  // Preferred row order inside a section; fields not listed follow in record order.
  const ROW_ORDER = {
    caseHead: ['R1', 'R3', 'R', 'E1', 'E', 'eMin', 'f', 'beta', 'delta'],
    collar: ['H1', 'H2'],
    junctionCone: ['S', 'alpha', 'r1Min', 'r1Max', 'r2'],
    lengths: ['L1', 'L2', 'L3', 'L4', 'L5', 'L6'],
    misc: ['Fe', 'deltaL'],
    powderChamber: ['P1', 'P2', 'E'],
    pressures: ['Pmax', 'PK', 'PE', 'EE', 'M'],
    projectile: ['G1', 'G2', 'L3PlusG'],
    barrel: ['F', 'Z'],
    breech: ['R1', 'R', 'R3', 'r'],
    grooves: ['N', 'b', 'Q', 'u'],
    rifling: ['G', 'G1', 'h', 's', 'alpha1', 'i'],
  };

  function buildSection(sectionKey, fields) {
    const names = Object.keys(fields).filter((n) => !/Tol$/.test(n) && isValue(fields[n]));
    const order = ROW_ORDER[sectionKey] || [];
    names.sort((a, b) => {
      const ia = order.indexOf(a), ib = order.indexOf(b);
      return (ia < 0 ? 1e9 : ia) - (ib < 0 ? 1e9 : ib);
    });
    return {
      key: sectionKey,
      title: SECTION_TITLES[sectionKey] || sectionKey,
      rows: names.map((field) => ({
        field,
        symbol: symbolFor(field),
        value: formatWithTolerance(field, fields[field], fields[field + 'Tol']),
        unit: unitFor(field),
      })),
    };
  }

  function buildGroup(groupKey, data) {
    const known = SECTION_ORDER[groupKey];
    const keys = known.filter((k) => data && data[k]).concat(
      Object.keys(data || {}).filter((k) => !known.includes(k)));
    return keys.map((k) => buildSection(k, data[k])).filter((s) => s.rows.length > 0);
  }

  function buildTables(record) {
    return {
      cartridge: buildGroup('cartridge', record.cartridge),
      chamber: buildGroup('chamber', record.chamber),
    };
  }

  const api = {
    isValue, formatNumber, formatAngle, isAngleField, unitFor, symbolFor, formatValue,
    formatWithTolerance, buildFacts, buildTables,
  };
  root.CIP = root.CIP || {};
  root.CIP.format = api;
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
})(typeof window !== 'undefined' ? window : globalThis);
