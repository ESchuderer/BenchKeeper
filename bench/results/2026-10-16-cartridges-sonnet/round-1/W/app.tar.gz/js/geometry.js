/* Geometry of a cartridge drawing, computed from a record only.
   Coordinates are {r, z}: r = radius, z = distance from the head face along the axis.
   Nothing here touches the DOM. Missing values drop a feature and add a note; no number is invented. */
(function (root) {
  'use strict';

  const DEG = Math.PI / 180;

  const isNum = (x) => typeof x === 'number' && isFinite(x);
  function degrees(a) {
    if (isNum(a)) return a;
    if (a && isNum(a.degrees)) return a.degrees + (a.minutes || 0) / 60 + (a.seconds || 0) / 3600;
    return undefined;
  }

  function rimType(record) {
    if (record.family === 'belted') return 'belted';
    if (record.family === 'rimfire') return 'rimfire';
    const ch = (record.cartridge && record.cartridge.caseHead) || {};
    const pc = (record.cartridge && record.cartridge.powderChamber) || {};
    if (!isNum(ch.R1) || !isNum(pc.P1)) return 'rimless';
    const ratio = ch.R1 / pc.P1;
    if (ratio >= 1.05) return 'rimmed';
    if (ratio < 0.98) return 'rebated';
    return 'rimless';
  }

  // ---- polyline helpers -----------------------------------------------------

  function pushPoint(pts, r, z) {
    const last = pts[pts.length - 1];
    if (last && Math.abs(last.r - r) < 1e-9 && Math.abs(last.z - z) < 1e-9) return;
    pts.push({ r, z });
  }

  function arcPoints(cr, cz, rad, a0, a1, stepDeg) {
    // points on a circle (centre r=cr, z=cz) from angle a0 to a1 (radians, measured in the (z, r) plane)
    const n = Math.max(2, Math.ceil(Math.abs(a1 - a0) / (stepDeg * DEG)));
    const out = [];
    for (let i = 0; i <= n; i++) {
      const a = a0 + ((a1 - a0) * i) / n;
      out.push({ r: cr + rad * Math.sin(a), z: cz + rad * Math.cos(a) });
    }
    return out;
  }

  // Rounds the corner p1 between p0->p1 and p1->p2 with a tangent arc.
  // The tangent length t = radius * tan(theta / 2) is limited to half of the shorter adjacent segment.
  function roundCorner(p0, p1, p2, radius) {
    const d1 = Math.hypot(p1.z - p0.z, p1.r - p0.r), d2 = Math.hypot(p2.z - p1.z, p2.r - p1.r);
    const u1 = { z: (p1.z - p0.z) / d1, r: (p1.r - p0.r) / d1 };
    const u2 = { z: (p2.z - p1.z) / d2, r: (p2.r - p1.r) / d2 };
    const cross = u1.z * u2.r - u1.r * u2.z;
    const theta = Math.acos(Math.max(-1, Math.min(1, u1.z * u2.z + u1.r * u2.r)));
    if (theta < 1e-4 || !(radius > 0)) return { points: [p1], radius: 0, clamped: false };
    const tanHalf = Math.tan(theta / 2);
    const tMax = 0.5 * Math.min(d1, d2);
    let rad = radius, clamped = false;
    if (rad * tanHalf > tMax) { rad = tMax / tanHalf; clamped = true; }
    const t = rad * tanHalf;
    const T1 = { z: p1.z - u1.z * t, r: p1.r - u1.r * t };
    const sign = cross > 0 ? 1 : -1;               // turn direction in the (z, r) plane
    const nrm = { z: -u1.r * sign, r: u1.z * sign }; // unit normal of u1 pointing to the arc centre
    const c = { z: T1.z + nrm.z * rad, r: T1.r + nrm.r * rad };
    const a0 = Math.atan2(T1.r - c.r, T1.z - c.z);
    const n = Math.max(2, Math.ceil(theta / (2 * DEG)));
    const points = [];
    for (let i = 0; i <= n; i++) {
      const a = a0 + sign * theta * (i / n);
      points.push({ r: c.r + rad * Math.sin(a), z: c.z + rad * Math.cos(a) });
    }
    return { points, radius: rad, clamped };
  }

  // Primer pocket diameter and depth by primer type; rimfire cases have none.
  const POCKETS = {
    sp: { diameter: 4.45, depth: 3.04 }, spm: { diameter: 4.45, depth: 3.04 }, sr: { diameter: 4.45, depth: 3.04 },
    lp: { diameter: 5.33, depth: 3.04 }, lpm: { diameter: 5.33, depth: 3.04 },
    lr: { diameter: 5.33, depth: 3.3 }, lrm: { diameter: 5.33, depth: 3.3 },
  };

  function interpolateR(poly, z) {
    if (z <= poly[0].z) return poly[0].r;
    for (let i = 1; i < poly.length; i++) {
      const a = poly[i - 1], b = poly[i];
      if (z <= b.z) return b.z === a.z ? b.r : a.r + ((b.r - a.r) * (z - a.z)) / (b.z - a.z);
    }
    return poly[poly.length - 1].r;
  }

  // ---- bullet ---------------------------------------------------------------

  const SEATING = { pointy: () => 1.0, semi_wadcutter: () => 0.6 };
  const CYLINDER_K = {
    pointy: () => 0.40, semi_wadcutter: () => 0.78,
    rounded: (pistol) => (pistol ? 0.65 : 0.55),
    flat: (pistol) => (pistol ? 0.70 : 0.60),
  };

  function nosePolyline(shape, rn, mr, zc, n) {
    const a = rn - mr;
    const out = [];
    if (shape === 'pointy' && n > a) {
      // tangent ogive: arc of radius rho centred at r = rn - rho on the radial line where the nose starts
      const rho = (a * a + n * n) / (2 * a);
      const steps = 48;
      for (let i = 0; i <= steps; i++) {
        const dz = (n * i) / steps;
        out.push({ r: rn - rho + Math.sqrt(Math.max(0, rho * rho - dz * dz)), z: zc + dz });
      }
      out[out.length - 1] = { r: mr, z: zc + n };
      return { points: out, rho };
    }
    if (shape === 'rounded') {
      // quarter ellipse, semi-axes n along the axis and a across it, centred at r = mr, z = zc
      const steps = 32;
      for (let i = 0; i <= steps; i++) {
        const phi = (Math.PI / 2) * (i / steps);
        out.push({ r: mr + a * Math.cos(phi), z: zc + n * Math.sin(phi) });
      }
      out[0] = { r: rn, z: zc };
      out[out.length - 1] = { r: mr, z: zc + n };
      return { points: out };
    }
    return { points: [{ r: rn, z: zc }, { r: mr, z: zc + n }] };
  }

  function buildBullet(record, model) {
    const { G1 } = section(record, 'cartridge', 'projectile');
    const { L3, L6 } = section(record, 'cartridge', 'lengths');
    const ann = record.annotations || {};
    const shape = ann.defaultBulletShape;
    const category = ann.category;
    const known = Object.prototype.hasOwnProperty.call(CYLINDER_K, shape);
    const needsCategory = shape === 'rounded' || shape === 'flat';
    const missing = [['G1', G1], ['L3', L3], ['L6', L6]].filter(([, v]) => !isNum(v)).map(([k]) => k);
    if (!shape) missing.push('bullet shape');
    if (needsCategory && !category) missing.push('category');
    if (shape && !known) {
      model.notes.push('Bullet not drawn: unknown bullet shape "' + shape + '".');
      return null;
    }
    if (missing.length) {
      model.notes.push('Bullet not drawn: ' + missing.join(', ') + ' not published.');
      return null;
    }
    const pistol = category === 'pistol';
    const s = shape === 'rounded' || shape === 'flat' ? (pistol ? 0.4 : 0.8) * G1 : SEATING[shape]() * G1;
    const zb = L3 - s;
    const Lb = L6 - zb;
    const k = CYLINDER_K[shape](pistol);
    const zc = zb + k * Lb;
    const n = L6 - zc;
    const meplat = shape === 'pointy' ? Math.max(0.08 * G1, 1.27)
      : shape === 'rounded' ? 0.15 * G1 : shape === 'flat' ? 0.55 * G1 : 0.6 * G1;
    const heeled = model.walls.heeled;
    const rExposed = heeled ? model.mouth.r : G1 / 2;
    const rSeated = heeled ? model.mouth.r - model.walls.tb : G1 / 2;
    const noseInfo = nosePolyline(shape, rExposed, meplat / 2, zc, n);
    const nose = noseInfo.points;

    // outside view: from the mouth to the tip and across the meplat face to the axis
    const exposed = [];
    if (zc >= L3) {
      exposed.push({ r: rExposed, z: L3 });
      pushPoint(exposed, rExposed, zc);
      for (const p of nose) pushPoint(exposed, p.r, p.z);
    } else {
      for (let i = 1; i < nose.length; i++) {
        const a = nose[i - 1], b = nose[i];
        if (b.z < L3) continue;
        if (!exposed.length) {
          const t = (L3 - a.z) / (b.z - a.z);
          exposed.push({ r: a.r + t * (b.r - a.r), z: L3 });
        }
        pushPoint(exposed, b.r, b.z);
      }
    }
    pushPoint(exposed, 0, L6);

    // section: the whole bullet from its base, seated part inside the case
    const full = [{ r: 0, z: zb }];
    pushPoint(full, rSeated, zb);
    if (zc >= L3) {
      pushPoint(full, rSeated, L3);
      pushPoint(full, rExposed, L3);
      pushPoint(full, rExposed, zc);
      for (const p of nose) pushPoint(full, p.r, p.z);
    } else {
      pushPoint(full, rSeated, zc);
      for (const p of nose) pushPoint(full, p.r, p.z);
    }
    pushPoint(full, 0, L6);

    return { shape, category, s, zb, zc, Lb, k, n, meplat, rho: noseInfo.rho, heeled, rExposed, rSeated, nose, exposed, full };
  }

  // ---- model ----------------------------------------------------------------

  function section(record, group, name) {
    return ((record[group] || {})[name]) || {};
  }

  function buildModel(record) {
    const notes = [];
    const ch = section(record, 'cartridge', 'caseHead');
    const pc = section(record, 'cartridge', 'powderChamber');
    const type = rimType(record);
    const model = {
      name: record.name, rimType: type, notes, outer: null, rim: {}, inner: null, hatch: null,
      head: null, walls: null, bullet: null, fillets: [], isBottleneck: false, mouth: null,
    };

    const { R, R1, f, beta } = ch;
    const P1 = pc.P1;
    if (!isNum(R1) || !isNum(R) || !isNum(P1)) {
      notes.push('Case outline not drawn: ' + ['R1', 'R', 'P1'].filter((k) => !isNum({ R1, R, P1 }[k])).join(', ') + ' not published.');
      return model;
    }

    const pts = [];
    pushPoint(pts, 0, 0);
    let rimOuterR = R1 / 2;
    let rimMidZ = R / 2;

    if (type === 'rimfire') {
      const rho = Math.min(R / 2, (R1 - P1) / 2);
      const rc = R1 / 2 - rho;
      model.rim.halfRoundRadius = rho;
      pushPoint(pts, rc, 0);
      pushPoint(pts, rc, R / 2 - rho);
      // semicircle bulging outward: centre (r = rc, z = R/2), from z = R/2 - rho over r = R1/2 to z = R/2 + rho
      for (const p of arcPoints(rc, R / 2, rho, Math.PI, 0, 3)) pushPoint(pts, p.r, p.z);
      pushPoint(pts, rc, R);
      rimOuterR = rc;
    } else {
      const betaDeg = degrees(beta);
      if (isNum(f) && betaDeg !== undefined && betaDeg < 90) {
        const c = Math.min(f * Math.tan(betaDeg * DEG), R1 / 4);
        pushPoint(pts, R1 / 2 - c, 0);
        pushPoint(pts, R1 / 2, f);
        rimMidZ = (f + R) / 2;
      } else {
        pushPoint(pts, R1 / 2, 0);
        const lacking = [['f', f], ['β', betaDeg]].filter(([, v]) => !isNum(v)).map(([k]) => k);
        if (lacking.length) notes.push('Head chamfer not drawn: ' + lacking.join(' and ') + ' not published.');
        else notes.push('Head chamfer not drawn: β must be below 90°.');
      }
      pushPoint(pts, R1 / 2, R);
    }
    model.rim.outerR = rimOuterR;
    model.rim.midZ = rimMidZ;

    // ---- extractor groove, belt, or plain step in behind the rim ----
    const { E, E1, eMin, R3, delta } = ch;
    const grooveNeeded = type !== 'rimmed' && type !== 'rimfire';
    const hasGroove = isNum(E) && isNum(E1) && isNum(eMin);
    if (hasGroove) {
      pushPoint(pts, E1 / 2, R);
      pushPoint(pts, E1 / 2, R + eMin);
      model.groove = { r: E1 / 2, z0: R, z1: R + eMin };
      const deltaDeg = degrees(delta);
      let belt = false;
      if (type === 'belted') {
        if (isNum(R3) && deltaDeg !== undefined && deltaDeg > 0) {
          const zEnd = R + eMin + (R3 / 2 - E1 / 2) / Math.tan(deltaDeg * DEG);
          if (zEnd <= E) {
            pushPoint(pts, R3 / 2, zEnd);
            pushPoint(pts, R3 / 2, E);
            model.beltRampEnd = zEnd;
            belt = true;
          } else {
            notes.push('Belt not drawn: the ramp at δ would end beyond E.');
          }
        } else {
          notes.push('Belt not drawn: ' + [['R3', R3], ['δ', deltaDeg]].filter(([, v]) => !isNum(v)).map(([k]) => k).join(' and ') + ' not published.');
        }
      }
      pushPoint(pts, P1 / 2, E);
      model.bodyStart = { r: P1 / 2, z: E };
      model.hasGroove = true;
      model.belt = belt;
    } else {
      if (grooveNeeded) {
        const missing = [['E', E], ['E1', E1], ['e min', eMin]].filter(([, v]) => !isNum(v)).map(([k]) => k);
        notes.push('Extractor groove not drawn: ' + missing.join(', ') + ' not published.');
      }
      pushPoint(pts, P1 / 2, R);
      model.bodyStart = { r: P1 / 2, z: R };
    }

    // ---- body, shoulder, neck, mouth ----
    const jc = section(record, 'cartridge', 'junctionCone');
    const len = section(record, 'cartridge', 'lengths');
    const col = section(record, 'cartridge', 'collar');
    const alphaDeg = degrees(jc.alpha);
    const { L1, L2, L3 } = len;
    const { H1, H2 } = col;
    const P2 = pc.P2;
    model.fillets = [];
    model.isBottleneck = false;
    if (!isNum(L3) || !isNum(H2)) {
      notes.push('Neck and mouth not drawn: ' + [['L3', L3], ['H2', H2]].filter(([, v]) => !isNum(v)).map(([k]) => k).join(' and ') + ' not published.');
      model.outer = pts;
      return model;
    }

    const shoulderInputs = [['α', alphaDeg], ['L1', L1], ['L2', L2]];
    const anyShoulder = shoulderInputs.some(([, v]) => isNum(v));
    const allShoulder = shoulderInputs.every(([, v]) => isNum(v));
    const bottleneck = allShoulder && isNum(P2) && isNum(H1);
    const start = model.bodyStart;
    if (bottleneck) {
      model.isBottleneck = true;
      const A = { r: P2 / 2, z: L1 }, B = { r: H1 / 2, z: L2 }, C = { r: H2 / 2, z: L3 };
      model.corners = { shoulderStart: A, shoulderEnd: B };
      const fa = roundCorner(start, A, B, jc.r1Min);
      const fb = roundCorner(A, B, C, jc.r2);
      for (const [sym, pub, f] of [['r1 min', jc.r1Min, fa], ['r2', jc.r2, fb]]) {
        if (!isNum(pub)) { notes.push('Shoulder corner not rounded: ' + sym + ' not published.'); continue; }
        model.fillets.push({ symbol: sym, published: pub, radius: f.radius, clamped: f.clamped });
        if (f.clamped) notes.push('Shoulder corner ' + sym + ' reduced from ' + pub + ' to ' + Math.round(f.radius * 100) / 100 + ' to fit.');
      }
      for (const p of (isNum(jc.r1Min) ? fa.points : [A])) pushPoint(pts, p.r, p.z);
      for (const p of (isNum(jc.r2) ? fb.points : [B])) pushPoint(pts, p.r, p.z);
      pushPoint(pts, C.r, C.z);
    } else {
      if (anyShoulder) {
        const missing = shoulderInputs.concat([['P2', P2], ['H1', H1]]).filter(([, v]) => !isNum(v)).map(([k]) => k);
        notes.push('Shoulder not drawn, the case is shown straight: ' + missing.join(', ') + ' not published.');
      }
      pushPoint(pts, H2 / 2, L3);
    }
    model.mouth = { r: H2 / 2, z: L3 };
    model.outer = pts;

    // ---- section: walls, inner line, solid head, primer pocket ----
    const G1 = section(record, 'cartridge', 'projectile').G1;
    const primer = (record.annotations || {}).primerType;
    let pocket = null;
    if (primer === 'rimfire') pocket = null;
    else if (POCKETS[primer]) pocket = { diameter: POCKETS[primer].diameter, depth: POCKETS[primer].depth };
    else notes.push('Primer pocket not drawn: primer type not published' + (primer ? ' (unknown type ' + primer + ')' : '') + '.');
    model.head = { w: undefined, pocket };
    model.inner = null;
    model.hatch = null;

    if (!isNum(G1)) {
      notes.push('Section walls not drawn: G1 not published.');
      model.bullet = buildBullet(record, model);
      return model;
    }
    const tn = (H2 - G1) / 2;
    const heeled = H2 - G1 <= 0.015;
    const tb = Math.min(Math.max(1.3 * tn, 0.6), (0.35 * P1) / 2);
    const tnEff = heeled ? tb : tn;
    model.walls = { tn, tb, heeled };
    const inner = [{ r: start.r - tb, z: start.z }];
    if (model.isBottleneck) {
      inner.push({ r: P2 / 2 - tb, z: L1 }, { r: H1 / 2 - tnEff, z: L2 });
    }
    inner.push({ r: H2 / 2 - tnEff, z: L3 });
    model.inner = inner;

    const wTerms = [2.5, (0.25 * P1) / 2];
    if (pocket) wTerms.push(pocket.depth + 1.5);
    if (model.beltRampEnd !== undefined) wTerms.push(model.beltRampEnd + tb);
    else if (model.hasGroove) wTerms.push(E + tb);
    const w = Math.max(...wTerms);
    model.head.w = w;

    // hatched region of the section: the solid head plus the case wall, minus the primer pocket
    const hatch = [];
    if (pocket) {
      hatch.push({ r: 0, z: pocket.depth }, { r: pocket.diameter / 2, z: pocket.depth }, { r: pocket.diameter / 2, z: 0 });
      for (let i = 1; i < pts.length; i++) hatch.push(pts[i]);
    } else {
      for (const p of pts) hatch.push(p);
    }
    hatch.push({ r: H2 / 2 - tnEff, z: L3 });
    for (let i = inner.length - 2; i >= 0; i--) if (inner[i].z > w) hatch.push(inner[i]);
    hatch.push({ r: interpolateR(inner, w), z: w }, { r: 0, z: w });
    model.hatch = hatch;
    model.bullet = buildBullet(record, model);

    return model;
  }

  const api = { rimType, buildModel, degrees };
  root.CIP = root.CIP || {};
  root.CIP.geometry = api;
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
})(typeof window !== 'undefined' ? window : globalThis);
