/* Dimension lines, labels and title block of the drawing.
   Output is in SVG user units (1 unit = 1 mm): x = z along the axis, y = -r in the upper half and +r in the
   lower half, so the axis is y = 0. Nothing here touches the DOM. */
(function (root) {
  'use strict';

  const F = root.CIP && root.CIP.format ? root.CIP.format : (typeof require !== 'undefined' ? require('./format.js') : null);

  const FS = 2.8;                  // label font size
  const CHAR_W = 0.6 * FS;         // conservative average advance of a sans-serif character
  const PITCH_TOP = FS + 1.2;      // distance between rows of diameter labels
  const PITCH_BOTTOM = 5.4;        // distance between length dimension rows
  const NARROW = 4.5;              // length dimensions shorter than this get outside arrowheads
  const TAIL = 2.6;
  const GAP = 0.8;                 // gap between an outline and the start of an extension line
  const PAD = 0.4;                 // clearance kept around labels
  const MARGIN = 3;
  const TITLE_H = 13;
  const MIN_W = 96;
  const MAX_ASPECT = 0.6;          // height / width, so one A4 page can hold the drawing at full width
  const PRINT_WIDTH = 190;         // A4 content width in mm

  const isNum = (x) => typeof x === 'number' && isFinite(x);

  function textWidth(text, size) {
    return text.length * 0.6 * (size || FS);
  }

  function labelBox(x, baseline, text, anchor) {
    const w = textWidth(text);
    const x0 = anchor === 'middle' ? x - w / 2 : anchor === 'end' ? x - w : x;
    return { x0, x1: x0 + w, y0: baseline - 0.95 * FS, y1: baseline + 0.25 * FS };
  }

  const grow = (b, p) => ({ x0: b.x0 - p, y0: b.y0 - p, x1: b.x1 + p, y1: b.y1 + p });
  const rectsOverlap = (a, b) => a.x0 < b.x1 && b.x0 < a.x1 && a.y0 < b.y1 && b.y0 < a.y1;

  // Liang-Barsky: does the segment touch the rectangle?
  function segmentHitsRect(sg, b) {
    let t0 = 0, t1 = 1;
    const dx = sg.x2 - sg.x1, dy = sg.y2 - sg.y1;
    const p = [-dx, dx, -dy, dy];
    const q = [sg.x1 - b.x0, b.x1 - sg.x1, sg.y1 - b.y0, b.y1 - sg.y1];
    for (let i = 0; i < 4; i++) {
      if (p[i] === 0) { if (q[i] < 0) return false; continue; }
      const t = q[i] / p[i];
      if (p[i] < 0) { if (t > t1) return false; if (t > t0) t0 = t; }
      else { if (t < t0) return false; if (t < t1) t1 = t; }
    }
    return true;
  }

  // A candidate box is free when it keeps PAD clear of every obstacle segment and placed label.
  function isFree(box, segments, placed) {
    const g = grow(box, PAD);
    return !segments.some((sg) => segmentHitsRect(sg, g)) && !placed.some((b) => rectsOverlap(g, b));
  }

  // Places the labels of the upper dimensions. Each label sits in a row above the drawing, at the end of a
  // leader that rises from its dimension line, either right of the leader ('start') or left of it ('end').
  // Tries every left/right choice in two orders and keeps the arrangement with the fewest rows.
  function placeUpperLabels(items, baseObstacles, initialBoxes, top) {
    const n = items.length;
    const xs = items.map((d) => d.anchorPoint.x);
    const orders = [
      [...Array(n).keys()].sort((p, q) => xs[q] - xs[p]),
      [...Array(n).keys()].sort((p, q) => xs[p] - xs[q]),
    ];
    let best = null;
    const run = (order, mask) => {
      const boxes = initialBoxes.slice();
      const obstacles = baseObstacles.slice();
      const out = new Array(n);
      let rows = 0, total = 0;
      for (const i of order) {
        const { x, y } = items[i].anchorPoint;
        const anchor = (mask >> i) & 1 ? 'end' : 'start';
        const lx = anchor === 'start' ? x + 0.8 : x - 0.8;
        let placed = null;
        for (let k = 0; k < 12 && !placed; k++) {
          const baseline = top - k * PITCH_TOP;
          const box = labelBox(lx, baseline, items[i].text, anchor);
          const leader = { x1: x, y1: y, x2: x, y2: baseline };
          if (isFree(box, obstacles, boxes) && !boxes.some((pb) => segmentHitsRect(leader, grow(pb, 0.2)))) {
            placed = { x: lx, y: baseline, anchor, box, k };
            obstacles.push(leader);
            boxes.push(box);
          }
        }
        if (!placed) return null;
        if (best && placed.k > best.rows) return null;   // cannot beat the best arrangement so far
        out[i] = placed;
        rows = Math.max(rows, placed.k);
        total += placed.k;
      }
      const ends = out.reduce((c, p) => c + (p.anchor === 'end' ? 1 : 0), 0);
      return { out, rows, score: rows * 1e6 + total * 1e3 + ends };
    };
    for (const order of orders) {
      const masks = n <= 10 ? (1 << n) : 1;   // all left/right choices for up to 10 labels, otherwise all 'start'
      for (let mask = 0; mask < masks; mask++) {
        const r = run(order, mask);
        if (r && (!best || r.score < best.score)) best = r;
      }
    }
    if (best) return best.out;
    // fallback: far above, right of the leader (never reached with the records at hand)
    return items.map((d) => {
      const baseline = top - 12 * PITCH_TOP;
      return { x: d.anchorPoint.x + 0.8, y: baseline, anchor: 'start', box: labelBox(d.anchorPoint.x + 0.8, baseline, d.text, 'start') };
    });
  }

  function makeArrow(x, y, dx, dy, spanLen) {
    const len = Math.min(1.8, 0.4 * spanLen);
    return { x, y, dx, dy, len, half: 0.35 };
  }

  function line(kind, x1, y1, x2, y2) {
    return { kind, x1, y1, x2, y2 };
  }

  function value(record, group, section, field) {
    const v = ((record[group] || {})[section] || {})[field];
    return isNum(v) || (v && typeof v === 'object') ? v : undefined;
  }

  // ---- geometry shared with tests ---------------------------------------------

  function mirror(poly) {
    return poly.map((p) => ({ x: p.z, y: -p.r }));
  }

  // Obstacle segments labels must keep away from: the case and bullet outlines.
  function outlineSegments(model) {
    const segs = [];
    const add = (poly, sign) => {
      for (let i = 1; i < poly.length; i++) {
        segs.push({ x1: poly[i - 1].z, y1: sign * poly[i - 1].r, x2: poly[i].z, y2: sign * poly[i].r });
      }
    };
    const closeHead = (sign) => {
      const first = model.outer[1];
      if (first) segs.push({ x1: 0, y1: -first.r * sign, x2: 0, y2: first.r * sign });
    };
    if (model.outer) {
      for (const sign of [-1, 1]) add(model.outer, sign);
      closeHead(1);
      if (model.mouth && model.walls) {
        const t = model.walls.heeled ? model.walls.tb : model.walls.tn;
        for (const sign of [-1, 1]) segs.push({ x1: model.mouth.z, y1: sign * model.mouth.r, x2: model.mouth.z, y2: sign * (model.mouth.r - t) });
      }
    }
    if (model.inner) for (const sign of [-1, 1]) add(model.inner, sign);
    if (model.bullet) {
      add(model.bullet.exposed, -1);
      add(model.bullet.full, 1);
    }
    return segs;
  }

  // ---- layout -------------------------------------------------------------------

  function layoutDimensions(model, record) {
    const dims = [];
    let lengthBoxes = [];
    const outline = outlineSegments(model);
    const rimR = model.outer ? Math.max(...model.outer.map((p) => p.r)) : 0;
    const bulletR = model.bullet ? Math.max(model.bullet.rExposed, model.bullet.rSeated) : 0;
    const rTop = Math.max(rimR, bulletR);

    if (model.outer) {
      const ch = (record.cartridge || {}).caseHead || {};
      const pc = (record.cartridge || {}).powderChamber || {};
      const len = (record.cartridge || {}).lengths || {};
      const col = (record.cartridge || {}).collar || {};
      const jc = (record.cartridge || {}).junctionCone || {};
      const proj = (record.cartridge || {}).projectile || {};
      const fmt = (field, v) => F.formatValue(field, v);

      // ---- length dimensions below the drawing -------------------------------------
      const lengthItems = [];
      const headEdgeR = Math.max(...model.outer.filter((p) => p.z === 0).map((p) => p.r));
      if (isNum(ch.R)) lengthItems.push({ id: 'R', field: 'R', v: ch.R, x: ch.R, r: model.rim.outerR });
      if (isNum(len.L1) && model.isBottleneck) lengthItems.push({ id: 'L1', field: 'L1', v: len.L1, x: len.L1, r: model.corners.shoulderStart.r });
      if (isNum(len.L2) && model.isBottleneck) lengthItems.push({ id: 'L2', field: 'L2', v: len.L2, x: len.L2, r: model.corners.shoulderEnd.r });
      if (isNum(len.L3) && model.mouth) lengthItems.push({ id: 'L3', field: 'L3', v: len.L3, x: len.L3, r: model.mouth.r });
      if (isNum(len.L6) && model.bullet) lengthItems.push({ id: 'L6', field: 'L6', v: len.L6, x: len.L6, r: model.bullet.meplat / 2 });
      lengthItems.sort((a, b) => a.v - b.v);
      const rowBase = rimR + 5;
      lengthItems.forEach((it, i) => {
        const rowY = rowBase + i * PITCH_BOTTOM;
        const d = { id: it.id, kind: 'length', symbol: F.symbolFor(it.field), lines: [], arrows: [] };
        d.lines.push(line('ext', 0, headEdgeR + GAP, 0, rowY + 0.8));
        d.lines.push(line('ext', it.x, it.r + GAP, it.x, rowY + 0.8));
        d.lines.push(line('dim', 0, rowY, it.x, rowY));
        if (it.x < NARROW) {
          // too short for arrowheads inside: they point in from outside, on short tails
          d.narrow = true;
          d.lines.push(line('tail', -TAIL, rowY, 0, rowY), line('tail', it.x, rowY, it.x + TAIL, rowY));
          d.arrows.push(makeArrow(0, rowY, -1, 0, 100), makeArrow(it.x, rowY, 1, 0, 100));
        } else {
          d.arrows.push(makeArrow(0, rowY, 1, 0, it.x), makeArrow(it.x, rowY, -1, 0, it.x));
        }
        d.text = d.symbol + ' ' + fmt(it.field, it.v);
        d.row = { y: rowY, x1: it.x };
        dims.push(d);
      });
      const placed = [];
      const lineObstacles = () => dims.flatMap((d) => d.lines);
      for (const d of dims) {
        const { y: rowY, x1 } = d.row;
        const candidates = [
          { x: x1 / 2, y: rowY - 1.4, anchor: 'middle' },
          { x: x1 + TAIL + 0.8, y: rowY - 1.4, anchor: 'start' },
          { x: x1 / 2, y: rowY + 0.9 + 0.95 * FS, anchor: 'middle' },
        ];
        if (d.narrow) candidates.shift();
        let chosen = candidates[0];
        for (const c of candidates) {
          if (isFree(labelBox(c.x, c.y, d.text, c.anchor), outline.concat(lineObstacles()), placed)) { chosen = c; break; }
        }
        d.label = { text: d.text, x: chosen.x, y: chosen.y, anchor: chosen.anchor };
        d.label.box = labelBox(d.label.x, d.label.y, d.text, d.label.anchor);
        placed.push(grow(d.label.box, 0));
        delete d.text; delete d.row;
      }
      lengthBoxes = placed;

      // ---- diameter dimensions above ------------------------------------------------
      const diaItems = [];
      const rimMid = model.rim.midZ;
      if (isNum(ch.R1)) diaItems.push({ id: 'R1', field: 'R1', v: ch.R1, xf: rimMid, xd: -4 });
      if (model.groove && isNum(ch.E1)) diaItems.push({ id: 'E1', field: 'E1', v: ch.E1, xf: (model.groove.z0 + model.groove.z1) / 2, xd: (model.groove.z0 + model.groove.z1) / 2 + 2.5 });
      if (isNum(pc.P1)) diaItems.push({ id: 'P1', field: 'P1', v: pc.P1, xf: model.bodyStart.z, xd: model.bodyStart.z + 2.5 });
      if (model.isBottleneck) {
        diaItems.push({ id: 'P2', field: 'P2', v: pc.P2, xf: model.corners.shoulderStart.z, xd: model.corners.shoulderStart.z + 2.5 });
        diaItems.push({ id: 'H1', field: 'H1', v: col.H1, xf: model.corners.shoulderEnd.z, xd: model.corners.shoulderEnd.z + 2.5 });
      }
      if (isNum(col.H2) && model.mouth) diaItems.push({ id: 'H2', field: 'H2', v: col.H2, xf: model.mouth.z, xd: model.mouth.z + 2.5 });
      if (model.bullet) {
        const xf = (model.mouth.z + Math.max(model.bullet.zc, model.mouth.z)) / 2;   // middle of the exposed cylinder
        diaItems.push({ id: 'G1', field: 'G1', v: proj.G1, xf, xd: xf + 2.5, r: model.bullet.rExposed });
      }
      // keep dimension lines 2.2 apart
      const sorted = diaItems.filter((d) => d.id !== 'R1').sort((a, b) => a.xd - b.xd);
      for (let i = 1; i < sorted.length; i++) sorted[i].xd = Math.max(sorted[i].xd, sorted[i - 1].xd + 2.2);

      const radiusOf = (it) => it.r !== undefined ? it.r : it.v / 2;
      const top = -(rTop + 3);
      for (const it of diaItems) {
        const r = radiusOf(it);
        const d = { id: it.id, kind: 'diameter', symbol: F.symbolFor(it.field), lines: [], arrows: [] };
        const dir = it.xd >= it.xf ? 1 : -1;
        const xe = it.xd + dir * 1;
        d.lines.push(line('ext', it.xf + dir * GAP, -r, xe, -r));
        d.lines.push(line('ext', it.xf + dir * GAP, r, xe, r));
        d.lines.push(line('dim', it.xd, -r, it.xd, r));
        d.arrows.push(makeArrow(it.xd, -r, 0, 1, 2 * r), makeArrow(it.xd, r, 0, -1, 2 * r));
        d.text = d.symbol + ' ' + fmt(it.field, it.v);
        d.anchorPoint = { x: it.xd, y: -r };
        dims.push(d);
      }

      // ---- shoulder angle callout ----------------------------------------------------
      if (model.isBottleneck && F.isValue(jc.alpha)) {
        const A = model.corners.shoulderStart, B = model.corners.shoulderEnd;
        const mx = (A.z + B.z) / 2, my = -(A.r + B.r) / 2;
        const d = { id: 'alpha', kind: 'angle', symbol: 'α', lines: [], arrows: [] };
        d.text = 'α ' + F.formatAngle(jc.alpha);
        d.anchorPoint = { x: mx, y: my };
        d.arrows.push(makeArrow(mx, my, 0, 1, 10));
        dims.push(d);
      }

      // ---- labels above ---------------------------------------------------------------------
      const upper = dims.filter((d) => d.anchorPoint);
      const fixedLines = dims.flatMap((d) => d.lines);
      const best = placeUpperLabels(upper, outline.concat(fixedLines), lengthBoxes, top);
      upper.forEach((d, i) => {
        const p = best[i];
        d.lines.push(line('leader', d.anchorPoint.x, d.anchorPoint.y, d.anchorPoint.x, p.y));
        d.label = { text: d.text, x: p.x, y: p.y, anchor: p.anchor, box: p.box };
        delete d.anchorPoint;
      });
      for (const d of dims) delete d.text;
    }

    // ---- frame, title block, view box --------------------------------------------------
    let minX = Infinity, maxX = -Infinity, minY = Infinity, maxY = -Infinity;
    const extend = (x, y) => { minX = Math.min(minX, x); maxX = Math.max(maxX, x); minY = Math.min(minY, y); maxY = Math.max(maxY, y); };
    for (const sg of outline) { extend(sg.x1, sg.y1); extend(sg.x2, sg.y2); }
    for (const d of dims) {
      for (const l of d.lines) { extend(l.x1, l.y1); extend(l.x2, l.y2); }
      extend(d.label.box.x0, d.label.box.y0); extend(d.label.box.x1, d.label.box.y1);
    }
    if (!isFinite(minX)) { minX = 0; maxX = 40; minY = -10; maxY = 10; }
    const contentW = maxX - minX, contentH = maxY - minY;
    const frameH = contentH + 2 * MARGIN + TITLE_H;
    const frameW = Math.max(contentW + 2 * MARGIN, MIN_W, (frameH + 1) / MAX_ASPECT - 1);
    const cx = (minX + maxX) / 2;
    const frame = { x: cx - frameW / 2, y: minY - MARGIN, w: frameW, h: frameH };
    const viewBox = { x: frame.x - 0.5, y: frame.y - 0.5, w: frame.w + 1, h: frame.h + 1 };
    const scale = PRINT_WIDTH / viewBox.w;
    const scaleText = 'Scale ' + (Math.round(scale * 100) / 100).toFixed(2) + ' : 1 (A4 print)';

    const tb = { x: frame.x, y: frame.y + frame.h - TITLE_H, w: frame.w, h: TITLE_H };
    const col1 = tb.x + 2, col2 = tb.x + tb.w / 2 + 2;
    tb.lines = [
      { text: record.name, x: col1, y: tb.y + 4.6, size: 3.6, weight: 'bold' },
      { text: 'C.I.P. table ' + record.tab, x: col1, y: tb.y + 8.0, size: 2.6 },
      { text: 'Revised ' + record.revised, x: col1, y: tb.y + 11.2, size: 2.6 },
      { text: 'Dimensions in mm', x: col2, y: tb.y + 4.6, size: 2.6 },
      { text: scaleText, x: col2, y: tb.y + 8.0, size: 2.6 },
    ];

    return {
      fontSize: FS, dims, outline, frame, viewBox, titleBlock: tb, scale, scaleText,
      centreLine: { x1: Math.min(-2, minX), x2: maxX, y: 0 },
    };
  }

  const api = { layoutDimensions, outlineSegments, labelBox, textWidth, FS, PAD };
  root.CIP = root.CIP || {};
  root.CIP.layout = api;
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
})(typeof window !== 'undefined' ? window : globalThis);
