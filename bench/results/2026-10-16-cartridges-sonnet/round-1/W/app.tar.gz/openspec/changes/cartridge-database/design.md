# Design

## Context

Greenfield: the repo holds only project setup (CLAUDE.md, OpenSpec, docs). Motivation and scope are in `proposal.md`; behaviour is in `specs/`. Hard constraints: plain HTML/CSS/JS, no build, no runtime dependencies, no network, must work from `file://` in Chromium, Node 22 for tooling. The 25 records are fixed input.

`file://` rules out ES modules (`<script type="module">` is blocked by CORS on `file://` in Chromium), `fetch`/XHR of local JSON, and path-based routing. Everything below follows from that.

## Goals / Non-Goals

**Goals:**
- Pure, unit-testable core (formatting, search, geometry, label layout) separated from DOM code.
- Drawing computed only from the record; every number traceable to a rule in the brief.
- Verified in a real Chromium (file://, print to A4 PDF, dark mode, 360 px).

**Non-Goals:**
- Editing data, unit conversion, comparing cartridges, ballistics, service worker/offline manifest, i18n.
- Drawing the extractor groove for rimmed/rimfire cases when E/E1 are absent (rule 3 says step).
- Pixel-exact match with OpenBallistics' own drawings.

## Decisions

### D1. File layout and module style
```
index.html
css/app.css                 screen + @media print (one file)
js/format.js  js/catalogue.js  js/geometry.js  js/layout.js  js/drawing.js  js/app.js
data/cartridges.jsonl       the 25 records verbatim (source of truth, one per line)
data/cartridges.js          `window.CIP_DATA = [...]`, generated from the jsonl by `npm run data`, committed
scripts/make-data.mjs       dev tool: jsonl -> js
test/*.test.mjs  test/e2e/*.mjs  package.json (dev deps only)
```
Each `js/*.js` is a classic script wrapped in an IIFE that attaches to a single global `CIP` namespace and also does `if (typeof module !== 'undefined') module.exports = CIP.x` so Node tests `require` the same file the browser loads. *Alternative:* ES modules — rejected (`file://`). *Alternative:* one big file — rejected (untestable, unreadable).

The data ships as a committed `.js` generated from the verbatim `.jsonl`; a test asserts they are in sync, so "records as given" is enforced and there is still no build step for the app.

### D2. Routing: hash, key-based
`#/` → list, `#/cartridge/<key>` → detail (`key` from the record, e.g. `223_rem`). `hashchange` re-renders. Works on `file://`, survives reload, bookmarkable, back/forward free. *Alternative:* History API paths — breaks on `file://`.

The list view stays in the DOM (hidden with the `hidden` attribute) while a detail view shows, so search text and family are preserved on back. The detail view is rebuilt per navigation. On navigation: set `document.title`, focus the view heading (`tabindex="-1"`), scroll to top. All DOM is built with `createElement`/`textContent` (never `innerHTML` with record data); SVG with `createElementNS`.

### D3. Search and filter
`normalise(s)`: NFC-lowercase, `,`→`.`, collapse whitespace, trim. A record matches when the normalised query is a substring of the normalised name or of any alternative name. Family select is exact match on `family`. Count text is always `"<n> cartridges"` (literal, also for 1) as the brief gives it; `aria-live="polite"`.

### D4. Formatting
- Number → `String(n)` (JSON already yields the shortest decimal, `4300.0` → `4300`, matching "as published"). Never `toFixed`, never `toLocaleString`.
- Angle: number → `${n}°`; `{degrees,minutes,seconds}` → `${d}°${m}'${s}"`. Angle fields: alpha, alpha1, beta, delta, i. Unit cell for angles shows `deg`.
- Units: Pmax/PK/PE bar; EE J; M g; Q mm²; N none; every other numeric field mm. **Assumption:** the brief says lengths and diameters are mm and lists the "other units"; remaining fields (Fe, deltaL, S, G, h, s, u, b, F, Z …) are lengths, so mm. Documented in README.
- Tolerance: field `XTol` is folded into row X as `"<value> <tol>"` (tol as published, `+` prefixed only if positive). A stray `XTol` without `X` would get no row (none exist; tested for all 25).
- Symbols: field name with the brief's override map.
- Row order within a section: a fixed preferred order per section (e.g. case head `R1, R, E1, E, e min, f, β, δ, R3`; lengths `L1, L2, L3, L4, L5, L6`), unknown fields appended in record order. Section titles: caseHead "Case head", collar "Collar", junctionCone "Junction cone", lengths "Lengths", misc "Miscellaneous", powderChamber "Powder chamber", pressures "Pressures", projectile "Projectile", barrel "Barrel", breech "Breech", grooves "Grooves", rifling "Rifling". Sections with no values are skipped.

### D5. Drawing pipeline: record → model → layout → SVG
Three stages, only the last touches the DOM:

1. `geometry.js` `buildModel(record)` returns plain data: `rimType`, `outer` (half-profile, points `{r, z}` plus arc segments for fillets/half-round), `inner`, `head` (w, pocket), `bullet` (seated and exposed polylines, cylinder end, meplat, ρ), `features` (named anchor points for dimensions), `notes` (omitted features with missing values). Coordinates follow the brief: pairs are `(r, z)`; SVG maps `x = z`, `y = −r` (upper) / `+r` (lower).
2. `layout.js` `layoutDimensions(model)` returns dimension primitives (extension lines, dimension line with arrow ends, label text and anchor) with collision-free label boxes, the viewBox, title block rect.
3. `drawing.js` `renderSvg(record)` assembles the `<svg>` (defs: hatch pattern, arrow markers; groups: bullet, section hatch, outline, centre line, dimensions, title block) with `createElementNS`.

Arcs (fillets, ogive, ellipse, half-round) are flattened to polylines at fixed angular steps (about 0.5° chord error is far below a pixel at 1 unit = 1 mm) so the same geometry feeds drawing, hatch clipping, and collision tests with one representation.

**Rules interpretation, where the brief is silent:**
- *Body start*: the last point of the head/groove (`(P1/2, E)` with groove, `(P1/2, R)` without).
- *Chamfer*: from `(R1/2 − c, z=0)` to `(R1/2, z=f)`, `c = min(f·tanβ, R1/4)`. The head face from the axis to `R1/2 − c` is a straight line.
- *Rimfire half-round*: semicircle of radius ρ whose axis is on `z = R/2`; the rim edge is flat at `r = R1/2 − ρ` for `z ∈ [0, R/2−ρ]` and `[R/2+ρ, R]`, with the arc between.
- *Belted ramp*: from the floor end, `dr/dz = tan δ` until `r = R3/2` (belt), then horizontal to `z = E`, then step in to `P1/2`. If the ramp would end beyond `E` the belt feature is dropped and noted.
- *w*: for a belted case the belt-ramp end replaces `E` in the `E + tb` term. The cavity floor at `z = w` is vertical.
- *Straight case wall*: `tb` at the body start, linear to `tn` at the mouth, so the bullet (diameter G1) always fits the bore at the mouth. Heeled case: constant `tb` (tn is 0). Bottleneck: `tb` body, linear blend `tb→tn` across the shoulder from `L1` to `L2`, `tn` neck.
- *Fillets*: tangent arc of radius `r` at a corner of turn angle θ needs tangent length `t = r·tan(θ/2)`; `t` is limited to half of the shorter adjacent straight segment. When limited, the radius used is reduced and the note says so (no invented numbers; only less than published).
- *Bullet exposed vs seated*: outside view draws the exposed part only (from the mouth); section draws seated plus exposed, with a solid light fill (no hatch, hatch means cut case metal).
- *Bullet nose geometry*: pointy tangent ogive centre at `r = G1/2 − ρ` on the radial line where the nose starts; flat tip of diameter m; rounded quarter ellipse with semi-axes `(n, G1/2 − m/2)` ending at the meplat edge; flat and semi_wadcutter straight cones.
- *Missing-value notes*: reported only for features the record's type makes applicable: groove (rimless, rebated, belted without E/E1/e min), chamfer (non-rimfire without beta/f), bottleneck when only some of alpha, L1, L2 are published, shoulder fillets (r1 min, r2), belt (R3, δ, e min), bullet (G1, L6, L3, shape), walls (H2, G1, P1), pocket (primer type). A straight case without alpha/L1/L2 and a rimmed case without a groove are normal, not notes.

### D6. Dimensions and label layout
All text is 2.8 user units; strokes 0.18 (outline 0.3). Text width is estimated as `0.6 × fontSize × chars` (conservative for a sans-serif system font); the e2e test checks real `getBBox()` against the estimate.

- **Lengths** (R, L1, L2, L3, L6), below the drawing: horizontal dimension lines from `z = 0`, one row each, ordered by value so the extension lines of deeper rows (larger z) never cross shallower rows' lines, `5.5` units apart. Extension lines drop from the feature point (with 0.8 gap) to 1.2 past their row. Label centred above its line. A dimension shorter than 4.5 (R) has its arrowheads outside the extension lines on 2.6-long tails, and its label to the right of the tail.
- **Diameters** (R1, E1, P1, P2, H1, H2, G1), above: vertical dimension line across the full diameter at `x_d = feature z + 2.5`, with horizontal extension lines from the upper and lower outline points. `R1` is placed left of the head instead (extension lines in clear space). Spacing between neighbouring `x_d` is at least 2.2 (pushed right). Each label sits in a row above the profile: the dimension line continues up as a leader to the label baseline and the label begins just right of the leader.
- **α**: a leader with an arrowhead on the shoulder line midpoint to a label `α <value>`. The cone apex lies inside the neck/bullet where an arc would collide with the H1/H2/G1 lines, so a callout is used instead of an arc. The shoulder line itself is drawn through the published points.
- **Label placement**: diameter and α labels sit in rows above the drawing at the end of a leader that rises from their dimension line. Each label goes right of its leader (`start`) or left of it (`end`); all 2^n left/right choices are tried in two orders (right to left, left to right) and the arrangement with the fewest rows wins. A candidate is accepted when its box (padded 0.4) misses every outline and dimension segment and every placed label, and its own leader misses the placed labels (Liang–Barsky segment–rectangle test). Length labels try: centred above the line, right of the tail, centred below. The viewBox is the bounding box of everything plus a margin, so a label can never be clipped.
- **Title block**: bottom strip of the frame: name | `C.I.P. table <tab>` and `Revised <date>` | `Dimensions in mm` and `Scale n : 1 (A4 print)` with `n = 190 / viewBoxWidth` (2 decimals).
- **Label text** is `"<symbol> <value>"` with the same formatters as the tables (`α 40°`); tolerances are not repeated in drawing labels.

The drawing is at most 0.6 as tall as it is wide (the frame is widened with empty space when needed) so that drawing, facts and tables fit one A4 page at full width; the check is a PDF page count over all 25.

### D7. Responsive and print
SVG gets `viewBox`, no width/height attributes, CSS `width:100%; height:auto; max-width:60rem`. Font and stroke are in user units, so proportions hold. Print CSS: `@page { size: A4; margin: 10mm }`; the drawing is `width:190mm`; tables flow in `column-count: 3` (each section table `break-inside: avoid`) so cartridge and chamber values plus facts fit on one page; list view, buttons, links and the header nav are `display:none`; colours forced to black on white by resetting the CSS custom properties inside `@media print`. A footer element, print-only, holds `Source: C.I.P. TDCC, revised <date>`. "Print" calls `window.print()`.

### D8. Look and feel
System font stack, `font-variant-numeric: tabular-nums` for numbers, 14–15 px base, tight line-height, thin rules instead of boxes, one accent colour. `color-scheme: light dark` and CSS custom properties switched with `prefers-color-scheme`; the SVG uses the same properties (stroke `var(--ink)`, hatch `var(--ink-soft)`), so dark mode needs no second drawing.

### D9. Testing strategy (tests before code, per task group)
- **Unit, `node --test`** (no dependencies): format, catalogue, geometry (hand-computed expected values from the brief for 308 Win., 300 Win. Mag., 22 LR, 9 mm Luger, 9,3 x 74 R, 357 Magnum, 17 HMR), layout invariants for all 25 (labels non-overlapping, inside viewBox, required labels present, notes), data integrity, static-delivery lint (no `import`/`export`, no `http` URLs in app code, no `type="module"`).
- **End-to-end, Playwright + Chromium** (dev dependency): open `file://…/index.html`; list, search, family, count, navigation, reload at a detail address, tables, accessible name, no external requests, 360 px no horizontal scroll, dark mode screenshot, `page.pdf({format:'A4'})` page count = 1 for all 25 (PDF page count by `/Type /Page` objects), print text assertions via `emulateMedia({media:'print'})`, real `getBBox` label overlap check, and a served-over-HTTP smoke run with a tiny Node static server in the test.
- Screenshots of several cartridges are looked at by eye during verification.

## Risks / Trade-offs

- **Chromium in the container** → Outcome of task 1.3: `npx playwright install chromium` downloads the headless shell, but it needs system libraries (nss, glib, X11, …) and fonts that are absent and there is no root. Solved without root by fetching the Debian `.deb` files with a private apt state dir (`apt-get -o Dir::State=… download`), extracting them to `/tmp/libs` and `/tmp/fonts`, and running with `LD_LIBRARY_PATH` and a minimal `FONTCONFIG_FILE`. Browser checks (file://, print PDF, dark mode, 360 px) therefore do run here; this setup is environment-only and not part of the repo.
- **Estimated text width vs real fonts** → conservative factor 0.6; e2e `getBBox` check catches under-estimates; a fallback margin of 0.5 around label boxes.
- **One-page print may overflow for long records** → three-column table flow and a measured test over all 25; if one overflows, shrink print table font before touching content.
- **Dense dimension lines crowd near the mouth** (H1, H2, G1 within 2–5 mm) → forced 2.2 spacing, label rows; accepted visual density.
- **Interpretation gaps in the geometry rules** (straight case wall, w for belted, ρ for flat ogive, α depiction) → each decision recorded above and visible in tests; none introduce numbers not derived from the record.
- **Hand-copied data** → integrity test (25 lines, valid JSON, distinct keys, sync with `.js`), plus spot checks of values against the brief text.
