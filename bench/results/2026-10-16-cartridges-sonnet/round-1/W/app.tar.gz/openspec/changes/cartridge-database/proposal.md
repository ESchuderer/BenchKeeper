# Proposal

## Why

Reloaders, gunsmiths and engineers need a quick, trustworthy reference for C.I.P. cartridge and chamber dimensions. The OpenBallistics cartridge database is the model, but a reference that works offline, from a plain file, with a dimensioned true-scale drawing and a clean A4 printout, does not exist for the 25 records we hold. The data is fixed (OpenBallistics commit e83db43); the work is presenting it faithfully.

## What Changes

- New static web app: `index.html` plus CSS and JavaScript files in the project root. No framework, no build step, no runtime dependencies, no network requests.
- Start page: searchable, family-filterable list of the 25 cartridges with name, family and case length L3.
- Detail view per cartridge, each with its own bookmarkable address that survives reload: header facts, a computed 2D drawing, and cartridge and chamber value tables with Symbol / Value / Unit columns and tolerances shown beside their values.
- Computed inline SVG drawing, true to scale (1 unit = 1 mm), upper half outside view, lower half hatched section, dimension lines, title block. Built from the record by the geometry rules in the brief; missing values drop the feature and are reported, never invented.
- Print layout: one A4 portrait page per detail view, black on white, with header, full-width drawing, tables and source footer.
- Light/dark on screen following the system setting; phone-usable.
- Dev tooling only: Node 22 test runner and a headless browser for end-to-end and print checks (npm dev dependencies; the app never needs them).

## Capabilities

### New Capabilities

- `cartridge-browser`: start page list, search, family filter, count, and the addressable navigation between list and detail views.
- `cartridge-detail`: detail view content: header facts, value formatting rules (units, angles, tolerances, symbols), grouped cartridge and chamber tables.
- `cartridge-drawing`: the computed true-scale SVG: profile geometry, bullet, section walls, dimension lines and labels, title block, missing-value reporting, responsive scaling.
- `cartridge-print`: print layout of the detail view and the screen look-and-feel constraints (light/dark, phone use).
- `static-delivery`: the app works opened from disk (`file://`) and from any static server, with no network requests and no runtime dependencies; the data ships as given.

### Modified Capabilities

None. `openspec/specs/` is empty.

## Impact

- New files in the project root: `index.html`, `css/`, `js/`, `data/`, tests under `test/`, `package.json` (dev dependencies only), a short `README.md`.
- No existing code is affected (the repo holds only project setup).
- Dev dependencies: a headless Chromium driver for end-to-end checks, if it can be installed in this container.
