# Spec Delta

## Purpose

The start page of the cartridge reference: a compact list of all 25 cartridges that can be searched and filtered, and the addressable navigation between that list and each cartridge's detail view.

## ADDED Requirements

### Requirement: Start page lists every cartridge
The start page SHALL show a heading "Cartridges" and, for every cartridge record, its name, its family and its case length L3 in mm. Each name SHALL be a link whose text is exactly the record's `name` as published, and the link SHALL open that cartridge's detail view.

#### Scenario: All 25 records are listed on first load
- **WHEN** the user opens the app with no address fragment
- **THEN** a heading "Cartridges" is visible
- **AND** 25 rows are listed, each with a name link, a family and an L3 value
- **AND** the text "25 cartridges" is shown

#### Scenario: Names are shown as published
- **WHEN** the list is shown
- **THEN** a link with the exact text "6,5 Creedmoor" exists
- **AND** a link with the exact text "40 S.& W." exists

#### Scenario: A name link opens the detail view
- **WHEN** the user activates the link "308 Win."
- **THEN** the detail view of "308 Win." is shown

### Requirement: Search by name and alternative names
The start page SHALL have a text field labelled "Search" that filters the list as the user types. A cartridge SHALL be listed when the typed text occurs in its name or in any of its alternative names, ignoring letter case and surrounding or repeated whitespace, and treating a decimal comma and a decimal point as the same character.

#### Scenario: Alternative name finds the cartridge
- **WHEN** the user types "7,62 x 51" into "Search"
- **THEN** the list contains "308 Win."

#### Scenario: Case is ignored
- **WHEN** the user types "creedmoor" into "Search"
- **THEN** the list contains "6,5 Creedmoor" and nothing else

#### Scenario: Decimal point finds a decimal comma
- **WHEN** the user types "6.5" into "Search"
- **THEN** the list contains "6,5 Creedmoor" and "6,5 x 55 SE"

#### Scenario: Filtering happens while typing
- **WHEN** the user types one character at a time
- **THEN** the list and the count update after each character without pressing a button

#### Scenario: Nothing matches
- **WHEN** the typed text matches no cartridge
- **THEN** the list is empty, the text "0 cartridges" is shown, and a message says that no cartridge matches

### Requirement: Filter by family
The start page SHALL have a select labelled "Family" with the options All, rimless, rimmed, belted, pistol and rimfire, in that order, defaulting to All. Choosing a family SHALL list only cartridges whose `family` equals it, combined with the search text.

#### Scenario: Family restricts the list
- **WHEN** the user chooses "belted" in "Family"
- **THEN** exactly "300 Win. Mag." and "7 mm Rem. Mag." are listed

#### Scenario: Family and search combine
- **WHEN** the user chooses "rimfire" in "Family" and types "22" into "Search"
- **THEN** exactly "22 Long Rifle" and "22 Win. Mag. R.F." are listed

#### Scenario: All restores the list
- **WHEN** the user chooses "All" with an empty search field
- **THEN** 25 cartridges are listed

### Requirement: Count of listed cartridges
The start page SHALL show the text "<n> cartridges", where n is the number of cartridges currently listed, and SHALL announce changes to assistive technology.

#### Scenario: Count follows the filter
- **WHEN** the user chooses "pistol" in "Family"
- **THEN** the text "6 cartridges" is shown

### Requirement: Each detail view has its own address
Every detail view SHALL have its own address of the form `index.html#/cartridge/<key>` that can be bookmarked and reloaded, and the start page SHALL be at `index.html` with an empty or `#/` fragment. Browser back and forward SHALL move between views.

#### Scenario: Address survives reload
- **WHEN** the user opens `index.html#/cartridge/223_rem` directly or reloads that page
- **THEN** the detail view of "223 Rem." is shown

#### Scenario: Unknown address
- **WHEN** the user opens `index.html#/cartridge/does_not_exist`
- **THEN** a message "Cartridge not found" and a link "All cartridges" are shown, and no drawing

#### Scenario: Back returns to the list
- **WHEN** the user opens a detail view from the list and then goes back
- **THEN** the start page is shown with the search text and family that were set before

### Requirement: Keyboard and assistive technology navigation
After navigating between views the page SHALL move keyboard focus to the new view's heading and set the document title to the cartridge name, or to "Cartridges" on the start page. All controls SHALL be reachable and operable with the keyboard.

#### Scenario: Title follows the view
- **WHEN** the detail view of "9 mm Luger" is shown
- **THEN** the document title contains "9 mm Luger"
