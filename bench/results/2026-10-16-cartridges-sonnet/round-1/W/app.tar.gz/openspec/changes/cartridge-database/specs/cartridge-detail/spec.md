# Spec Delta

## Purpose

The detail view of one cartridge: its identifying facts, the drawing, and every cartridge and chamber value in grouped tables, formatted exactly as published with symbols, units and tolerances.

## ADDED Requirements

### Requirement: Detail heading and identifying facts
The detail view SHALL have a heading whose text is the cartridge's name as published, followed by these facts, each with a visible label: alternative names, family, category, primer type, C.I.P. table, country, published date, revised date, pressure method and water capacity. A fact the record does not have SHALL be shown as "—", except water capacity, which SHALL read "not published".

#### Scenario: Facts of a record with alternative names
- **WHEN** the detail view of "308 Win." is shown
- **THEN** the heading reads "308 Win."
- **AND** alternative names read "308 Winchester, 7,62 x 51"
- **AND** family reads "rimless", category "rifle", primer type "lr", C.I.P. table "I", country "US"
- **AND** published reads "1984-06-14", revised "2008-09-23", pressure method "Transducer"

#### Scenario: Record without alternative names
- **WHEN** the detail view of "223 Rem." is shown
- **THEN** alternative names read "—"

#### Scenario: Record without water capacity
- **WHEN** the detail view of "7 x 64" is shown
- **THEN** water capacity reads "not published"

### Requirement: Water capacity with source link
When a record has a published capacity, the detail view SHALL show its value in `gr H2O`, the capacity's note when one exists, and a link to the source whose text is the source's name and whose target is the published URL.

#### Scenario: Capacity and source
- **WHEN** the detail view of "223 Rem." is shown
- **THEN** the water capacity reads "30.5 gr H2O" with the note "kwk 31, Wikipedia 28.8; the mean"
- **AND** a link "kwk" points to `http://kwk.us/cases.html`

### Requirement: Values are shown as published
Numbers SHALL be shown with a decimal point, no thousands separator and no padding or rounding beyond the record's own digits, followed by the unit in a separate column: lengths and diameters in mm; Pmax, PK and PE in bar; EE in J; M in g; Q in mm²; N without unit; angles in degrees. Names, including a decimal comma, SHALL be shown as published.

#### Scenario: Plain numbers
- **WHEN** the cartridge values of "308 Win." are shown
- **THEN** L3 reads "51.18" with unit "mm" and Pmax reads "4150" with unit "bar"

#### Scenario: Count without unit
- **WHEN** the chamber values of "223 Rem." are shown
- **THEN** N reads "6" with an empty unit

### Requirement: Angles in degrees
An angle given as a number of degrees SHALL be shown as that number followed by "°". An angle given as degrees, minutes and seconds SHALL be shown as degrees, minutes and seconds in the form `39°59'49"`, keeping zero parts. The fields alpha, alpha1, beta, delta and i are angles.

#### Scenario: Whole degrees
- **WHEN** alpha of "308 Win." is shown
- **THEN** it reads "40°"

#### Scenario: Degrees, minutes and seconds
- **WHEN** alpha of "6,5 x 55 SE" is shown
- **THEN** it reads `50°35'2"`

#### Scenario: Zero parts are kept
- **WHEN** the chamber alpha of "30-06 Spring." is shown
- **THEN** it reads `34°30'0"`
- **AND** the chamber i of "270 Win." reads `0°47'33"`

#### Scenario: Angle given as a bare number
- **WHEN** the chamber i of "7 mm Rem. Mag." is shown
- **THEN** it reads "3°"

### Requirement: Tolerances sit beside their value
A field named `<X>Tol` SHALL be shown in the Value cell of the row of X, after the value of X, separated by a space, and SHALL NOT have a row of its own.

#### Scenario: Length tolerance
- **WHEN** the cartridge values of "308 Win." are shown
- **THEN** the Value cell of L1 reads "39.62 -0.2"
- **AND** no row has the symbol "L1Tol"

#### Scenario: Rim tolerance
- **WHEN** the cartridge values of "22 Long Rifle" are shown
- **THEN** the Value cell of R reads "1.09 -0.18"

### Requirement: Symbols
Each row SHALL be labelled with the field name as its symbol, except: eMin "e min", r1Min "r1 min", r1Max "r1 max", alpha "α", alpha1 "α1", beta "β", delta "δ", deltaL "delta L", L3PlusG "L3 + G".

#### Scenario: Renamed symbols
- **WHEN** the cartridge values of "223 Rem." are shown
- **THEN** rows with the symbols "e min", "r1 min", "α", "β", "δ", "delta L" and "L3 + G" exist
- **AND** no row has the symbol "eMin" or "alpha"

#### Scenario: Chamber symbols
- **WHEN** the chamber values of "223 Rem." are shown
- **THEN** rows with the symbols "r1 max" and "α1" exist

### Requirement: Tables grouped by section
All cartridge values and all chamber values SHALL be shown in separate groups headed "Cartridge" and "Chamber", each divided into one table per section present in the record, with a visible section title and the columns "Symbol", "Value" and "Unit". A section without values SHALL NOT be shown. Every value of the record, other than tolerances, SHALL appear exactly once.

#### Scenario: Sections of a bottleneck rifle cartridge
- **WHEN** the detail view of "223 Rem." is shown
- **THEN** the cartridge group has tables titled "Case head", "Collar", "Junction cone", "Lengths", "Miscellaneous", "Powder chamber", "Pressures" and "Projectile"
- **AND** the chamber group has tables titled "Barrel", "Breech", "Collar", "Grooves", "Junction cone", "Lengths", "Powder chamber" and "Rifling"
- **AND** every table has the column headers "Symbol", "Value" and "Unit"

#### Scenario: Empty section is not shown
- **WHEN** the detail view of "9 mm Luger" is shown
- **THEN** no table titled "Junction cone" exists

#### Scenario: Completeness
- **WHEN** any detail view is shown
- **THEN** the number of value rows equals the number of numeric fields in the record's `cartridge` and `chamber` objects, not counting tolerance fields

### Requirement: Actions on the detail view
The detail view SHALL have a button "Print" that opens the browser's print dialog, and a link "All cartridges" that returns to the start page.

#### Scenario: Print button
- **WHEN** the user presses "Print"
- **THEN** the browser's print dialog is requested

#### Scenario: Back link
- **WHEN** the user activates "All cartridges"
- **THEN** the start page is shown
