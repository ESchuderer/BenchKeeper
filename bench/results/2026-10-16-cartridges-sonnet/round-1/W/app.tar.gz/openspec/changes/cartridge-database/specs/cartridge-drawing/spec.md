# Spec Delta

## Purpose

A true-scale 2D drawing of each cartridge, computed from its record: outside view above the axis, section below, seated bullet, dimension lines and title block. It lets an engineer read the shape and key dimensions without leaving the page.

## ADDED Requirements

### Requirement: Drawing is an inline SVG with an accessible name
The detail view SHALL contain exactly one inline SVG drawing with `role="img"` whose accessible name is "<name> drawing", where <name> is the cartridge's name as published. The drawing SHALL be computed in the browser from the record only.

#### Scenario: Accessible name
- **WHEN** the detail view of "6,5 Creedmoor" is shown
- **THEN** an image named "6,5 Creedmoor drawing" exists and is an inline `svg` element

### Requirement: True scale in millimetres
The SVG's user units SHALL be millimetres: one user unit is 1 mm of the cartridge. The axis SHALL be horizontal with the head face on the left (z = 0) and the mouth and bullet to the right; z increases to the right and the radius r is drawn perpendicular to the axis, mirrored about it.

#### Scenario: Case length is true to scale
- **WHEN** the drawing of "308 Win." is shown
- **THEN** the distance in user units between the head face and the mouth face equals 51.18
- **AND** the distance between the head face and the bullet tip equals 71.12

#### Scenario: Diameter is true to scale
- **WHEN** the drawing of "308 Win." is shown
- **THEN** the outline at the start of the body is 11.96 units tall, measured across both halves

### Requirement: Outside view above, section below
The upper half SHALL show the outside view of the case and the exposed bullet. The lower half SHALL show a section: cut walls and the solid head hatched, the cavity empty, the seated bullet inside the case. A dash-dot centre line SHALL run along the axis over the full length of the drawing.

#### Scenario: Hatching only on cut material
- **WHEN** the drawing of "308 Win." is shown
- **THEN** hatched areas exist only in the lower half
- **AND** they cover the case wall and the solid head, and not the cavity or the bullet
- **AND** a centre line with a dash-dot stroke pattern lies on the axis

### Requirement: Rim type
The drawing SHALL classify the rim: family `belted` is belted; family `rimfire` is rimfire; otherwise R1/P1 ≥ 1.05 is rimmed, R1/P1 < 0.98 is rebated and anything else is rimless.

#### Scenario: Classification of the records
- **WHEN** rim types are computed
- **THEN** "308 Win." is rimless, "9,3 x 74 R" is rimmed, "300 Win. Mag." is belted, "22 Long Rifle" is rimfire and "45 Auto" is rimless

### Requirement: Head face and rim edge
Where beta and f are published and beta < 90°, the head face SHALL end in a chamfer from radius R1/2 − min(f·tan β, R1/4) at z = 0 to radius R1/2 at z = f, followed by the rim edge up to z = R. A rimfire rim edge SHALL be a half-round of radius min(R/2, (R1 − P1)/2) whose outermost point lies at radius R1/2. Otherwise the corner SHALL be square.

#### Scenario: Chamfer of 308 Win.
- **WHEN** the drawing of "308 Win." is shown
- **THEN** the outline passes through radius 5.739 at z = 0, radius 6.005 at z = 0.38 and radius 6.005 at z = 1.37 (± 0.005)

#### Scenario: Half-round of 22 Long Rifle
- **WHEN** the drawing of "22 Long Rifle" is shown
- **THEN** the rim edge is a half-round of radius 0.545 whose outermost point lies at radius 3.53

#### Scenario: Square corner without chamfer values
- **WHEN** the drawing of a non-rimfire record without f is shown
- **THEN** the head face runs straight up to radius R1/2 with a square corner

### Requirement: Extractor groove, belt and step
Where E and E1 are published the outline SHALL go from (R1/2, R) in to E1/2 at z = R, along the floor to z = R + e min, then in a straight ramp out to radius P1/2 at z = E. On a belted case the ramp from the floor end rises at angle δ to the axis up to radius R3/2, follows the belt to z = E, then steps in to P1/2. Without a groove the outline SHALL step in from R1/2 to P1/2 at z = R.

#### Scenario: Groove of 308 Win.
- **WHEN** the drawing of "308 Win." is shown
- **THEN** the outline passes through radius 5.195 at z = 1.37, radius 5.195 at z = 2.77 and radius 5.98 at z = 3.85

#### Scenario: Belt of 300 Win. Mag.
- **WHEN** the drawing of "300 Win. Mag." is shown
- **THEN** the outline follows radius 6.755 from the end of the 35° ramp to z = 5.59 and then steps in to radius 6.515

#### Scenario: Rimmed case without groove
- **WHEN** the drawing of "9,3 x 74 R" is shown
- **THEN** the outline steps in at z = 1.4 from radius 6.675 to radius 5.95

### Requirement: Body, shoulder and neck
The body SHALL run straight from radius P1/2 at the body start to (P2/2, L1) on a bottleneck case. The shoulder SHALL join (P2/2, L1) to (H1/2, L2) and the neck (H1/2, L2) to (H2/2, L3), then the mouth face. A case without alpha, L1 or L2 is straight and the body SHALL run to (H2/2, L3). The body-side shoulder corner SHALL be rounded with r1 min and the neck-side corner with r2 where published.

#### Scenario: Points of 308 Win.
- **WHEN** the drawing of "308 Win." is shown
- **THEN** the outline passes through radius 4.36 at z = 51.18
- **AND** the unrounded shoulder corners (radius 5.765 at z = 39.62 and radius 4.36 at z = 43.48) lie within 0.06 of the outline, the difference being the corner rounding

#### Scenario: Straight case
- **WHEN** the drawing of "9 mm Luger" is shown
- **THEN** the body runs from radius 4.965 at z = 2.98 to radius 4.825 at z = 19.15 without a shoulder

#### Scenario: Rounded corners
- **WHEN** the drawing of "223 Rem." is shown
- **THEN** the shoulder corners are replaced by tangent arcs of radius 0.64 at the body side and 2.54 at the neck side

### Requirement: Shoulder angle
The shoulder line SHALL be drawn through the published points (P2/2, L1) and (H1/2, L2), not recomputed from α. α is the included cone angle: the line lies at α/2 to the axis. The angle SHALL be labelled α with its value.

#### Scenario: Shoulder is not recomputed
- **WHEN** the drawing of "6,5 x 55 SE" is shown
- **THEN** the straight part of the shoulder lies on the line from radius 5.52 at z = 43.49 to radius 3.8 at z = 47.13
- **AND** the rounded corners lie within 0.1 of those end points

### Requirement: Bullet seating and shape
The bullet SHALL have shank diameter G1 and its tip at z = L6. Its seating depth s below the mouth SHALL be 1.0·G1 for a pointy nose, 0.8·G1 for rounded or flat on rifle and rimfire cartridges, 0.4·G1 for rounded or flat on pistol cartridges and 0.6·G1 for semi_wadcutter. The nose shape SHALL be the record's `annotations.defaultBulletShape`; the cartridge category SHALL be `annotations.category`. The base lies at z = L3 − s.

#### Scenario: Seating of 308 Win.
- **WHEN** the drawing of "308 Win." is shown
- **THEN** the bullet base lies at z = 43.33 and the tip at z = 71.12

#### Scenario: Seating of a pistol cartridge
- **WHEN** the drawing of "9 mm Luger" is shown
- **THEN** the bullet base lies at z = 15.54 (± 0.005)

### Requirement: Bullet cylinder length
With bullet length Lb = L6 − base, the cylinder SHALL run from the base to base + k·Lb, with k = 0.40 for pointy; 0.55 for rounded on rifle or rimfire; 0.65 for rounded on pistol; 0.60 for flat on rifle; 0.70 for flat on pistol; 0.78 for semi_wadcutter.

#### Scenario: Cylinder of 308 Win.
- **WHEN** the drawing of "308 Win." is shown
- **THEN** the cylinder ends at z = 54.446 (± 0.005)

#### Scenario: Semi-wadcutter cylinder
- **WHEN** the drawing of "357 Magnum" is shown
- **THEN** the cylinder ends at 78 % of the bullet length from the base

### Requirement: Bullet nose
The nose SHALL run from the end of the cylinder to the tip with a flat meplat of diameter m. Pointy: tangent ogive, m = max(0.08·G1, 1.27), arc radius ρ = ((G1/2 − m/2)² + n²) / (2·(G1/2 − m/2)) for nose length n, centre at r = G1/2 − ρ. Rounded: quarter ellipse, m = 0.15·G1. Flat: straight cone, m = 0.55·G1. Semi_wadcutter: straight cone, m = 0.6·G1.

#### Scenario: Pointy nose of 308 Win.
- **WHEN** the drawing of "308 Win." is shown
- **THEN** the tip meplat is 1.27 wide and the ogive arc radius is 43.9 (± 0.1)

#### Scenario: Semi-wadcutter nose
- **WHEN** the drawing of "357 Magnum" is shown
- **THEN** the tip meplat is 0.6·G1 = 5.472 wide

### Requirement: Heeled bullet
A case with H2 − G1 ≤ 0.015 SHALL be drawn with a heeled bullet: the exposed bullet has the case's outside diameter H2 and the seated heel has the case's inside diameter H2 − 2·tb. The outside view SHALL hide the seated part; the section SHALL show it inside the case.

#### Scenario: 22 Long Rifle heel
- **WHEN** the drawing of "22 Long Rifle" is shown
- **THEN** the seated heel has radius 2.26 and the exposed bullet radius 2.86

### Requirement: Section walls
The neck wall SHALL be tn = (H2 − G1)/2 and the body wall tb = min(max(1.3·tn, 0.6), 0.35·P1/2). The inner line SHALL follow the outer body, shoulder and neck at these walls: tb along the body, tn along the neck, blended linearly across the shoulder. A straight case blends from tb at the body start to tn at the mouth; a heeled case keeps tb.

#### Scenario: Walls of 308 Win.
- **WHEN** the drawing of "308 Win." is shown
- **THEN** the neck wall is 0.435 and the body wall 0.6

#### Scenario: Wall of a straight case
- **WHEN** the drawing of "9 mm Luger" is shown
- **THEN** the wall is 0.6 at the body start and 0.31 at the mouth

### Requirement: Solid head
The solid head SHALL run in the section from z = 0 to w = max(2.5, 0.25·P1/2, pocket depth + 1.5, E + tb where a groove exists, or the belt ramp end + tb on a belted case).

#### Scenario: Head of 308 Win.
- **WHEN** the drawing of "308 Win." is shown
- **THEN** the solid head ends at z = 4.8

### Requirement: Primer pocket
A centrefire case SHALL have a primer pocket in the section at the head face with diameter 4.45 for primer types sp, spm, sr and 5.33 for lp, lpm, lr, lrm, and depth 3.04 for sp, spm, sr, lp, lpm and 3.3 for lr, lrm. A rimfire case SHALL have no pocket.

#### Scenario: Pocket sizes
- **WHEN** the drawings of "223 Rem." and "45 Auto" are shown
- **THEN** the pocket of "223 Rem." is 4.45 wide and 3.04 deep
- **AND** the pocket of "45 Auto" is 5.33 wide and 3.04 deep

#### Scenario: Rimfire has no pocket
- **WHEN** the drawing of "22 Long Rifle" is shown
- **THEN** the section has no pocket

### Requirement: Dimension lines and labels
The drawing SHALL carry dimension lines with arrowheads for L3, L6, R1, R and P1, and, where published, P2, H1, H2, G1, L1, L2, E1 and the shoulder angle α. Each dimension SHALL have extension lines and a label of its symbol and value, such as "L3 51.18", "R1 12.01" or "α 40°". The values SHALL be those of the cartridge record.

#### Scenario: Labels of 308 Win.
- **WHEN** the drawing of "308 Win." is shown
- **THEN** it contains the labels "L3 51.18", "L6 71.12", "R1 12.01", "R 1.37", "P1 11.96", "P2 11.53", "H1 8.72", "H2 8.72", "G1 7.85", "L1 39.62", "L2 43.48", "E1 10.39" and "α 40°"

#### Scenario: Unpublished dimensions are left out
- **WHEN** the drawing of "9 mm Luger" is shown
- **THEN** it has no labels for P2, H1, L1, L2 or α

#### Scenario: Arrowheads and extension lines
- **WHEN** a drawing is shown
- **THEN** every dimension line has an arrowhead at each end and at least one extension line

### Requirement: Labels do not collide
No label's bounding box SHALL overlap another label, the case or bullet outline, the title block, or the drawing's border, and every label SHALL lie inside the drawing's viewBox.

#### Scenario: Every cartridge
- **WHEN** the drawing of each of the 25 cartridges is computed
- **THEN** no two labels overlap and no label overlaps an outline segment

### Requirement: Title block
The drawing SHALL contain a title block with the cartridge's name, its C.I.P. table, its revision date, the text "Dimensions in mm" and the scale. The scale SHALL be the print scale at the full A4 content width of 190 mm, written "Scale n : 1" with n = 190 / viewBox width rounded to two decimals.

#### Scenario: Title block of 308 Win.
- **WHEN** the drawing of "308 Win." is shown
- **THEN** its title block contains "308 Win.", "C.I.P. table I", "Revised 2008-09-23", "Dimensions in mm" and a text starting "Scale"

### Requirement: Scales to the screen
The SVG SHALL scale to the width of its container without a fixed pixel size, keeping its aspect ratio, so that on a 360 px wide screen the page has no horizontal scroll caused by the drawing. Strokes and text SHALL be sized in user units so that proportions are preserved at every size.

#### Scenario: Phone width
- **WHEN** a detail view is shown at a viewport 360 px wide
- **THEN** the drawing is no wider than the viewport and the page does not scroll horizontally

### Requirement: Missing values are reported, never invented
When a value that a feature needs is missing the drawing SHALL omit that feature, SHALL NOT use any substitute number, and SHALL list under the drawing, as plain text, each omitted feature with the missing values. A case that is not a bottleneck, and a rim that is not applicable to the feature, are not missing values.

#### Scenario: Missing fillet radii
- **WHEN** the drawing of "17 HMR" is shown
- **THEN** the shoulder corners are sharp
- **AND** a note names "r1 min" and "r2" as not published

#### Scenario: No note for a complete record
- **WHEN** the drawing of "223 Rem." is shown
- **THEN** no omitted-feature note is listed

#### Scenario: Missing bullet values
- **WHEN** a record lacks G1 or L6
- **THEN** the bullet is not drawn and the note names the missing value
