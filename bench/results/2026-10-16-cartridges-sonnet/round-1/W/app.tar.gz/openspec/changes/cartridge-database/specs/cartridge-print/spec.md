# Spec Delta

## Purpose

How the detail view looks on screen and on paper: a calm, dense technical reference in light and dark, usable on a phone, and a one-page A4 printout of every cartridge.

## ADDED Requirements

### Requirement: Print opens the print dialog
The "Print" button SHALL call the browser's print function for the current page. It SHALL NOT generate files or open other windows.

#### Scenario: Print is requested
- **WHEN** the user presses "Print" in the detail view
- **THEN** the page's print function is called once

### Requirement: Printed detail view is one A4 portrait page
A printed detail view SHALL fit on one A4 portrait page for every one of the 25 cartridges, with black text on a white background. The page SHALL contain, in order: a header with the cartridge name, the drawing at the full width of the page's content area, then the identifying facts and the value tables, and a footer.

#### Scenario: One page for every cartridge
- **WHEN** the detail view of each of the 25 cartridges is printed to A4 portrait
- **THEN** the output has exactly one page

#### Scenario: Content order and colours
- **WHEN** the detail view of "308 Win." is printed
- **THEN** the heading "308 Win." comes first, the drawing second and the tables after it
- **AND** the background is white and all text is black, even when the system setting is dark

### Requirement: Printed drawing is legible
In print the drawing SHALL span the full width of the content area and every label and title block text SHALL be at least 6 pt high on paper. Hatching, outlines and dimension lines SHALL be visible in black on white.

#### Scenario: Label size on paper
- **WHEN** the detail view of the cartridge with the widest drawing is printed
- **THEN** the smallest label text is at least 6 pt on the page

### Requirement: Print hides interface
A printed detail view SHALL NOT show navigation, the "All cartridges" link, the "Print" button, the search field, the family select or the list. It SHALL end with a footer reading "Source: C.I.P. TDCC, revised <revised date>".

#### Scenario: Footer
- **WHEN** the detail view of "308 Win." is printed
- **THEN** the footer reads "Source: C.I.P. TDCC, revised 2008-09-23"

#### Scenario: No interface
- **WHEN** a detail view is printed
- **THEN** no button, link text "All cartridges", search field or select is visible on the page

### Requirement: Light and dark on screen
On screen the app SHALL follow the system's colour scheme setting, with a calm light and a calm dark palette that both keep text contrast of at least 4.5:1 and drawing strokes legible. Print SHALL always be light.

#### Scenario: Dark system setting
- **WHEN** the system prefers a dark colour scheme
- **THEN** the page background is dark and the text is light
- **AND** the drawing's outlines, hatching and labels are visible against it

### Requirement: Precise technical typography
Numbers in tables and lists SHALL use tabular figures and right alignment where they are compared, and the type SHALL come from the system font stack with no web fonts. Content SHALL be dense but spaced enough to read.

#### Scenario: Aligned numbers
- **WHEN** the cartridge list is shown
- **THEN** the L3 column is right aligned with tabular figures

### Requirement: Usable on a phone
At a viewport 360 px wide every view SHALL be usable without horizontal page scroll: controls stack, tables stay readable, and touch targets are at least 44 px high.

#### Scenario: Phone detail view
- **WHEN** the detail view is shown at 360 px wide
- **THEN** the page has no horizontal scroll and the "Print" button and "All cartridges" link are at least 44 px high
