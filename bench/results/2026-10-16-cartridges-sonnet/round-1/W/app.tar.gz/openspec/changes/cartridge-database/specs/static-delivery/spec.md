# Spec Delta

## Purpose

The app is delivered as plain static files that work when opened straight from disk and when served by any static file server, with nothing fetched from the network and the 25 records exactly as given.

## ADDED Requirements

### Requirement: Plain files, no build, no runtime dependencies
The app SHALL be `index.html` in the project root with its CSS and JavaScript files, written in plain HTML, CSS and JavaScript. It SHALL NOT need a framework, a build step, server code or any runtime dependency. Development tools MAY be npm dev dependencies.

#### Scenario: Nothing to build
- **WHEN** the repository is checked out
- **THEN** `index.html` works without running any install or build command

### Requirement: Works from disk and from a server
The app SHALL work fully when `index.html` is opened directly from disk in Chromium (`file://`) and when the folder is served by a static file server. It SHALL use classic scripts and an address fragment for navigation, not ES modules, `fetch` of local files or server paths.

#### Scenario: Opened from disk
- **WHEN** `index.html` is opened from a `file://` address in Chromium
- **THEN** the list shows 25 cartridges and a detail view with its drawing opens

#### Scenario: Served by a static server
- **WHEN** the folder is served over HTTP by any static file server
- **THEN** the same behaviour is seen

### Requirement: No network requests
The running app SHALL make no network requests of its own: no CDN, web font, analytics or other remote resource, and no request for data. The only outgoing navigation is the user's activation of a water-capacity source link.

#### Scenario: Request log
- **WHEN** the start page and a detail view are loaded and every network request is recorded
- **THEN** every request is for a file of the app itself

### Requirement: The records are used as given
The app SHALL contain the 25 records of the brief exactly as given and SHALL NOT add, change or fetch data. Values in the app SHALL be derived from the records only.

#### Scenario: Data integrity
- **WHEN** the shipped data is compared with the 25 supplied records
- **THEN** they are identical, in the same order, with 25 distinct keys

### Requirement: Interface language
All interface text SHALL be in English.

#### Scenario: Language attribute
- **WHEN** `index.html` is loaded
- **THEN** the document language is `en`
