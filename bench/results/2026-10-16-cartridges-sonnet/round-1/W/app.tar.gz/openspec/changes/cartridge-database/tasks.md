# Tasks

## 1. Scaffold, data and tooling

- [x] 1.1 Create `package.json` (dev dependencies only, scripts `test`, `test:e2e`, `data`) and `.gitignore`; verify `npm install` succeeds and `node --test` runs with zero tests
- [x] 1.2 Write the data integrity test first (`test/data.test.mjs`: 25 lines in `data/cartridges.jsonl`, valid JSON, 25 distinct keys, `data/cartridges.js` equals the jsonl, spot checks such as `308_win` L3 = 51.18 and `6_5_creedmoor` name `6,5 Creedmoor`), see it fail, then add `data/cartridges.jsonl` verbatim from the brief, `scripts/make-data.mjs` and the generated `data/cartridges.js`; verify the test passes
- [x] 1.3 Check that a headless Chromium can be installed and launched here (`npx playwright install chromium`, launch, open a `file://` page); record the outcome in `design.md` Risks; verify with a one-line smoke script, and if it cannot run, note the fallback decided

## 2. Formatting (`js/format.js`)

- [x] 2.1 Write `test/format.test.mjs` first for number, angle (number and degrees/minutes/seconds, zero parts kept), unit per field, symbol map, section titles, tolerance folding (`39.62 -0.2`), water capacity, family/name passthrough; verify they fail, then implement `js/format.js` (UMD-style classic script) and verify they pass
- [x] 2.2 Add `buildTables(record)` (cartridge and chamber groups, section order, row order, empty sections skipped, `XTol` folded) with tests including "every non-tolerance numeric field appears exactly once" over all 25 records; verify the tests pass

## 3. Catalogue (`js/catalogue.js`)

- [x] 3.1 Write `test/catalogue.test.mjs` first: normalise (case, whitespace, decimal comma), search by name and alternative names (`7,62 x 51` → `308 Win.`, `creedmoor`, `6.5`), family filter counts (belted 2, pistol 6, rimfire 3, rimless 12, rimmed 2), combined filter, no match; then implement and verify they pass

## 4. Geometry (`js/geometry.js`)

- [x] 4.1 Write rim-type and head-face tests first (classification of the five reference records, chamfer points of 308 Win. 5.739/6.005, 22 LR half-round radius 0.545 and outermost 3.53, square corner without f); implement `rimType` and head/rim edge; verify they pass
- [x] 4.2 Write groove, belt and step tests first (308 Win. groove points, 300 Win. Mag. belt and ramp, 9,3 x 74 R step at z = 1.4); implement; verify they pass
- [x] 4.3 Write body/shoulder/neck/fillet tests first (308 Win. points, 9 mm Luger straight body, 6,5 x 55 SE shoulder through published points, tangent fillet radius and clamping, 17 HMR sharp corners with notes); implement; verify they pass
- [x] 4.4 Write wall, head and pocket tests first (308 Win. tn 0.435, tb 0.6, w 4.8, pocket 5.33 × 3.3; 223 pocket 4.45 × 3.04; 45 Auto 5.33 × 3.04; rimfire none; straight and heeled wall rules); implement the inner line, solid head and pocket; verify they pass
- [x] 4.5 Write bullet tests first (seating and cylinder end for 308 Win. 43.33/54.446, ρ ≈ 43.9, m 1.27; 9 mm Luger base 15.538; 357 Magnum semi-wadcutter m 5.472 and k 0.78; 22 LR heel 2.26/2.86; every shape/category pair in the data); implement; verify they pass
- [x] 4.6 Write the missing-value tests first (223 Rem. has no notes; 17 HMR names r1 min and r2; a stripped record loses G1 → bullet omitted, note names G1; nothing is substituted) and implement the notes; verify all 25 records build without throwing and with only the expected notes

## 5. Dimensions, labels and SVG (`js/layout.js`, `js/drawing.js`)

- [x] 5.1 Write layout tests first: required labels present for all 25 (`L3 51.18` form), optional ones only where published, `α 40°` and DMS angle label, arrowheads on both ends and ≥ 1 extension line per dimension, labels inside the viewBox; implement `layoutDimensions`; verify they pass
- [x] 5.2 Write the collision test first (for all 25: no label box overlaps another label, any outline/bullet segment, the title block or the border, using Liang–Barsky segment–rectangle checks) and make the placement algorithm pass it; verify the test passes for all 25
- [x] 5.3 Write SVG tests first (`role="img"`, `aria-label="<name> drawing"`, viewBox in mm with width equal to extent, hatch only in the lower half, centre line dash-dot, title block texts and `Scale n : 1` value, notes list text) using a minimal DOM stub or jsdom as a dev dependency; implement `renderSvg`; verify they pass
- [x] 5.4 Render all 25 drawings to SVG files in a temp directory (script outside the repo's tracked files) and inspect them visually in Chromium or an image viewer; fix geometry or layout defects found and add a regression test for each; verify no defect remains on the 25

## 6. App shell, list and detail (`index.html`, `js/app.js`)

- [x] 6.1 Write e2e tests first (`test/e2e/list.spec.mjs`: heading "Cartridges", 25 rows with name link, family, L3; "Search" and "Family" controls with accessible labels; `7,62 x 51` finds `308 Win.`; belted shows 2; "N cartridges" text; no-match message); implement `index.html`, the list view and the filter wiring; verify they pass on `file://`
- [x] 6.2 Write e2e tests first (`detail.spec.mjs`: address `#/cartridge/223_rem` survives reload, heading, facts incl. alternative names and "not published", capacity with source link, grouped tables with Symbol/Value/Unit, tolerance beside value, no row for `L1Tol`, "Print" calls `window.print`, "All cartridges" returns with search kept, unknown key message, document title and focus); implement routing and the detail view; verify they pass
- [x] 6.3 Add `test/e2e/delivery.spec.mjs`: every request is a file of the app, works over a local static HTTP server, `lang="en"`, no `type="module"`/`import`/remote URLs in `index.html` and `js/`/`css/` (static lint in `test/static.test.mjs`); verify both pass

## 7. Styling, responsive and print

- [x] 7.1 Write e2e tests first for 360 px (no horizontal scroll on list and detail for all 25, touch targets ≥ 44 px, drawing not wider than the viewport) and for dark scheme (background dark, text light, contrast ≥ 4.5:1 computed from computed styles); implement `css/app.css` screen styles (light/dark custom properties, tabular numbers, dense type, phone layout); verify they pass
- [x] 7.2 Write print e2e tests first (`page.pdf` A4 portrait yields exactly one page for each of the 25 cartridges; print media: white background and black text even under dark scheme, header name first, no button/link/search/select, footer "Source: C.I.P. TDCC, revised <date>", drawing width 190 mm, label text ≥ 6 pt via `getBBox` scaled to mm); implement the `@media print` rules (three-column tables, hidden interface, footer); verify they pass
- [x] 7.3 Add the real-browser label check (`getBBox` boxes of every drawing label do not overlap each other or the outline, all inside the viewBox) for all 25; fix text-width estimate or placement if it fails; verify it passes

## 8. Documentation and final verification

- [x] 8.1 Write `README.md` (how to open, `npm test`, `npm run test:e2e`, data source and licence note, unit assumption for fields not listed, geometry interpretation decisions, how to regenerate `data/cartridges.js`); verify every command in it runs as written
- [x] 8.2 Run the whole suite plus `openspec validate cartridge-database --strict`, take screenshots (light, dark, phone, print PDF) of at least 308 Win., 300 Win. Mag., 22 Long Rifle, 9 mm Luger, 9,3 x 74 R and 17 HMR and look at each; fix what is wrong and add tests for it; verify all tests green and screenshots acceptable
- [x] 8.3 Review the change (`/code-review` on the diff and a spec-conformance pass against `specs/`), fix findings, and verify tests are still green

## Workflow follow-up

- Archive the change (`/openspec-archive-change`) after review.
- Commit on a branch when the user asks.
