import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import { createRequire } from 'node:module';

const require = createRequire(import.meta.url);
const C = require('../js/catalogue.js');
const records = fs.readFileSync(new URL('../data/cartridges.jsonl', import.meta.url), 'utf8')
  .split('\n').filter(Boolean).map((l) => JSON.parse(l));
const names = (list) => list.map((r) => r.name);

test('normalise ignores case, repeated whitespace and the decimal separator', () => {
  assert.equal(C.normalise('  6,5   CREEDMOOR '), '6.5 creedmoor');
  assert.equal(C.normalise('7,62 x 51'), C.normalise('7.62  X 51'));
});

test('empty query and family All list everything', () => {
  assert.equal(C.filter(records, { query: '', family: 'All' }).length, 25);
  assert.equal(C.filter(records, {}).length, 25);
});

test('alternative names are searched', () => {
  assert.deepEqual(names(C.filter(records, { query: '7,62 x 51' })), ['308 Win.']);
  assert.deepEqual(names(C.filter(records, { query: '22LR' })), ['22 Long Rifle']);
  assert.deepEqual(names(C.filter(records, { query: '30-06' })), ['30-06 Spring.']);
});

test('case is ignored and the name is searched', () => {
  assert.deepEqual(names(C.filter(records, { query: 'creedmoor' })), ['6,5 Creedmoor']);
  assert.deepEqual(names(C.filter(records, { query: 'CREEDMOOR' })), ['6,5 Creedmoor']);
});

test('a decimal point finds a decimal comma', () => {
  assert.deepEqual(names(C.filter(records, { query: '6.5' })), ['6,5 Creedmoor', '6,5 x 55 SE']);
});

test('family filter counts', () => {
  const count = (family) => C.filter(records, { query: '', family }).length;
  assert.equal(count('rimless'), 12);
  assert.equal(count('rimmed'), 2);
  assert.equal(count('belted'), 2);
  assert.equal(count('pistol'), 6);
  assert.equal(count('rimfire'), 3);
  assert.deepEqual(names(C.filter(records, { family: 'belted' })), ['300 Win. Mag.', '7 mm Rem. Mag.']);
});

test('family and search combine', () => {
  assert.deepEqual(names(C.filter(records, { family: 'rimfire', query: '22' })),
    ['22 Long Rifle', '22 Win. Mag. R.F.']);
});

test('no match gives an empty list', () => {
  assert.deepEqual(C.filter(records, { query: 'zzz' }), []);
});

test('count text is literal "<n> cartridges"', () => {
  assert.equal(C.countText(25), '25 cartridges');
  assert.equal(C.countText(1), '1 cartridges');
  assert.equal(C.countText(0), '0 cartridges');
});

test('families offered by the select, in order', () => {
  assert.deepEqual(C.FAMILIES, ['All', 'rimless', 'rimmed', 'belted', 'pistol', 'rimfire']);
});

test('lookup by key', () => {
  assert.equal(C.findByKey(records, '223_rem').name, '223 Rem.');
  assert.equal(C.findByKey(records, 'nope'), undefined);
});
