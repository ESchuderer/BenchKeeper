import test from 'node:test';
import assert from 'node:assert/strict';
import { load, records } from './helpers/records.mjs';

const G = load('geometry');
const L = load('layout');

// ---- independent geometry helpers ---------------------------------------------

const FONT = 2.8;
const boxOf = (lab) => {
  const w = lab.text.length * 0.6 * FONT;
  const x0 = lab.anchor === 'middle' ? lab.x - w / 2 : lab.anchor === 'end' ? lab.x - w : lab.x;
  return { x0, x1: x0 + w, y0: lab.y - 0.95 * FONT, y1: lab.y + 0.25 * FONT };
};
const grow = (b, p) => ({ x0: b.x0 - p, y0: b.y0 - p, x1: b.x1 + p, y1: b.y1 + p });
const rectsOverlap = (a, b) => a.x0 < b.x1 && b.x0 < a.x1 && a.y0 < b.y1 && b.y0 < a.y1;

// Liang-Barsky: does the segment touch the rectangle?
function segmentHitsRect(s, b) {
  let t0 = 0, t1 = 1;
  const dx = s.x2 - s.x1, dy = s.y2 - s.y1;
  const p = [-dx, dx, -dy, dy];
  const q = [s.x1 - b.x0, b.x1 - s.x1, s.y1 - b.y0, b.y1 - s.y1];
  for (let i = 0; i < 4; i++) {
    if (p[i] === 0) { if (q[i] < 0) return false; continue; }
    const t = q[i] / p[i];
    if (p[i] < 0) { if (t > t1) return false; if (t > t0) t0 = t; }
    else { if (t < t0) return false; if (t < t1) t1 = t; }
  }
  return true;
}

// Obstacles derived from the geometry model by the test itself (not taken from the layout module).
function obstacles(model) {
  const segs = [];
  const add = (poly, sign) => { for (let i = 1; i < poly.length; i++) segs.push({ x1: poly[i - 1].z, y1: sign * poly[i - 1].r, x2: poly[i].z, y2: sign * poly[i].r }); };
  if (model.outer) {
    add(model.outer, -1); add(model.outer, 1);
    const r0 = model.outer[1].r;
    segs.push({ x1: 0, y1: -r0, x2: 0, y2: r0 });
    segs.push({ x1: model.mouth.z, y1: -model.mouth.r, x2: model.mouth.z, y2: model.mouth.r });
  }
  if (model.inner) { add(model.inner, -1); add(model.inner, 1); }
  if (model.bullet) { add(model.bullet.exposed, -1); add(model.bullet.full, 1); }
  return segs;
}

test('no label overlaps another label, the outline, the title block or the frame (all 25)', () => {
  for (const r of records) {
    const model = G.buildModel(r);
    const lay = L.layoutDimensions(model, r);
    const segs = obstacles(model);
    const labels = lay.dims.map((d) => ({ id: d.id, box: boxOf(d.label) }));
    const tb = lay.titleBlock;
    for (let i = 0; i < labels.length; i++) {
      const { id, box } = labels[i];
      const ctx = `${r.key} ${id}`;
      for (const s of segs) assert.ok(!segmentHitsRect(s, grow(box, 0.3)), `${ctx} touches the outline at (${s.x1.toFixed(2)},${s.y1.toFixed(2)})-(${s.x2.toFixed(2)},${s.y2.toFixed(2)})`);
      for (let j = i + 1; j < labels.length; j++) assert.ok(!rectsOverlap(grow(box, 0.3), labels[j].box), `${ctx} overlaps ${labels[j].id}`);
      assert.ok(!rectsOverlap(box, { x0: tb.x, y0: tb.y, x1: tb.x + tb.w, y1: tb.y + tb.h }), `${ctx} overlaps the title block`);
      assert.ok(box.x0 >= lay.frame.x + 1 && box.x1 <= lay.frame.x + lay.frame.w - 1, `${ctx} outside the frame horizontally`);
      assert.ok(box.y0 >= lay.frame.y + 1 && box.y1 <= tb.y, `${ctx} outside the frame vertically`);
    }
  }
});

test('layout label boxes agree with the independent estimate', () => {
  for (const r of records) {
    const lay = L.layoutDimensions(G.buildModel(r), r);
    for (const d of lay.dims) {
      const b = boxOf(d.label);
      assert.ok(Math.abs(b.x0 - d.label.box.x0) < 1e-9 && Math.abs(b.x1 - d.label.box.x1) < 1e-9, `${r.key} ${d.id}`);
    }
  }
});

test('labels also keep clear of the lines of other dimensions', () => {
  for (const r of records) {
    const model = G.buildModel(r);
    const lay = L.layoutDimensions(model, r);
    for (const d of lay.dims) {
      const box = grow(boxOf(d.label), 0.2);
      for (const o of lay.dims) {
        if (o === d) continue;
        for (const l of o.lines) assert.ok(!segmentHitsRect(l, box), `${r.key}: label ${d.id} is crossed by ${l.kind} line of ${o.id}`);
      }
    }
  }
});

test('a label does not sit on its own extension or dimension line', () => {
  for (const r of records) {
    const lay = L.layoutDimensions(G.buildModel(r), r);
    for (const d of lay.dims) {
      const box = grow(boxOf(d.label), 0.1);
      for (const l of d.lines) assert.ok(!segmentHitsRect(l, box), `${r.key}: label ${d.id} sits on its own ${l.kind} line`);
    }
  }
});
