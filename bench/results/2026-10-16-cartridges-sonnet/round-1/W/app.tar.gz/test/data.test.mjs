import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';

const jsonl = fs.readFileSync(new URL('../data/cartridges.jsonl', import.meta.url), 'utf8');
const lines = jsonl.split('\n').filter((l) => l.trim());
const records = lines.map((l) => JSON.parse(l));

function loadShipped() {
  const ctx = { window: {} };
  vm.createContext(ctx);
  vm.runInContext(fs.readFileSync(new URL('../data/cartridges.js', import.meta.url), 'utf8'), ctx);
  return JSON.parse(JSON.stringify(ctx.window.CIP_DATA));
}

test('the jsonl holds 25 records with distinct keys', () => {
  assert.equal(records.length, 25);
  assert.equal(new Set(records.map((r) => r.key)).size, 25);
});

test('the shipped data file is identical to the jsonl, in order', () => {
  assert.deepEqual(loadShipped(), records);
});

test('spot checks against the brief', () => {
  const by = Object.fromEntries(records.map((r) => [r.key, r]));
  assert.equal(by['308_win'].cartridge.lengths.L3, 51.18);
  assert.equal(by['6_5_creedmoor'].name, '6,5 Creedmoor');
  assert.deepEqual(by['308_win'].alternativeNames, ['308 Winchester', '7,62 x 51']);
  assert.equal(by['40_s_w'].name, '40 S.& W.');
  assert.equal(by['22_long_rifle'].cartridge.caseHead.RTol, -0.18);
  assert.deepEqual(by['6_5_x_55_se'].cartridge.junctionCone.alpha, { degrees: 50, minutes: 35, seconds: 2 });
  assert.equal(by['300_win_mag'].cartridge.caseHead.R3, 13.51);
  assert.deepEqual(records.map((r) => r.family).reduce((a, f) => ((a[f] = (a[f] || 0) + 1), a), {}),
    { rimless: 12, belted: 2, rimmed: 2, pistol: 6, rimfire: 3 });
});
