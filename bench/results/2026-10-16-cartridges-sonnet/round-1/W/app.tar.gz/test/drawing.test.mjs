import test from 'node:test';
import assert from 'node:assert/strict';
import { JSDOM } from 'jsdom';
import { load, records, rec } from './helpers/records.mjs';

const D = load('drawing');
const document = new JSDOM('<!doctype html><body></body>').window.document;
const draw = (key) => D.render(rec(key), document);
const pts = (el) => el.getAttribute('points').trim().split(/\s+/).map((p) => p.split(',').map(Number));
const SVG_NS = 'http://www.w3.org/2000/svg';

test('inline svg with role img and the accessible name "<name> drawing"', () => {
  const { svg } = draw('6_5_creedmoor');
  assert.equal(svg.namespaceURI, SVG_NS);
  assert.equal(svg.tagName.toLowerCase(), 'svg');
  assert.equal(svg.getAttribute('role'), 'img');
  assert.equal(svg.getAttribute('aria-label'), '6,5 Creedmoor drawing');
});

test('the svg scales: a viewBox in mm and no fixed width or height', () => {
  const { svg } = draw('308_win');
  const vb = svg.getAttribute('viewBox').split(/\s+/).map(Number);
  assert.equal(vb.length, 4);
  assert.ok(vb[2] > 90 && vb[3] > 40);
  assert.equal(svg.hasAttribute('width'), false);
  assert.equal(svg.hasAttribute('height'), false);
  assert.ok(/xMidYMid/.test(svg.getAttribute('preserveAspectRatio')));
});

test('true to scale: case ends at L3 and the bullet tip at L6 (1 unit = 1 mm)', () => {
  const { svg } = draw('308_win');
  const caseXs = pts(svg.querySelector('[data-part="case-outline-upper"]')).map((p) => p[0]);
  assert.equal(Math.min(...caseXs), 0);
  assert.ok(Math.abs(Math.max(...caseXs) - 51.18) < 1e-3);
  const bulletXs = pts(svg.querySelector('[data-part="bullet-outline-upper"]')).map((p) => p[0]);
  assert.ok(Math.abs(Math.max(...bulletXs) - 71.12) < 1e-3);
  const ys = pts(svg.querySelector('[data-part="case-outline-upper"]')).map((p) => p[1]);
  assert.ok(Math.abs(Math.min(...ys) + 6.005) < 1e-3, 'rim edge at -R1/2 in the upper half');
});

test('upper half is the outside view: nothing of the cut is drawn above the axis', () => {
  const { svg } = draw('308_win');
  const hatch = svg.querySelectorAll('[data-part="hatch"]');
  assert.equal(hatch.length, 1);
  assert.ok(pts(hatch[0]).every(([, y]) => y >= -1e-9), 'hatched region is below the axis');
  // seated part of the bullet is hidden in the outside view: its upper outline starts at the mouth
  const up = pts(svg.querySelector('[data-part="bullet-outline-upper"]'));
  assert.ok(Math.min(...up.map((p) => p[0])) >= 51.18 - 1e-3);
  const low = pts(svg.querySelector('[data-part="bullet-section"]'));
  assert.ok(Math.min(...low.map((p) => p[0])) < 44, 'seated part shown in the section');
  assert.ok(low.every(([, y]) => y >= -1e-9));
});

test('hatching uses a pattern and covers neither the cavity nor the bullet', () => {
  const { svg } = draw('308_win');
  const h = svg.querySelector('[data-part="hatch"]');
  const m = /url\(#([^)]+)\)/.exec(h.getAttribute('fill'));
  assert.ok(m, 'fill refers to a pattern');
  assert.ok(svg.querySelector(`pattern[id="${m[1]}"]`));
  const bullet = svg.querySelector('[data-part="bullet-section"]');
  assert.ok(!/url\(/.test(bullet.getAttribute('fill') || ''));
});

test('a dash-dot centre line lies on the axis over the full length', () => {
  const { svg } = draw('308_win');
  const c = svg.querySelector('.centre-line');
  assert.equal(Number(c.getAttribute('y1')), 0);
  assert.equal(Number(c.getAttribute('y2')), 0);
  assert.ok(Number(c.getAttribute('x1')) <= 0 && Number(c.getAttribute('x2')) >= 71.12);
  const dash = c.getAttribute('stroke-dasharray').trim().split(/[\s,]+/).map(Number);
  assert.equal(dash.length, 4, 'long dash, gap, dot, gap');
  assert.ok(dash[0] > 3 * dash[2]);
});

test('labels are text elements with the layout texts; arrows and extension lines are drawn', () => {
  const { svg } = draw('308_win');
  const labels = [...svg.querySelectorAll('text.dim-label')].map((t) => t.textContent).sort();
  assert.deepEqual(labels, ['E1 10.39', 'G1 7.85', 'H1 8.72', 'H2 8.72', 'L1 39.62', 'L2 43.48', 'L3 51.18', 'L6 71.12',
    'P1 11.96', 'P2 11.53', 'R 1.37', 'R1 12.01', 'α 40°'].sort());
  assert.ok(svg.querySelectorAll('.arrow').length >= 2 * 12 + 1);
  assert.ok(svg.querySelectorAll('line.ext').length >= 2 * 12);
});

test('title block text', () => {
  const { svg } = draw('308_win');
  const t = [...svg.querySelectorAll('.title-block text')].map((x) => x.textContent);
  assert.ok(t.includes('308 Win.') && t.includes('C.I.P. table I') && t.includes('Revised 2008-09-23'));
  assert.ok(t.includes('Dimensions in mm'));
  assert.ok(t.some((x) => /^Scale \d+\.\d\d : 1/.test(x)));
});

test('notes for omitted features are returned, none for a complete record', () => {
  assert.deepEqual(draw('223_rem').notes, []);
  const n = draw('17_hmr').notes.join(' ');
  assert.match(n, /r1 min/);
  assert.match(n, /r2/);
});

test('every record renders, with no NaN in any attribute', () => {
  for (const r of records) {
    const { svg } = D.render(r, document);
    const all = [svg, ...svg.querySelectorAll('*')];
    for (const el of all) for (const a of el.attributes) assert.ok(!/NaN|undefined|Infinity/.test(a.value), `${r.key} ${el.tagName} ${a.name}`);
    for (const t of svg.querySelectorAll('text')) assert.ok(!/NaN|undefined/.test(t.textContent), r.key);
  }
});

test('a record without an outline still renders a title block and no stray shapes', () => {
  const r = JSON.parse(JSON.stringify(rec('308_win')));
  delete r.cartridge.powderChamber.P1;
  const { svg, notes } = D.render(r, document);
  assert.ok(svg.querySelector('.title-block'));
  assert.equal(svg.querySelector('[data-part="case-outline-upper"]'), null);
  assert.ok(notes.some((n) => /P1/.test(n)));
});
