import { test, before, after } from 'node:test';
import assert from 'node:assert/strict';
import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import { launch, openPage, INDEX_URL, ROOT } from './helpers.mjs';

let browser;
before(async () => { browser = await launch(); });
after(async () => { await browser.close(); });

test('from disk (file://): every request is a file of the app', async () => {
  const context = await browser.newContext();
  const page = await context.newPage();
  const urls = [];
  page.on('request', (r) => urls.push(r.url()));
  const errors = [];
  page.on('pageerror', (e) => errors.push(e.message));
  await page.goto(INDEX_URL);
  await page.getByRole('link', { name: '308 Win.', exact: true }).click();
  await page.getByRole('img', { name: '308 Win. drawing' }).waitFor();
  await page.reload();
  await context.close();
  assert.deepEqual(errors, []);
  assert.ok(urls.length >= 8, 'index, css and scripts were requested');
  for (const u of urls) {
    assert.ok(u.startsWith('file://'), `non-file request: ${u}`);
    const p = decodeURIComponent(new URL(u).pathname);
    assert.ok(p.startsWith(ROOT + '/'), `outside the project: ${p}`);
  }
});

test('served by a static file server: same behaviour and only same-origin requests', async () => {
  const types = { '.html': 'text/html', '.js': 'text/javascript', '.css': 'text/css' };
  const server = http.createServer((req, res) => {
    const p = path.join(ROOT, decodeURIComponent(new URL(req.url, 'http://x').pathname).replace(/\/$/, '/index.html'));
    if (!p.startsWith(ROOT) || !fs.existsSync(p) || fs.statSync(p).isDirectory()) { res.writeHead(404); res.end(); return; }
    res.writeHead(200, { 'content-type': types[path.extname(p)] || 'application/octet-stream' });
    fs.createReadStream(p).pipe(res);
  });
  await new Promise((r) => server.listen(0, '127.0.0.1', r));
  const origin = `http://127.0.0.1:${server.address().port}`;
  try {
    const { page, context, problems } = await openPage(browser, { url: origin + '/' });
    const urls = [];
    page.on('request', (r) => urls.push(r.url()));
    assert.equal(await page.locator('#list-view tbody tr').count(), 25);
    await page.getByRole('link', { name: '7,62 x 39', exact: true }).click();
    await page.getByRole('img', { name: '7,62 x 39 drawing' }).waitFor();
    await page.reload();
    await page.getByRole('heading', { level: 1, name: '7,62 x 39' }).waitFor();
    await context.close();
    assert.deepEqual(problems, []);
    for (const u of urls) assert.ok(u.startsWith(origin), `foreign request: ${u}`);
  } finally { server.close(); }
});
