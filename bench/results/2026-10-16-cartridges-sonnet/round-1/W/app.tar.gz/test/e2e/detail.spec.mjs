import { test, before, after } from 'node:test';
import assert from 'node:assert/strict';
import { launch, openPage, INDEX_URL } from './helpers.mjs';

let browser;
before(async () => { browser = await launch(); });
after(async () => { await browser.close(); });

async function withPage(fn, opts) {
  const { page, context, problems } = await openPage(browser, opts);
  try { await fn(page); assert.deepEqual(problems, [], 'no page errors'); } finally { await context.close(); }
}
const detail = (key) => ({ url: INDEX_URL + '#/cartridge/' + key });
const fact = async (page, label) => (await page.locator('#detail-view dt', { hasText: new RegExp('^' + label.replace(/[.]/g, '\\.') + '$') }).locator('xpath=following-sibling::dd[1]').innerText()).trim();

test('a name link opens the detail view with its own address', () => withPage(async (page) => {
  await page.getByRole('link', { name: '308 Win.', exact: true }).click();
  await page.getByRole('heading', { level: 1, name: '308 Win.' }).waitFor();
  assert.match(page.url(), /#\/cartridge\/308_win$/);
  assert.equal(await page.locator('#list-view').isHidden(), true);
}));

test('the address survives a reload and can be opened directly', () => withPage(async (page) => {
  assert.equal(await page.getByRole('heading', { level: 1, name: '223 Rem.' }).count(), 1);
  await page.reload();
  assert.equal(await page.getByRole('heading', { level: 1, name: '223 Rem.' }).count(), 1);
  assert.equal(await page.locator('#list-view').isHidden(), true);
}, detail('223_rem')));

test('identifying facts of 308 Win.', () => withPage(async (page) => {
  assert.equal(await fact(page, 'Alternative names'), '308 Winchester, 7,62 x 51');
  assert.equal(await fact(page, 'Family'), 'rimless');
  assert.equal(await fact(page, 'Category'), 'rifle');
  assert.equal(await fact(page, 'Primer type'), 'lr');
  assert.equal(await fact(page, 'C.I.P. table'), 'I');
  assert.equal(await fact(page, 'Country'), 'US');
  assert.equal(await fact(page, 'Published'), '1984-06-14');
  assert.equal(await fact(page, 'Revised'), '2008-09-23');
  assert.equal(await fact(page, 'Pressure method'), 'Transducer');
}, detail('308_win')));

test('missing alternative names and capacity are shown as such', () => withPage(async (page) => {
  assert.equal(await fact(page, 'Alternative names'), '—');
  assert.equal(await fact(page, 'Water capacity'), 'not published');
}, detail('7_x_64')));

test('water capacity with note and a source link', () => withPage(async (page) => {
  const text = await fact(page, 'Water capacity');
  assert.match(text, /^30\.5 gr H2O/);
  assert.match(text, /kwk 31, Wikipedia 28\.8; the mean/);
  const link = page.locator('#detail-view dd a', { hasText: 'kwk' });
  assert.equal(await link.getAttribute('href'), 'http://kwk.us/cases.html');
}, detail('223_rem')));

test('tables: grouped, with Symbol, Value and Unit columns', () => withPage(async (page) => {
  const titles = await page.locator('#detail-view h3').allTextContents();
  for (const t of ['Case head', 'Collar', 'Junction cone', 'Lengths', 'Miscellaneous', 'Powder chamber', 'Pressures', 'Projectile',
    'Barrel', 'Breech', 'Grooves', 'Rifling']) assert.ok(titles.includes(t), t);
  assert.equal(await page.getByRole('heading', { level: 2, name: 'Cartridge' }).count(), 1);
  assert.equal(await page.getByRole('heading', { level: 2, name: 'Chamber' }).count(), 1);
  const headers = await page.locator('#detail-view table.values').first().locator('thead th').allTextContents();
  assert.deepEqual(headers, ['Symbol', 'Value', 'Unit']);
  assert.equal(await page.locator('#detail-view table.values').count(), 16);
}, detail('223_rem')));

test('values, units, tolerance beside the value, no tolerance rows, renamed symbols', () => withPage(async (page) => {
  const row = (sym, table) => page.locator(`#detail-view section.value-group[data-group="${table}"] tbody tr`).filter({ has: page.locator('th', { hasText: new RegExp('^' + sym + '$') }) });
  const l3 = row('L3', 'cartridge').first();
  assert.equal((await l3.locator('td').nth(0).innerText()).trim(), '51.18');
  assert.equal((await l3.locator('td').nth(1).innerText()).trim(), 'mm');
  assert.equal((await row('L1', 'cartridge').first().locator('td').nth(0).innerText()).trim(), '39.62 -0.2');
  assert.equal((await row('Pmax', 'cartridge').first().locator('td').nth(0).innerText()).trim(), '4150');
  assert.equal((await row('Pmax', 'cartridge').first().locator('td').nth(1).innerText()).trim(), 'bar');
  assert.equal((await row('α', 'cartridge').first().locator('td').nth(0).innerText()).trim(), '40°');
  assert.equal(await row('L1Tol', 'cartridge').count(), 0);
  assert.equal(await row('eMin', 'cartridge').count(), 0);
  assert.equal(await row('e min', 'cartridge').count(), 1);
  assert.equal((await row('α1', 'chamber').first().locator('td').nth(0).innerText()).trim(), `71°25'59"`);
  assert.equal((await row('N', 'chamber').first().locator('td').nth(1).innerText()).trim(), '');
}, detail('308_win')));

test('every value row shows once: row count equals the record field count', () => withPage(async (page) => {
  // 223 Rem.: cartridge 8+2+4+5+2+2+5+2 = 30 values? counted from the record below
  const rec = await page.evaluate(() => window.CIP_DATA.find((r) => r.key === '223_rem'));
  const count = (o) => Object.values(o).reduce((n, sec) => n + Object.keys(sec).filter((k) => !k.endsWith('Tol')).length, 0);
  assert.equal(await page.locator('section.value-group[data-group="cartridge"] tbody tr').count(), count(rec.cartridge));
  assert.equal(await page.locator('section.value-group[data-group="chamber"] tbody tr').count(), count(rec.chamber));
}, detail('223_rem')));

test('empty junction cone section of 9 mm Luger is not shown', () => withPage(async (page) => {
  assert.equal(await page.locator('#detail-view h3', { hasText: 'Junction cone' }).count(), 0);
}, detail('9_mm_luger')));

test('drawing is an image named "<name> drawing"', () => withPage(async (page) => {
  const img = page.getByRole('img', { name: '6,5 Creedmoor drawing' });
  assert.equal(await img.count(), 1);
  assert.equal(await img.evaluate((e) => e.tagName.toLowerCase()), 'svg');
  assert.equal(await page.locator('#detail-view svg').count(), 1);
}, detail('6_5_creedmoor')));

test('omitted drawing features are listed below the drawing', () => withPage(async (page) => {
  const notes = (await page.locator('#detail-view .drawing-notes').innerText());
  assert.match(notes, /r1 min/);
  assert.match(notes, /r2/);
}, detail('17_hmr')));

test('a complete record has no drawing notes', () => withPage(async (page) => {
  assert.equal(await page.locator('#detail-view .drawing-notes').count(), 0);
}, detail('223_rem')));

test('Print calls the print function once', () => withPage(async (page) => {
  await page.getByRole('button', { name: 'Print' }).click();
  assert.equal(await page.evaluate(() => window.__printCalls), 1);
}, detail('308_win')));

test('All cartridges returns to the list and keeps search and family', () => withPage(async (page) => {
  await page.getByLabel('Search').fill('win');
  await page.getByLabel('Family').selectOption('belted');
  await page.getByRole('link', { name: '300 Win. Mag.', exact: true }).click();
  await page.getByRole('link', { name: 'All cartridges' }).click();
  await page.getByRole('heading', { level: 1, name: 'Cartridges' }).waitFor();
  assert.equal(await page.getByLabel('Search').inputValue(), 'win');
  assert.equal(await page.getByLabel('Family').inputValue(), 'belted');
  assert.deepEqual(await page.locator('#list-view tbody tr a').allTextContents(), ['300 Win. Mag.']);
}));

test('browser back returns to the list', () => withPage(async (page) => {
  await page.getByRole('link', { name: '45 Auto', exact: true }).click();
  await page.goBack();
  await page.getByRole('heading', { level: 1, name: 'Cartridges' }).waitFor();
  await page.goForward();
  await page.getByRole('heading', { level: 1, name: '45 Auto' }).waitFor();
}));

test('unknown address: message, link to the list, no drawing', () => withPage(async (page) => {
  assert.equal(await page.getByText('Cartridge not found').count() > 0, true);
  assert.equal(await page.getByRole('link', { name: 'All cartridges' }).count(), 1);
  assert.equal(await page.locator('svg.drawing').count(), 0);
}, detail('does_not_exist')));

test('title follows the view and focus moves to the heading after navigation', () => withPage(async (page) => {
  await page.getByRole('link', { name: '9 mm Luger', exact: true }).click();
  await page.getByRole('heading', { level: 1, name: '9 mm Luger' }).waitFor();
  assert.match(await page.title(), /9 mm Luger/);
  assert.equal(await page.evaluate(() => document.activeElement && document.activeElement.tagName), 'H1');
  await page.getByRole('link', { name: 'All cartridges' }).click();
  await page.getByRole('heading', { level: 1, name: 'Cartridges' }).waitFor();
  assert.match(await page.title(), /^Cartridges/);
  assert.equal(await page.evaluate(() => document.activeElement && document.activeElement.id), 'list-heading');
}));

test('every cartridge opens without errors and shows a drawing', async () => {
  const { page, context, problems } = await openPage(browser);
  try {
    const keys = await page.evaluate(() => window.CIP_DATA.map((r) => [r.key, r.name]));
    for (const [key, name] of keys) {
      await page.goto(INDEX_URL + '#/cartridge/' + key);
      assert.equal(await page.getByRole('heading', { level: 1, name, exact: true }).count(), 1, key);
      assert.equal(await page.getByRole('img', { name: name + ' drawing' }).count(), 1, key);
    }
    assert.deepEqual(problems, []);
  } finally { await context.close(); }
});

test('ids are unique and each value table is labelled by its heading', () => withPage(async (page) => {
  const dup = await page.evaluate(() => { const ids = [...document.querySelectorAll('[id]')].map((e) => e.id); return ids.filter((id, i) => ids.indexOf(id) !== i); });
  assert.deepEqual(dup, []);
  const unlabelled = await page.evaluate(() => [...document.querySelectorAll('section.value-table')].filter((s) => {
    const l = document.getElementById(s.getAttribute('aria-labelledby')); return !l || l.tagName !== 'H3'; }).length);
  assert.equal(unlabelled, 0);
  const ids = () => page.evaluate(() => [...document.querySelectorAll('section.value-table')].map((s) => s.getAttribute('aria-labelledby')).join());
  const first = await ids();
  await page.getByRole('link', { name: 'All cartridges' }).click();
  await page.goBack();
  assert.equal(await ids(), first, 'ids are the same on every render');
}, detail('223_rem')));

test('the notes caption does not claim that published values are missing', () => withPage(async (page) => {
  const caption = await page.locator('#detail-view .drawing-notes p').innerText();
  assert.equal(caption, 'Drawing notes');
}, detail('17_hmr')));

test('back from a cartridge restores the scroll position of the list', () => withPage(async (page) => {
  await page.getByLabel('Family').selectOption('All');
  await page.evaluate(() => window.scrollTo(0, 400));
  const before = await page.evaluate(() => window.scrollY);
  assert.ok(before > 100, 'the list is long enough to scroll: ' + before);
  await page.locator('#list-view tbody tr').nth(20).getByRole('link').click();
  await page.waitForFunction(() => window.scrollY === 0);
  await page.goBack();
  await page.waitForFunction((y) => Math.abs(window.scrollY - y) < 3, before, { timeout: 3000 });
}, { viewport: { width: 1100, height: 500 } }));
