import { chromium } from 'playwright';
import path from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';

export const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '../..');
export const INDEX_URL = pathToFileURL(path.join(ROOT, 'index.html')).href;

// One browser per test file; every test gets a fresh context (so no state leaks between tests).
export async function launch() {
  return chromium.launch();
}

export async function openPage(browser, { url = INDEX_URL, viewport, colorScheme = 'light', media, failOnConsole = true } = {}) {
  const context = await browser.newContext({ viewport: viewport || { width: 1100, height: 900 }, colorScheme });
  context.setDefaultTimeout(4000);
  const page = await context.newPage();
  const problems = [];
  page.on('pageerror', (e) => problems.push('pageerror: ' + e.message));
  page.on('console', (m) => { if (failOnConsole && m.type() === 'error') problems.push('console: ' + m.text()); });
  await page.addInitScript(() => { window.__printCalls = 0; window.print = () => { window.__printCalls++; }; });
  if (media) await page.emulateMedia({ media });
  await page.goto(url);
  page.problems = problems;
  return { page, context, problems };
}
