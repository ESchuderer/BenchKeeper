import { test, before, after } from 'node:test';
import assert from 'node:assert/strict';
import { launch, openPage, INDEX_URL } from './helpers.mjs';

let browser;
before(async () => { browser = await launch(); });
after(async () => { await browser.close(); });

// Runs in the page: real font metrics from getBBox(), real geometry of the drawn outline.
function measure() {
  const svg = document.querySelector('svg.drawing');
  const vb = svg.viewBox.baseVal;
  const boxes = [...svg.querySelectorAll('text.dim-label')].map((t) => { const b = t.getBBox(); return { id: t.parentNode.getAttribute('data-id'), text: t.textContent, x0: b.x, y0: b.y, x1: b.x + b.width, y1: b.y + b.height }; });
  const segs = [];
  for (const part of ['case-outline-upper', 'section-outline', 'case-outline-lower', 'bullet-outline-upper', 'bullet-outline-lower']) {
    const el = svg.querySelector(`[data-part="${part}"]`);
    if (!el) continue;
    const p = el.getAttribute('points').trim().split(/\s+/).map((s) => s.split(',').map(Number));
    for (let i = 1; i < p.length; i++) segs.push({ x1: p[i - 1][0], y1: p[i - 1][1], x2: p[i][0], y2: p[i][1] });
  }
  const tb = svg.querySelector('.title-block .title-rule').getBBox();
  const frame = svg.querySelector('.frame').getBBox();
  return { vb: { x: vb.x, y: vb.y, w: vb.width, h: vb.height }, boxes, segs, titleTop: tb.y, frame: { x: frame.x, y: frame.y, w: frame.width, h: frame.height } };
}

function hits(seg, b) {
  let t0 = 0, t1 = 1;
  const dx = seg.x2 - seg.x1, dy = seg.y2 - seg.y1;
  const p = [-dx, dx, -dy, dy], q = [seg.x1 - b.x0, b.x1 - seg.x1, seg.y1 - b.y0, b.y1 - seg.y1];
  for (let i = 0; i < 4; i++) {
    if (p[i] === 0) { if (q[i] < 0) return false; continue; }
    const t = q[i] / p[i];
    if (p[i] < 0) { if (t > t1) return false; if (t > t0) t0 = t; } else { if (t < t0) return false; if (t < t1) t1 = t; }
  }
  return true;
}
const overlap = (a, b) => a.x0 < b.x1 && b.x0 < a.x1 && a.y0 < b.y1 && b.y0 < a.y1;

test('with real font metrics no label overlaps another label or the outline, and all lie inside the frame (all 25)', async () => {
  const { page, context, problems } = await openPage(browser);
  try {
    const keys = await page.evaluate(() => window.CIP_DATA.map((r) => r.key));
    const failures = [];
    for (const key of keys) {
      await page.goto(INDEX_URL + '#/cartridge/' + key);
      const m = await page.evaluate(measure);
      for (let i = 0; i < m.boxes.length; i++) {
        const b = m.boxes[i];
        const pad = { x0: b.x0 - 0.1, y0: b.y0 - 0.1, x1: b.x1 + 0.1, y1: b.y1 + 0.1 };
        if (b.x0 < m.frame.x || b.x1 > m.frame.x + m.frame.w || b.y0 < m.frame.y || b.y1 > m.titleTop) failures.push(`${key} ${b.text}: outside the frame`);
        if (b.x0 < m.vb.x || b.x1 > m.vb.x + m.vb.w || b.y0 < m.vb.y || b.y1 > m.vb.y + m.vb.h) failures.push(`${key} ${b.text}: outside the viewBox`);
        for (const s of m.segs) if (hits(s, pad)) { failures.push(`${key} ${b.text}: touches the outline`); break; }
        for (let j = i + 1; j < m.boxes.length; j++) if (overlap(pad, m.boxes[j])) failures.push(`${key} ${b.text} overlaps ${m.boxes[j].text}`);
      }
    }
    assert.deepEqual(failures, []);
    assert.deepEqual(problems, []);
  } finally { await context.close(); }
});

test('real text widths do not exceed the estimate used for layout', async () => {
  const { page, context } = await openPage(browser);
  try {
    const keys = await page.evaluate(() => window.CIP_DATA.map((r) => r.key));
    for (const key of keys) {
      await page.goto(INDEX_URL + '#/cartridge/' + key);
      const over = await page.evaluate(() => [...document.querySelectorAll('svg.drawing text.dim-label')]
        .map((t) => ({ t: t.textContent, real: t.getBBox().width, est: t.textContent.length * 0.6 * 2.8 }))
        .filter((x) => x.real > x.est));
      assert.deepEqual(over, [], key);
    }
  } finally { await context.close(); }
});
