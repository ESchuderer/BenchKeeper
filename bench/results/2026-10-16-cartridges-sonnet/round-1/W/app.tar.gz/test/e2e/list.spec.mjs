import { test, before, after } from 'node:test';
import assert from 'node:assert/strict';
import { launch, openPage } from './helpers.mjs';

let browser;
before(async () => { browser = await launch(); });
after(async () => { await browser.close(); });

async function withPage(fn, opts) {
  const { page, context, problems } = await openPage(browser, opts);
  try { await fn(page); assert.deepEqual(problems, [], 'no page errors'); } finally { await context.close(); }
}

const listedNames = (page) => page.locator('#list-view tbody tr a').allTextContents();

test('start page: heading, 25 rows with name link, family and L3, and the count', () => withPage(async (page) => {
  assert.equal(await page.getByRole('heading', { level: 1, name: 'Cartridges' }).count(), 1);
  const rows = page.locator('#list-view tbody tr');
  assert.equal(await rows.count(), 25);
  const first = rows.first();
  assert.equal(await first.getByRole('link').textContent(), '223 Rem.');
  assert.equal((await first.locator('td').nth(1).textContent()).trim(), 'rimless');
  assert.equal((await first.locator('td').nth(2).textContent()).trim(), '44.7');
  assert.equal(await page.getByText('25 cartridges', { exact: true }).count(), 1);
}));

test('names are links with exactly the published text', () => withPage(async (page) => {
  for (const name of ['6,5 Creedmoor', '40 S.& W.', '300 Win. Mag.', '22 Win. Mag. R.F.']) {
    assert.equal(await page.getByRole('link', { name, exact: true }).count(), 1, name);
  }
  assert.equal(await page.getByRole('link', { name: '308 Win.', exact: true }).getAttribute('href'), '#/cartridge/308_win');
}));

test('Search and Family controls are labelled; family options in order', () => withPage(async (page) => {
  assert.equal(await page.getByLabel('Search').count(), 1);
  const sel = page.getByLabel('Family');
  assert.deepEqual(await sel.locator('option').allTextContents(), ['All', 'rimless', 'rimmed', 'belted', 'pistol', 'rimfire']);
  assert.equal(await sel.inputValue(), 'All');
}));

test('an alternative name finds the cartridge while typing', () => withPage(async (page) => {
  await page.getByLabel('Search').pressSequentially('7,62 x 51');
  assert.deepEqual(await listedNames(page), ['308 Win.']);
  assert.equal(await page.getByText('1 cartridges', { exact: true }).count(), 1);
}));

test('search ignores case and accepts a decimal point', () => withPage(async (page) => {
  await page.getByLabel('Search').fill('CREEDMOOR');
  assert.deepEqual(await listedNames(page), ['6,5 Creedmoor']);
  await page.getByLabel('Search').fill('6.5');
  assert.deepEqual(await listedNames(page), ['6,5 Creedmoor', '6,5 x 55 SE']);
}));

test('the list updates after each typed character', () => withPage(async (page) => {
  const input = page.getByLabel('Search');
  await input.pressSequentially('30');
  assert.deepEqual(await listedNames(page), ['308 Win.', '30-06 Spring.', '300 Win. Mag.']);
  await input.press('-');
  assert.deepEqual(await listedNames(page), ['30-06 Spring.']);
}));

test('family filter and count', () => withPage(async (page) => {
  await page.getByLabel('Family').selectOption('belted');
  assert.deepEqual(await listedNames(page), ['300 Win. Mag.', '7 mm Rem. Mag.']);
  await page.getByLabel('Family').selectOption('pistol');
  assert.equal(await page.getByText('6 cartridges', { exact: true }).count(), 1);
  await page.getByLabel('Family').selectOption('rimfire');
  await page.getByLabel('Search').fill('22');
  assert.deepEqual(await listedNames(page), ['22 Long Rifle', '22 Win. Mag. R.F.']);
  await page.getByLabel('Search').fill('');
  await page.getByLabel('Family').selectOption('All');
  assert.equal((await listedNames(page)).length, 25);
}));

test('nothing matches: empty list, 0 cartridges and a message', () => withPage(async (page) => {
  await page.getByLabel('Search').fill('zzz');
  assert.equal(await page.locator('#list-view tbody tr a').count(), 0);
  assert.equal(await page.getByText('0 cartridges', { exact: true }).count(), 1);
  assert.equal(await page.getByText('No cartridge matches').count(), 1);
}));
