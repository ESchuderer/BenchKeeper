import { test, before, after } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import { launch, openPage, INDEX_URL } from './helpers.mjs';

let browser;
before(async () => { browser = await launch(); });
after(async () => { await browser.close(); });

const pageCount = (pdf) => (pdf.toString('latin1').match(/\/Type\s*\/Page[^s]/g) || []).length;
const MM = 96 / 25.4;   // CSS px per mm

test('every cartridge prints on exactly one A4 portrait page', async () => {
  const { page, context, problems } = await openPage(browser, { colorScheme: 'dark' });
  try {
    const keys = await page.evaluate(() => window.CIP_DATA.map((r) => r.key));
    const bad = [];
    for (const key of keys) {
      await page.goto(INDEX_URL + '#/cartridge/' + key);
      await page.getByRole('img').first().waitFor();
      const pdf = await page.pdf({ format: 'A4', printBackground: false, preferCSSPageSize: true });
      const n = pageCount(pdf);
      if (n !== 1) bad.push(`${key}: ${n} pages`);
      if (key === '308_win') fs.mkdirSync('tmp', { recursive: true }), fs.writeFileSync('tmp/308_win.pdf', pdf);
    }
    assert.deepEqual(bad, []);
    assert.deepEqual(problems, []);
  } finally { await context.close(); }
});

test('print media: light, black on white, even when the system setting is dark', async () => {
  const { page, context } = await openPage(browser, { colorScheme: 'dark', media: 'print', url: INDEX_URL + '#/cartridge/308_win' });
  try {
    const colours = await page.evaluate(() => {
      const c = (sel, prop) => getComputedStyle(document.querySelector(sel))[prop];
      return {
        bodyBg: c('body', 'backgroundColor'), htmlBg: c('html', 'backgroundColor'),
        h1: c('h1', 'color'), dt: c('dl.facts dt', 'color'), dd: c('dl.facts dd', 'color'), th: c('table.values th', 'color'), td: c('table.values td', 'color'),
        label: c('svg.drawing .dim-label', 'fill'), title: c('svg.drawing .title-block text', 'fill'), outline: c('svg.drawing .case-line', 'stroke'),
        dim: c('svg.drawing .dim .dim', 'stroke'), svgBg: c('svg.drawing', 'backgroundColor'), footer: c('.print-footer', 'color'),
      };
    });
    const white = 'rgb(255, 255, 255)', black = 'rgb(0, 0, 0)';
    assert.equal(colours.bodyBg, white);
    assert.ok(colours.htmlBg === white || colours.htmlBg === 'rgba(0, 0, 0, 0)', colours.htmlBg);
    assert.equal(colours.svgBg, white);
    for (const k of ['h1', 'dt', 'dd', 'th', 'td', 'label', 'title', 'outline', 'dim', 'footer']) assert.equal(colours[k], black, k);
  } finally { await context.close(); }
});

test('print media: header with the name, drawing second, tables after; no interface', async () => {
  const { page, context } = await openPage(browser, { media: 'print', url: INDEX_URL + '#/cartridge/308_win' });
  try {
    const tops = await page.evaluate(() => ({
      h1: document.querySelector('h1').getBoundingClientRect().top,
      svg: document.querySelector('svg.drawing').getBoundingClientRect().top,
      tables: document.querySelector('.value-groups').getBoundingClientRect().top,
      footer: document.querySelector('.print-footer').getBoundingClientRect().top,
    }));
    assert.ok(tops.h1 < tops.svg && tops.svg < tops.tables && tops.tables < tops.footer, JSON.stringify(tops));
    assert.equal(await page.getByRole('button', { name: 'Print' }).isVisible(), false);
    assert.equal(await page.getByRole('link', { name: 'All cartridges' }).isVisible(), false);
    assert.equal(await page.locator('#list-view').isVisible(), false);
    assert.equal(await page.locator('#search').isVisible(), false);
    assert.equal(await page.locator('#family').isVisible(), false);
    assert.equal(await page.locator('.site-header').isVisible(), false);
    assert.equal((await page.locator('.print-footer').innerText()).trim(), 'Source: C.I.P. TDCC, revised 2008-09-23');
  } finally { await context.close(); }
});

test('print media: the drawing spans 190 mm and every label is at least 6 pt', async () => {
  const { page, context } = await openPage(browser, { media: 'print' });
  try {
    const keys = await page.evaluate(() => window.CIP_DATA.map((r) => r.key));
    for (const key of keys) {
      await page.goto(INDEX_URL + '#/cartridge/' + key);
      const m = await page.evaluate(() => {
        const svg = document.querySelector('svg.drawing');
        const vb = svg.viewBox.baseVal;
        const pxPerUnit = svg.getBoundingClientRect().width / vb.width;
        const sizes = [...svg.querySelectorAll('text')].map((t) => parseFloat(t.getAttribute('font-size')));
        return { width: svg.getBoundingClientRect().width, minPt: Math.min(...sizes) * pxPerUnit * 0.75 };
      });
      assert.ok(Math.abs(m.width - 190 * MM) < 1.5, `${key}: width ${m.width}px`);
      assert.ok(m.minPt >= 6, `${key}: smallest text ${m.minPt.toFixed(1)} pt`);
    }
  } finally { await context.close(); }
});

test('the PDF of one cartridge is not blank: it contains the drawing and the tables', async () => {
  const { page, context } = await openPage(browser, { url: INDEX_URL + '#/cartridge/308_win' });
  try {
    const pdf = await page.pdf({ format: 'A4', preferCSSPageSize: true });
    assert.ok(pdf.length > 20000, 'pdf size ' + pdf.length);
  } finally { await context.close(); }
});
