import { test, before, after } from 'node:test';
import assert from 'node:assert/strict';
import { launch, openPage, INDEX_URL } from './helpers.mjs';

let browser;
before(async () => { browser = await launch(); });
after(async () => { await browser.close(); });

const PHONE = { width: 360, height: 740 };

// WCAG contrast of two computed colours, evaluated in the page.
const CONTRAST_FN = `(() => {
  const parse = (c) => { const m = /rgba?\\(([^)]+)\\)/.exec(c); const p = m[1].split(/[ ,\\/]+/).filter(Boolean).map(Number); return { r: p[0], g: p[1], b: p[2], a: p.length > 3 ? p[3] : 1 }; };
  const lum = ({ r, g, b }) => { const f = (v) => { v /= 255; return v <= 0.03928 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4); }; return 0.2126 * f(r) + 0.7152 * f(g) + 0.0722 * f(b); };
  const backdrop = (el) => { for (let e = el; e; e = e.parentElement) { const c = parse(getComputedStyle(e).backgroundColor); if (c.a > 0.99) return c; } return parse('rgb(255,255,255)'); };
  window.__contrast = (fg, bg) => { const a = lum(parse(fg)), b = lum(parse(bg)); return (Math.max(a, b) + 0.05) / (Math.min(a, b) + 0.05); };
  window.__textContrast = (sel) => { const el = document.querySelector(sel); const cs = getComputedStyle(el); return window.__contrast(cs.color, (() => { const b = backdrop(el); return 'rgb(' + b.r + ',' + b.g + ',' + b.b + ')'; })()); };
  window.__svgContrast = (sel, prop) => { const el = document.querySelector(sel); const svg = document.querySelector('svg.drawing'); const cs = getComputedStyle(el); const bg = getComputedStyle(svg).backgroundColor; return window.__contrast(cs[prop], bg); };
})()`;

async function open(opts) {
  const o = await openPage(browser, opts);
  await o.page.evaluate(CONTRAST_FN);
  return o;
}

test('360 px wide: no horizontal scroll on the list and on every detail view', async () => {
  const { page, context, problems } = await open({ viewport: PHONE });
  try {
    const noScroll = () => page.evaluate(() => document.documentElement.scrollWidth <= document.documentElement.clientWidth);
    assert.equal(await noScroll(), true, 'list');
    const keys = await page.evaluate(() => window.CIP_DATA.map((r) => r.key));
    for (const key of keys) {
      await page.goto(INDEX_URL + '#/cartridge/' + key);
      assert.equal(await noScroll(), true, key);
      const w = await page.locator('svg.drawing').evaluate((e) => e.getBoundingClientRect().width);
      assert.ok(w <= 360 && w > 250, `${key}: drawing width ${w}`);
    }
    assert.deepEqual(problems, []);
  } finally { await context.close(); }
});

test('360 px wide: touch targets of Print, All cartridges, name links and controls are at least 44 px high', async () => {
  const { page, context } = await open({ viewport: PHONE, url: INDEX_URL + '#/cartridge/308_win' });
  try {
    const height = (loc) => loc.evaluate((e) => e.getBoundingClientRect().height);
    assert.ok(await height(page.getByRole('button', { name: 'Print' })) >= 44);
    assert.ok(await height(page.getByRole('link', { name: 'All cartridges' })) >= 44);
    await page.getByRole('link', { name: 'All cartridges' }).click();
    await page.getByRole('heading', { level: 1, name: 'Cartridges' }).waitFor();
    assert.ok(await height(page.getByLabel('Search')) >= 44);
    assert.ok(await height(page.getByLabel('Family')) >= 44);
    assert.ok(await height(page.locator('#list-view tbody tr').first().getByRole('link')) >= 44);
  } finally { await context.close(); }
});

for (const scheme of ['light', 'dark']) {
  test(`${scheme} scheme: page colours follow the system setting and keep contrast >= 4.5`, async () => {
    const { page, context } = await open({ colorScheme: scheme, url: INDEX_URL + '#/cartridge/308_win' });
    try {
      const bg = await page.evaluate(() => getComputedStyle(document.body).backgroundColor);
      const m = bg.match(/\d+/g).map(Number);
      const luminance = (0.2126 * m[0] + 0.7152 * m[1] + 0.0722 * m[2]) / 255;
      if (scheme === 'dark') assert.ok(luminance < 0.25, 'dark background: ' + bg); else assert.ok(luminance > 0.85, 'light background: ' + bg);
      for (const sel of ['body', '#detail-view h1', '#detail-view dt', '#detail-view dd', 'table.values th', 'table.values td', '.toolbar .button', '#detail-view dd a', '.site-title']) {
        const c = await page.evaluate((s) => window.__textContrast(s), sel);
        assert.ok(c >= 4.5, `${scheme} ${sel}: contrast ${c.toFixed(2)}`);
      }
      for (const [sel, prop] of [['svg.drawing .dim-label', 'fill'], ['svg.drawing .case-line', 'stroke'], ['svg.drawing .hatch-line', 'stroke'], ['svg.drawing .dim .dim', 'stroke'], ['svg.drawing .title-block text', 'fill']]) {
        const c = await page.evaluate(([s, p]) => window.__svgContrast(s, p), [sel, prop]);
        assert.ok(c >= 4.5, `${scheme} drawing ${sel}: contrast ${c.toFixed(2)}`);
      }
      await page.getByRole('link', { name: 'All cartridges' }).click();
      await page.getByRole('heading', { level: 1, name: 'Cartridges' }).waitFor();
      for (const sel of ['#list-view h1', '#list-view tbody a', '#count', 'label[for=search]', '#list-view th', '#list-view td']) {
        const c = await page.evaluate((s) => window.__textContrast(s), sel);
        assert.ok(c >= 4.5, `${scheme} list ${sel}: contrast ${c.toFixed(2)}`);
      }
    } finally { await context.close(); }
  });
}

test('numbers use tabular figures and are right aligned; no web fonts', async () => {
  const { page, context } = await open({ url: INDEX_URL });
  try {
    const list = await page.locator('#list-view tbody td.num').first().evaluate((e) => { const c = getComputedStyle(e); return [c.fontVariantNumeric, c.textAlign]; });
    assert.match(list[0], /tabular-nums/);
    assert.equal(list[1], 'right');
    await page.goto(INDEX_URL + '#/cartridge/308_win');
    const val = await page.locator('table.values td.num').first().evaluate((e) => { const c = getComputedStyle(e); return [c.fontVariantNumeric, c.textAlign]; });
    assert.match(val[0], /tabular-nums/);
    assert.equal(val[1], 'right');
    assert.equal(await page.evaluate(() => document.fonts.size), 0, 'no @font-face loaded');
  } finally { await context.close(); }
});

test('desktop: the page is a calm single column with a readable measure', async () => {
  const { page, context } = await open({ viewport: { width: 1400, height: 900 }, url: INDEX_URL + '#/cartridge/308_win' });
  try {
    const w = await page.locator('main').evaluate((e) => e.getBoundingClientRect().width);
    assert.ok(w <= 1100, 'main is not stretched across the screen: ' + w);
  } finally { await context.close(); }
});
