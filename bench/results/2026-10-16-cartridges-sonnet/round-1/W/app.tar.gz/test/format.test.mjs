import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import { createRequire } from 'node:module';

const require = createRequire(import.meta.url);
const F = require('../js/format.js');
const records = fs.readFileSync(new URL('../data/cartridges.jsonl', import.meta.url), 'utf8')
  .split('\n').filter(Boolean).map((l) => JSON.parse(l));
const rec = (key) => records.find((r) => r.key === key);

test('numbers are shown as published, with decimal point and no grouping', () => {
  assert.equal(F.formatNumber(51.18), '51.18');
  assert.equal(F.formatNumber(4150), '4150');
  assert.equal(F.formatNumber(4300.0), '4300');
  assert.equal(F.formatNumber(0.1), '0.1');
  assert.equal(F.formatNumber(-0.2), '-0.2');
});

test('angles: bare degrees, and degrees minutes seconds with zero parts kept', () => {
  assert.equal(F.formatAngle(40), '40°');
  assert.equal(F.formatAngle(35.0), '35°');
  assert.equal(F.formatAngle({ degrees: 39, minutes: 59, seconds: 49 }), `39°59'49"`);
  assert.equal(F.formatAngle({ degrees: 34, minutes: 30, seconds: 0 }), `34°30'0"`);
  assert.equal(F.formatAngle({ degrees: 0, minutes: 47, seconds: 33 }), `0°47'33"`);
});

test('which fields are angles', () => {
  for (const f of ['alpha', 'alpha1', 'beta', 'delta', 'i']) assert.equal(F.isAngleField(f), true, f);
  for (const f of ['L1', 'deltaL', 'R1', 'eMin']) assert.equal(F.isAngleField(f), false, f);
});

test('units per field', () => {
  assert.equal(F.unitFor('L3'), 'mm');
  assert.equal(F.unitFor('R1'), 'mm');
  assert.equal(F.unitFor('Q'), 'mm²');
  assert.equal(F.unitFor('Pmax'), 'bar');
  assert.equal(F.unitFor('PK'), 'bar');
  assert.equal(F.unitFor('PE'), 'bar');
  assert.equal(F.unitFor('EE'), 'J');
  assert.equal(F.unitFor('M'), 'g');
  assert.equal(F.unitFor('N'), '');
  assert.equal(F.unitFor('alpha'), 'deg');
  assert.equal(F.unitFor('i'), 'deg');
  assert.equal(F.unitFor('deltaL'), 'mm');
});

test('symbols: the field name, except the listed renames', () => {
  const renamed = { eMin: 'e min', r1Min: 'r1 min', r1Max: 'r1 max', alpha: 'α', alpha1: 'α1',
    beta: 'β', delta: 'δ', deltaL: 'delta L', L3PlusG: 'L3 + G' };
  for (const [k, v] of Object.entries(renamed)) assert.equal(F.symbolFor(k), v);
  for (const k of ['L1', 'R1', 'Pmax', 'PK', 'N', 'Q', 'G1', 'r2', 'h']) assert.equal(F.symbolFor(k), k);
});

test('a tolerance sits after its value, separated by a space', () => {
  assert.equal(F.formatWithTolerance('L1', 39.62, -0.2), '39.62 -0.2');
  assert.equal(F.formatWithTolerance('R', 1.09, -0.18), '1.09 -0.18');
  assert.equal(F.formatWithTolerance('L3', 51.18, undefined), '51.18');
  assert.equal(F.formatWithTolerance('alpha', 40, undefined), '40°');
});

test('identifying facts of a record', () => {
  const f = F.buildFacts(rec('308_win'));
  const get = (label) => f.find((x) => x.label === label).text;
  assert.equal(get('Alternative names'), '308 Winchester, 7,62 x 51');
  assert.equal(get('Family'), 'rimless');
  assert.equal(get('Category'), 'rifle');
  assert.equal(get('Primer type'), 'lr');
  assert.equal(get('C.I.P. table'), 'I');
  assert.equal(get('Country'), 'US');
  assert.equal(get('Published'), '1984-06-14');
  assert.equal(get('Revised'), '2008-09-23');
  assert.equal(get('Pressure method'), 'Transducer');
});

test('missing alternative names and capacity', () => {
  const f = F.buildFacts(rec('223_rem'));
  assert.equal(f.find((x) => x.label === 'Alternative names').text, '—');
  const g = F.buildFacts(rec('7_x_64'));
  assert.equal(g.find((x) => x.label === 'Water capacity').text, 'not published');
  assert.equal(g.find((x) => x.label === 'Water capacity').link, undefined);
});

test('water capacity with note and source link', () => {
  const cap = F.buildFacts(rec('223_rem')).find((x) => x.label === 'Water capacity');
  assert.equal(cap.text, '30.5 gr H2O');
  assert.equal(cap.note, 'kwk 31, Wikipedia 28.8; the mean');
  assert.deepEqual(cap.link, { text: 'kwk', href: 'http://kwk.us/cases.html' });
  const noNote = F.buildFacts(rec('243_win')).find((x) => x.label === 'Water capacity');
  assert.equal(noNote.note, undefined);
});

// ---- tables -------------------------------------------------------------

function leafFields(obj) {
  // Independent count: numeric leaves and degree/minute/second objects, minus tolerance fields.
  const out = [];
  for (const [section, fields] of Object.entries(obj)) {
    for (const [name, v] of Object.entries(fields)) {
      if (name.endsWith('Tol')) continue;
      out.push(section + '.' + name);
    }
  }
  return out;
}

const rowsOf = (group) => group.flatMap((s) => s.rows);
const section = (group, title) => group.find((s) => s.title === title);

test('tables: section titles of a bottleneck rifle cartridge', () => {
  const t = F.buildTables(rec('223_rem'));
  assert.deepEqual(t.cartridge.map((s) => s.title).sort(),
    ['Case head', 'Collar', 'Junction cone', 'Lengths', 'Miscellaneous', 'Powder chamber', 'Pressures', 'Projectile']);
  assert.deepEqual(t.chamber.map((s) => s.title).sort(),
    ['Barrel', 'Breech', 'Collar', 'Grooves', 'Junction cone', 'Lengths', 'Powder chamber', 'Rifling']);
});

test('tables: an empty section is not shown', () => {
  const t = F.buildTables(rec('9_mm_luger'));
  assert.equal(t.cartridge.find((s) => s.title === 'Junction cone'), undefined);
  assert.equal(t.chamber.find((s) => s.title === 'Junction cone'), undefined);
});

test('tables: every value appears exactly once, tolerances never as rows', () => {
  for (const r of records) {
    const t = F.buildTables(r);
    assert.equal(rowsOf(t.cartridge).length, leafFields(r.cartridge).length, r.key + ' cartridge');
    assert.equal(rowsOf(t.chamber).length, leafFields(r.chamber).length, r.key + ' chamber');
    for (const row of [...rowsOf(t.cartridge), ...rowsOf(t.chamber)]) {
      assert.ok(!/Tol$/.test(row.field), row.field);
    }
  }
});

test('tables: values, units and tolerances of 308 Win.', () => {
  const t = F.buildTables(rec('308_win'));
  const row = (g, sec, field) => section(t[g], sec).rows.find((x) => x.field === field);
  assert.deepEqual(row('cartridge', 'Lengths', 'L3'), { field: 'L3', symbol: 'L3', value: '51.18', unit: 'mm' });
  assert.equal(row('cartridge', 'Lengths', 'L1').value, '39.62 -0.2');
  assert.equal(row('cartridge', 'Pressures', 'Pmax').value, '4150');
  assert.equal(row('cartridge', 'Pressures', 'Pmax').unit, 'bar');
  assert.equal(row('cartridge', 'Junction cone', 'alpha').value, '40°');
  assert.equal(row('cartridge', 'Junction cone', 'alpha').symbol, 'α');
  assert.equal(row('chamber', 'Grooves', 'Q').unit, 'mm²');
  assert.equal(row('chamber', 'Rifling', 'alpha1').value, `71°25'59"`);
});

test('tables: count N has an empty unit; angle forms of other records', () => {
  const t = F.buildTables(rec('223_rem'));
  const n = section(t.chamber, 'Grooves').rows.find((x) => x.field === 'N');
  assert.equal(n.value, '6');
  assert.equal(n.unit, '');
  const se = F.buildTables(rec('6_5_x_55_se'));
  assert.equal(section(se.cartridge, 'Junction cone').rows.find((x) => x.field === 'alpha').value, `50°35'2"`);
  const j = F.buildTables(rec('30_06_spring'));
  assert.equal(section(j.chamber, 'Junction cone').rows.find((x) => x.field === 'alpha').value, `34°30'0"`);
  const o = F.buildTables(rec('270_win'));
  assert.equal(section(o.chamber, 'Rifling').rows.find((x) => x.field === 'i').value, `0°47'33"`);
  const m = F.buildTables(rec('7_mm_rem_mag'));
  assert.equal(section(m.chamber, 'Rifling').rows.find((x) => x.field === 'i').value, '3°');
});

test('tables: 22 Long Rifle rim tolerance sits beside R', () => {
  const t = F.buildTables(rec('22_long_rifle'));
  assert.equal(section(t.cartridge, 'Case head').rows.find((x) => x.field === 'R').value, '1.09 -0.18');
});

test('tables: renamed symbols appear, raw names do not', () => {
  const t = F.buildTables(rec('223_rem'));
  const syms = rowsOf(t.cartridge).map((r) => r.symbol);
  for (const s of ['e min', 'r1 min', 'α', 'β', 'δ', 'delta L', 'L3 + G']) assert.ok(syms.includes(s), s);
  for (const s of ['eMin', 'alpha', 'beta', 'delta', 'r1Min']) assert.ok(!syms.includes(s), s);
  const c = rowsOf(t.chamber).map((r) => r.symbol);
  assert.ok(c.includes('r1 max') && c.includes('α1'));
});

test('angles tolerate partial and malformed values', () => {
  assert.equal(F.formatAngle({ degrees: 40 }), '40°');
  assert.equal(F.formatAngle({ degrees: 40, minutes: 5 }), `40°5'`);
  assert.equal(F.formatAngle(null), '');
});

test('tables skip fields that hold no usable value', () => {
  const r = JSON.parse(JSON.stringify(rec('308_win')));
  r.cartridge.junctionCone.alpha = null;
  r.cartridge.lengths.L6 = 'n/a';
  const t = F.buildTables(r);
  const rows = rowsOf(t.cartridge).map((x) => x.field);
  assert.ok(!rows.includes('alpha') && !rows.includes('L6'));
  assert.ok(rows.includes('L3'));
});
