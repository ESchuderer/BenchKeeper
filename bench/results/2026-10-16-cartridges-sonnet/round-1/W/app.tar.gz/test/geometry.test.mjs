import test from 'node:test';
import assert from 'node:assert/strict';
import { load, records, rec, distToPolyline } from './helpers/records.mjs';

const G = load('geometry');
const near = (poly, r, z, tol = 0.006) =>
  assert.ok(distToPolyline(poly, r, z) <= tol, `no outline point near (r=${r}, z=${z}); nearest ${distToPolyline(poly, r, z).toFixed(4)}`);

// ---- 4.1 rim type and head face -------------------------------------------

test('rim type classification', () => {
  assert.equal(G.rimType(rec('308_win')), 'rimless');
  assert.equal(G.rimType(rec('223_rem')), 'rimless');
  assert.equal(G.rimType(rec('9_3_x_74_r')), 'rimmed');
  assert.equal(G.rimType(rec('300_win_mag')), 'belted');
  assert.equal(G.rimType(rec('22_long_rifle')), 'rimfire');
  assert.equal(G.rimType(rec('45_auto')), 'rimless');
  assert.equal(G.rimType(rec('38_special')), 'rimmed');
});

test('rim type thresholds: >= 1.05 rimmed, < 0.98 rebated, otherwise rimless', () => {
  const mk = (R1, P1) => ({ family: 'rimless', cartridge: { caseHead: { R1 }, powderChamber: { P1 } } });
  assert.equal(G.rimType(mk(10.5, 10)), 'rimmed');
  assert.equal(G.rimType(mk(10.49, 10)), 'rimless');
  assert.equal(G.rimType(mk(9.79, 10)), 'rebated');
  assert.equal(G.rimType(mk(9.8, 10)), 'rimless');
});

test('308 Win.: chamfered head face and rim edge', () => {
  const m = G.buildModel(rec('308_win'));
  // c = min(0.38 tan 35°, R1/4) = 0.2661 -> head face ends at r = 6.005 - 0.2661
  near(m.outer, 5.739, 0);
  near(m.outer, 6.005, 0.38);
  near(m.outer, 6.005, 1.37);
  assert.deepEqual(m.outer[0], { r: 0, z: 0 });
});

test('22 Long Rifle: half-round rim edge of radius min(R/2, (R1-P1)/2)', () => {
  const m = G.buildModel(rec('22_long_rifle'));
  assert.ok(Math.abs(m.rim.halfRoundRadius - 0.545) < 1e-9);
  near(m.outer, 3.53, 0.545);                // outermost point at R1/2, mid-rim
  const top = Math.max(...m.outer.map((p) => p.r));
  assert.ok(Math.abs(top - 3.53) < 1e-9, 'nothing sticks out further than R1/2');
  // a point on the arc: centre (r=2.985, z=0.545), 45 degrees
  near(m.outer, 2.985 + 0.545 * Math.cos(Math.PI / 4), 0.545 - 0.545 * Math.sin(Math.PI / 4), 0.003);
});

test('square corner when beta or f is missing on a non-rimfire case', () => {
  const r = JSON.parse(JSON.stringify(rec('308_win')));
  delete r.cartridge.caseHead.f;
  const m = G.buildModel(r);
  near(m.outer, 6.005, 0);
  near(m.outer, 6.005, 1.37);
  assert.ok(m.outer.every((p) => !(p.z === 0 && p.r > 6.0 && p.r < 6.005)), 'no chamfer');
});

test('chamfer size is limited to R1/4', () => {
  const r = JSON.parse(JSON.stringify(rec('308_win')));
  r.cartridge.caseHead.f = 10; r.cartridge.caseHead.R = 12; r.cartridge.caseHead.beta = 80;
  const m = G.buildModel(r);
  near(m.outer, 6.005 - 12.01 / 4, 0);
});

// ---- 4.2 groove, belt and step ---------------------------------------------

test('308 Win.: extractor groove and ramp to the body', () => {
  const m = G.buildModel(rec('308_win'));
  near(m.outer, 5.195, 1.37);   // in to E1/2 at z = R
  near(m.outer, 5.195, 2.77);   // along the floor to R + e min
  near(m.outer, 5.98, 3.85);    // ramp out to P1/2 at z = E
  near(m.outer, 5.6, 2.0, 1);   // sanity: still in the groove area
  assert.deepEqual(m.bodyStart, { r: 5.98, z: 3.85 });
  // the ramp is straight: midpoint of floor end and ramp end lies on the outline
  near(m.outer, (5.195 + 5.98) / 2, (2.77 + 3.85) / 2, 0.003);
});

test('300 Win. Mag.: belted ramp at delta to the axis, belt to E, step in to P1/2', () => {
  const m = G.buildModel(rec('300_win_mag'));
  const zRamp = 1.27 + 0.94 + (6.755 - 6.035) / Math.tan(35 * Math.PI / 180);   // 3.238
  near(m.outer, 6.035, 2.21);          // floor end
  near(m.outer, 6.755, zRamp);         // ramp reaches the belt
  near(m.outer, 6.755, 5.59);          // belt runs to z = E
  near(m.outer, 6.515, 5.59);          // then steps in to P1/2
  assert.ok(Math.abs(m.beltRampEnd - zRamp) < 1e-9);
  assert.deepEqual(m.bodyStart, { r: 6.515, z: 5.59 });
});

test('9,3 x 74 R: rimmed case without a groove steps in at z = R', () => {
  const m = G.buildModel(rec('9_3_x_74_r'));
  near(m.outer, 6.675, 1.4);
  near(m.outer, 5.95, 1.4);
  assert.deepEqual(m.bodyStart, { r: 5.95, z: 1.4 });
  assert.deepEqual(m.notes.filter((n) => /groove/i.test(n)), [], 'a rimmed case has no groove note');
});

test('rimless case without E1: step in, with a note naming the missing value', () => {
  const r = JSON.parse(JSON.stringify(rec('308_win')));
  delete r.cartridge.caseHead.E1;
  const m = G.buildModel(r);
  assert.deepEqual(m.bodyStart, { r: 5.98, z: 1.37 });
  assert.ok(m.notes.some((n) => /groove/i.test(n) && /E1/.test(n)), m.notes.join('|'));
});

test('groove without e min is not drawn and says so', () => {
  const r = JSON.parse(JSON.stringify(rec('308_win')));
  delete r.cartridge.caseHead.eMin;
  const m = G.buildModel(r);
  assert.deepEqual(m.bodyStart, { r: 5.98, z: 1.37 });
  assert.ok(m.notes.some((n) => /groove/i.test(n) && /e min/.test(n)), m.notes.join('|'));
});

test('belt ramp ending beyond E is dropped with a note', () => {
  const r = JSON.parse(JSON.stringify(rec('300_win_mag')));
  r.cartridge.caseHead.E = 3.0;
  const m = G.buildModel(r);
  assert.equal(m.beltRampEnd, undefined);
  assert.ok(m.notes.some((n) => /belt/i.test(n)), m.notes.join('|'));
});

// ---- 4.3 body, shoulder, neck, fillets -------------------------------------

const clone = (r) => JSON.parse(JSON.stringify(r));

test('308 Win.: mouth point exact, shoulder corners within fillet deviation', () => {
  const m = G.buildModel(rec('308_win'));
  near(m.outer, 4.36, 51.18, 0.0005);
  near(m.outer, 5.765, 39.62, 0.05);
  near(m.outer, 4.36, 43.48, 0.06);
  // the straight part of the shoulder: midpoint of the published points
  near(m.outer, (5.765 + 4.36) / 2, (39.62 + 43.48) / 2, 0.003);
  assert.deepEqual(m.corners.shoulderStart, { r: 5.765, z: 39.62 });
  assert.deepEqual(m.corners.shoulderEnd, { r: 4.36, z: 43.48 });
  assert.deepEqual(m.mouth, { r: 4.36, z: 51.18 });
  assert.equal(m.isBottleneck, true);
});

test('9 mm Luger: straight case, body tapers from P1/2 at E to H2/2 at L3', () => {
  const m = G.buildModel(rec('9_mm_luger'));
  assert.equal(m.isBottleneck, false);
  near(m.outer, 4.965, 2.98, 0.0005);
  near(m.outer, 4.825, 19.15, 0.0005);
  near(m.outer, (4.965 + 4.825) / 2, (2.98 + 19.15) / 2, 0.0005);
  assert.deepEqual(m.notes.filter((n) => /shoulder|fillet|r1|r2/i.test(n)), []);
});

test('corner rounding: tangent arcs whose apex deviation is r (sec(theta/2) - 1)', () => {
  const m = G.buildModel(rec('223_rem'));
  const A = { r: 9.0 / 2, z: 36.52 }, B = { r: 6.43 / 2, z: 39.55 }, S = { r: 4.79, z: 3.13 };
  const turn = (p0, p1, p2) => {
    const a1 = Math.atan2(p1.r - p0.r, p1.z - p0.z), a2 = Math.atan2(p2.r - p1.r, p2.z - p1.z);
    return Math.abs(a1 - a2);
  };
  const C = { r: 6.43 / 2, z: 44.7 };
  const devA = 0.64 * (1 / Math.cos(turn(S, A, B) / 2) - 1);
  const devB = 2.54 * (1 / Math.cos(turn(A, B, C) / 2) - 1);
  assert.ok(Math.abs(distToPolyline(m.outer, A.r, A.z) - devA) < 0.002, 'body-side corner');
  assert.ok(Math.abs(distToPolyline(m.outer, B.r, B.z) - devB) < 0.002, 'neck-side corner');
  assert.deepEqual(m.fillets.map((f) => [f.symbol, f.radius, f.clamped]), [['r1 min', 0.64, false], ['r2', 2.54, false]]);
});

test('6,5 x 55 SE: shoulder follows the published points, not alpha', () => {
  const m = G.buildModel(rec('6_5_x_55_se'));
  near(m.outer, (5.52 + 3.8) / 2, (43.49 + 47.13) / 2, 0.003);
  near(m.outer, 5.52, 43.49, 0.1);
  near(m.outer, 3.8, 47.13, 0.1);
});

test('17 HMR: no fillet values, corners stay sharp and notes name r1 min and r2', () => {
  const m = G.buildModel(rec('17_hmr'));
  near(m.outer, 6.15 / 2, 22.2, 0.0005);
  near(m.outer, 4.9 / 2, 23.54, 0.0005);
  assert.deepEqual(m.fillets, []);
  const text = m.notes.join(' | ');
  assert.match(text, /r1 min/);
  assert.match(text, /r2/);
});

test('a fillet that cannot fit is reduced and says so', () => {
  const r = clone(rec('308_win'));
  r.cartridge.junctionCone.r2 = 50;
  const m = G.buildModel(r);
  const f = m.fillets.find((x) => x.symbol === 'r2');
  assert.equal(f.clamped, true);
  assert.ok(f.radius < 50 && f.radius > 0);
  assert.ok(m.notes.some((n) => /r2/.test(n) && /reduced/i.test(n)), m.notes.join('|'));
});

test('a case without alpha, L1 or L2 is straight; a partly published shoulder is noted', () => {
  const r = clone(rec('308_win'));
  delete r.cartridge.junctionCone.alpha;
  const m = G.buildModel(r);
  assert.equal(m.isBottleneck, false);
  near(m.outer, 4.36, 51.18, 0.0005);
  assert.ok(m.notes.some((n) => /shoulder/i.test(n) && /α/.test(n)), m.notes.join('|'));
});

test('every record builds an outline ending at the mouth', () => {
  for (const r of records) {
    const m = G.buildModel(r);
    const last = m.outer[m.outer.length - 1];
    assert.ok(Math.abs(last.z - r.cartridge.lengths.L3) < 1e-9, r.key);
    assert.ok(Math.abs(last.r - r.cartridge.collar.H2 / 2) < 1e-9, r.key);
    for (let i = 1; i < m.outer.length; i++) assert.ok(m.outer[i].z >= m.outer[i - 1].z - 1e-9, r.key + ' z monotone');
  }
});

// ---- 4.4 walls, solid head, primer pocket ------------------------------------

// Independent point-in-polygon (ray casting) in the (z, r) plane.
function inside(poly, r, z) {
  let c = false;
  for (let i = 0, j = poly.length - 1; i < poly.length; j = i++) {
    const a = poly[i], b = poly[j];
    if ((a.r > r) !== (b.r > r) && z < ((b.z - a.z) * (r - a.r)) / (b.r - a.r) + a.z) c = !c;
  }
  return c;
}

test('308 Win.: walls, inner line, solid head and pocket', () => {
  const m = G.buildModel(rec('308_win'));
  assert.ok(Math.abs(m.walls.tn - 0.435) < 1e-9);
  assert.ok(Math.abs(m.walls.tb - 0.6) < 1e-9);
  assert.equal(m.walls.heeled, false);
  near(m.inner, 5.38, 3.85, 0.0005);         // P1/2 - tb at the body start
  near(m.inner, 5.165, 39.62, 0.0005);       // P2/2 - tb at L1
  near(m.inner, 3.925, 43.48, 0.0005);       // H1/2 - tn at L2
  near(m.inner, 3.925, 51.18, 0.0005);       // H2/2 - tn at the mouth (= G1/2)
  assert.ok(Math.abs(m.head.w - 4.8) < 1e-9);
  assert.deepEqual(m.head.pocket, { diameter: 5.33, depth: 3.3 });
});

test('solid head w: groove, pocket and belt terms', () => {
  assert.ok(Math.abs(G.buildModel(rec('223_rem')).head.w - 4.54) < 1e-9);       // pocket 3.04 + 1.5
  assert.ok(Math.abs(G.buildModel(rec('22_long_rifle')).head.w - 2.5) < 1e-9);  // floor of 2.5
  const belted = G.buildModel(rec('300_win_mag'));
  assert.ok(Math.abs(belted.head.w - 4.8) < 1e-9);
  const r = clone(rec('308_win'));
  r.annotations.primerType = 'rimfire';        // no pocket: w comes from E + tb = 4.45
  assert.ok(Math.abs(G.buildModel(r).head.w - 4.45) < 1e-9);
  const b = clone(rec('300_win_mag'));
  b.annotations.primerType = 'rimfire';        // belt ramp end + tb = 3.238.. + 0.6
  const zRamp = 1.27 + 0.94 + 0.72 / Math.tan(35 * Math.PI / 180);
  assert.ok(Math.abs(G.buildModel(b).head.w - Math.max(2.5, 0.25 * 6.515, zRamp + 0.6)) < 1e-9);
});

test('primer pockets by primer type', () => {
  const pocket = (k) => G.buildModel(rec(k)).head.pocket;
  assert.deepEqual(pocket('223_rem'), { diameter: 4.45, depth: 3.04 });        // sr
  assert.deepEqual(pocket('9_mm_luger'), { diameter: 4.45, depth: 3.04 });     // sp
  assert.deepEqual(pocket('357_magnum'), { diameter: 4.45, depth: 3.04 });     // spm
  assert.deepEqual(pocket('45_auto'), { diameter: 5.33, depth: 3.04 });        // lp
  assert.deepEqual(pocket('44_rem_mag'), { diameter: 5.33, depth: 3.04 });     // lpm
  assert.deepEqual(pocket('243_win'), { diameter: 5.33, depth: 3.3 });         // lr
  assert.deepEqual(pocket('338_lapua_mag'), { diameter: 5.33, depth: 3.3 });   // lrm
  assert.equal(pocket('22_long_rifle'), null);
  assert.equal(pocket('17_hmr'), null);
});

test('9 mm Luger: a straight case blends from tb at the body start to tn at the mouth', () => {
  const m = G.buildModel(rec('9_mm_luger'));
  assert.ok(Math.abs(m.walls.tn - 0.31) < 1e-9);
  near(m.inner, 4.965 - 0.6, 2.98, 0.0005);
  near(m.inner, 4.825 - 0.31, 19.15, 0.0005);
  assert.deepEqual(m.inner.length, 2);
});

test('22 Long Rifle: heeled case keeps wall tb along the whole body', () => {
  const m = G.buildModel(rec('22_long_rifle'));
  assert.equal(m.walls.heeled, true);
  assert.ok(Math.abs(m.walls.tb - 0.6) < 1e-9);
  near(m.inner, 2.87 - 0.6, 1.09, 0.0005);
  near(m.inner, 2.86 - 0.6, 15.57, 0.0005);
});

test('wall limit 0.35 P1/2 applies to tb', () => {
  const r = clone(rec('308_win'));
  r.cartridge.collar.H2 = 6.0; r.cartridge.collar.H1 = 6.0;   // tn = (6 - 7.85)/2 < 0 -> tb = 0.6 anyway
  r.cartridge.powderChamber.P1 = 1.0;                           // 0.35 * 0.5 = 0.175
  assert.ok(Math.abs(G.buildModel(r).walls.tb - 0.175) < 1e-9);
});

test('section hatch region: head and wall are solid, cavity and pocket are not', () => {
  const m = G.buildModel(rec('308_win'));
  assert.ok(inside(m.hatch, 1, 4.0), 'solid head');
  assert.ok(inside(m.hatch, 5.6, 20), 'wall');
  assert.ok(inside(m.hatch, 4.1, 48), 'neck wall');
  assert.ok(!inside(m.hatch, 3, 20), 'cavity');
  assert.ok(!inside(m.hatch, 1, 1), 'primer pocket');
  assert.ok(!inside(m.hatch, 2, 6), 'cavity just above the head');
  assert.ok(!inside(m.hatch, 6.2, 20), 'outside the case');
});

test('rimfire section has a solid head without pocket', () => {
  const m = G.buildModel(rec('22_long_rifle'));
  assert.ok(inside(m.hatch, 1, 1));
  assert.ok(!inside(m.hatch, 1, 8));
});

test('missing G1: no walls, no hatch, a note names G1', () => {
  const r = clone(rec('308_win'));
  delete r.cartridge.projectile.G1;
  const m = G.buildModel(r);
  assert.equal(m.hatch, null);
  assert.ok(m.notes.some((n) => /section/i.test(n) && /G1/.test(n)), m.notes.join('|'));
});

test('unknown primer type: no pocket and a note', () => {
  const r = clone(rec('308_win'));
  delete r.annotations.primerType;
  const m = G.buildModel(r);
  assert.equal(m.head.pocket, null);
  assert.ok(m.notes.some((n) => /pocket/i.test(n) && /primer/i.test(n)), m.notes.join('|'));
});

// ---- 4.5 bullet --------------------------------------------------------------

const close = (a, b, tol = 0.001) => assert.ok(Math.abs(a - b) <= tol, `${a} != ${b} (±${tol})`);

test('308 Win.: pointy bullet seating, cylinder, meplat and tangent ogive', () => {
  const b = G.buildModel(rec('308_win')).bullet;
  assert.equal(b.shape, 'pointy');
  close(b.s, 7.85);
  close(b.zb, 43.33);
  close(b.zc, 54.446);
  close(b.meplat, 1.27);
  close(b.rho, 43.8976, 0.001);
  // the nose starts at the shank radius on the cylinder end and ends at the meplat edge at the tip
  near(b.nose, 3.925, 54.446, 0.0005);
  near(b.nose, 0.635, 71.12, 0.0005);
  // a point on the ogive 8 mm past the start of the nose
  near(b.nose, 3.18988, 54.446 + 8, 0.003);
  // exposed outline: from the mouth along the shank, nose, meplat face to the axis
  assert.deepEqual(b.exposed[0], { r: 3.925, z: 51.18 });
  assert.deepEqual(b.exposed[b.exposed.length - 1], { r: 0, z: 71.12 });
  near(b.exposed, 3.925, 54.446, 0.0005);
  // section: seated part is inside the case, base at zb
  assert.deepEqual(b.full[0], { r: 0, z: 43.33 });
  assert.ok(inside(b.full, 1, 45), 'seated part');
  assert.ok(inside(b.full, 1, 60), 'exposed part');
  assert.ok(!inside(b.full, 1, 40), 'below the base');
});

test('seating depth by shape and category', () => {
  const s = (k) => G.buildModel(rec(k)).bullet;
  close(s('9_mm_luger').s, 0.4 * 9.03);          // rounded, pistol
  close(s('9_mm_luger').zb, 15.538);
  close(s('40_s_w').s, 0.4 * 10.17);             // flat, pistol
  close(s('357_magnum').s, 0.6 * 9.12);          // semi_wadcutter
  close(s('22_long_rifle').s, 0.8 * 5.72);       // rounded, rimfire
  close(s('17_hmr').s, 4.38);                    // pointy
});

test('cylinder end fractions k', () => {
  const frac = (k) => { const b = G.buildModel(rec(k)).bullet; return (b.zc - b.zb) / (b.zb ? (rec(k).cartridge.lengths.L6 - b.zb) : 1); };
  close(frac('308_win'), 0.40, 1e-9);
  close(frac('9_mm_luger'), 0.65, 1e-9);        // rounded pistol
  close(frac('22_long_rifle'), 0.55, 1e-9);     // rounded rimfire
  close(frac('40_s_w'), 0.70, 1e-9);            // flat pistol
  close(frac('357_magnum'), 0.78, 1e-9);        // semi_wadcutter
  const flatRifle = clone(rec('308_win')); flatRifle.annotations.defaultBulletShape = 'flat';
  const b = G.buildModel(flatRifle).bullet;
  close((b.zc - b.zb) / (71.12 - b.zb), 0.60, 1e-9);
  close(b.s, 0.8 * 7.85);
});

test('meplat diameters by shape', () => {
  const m = (k) => G.buildModel(rec(k)).bullet.meplat;
  close(m('17_hmr'), 1.27);                      // max(0.08 G1, 1.27)
  close(m('9_mm_luger'), 0.15 * 9.03);           // rounded
  close(m('40_s_w'), 0.55 * 10.17);              // flat
  close(m('357_magnum'), 5.472);                 // semi_wadcutter 0.6 G1
  close(m('44_rem_mag'), 0.6 * 10.97);
});

test('9 mm Luger: rounded nose is a quarter ellipse tangent to the shank', () => {
  const b = G.buildModel(rec('9_mm_luger')).bullet;
  close(b.zc, 24.7368, 0.0005);
  near(b.nose, 4.515, 24.7368, 0.0005);
  near(b.nose, 0.67725, 29.69, 0.0005);
  near(b.nose, 3.39095, 28.23924, 0.003);        // 45 degrees on the ellipse
});

test('357 Magnum: semi-wadcutter nose is a straight cone', () => {
  const b = G.buildModel(rec('357_magnum')).bullet;
  const zc = b.zc;
  near(b.nose, (4.56 + 2.736) / 2, (zc + 40.39) / 2, 0.0005);
  assert.equal(b.nose.length, 2);
});

test('22 Long Rifle: heeled bullet, exposed at the case outside diameter, seated at its inside diameter', () => {
  const b = G.buildModel(rec('22_long_rifle')).bullet;
  assert.equal(b.heeled, true);
  close(b.rExposed, 2.86);
  close(b.rSeated, 2.26);
  assert.deepEqual(b.exposed[0], { r: 2.86, z: 15.57 });
  near(b.full, 2.26, 12, 0.0005);                // seated heel in the section
  near(b.full, 2.26, 15.57, 0.0005);
  near(b.full, 2.86, 15.57, 0.0005);             // step out at the mouth
});

test('a bullet whose cylinder ends inside the case starts its exposed outline on the nose', () => {
  const r = clone(rec('308_win'));
  r.cartridge.lengths.L6 = 52;
  const b = G.buildModel(r).bullet;
  assert.ok(b.zc < 51.18);
  assert.equal(b.exposed[0].z, 51.18);
  assert.ok(b.exposed[0].r < 3.925 && b.exposed[0].r > 0.6);
});

test('bullet needs G1, L6, L3 and a shape: missing ones are named, nothing is substituted', () => {
  const noG1 = clone(rec('308_win')); delete noG1.cartridge.projectile.G1;
  assert.equal(G.buildModel(noG1).bullet, null);
  assert.ok(G.buildModel(noG1).notes.some((n) => /bullet/i.test(n) && /G1/.test(n)));
  const noL6 = clone(rec('308_win')); delete noL6.cartridge.lengths.L6;
  assert.equal(G.buildModel(noL6).bullet, null);
  assert.ok(G.buildModel(noL6).notes.some((n) => /bullet/i.test(n) && /L6/.test(n)));
  const noShape = clone(rec('308_win')); delete noShape.annotations.defaultBulletShape;
  assert.equal(G.buildModel(noShape).bullet, null);
  assert.ok(G.buildModel(noShape).notes.some((n) => /bullet/i.test(n) && /shape/i.test(n)));
  const noCat = clone(rec('9_mm_luger')); delete noCat.annotations.category;
  assert.equal(G.buildModel(noCat).bullet, null);
  assert.ok(G.buildModel(noCat).notes.some((n) => /bullet/i.test(n) && /category/i.test(n)));
});

// ---- 4.6 missing values -------------------------------------------------------

test('223 Rem. is complete: no notes', () => {
  assert.deepEqual(G.buildModel(rec('223_rem')).notes, []);
});

test('only the expected records carry notes', () => {
  const withNotes = records.map((r) => [r.key, G.buildModel(r).notes]).filter(([, n]) => n.length);
  assert.deepEqual(withNotes.map(([k]) => k), ['338_lapua_mag', '17_hmr']);
  assert.deepEqual(withNotes[0][1], ['Shoulder corner not rounded: r1 min not published.']);
});

function* leafPaths(obj, prefix = []) {
  for (const [k, v] of Object.entries(obj)) {
    if (v && typeof v === 'object' && !Array.isArray(v) && !('degrees' in v)) yield* leafPaths(v, [...prefix, k]);
    else yield [...prefix, k];
  }
}
function allNumbers(model) {
  const out = [];
  const visit = (x) => {
    if (typeof x === 'number') out.push(x);
    else if (Array.isArray(x)) x.forEach(visit);
    else if (x && typeof x === 'object') Object.values(x).forEach(visit);
  };
  visit([model.outer, model.inner, model.hatch, model.bullet, model.head, model.walls, model.mouth, model.bodyStart]);
  return out;
}

test('removing any single value never throws and never produces NaN', () => {
  for (const base of records) {
    for (const path of leafPaths({ cartridge: base.cartridge, annotations: base.annotations })) {
      const r = clone(base);
      let o = r;
      for (const k of path.slice(0, -1)) o = o[k];
      delete o[path[path.length - 1]];
      let m;
      assert.doesNotThrow(() => { m = G.buildModel(r); }, `${base.key} minus ${path.join('.')}`);
      assert.ok(allNumbers(m).every(Number.isFinite), `${base.key} minus ${path.join('.')} has a non-finite number`);
      assert.ok(Array.isArray(m.notes));
    }
  }
});

test('no feature uses a substitute number: dropping P1 removes the whole outline with a note', () => {
  const r = clone(rec('308_win'));
  delete r.cartridge.powderChamber.P1;
  const m = G.buildModel(r);
  assert.equal(m.outer, null);
  assert.ok(m.notes.some((n) => /P1/.test(n)));
});

// ---- regressions from review ---------------------------------------------------

test('a chamfer angle of 90 degrees or more is reported as such, not as a missing value', () => {
  const r = clone(rec('308_win'));
  r.cartridge.caseHead.beta = 90;
  const m = G.buildModel(r);
  const n = m.notes.find((x) => /chamfer/i.test(x));
  assert.ok(n, m.notes.join('|'));
  assert.match(n, /β/);
  assert.doesNotMatch(n, /:\s+not published/);
  assert.match(n, /below 90/);
});

test('an unknown bullet shape gets a readable note', () => {
  const r = clone(rec('308_win'));
  r.annotations.defaultBulletShape = 'ogive';
  const m = G.buildModel(r);
  assert.equal(m.bullet, null);
  assert.ok(m.notes.some((n) => n === 'Bullet not drawn: unknown bullet shape "ogive".'), m.notes.join('|'));
});

test('notes are plain sentences, whether a value is missing or a size was adjusted', () => {
  const r = clone(rec('308_win'));
  r.cartridge.junctionCone.r2 = 50;
  const m = G.buildModel(r);
  for (const n of m.notes) assert.match(n, /^[A-Z].*\.$/);
});
