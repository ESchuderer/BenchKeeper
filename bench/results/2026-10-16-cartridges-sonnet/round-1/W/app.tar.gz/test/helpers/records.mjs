import fs from 'node:fs';
import { createRequire } from 'node:module';

export const require = createRequire(import.meta.url);
export const records = fs.readFileSync(new URL('../../data/cartridges.jsonl', import.meta.url), 'utf8')
  .split('\n').filter(Boolean).map((l) => JSON.parse(l));
export const rec = (key) => records.find((r) => r.key === key);

// Distance from point (r, z) to a polyline of {r, z} points. Independent of the code under test.
export function distToPolyline(poly, r, z) {
  let best = Infinity;
  for (let i = 0; i < poly.length - 1; i++) {
    const a = poly[i], b = poly[i + 1];
    const dr = b.r - a.r, dz = b.z - a.z;
    const len2 = dr * dr + dz * dz;
    let t = len2 === 0 ? 0 : ((r - a.r) * dr + (z - a.z) * dz) / len2;
    t = Math.max(0, Math.min(1, t));
    best = Math.min(best, Math.hypot(a.r + t * dr - r, a.z + t * dz - z));
  }
  return best;
}

// Loads a classic script of the app (js/<name>.js) the same way the browser would.
export const load = (name) => require(`../../js/${name}.js`);
