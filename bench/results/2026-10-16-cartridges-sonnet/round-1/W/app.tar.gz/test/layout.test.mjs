import test from 'node:test';
import assert from 'node:assert/strict';
import { load, records, rec } from './helpers/records.mjs';

const G = load('geometry');
const F = load('format');
const L = load('layout');

const clone = (r) => JSON.parse(JSON.stringify(r));
const layoutOf = (r) => L.layoutDimensions(G.buildModel(r), r);
const texts = (lay) => lay.dims.map((d) => d.label.text);
const dim = (lay, id) => lay.dims.find((d) => d.id === id);
const lineOf = (d, kind) => d.lines.filter((l) => l.kind === kind);

test('308 Win.: every published dimension has a label "<symbol> <value>"', () => {
  const lay = layoutOf(rec('308_win'));
  assert.deepEqual(texts(lay).sort(), [
    'E1 10.39', 'G1 7.85', 'H1 8.72', 'H2 8.72', 'L1 39.62', 'L2 43.48', 'L3 51.18', 'L6 71.12',
    'P1 11.96', 'P2 11.53', 'R 1.37', 'R1 12.01', 'α 40°',
  ].sort());
});

test('9 mm Luger: unpublished dimensions are left out', () => {
  const lay = layoutOf(rec('9_mm_luger'));
  assert.deepEqual(texts(lay).sort(), ['E1 8.79', 'G1 9.03', 'H2 9.65', 'L3 19.15', 'L6 29.69', 'P1 9.93', 'R 1.27', 'R1 9.96'].sort());
});

test('angle labels use degrees, minutes, seconds as published', () => {
  assert.ok(texts(layoutOf(rec('6_5_x_55_se'))).includes(`α 50°35'2"`));
});

test('required dimensions are present on all 25 records', () => {
  for (const r of records) {
    const t = texts(layoutOf(r));
    for (const sym of ['L3', 'L6', 'R1', 'R', 'P1']) {
      const want = `${sym} ${F.formatNumber(sym === 'R1' || sym === 'R' ? r.cartridge.caseHead[sym] : sym === 'P1' ? r.cartridge.powderChamber.P1 : r.cartridge.lengths[sym])}`;
      assert.ok(t.includes(want), `${r.key} lacks "${want}"`);
    }
  }
});

test('dimension lines have the true length of the value they show', () => {
  const lay = layoutOf(rec('308_win'));
  const len = (id) => { const l = lineOf(dim(lay, id), 'dim')[0]; return Math.hypot(l.x2 - l.x1, l.y2 - l.y1); };
  for (const [id, v] of [['L3', 51.18], ['L6', 71.12], ['L1', 39.62], ['L2', 43.48], ['R', 1.37],
    ['R1', 12.01], ['P1', 11.96], ['P2', 11.53], ['H1', 8.72], ['H2', 8.72], ['E1', 10.39], ['G1', 7.85]]) {
    assert.ok(Math.abs(len(id) - v) < 1e-9, `${id}: ${len(id)} != ${v}`);
  }
  const l3 = lineOf(dim(lay, 'L3'), 'dim')[0];
  assert.equal(Math.min(l3.x1, l3.x2), 0);
  assert.equal(Math.max(l3.x1, l3.x2), 51.18);
});

test('every dimension has arrowheads at both ends and extension lines; α has a leader arrow', () => {
  for (const r of records) {
    const lay = layoutOf(r);
    for (const d of lay.dims) {
      if (d.id === 'alpha') {
        assert.equal(d.arrows.length, 1, r.key + ' alpha arrow');
        assert.ok(lineOf(d, 'leader').length >= 1);
        continue;
      }
      assert.equal(d.arrows.length, 2, `${r.key} ${d.id} arrows`);
      assert.ok(lineOf(d, 'ext').length >= 1, `${r.key} ${d.id} extension lines`);
      assert.equal(lineOf(d, 'dim').length, 1);
    }
  }
});

test('arrow tips touch the ends of the dimension line', () => {
  const d = dim(layoutOf(rec('308_win')), 'L3');
  const l = lineOf(d, 'dim')[0];
  const tips = d.arrows.map((a) => [a.x, a.y]).sort();
  assert.deepEqual(tips, [[l.x1, l.y1], [l.x2, l.y2]].sort());
});

test('all labels lie inside the viewBox, which contains the frame', () => {
  for (const r of records) {
    const lay = layoutOf(r);
    const v = lay.viewBox;
    for (const d of lay.dims) {
      const b = d.label.box;
      assert.ok(b.x0 >= v.x && b.x1 <= v.x + v.w && b.y0 >= v.y && b.y1 <= v.y + v.h, `${r.key} ${d.id}`);
    }
    assert.ok(lay.frame.x >= v.x && lay.frame.x + lay.frame.w <= v.x + v.w);
    assert.ok(lay.frame.y >= v.y && lay.frame.y + lay.frame.h <= v.y + v.h);
  }
});

test('title block: name, table, revision date, units text and print scale', () => {
  const lay = layoutOf(rec('308_win'));
  const all = lay.titleBlock.lines.map((l) => l.text);
  assert.ok(all.includes('308 Win.'));
  assert.ok(all.includes('C.I.P. table I'));
  assert.ok(all.includes('Revised 2008-09-23'));
  assert.ok(all.includes('Dimensions in mm'));
  const scale = all.find((t) => t.startsWith('Scale'));
  const n = (190 / lay.viewBox.w).toFixed(2);
  assert.equal(scale, `Scale ${n} : 1 (A4 print)`);
  assert.ok(lay.scale > 0);
});

test('the drawing is never taller than 0.6 of its width, so one A4 page can hold it', () => {
  for (const r of records) {
    const v = layoutOf(r).viewBox;
    assert.ok(v.h / v.w <= 0.6 + 1e-9, `${r.key}: ${(v.h / v.w).toFixed(2)}`);
  }
});

test('a record without outline data still lays out its title block and no dimensions that need it', () => {
  const r = clone(rec('308_win'));
  delete r.cartridge.powderChamber.P1;
  const lay = layoutOf(r);
  assert.ok(lay.titleBlock.lines.length >= 5);
  assert.ok(lay.viewBox.w > 0 && lay.viewBox.h > 0);
});

test('a dimension too short for inside arrowheads gets outside arrowheads on tails (R)', () => {
  const d = dim(layoutOf(rec('308_win')), 'R');
  const l = lineOf(d, 'dim')[0];
  assert.equal(Math.hypot(l.x2 - l.x1, l.y2 - l.y1), 1.37, 'the dimension line keeps its true length');
  assert.equal(lineOf(d, 'tail').length, 2);
  const left = d.arrows.find((a) => a.x === 0);
  const right = d.arrows.find((a) => a.x === 1.37);
  assert.equal(left.dx, -1, 'left arrowhead lies outside, left of the extension line');
  assert.equal(right.dx, 1);
  const wide = dim(layoutOf(rec('308_win')), 'L3');
  assert.equal(lineOf(wide, 'tail').length, 0);
});

// ---- regressions from review ---------------------------------------------------

test('length labels sit above their dimension line when there is room', () => {
  const lay = layoutOf(rec('308_win'));
  for (const id of ['L1', 'L2', 'L3', 'L6']) {
    const d = dim(lay, id);
    const y = lineOf(d, 'dim')[0].y1;
    assert.ok(d.label.y < y, `${id}: label baseline ${d.label.y} should be above the line at ${y}`);
    assert.equal(d.label.anchor, 'middle');
  }
});

test('the R extension line starts at the rim edge: at the half-round of a rimfire case', () => {
  const lay = layoutOf(rec('22_long_rifle'));
  const ext = lineOf(dim(lay, 'R'), 'ext').find((l) => l.x1 === 1.09);
  const rc = 7.06 / 2 - 0.545;
  assert.ok(Math.abs(ext.y1 - (rc + 0.8)) < 1e-9, `starts at ${ext.y1}`);
  const rimless = lineOf(dim(layoutOf(rec('308_win')), 'R'), 'ext').find((l) => l.x1 === 1.37);
  assert.ok(Math.abs(rimless.y1 - (6.005 + 0.8)) < 1e-9);
});

test('laying out all 25 records is fast', () => {
  const t = Date.now();
  for (const r of records) layoutOf(r);
  assert.ok(Date.now() - t < 2500, `took ${Date.now() - t} ms`);
});

test('a malformed angle does not break the layout', () => {
  const r = clone(rec('308_win'));
  r.cartridge.junctionCone.alpha = null;
  const lay = layoutOf(r);
  assert.ok(!texts(lay).some((t) => t.startsWith('α')));
  r.cartridge.junctionCone.alpha = { degrees: 40 };
  assert.ok(texts(layoutOf(r)).includes('α 40°'));
});
