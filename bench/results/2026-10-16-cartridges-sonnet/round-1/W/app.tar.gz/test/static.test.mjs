import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';

const root = path.resolve(new URL('..', import.meta.url).pathname);
const read = (p) => fs.readFileSync(path.join(root, p), 'utf8');
const appFiles = ['index.html', 'css/app.css', ...fs.readdirSync(path.join(root, 'js')).map((f) => 'js/' + f)];

test('index.html is in the project root, in English, and loads only local classic scripts and styles', () => {
  const html = read('index.html');
  assert.match(html, /<html lang="en">/);
  assert.doesNotMatch(html, /type\s*=\s*["']module["']/);
  for (const m of html.matchAll(/(?:src|href)\s*=\s*"([^"]+)"/g)) {
    const url = m[1];
    if (url.startsWith('#')) continue;
    assert.doesNotMatch(url, /^[a-z]+:|^\/\//i, `external reference: ${url}`);
    assert.ok(fs.existsSync(path.join(root, url)), `missing file ${url}`);
  }
});

test('no ES modules, no network APIs, no remote URLs in the app files', () => {
  for (const f of appFiles) {
    const src = read(f).replace(/http:\/\/www\.w3\.org\/2000\/svg/g, '');   // the SVG namespace is an identifier, not a request
    assert.doesNotMatch(src, /^\s*(import|export)\s/m, `${f}: ES module syntax`);
    assert.doesNotMatch(src, /\bimport\s*\(/, `${f}: dynamic import`);
    assert.doesNotMatch(src, /\bfetch\s*\(|XMLHttpRequest|WebSocket|EventSource|sendBeacon|serviceWorker/, `${f}: network API`);
    assert.doesNotMatch(src, /https?:\/\/|@import|url\(\s*["']?(https?:)?\/\//i, `${f}: remote URL`);
  }
});

test('no web fonts and no font files are referenced', () => {
  assert.doesNotMatch(read('css/app.css'), /@font-face/);
});

test('the app has no runtime dependencies', () => {
  const pkg = JSON.parse(read('package.json'));
  assert.equal(pkg.dependencies, undefined);
});
