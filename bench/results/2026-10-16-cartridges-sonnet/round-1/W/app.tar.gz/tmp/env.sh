export FONTCONFIG_FILE=/tmp/fc/fonts.conf
export LD_LIBRARY_PATH=/tmp/libs/usr/lib/x86_64-linux-gnu:/tmp/libs/lib/x86_64-linux-gnu
