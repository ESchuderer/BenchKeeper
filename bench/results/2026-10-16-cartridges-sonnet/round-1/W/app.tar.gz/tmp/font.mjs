import { chromium } from 'playwright';
const b = await chromium.launch(); const p = await b.newPage();
await p.setContent('<svg id=s width=300 height=50><text id=t x=2 y=30 font-family="system-ui, sans-serif" font-size="20">L3 51.18 α 40°</text></svg>');
console.log(await p.evaluate(()=>{const r=document.getElementById('t').getBBox();return [r.width,r.height]}));
await p.screenshot({path:'tmp/font.png'});
await b.close();
