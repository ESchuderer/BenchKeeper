import { chromium } from 'playwright';
const b = await chromium.launch();
const p = await b.newPage({ viewport: { width: 718, height: 1047 } });
await p.emulateMedia({ media: 'print' });
for (const key of ['223_rem', '308_win', '17_hmr', '9_mm_luger', '300_win_mag']) {
  await p.goto('file:///work/index.html#/cartridge/' + key);
  const r = await p.evaluate(() => { const mm = 96 / 25.4; const h = (s) => +(document.querySelector(s).getBoundingClientRect().height / mm).toFixed(1);
    return { h1: h('h1'), facts: h('dl.facts'), fig: h('figure'), values: h('.value-groups'), footer: h('.print-footer'), total: +(document.documentElement.scrollHeight / mm).toFixed(1) }; });
  console.log(key, JSON.stringify(r));
}
await b.close();
