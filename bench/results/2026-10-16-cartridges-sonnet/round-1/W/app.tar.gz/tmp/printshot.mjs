import { chromium } from 'playwright';
const key = process.argv[2] || '223_rem';
const b = await chromium.launch();
const p = await b.newPage({ viewport: { width: 794, height: 1123 }, colorScheme: 'dark' });
await p.emulateMedia({ media: 'print' });
await p.goto('file:///work/index.html#/cartridge/' + key);
await p.addStyleTag({ content: 'html{padding:10mm;background:#fff;} body{width:190mm}' });
await p.screenshot({ path: `tmp/print-${key}.png`, fullPage: true });
await b.close();
