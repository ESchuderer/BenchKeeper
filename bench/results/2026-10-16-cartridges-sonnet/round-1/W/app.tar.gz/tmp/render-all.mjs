// Dev helper: renders the drawings of all records (or the keys given) to PNG files in tmp/shots.
import { chromium } from 'playwright';
import fs from 'node:fs';
const keys = process.argv.slice(2);
const scheme = process.env.SCHEME || 'light';
const b = await chromium.launch();
const p = await b.newPage({ viewport: { width: 1000, height: 800 }, colorScheme: scheme });
await p.setContent('<!doctype html><meta charset=utf-8><body style="margin:0;background:#888"><div id=app></div>');
await p.addStyleTag({ content: fs.readFileSync('css/app.css', 'utf8') });
for (const f of ['format', 'geometry', 'layout', 'drawing']) await p.addScriptTag({ content: fs.readFileSync(`js/${f}.js`, 'utf8') });
await p.addScriptTag({ content: fs.readFileSync('data/cartridges.js', 'utf8') });
fs.mkdirSync('tmp/shots', { recursive: true });
const all = await p.evaluate(() => window.CIP_DATA.map((r) => r.key));
for (const key of (keys.length ? keys : all)) {
  await p.evaluate((k) => {
    const r = window.CIP_DATA.find((x) => x.key === k);
    const { svg, notes } = window.CIP.drawing.render(r, document);
    const app = document.getElementById('app'); app.innerHTML = ''; app.appendChild(svg);
    const n = document.createElement('pre'); n.style.cssText = 'margin:0;padding:4px;background:#fff'; n.textContent = notes.join('\n'); app.appendChild(n);
  }, key);
  await p.locator('#app').screenshot({ path: `tmp/shots/${key}-${scheme}.png` });
}
await b.close();
