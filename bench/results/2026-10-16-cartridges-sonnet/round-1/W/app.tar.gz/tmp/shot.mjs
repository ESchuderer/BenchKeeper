import { chromium } from 'playwright';
const [,, hash, scheme='light', w='1100', h='900', out='tmp/shot.png', full='1'] = process.argv;
const b = await chromium.launch();
const p = await b.newPage({ viewport: { width: +w, height: +h }, colorScheme: scheme });
await p.goto('file:///work/index.html' + (hash === '-' ? '' : hash));
await p.screenshot({ path: out, fullPage: full === '1' });
await b.close();
