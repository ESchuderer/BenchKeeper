import { chromium } from 'playwright';
const b = await chromium.launch();
const p = await b.newPage();
await p.goto('file:///work/data/cartridges.js');
console.log('ok', b.version());
await p.setContent('<p>hi</p>');
const pdf = await p.pdf({ format: 'A4' });
console.log('pdf bytes', pdf.length);
await b.close();
