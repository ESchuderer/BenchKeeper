# 01 Data and formatting
Status: ready-for-agent
Blocked by: none
`js/data.js` with the 25 records verbatim; `js/format.js`: number, angle, symbol, unit, tolerance, rows per section. Unit tests.
