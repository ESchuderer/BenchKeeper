# 03 Detail view
Status: ready-for-agent
Blocked by: 01, 02
Heading, meta list, water capacity link, tables by section (Symbol, Value, Unit), Print button, All cartridges link, light/dark styles.
