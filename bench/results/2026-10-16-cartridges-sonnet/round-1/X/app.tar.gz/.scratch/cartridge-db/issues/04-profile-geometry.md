# 04 Outer profile
Status: ready-for-agent
Blocked by: 01
Rules 1-6 and 9 as pure functions with unit tests (rim type, rim, groove, belt, body, shoulder, fillets, neck).
