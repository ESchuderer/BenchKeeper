# 05 Bullet and section
Status: ready-for-agent
Blocked by: 04
Rules 7-8: bullet profile by shape, heeled case, walls, solid head, primer pocket.
