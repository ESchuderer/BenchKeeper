# 06 Drawing
Status: ready-for-agent
Blocked by: 04, 05, 03
Dimension layout, SVG output, hatching, centre line, title block, scale, accessible name; no label overlap for all 25.
