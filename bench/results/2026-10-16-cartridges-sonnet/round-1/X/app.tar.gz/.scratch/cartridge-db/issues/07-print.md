# 07 Print
Status: ready-for-agent
Blocked by: 03, 06
A4 portrait one page, black on white, header, footer, hidden controls.
