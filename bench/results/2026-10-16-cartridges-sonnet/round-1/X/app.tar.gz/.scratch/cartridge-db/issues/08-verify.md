# 08 Verify
Status: ready-for-agent
Blocked by: 02-07
Browser tests on file:// and a static server, screenshots light/dark/phone, PDF page count.
