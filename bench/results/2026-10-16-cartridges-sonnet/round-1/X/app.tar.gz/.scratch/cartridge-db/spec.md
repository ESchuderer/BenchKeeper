# Cartridge database (static web app)

Status: ready-for-agent
Tier: full

Source of requirements: the brief in the originating prompt (data, start page, detail view, drawing rules 1-9, print, look and feel, technology). This file records only decisions and assumptions made on top of it.

## Structure
- `index.html`, `css/style.css`, `js/data.js` (25 records, `window.CARTRIDGES`), `js/format.js`, `js/geometry.js`, `js/drawing.js`, `js/app.js`.
- Classic scripts with one global namespace `CIP`; each file also exports through `module.exports` so `node --test` can load it. ES modules and `fetch` are not used (they fail on `file://`).
- Routing by hash: `#/` list, `#/<key>` detail. Survives reload, works on `file://` and any static server.

## Decisions
- Units: every field is mm unless the brief names another unit. Water capacity is `gr H2O`. Angles show unit `deg` in the Unit column and `°` in the value.
- `<X>Tol` is shown inside the value cell of X (`39.62 -0.2`); the drawing labels carry no tolerance.
- Result count text is always "<n> cartridges" (also for 1), as written in the brief.
- Drawing axes: x = z, y = radius (upper half outside view `y < 0`, lower half section `y > 0`).
- Print scale: the SVG view box is `190 / S` mm wide so that, printed at 190 mm width (A4, 10 mm margins), 1 user unit = `S` paper mm. The title block states the print scale `S` as "Scale S:1 (A4 print)"; on screen the drawing is scaled to the window. Fonts, arrowheads, line weights and offsets are laid out in paper mm, divided by `S`.
- Dimension layout: axial dimensions as rows above (R, L1, L2) and below (L3, L6) the part; diameters as rotated-label columns left of the head (R1, P1, E1) and right of the bullet tip (P2, H1, H2, G1), larger diameter nearest the part. The included angle α is an arc centred on the cone apex (the published `S`, found from the shoulder line).
- Heeled case: wall at the neck equals `tb` (otherwise `tn = 0` leaves no wall around the heel).
- Straight case: wall thickness blends linearly from `tb` at the body start to `tn` at the mouth.
- Inner wall radius is taken from the body/shoulder/neck outer line (not from belt or rim), so belted cases keep a smooth bore.
- Missing value rule: a feature whose published values are only partly present is skipped and listed in "Drawing notes".

## Acceptance
Every bullet of the brief. Checks: `npm test` (unit), `npm run test:e2e` (browser: list, detail, drawing label overlap on all 25, print to one A4 page, `file://` and static server).
