// Start page and detail view; routing by location hash (#/ list, #/<key> detail) so it works on file://.
(function () {
  const { format: F, catalog, drawing } = window.CIP;
  const DATA = window.CARTRIDGES;
  const app = document.getElementById('app');
  const FAMILIES = ['All', 'rimless', 'rimmed', 'belted', 'pistol', 'rimfire'];
  const TITLE = 'C.I.P. cartridges';

  function h(tag, attrs, ...kids) {
    const e = document.createElement(tag);
    for (const [k, v] of Object.entries(attrs || {})) e.setAttribute(k, v);
    e.append(...kids);
    return e;
  }

  function listView() {
    document.title = TITLE;
    const search = h('input', { type: 'search', id: 'search', autocomplete: 'off', spellcheck: 'false' });
    const family = h('select', { id: 'family' }, ...FAMILIES.map((f) => h('option', { value: f }, f)));
    const count = h('p', { role: 'status', class: 'count' });
    const body = h('tbody');
    const render = () => {
      const rows = catalog.filterCartridges(DATA, search.value, family.value);
      count.textContent = `${rows.length} cartridges`;
      body.replaceChildren(
        ...rows.map((c) =>
          h('tr', {}, h('td', {}, h('a', { href: `#/${c.key}` }, c.name)), h('td', {}, c.family), h('td', { class: 'num' }, `${F.formatNumber(c.cartridge.lengths.L3)} mm`))
        )
      );
    };
    search.addEventListener('input', render);
    family.addEventListener('change', render);
    app.replaceChildren(
      h('h1', {}, 'Cartridges'),
      h('div', { class: 'controls' }, h('label', { for: 'search' }, 'Search'), search, h('label', { for: 'family' }, 'Family'), family, count),
      h('table', { class: 'list' }, h('thead', {}, h('tr', {}, h('th', {}, 'Name'), h('th', {}, 'Family'), h('th', { class: 'num' }, 'Case length L3'))), body)
    );
    render();
  }

  function valueCell(row) {
    const td = h('td', { class: 'num' }, row.value);
    if (row.tol !== undefined) td.append(' ', h('span', { class: 'tol' }, row.tol));
    return td;
  }

  function tables(title, part, prefix) {
    const sections = Object.entries(part)
      .filter(([, s]) => Object.keys(s).length)
      .map(([key, s]) =>
        h('section', {},
          h('h3', {}, F.sectionTitle(key)),
          h('table', { 'aria-label': `${prefix} ${F.sectionTitle(key).toLowerCase()}` },
            h('thead', {}, h('tr', {}, h('th', { scope: 'col' }, 'Symbol'), h('th', { scope: 'col', class: 'num' }, 'Value'), h('th', { scope: 'col' }, 'Unit'))),
            h('tbody', {}, ...F.sectionRows(s).map((r) => h('tr', {}, h('th', { scope: 'row' }, r.symbol), valueCell(r), h('td', {}, r.unit))))
          )
        )
      );
    return h('section', { class: 'group' }, h('h2', {}, title), h('div', { class: 'sections' }, ...sections));
  }

  function capacity(c) {
    const p = c.annotations.publishedCapacity;
    if (!p) return 'not published';
    const dd = document.createDocumentFragment();
    dd.append(`${F.formatNumber(p.grH2O)} gr H2O, source `, h('a', { href: p.url, rel: 'noopener noreferrer', target: '_blank' }, p.source));
    if (p.note) dd.append(h('span', { class: 'note' }, ` (${p.note})`));
    return dd;
  }

  function detailView(c) {
    document.title = `${c.name} | ${TITLE}`;
    const meta = [
      ['Alternative names', (c.alternativeNames || []).join(', ') || 'none'],
      ['Family', c.family],
      ['Category', c.annotations.category],
      ['Primer type', c.annotations.primerType],
      ['C.I.P. table', c.tab],
      ['Country', c.country],
      ['Published', c.published],
      ['Revised', c.revised],
      ['Pressure method', c.pressureMethod],
      ['Water capacity', capacity(c)],
    ];
    const d = drawing.buildDrawing(c);
    const figure = h('figure', { class: 'drawing' });
    if (d.missing) figure.append(h('p', { class: 'notes' }, `Drawing not available: ${d.missing.map(F.symbol).join(', ')} missing.`));
    else {
      figure.insertAdjacentHTML('afterbegin', drawing.renderSvg(d));
      if (d.notes.length) figure.append(h('figcaption', { class: 'notes' }, h('strong', {}, 'Drawing notes: '), d.notes.join('; ')));
    }
    app.replaceChildren(
      h('nav', { class: 'actions' }, h('a', { href: '#/' }, 'All cartridges'), h('button', { type: 'button', id: 'print' }, 'Print')),
      h('article', {},
        h('header', { class: 'sheet-head' }, h('h1', {}, c.name), h('p', { class: 'print-only' }, 'C.I.P. cartridge data sheet')),
        h('dl', { class: 'meta' }, ...meta.flatMap(([k, v]) => [h('dt', {}, k), h('dd', {}, v)])),
        figure,
        h('div', { class: 'tables' }, tables('Cartridge', c.cartridge, 'Cartridge'), tables('Chamber', c.chamber, 'Chamber')),
        h('footer', { class: 'sheet-foot' }, `Source: C.I.P. TDCC, revised ${c.revised}`)
      )
    );
    document.getElementById('print').addEventListener('click', () => window.print());
  }

  function route() {
    const m = location.hash.match(/^#\/(.+)$/);
    if (!m) listView();
    else {
      let key = m[1];
      try { key = decodeURIComponent(key); } catch (e) { /* malformed escape: shown as not found */ }
      const c = DATA.find((x) => x.key === key);
      if (c) detailView(c);
      else {
        document.title = `Not found | ${TITLE}`;
        app.replaceChildren(h('h1', {}, 'Not found'), h('p', {}, `No cartridge "${key}". `, h('a', { href: '#/' }, 'All cartridges')));
      }
    }
    window.scrollTo(0, 0);
  }

  window.addEventListener('hashchange', route);
  route();
})();
