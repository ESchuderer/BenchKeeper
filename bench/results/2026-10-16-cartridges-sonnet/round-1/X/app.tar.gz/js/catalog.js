// List filtering for the start page.
(function () {
  function filterCartridges(list, query, family) {
    const q = query.trim().toLowerCase();
    return list.filter(
      (c) =>
        (family === 'All' || c.family === family) &&
        [c.name, ...(c.alternativeNames || [])].some((n) => n.toLowerCase().includes(q))
    );
  }

  const api = { filterCartridges };
  if (typeof module !== 'undefined') module.exports = api;
  else (window.CIP = window.CIP || {}).catalog = api;
})();
