// Layout and SVG output of the 2D drawing. 1 user unit = 1 mm of the cartridge.
// Annotation sizes are set in paper mm ("pm") and divided by the print scale S, so a sheet printed at 190 mm width has S paper mm per cartridge mm.
(function () {
  const F = typeof require === 'function' ? require('./format.js') : window.CIP.format;
  const G = typeof require === 'function' ? require('./geometry.js') : window.CIP.geometry;

  const SHEET = 190; // A4 portrait width minus 2 x 10 mm margins
  const FS = 3.2; // label font size
  const CHAR = 0.62; // label width per character, in em (conservative for tabular figures)
  const ARROW = 2.2, ARROW_HALF = 0.5, TAIL = 2.5, GAP = 1, OVER = 1.5;
  const ROW = 7, COL = 8; // pitch of dimension rows and columns
  const LW = { outline: 0.35, thin: 0.18, hatch: 0.18 };

  const n3 = (v) => +v.toFixed(3);
  const esc = (s) => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');

  function buildDrawing(c) {
    const m = G.buildModel(c);
    if (m.missing) return { name: c.name, missing: m.missing, notes: [] };
    const k = c.cartridge;
    const { R, R1, E1 } = k.caseHead, { P1, P2 } = k.powderChamber, { H1, H2 } = k.collar, { G1 } = k.projectile;
    const { L1, L2, L3, L6 } = k.lengths;
    const sh = m.shoulder, b = m.bullet;
    const notes = m.notes.slice();
    const grooved = [k.caseHead.E, E1, k.caseHead.eMin].every((v) => typeof v === 'number');
    const num = (v) => F.formatNumber(v);

    const left = [{ sym: 'R1', val: num(R1), D: R1, zf: 0 }, { sym: 'P1', val: num(P1), D: P1, zf: m.outer[m.bodyStart].z }];
    if (grooved) left.push({ sym: 'E1', val: num(E1), D: E1, zf: R });
    const right = [{ sym: 'H2', val: num(H2), D: H2, zf: L3 }];
    if (sh) right.push({ sym: 'P2', val: num(P2), D: P2, zf: L1 }, { sym: 'H1', val: num(H1), D: H1, zf: L2 });
    if (b) right.push({ sym: 'G1', val: num(G1), D: G1, zf: b.zc });
    for (const g of [left, right]) g.sort((p, q) => q.D - p.D);
    const upper = [{ sym: 'R', val: num(R), z2: R }];
    if (sh) upper.push({ sym: 'L1', val: num(L1), z2: L1 }, { sym: 'L2', val: num(L2), z2: L2 });
    const lower = [{ sym: 'L3', val: num(L3), z2: L3 }, { sym: 'L6', val: num(L6), z2: L6 }];

    // scale: the part plus the dimension columns fill the sheet width
    const mL = COL * left.length + 10, mR = COL * right.length + 6;
    const S = Math.floor(((SHEET - mL - mR) / L6) * 10) / 10;
    const u = 1 / S;
    const P = (pm) => pm * u;
    const fs = P(FS);
    const rMax = Math.max(...m.outer.map((p) => p.r));
    const silR = (z) => Math.max(G.maxR(m.outer, z, z), b && z >= L3 - 1e-9 ? G.maxR(b.exposed, z, z) : 0);

    const els = [];
    const labels = [];
    const outline = [];
    const bounds = { x0: Infinity, x1: -Infinity, y0: Infinity, y1: -Infinity };
    const track = (x, y) => { bounds.x0 = Math.min(bounds.x0, x); bounds.x1 = Math.max(bounds.x1, x); bounds.y0 = Math.min(bounds.y0, y); bounds.y1 = Math.max(bounds.y1, y); };
    const poly = (pts) => pts.map(([x, y], i) => `${i ? 'L' : 'M'}${n3(x)} ${n3(y)}`).join('');
    const path = (cls, pts, width, extra = {}) => { pts.forEach(([x, y]) => track(x, y)); els.push({ tag: 'path', cls, d: poly(pts), width, ...extra }); };
    const up = (p) => [p.z, -p.r];
    const dn = (p) => [p.z, p.r];

    // text with an estimated box (real boxes are checked in the browser tests)
    function text(cls, str, x, y, anchor, vertical) {
      const w = str.length * CHAR * fs;
      let box;
      if (vertical) box = { x0: x - 1.0 * fs, x1: x + 0.65 * fs, y0: y - w / 2, y1: y + w / 2 };
      else {
        const x0 = anchor === 'middle' ? x - w / 2 : anchor === 'end' ? x - w : x;
        box = { x0, x1: x0 + w, y0: y - 0.98 * fs, y1: y + 0.3 * fs };
      }
      track(box.x0, box.y0); track(box.x1, box.y1);
      const el = { tag: 'text', cls, text: str, x, y, anchor, vertical, fs, box };
      els.push(el);
      if (cls === 'label') labels.push(el);
    }

    function arrow(tx, ty, ax, ay) { // tip at (tx, ty), pointing along unit vector (ax, ay)
      const bx = tx - ax * P(ARROW), by = ty - ay * P(ARROW), nx = -ay * P(ARROW_HALF), ny = ax * P(ARROW_HALF);
      const pts = [[tx, ty], [bx + nx, by + ny], [bx - nx, by - ny]];
      pts.forEach(([x, y]) => track(x, y));
      els.push({ tag: 'path', cls: 'arrow', d: `${poly(pts)}Z` });
    }

    // dimension line p1 -> p2 with arrowheads inside, or outside with tails when the span is short
    function dimLine(x1, y1, x2, y2) {
      const len = Math.hypot(x2 - x1, y2 - y1), ax = (x2 - x1) / len, ay = (y2 - y1) / len;
      const tight = len * S < 2 * ARROW + 1.2;
      if (tight) {
        const t = P(ARROW + TAIL);
        path('dim', [[x1 - ax * t, y1 - ay * t], [x1, y1]], P(LW.thin));
        path('dim', [[x2, y2], [x2 + ax * t, y2 + ay * t]], P(LW.thin));
        arrow(x1, y1, ax, ay); arrow(x2, y2, -ax, -ay);
      } else {
        path('dim', [[x1, y1], [x2, y2]], P(LW.thin));
        arrow(x1, y1, -ax, -ay); arrow(x2, y2, ax, ay);
      }
    }
    const ext = (pts) => path('ext', pts, P(LW.thin));

    // axial dimensions: rows above (side -1) and below (side +1) the part
    function rows(list, side) {
      list.forEach((d, i) => {
        const y = side * (rMax + P(6 + ROW * i));
        for (const z of [0, d.z2]) ext([[z, side * (silR(z) + P(GAP))], [z, y + side * P(OVER)]]);
        dimLine(0, y, d.z2, y);
        const str = `${d.sym} ${d.val}`;
        const fits = d.z2 * S > str.length * CHAR * FS + 2;
        if (!fits) text('label', str, d.z2 + P(ARROW + TAIL + 1.5), y + 0.35 * fs, 'start');
        else if (side < 0) text('label', str, d.z2 / 2, y - P(1.4), 'middle');
        else text('label', str, d.z2 / 2, y + P(1.2) + 0.98 * fs, 'middle');
      });
    }
    rows(upper, -1);
    rows(lower, 1);

    // diameters: columns left of the head and right of the bullet tip, larger diameter nearest the part
    function columns(list, dir) {
      list.forEach((d, i) => {
        const x = dir < 0 ? -P(10 + COL * i) : L6 + P(6 + COL * i);
        for (const s of [-1, 1]) ext([[d.zf + dir * P(GAP), s * d.D / 2], [x + dir * P(OVER), s * d.D / 2]]);
        dimLine(x, -d.D / 2, x, d.D / 2);
        const str = `${d.sym} ${d.val}`;
        const len = str.length * CHAR * fs;
        text('label', str, x - P(0.8) - 0.65 * fs, -d.D / 2 - P(1.2) - len / 2, 'middle', true);
      });
    }
    columns(left, -1);
    columns(right, 1);

    // part: outside view above the axis, section below
    const upperOutline = m.outer.map(up);
    if (b) upperOutline.push([L3, -b.rExp], ...b.exposed.map(up));
    path('outline', upperOutline, P(LW.outline));
    outline.push(upperOutline);

    const w = m.walls.w, pr = m.pocket ? m.pocket.d / 2 : 0;
    const innerMouth = m.inner[m.inner.length - 1];
    const outerFromHead = [[0, pr], ...m.outer.slice(1).map(dn)];
    const sectionEdge = [...outerFromHead, [L3, innerMouth.r], ...m.inner.slice().reverse().map(dn), [w, 0]];
    const sectionFill = [...sectionEdge];
    if (m.pocket) sectionFill.push([m.pocket.depth, 0], [m.pocket.depth, pr]);
    sectionFill.forEach(([x, y]) => track(x, y));
    els.push({ tag: 'path', cls: 'cut', d: `${poly(sectionFill)}Z`, fill: 'url(#hatch-case)' });
    path('outline', sectionEdge, P(LW.outline));
    outline.push(sectionEdge);
    if (m.pocket) {
      const pocketEdge = [[0, pr], [m.pocket.depth, pr], [m.pocket.depth, 0]];
      path('outline', pocketEdge, P(LW.outline));
      outline.push(pocketEdge);
    }
    if (b) {
      els.push({ tag: 'path', cls: 'cut', d: `${poly(b.section.map(dn))}Z`, fill: 'url(#hatch-bullet)' });
      const bulletEdge = b.section.map(dn);
      path('outline', bulletEdge, P(LW.outline));
      outline.push(bulletEdge);
    }
    path('centre', [[-P(4), 0], [L6 + P(4), 0]], P(LW.thin));

    // shoulder angle: arc about the cone apex through the shoulder start, label below the section
    if (sh) {
      const { v1, n, apexZ } = sh;
      const rho = Math.hypot(apexZ - v1.z, v1.r);
      const psi = Math.atan2(v1.r, apexZ - v1.z);
      const endZ = Math.min(apexZ, L6); // the apex can lie beyond the tip on shallow cones
      for (const s of [-1, 1]) path('construction', [[n.z, s * n.r], [endZ, s * n.r * (apexZ - endZ) / (apexZ - n.z)]], P(LW.thin));
      els.push({ tag: 'path', cls: 'dim', d: `M${n3(v1.z)} ${n3(-v1.r)}A${n3(rho)} ${n3(rho)} 0 0 0 ${n3(v1.z)} ${n3(v1.r)}`, width: P(LW.thin) });
      track(apexZ - rho, 0);
      arrow(v1.z, -v1.r, Math.sin(psi), -Math.cos(psi));
      arrow(v1.z, v1.r, Math.sin(psi), Math.cos(psi));
      const str = `${F.symbol('alpha')} ${F.formatAngle(k.junctionCone.alpha)}`;
      const width = str.length * CHAR * fs;
      let lx = v1.z + P(1.5), clear = v1.r;
      if (lx + width > L3 - P(1)) { // no room right of the shoulder start: put the label to its left
        lx = v1.z - P(1.5) - width;
        clear = G.maxR(m.outer, lx, v1.z);
      }
      text('label', str, lx, clear + P(1.2) + 0.98 * fs, 'start');
    }

    // title block
    const vx0 = -P(mL) - P((SHEET - mL - mR - S * L6) / 2);
    const vw = P(SHEET);
    const top = bounds.y1 + P(5), h = P(14), x0 = vx0 + P(2), tw = vw - P(4);
    const cell = (x, y, str, cls = 'tb') => { const e = { tag: 'text', cls, text: str, x, y, anchor: 'start', fs: P(cls === 'tb-name' ? 5.5 : FS) }; els.push(e); };
    els.push({ tag: 'rect', cls: 'tb-frame', x: x0, y: top, w: tw, h, width: P(LW.outline) });
    const c1 = x0 + tw * 0.4, c2 = x0 + tw * 0.7;
    path('tb-line', [[c1, top], [c1, top + h]], P(LW.thin));
    path('tb-line', [[c2, top], [c2, top + h]], P(LW.thin));
    path('tb-line', [[c1, top + h / 2], [x0 + tw, top + h / 2]], P(LW.thin));
    cell(x0 + P(2), top + h / 2 + P(1.9), c.name, 'tb-name');
    cell(c1 + P(2), top + h / 4 + P(1.1), `C.I.P. table ${c.tab}`);
    cell(c2 + P(2), top + h / 4 + P(1.1), `Revised ${c.revised}`);
    cell(c1 + P(2), top + (3 * h) / 4 + P(1.1), 'Dimensions in mm');
    cell(c2 + P(2), top + (3 * h) / 4 + P(1.1), `Scale ${S.toFixed(1)}:1 (A4 print)`);
    track(x0, top + h);

    const y0 = bounds.y0 - P(3), y1 = top + h + P(3);
    return { name: c.name, S, u, viewBox: [n3(vx0), n3(y0), n3(vw), n3(y1 - y0)], els, labels, outline, bounds, notes, hatch: P(1.6) };
  }

  function renderSvg(d) {
    if (d.missing) return '';
    const [x, y, w, h] = d.viewBox;
    const hp = d.hatch, hb = hp * 1.5;
    const body = d.els.map((e) => {
      if (e.tag === 'text') {
        return `<text class="${e.cls}${e.vertical ? ' vlabel' : ''}" x="${n3(e.x)}" y="${n3(e.y)}" font-size="${n3(e.fs)}" text-anchor="${e.anchor}">${esc(e.text)}</text>`;
      }
      if (e.tag === 'rect') return `<rect class="${e.cls}" x="${n3(e.x)}" y="${n3(e.y)}" width="${n3(e.w)}" height="${n3(e.h)}" stroke-width="${n3(e.width)}"/>`;
      return `<path class="${e.cls}" d="${e.d}"${e.width ? ` stroke-width="${n3(e.width)}"` : ''}${e.fill ? ` fill="${e.fill}"` : ''}/>`;
    }).join('');
    return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="${x} ${y} ${w} ${h}" role="img" aria-label="${esc(d.name)} drawing" preserveAspectRatio="xMidYMid meet"><title>${esc(d.name)} drawing</title>` +
      `<defs><pattern id="hatch-case" patternUnits="userSpaceOnUse" width="${n3(hp)}" height="${n3(hp)}" patternTransform="rotate(45)"><line class="hatch" x1="0" y1="0" x2="0" y2="${n3(hp)}" stroke-width="${n3(d.u * LW.hatch)}"/></pattern>` +
      `<pattern id="hatch-bullet" patternUnits="userSpaceOnUse" width="${n3(hb)}" height="${n3(hb)}" patternTransform="rotate(-45)"><line class="hatch" x1="0" y1="0" x2="0" y2="${n3(hb)}" stroke-width="${n3(d.u * LW.hatch)}"/></pattern></defs>` +
      `${body}</svg>`;
  }

  const api = { buildDrawing, renderSvg };
  if (typeof module !== 'undefined') module.exports = api;
  else (window.CIP = window.CIP || {}).drawing = api;
})();
