// Display formatting for cartridge values. Values are shown as published: decimal point, no grouping.
(function () {
  const ANGLES = new Set(['alpha', 'alpha1', 'beta', 'delta', 'i']);
  const UNITS = { Pmax: 'bar', PK: 'bar', PE: 'bar', EE: 'J', M: 'g', Q: 'mm²', N: '' };
  const SYMBOLS = {
    eMin: 'e min', r1Min: 'r1 min', r1Max: 'r1 max', alpha: 'α', alpha1: 'α1', beta: 'β', delta: 'δ', deltaL: 'delta L', L3PlusG: 'L3 + G',
  };

  const formatNumber = (n) => String(n);
  const toDegrees = (a) => (typeof a === 'number' ? a : a.degrees + a.minutes / 60 + a.seconds / 3600);
  const formatAngle = (a) => (typeof a === 'number' ? `${a}°` : `${a.degrees}°${a.minutes}'${a.seconds}"`);
  const symbol = (key) => SYMBOLS[key] || key;
  const unit = (key) => (ANGLES.has(key) ? 'deg' : key in UNITS ? UNITS[key] : 'mm');
  const formatValue = (key, v) => (ANGLES.has(key) ? formatAngle(v) : formatNumber(v));

  // One row per field; `<X>Tol` is folded into the row of X.
  function sectionRows(section) {
    return Object.keys(section)
      .filter((k) => !(k.endsWith('Tol') && k.slice(0, -3) in section))
      .map((k) => {
        const row = { symbol: symbol(k), value: formatValue(k, section[k]), tol: undefined, unit: unit(k) };
        if (k + 'Tol' in section) row.tol = formatNumber(section[k + 'Tol']);
        return row;
      });
  }

  function sectionTitle(key) {
    const words = key.replace(/([A-Z])/g, ' $1').toLowerCase();
    return words[0].toUpperCase() + words.slice(1);
  }

  const api = { formatNumber, toDegrees, formatAngle, symbol, unit, sectionRows, sectionTitle };
  if (typeof module !== 'undefined') module.exports = api;
  else (window.CIP = window.CIP || {}).format = api;
})();
