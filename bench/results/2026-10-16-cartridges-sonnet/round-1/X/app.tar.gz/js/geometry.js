// Drawing model of a cartridge from its record (brief rules 1-9). Points are {z, r}: z along the axis from the head face, r the radius, in mm.
(function () {
  const F = typeof require === 'function' ? require('./format.js') : window.CIP.format;
  const RAD = Math.PI / 180;
  const isNum = (v) => typeof v === 'number';
  const deg = F.toDegrees;
  const SEGMENTS = 10;
  const POCKET = { sp: [4.45, 3.04], spm: [4.45, 3.04], sr: [4.45, 3.04], lp: [5.33, 3.04], lpm: [5.33, 3.04], lr: [5.33, 3.3], lrm: [5.33, 3.3] };

  function rimType(c) {
    if (c.family === 'belted' || c.family === 'rimfire') return c.family;
    const ratio = c.cartridge.caseHead.R1 / c.cartridge.powderChamber.P1;
    return ratio >= 1.05 ? 'rimmed' : ratio < 0.98 ? 'rebated' : 'rimless';
  }

  // r at z along a polyline whose z does not decrease; clamped to the end points.
  function rAt(pts, z) {
    if (z <= pts[0].z) return pts[0].r;
    for (let i = 1; i < pts.length; i++) {
      const a = pts[i - 1], b = pts[i];
      if (z <= b.z && b.z - a.z > 1e-12) return a.r + ((b.r - a.r) * (z - a.z)) / (b.z - a.z);
    }
    return pts[pts.length - 1].r;
  }

  // Largest r of a polyline between z0 and z1.
  function maxR(pts, z0, z1) {
    let m = Math.max(rAt(pts, z0), rAt(pts, z1));
    for (const p of pts) if (p.z >= z0 && p.z <= z1) m = Math.max(m, p.r);
    return m;
  }

  function push(pts, z, r) {
    const l = pts[pts.length - 1];
    if (!l || Math.abs(l.z - z) > 1e-9 || Math.abs(l.r - r) > 1e-9) pts.push({ z, r });
  }

  function arc(cz, cr, rho, a0, a1) {
    return Array.from({ length: SEGMENTS + 1 }, (_, i) => {
      const a = a0 + ((a1 - a0) * i) / SEGMENTS;
      return { z: cz + rho * Math.cos(a), r: cr + rho * Math.sin(a) };
    });
  }

  const dist = (a, b) => Math.hypot(b.z - a.z, b.r - a.r);

  // Round the corner at v with a tangent arc of the given radius; the arc is shortened to fit maxT (tangent length).
  function corner(prev, v, next, radius, maxT) {
    if (!(radius > 0)) return [v];
    const l1 = dist(prev, v), l2 = dist(v, next);
    const d1 = { z: (v.z - prev.z) / l1, r: (v.r - prev.r) / l1 };
    const d2 = { z: (next.z - v.z) / l2, r: (next.r - v.r) / l2 };
    const cross = d1.z * d2.r - d1.r * d2.z;
    const theta = Math.acos(Math.max(-1, Math.min(1, d1.z * d2.z + d1.r * d2.r)));
    if (theta < 1e-6) return [v];
    const tan = Math.tan(theta / 2);
    const t = Math.min(radius * tan, maxT);
    const rho = t / tan;
    const s = cross < 0 ? -1 : 1;
    const a = { z: v.z - d1.z * t, r: v.r - d1.r * t };
    const cz = a.z - s * d1.r * rho, cr = a.r + s * d1.z * rho;
    const a0 = Math.atan2(a.r - cr, a.z - cz);
    return arc(cz, cr, rho, a0, a0 + s * theta);
  }

  const missingOf = (obj, keys) => keys.filter((k) => !isNum(obj[k]));
  const names = (keys) => keys.map(F.symbol).join(', ');

  function buildOuter(c, type, notes) {
    const h = c.cartridge.caseHead, p = c.cartridge.powderChamber, jc = c.cartridge.junctionCone || {}, len = c.cartridge.lengths, col = c.cartridge.collar;
    const { R, R1, E, E1, eMin, beta, f, delta, R3 } = h;
    const P1 = p.P1;
    const pts = [{ z: 0, r: 0 }];
    let rampEnd = null;

    // rule 2: head face and rim edge
    if (type === 'rimfire') {
      const rho = Math.min(R / 2, (R1 - P1) / 2);
      for (const q of arc(R1 / 2 - rho, rho, rho, -Math.PI / 2, 0)) push(pts, q.r, q.z);
      for (const q of arc(R1 / 2 - rho, R - rho, rho, 0, Math.PI / 2)) push(pts, q.r, q.z);
    } else {
      const chamfer = [beta, f].filter(isNum).length;
      if (chamfer === 1) notes.push(`Head chamfer not drawn: ${names(missingOf(h, ['beta', 'f']))} missing`);
      if (chamfer === 2 && deg(beta) < 90) {
        push(pts, 0, R1 / 2 - Math.min(f * Math.tan(deg(beta) * RAD), R1 / 4));
        push(pts, f, R1 / 2);
      } else push(pts, 0, R1 / 2);
      push(pts, R, R1 / 2);
    }

    // rule 3: extractor groove or belt, otherwise a plain step to the body
    const groove = [E, E1, eMin].filter(isNum).length;
    if (groove === 3) {
      push(pts, R, E1 / 2);
      push(pts, R + eMin, E1 / 2);
      if (type === 'belted' && isNum(R3) && isNum(delta) && R3 > E1) {
        rampEnd = R + eMin + (R3 / 2 - E1 / 2) / Math.tan(deg(delta) * RAD);
        push(pts, rampEnd, R3 / 2);
        push(pts, E, R3 / 2);
        push(pts, E, P1 / 2);
      } else {
        if (type === 'belted') notes.push(`Belt not drawn: ${names(missingOf(h, ['R3', 'delta']))} missing`);
        push(pts, E, P1 / 2);
      }
    } else {
      if (groove > 0) notes.push(`Extractor groove not drawn: ${names(missingOf(h, ['E', 'E1', 'eMin']))} missing`);
      push(pts, R, P1 / 2);
    }
    const bodyStart = pts.length - 1;

    // rules 4-6: body, shoulder, neck, mouth
    const { L1, L2, L3 } = len;
    const P2 = p.P2, H1 = col.H1, H2 = col.H2, alpha = jc.alpha;
    const shoulderFields = { alpha, L1, L2, P2, H1 };
    const present = Object.keys(shoulderFields).filter((k) => shoulderFields[k] !== undefined).length;
    let shoulder = null;
    if (present === 5) {
      const v1 = { z: L1, r: P2 / 2 }, n = { z: L2, r: H1 / 2 }, m = { z: L3, r: H2 / 2 };
      const start = pts[bodyStart];
      const len12 = dist(v1, n);
      for (const q of corner(start, v1, n, jc.r1Min, Math.min(0.45 * len12, 0.9 * dist(start, v1)))) push(pts, q.z, q.r);
      for (const q of corner(v1, n, m, jc.r2, Math.min(0.45 * len12, 0.9 * dist(n, m)))) push(pts, q.z, q.r);
      push(pts, m.z, m.r);
      const slope = (v1.r - n.r) / (n.z - v1.z);
      shoulder = { v1, n, apexZ: n.z + n.r / slope, alpha };
    } else {
      if (present > 0) notes.push(`Shoulder not drawn: ${names(Object.keys(shoulderFields).filter((k) => shoulderFields[k] === undefined))} missing`);
      push(pts, L3, H2 / 2);
    }
    return { pts, bodyStart, rampEnd, shoulder };
  }

  function bulletModel(c, heeled, tb, notes) {
    const G1 = c.cartridge.projectile.G1, H2 = c.cartridge.collar.H2, { L3, L6 } = c.cartridge.lengths;
    const shape = c.annotations.defaultBulletShape;
    const pistol = c.annotations.category === 'pistol';
    const SHAPES = {
      pointy: { s: 1.0, k: 0.4, m: Math.max(0.08 * G1, 1.27) },
      rounded: { s: pistol ? 0.4 : 0.8, k: pistol ? 0.65 : 0.55, m: 0.15 * G1 },
      flat: { s: pistol ? 0.4 : 0.8, k: pistol ? 0.7 : 0.6, m: 0.55 * G1 },
      semi_wadcutter: { s: 0.6, k: 0.78, m: 0.6 * G1 },
    };
    const sh = SHAPES[shape];
    if (!sh) { notes.push(`Bullet not drawn: bullet shape ${shape === undefined ? '' : shape + ' '}unknown`); return null; }
    const rExp = heeled ? H2 / 2 : G1 / 2;
    const rSeat = heeled ? H2 / 2 - tb : G1 / 2;
    const zb = L3 - sh.s * G1;
    const zc = zb + sh.k * (L6 - zb);
    const n = L6 - zc, m = sh.m;
    const nose = [{ z: zc, r: rExp }];
    let rho = null;
    if (shape === 'pointy') {
      const a = rExp - m / 2;
      rho = (a * a + n * n) / (2 * a);
      const phi = Math.asin(n / rho);
      for (let i = 1; i < 24; i++) nose.push({ z: zc + rho * Math.sin((phi * i) / 24), r: rExp - rho + rho * Math.cos((phi * i) / 24) });
    } else if (shape === 'rounded') {
      for (let i = 1; i < 24; i++) {
        const t = (Math.PI / 2) * (i / 24);
        nose.push({ z: zc + n * Math.sin(t), r: m / 2 + (rExp - m / 2) * Math.cos(t) });
      }
    }
    nose.push({ z: L6, r: m / 2 });
    const profile = [{ z: zb, r: rSeat }];
    if (heeled) profile.push({ z: L3, r: rSeat }, { z: L3, r: rExp });
    profile.push(...nose);
    return {
      zb, zc, rho, meplat: m, rExp,
      section: [{ z: zb, r: 0 }, ...profile, { z: L6, r: 0 }],
      exposed: [{ z: L3, r: rExp }, ...profile.filter((q) => q.z > L3 + 1e-9), { z: L6, r: 0 }],
    };
  }

  function buildModel(c) {
    const k = c.cartridge;
    const core = [...missingOf(k.caseHead, ['R', 'R1']), ...missingOf(k.powderChamber, ['P1']), ...missingOf(k.lengths, ['L3', 'L6'])];
    if (core.length) return { missing: core };
    const notes = [];
    const type = rimType(c);
    const { pts: outer, bodyStart, rampEnd, shoulder } = buildOuter(c, type, notes);
    const { P1 } = k.powderChamber, { H2 } = k.collar, { G1 } = k.projectile, { L1, L2, L3 } = k.lengths, E = k.caseHead.E;

    // rule 8: walls, solid head, primer pocket
    const heeled = H2 - G1 <= 0.015;
    const tb = Math.min(Math.max(1.3 * ((H2 - G1) / 2), 0.6), (0.35 * P1) / 2);
    const tn = heeled ? tb : (H2 - G1) / 2;
    const z0 = outer[bodyStart].z;
    const wall = (z) => (shoulder ? (z <= L1 ? tb : z >= L2 ? tn : tb + ((tn - tb) * (z - L1)) / (L2 - L1)) : tb + ((tn - tb) * (z - z0)) / (L3 - z0));
    let pocket = null;
    const primer = c.annotations.primerType;
    if (primer in POCKET) pocket = { d: POCKET[primer][0], depth: POCKET[primer][1] };
    else if (primer !== 'rimfire') notes.push('Primer pocket not drawn: primer type missing');
    const grooved = outer.some((q) => Math.abs(q.r - k.caseHead.E1 / 2) < 1e-9);
    const w = Math.max(2.5, (0.25 * P1) / 2, pocket ? pocket.depth + 1.5 : 0, grooved ? (rampEnd !== null ? rampEnd : E) + tb : 0);

    const body = outer.slice(bodyStart);
    const inner = [{ z: w, r: rAt(body, w) - wall(w) }];
    for (const q of body) if (q.z > w) inner.push({ z: q.z, r: q.r - wall(q.z) });

    return { rimType: type, heeled, notes, outer, bodyStart, shoulder, walls: { tn, tb, w }, inner, pocket, bullet: bulletModel(c, heeled, tb, notes) };
  }

  const api = { rimType, rAt, maxR, buildModel };
  if (typeof module !== 'undefined') module.exports = api;
  else (window.CIP = window.CIP || {}).geometry = api;
})();
