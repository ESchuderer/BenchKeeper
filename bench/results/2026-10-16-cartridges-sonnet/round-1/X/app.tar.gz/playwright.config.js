const fs = require('fs');
const os = require('os');
const path = require('path');

// The container ships Chromium under ms-playwright; use it when the bundled revision is not installed.
function installedChromium() {
  const base = path.join(os.homedir(), '.cache', 'ms-playwright');
  if (!fs.existsSync(base)) return undefined;
  const dir = fs.readdirSync(base).filter((d) => d.startsWith('chromium-')).sort().pop();
  const exe = dir && path.join(base, dir, 'chrome-linux64', 'chrome');
  return exe && fs.existsSync(exe) ? exe : undefined;
}

module.exports = {
  testDir: 'tests/e2e',
  fullyParallel: true,
  reporter: 'list',
  use: {
    browserName: 'chromium',
    launchOptions: { executablePath: process.env.CHROMIUM_PATH || installedChromium(), args: ['--no-sandbox'] },
  },
};
