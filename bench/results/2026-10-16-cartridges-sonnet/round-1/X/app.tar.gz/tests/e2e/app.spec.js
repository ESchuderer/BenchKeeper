const { test, expect } = require('@playwright/test');
const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const { pathToFileURL } = require('node:url');

const ROOT = path.resolve(__dirname, '../..');
const DATA = require('../../js/data.js');
const TYPES = { '.html': 'text/html', '.js': 'text/javascript', '.css': 'text/css' };

let server, httpBase;
test.beforeAll(async () => {
  server = http.createServer((req, res) => {
    const file = path.join(ROOT, req.url === '/' ? 'index.html' : decodeURIComponent(req.url.split('?')[0]));
    if (!file.startsWith(ROOT) || !fs.existsSync(file)) { res.writeHead(404).end(); return; }
    res.writeHead(200, { 'content-type': TYPES[path.extname(file)] || 'application/octet-stream' }).end(fs.readFileSync(file));
  });
  await new Promise((r) => server.listen(0, '127.0.0.1', r));
  httpBase = `http://127.0.0.1:${server.address().port}/`;
});
test.afterAll(() => server.close());

const modes = { file: () => pathToFileURL(path.join(ROOT, 'index.html')).href, http: () => httpBase };

for (const [mode, base] of Object.entries(modes)) {
  test.describe(`served as ${mode}`, () => {
    let problems;
    test.beforeEach(async ({ page }) => {
      problems = [];
      page.on('pageerror', (e) => problems.push(String(e)));
      page.on('request', (r) => { if (!/^(file|data|blob|about):/.test(r.url()) && !r.url().startsWith(httpBase)) problems.push('external request ' + r.url()); });
    });
    test.afterEach(() => expect(problems).toEqual([]));

    test('start page lists 25 cartridges and filters', async ({ page }) => {
      await page.goto(base());
      await expect(page.getByRole('heading', { name: 'Cartridges', level: 1 })).toBeVisible();
      await expect(page.getByText('25 cartridges')).toBeVisible();
      await expect(page.getByRole('link', { name: '223 Rem.', exact: true })).toBeVisible();
      await page.getByLabel('Search').fill('7,62 x 51');
      await expect(page.getByText('1 cartridges')).toBeVisible();
      await expect(page.getByRole('link', { name: '308 Win.', exact: true })).toBeVisible();
      await page.getByLabel('Search').fill('');
      await page.getByLabel('Family').selectOption('belted');
      await expect(page.getByText('2 cartridges')).toBeVisible();
      await page.getByLabel('Family').selectOption('All');
      await page.getByLabel('Search').fill('zzz');
      await expect(page.getByText('0 cartridges')).toBeVisible();
    });

    test('list row shows family and L3; link opens detail that survives reload', async ({ page }) => {
      await page.goto(base());
      const row = page.getByRole('row', { name: /^308 Win\./ });
      await expect(row).toContainText('rimless');
      await expect(row).toContainText('51.18 mm');
      await page.getByRole('link', { name: '308 Win.', exact: true }).click();
      await expect(page.getByRole('heading', { name: '308 Win.', level: 1 })).toBeVisible();
      await page.reload();
      await expect(page.getByRole('heading', { name: '308 Win.', level: 1 })).toBeVisible();
      await expect(page.getByRole('img', { name: '308 Win. drawing' })).toBeVisible();
      await page.getByRole('link', { name: 'All cartridges' }).click();
      await expect(page.getByRole('heading', { name: 'Cartridges', level: 1 })).toBeVisible();
    });

    test('detail meta, tables, tolerance, units', async ({ page }) => {
      await page.goto(base() + '#/308_win');
      const main = page.locator('main');
      for (const t of ['308 Winchester, 7,62 x 51', 'rimless', 'rifle', 'lr', '2008-09-23', '1984-06-14', 'Transducer', '56 gr H2O', 'US']) await expect(main).toContainText(t);
      await expect(page.getByRole('link', { name: 'kwk' })).toHaveAttribute('href', 'http://kwk.us/cases.html');
      const lengths = page.getByRole('table', { name: 'Cartridge lengths' });
      await expect(lengths.getByRole('columnheader')).toHaveText(['Symbol', 'Value', 'Unit']);
      await expect(lengths.getByRole('row', { name: /^L1 / }).locator('th, td')).toHaveText(['L1', '39.62 -0.2', 'mm']);
      await expect(lengths.getByRole('row', { name: /^L3 / }).locator('th, td')).toHaveText(['L3', '51.18', 'mm']);
      await expect(lengths.getByRole('row', { name: /^L1Tol/ })).toHaveCount(0);
      await expect(page.getByRole('table', { name: 'Cartridge pressures' }).getByRole('row', { name: /^Pmax/ }).locator('th, td')).toHaveText(["Pmax","4150","bar"]);
      await expect(page.getByRole('table', { name: 'Cartridge junction cone' }).getByRole('row', { name: /^α / }).locator('th, td')).toHaveText(["α","40°","deg"]);
      await expect(page.getByRole('table', { name: 'Chamber rifling' }).getByRole('row', { name: /^α1/ })).toContainText('71°25\'59"');
      await expect(page.getByRole('table', { name: 'Chamber grooves' }).getByRole('row', { name: /^Q / }).locator('th, td')).toHaveText(["Q","47.51","mm²"]);
      await expect(page.getByRole('button', { name: 'Print' })).toBeVisible();
    });

    test('unknown address shows not found', async ({ page }) => {
      await page.goto(base() + '#/nope');
      await expect(page.getByRole('heading', { name: 'Not found' })).toBeVisible();
    });
  });
}

test('drawing: real text boxes overlap neither each other nor the outline, for all 25', async ({ page }) => {
  await page.goto(pathToFileURL(path.join(ROOT, 'index.html')).href);
  for (const c of DATA) {
    await page.goto(pathToFileURL(path.join(ROOT, 'index.html')).href + '#/' + c.key);
    const res = await page.evaluate(() => {
      const svg = document.querySelector('svg[role="img"]');
      const boxes = [...svg.querySelectorAll('text.label')].map((t) => { const r = t.getBoundingClientRect(); return { t: t.textContent, x0: r.left, x1: r.right, y0: r.top, y1: r.bottom }; });
      const vb = svg.getBoundingClientRect();
      const m = svg.getScreenCTM();
      const segs = [];
      for (const p of svg.querySelectorAll('path.outline')) {
        const len = p.getTotalLength();
        let prev = null;
        for (let i = 0; i <= 400; i++) {
          const q = p.getPointAtLength((len * i) / 400);
          const pt = [q.x * m.a + m.e, q.y * m.d + m.f];
          if (prev) segs.push([prev, pt]);
          prev = pt;
        }
      }
      const all = [...svg.querySelectorAll('text')].map((t) => t.getBoundingClientRect());
      const inside = all.every((r) => r.left >= vb.left - 0.5 && r.right <= vb.right + 0.5 && r.top >= vb.top - 0.5 && r.bottom <= vb.bottom + 0.5);
      return { boxes, segs, inside, label: svg.getAttribute('aria-label') };
    });
    expect(res.label).toBe(`${c.name} drawing`);
    expect(res.inside, `${c.key} text inside svg`).toBe(true);
    const hit = (b, [p, q]) => { // segment against box, sampled
      for (let i = 0; i <= 4; i++) { const x = p[0] + ((q[0] - p[0]) * i) / 4, y = p[1] + ((q[1] - p[1]) * i) / 4; if (x > b.x0 && x < b.x1 && y > b.y0 && y < b.y1) return true; }
      return false;
    };
    res.boxes.forEach((a, i) => {
      for (const b of res.boxes.slice(i + 1)) expect(a.x0 < b.x1 && b.x0 < a.x1 && a.y0 < b.y1 && b.y0 < a.y1, `${c.key}: ${a.t} x ${b.t}`).toBe(false);
      expect(res.segs.some((s) => hit(a, s)), `${c.key}: ${a.t} on outline`).toBe(false);
    });
  }
});

test('print: A4 portrait, one page, light, controls hidden, for all 25', async ({ page }) => {
  for (const c of DATA) {
    await page.goto(pathToFileURL(path.join(ROOT, 'index.html')).href + '#/' + c.key);
    await page.emulateMedia({ media: 'print', colorScheme: 'dark' });
    expect(await page.locator('.actions').isVisible()).toBe(false);
    const bg = await page.evaluate(() => getComputedStyle(document.body).color);
    expect(bg).toBe('rgb(0, 0, 0)');
    const pdf = await page.pdf({ preferCSSPageSize: true, printBackground: true });
    const pages = (pdf.toString('latin1').match(/\/Type\s*\/Page[^s]/g) || []).length;
    expect(pages, `${c.key} pages`).toBe(1);
    await page.emulateMedia({ media: 'screen', colorScheme: 'light' });
  }
});
