const test = require('node:test');
const assert = require('node:assert/strict');
const { filterCartridges } = require('../../js/catalog.js');
const DATA = require('../../js/data.js');
const names = (l) => l.map((c) => c.name);

test('no filter lists all 25', () => {
  assert.equal(filterCartridges(DATA, '', 'All').length, 25);
});

test('search matches alternative names', () => {
  assert.deepEqual(names(filterCartridges(DATA, '7,62 x 51', 'All')), ['308 Win.']);
});

test('search is case-insensitive and ignores surrounding space', () => {
  assert.deepEqual(names(filterCartridges(DATA, '  CREEDMOOR ', 'All')), ['6,5 Creedmoor']);
});

test('family filter combines with search', () => {
  assert.equal(filterCartridges(DATA, '', 'belted').length, 2);
  assert.equal(filterCartridges(DATA, '', 'rimfire').length, 3);
  assert.deepEqual(names(filterCartridges(DATA, '22', 'rimfire')), ['22 Long Rifle', '22 Win. Mag. R.F.']);
  assert.equal(filterCartridges(DATA, '308', 'pistol').length, 0);
});
