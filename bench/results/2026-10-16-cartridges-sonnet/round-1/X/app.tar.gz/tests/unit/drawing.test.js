const test = require('node:test');
const assert = require('node:assert/strict');
const D = require('../../js/drawing.js');
const DATA = require('../../js/data.js');

const inter = (a, b) => a.x0 < b.x1 && b.x0 < a.x1 && a.y0 < b.y1 && b.y0 < a.y1;
// does segment p-q touch box (Liang-Barsky)
function segHits(p, q, b) {
  let t0 = 0, t1 = 1;
  const dx = q[0] - p[0], dy = q[1] - p[1];
  for (const [pp, qq] of [[-dx, p[0] - b.x0], [dx, b.x1 - p[0]], [-dy, p[1] - b.y0], [dy, b.y1 - p[1]]]) {
    if (pp === 0) { if (qq < 0) return false; } else { const t = qq / pp; if (pp < 0) t0 = Math.max(t0, t); else t1 = Math.min(t1, t); }
  }
  return t0 <= t1;
}

test('every drawing has required dimension labels', () => {
  for (const c of DATA) {
    const d = D.buildDrawing(c);
    const txt = d.labels.map((l) => l.text);
    const k = c.cartridge;
    for (const want of [`L3 ${k.lengths.L3}`, `L6 ${k.lengths.L6}`, `R1 ${k.caseHead.R1}`, `R ${k.caseHead.R}`, `P1 ${k.powderChamber.P1}`, `H2 ${k.collar.H2}`, `G1 ${k.projectile.G1}`]) assert.ok(txt.includes(want), `${c.key} ${want}`);
    if (k.lengths.L1 !== undefined) for (const want of [`L1 ${k.lengths.L1}`, `L2 ${k.lengths.L2}`, `P2 ${k.powderChamber.P2}`, `H1 ${k.collar.H1}`]) assert.ok(txt.includes(want), `${c.key} ${want}`);
    assert.equal(txt.some((t) => t.startsWith('α ')), k.lengths.L1 !== undefined, c.key);
    assert.equal(txt.some((t) => t.startsWith('E1 ')), k.caseHead.E1 !== undefined, c.key);
  }
});

test('labels use the published angle format', () => {
  const t = D.buildDrawing(DATA.find((c) => c.key === '6_5_x_55_se')).labels.map((l) => l.text);
  assert.ok(t.includes('α 50°35\'2"'));
});

test('labels overlap neither each other nor the outline (estimated boxes)', () => {
  for (const c of DATA) {
    const d = D.buildDrawing(c);
    d.labels.forEach((a, i) => {
      for (const b of d.labels.slice(i + 1)) assert.ok(!inter(a.box, b.box), `${c.key}: ${a.text} x ${b.text}`);
      for (const line of d.outline) for (let j = 1; j < line.length; j++) assert.ok(!segHits(line[j - 1], line[j], a.box), `${c.key}: ${a.text} on outline`);
    });
  }
});

test('content lies inside the view box and the sheet is 190 / S mm wide', () => {
  for (const c of DATA) {
    const d = D.buildDrawing(c);
    const [x, y, w, h] = d.viewBox;
    assert.ok(Math.abs(w - 190 / d.S) < 1e-2, c.key);
    assert.ok(d.bounds.x0 >= x - 1e-6 && d.bounds.x1 <= x + w + 1e-6, `${c.key} x`);
    assert.ok(d.bounds.y0 >= y - 1e-6 && d.bounds.y1 <= y + h + 1e-6, `${c.key} y`);
  }
});

test('true to scale: tip and mouth are L6 and L3 mm from the head face', () => {
  const c = DATA[0];
  const d = D.buildDrawing(c);
  const xs = d.outline.flat().map((p) => p[0]);
  assert.equal(Math.min(...xs), 0);
  assert.ok(Math.abs(Math.max(...xs) - c.cartridge.lengths.L6) < 1e-9);
});

test('svg has accessible name, title block and escapes names', () => {
  const c = DATA.find((x) => x.key === '40_s_w');
  const svg = D.renderSvg(D.buildDrawing(c));
  assert.match(svg, /role="img" aria-label="40 S\.&amp; W\. drawing"/);
  for (const t of ['Dimensions in mm', 'Scale ', 'Revised 2000-06-07', 'C.I.P. table IV', '>40 S.&amp; W.<']) assert.ok(svg.includes(t), t);
  assert.ok(!svg.includes('NaN'));
});

test('missing core value gives no svg', () => {
  const c = JSON.parse(JSON.stringify(DATA[0]));
  delete c.cartridge.caseHead.R1;
  const d = D.buildDrawing(c);
  assert.deepEqual(d.missing, ['R1']);
  assert.equal(D.renderSvg(d), '');
});
