const test = require('node:test');
const assert = require('node:assert/strict');
const F = require('../../js/format.js');
const DATA = require('../../js/data.js');

test('numbers show as published, no grouping', () => {
  assert.equal(F.formatNumber(4150.0), '4150');
  assert.equal(F.formatNumber(51.18), '51.18');
  assert.equal(F.formatNumber(-0.25), '-0.25');
});

test('angles: degrees or d m s', () => {
  assert.equal(F.formatAngle(40.0), '40°');
  assert.equal(F.formatAngle({ degrees: 39, minutes: 59, seconds: 49 }), '39°59\'49"');
  assert.equal(F.formatAngle({ degrees: 34, minutes: 30, seconds: 0 }), '34°30\'0"');
  assert.equal(F.toDegrees({ degrees: 30, minutes: 30, seconds: 0 }), 30.5);
  assert.equal(F.toDegrees(45), 45);
});

test('symbols', () => {
  const s = { eMin: 'e min', r1Min: 'r1 min', r1Max: 'r1 max', alpha: 'α', alpha1: 'α1', beta: 'β', delta: 'δ', deltaL: 'delta L', L3PlusG: 'L3 + G', L3: 'L3', Pmax: 'Pmax', r: 'r' };
  for (const [k, v] of Object.entries(s)) assert.equal(F.symbol(k), v, k);
});

test('units', () => {
  const u = { Pmax: 'bar', PK: 'bar', PE: 'bar', EE: 'J', M: 'g', Q: 'mm²', N: '', alpha: 'deg', alpha1: 'deg', beta: 'deg', delta: 'deg', i: 'deg', L3: 'mm', deltaL: 'mm', P1: 'mm', u: 'mm' };
  for (const [k, v] of Object.entries(u)) assert.equal(F.unit(k), v, k);
});

test('rows: tolerance joins its value and has no row of its own', () => {
  const rows = F.sectionRows(DATA[6].cartridge.lengths); // 308 Win.
  assert.deepEqual(rows.map((r) => r.symbol), ['L1', 'L2', 'L3', 'L6']);
  assert.deepEqual(rows[0], { symbol: 'L1', value: '39.62', tol: '-0.2', unit: 'mm' });
  assert.equal(rows[2].tol, undefined);
});

test('rows: angle values carry the degree sign', () => {
  const rows = F.sectionRows(DATA[3].cartridge.junctionCone); // 6,5 x 55 SE
  const alpha = rows.find((r) => r.symbol === 'α');
  assert.equal(alpha.value, '50°35\'2"');
  assert.equal(alpha.unit, 'deg');
});

test('section title from camelCase key', () => {
  assert.equal(F.sectionTitle('caseHead'), 'Case head');
  assert.equal(F.sectionTitle('junctionCone'), 'Junction cone');
  assert.equal(F.sectionTitle('misc'), 'Misc');
});

test('all 25 records: every value is formatted, no Tol row, no NaN', () => {
  assert.equal(DATA.length, 25);
  for (const c of DATA) for (const part of [c.cartridge, c.chamber]) for (const sec of Object.values(part)) {
    const rows = F.sectionRows(sec);
    assert.equal(rows.length, Object.keys(sec).filter((k) => !k.endsWith('Tol')).length);
    for (const r of rows) assert.ok(r.value && !/NaN|undefined|object/.test(r.value), `${c.key} ${r.symbol}`);
  }
});
