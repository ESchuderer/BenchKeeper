const test = require('node:test');
const assert = require('node:assert/strict');
const G = require('../../js/geometry.js');
const DATA = require('../../js/data.js');

const get = (key) => DATA.find((c) => c.key === key);
const near = (a, b, tol = 1e-3, msg) => assert.ok(Math.abs(a - b) <= tol, `${msg || ''} ${a} vs ${b}`);
const clone = (c) => JSON.parse(JSON.stringify(c));

test('rim type follows rule 1', () => {
  assert.equal(G.rimType(get('223_rem')), 'rimless');
  assert.equal(G.rimType(get('300_win_mag')), 'belted');
  assert.equal(G.rimType(get('9_3_x_74_r')), 'rimmed');
  assert.equal(G.rimType(get('38_special')), 'rimmed');
  assert.equal(G.rimType(get('22_long_rifle')), 'rimfire');
  const c = clone(get('223_rem'));
  c.cartridge.caseHead.R1 = c.cartridge.powderChamber.P1 * 1.05;
  assert.equal(G.rimType(c), 'rimmed');
  c.cartridge.caseHead.R1 = c.cartridge.powderChamber.P1 * 0.97;
  assert.equal(G.rimType(c), 'rebated');
  c.cartridge.caseHead.R1 = c.cartridge.powderChamber.P1 * 0.98;
  assert.equal(G.rimType(c), 'rimless');
});

test('223 Rem. head: chamfer, rim, groove, ramp', () => {
  const o = G.buildModel(get('223_rem')).outer;
  const want = [[0, 0], [0, 4.8 - 0.45 * Math.tan((35 * Math.PI) / 180)], [0.45, 4.8], [1.14, 4.8], [1.14, 4.215], [1.9, 4.215], [3.13, 4.79]];
  want.forEach(([z, r], i) => { near(o[i].z, z, 1e-3, `z${i}`); near(o[i].r, r, 1e-3, `r${i}`); });
});

test('chamfer width is capped at R1/4', () => {
  const c = clone(get('223_rem'));
  c.cartridge.caseHead.f = 50;
  near(G.buildModel(c).outer[1].r, 4.8 - 2.4);
});

test('belted 300 Win. Mag.: ramp at delta to the belt, belt to E, step in to P1/2', () => {
  const m = G.buildModel(get('300_win_mag'));
  const h = get('300_win_mag').cartridge.caseHead;
  const o = m.outer;
  const i = o.findIndex((p) => Math.abs(p.r - h.R3 / 2) < 1e-9 && p.z > h.R + h.eMin);
  near(o[i].z, h.R + h.eMin + (h.R3 / 2 - h.E1 / 2) / Math.tan((35 * Math.PI) / 180));
  near(o[i + 1].z, h.E);
  near(o[i + 1].r, h.R3 / 2);
  near(o[i + 2].z, h.E);
  near(o[i + 2].r, 13.03 / 2);
  assert.equal(m.outer[m.bodyStart].z, h.E);
});

test('rimfire 22 LR: half-round rim edge, outermost point at R1/2', () => {
  const m = G.buildModel(get('22_long_rifle'));
  const rho = 1.09 / 2;
  near(m.outer[1].r, 7.06 / 2 - rho);
  near(Math.max(...m.outer.map((p) => p.r)), 7.06 / 2);
  const top = m.outer.find((p) => Math.abs(p.r - 7.06 / 2) < 1e-9);
  near(top.z, rho);
  const end = m.outer[m.outer.length - 1];
  near(end.z, 15.57); near(end.r, 5.72 / 2);
  assert.equal(m.notes.length, 0);
});

test('rimmed without groove: step in at z = R', () => {
  const m = G.buildModel(get('9_3_x_74_r'));
  const i = m.bodyStart;
  near(m.outer[i].z, 1.4); near(m.outer[i].r, 11.9 / 2);
  near(m.outer[i - 1].r, 13.35 / 2); near(m.outer[i - 1].z, 1.4);
  assert.equal(m.notes.length, 0, m.notes.join());
});

test('bottleneck: shoulder lies on the line through (P2/2, L1) and (H1/2, L2)', () => {
  const m = G.buildModel(get('308_win'));
  const k = get('308_win').cartridge;
  const zm = (k.lengths.L1 + k.lengths.L2) / 2;
  near(G.rAt(m.outer, zm), (k.powderChamber.P2 + k.collar.H1) / 4, 1e-6);
  const end = m.outer[m.outer.length - 1];
  near(end.z, k.lengths.L3); near(end.r, k.collar.H2 / 2);
});

test('fillets only where published', () => {
  const withR = G.buildModel(get('223_rem')).outer.length;
  const c = clone(get('223_rem'));
  delete c.cartridge.junctionCone.r1Min; delete c.cartridge.junctionCone.r2;
  assert.ok(withR > G.buildModel(c).outer.length + 10);
  assert.ok(G.buildModel(get('338_lapua_mag')).outer.length > G.buildModel(c).outer.length); // r2 only
});

test('fillet radius is clamped to the available length', () => {
  const c = clone(get('223_rem'));
  c.cartridge.junctionCone.r1Min = 50; c.cartridge.junctionCone.r2 = 50;
  const o = G.buildModel(c).outer;
  for (const p of o) assert.ok(Number.isFinite(p.z) && Number.isFinite(p.r));
  for (let i = 1; i < o.length; i++) assert.ok(o[i].z >= o[i - 1].z - 1e-9, `z non-decreasing at ${i}`);
});

test('straight case (no alpha, L1, L2): body runs to (H2/2, L3)', () => {
  const m = G.buildModel(get('9_mm_luger'));
  const end = m.outer[m.outer.length - 1];
  near(end.z, 19.15); near(end.r, 9.65 / 2);
  assert.equal(m.outer.length, m.bodyStart + 2);
  assert.equal(m.notes.length, 0);
});

test('outer profile is monotonic in z for all 25 and ends at the mouth', () => {
  for (const c of DATA) {
    const m = G.buildModel(c);
    assert.ok(!m.missing, c.key);
    for (let i = 1; i < m.outer.length; i++) assert.ok(m.outer[i].z >= m.outer[i - 1].z - 1e-9, `${c.key} ${i}`);
    for (const p of m.outer) assert.ok(p.r >= 0, c.key);
    assert.equal(m.outer[0].z, 0); assert.equal(m.outer[0].r, 0);
    near(m.outer[m.outer.length - 1].z, c.cartridge.lengths.L3);
  }
});

test('partly published groove is skipped and named in the notes (rule 9)', () => {
  const c = clone(get('223_rem'));
  delete c.cartridge.caseHead.eMin;
  const m = G.buildModel(c);
  assert.ok(m.notes.some((n) => /groove/i.test(n) && /e min/.test(n)), m.notes.join());
  near(m.outer[m.bodyStart].z, 1.14);
});

test('partly published shoulder is skipped and named', () => {
  const c = clone(get('223_rem'));
  delete c.cartridge.lengths.L2;
  const m = G.buildModel(c);
  assert.ok(m.notes.some((n) => /shoulder/i.test(n) && /L2/.test(n)), m.notes.join());
  assert.equal(m.shoulder, null);
});

test('missing core value: no drawing, value named', () => {
  const c = clone(get('223_rem'));
  delete c.cartridge.lengths.L6;
  assert.deepEqual(G.buildModel(c).missing, ['L6']);
});

test('bullet pointy 223: seating, cylinder, tangent ogive with meplat', () => {
  const m = G.buildModel(get('223_rem'));
  const b = m.bullet;
  near(b.zb, 44.7 - 5.7); near(b.zc, 39 + 0.4 * (57.4 - 39));
  near(b.meplat, 1.27);
  const tip = b.section[b.section.length - 2];
  near(tip.z, 57.4); near(tip.r, 0.635);
  const a = 2.85 - 0.635, n = 57.4 - b.zc, rho = (a * a + n * n) / (2 * a);
  near(b.rho, rho);
  for (const p of b.section.filter((p) => p.z > b.zc && p.z < 57.4)) near(Math.hypot(p.z - b.zc, p.r - (2.85 - rho)), rho, 1e-6);
  near(b.exposed[0].z, 44.7); near(b.exposed[0].r, 2.85);
  assert.equal(b.exposed[b.exposed.length - 1].r, 0);
});

test('bullet shapes: seating and meplat per rule 7', () => {
  const cases = [['9_mm_luger', 0.4 * 9.03, 0.15 * 9.03], ['40_s_w', 0.4 * 10.17, 0.55 * 10.17], ['357_magnum', 0.6 * 9.12, 0.6 * 9.12], ['22_win_mag_r_f', 0.8 * 5.7, 0.15 * 5.7], ['17_hmr', 4.38, Math.max(0.08 * 4.38, 1.27)]];
  for (const [key, s, m] of cases) {
    const c = get(key), b = G.buildModel(c).bullet;
    near(b.zb, c.cartridge.lengths.L3 - s, 1e-9, key);
    near(b.meplat, m, 1e-9, key);
  }
  const b = G.buildModel(get('357_magnum')).bullet; // k = 0.78
  near(b.zc, b.zb + 0.78 * (40.39 - b.zb));
  const r = G.buildModel(get('9_mm_luger')).bullet; // rounded pistol k = 0.65
  near(r.zc, r.zb + 0.65 * (29.69 - r.zb));
});

test('rounded nose is a quarter ellipse ending in a flat meplat', () => {
  const b = G.buildModel(get('9_mm_luger')).bullet;
  const m = 0.15 * 9.03, a = 9.03 / 2 - m / 2, n = 29.69 - b.zc;
  for (const p of b.section.filter((p) => p.z > b.zc && p.z < 29.69)) near(Math.hypot((p.z - b.zc) / n, (p.r - m / 2) / a), 1, 1e-6);
});

test('heeled 22 LR: exposed bullet at case OD, seated heel at case ID', () => {
  const m = G.buildModel(get('22_long_rifle'));
  const b = m.bullet;
  assert.equal(m.heeled, true);
  near(b.exposed[0].r, 5.72 / 2);
  near(b.section[1].r, 5.72 / 2 - m.walls.tb);
  near(m.walls.tn, m.walls.tb);
  assert.equal(G.buildModel(get('22_win_mag_r_f')).heeled, false);
});

test('walls and solid head', () => {
  let m = G.buildModel(get('223_rem'));
  near(m.walls.tn, 0.365); near(m.walls.tb, 0.6); near(m.walls.w, 4.54);
  near(m.pocket.d, 4.45); near(m.pocket.depth, 3.04);
  m = G.buildModel(get('308_win'));
  near(m.walls.w, 4.8); near(m.pocket.d, 5.33); near(m.pocket.depth, 3.3);
  m = G.buildModel(get('22_long_rifle'));
  near(m.walls.w, 2.5); assert.equal(m.pocket, null);
  m = G.buildModel(get('300_win_mag'));
  near(m.walls.w, 4.8);
  m = G.buildModel(get('45_auto'));
  near(m.pocket.d, 5.33); near(m.pocket.depth, 3.04); near(m.walls.tb, 0.6);
});

test('body wall is capped at 0.35 * P1/2 and floors at 0.6', () => {
  const c = clone(get('223_rem'));
  c.cartridge.collar.H2 = 5.7 + 2 * 1.2;
  near(G.buildModel(c).walls.tb, 1.56);
  c.cartridge.collar.H2 = 5.7 + 2 * 3;
  near(G.buildModel(c).walls.tb, (0.35 * 9.58) / 2);
});

test('inner line: tb along the body, tn along the neck, linear across the shoulder', () => {
  const m = G.buildModel(get('308_win'));
  const k = get('308_win').cartridge;
  const { tb, tn, w } = m.walls;
  near(m.inner[0].z, w);
  near(m.inner[0].r, G.rAt(m.outer, w) - tb);
  const last = m.inner[m.inner.length - 1];
  near(last.z, k.lengths.L3); near(last.r, k.collar.H2 / 2 - tn); near(last.r, k.projectile.G1 / 2);
  const zm = (k.lengths.L1 + k.lengths.L2) / 2;
  near(G.rAt(m.outer, zm) - G.rAt(m.inner, zm), (tb + tn) / 2, 2e-3);
  for (let i = 1; i < m.inner.length; i++) assert.ok(m.inner[i].z >= m.inner[i - 1].z - 1e-9);
});

test('all 25 build with a bullet, walls and no notes', () => {
  for (const c of DATA) {
    const m = G.buildModel(c);
    assert.ok(m.bullet, c.key);
    assert.deepEqual(m.notes, [], c.key);
    assert.ok(m.inner.every((p) => p.r > 0 && p.r < c.cartridge.caseHead.R1 / 2), c.key);
    near(m.bullet.section[m.bullet.section.length - 1].z, c.cartridge.lengths.L6);
  }
});
