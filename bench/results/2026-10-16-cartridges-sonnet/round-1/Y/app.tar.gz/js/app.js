// DOM glue: list with search and family filter, detail view, hash routes (#/ and #/cartridge/<key>).
(function () {
  const { CARTRIDGES, Format, Catalog, Drawing } = window;
  const $ = (id) => document.getElementById(id);
  const listView = $('list-view'), detailView = $('detail-view');
  const esc = (s) => String(s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  const href = (r) => '#/cartridge/' + encodeURIComponent(r.key);

  function renderList() {
    const rows = Catalog.filter(CARTRIDGES, $('search').value, $('family').value);
    $('list').innerHTML = rows
      .map((r) => {
        const l3 = Format.sectionRows({ L3: r.cartridge.lengths.L3, L3Tol: r.cartridge.lengths.L3Tol })[0];
        return `<tr><td><a href="${href(r)}">${esc(r.name)}</a></td><td>${esc(r.family)}</td><td class="num">${esc(Format.valueText(l3))}</td></tr>`;
      })
      .join('');
    $('count').textContent = rows.length + ' cartridges';
  }

  function table(s) {
    const body = s.rows
      .map((row) => `<tr><th scope="row">${esc(row.symbol)}</th><td class="num">${esc(Format.valueText(row))}</td><td class="unit">${esc(row.unit)}</td></tr>`)
      .join('');
    return `<table class="values"><caption>${esc(s.title)}</caption><thead><tr><th scope="col">Symbol</th><th scope="col" class="num">Value</th><th scope="col">Unit</th></tr></thead><tbody>${body}</tbody></table>`;
  }

  function meta(r) {
    const cap = r.annotations.publishedCapacity;
    const capacity = cap
      ? `${esc(Format.formatNumber(cap.grH2O))} gr H2O (<a href="${esc(cap.url)}" rel="noopener">${esc(cap.source)}</a>${cap.note ? ', ' + esc(cap.note) : ''})`
      : 'not published';
    const items = [
      r.alternativeNames && ['Alternative names', esc(r.alternativeNames.join(', '))],
      ['Family', esc(r.family)],
      ['Category', esc(r.annotations.category)],
      ['Primer type', esc(r.annotations.primerType)],
      ['C.I.P. table', esc(r.tab)],
      ['Country', esc(r.country)],
      ['Published', esc(r.published)],
      ['Revised', esc(r.revised)],
      ['Pressure method', esc(r.pressureMethod)],
      ['Water capacity', capacity]
    ].filter(Boolean);
    return '<dl class="meta">' + items.map(([k, v]) => `<div><dt>${k}</dt><dd>${v}</dd></div>`).join('') + '</dl>';
  }

  function group(title, part) {
    return `<section class="group"><h2>${title}</h2><div class="tables">${Format.sections(part).map(table).join('')}</div></section>`;
  }

  function renderDetail(r) {
    const d = Drawing.draw(r);
    const notes = d.notes.length ? `<ul class="notes">${d.notes.map((n) => `<li>${esc(n)}</li>`).join('')}</ul>` : '';
    detailView.innerHTML =
      `<nav class="actions no-print"><a href="#/">All cartridges</a><button type="button" id="print">Print</button></nav>` +
      `<h1 tabindex="-1">${esc(r.name)}</h1>${meta(r)}` +
      `<figure class="drawing-box">${d.svg}${notes}</figure>` +
      `<div class="groups">${group('Cartridge', r.cartridge)}${group('Chamber', r.chamber)}</div>` +
      `<footer class="source">Source: C.I.P. TDCC, revised ${esc(r.revised)}</footer>`;
    document.title = r.name + ' - Cartridges';
  }

  function route(moved) {
    const m = /^#\/cartridge\/([^/]+)$/.exec(location.hash);
    let key = m && m[1];
    try { key = m && decodeURIComponent(m[1]); } catch (e) { /* malformed escape: no such key */ }
    const r = m && CARTRIDGES.find((c) => c.key === key);
    listView.hidden = !!m;
    detailView.hidden = !m;
    if (!m) document.title = 'Cartridges';
    else if (r) renderDetail(r);
    else {
      detailView.innerHTML = '<nav class="actions"><a href="#/">All cartridges</a></nav><h1 tabindex="-1">Cartridge not found</h1>';
      document.title = 'Cartridge not found';
    }
    if (moved) {
      window.scrollTo(0, 0);
      (m ? detailView : listView).querySelector('h1').focus({ preventScroll: true });
    }
  }

  $('search').addEventListener('input', renderList);
  $('family').addEventListener('change', renderList);
  detailView.addEventListener('click', (e) => {
    if (e.target.id === 'print') window.print();
  });
  window.addEventListener('hashchange', () => route(true));
  renderList();
  route(false);
})();
