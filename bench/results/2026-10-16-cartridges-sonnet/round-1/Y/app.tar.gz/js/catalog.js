// Search and family filter of the cartridge list.
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.Catalog = factory();
})(this, function () {
  const norm = (s) => s.toLowerCase().replace(/\s+/g, '');

  function filter(list, query, family) {
    const q = norm(query || '');
    return list.filter(
      (r) =>
        (!family || family === 'All' || r.family === family) &&
        [r.name, ...(r.alternativeNames || [])].some((n) => norm(n).includes(q))
    );
  }

  return { filter };
});
