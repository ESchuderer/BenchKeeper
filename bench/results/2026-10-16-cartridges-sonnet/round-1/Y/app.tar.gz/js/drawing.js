// SVG drawing of a cartridge: 1 user unit = 1 mm, axis horizontal, head left, outside view above the
// axis (y = -r), section below (y = +r). Pure string output plus a layout description for tests.
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory(require('./geometry.js'), require('./format.js'));
  else root.Drawing = factory(root.Geometry, root.Format);
})(this, function (Geometry, Format) {
  const FS = 3; // label font size, mm
  const CW = 0.62 * FS; // monospace advance
  const ASC = 0.8 * FS, DESC = 0.2 * FS;
  const ARROW = { len: 1.8, half: 0.6 };
  const LINE_H = ASC + DESC;
  const TRACK_PITCH = 4;
  const PRINT_WIDTH = 190; // mm, A4 portrait content width
  const PRINT_MAX_HEIGHT = 165; // mm, keeps the tables on the same page (css/app.css)
  const TB = { w: 92, h: 15 };
  const MIN_W = TB.w + 4;

  const num = (x) => String(Math.round(x * 1000) / 1000);
  const esc = (s) => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  const pts = (arr) => arr.map((p) => num(p.x) + ',' + num(p.y)).join(' ');
  const up = (poly) => poly.map((p) => ({ x: p.z, y: -p.r }));
  const down = (poly) => poly.map((p) => ({ x: p.z, y: p.r }));

  function draw(rec) {
    const m = Geometry.build(rec);
    const out = { model: m, notes: m.notes.map(Geometry.noteText), labels: [], segments: [], dims: [], hatch: [], outline: { upper: [], lower: [] }, title: [], viewBox: null, svg: '' };
    if (!m.outer) return out;
    const v = m.values, a = m.anchors, c = rec.cartridge, ch = c.caseHead, pc = c.powderChamber, ln = c.lengths, col = c.collar;
    const body = []; // svg fragments
    const seg = (kind, id, x1, y1, x2, y2) => out.segments.push({ kind, id, x1, y1, x2, y2 });
    const line = (cls, id, x1, y1, x2, y2) => {
      seg(cls, id, x1, y1, x2, y2);
      body.push(`<line class="${cls}" x1="${num(x1)}" y1="${num(y1)}" x2="${num(x2)}" y2="${num(y2)}"/>`);
    };
    const arrows = {};
    const arrow = (id, tx, ty, dx, dy, k = 1) => {
      const bx = tx - dx * ARROW.len * k, by = ty - dy * ARROW.len * k, px = -dy * ARROW.half * k, py = dx * ARROW.half * k;
      body.push(`<path class="arrow" d="M${num(tx)} ${num(ty)}L${num(bx + px)} ${num(by + py)}L${num(bx - px)} ${num(by - py)}Z"/>`);
      arrows[id] = (arrows[id] || 0) + 1;
    };
    const dimInfo = (id) => out.dims.find((d) => d.id === id) || (out.dims.push({ id, arrows: 0, ext: 0 }), out.dims[out.dims.length - 1]);
    const ext = (id, x1, y1, x2, y2) => { line('ext-line', id, x1, y1, x2, y2); dimInfo(id).ext++; };
    // second: optional second line (the tolerance), set below the first
    const label = (id, text, x, y, anchor, second) => {
      const w = Math.max(text.length, second ? second.length : 0) * CW;
      const x0 = anchor === 'middle' ? x - w / 2 : anchor === 'end' ? x - w : x;
      out.labels.push({ id, text: text + (second || ''), box: { x0, x1: x0 + w, y0: y - ASC, y1: y + (second ? LINE_H : 0) + DESC } });
      const inner = second
        ? `<tspan x="${num(x)}" y="${num(y)}">${esc(text)}</tspan><tspan x="${num(x)}" y="${num(y + LINE_H)}">${esc(second)}</tspan>`
        : esc(text);
      body.push(`<text class="dim-label" data-dim="${id}" x="${num(x)}" y="${num(y)}" text-anchor="${anchor}">${inner}</text>`);
    };
    const valueLabel = (id, key, value, tol) => Format.labelText(key, value, tol == null ? undefined : tol);

    // ---- part ----
    const bullet = m.bullet;
    const upper = up(m.outer), lower = down(m.outer);
    const mouthR = bullet ? bullet.exposed[0].r : m.inner ? m.inner[m.inner.length - 1].r : v.H2 / 2;
    const closePath = (sign) => {
      const mouth = { x: v.L3, y: sign * mouthR };
      const tail = bullet ? bullet.exposed.map((p) => ({ x: p.z, y: sign * p.r })) : [];
      return [...(sign < 0 ? upper : lower), mouth, ...tail];
    };
    out.outline.upper = closePath(-1);
    out.outline.lower = closePath(1);
    const rMax = m.rMax;

    // centre line
    const cx0 = -4, cx1 = (bullet ? v.L6 : v.L3) + 4;
    body.push(`<line class="centre-line" x1="${cx0}" y1="0" x2="${num(cx1)}" y2="0"/>`);
    out.segments.push({ kind: 'centre', id: 'centre', x1: cx0, y1: 0, x2: cx1, y2: 0 });

    // section: hatched walls and head below the axis, bullet solid
    let defs = '';
    if (m.inner) {
      const poly = [];
      const pk = m.head.pocket;
      poly.push(pk ? { r: pk.d / 2, z: 0 } : { r: 0, z: 0 });
      poly.push(...m.outer.slice(1));
      poly.push(...[...m.inner].reverse());
      poly.push({ r: 0, z: m.head.w });
      if (pk) poly.push({ r: 0, z: pk.h }, { r: pk.d / 2, z: pk.h });
      out.hatch.push(down(poly));
      body.push(`<polygon class="wall" points="${pts(down(poly))}"/>`);
      defs = '<defs><pattern id="hatch" width="0.9" height="0.9" patternUnits="userSpaceOnUse" patternTransform="rotate(45)"><line x1="0" y1="0" x2="0" y2="0.9"/></pattern></defs>';
    }
    if (bullet) body.push(`<polygon class="bullet" points="${pts(down(bullet.profile))}"/>`);
    body.push(`<polyline class="outline" points="${pts(out.outline.upper)}"/>`);
    body.push(`<polyline class="outline" points="${pts(out.outline.lower)}"/>`);
    for (const poly of [out.outline.upper, out.outline.lower, ...out.hatch]) {
      for (let i = 1; i < poly.length; i++) seg('outline', 'outline', poly[i - 1].x, poly[i - 1].y, poly[i].x, poly[i].y);
    }
    if (bullet) {
      const bp = down(bullet.profile);
      for (let i = 1; i < bp.length; i++) seg('outline', 'bullet', bp[i - 1].x, bp[i - 1].y, bp[i].x, bp[i].y);
    }

    // ---- length dimensions: rows below the part ----
    const rAt = (z) => {
      let best = 0;
      for (let i = 1; i < m.outer.length; i++) {
        const p = m.outer[i - 1], q = m.outer[i];
        if (z >= Math.min(p.z, q.z) - 1e-9 && z <= Math.max(p.z, q.z) + 1e-9) {
          best = Math.max(best, q.z === p.z ? Math.max(p.r, q.r) : p.r + ((q.r - p.r) * (z - p.z)) / (q.z - p.z));
        }
      }
      return best;
    };
    const lengths = [];
    const lenVal = (key, from) => (key in from ? from[key] : null);
    lengths.push({ id: 'R', key: 'R', val: v.R, tol: lenVal('RTol', ch), z: v.R, r: rAt(v.R) });
    for (const k of ['L1', 'L2', 'L3']) if (ln[k] != null) lengths.push({ id: k, key: k, val: ln[k], tol: lenVal(k + 'Tol', ln), z: ln[k], r: rAt(ln[k]) });
    if (bullet) lengths.push({ id: 'L6', key: 'L6', val: v.L6, tol: lenVal('L6Tol', ln), z: v.L6, r: a.tip.r });
    lengths.sort((p, q) => (p.id === 'R' ? -1 : q.id === 'R' ? 1 : p.z - q.z));
    const headR = a.headFaceR;
    let y = rMax;
    let lastRow = y;
    for (const d of lengths) {
      const tight = d.z < 2 * ARROW.len + 1;
      const text = valueLabel(d.id, d.key, d.val, d.tol);
      // shortcut: a label wider than its span without a tolerance to wrap overflows the extension lines; none of the 25 records does
      const wrap = !tight && text.length * CW > d.z - 0.5 && d.tol != null;
      y += wrap ? 2 * LINE_H + 2.6 : LINE_H + 2.6;
      lastRow = y;
      ext(d.id, 0, headR + 0.8, 0, y + 1.8);
      ext(d.id, d.z, d.r + 0.8, d.z, y + 1.8);
      line('dim-line', d.id, tight ? -3 : 0, y, tight ? d.z + 3 : d.z, y);
      // arrow tips touch the extension lines; inside the span they point out, on a short span they point in
      arrow(d.id, 0, y, tight ? 1 : -1, 0);
      arrow(d.id, d.z, y, tight ? -1 : 1, 0);
      dimInfo(d.id).arrows = arrows[d.id];
      if (tight) label(d.id, text, -3.8, y - 1, 'end');
      else if (wrap) label(d.id, valueLabel(d.id, d.key, d.val), d.z / 2, y - 1 - LINE_H, 'middle', ' ' + Format.formatTol(d.tol));
      else label(d.id, text, d.z / 2, y - 1, 'middle');
    }

    // ---- diameter dimensions: vertical lines with extension lines, labels as flags above ----
    const flags = [];
    const diam = (id, key, val, tol, zc, x, dirStub) => {
      const r = val / 2;
      const xEnd = x + dirStub * 1.5;
      ext(id, zc, -r, xEnd, -r);
      ext(id, zc, r, xEnd, r);
      line('dim-line', id, x, -r, x, r);
      arrow(id, x, -r, 0, -1);
      arrow(id, x, r, 0, 1);
      dimInfo(id).arrows = arrows[id];
      flags.push({ id, x, y: -r, text: valueLabel(id, key, val, tol) });
    };
    let leftX = -3;
    if (ch.E1 != null && a.grooveFloorZ != null) { diam('E1', 'E1', ch.E1, ch.E1Tol, a.grooveFloorZ, leftX, -1); leftX -= 3; }
    diam('R1', 'R1', ch.R1, ch.R1Tol, a.rimStubZ, leftX, -1);
    diam('P1', 'P1', pc.P1, pc.P1Tol, a.bodyStartZ, a.bodyStartZ + 3.5, 1);
    if (a.P2) diam('P2', 'P2', pc.P2, pc.P2Tol, a.P2.z, a.P2.z - 2.5, -1);
    if (a.H1) diam('H1', 'H1', col.H1, col.H1Tol, a.H1.z, a.H1.z + 2, 1);
    diam('H2', 'H2', col.H2, col.H2Tol, v.L3, v.L3 + 2, 1);
    if (a.G1) diam('G1', 'G1', c.projectile.G1, c.projectile.G1Tol, a.G1.z, a.G1.z + 2, 1);

    // shoulder angle: arc between the shoulder line and its mirror about the axis-parallel line at the body corner
    let markerTop = rMax;
    if (m.shoulder) {
      const { P, N, halfAngle, alphaValue } = m.shoulder;
      const h = (halfAngle * Math.PI) / 180;
      const rho = Math.min(4.5, Math.max(2.4, 0.95 * Math.hypot(N.z - P.z, P.r - N.r)));
      const reach = rho + 0.8;
      line('marker-line', 'alpha', P.z, -P.r, P.z + reach, -P.r);
      line('marker-line', 'alpha', P.z, -P.r, P.z + reach * Math.cos(h), -P.r - reach * Math.sin(h));
      const arc = [];
      for (let i = 0; i <= 12; i++) {
        const t = -h + (2 * h * i) / 12;
        arc.push({ x: P.z + rho * Math.cos(t), y: -P.r + rho * Math.sin(t) });
      }
      body.push(`<polyline class="marker-line" points="${pts(arc)}"/>`);
      for (let i = 1; i < arc.length; i++) seg('marker-line', 'alpha', arc[i - 1].x, arc[i - 1].y, arc[i].x, arc[i].y);
      const e1 = arc[arc.length - 1], e0 = arc[0];
      arrow('alpha', e1.x, e1.y, -Math.sin(h), Math.cos(h), 0.6);
      arrow('alpha', e0.x, e0.y, Math.sin(h), -Math.cos(h), 0.6);
      dimInfo('alpha').arrows = arrows.alpha;
      markerTop = Math.max(markerTop, P.r + reach * Math.sin(h));
      flags.push({ id: 'alpha', x: P.z, y: -P.r, text: valueLabel('alpha', 'alpha', alphaValue) });
    }

    // flags: right to left, each takes the lowest track free of boxes and of the poles of other flags
    const base = markerTop + 3.6;
    const occupied = []; // occupied[k] = list of [x0, x1]
    const free = (k, x0, x1) => (occupied[k] || []).every(([p, q]) => x1 <= p || x0 >= q);
    let tracks = 0;
    flags.sort((p, q) => q.x - p.x);
    for (const f of flags) {
      const w = f.text.length * CW;
      const bx0 = f.x + 0.9, bx1 = bx0 + w;
      let k = 0;
      while (!free(k, f.x - 0.8, bx1 + 0.8)) k++;
      (occupied[k] = occupied[k] || []).push([f.x - 0.8, bx1 + 0.8]);
      for (let j = 0; j < k; j++) (occupied[j] = occupied[j] || []).push([f.x - 0.8, f.x + 0.8]);
      tracks = Math.max(tracks, k + 1);
      const by = -(base + TRACK_PITCH * k);
      line('leader', f.id, f.x, f.y, f.x, by - ASC);
      label(f.id, f.text, bx0, by, 'start');
    }
    const topY = -(base + TRACK_PITCH * (tracks - 1)) - ASC - 2;

    // ---- title block ----
    let minX = Math.min(-4, ...out.labels.map((l) => l.box.x0), ...out.segments.map((s) => Math.min(s.x1, s.x2)));
    let maxX = Math.max(cx1, ...out.labels.map((l) => l.box.x1), ...out.segments.map((s) => Math.max(s.x1, s.x2)));
    minX -= 2; maxX += 2;
    if (maxX - minX < MIN_W) { const pad = (MIN_W - (maxX - minX)) / 2; minX -= pad; maxX += pad; }
    const W = maxX - minX;
    const tbX = maxX - TB.w - 2, tbY = lastRow + 5;
    const H0 = tbY + TB.h + 2 - topY;
    const scaleText = `Scale ${Math.min(PRINT_WIDTH / W, PRINT_MAX_HEIGHT / H0).toFixed(2)}:1 (A4 print)`;
    out.title = [rec.name, `C.I.P. table ${rec.tab}`, `Revised ${rec.revised}`, 'Dimensions in mm', scaleText];
    body.push(
      `<g class="title-block"><rect x="${num(tbX)}" y="${num(tbY)}" width="${TB.w}" height="${TB.h}"/>` +
      `<line x1="${num(tbX + 43)}" y1="${num(tbY)}" x2="${num(tbX + 43)}" y2="${num(tbY + TB.h)}"/>` +
      `<text class="tb-name" x="${num(tbX + 2)}" y="${num(tbY + 5.8)}">${esc(rec.name)}</text>` +
      `<text x="${num(tbX + 2)}" y="${num(tbY + 10)}">Dimensions in mm</text>` +
      `<line class="scale-bar" x1="${num(tbX + 2)}" y1="${num(tbY + 12.6)}" x2="${num(tbX + 12)}" y2="${num(tbY + 12.6)}"/>` +
      `<text x="${num(tbX + 14)}" y="${num(tbY + 13.5)}">10 mm</text>` +
      `<text x="${num(tbX + 45)}" y="${num(tbY + 5)}">C.I.P. table ${esc(rec.tab)}</text>` +
      `<text x="${num(tbX + 45)}" y="${num(tbY + 9.5)}">Revised ${esc(rec.revised)}</text>` +
      `<text x="${num(tbX + 45)}" y="${num(tbY + 14)}">${esc(scaleText)}</text></g>`
    );
    const H = H0;
    out.viewBox = { x: minX, y: topY, w: W, h: H };
    out.svg =
      `<svg xmlns="http://www.w3.org/2000/svg" class="drawing" role="img" aria-label="${esc(rec.name)} drawing" viewBox="${num(minX)} ${num(topY)} ${num(W)} ${num(H)}">` +
      defs + body.join('') + '</svg>';
    return out;
  }

  return { draw };
});
