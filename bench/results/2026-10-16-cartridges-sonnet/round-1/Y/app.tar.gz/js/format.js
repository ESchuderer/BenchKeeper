// Formatting of record values: numbers as published, angles, symbols, units, value rows.
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.Format = factory();
})(this, function () {
  const SYMBOLS = {
    eMin: 'e min', r1Min: 'r1 min', r1Max: 'r1 max', alpha: 'α', alpha1: 'α1',
    beta: 'β', delta: 'δ', deltaL: 'delta L', L3PlusG: 'L3 + G'
  };
  const ANGLES = new Set(['alpha', 'alpha1', 'beta', 'delta', 'i']);
  const UNITS = { Pmax: 'bar', PK: 'bar', PE: 'bar', EE: 'J', M: 'g', Q: 'mm²', N: '' };
  const TITLES = { misc: 'Miscellaneous' };

  const formatNumber = (n) => String(n);
  const formatAngle = (a) =>
    typeof a === 'number' ? formatNumber(a) + '°' : `${a.degrees}°${a.minutes}'${a.seconds}"`;
  const symbolOf = (key) => SYMBOLS[key] || key;
  const unitOf = (key) => (ANGLES.has(key) ? '°' : key in UNITS ? UNITS[key] : 'mm');
  const formatValue = (key, v) => (ANGLES.has(key) ? formatAngle(v) : formatNumber(v));
  const formatTol = (t) => (t > 0 ? '+' : '') + formatNumber(t);

  // One row per field; <X>Tol fields are merged into the row of X.
  function sectionRows(section) {
    return Object.keys(section)
      .filter((k) => section[k] !== undefined && !(k.endsWith('Tol') && section[k.slice(0, -3)] !== undefined))
      .map((key) => {
        const row = { key, symbol: symbolOf(key), value: formatValue(key, section[key]), unit: unitOf(key) };
        if (section[key + 'Tol'] !== undefined) row.tol = formatTol(section[key + 'Tol']);
        return row;
      });
  }

  const valueText = (row) => (row.tol === undefined ? row.value : row.value + ' ' + row.tol);

  function title(key) {
    if (TITLES[key]) return TITLES[key];
    const words = key.replace(/([A-Z])/g, ' $1').toLowerCase();
    return words.charAt(0).toUpperCase() + words.slice(1);
  }

  // Non-empty sections of the cartridge or chamber part, in record order.
  const sections = (part) =>
    Object.keys(part)
      .map((key) => ({ key, title: title(key), rows: sectionRows(part[key]) }))
      .filter((s) => s.rows.length);

  const labelText = (key, value, tol) =>
    symbolOf(key) + ' ' + valueText({ value: formatValue(key, value), tol: tol === undefined ? undefined : formatTol(tol) });

  return { formatNumber, formatAngle, formatTol, symbolOf, unitOf, sectionRows, valueText, sections, labelText };
});
