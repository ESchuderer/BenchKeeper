// Cartridge geometry from a record: outer half-profile, section, bullet. Points are {r, z} in mm
// (r radius, z along the axis from the head face). No DOM; every number comes from the record.
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.Geometry = factory();
})(this, function () {
  const RAD = Math.PI / 180;
  const ARC_STEPS = 16;
  const POCKET = { sp: [4.45, 3.04], spm: [4.45, 3.04], sr: [4.45, 3.04], lp: [5.33, 3.04], lpm: [5.33, 3.04], lr: [5.33, 3.3], lrm: [5.33, 3.3] };
  const pt = (r, z) => ({ r, z });
  const deg = (a) => (typeof a === 'number' ? a : a.degrees + a.minutes / 60 + a.seconds / 3600);
  const missing = (pairs) => pairs.filter((p) => p[1] == null).map((p) => p[0]);

  function rimType(rec) {
    if (rec.family === 'belted') return 'belted';
    if (rec.family === 'rimfire') return 'rimfire';
    const ratio = rec.cartridge.caseHead.R1 / rec.cartridge.powderChamber.P1;
    return ratio >= 1.05 ? 'rimmed' : ratio < 0.98 ? 'rebated' : 'rimless';
  }

  // Round the corner b of the polyline a-b-c with the given radius (clamped to the adjacent segments).
  function fillet(a, b, c, radius) {
    if (!radius) return [b];
    const len = (p, q) => Math.hypot(p.r - q.r, p.z - q.z);
    const la = len(a, b), lc = len(c, b);
    const u = { r: (a.r - b.r) / la, z: (a.z - b.z) / la };
    const v = { r: (c.r - b.r) / lc, z: (c.z - b.z) / lc };
    const half = Math.acos(Math.max(-1, Math.min(1, u.r * v.r + u.z * v.z))) / 2;
    if (Math.PI / 2 - Math.abs(Math.PI / 2 - half) < 1e-6 || half > Math.PI / 2 - 1e-6) return [b];
    const d = Math.min(radius / Math.tan(half), 0.49 * Math.min(la, lc));
    const rad = d * Math.tan(half);
    const bis = { r: u.r + v.r, z: u.z + v.z };
    const bl = Math.hypot(bis.r, bis.z);
    const cen = { r: b.r + (bis.r / bl) * (rad / Math.sin(half)), z: b.z + (bis.z / bl) * (rad / Math.sin(half)) };
    const t1 = pt(b.r + u.r * d, b.z + u.z * d), t2 = pt(b.r + v.r * d, b.z + v.z * d);
    const a1 = Math.atan2(t1.z - cen.z, t1.r - cen.r);
    let a2 = Math.atan2(t2.z - cen.z, t2.r - cen.r);
    while (a2 - a1 > Math.PI) a2 -= 2 * Math.PI;
    while (a2 - a1 < -Math.PI) a2 += 2 * Math.PI;
    const out = [t1];
    for (let i = 1; i < ARC_STEPS; i++) {
      const t = a1 + ((a2 - a1) * i) / ARC_STEPS;
      out.push(pt(cen.r + rad * Math.cos(t), cen.z + rad * Math.sin(t)));
    }
    out.push(t2);
    return out;
  }

  function interp(poly, z) {
    for (let i = 1; i < poly.length; i++) {
      const a = poly[i - 1], b = poly[i];
      if (z >= a.z && z <= b.z && b.z > a.z) return a.r + ((b.r - a.r) * (z - a.z)) / (b.z - a.z);
    }
    return z < poly[0].z ? poly[0].r : poly[poly.length - 1].r;
  }

  function buildBullet(rec, v, walls) {
    const shape = rec.annotations.defaultBulletShape;
    const cat = rec.annotations.category;
    const { G1, H2, L3, L6 } = v;
    const pistol = cat === 'pistol';
    const seat = { pointy: 1.0, rounded: pistol ? 0.4 : 0.8, flat: pistol ? 0.4 : 0.8, semi_wadcutter: 0.6 }[shape];
    const k = { pointy: 0.4, rounded: pistol ? 0.65 : 0.55, flat: pistol ? 0.7 : 0.6, semi_wadcutter: 0.78 }[shape];
    const mf = { pointy: null, rounded: 0.15, flat: 0.55, semi_wadcutter: 0.6 }[shape];
    const s = seat * G1;
    const m = shape === 'pointy' ? Math.max(0.08 * G1, 1.27) : mf * G1;
    const zb = L3 - s;
    const Lb = L6 - zb;
    const zc = zb + k * Lb;
    const n = L6 - zc;
    const rs = G1 / 2, rm = m / 2, a = rs - rm;
    const heeled = walls.heeled;
    const exposedR = heeled ? H2 / 2 : rs;
    const heelR = heeled ? H2 / 2 - walls.tb : rs;
    const nose = [];
    if (shape === 'pointy') {
      const rho = (a * a + n * n) / (2 * a);
      const phi = Math.asin(n / rho);
      for (let i = 0; i <= ARC_STEPS; i++) {
        const t = (phi * i) / ARC_STEPS;
        nose.push(pt(exposedR - rho + rho * Math.cos(t), zc + rho * Math.sin(t)));
      }
      nose[nose.length - 1] = pt(rm, L6);
    } else if (shape === 'rounded') {
      for (let i = 0; i <= ARC_STEPS; i++) {
        const t = ((Math.PI / 2) * i) / ARC_STEPS;
        nose.push(pt(rm + (exposedR - rm) * Math.cos(t), zc + n * Math.sin(t)));
      }
    } else {
      nose.push(pt(exposedR, zc), pt(rm, L6));
    }
    const profile = [pt(0, zb), pt(heelR, zb)];
    if (heeled) profile.push(pt(heelR, L3));
    profile.push(pt(exposedR, heeled ? L3 : zb), pt(exposedR, zc), ...nose.slice(1), pt(0, L6));
    if (!heeled) profile.splice(2, 1);
    // exposed part: from the mouth plane to the tip
    let exposed = [];
    for (let i = 1; i < profile.length; i++) {
      const p = profile[i - 1], q = profile[i];
      if (q.z > L3 && p.z <= L3) {
        exposed = [pt(p.r + ((q.r - p.r) * (L3 - p.z)) / (q.z - p.z), L3), ...profile.slice(i)];
        break;
      }
    }
    return { shape, s, k, m, zb, Lb, zc, n, nose, profile, exposed, exposedD: 2 * exposedR, heelD: 2 * heelR, heeled };
  }

  function build(rec) {
    const c = rec.cartridge;
    const ch = c.caseHead || {}, col = c.collar || {}, jc = c.junctionCone || {}, ln = c.lengths || {}, pc = c.powderChamber || {}, pr = c.projectile || {};
    const an = rec.annotations || {};
    const notes = [];
    const note = (feature, miss) => notes.push({ feature, missing: miss });
    const v = { R: ch.R, R1: ch.R1, P1: pc.P1, H2: col.H2, L3: ln.L3, L6: ln.L6, G1: pr.G1 };
    const core = missing([['R', v.R], ['R1', v.R1], ['P1', v.P1], ['H2', v.H2], ['L3', v.L3], ['L6', v.L6]]);
    const model = { key: rec.key, name: rec.name, notes, outer: null, inner: null, bullet: null, shoulder: null, anchors: {}, head: { w: null, pocket: null }, walls: null, values: v };
    if (core.length) {
      note('Drawing', core);
      return model;
    }
    const type = rimType(rec);
    model.rimType = type;
    const { R, R1, P1, H2, L3 } = v;

    // head face and rim edge
    const beta = ch.beta == null ? null : deg(ch.beta);
    const outer = [pt(0, 0)];
    let rimStubZ = 0, rimR = R1 / 2;
    if (beta != null && ch.f != null && beta < 90) {
      const cut = Math.min(ch.f * Math.tan(beta * RAD), R1 / 4);
      outer.push(pt(R1 / 2 - cut, 0), pt(R1 / 2, ch.f), pt(R1 / 2, R));
      rimStubZ = ch.f;
    } else if (type === 'rimfire') {
      const rho = Math.min(R / 2, (R1 - P1) / 2);
      rimR = R1 / 2 - rho;
      outer.push(pt(rimR, 0), pt(rimR, R / 2 - rho));
      for (let i = 1; i < 2 * ARC_STEPS; i++) {
        const t = -Math.PI / 2 + (Math.PI * i) / (2 * ARC_STEPS);
        outer.push(pt(rimR + rho * Math.cos(t), R / 2 + rho * Math.sin(t)));
      }
      outer.push(pt(rimR, R / 2 + rho), pt(rimR, R));
      rimStubZ = R / 2;
    } else {
      outer.push(pt(R1 / 2, 0), pt(R1 / 2, R));
      if (type !== 'rimfire' && (beta == null || ch.f == null)) note('Head chamfer', missing([['β', ch.beta], ['f', ch.f]]));
    }

    // extractor groove (or belt), or a plain step to the body
    const belted = type === 'belted';
    const gMiss = missing([['E', ch.E], ['E1', ch.E1], ['e min', ch.eMin], ...(belted ? [['R3', ch.R3], ['δ', ch.delta]] : [])]);
    let z0 = R, grooveZEnd = null;
    if (type !== 'rimfire' && gMiss.length && (type !== 'rimmed' || ch.E != null || ch.E1 != null)) note('Extractor groove', gMiss);
    if (type !== 'rimfire' && !gMiss.length) {
      outer.push(pt(ch.E1 / 2, R), pt(ch.E1 / 2, R + ch.eMin));
      if (belted) {
        grooveZEnd = Math.min(R + ch.eMin + (ch.R3 / 2 - ch.E1 / 2) / Math.tan(deg(ch.delta) * RAD), ch.E);
        outer.push(pt(ch.R3 / 2, grooveZEnd), pt(ch.R3 / 2, ch.E));
      } else {
        grooveZEnd = ch.E;
      }
      outer.push(pt(P1 / 2, ch.E));
      z0 = ch.E;
      model.anchors.grooveFloorZ = R;
    } else {
      outer.push(pt(P1 / 2, R));
    }

    // body, shoulder, neck
    const body = [pt(P1 / 2, z0)];
    const wantShoulder = jc.alpha != null && ln.L1 != null && ln.L2 != null;
    const sMiss = missing([['P2', pc.P2], ['H1', col.H1]]);
    let shoulder = null;
    if (wantShoulder && sMiss.length) note('Shoulder', sMiss);
    if (wantShoulder && !sMiss.length) {
      const P = pt(pc.P2 / 2, ln.L1), N = pt(col.H1 / 2, ln.L2), M = pt(H2 / 2, L3);
      if (jc.r1Min == null) note('Shoulder corner rounding (body side)', ['r1 min']);
      if (jc.r2 == null) note('Shoulder corner rounding (neck side)', ['r2']);
      body.push(...fillet(body[0], P, N, jc.r1Min), ...fillet(P, N, M, jc.r2), M);
      shoulder = { P, N, alpha: deg(jc.alpha), alphaValue: jc.alpha, halfAngle: Math.atan2(P.r - N.r, N.z - P.z) / RAD };
    } else {
      body.push(pt(H2 / 2, L3));
    }
    model.shoulder = shoulder;
    outer.push(...body.slice(1));
    model.outer = outer;
    model.rMax = Math.max(...outer.map((p) => p.r));

    // walls
    const gm = missing([['G1', v.G1]]);
    let walls = null;
    if (gm.length) { note('Bullet', gm); note('Section walls', gm); }
    else {
      const tnRaw = (H2 - v.G1) / 2;
      const tb = Math.min(Math.max(1.3 * tnRaw, 0.6), (0.35 * P1) / 2);
      const heeled = H2 - v.G1 <= 0.015;
      walls = { tn: heeled ? tb : tnRaw, tb, heeled };
    }
    model.walls = walls;

    // bullet
    const shapes = ['pointy', 'rounded', 'flat', 'semi_wadcutter'];
    if (walls && shapes.includes(an.defaultBulletShape)) model.bullet = buildBullet(rec, v, walls);
    else if (walls) note('Bullet', ['default bullet shape']);
    const bullet = model.bullet;

    // primer pocket and solid head
    const pk = POCKET[an.primerType];
    if (type !== 'rimfire' && !pk) note('Primer pocket', ['primer type']);
    const pocket = pk ? { d: pk[0], h: pk[1] } : null;
    const tb = walls ? walls.tb : 0;
    const w = Math.max(2.5, (0.25 * P1) / 2, pocket ? pocket.h + 1.5 : 0, belted && grooveZEnd != null ? grooveZEnd + tb : grooveZEnd != null ? ch.E + tb : 0);
    model.head = { w, pocket };

    // inner line
    if (walls) {
      const { tn } = walls;
      const bodyPoly = [pt(P1 / 2, 0), ...body];
      const L1 = shoulder ? ln.L1 : null, L2 = shoulder ? ln.L2 : null;
      const seatStart = bullet ? bullet.zb - Math.max(tb - tn, 0) : null;
      const tAt = (z) => {
        if (shoulder) return z <= L1 ? tb : z >= L2 ? tn : tb + ((tn - tb) * (z - L1)) / (L2 - L1);
        if (!bullet) return tb;
        return z <= seatStart ? tb : z >= bullet.zb ? tn : tb + ((tn - tb) * (z - seatStart)) / (bullet.zb - seatStart);
      };
      const zs = new Set([w, L3, ...body.map((p) => p.z)]);
      if (shoulder) zs.add(L1).add(L2);
      else if (bullet) zs.add(seatStart).add(bullet.zb);
      const inner = [...zs].filter((z) => z >= w && z <= L3).sort((a, b) => a - b).map((z) => pt(interp(bodyPoly, z) - tAt(z), z));
      model.inner = inner;
    }

    // anchors of the dimension lines
    const a = model.anchors;
    a.headFaceR = outer[1].r;
    a.rimStubZ = rimStubZ;
    a.rimR = R1 / 2;
    a.bodyStartZ = z0;
    a.mouthR = H2 / 2;
    if (ln.L1 != null && pc.P2 != null) a.P2 = pt(pc.P2 / 2, ln.L1);
    if (ln.L2 != null && col.H1 != null) a.H1 = pt(col.H1 / 2, ln.L2);
    if (bullet) {
      a.tip = pt(bullet.m / 2, v.L6);
      const zG = bullet.zc >= L3 ? bullet.zc : (bullet.zb + Math.min(bullet.zc, L3)) / 2;
      a.G1 = pt(v.G1 / 2, zG);
    }
    return model;
  }

  const noteText = (n) => `${n.feature} not drawn: ${n.missing.join(', ')} not published`;

  return { build, rimType, noteText };
});
