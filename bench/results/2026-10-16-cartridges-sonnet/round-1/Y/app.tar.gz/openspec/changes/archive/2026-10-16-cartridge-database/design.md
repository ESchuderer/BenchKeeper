# Design

## Context

Greenfield repository with no code. Constraints: plain HTML/CSS/JS, no build, no network, must work from `file://`. Chromium blocks ES modules and `fetch` of local files on `file://`, so data and code load as classic scripts. Node.js 22 and Playwright with Chromium are available for dev-time tests.

## Goals / Non-Goals

**Goals:**
- Pure, DOM-free modules for formatting, catalog filtering, geometry and drawing layout so they run under `node --test`.
- Deterministic label layout that provably avoids overlaps.

**Non-Goals:**
- Boat-tail bullets, rifling drawings, rendering `annotations.implausible`, unit conversion.

## Decisions

- **Files:** `index.html`, `css/app.css`, `js/data.js` (`window.CARTRIDGES`, the 25 records verbatim), `js/format.js`, `js/catalog.js`, `js/geometry.js`, `js/drawing.js`, `js/app.js`. Each pure module is a UMD wrapper (`module.exports` in Node, `window.<Name>` in the browser). Alternative, ES modules plus JSON: rejected, fails on `file://`.
- **Routing:** hash routes `#/` and `#/cartridge/<key>`. Works on `file://` and any static server, survives reload, no server rewrite. The list view stays in the DOM (hidden) so search and family filter persist across navigation.
- **Number format:** `String(number)` for JSON numbers: `4150.0` prints `4150`, `51.18` prints `51.18`, no locale formatting. Angle objects always print `D°M'S"`.
- **Rows:** keys in record order; `<X>Tol` merged into the value cell of `X`. Units from a small map: angles (alpha, alpha1, beta, delta, i), bar (Pmax, PK, PE), J (EE), g (M), mm² (Q), none (N), everything else mm.
- **Geometry (`geometry.js`)**: points are `{r, z}` in mm. Outer half-profile built per brief rules 1 to 6, arcs sampled to polylines; fillets by tangent-point construction clamped to half the adjacent segment. Bullet profile (rule 7), seated and exposed split at z = L3. Inner wall radius = body radial offset `r_out(z) - t(z)` with t = tb on the body, linear tb to tn from L1 to L2, tn on the neck. Straight cases: tb up to the bullet base minus (tb - tn), linear to tn at the bullet base, tn beyond (a 45 degree seat); heeled cases use tb everywhere. Belted cases compute the inner line from P1/2, not the belt. Every optional feature declares its required fields; a missing one yields a note `{feature, missing:[symbols]}` and the feature is skipped.
- **Drawing (`drawing.js`)**: SVG y = -r above the axis, +r below (section). Strokes use `vector-effect: non-scaling-stroke` so lines stay legible at phone scale; text is monospace at 3 mm so label width is `0.62 * 3 * chars`, making box estimates deterministic.
- **Dimension layout:**
  - Length dims (R, L1, L2, L3, L6) in rows below the part, nested by span, with vertical extension lines from the outline; R has outside arrows and its label left of the head.
  - Diameter dims are vertical lines through the part with horizontal extension lines from the outline corner; R1 and E1 sit left of the head, P1, H1, H2, G1 right of their corner, P2 left of its corner.
  - Diameter and α labels are flags above the part: a vertical leader from the dimension line and the text to the right of the leader's top. Flags are placed right to left, each taking the lowest track whose box does not overlap a placed box in that track. Leaders of later flags lie left of earlier boxes, so leaders never cross labels.
  - α is drawn as a small arc at the body-side shoulder corner between the shoulder line and its mirror about the axis-parallel line (included angle), labelled with the published value.
- **Print:** `@media print` with A4 portrait, tables in three columns at 7 pt, SVG at 100% width with a max height, `position: fixed` footer. Verified by `page.pdf()` page count.
- **Tests:** `node --test` for modules; Playwright for UI, `file://`, static server, print and layout checks via `getBBox`. The test server is a 20-line Node script, not a dependency.
- **Scale text:** the SVG has no fixed on-screen scale; the title block states the scale for the A4 print width (190 mm / drawing width) and draws a 10 mm scale bar.

## Risks / Trade-offs

- [Font fallback changes monospace width] -> 0.62 em estimate has slack; a Playwright test compares real `getBBox` with the layout boxes.
- [Data inconsistent with a rule, e.g. G2 of 7 mm Rem. Mag. is 68.61] -> shown as published; not used by the drawing.
- [Dimension lines cross the part] -> accepted: thin, non-scaling lines; the outline stays dominant.
- [Print must fit on one page for the longest record] -> three-column tables and drawing max height; PDF test over all 25 records.
