# Proposal

## Why

Reloaders, gunsmiths and engineers need a quick, offline reference for C.I.P. cartridge dimensions and chamber values, with a scale drawing, in the style of the OpenBallistics cartridge database. The 25 supplied records are the only data.

## What Changes

- New static web app (`index.html`, CSS, JavaScript), no framework, no build step, no network requests.
- Start page: searchable, family-filterable list of the 25 cartridges.
- Detail view per cartridge with its own bookmarkable address: metadata, 2D drawing, cartridge and chamber value tables.
- 2D drawing: inline SVG computed from the record, 1 SVG unit = 1 mm, outside view above the axis, hatched section below, dimension lines, title block.
- Print layout: one A4 portrait page per detail view, black on white.
- Light and dark theme on screen following the system setting.
- Unit and formatting rules for lengths, angles, tolerances and symbols.

## Capabilities

### New Capabilities
- `cartridge-catalog`: start page list, search, family filter, count.
- `cartridge-detail`: detail view content, value tables, formatting, addressable routes.
- `cartridge-drawing`: SVG geometry, section, dimensions, labels, title block, missing-value handling.
- `cartridge-print`: A4 print layout of a detail view.
- `app-delivery`: file:// and static-server operation, no dependencies, themes, phone layout.

### Modified Capabilities

## Impact

- New files in the project root: `index.html`, `css/`, `js/`, `test/`, `package.json`.
- npm dev dependencies only (`@playwright/test`); the app has no runtime dependencies.
- Out of scope: editing data, fetching data, unit conversion, search by other fields, boat-tail bullets, rifling drawing, the `annotations.implausible` notes.
