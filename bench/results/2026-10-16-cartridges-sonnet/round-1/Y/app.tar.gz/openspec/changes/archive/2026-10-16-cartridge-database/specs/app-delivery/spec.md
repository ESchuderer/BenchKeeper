# Spec Delta

## Purpose

Defines how the app is delivered and looks: plain static files that work offline and on a phone, in light and dark themes.

## ADDED Requirements

### Requirement: Plain static app without dependencies
The app SHALL be `index.html` in the project root with its CSS and JavaScript files, using no framework, build step, server code or runtime dependency, and SHALL make no network request (no CDN, web font or analytics).

#### Scenario: No network requests
- **WHEN** the start page and a detail view are opened
- **THEN** every request is for a file of the app itself

### Requirement: Works from disk and from a server
The app SHALL work fully when `index.html` is opened from disk in Chromium (`file://`) and when the folder is served by a static file server.

#### Scenario: file:// start page
- **WHEN** `index.html` is opened through a `file://` address
- **THEN** 25 cartridges are listed and a detail view with its drawing opens

#### Scenario: Static server
- **WHEN** the folder is served over HTTP
- **THEN** the same behavior holds

### Requirement: Theme follows the system
On screen the app SHALL use a light theme or a dark theme following the system setting, with dense, precise typography and tabular numbers.

#### Scenario: Dark preference
- **WHEN** the system prefers a dark color scheme
- **THEN** the page background is dark and the drawing remains legible

### Requirement: Usable on a phone
The app SHALL be usable at 360 px width without horizontal scrolling.

#### Scenario: Phone list and detail
- **WHEN** the viewport is 360 px wide
- **THEN** neither the list nor a detail view scrolls horizontally
