# Spec Delta

## Purpose

Lets users find a cartridge in the 25-record catalog by name, alternative name or family and open its detail view.

## ADDED Requirements

### Requirement: Start page lists every cartridge
The start page SHALL show the heading "Cartridges" and, for every cartridge, its name, family and case length L3. Each name SHALL be a link whose text is exactly the record's `name` and which opens the detail view.

#### Scenario: Initial list
- **WHEN** the app is opened without an address fragment
- **THEN** the heading "Cartridges" is shown, 25 links are listed, and "25 cartridges" is shown

#### Scenario: Name as published
- **WHEN** the list is shown
- **THEN** a link with the text "6,5 Creedmoor" exists

### Requirement: Search filters by name and alternative names
A field labelled "Search" SHALL filter the list as the user types, matching case-insensitively and ignoring spaces against the name and every alternative name.

#### Scenario: Alternative name
- **WHEN** the user types "7,62 x 51" into "Search"
- **THEN** the list contains "308 Win." and the count reads "1 cartridges"

#### Scenario: No match
- **WHEN** the user types text that matches nothing
- **THEN** no cartridge is listed and the count reads "0 cartridges"

### Requirement: Family filter
A select labelled "Family" with the options All, rimless, rimmed, belted, pistol and rimfire SHALL restrict the list to that family, combined with the search text.

#### Scenario: Rimfire family
- **WHEN** the user selects "rimfire"
- **THEN** only the 22 Long Rifle, 22 Win. Mag. R.F. and 17 HMR are listed and the count reads "3 cartridges"

#### Scenario: Combined filters
- **WHEN** family "pistol" is selected and "44" is typed into "Search"
- **THEN** only "44 Rem. Mag." is listed

### Requirement: Count of listed cartridges
The text "<n> cartridges" SHALL state how many cartridges are currently listed.

#### Scenario: Count follows filters
- **WHEN** the filters change the list
- **THEN** the count text equals the number of listed links followed by " cartridges"
