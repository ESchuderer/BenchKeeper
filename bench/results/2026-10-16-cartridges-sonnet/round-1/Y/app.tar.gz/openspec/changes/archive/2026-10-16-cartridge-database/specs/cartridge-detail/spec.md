# Spec Delta

## Purpose

Shows every published value of one cartridge and its chamber in a precise, consistently formatted reference view with a stable address.

## ADDED Requirements

### Requirement: Detail view address
Each cartridge SHALL have its own address, of the form `index.html#/cartridge/<key>`, that opens its detail view directly, survives a reload and works from `file://`.

#### Scenario: Reload keeps the view
- **WHEN** the detail view of "308 Win." is open and the page is reloaded
- **THEN** the same detail view is shown

#### Scenario: Unknown key
- **WHEN** the address names a key that does not exist
- **THEN** a "Cartridge not found" message and the link "All cartridges" are shown

### Requirement: Detail header and metadata
The detail view SHALL show the cartridge name as the heading, then alternative names, family, category, primer type, C.I.P. table, country, published date, revised date, pressure method, and the published water capacity with a link to its source.

#### Scenario: Metadata of 308 Win.
- **WHEN** the detail view of "308 Win." is open
- **THEN** it lists "308 Winchester" and "7,62 x 51", family "rimless", table "I", country "US", published "1984-06-14", revised "2008-09-23", method "Transducer", and capacity "56" with the link "kwk" to http://kwk.us/cases.html

#### Scenario: No published capacity
- **WHEN** the record has no published capacity
- **THEN** the capacity is shown as "not published"

### Requirement: Value tables by section
The detail view SHALL show all cartridge values and all chamber values in tables grouped by section, each table with the columns "Symbol", "Value" and "Unit". Sections without values SHALL be omitted.

#### Scenario: Sections
- **WHEN** the detail view of "223 Rem." is open
- **THEN** a "Cartridge" group and a "Chamber" group are shown, each with one table per non-empty section

#### Scenario: Empty section
- **WHEN** the record's `junctionCone` is empty
- **THEN** no "Junction cone" table is shown

### Requirement: Units, symbols and number format
Values SHALL be shown as published with a decimal point and no thousands separator. Lengths and diameters are in mm; Pmax, PK and PE in bar; EE in J; M in g; Q in mm²; N has no unit. Symbols SHALL be the field name, except eMin "e min", r1Min "r1 min", r1Max "r1 max", alpha "α", alpha1 "α1", beta "β", delta "δ", deltaL "delta L", L3PlusG "L3 + G".

#### Scenario: Values and units
- **WHEN** the detail view of "308 Win." is open
- **THEN** the row "Pmax" shows "4150" with unit "bar" and the row "L3" shows "51.18" with unit "mm"

#### Scenario: Symbols
- **WHEN** the detail view of "223 Rem." is open
- **THEN** the symbols "α", "r1 min", "L3 + G" and "delta L" appear

### Requirement: Angle format
An angle given as a number SHALL be shown as `<degrees>°`; an angle given as an object SHALL be shown as `<degrees>°<minutes>'<seconds>"`.

#### Scenario: Plain and sexagesimal angles
- **WHEN** the detail views of "308 Win." and "338 Lapua Mag." show α
- **THEN** the values read `40°` and `39°59'49"`

### Requirement: Tolerances next to the value
A field `<X>Tol` SHALL be shown next to the value of X in the same cell and never as a row of its own.

#### Scenario: Tolerance
- **WHEN** the detail view of "308 Win." is open
- **THEN** the row "L1" reads "39.62 -0.2" and no row has the symbol "L1Tol"

### Requirement: Navigation and print button
The detail view SHALL show a "Print" button that opens the browser's print dialog and a link "All cartridges" that returns to the list.

#### Scenario: Back to the list
- **WHEN** the user activates "All cartridges"
- **THEN** the start page is shown with its previous search and family filter
