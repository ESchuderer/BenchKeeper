# Spec Delta

## Purpose

Draws a true-scale 2D view of a cartridge with its section and dimensions, computed only from the record's published values.

## ADDED Requirements

### Requirement: True-scale inline SVG
The detail view SHALL contain an inline SVG named "<name> drawing" in which 1 SVG user unit equals 1 mm, the axis is horizontal and the head is on the left. Every coordinate SHALL be computed from the record; no number is invented.

#### Scenario: Accessible name and scale
- **WHEN** the detail view of "308 Win." is open
- **THEN** an SVG image named "308 Win. drawing" exists and its mouth face lies L3 = 51.18 units from its head face

### Requirement: Outside view above, section below
The upper half of the drawing SHALL be the outside view and the lower half a section with cut walls hatched, plus a dash-dot centre line along the axis.

#### Scenario: Halves
- **WHEN** a drawing is shown
- **THEN** it contains a hatched wall region only below the axis and a centre line with a dash-dot pattern

### Requirement: Rim type and head
The rim type SHALL be belted for family belted, rimfire for family rimfire, otherwise rimmed when R1/P1 >= 1.05, rebated when R1/P1 < 0.98 and rimless else. The head face has a chamfer where beta and f are published and beta < 90°, a half-round rim edge on rimfire cases, and a square corner otherwise.

#### Scenario: Rim types
- **WHEN** the rim type is computed for "9,3 x 74 R", "300 Win. Mag.", "22 Long Rifle" and "308 Win."
- **THEN** the results are rimmed, belted, rimfire and rimless

### Requirement: Extractor groove and body
Where E and E1 (and e min) are published, the profile SHALL show the extractor groove: floor at E1/2 for e min, then a straight ramp to (P1/2, E), or on belted cases a ramp at angle δ up to the belt R3/2, the belt to z = E and a step in to P1/2. Without a groove the profile steps in from R1/2 to P1/2 at z = R. The body runs straight from P1/2 to (P2/2, L1) on bottleneck cases and to (H2/2, L3) on straight cases.

#### Scenario: Groove ramp
- **WHEN** the profile of "308 Win." is computed
- **THEN** it contains the points (E1/2, R + e min) = (5.195, 2.77) and (P1/2, E) = (5.98, 3.85)

#### Scenario: Straight case
- **WHEN** the record has no alpha, L1 or L2
- **THEN** the body line ends at (H2/2, L3)

### Requirement: Shoulder and neck
On a bottleneck case the shoulder SHALL run from (P2/2, L1) to (H1/2, L2) and the neck from (H1/2, L2) to (H2/2, L3). The corners are rounded with r1 min (body side) and r2 (neck side) where published. The angle α is the included cone angle and is labelled.

#### Scenario: Shoulder points
- **WHEN** the profile of "223 Rem." is computed
- **THEN** it passes through (4.5, 36.52) and (3.215, 39.55) and the α label reads "α 46°"

### Requirement: Bullet
A bullet SHALL be drawn from the mouth to the tip at z = L6 with shank diameter G1, using seating depth, cylinder fraction, meplat and nose shape from `annotations.defaultBulletShape`, the rifle, pistol or rimfire category, and the rules of the brief. On heeled cases (H2 - G1 <= 0.015) the exposed bullet has the case outside diameter and the seated heel the case inside diameter H2 - 2·tb. The outside view hides the seated part; the section shows it.

#### Scenario: Pointy bullet of 308 Win.
- **WHEN** the bullet of "308 Win." is computed
- **THEN** the base is at z = 43.33, the cylinder ends at z = 54.45, the tip meplat diameter is 1.27 and the tip is at z = 71.12

#### Scenario: Heeled 22 Long Rifle
- **WHEN** the bullet of "22 Long Rifle" is computed
- **THEN** the exposed bullet diameter is 5.72 and the seated heel diameter is 4.52

### Requirement: Section walls and head
The neck wall SHALL be tn = (H2 - G1)/2 and the body wall tb = min(max(1.3·tn, 0.6), 0.35·P1/2). The inner line SHALL follow the outer line at tb on the body and tn on the neck, blended linearly across the shoulder. The solid head runs from the head face to z = w; centrefire cases have a primer pocket of the diameter and depth set by the primer type; rimfire cases have none.

#### Scenario: Walls of 308 Win.
- **WHEN** the section of "308 Win." is computed
- **THEN** tn = 0.435, tb = 0.6 and the primer pocket is 5.33 mm wide and 3.3 mm deep

### Requirement: Dimension lines and labels
The drawing SHALL show dimension lines with arrowheads and extension lines for L3, L6, R1, R and P1 and, where published, P2, H1, H2, G1, L1, L2, E1 and the shoulder angle α. Each is labelled with its symbol and value, for example "L3 51.18". Labels SHALL NOT overlap each other or the outline.

#### Scenario: Labels of 308 Win.
- **WHEN** the drawing of "308 Win." is shown
- **THEN** a label "L3 51.18" exists, and no two label boxes intersect and no label box intersects the outline

#### Scenario: Only published dimensions
- **WHEN** the drawing of "9 mm Luger" is shown
- **THEN** it has labels for L3, L6, R1, R, P1, E1, H2 and G1 and none for P2, H1, L1, L2 or α

### Requirement: Title block
The drawing SHALL include a title block with the name, C.I.P. table and revision date, the text "Dimensions in mm" and the scale.

#### Scenario: Title block text
- **WHEN** the drawing of "308 Win." is shown
- **THEN** its text includes "308 Win.", "C.I.P. table I", "Revised 2008-09-23", "Dimensions in mm" and "Scale"

### Requirement: Missing values
If a value a feature needs is missing, the drawing SHALL omit that feature and the detail view SHALL say which value is missing. No number is invented.

#### Scenario: 338 Lapua Mag. without r1 min
- **WHEN** the drawing of "338 Lapua Mag." is shown
- **THEN** the body-side shoulder corner is not rounded and a note names the missing r1 min

#### Scenario: Record without E1
- **WHEN** a rimless record lacks E1
- **THEN** the drawing has no extractor groove and a note names E1

### Requirement: Responsive drawing
The SVG SHALL scale to the width of its container, down to a phone screen, with text that stays legible.

#### Scenario: Phone width
- **WHEN** the viewport is 360 px wide
- **THEN** the SVG is no wider than the viewport and the page has no horizontal scroll
