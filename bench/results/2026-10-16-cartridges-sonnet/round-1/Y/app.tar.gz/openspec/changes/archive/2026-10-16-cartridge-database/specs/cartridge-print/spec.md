# Spec Delta

## Purpose

Prints one cartridge detail view as a single A4 portrait reference sheet.

## ADDED Requirements

### Requirement: Print opens the dialog
The "Print" button SHALL open the browser's print dialog.

#### Scenario: Print button
- **WHEN** the user activates "Print"
- **THEN** `window.print` is called once

### Requirement: One A4 portrait page
A printed detail view SHALL be one A4 portrait page: a page header with the name, the drawing at full width with every label legible, then the tables, and a footer with the source "C.I.P. TDCC, revised <date>".

#### Scenario: Page count
- **WHEN** the detail view of "338 Lapua Mag." is printed to PDF at A4 portrait
- **THEN** the PDF has exactly one page

#### Scenario: Footer
- **WHEN** "308 Win." is printed
- **THEN** the footer reads "Source: C.I.P. TDCC, revised 2008-09-23"

### Requirement: Print excludes interface elements
A printed page SHALL contain no navigation, search, filter or buttons and SHALL be black on white regardless of the screen theme.

#### Scenario: Dark system theme
- **WHEN** the system theme is dark and the page is printed
- **THEN** the print background is white, the text is black and the Print button and "All cartridges" link are not displayed
