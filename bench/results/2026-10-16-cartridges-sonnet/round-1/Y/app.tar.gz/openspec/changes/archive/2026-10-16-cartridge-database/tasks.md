# Tasks

## 1. Scaffold and data

- [x] 1.1 Create `package.json` (scripts `test`, `test:e2e`, `start`), `.gitignore`, `js/data.js` with the 25 records verbatim, and `test/data.test.js`; verify `npm test` passes (25 records, unique keys, expected family counts).

## 2. Formatting and catalog

- [x] 2.1 Write `test/format.test.js` and `test/catalog.test.js` first (angles, Tol merge, symbols, units, search, family), then implement `js/format.js` and `js/catalog.js`; verify `npm test` passes.

## 3. Geometry

- [x] 3.1 Write `test/geometry.test.js` first (rim type, head, groove, shoulder points, bullet numbers, walls, pocket, w, heeled, missing-value notes for all 25 records), then implement `js/geometry.js`; verify `npm test` passes.

## 4. Drawing

- [x] 4.1 Write `test/drawing.test.js` first (labels per record, arrowheads and extension lines, title block text, no label overlaps with each other or the outline for all 25 records, accessible name), then implement `js/drawing.js`; verify `npm test` passes.

## 5. Application shell

- [x] 5.1 Write `test/e2e` specs first (list, search, family, count, routes, reload, tables, tolerances, angles, print button, no network, `file://` and server projects, phone and dark), then implement `index.html`, `css/app.css`, `js/app.js`; verify `npm run test:e2e` passes.

## 6. Print

- [x] 6.1 Write the print e2e spec first (one A4 page for all 25 records, footer text, light colors under dark theme, hidden controls), then implement the print CSS; verify `npm run test:e2e` passes.

## 7. Integration

- [x] 7.1 Run `npm test` and `npm run test:e2e`, inspect screenshots of a bottleneck, belted, rimmed, pistol and rimfire record in light, dark and phone widths; fix findings.

## Workflow follow-up

- Run `code-review` on the branch before any push.
- Archive the change (`openspec-archive-change`) on the branch before the pull request is merged.
