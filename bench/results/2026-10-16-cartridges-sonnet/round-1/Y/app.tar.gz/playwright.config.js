const { defineConfig } = require('@playwright/test');
const fs = require('fs');
const os = require('os');
const path = require('path');
const port = 4173;
const fileUrl = 'file://' + path.resolve(__dirname, 'index.html');

// Use a Chromium already in the Playwright cache when the one this Playwright version wants is missing.
function cachedChromium() {
  const dir = path.join(process.env.PLAYWRIGHT_BROWSERS_PATH || path.join(os.homedir(), '.cache', 'ms-playwright'));
  if (!fs.existsSync(dir)) return undefined;
  for (const d of fs.readdirSync(dir).filter((n) => /^chromium-\d+$/.test(n)).sort().reverse()) {
    const exe = path.join(dir, d, 'chrome-linux64', 'chrome');
    if (fs.existsSync(exe)) return exe;
  }
}

module.exports = defineConfig({
  testDir: 'test/e2e',
  timeout: 30000,
  reporter: 'list',
  use: { browserName: 'chromium', launchOptions: { executablePath: process.env.CHROMIUM_PATH || cachedChromium(), args: ['--no-sandbox'] } },
  webServer: { command: 'node test/serve.js', url: `http://127.0.0.1:${port}/`, reuseExistingServer: true, env: { PORT: String(port) } },
  projects: [
    { name: 'file', metadata: { appUrl: fileUrl } },
    { name: 'server', metadata: { appUrl: `http://127.0.0.1:${port}/index.html` } }
  ]
});
