const { test, expect } = require('@playwright/test');
const data = require('../../js/data.js');

test.beforeEach(async ({ page }, info) => {
  await page.goto(info.project.metadata.appUrl);
});
const open = async (page, name) => {
  await page.getByRole('link', { name, exact: true }).click();
  await expect(page.getByRole('heading', { level: 1, name })).toBeVisible();
};

test('start page lists 25 cartridges with name, family and L3', async ({ page }) => {
  await expect(page.getByRole('heading', { level: 1, name: 'Cartridges' })).toBeVisible();
  await expect(page.getByText('25 cartridges', { exact: true })).toBeVisible();
  await expect(page.locator('#list a')).toHaveCount(25);
  await expect(page.getByRole('link', { name: '6,5 Creedmoor', exact: true })).toBeVisible();
  const row = page.getByRole('row', { name: /^308 Win\./ });
  await expect(row).toContainText('rimless');
  await expect(row.getByRole('cell').nth(2)).toHaveText('51.18');
  await expect(page.getByRole('row', { name: /^9 mm Luger/ }).getByRole('cell').nth(2)).toHaveText('19.15 -0.25');
  await expect(page.locator('#list')).not.toContainText('undefined');
});

test('search filters by name and alternative names as the user types', async ({ page }) => {
  await page.getByLabel('Search').pressSequentially('7,62 x 51');
  await expect(page.locator('#list a')).toHaveText(['308 Win.']);
  await expect(page.getByText('1 cartridges', { exact: true })).toBeVisible();
  await page.getByLabel('Search').fill('zzz');
  await expect(page.getByText('0 cartridges', { exact: true })).toBeVisible();
});

test('family select filters and combines with search', async ({ page }) => {
  await expect(page.getByLabel('Family').locator('option')).toHaveText(['All', 'rimless', 'rimmed', 'belted', 'pistol', 'rimfire']);
  await page.getByLabel('Family').selectOption('rimfire');
  await expect(page.locator('#list a')).toHaveText(['22 Long Rifle', '22 Win. Mag. R.F.', '17 HMR']);
  await expect(page.getByText('3 cartridges', { exact: true })).toBeVisible();
  await page.getByLabel('Family').selectOption('pistol');
  await page.getByLabel('Search').fill('44');
  await expect(page.locator('#list a')).toHaveText(['44 Rem. Mag.']);
});

test('detail view: heading, metadata, address that survives reload', async ({ page }) => {
  await open(page, '308 Win.');
  expect(page.url()).toContain('#/cartridge/308_win');
  const meta = page.locator('.meta');
  await expect(meta).toContainText('308 Winchester, 7,62 x 51');
  for (const t of ['rimless', 'rifle', 'lr', 'US', '1984-06-14', '2008-09-23', 'Transducer', '56 gr H2O']) await expect(meta).toContainText(t);
  await expect(meta.getByRole('link', { name: 'kwk' })).toHaveAttribute('href', 'http://kwk.us/cases.html');
  await page.reload();
  await expect(page.getByRole('heading', { level: 1, name: '308 Win.' })).toBeVisible();
  await expect(page.getByRole('img', { name: '308 Win. drawing' })).toBeVisible();
});

test('a malformed address shows not found instead of failing', async ({ page }, info) => {
  await page.goto(info.project.metadata.appUrl + '#/cartridge/%E0%A4%A');
  await expect(page.getByText('Cartridge not found')).toBeVisible();
});

test('detail view addresses open directly and unknown keys say so', async ({ page }, info) => {
  await page.goto(info.project.metadata.appUrl + '#/cartridge/22_long_rifle');
  await expect(page.getByRole('heading', { level: 1, name: '22 Long Rifle' })).toBeVisible();
  await page.goto(info.project.metadata.appUrl + '#/cartridge/nope');
  await expect(page.getByText('Cartridge not found')).toBeVisible();
  await page.getByRole('link', { name: 'All cartridges' }).click();
  await expect(page.getByRole('heading', { level: 1, name: 'Cartridges' })).toBeVisible();
});

test('value tables: columns, units, tolerance, angles, symbols', async ({ page }) => {
  await open(page, '308 Win.');
  await expect(page.getByRole('columnheader', { name: 'Symbol' }).first()).toBeVisible();
  await expect(page.getByRole('columnheader', { name: 'Value' }).first()).toBeVisible();
  await expect(page.getByRole('columnheader', { name: 'Unit' }).first()).toBeVisible();
  const cell = (sym, nth = 0) => page.getByRole('row').filter({ has: page.getByRole('rowheader', { name: sym, exact: true }) }).nth(nth);
  await expect(cell('Pmax')).toContainText('4150');
  await expect(cell('Pmax')).toContainText('bar');
  await expect(cell('L1', 0)).toContainText('39.62 -0.2');
  await expect(cell('α', 0)).toContainText('40°');
  await expect(page.getByRole('rowheader', { name: 'L1Tol' })).toHaveCount(0);
  await expect(page.getByRole('rowheader', { name: 'r1 min' })).toHaveCount(1);
  await expect(page.getByRole('rowheader', { name: 'L3 + G' })).toHaveCount(1);
  await expect(page.getByRole('rowheader', { name: 'delta L' })).toHaveCount(1);
  await expect(page.getByRole('heading', { level: 2, name: 'Cartridge' })).toBeVisible();
  await expect(page.getByRole('heading', { level: 2, name: 'Chamber' })).toBeVisible();
});

test('sexagesimal angle and empty sections', async ({ page }, info) => {
  await page.goto(info.project.metadata.appUrl + '#/cartridge/338_lapua_mag');
  await expect(page.getByText('39°59\'49"').first()).toBeVisible();
  await page.goto(info.project.metadata.appUrl + '#/cartridge/9_mm_luger');
  await expect(page.getByText('Junction cone')).toHaveCount(0);
});

test('back to the list keeps search and family', async ({ page }) => {
  await page.getByLabel('Search').fill('win');
  await page.getByLabel('Family').selectOption('rimless');
  await page.getByRole('link', { name: '270 Win.', exact: true }).click();
  await page.getByRole('link', { name: 'All cartridges' }).click();
  await expect(page.getByLabel('Search')).toHaveValue('win');
  await expect(page.getByLabel('Family')).toHaveValue('rimless');
  await expect(page.locator('#list a')).toHaveText(['243 Win.', '270 Win.', '308 Win.']);
});

test('print button calls window.print', async ({ page }) => {
  await open(page, '223 Rem.');
  await page.evaluate(() => { window.__printed = 0; window.print = () => { window.__printed++; }; });
  await page.getByRole('button', { name: 'Print' }).click();
  expect(await page.evaluate(() => window.__printed)).toBe(1);
});

test('no console errors and only app files are requested', async ({ page }, info) => {
  const errors = [], urls = [];
  page.on('pageerror', (e) => errors.push(e.message));
  page.on('console', (m) => m.type() === 'error' && errors.push(m.text()));
  page.on('request', (r) => urls.push(r.url()));
  await page.goto(info.project.metadata.appUrl);
  await open(page, '300 Win. Mag.');
  const base = info.project.metadata.appUrl.replace(/index\.html$/, '');
  for (const u of urls) expect(u.startsWith(base) || u.startsWith('data:'), u).toBe(true);
  expect(errors).toEqual([]);
});

test('drawing: scale, halves, centre line, labels, missing-value note', async ({ page }, info) => {
  await page.goto(info.project.metadata.appUrl + '#/cartridge/308_win');
  const svg = page.getByRole('img', { name: '308 Win. drawing' });
  await expect(svg).toBeVisible();
  await expect(svg.locator('text', { hasText: 'L3 51.18' })).toHaveCount(1);
  await expect(svg.locator('text', { hasText: 'α 40°' })).toHaveCount(1);
  const dash = await svg.locator('.centre-line').evaluate((e) => getComputedStyle(e).strokeDasharray);
  expect(dash.split(/[ ,]+/).length).toBeGreaterThanOrEqual(4);
  // hatched walls are below the axis: bounding box top is at or below y = 0
  const box = await svg.locator('.wall').evaluate((e) => { const b = e.getBBox(); return { y: b.y, h: b.height }; });
  expect(box.y).toBeGreaterThanOrEqual(0);
  await page.goto(info.project.metadata.appUrl + '#/cartridge/338_lapua_mag');
  await expect(page.locator('.notes')).toContainText('r1 min');
});

test('rendered label text stays inside the layout boxes and apart for all records', async ({ page }, info) => {
  for (const r of data) {
    await page.goto(info.project.metadata.appUrl + '#/cartridge/' + r.key);
    const res = await page.locator('svg.drawing').evaluate((svg) => {
      const boxes = [...svg.querySelectorAll('text.dim-label')].map((t) => { const b = t.getBBox(); return { id: t.dataset.dim, x0: b.x, x1: b.x + b.width, y0: b.y, y1: b.y + b.height }; });
      const bad = [];
      for (let i = 0; i < boxes.length; i++) for (let j = i + 1; j < boxes.length; j++) {
        const a = boxes[i], b = boxes[j];
        if (a.x0 < b.x1 && b.x0 < a.x1 && a.y0 < b.y1 && b.y0 < a.y1) bad.push(a.id + '/' + b.id);
      }
      const vb = svg.viewBox.baseVal;
      for (const b of boxes) if (b.x0 < vb.x || b.x1 > vb.x + vb.width || b.y0 < vb.y || b.y1 > vb.y + vb.height) bad.push('outside ' + b.id);
      return bad;
    });
    expect(res, r.key).toEqual([]);
  }
});
