const { test, expect } = require('@playwright/test');
const data = require('../../js/data.js');

test.use({ colorScheme: 'dark' });

test('printed detail view is light, without interface, with a footer', async ({ page }, info) => {
  await page.goto(info.project.metadata.appUrl + '#/cartridge/308_win');
  await page.emulateMedia({ media: 'print', colorScheme: 'dark' });
  const bg = await page.evaluate(() => getComputedStyle(document.body).backgroundColor);
  expect(bg).toBe('rgb(255, 255, 255)');
  expect(await page.evaluate(() => getComputedStyle(document.body).color)).toBe('rgb(0, 0, 0)');
  await expect(page.getByRole('button', { name: 'Print' })).toBeHidden();
  await expect(page.getByRole('link', { name: 'All cartridges' })).toBeHidden();
  await expect(page.locator('#list-view')).toBeHidden();
  await expect(page.getByText('Source: C.I.P. TDCC, revised 2008-09-23')).toBeVisible();
  await expect(page.getByRole('heading', { level: 1, name: '308 Win.' })).toBeVisible();
});

test('every detail view prints on one A4 portrait page', async ({ page }, info) => {
  await page.setViewportSize({ width: 718, height: 1047 });
  for (const r of data) {
    await page.goto(info.project.metadata.appUrl + '#/cartridge/' + r.key);
    await page.emulateMedia({ media: 'print' });
    // the content ends above the fixed footer
    const gap = await page.evaluate(() => document.querySelector('.source').getBoundingClientRect().top - document.querySelector('.groups').getBoundingClientRect().bottom);
    expect(gap, r.key).toBeGreaterThan(5);
    const pdf = await page.pdf({ preferCSSPageSize: true });
    const text = pdf.toString('latin1');
    const pages = (text.match(/\/Type\s*\/Page[^s]/g) || []).length;
    expect(pages, r.key).toBe(1);
    expect(text, r.key).toMatch(/\/MediaBox\s*\[\s*0 0 59[45]\.\d+ 84[12]\.\d+\s*\]/);
  }
});
