const { test, expect } = require('@playwright/test');

test.describe('phone', () => {
  test.use({ viewport: { width: 360, height: 740 } });
  for (const hash of ['', '#/cartridge/338_lapua_mag', '#/cartridge/22_long_rifle']) {
    test('no horizontal scroll at 360 px ' + (hash || 'list'), async ({ page }, info) => {
      await page.goto(info.project.metadata.appUrl + hash);
      await page.locator('h1:visible').waitFor();
      const [sw, cw] = await page.evaluate(() => [document.documentElement.scrollWidth, document.documentElement.clientWidth]);
      expect(sw).toBeLessThanOrEqual(cw);
      if (hash) {
        const w = await page.locator('svg.drawing').evaluate((e) => e.getBoundingClientRect().width);
        expect(w).toBeLessThanOrEqual(360);
        // legible: the 3 mm label font renders at least 7 px
        const px = await page.locator('svg.drawing text.dim-label').first().evaluate((e) => e.getBoundingClientRect().height);
        expect(px).toBeGreaterThanOrEqual(6);
      }
    });
  }
});

test.describe('dark', () => {
  test.use({ colorScheme: 'dark' });
  test('dark system theme gives a dark page', async ({ page }, info) => {
    await page.goto(info.project.metadata.appUrl + '#/cartridge/308_win');
    const bg = await page.evaluate(() => getComputedStyle(document.body).backgroundColor);
    const [r, g, b] = bg.match(/\d+/g).map(Number);
    expect(r + g + b).toBeLessThan(200);
    const ink = await page.locator('svg.drawing .outline').first().evaluate((e) => getComputedStyle(e).stroke);
    const [ir, ig, ib] = ink.match(/\d+/g).map(Number);
    expect(ir + ig + ib).toBeGreaterThan(500);
  });
});
