// Minimal static file server for the e2e tests and `npm start`.
const http = require('http');
const fs = require('fs');
const path = require('path');
const root = path.resolve(__dirname, '..');
const types = { '.html': 'text/html', '.js': 'text/javascript', '.css': 'text/css' };
http
  .createServer((req, res) => {
    let pathname;
    try { pathname = decodeURIComponent(new URL(req.url, 'http://x').pathname); } catch (e) { res.writeHead(400).end('bad request'); return; }
    const file = path.join(root, pathname === '/' ? 'index.html' : pathname);
    // only the app files: index.html, css/, js/
    const rel = path.relative(root, file).split(path.sep);
    if (!(rel.join('/') === 'index.html' || (['css', 'js'].includes(rel[0]) && rel.length === 2 && !rel.includes('..'))) || !fs.existsSync(file)) {
      res.writeHead(404).end('not found');
      return;
    }
    res.writeHead(200, { 'Content-Type': types[path.extname(file)] || 'application/octet-stream' });
    fs.createReadStream(file).pipe(res);
  })
  .listen(Number(process.env.PORT) || 4173, '127.0.0.1', () => console.log('http://127.0.0.1:' + (process.env.PORT || 4173) + '/'));
