const test = require('node:test');
const assert = require('node:assert/strict');
const C = require('../../js/catalog.js');
const data = require('../../js/data.js');
const names = (q, f) => C.filter(data, q, f).map((r) => r.name);

test('no filter lists all 25', () => assert.equal(names('', 'All').length, 25));
test('alternative names', () => assert.deepEqual(names('7,62 x 51', 'All'), ['308 Win.']));
test('spaces and case are ignored', () => {
  assert.deepEqual(names('7,62x51', 'All'), ['308 Win.']);
  assert.deepEqual(names('308 WINCHESTER', 'All'), ['308 Win.']);
});
test('name search', () => assert.ok(names('creed', 'All').includes('6,5 Creedmoor')));
test('family filter', () => {
  assert.deepEqual(names('', 'rimfire'), ['22 Long Rifle', '22 Win. Mag. R.F.', '17 HMR']);
  assert.equal(names('', 'belted').length, 2);
});
test('combined', () => assert.deepEqual(names('44', 'pistol'), ['44 Rem. Mag.']));
test('no match', () => assert.deepEqual(names('zzz', 'All'), []));
