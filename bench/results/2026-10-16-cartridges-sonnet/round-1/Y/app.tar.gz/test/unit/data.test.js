const test = require('node:test');
const assert = require('node:assert/strict');
const data = require('../../js/data.js');

test('25 records with unique keys and names', () => {
  assert.equal(data.length, 25);
  assert.equal(new Set(data.map((r) => r.key)).size, 25);
  assert.equal(new Set(data.map((r) => r.name)).size, 25);
});

test('family counts', () => {
  const n = (f) => data.filter((r) => r.family === f).length;
  assert.deepEqual(
    { rimless: n('rimless'), rimmed: n('rimmed'), belted: n('belted'), pistol: n('pistol'), rimfire: n('rimfire') },
    { rimless: 12, rimmed: 2, belted: 2, pistol: 6, rimfire: 3 }
  );
});

test('records keep published values', () => {
  const r = data.find((x) => x.key === '308_win');
  assert.equal(r.name, '308 Win.');
  assert.deepEqual(r.alternativeNames, ['308 Winchester', '7,62 x 51']);
  assert.equal(r.cartridge.lengths.L3, 51.18);
  assert.equal(r.cartridge.pressures.Pmax, 4150);
  assert.equal(data.find((x) => x.key === '6_5_creedmoor').name, '6,5 Creedmoor');
});
