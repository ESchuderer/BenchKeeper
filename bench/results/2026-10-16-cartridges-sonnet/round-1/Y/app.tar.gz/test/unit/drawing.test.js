const test = require('node:test');
const assert = require('node:assert/strict');
const D = require('../../js/drawing.js');
const G = require('../../js/geometry.js');
const F = require('../../js/format.js');
const data = require('../../js/data.js');
const rec = (k) => data.find((r) => r.key === k);
const draw = (k) => D.draw(rec(k));
const ids = (d) => d.labels.map((l) => l.id).sort();

const segHitsBox = (s, b) => {
  // Liang-Barsky clip of the segment against the box
  let t0 = 0, t1 = 1;
  const dx = s.x2 - s.x1, dy = s.y2 - s.y1;
  for (const [p, q] of [[-dx, s.x1 - b.x0], [dx, b.x1 - s.x1], [-dy, s.y1 - b.y0], [dy, b.y1 - s.y1]]) {
    if (p === 0) { if (q < 0) return false; } else {
      const r = q / p;
      if (p < 0) { if (r > t1) return false; if (r > t0) t0 = r; } else { if (r < t0) return false; if (r < t1) t1 = r; }
    }
  }
  return t0 <= t1;
};
const boxesHit = (a, b) => a.x0 < b.x1 && b.x0 < a.x1 && a.y0 < b.y1 && b.y0 < a.y1;

test('308 Win.: svg name, scale, labels', () => {
  const d = draw('308_win');
  assert.match(d.svg, /^<svg [^>]*role="img"/);
  assert.match(d.svg, /aria-label="308 Win\. drawing"/);
  assert.deepEqual(ids(d), ['E1', 'G1', 'H1', 'H2', 'L1', 'L2', 'L3', 'L6', 'P1', 'P2', 'R', 'R1', 'alpha'].sort());
  const text = (id) => d.labels.find((l) => l.id === id).text;
  assert.equal(text('L3'), 'L3 51.18');
  assert.equal(text('L1'), 'L1 39.62 -0.2');
  assert.equal(text('alpha'), 'α 40°');
  assert.equal(text('R1'), 'R1 12.01');
  // 1 user unit = 1 mm: the mouth face lies at x = L3
  assert.ok(d.outline.upper.some((p) => p.x === 51.18));
  assert.ok(d.outline.upper.some((p) => Math.abs(p.x - 71.12) < 1e-9));
});

test('names are escaped in the svg', () => {
  assert.match(draw('40_s_w').svg, /aria-label="40 S\.&amp; W\. drawing"/);
});

test('only published dimensions are drawn', () => {
  assert.deepEqual(ids(draw('9_mm_luger')), ['E1', 'G1', 'H2', 'L3', 'L6', 'P1', 'R', 'R1']);
  assert.deepEqual(ids(draw('22_long_rifle')), ['G1', 'H2', 'L3', 'L6', 'P1', 'R', 'R1']);
  assert.ok(ids(draw('17_hmr')).includes('alpha'));
  assert.equal(draw('9_mm_luger').labels.find((l) => l.id === 'L3').text, 'L3 19.15 -0.25');
});

test('every dimension has two arrowheads (alpha too) and extension lines', () => {
  for (const r of data) {
    const d = D.draw(r);
    for (const dim of d.dims) {
      assert.equal(dim.arrows, 2, `${r.key} ${dim.id}`);
      if (dim.id !== 'alpha') assert.ok(dim.ext >= 2, `${r.key} ${dim.id}`);
    }
    for (const id of ['L3', 'L6', 'R1', 'R', 'P1']) assert.ok(d.dims.some((x) => x.id === id), `${r.key} ${id}`);
  }
});

test('labels overlap neither each other nor any line of the drawing, for all 25 records', () => {
  for (const r of data) {
    const d = D.draw(r);
    for (let i = 0; i < d.labels.length; i++) {
      for (let j = i + 1; j < d.labels.length; j++) {
        assert.ok(!boxesHit(d.labels[i].box, d.labels[j].box), `${r.key}: ${d.labels[i].id} overlaps ${d.labels[j].id}`);
      }
      for (const s of d.segments) {
        assert.ok(!segHitsBox(s, d.labels[i].box), `${r.key}: label ${d.labels[i].id} hits ${s.kind} ${s.id || ''}`);
      }
      const b = d.labels[i].box, v = d.viewBox;
      assert.ok(b.x0 >= v.x && b.x1 <= v.x + v.w && b.y0 >= v.y && b.y1 <= v.y + v.h, `${r.key}: ${d.labels[i].id} outside viewBox`);
    }
  }
});

test('section: hatch only below the axis, centre line present', () => {
  const d = draw('308_win');
  assert.ok(d.hatch.length >= 1);
  for (const poly of d.hatch) for (const p of poly) assert.ok(p.y >= 0);
  assert.ok(d.segments.some((s) => s.kind === 'centre' && s.y1 === 0 && s.y2 === 0));
  assert.match(d.svg, /class="centre-line"/);
});

test('title block', () => {
  const d = draw('308_win');
  for (const t of ['308 Win.', 'C.I.P. table I', 'Revised 2008-09-23', 'Dimensions in mm', 'Scale']) {
    assert.ok(d.title.some((s) => s.includes(t)), t);
  }
  assert.match(d.svg, /Dimensions in mm/);
  const scale = d.title.find((s) => s.startsWith('Scale'));
  assert.equal(scale, `Scale ${Math.min(190 / d.viewBox.w, 165 / d.viewBox.h).toFixed(2)}:1 (A4 print)`);
});

test('view box has the aspect needed for a phone and no invented numbers', () => {
  for (const r of data) {
    const d = D.draw(r);
    assert.ok(d.viewBox.w >= 90 && d.viewBox.w < 200, `${r.key} ${d.viewBox.w}`);
    assert.ok(d.viewBox.h > 40 && d.viewBox.h < 140, `${r.key} ${d.viewBox.h}`);
    assert.doesNotMatch(d.svg, /NaN|undefined|Infinity/, r.key);
  }
});
