const test = require('node:test');
const assert = require('node:assert/strict');
const F = require('../../js/format.js');
const data = require('../../js/data.js');
const rec = (k) => data.find((r) => r.key === k);

test('angles', () => {
  assert.equal(F.formatAngle(40), '40°');
  assert.equal(F.formatAngle({ degrees: 39, minutes: 59, seconds: 49 }), '39°59\'49"');
  assert.equal(F.formatAngle({ degrees: 34, minutes: 30, seconds: 0 }), '34°30\'0"');
});

test('numbers as published', () => {
  assert.equal(F.formatNumber(4150), '4150');
  assert.equal(F.formatNumber(51.18), '51.18');
  assert.equal(F.formatNumber(9), '9');
});

test('symbols', () => {
  assert.equal(F.symbolOf('eMin'), 'e min');
  assert.equal(F.symbolOf('r1Min'), 'r1 min');
  assert.equal(F.symbolOf('r1Max'), 'r1 max');
  assert.equal(F.symbolOf('alpha'), 'α');
  assert.equal(F.symbolOf('alpha1'), 'α1');
  assert.equal(F.symbolOf('beta'), 'β');
  assert.equal(F.symbolOf('delta'), 'δ');
  assert.equal(F.symbolOf('deltaL'), 'delta L');
  assert.equal(F.symbolOf('L3PlusG'), 'L3 + G');
  assert.equal(F.symbolOf('Pmax'), 'Pmax');
});

test('units', () => {
  assert.equal(F.unitOf('L3'), 'mm');
  assert.equal(F.unitOf('Pmax'), 'bar');
  assert.equal(F.unitOf('PK'), 'bar');
  assert.equal(F.unitOf('PE'), 'bar');
  assert.equal(F.unitOf('EE'), 'J');
  assert.equal(F.unitOf('M'), 'g');
  assert.equal(F.unitOf('Q'), 'mm²');
  assert.equal(F.unitOf('N'), '');
  for (const k of ['alpha', 'alpha1', 'beta', 'delta', 'i']) assert.equal(F.unitOf(k), '°');
});

test('rows merge the tolerance into the value and never list it', () => {
  const rows = F.sectionRows(rec('308_win').cartridge.lengths);
  assert.deepEqual(rows.map((r) => r.symbol), ['L1', 'L2', 'L3', 'L6']);
  const l1 = rows[0];
  assert.equal(l1.value, '39.62');
  assert.equal(l1.tol, '-0.2');
  assert.equal(F.valueText(l1), '39.62 -0.2');
  assert.equal(rows[2].tol, undefined);
});

test('no record yields a Tol row', () => {
  for (const r of data) {
    for (const part of ['cartridge', 'chamber']) {
      for (const sec of Object.values(r[part])) {
        for (const row of F.sectionRows(sec)) assert.ok(!/Tol$/.test(row.key), row.key);
      }
    }
  }
});

test('angle rows and units', () => {
  const rows = F.sectionRows(rec('338_lapua_mag').cartridge.junctionCone);
  const a = rows.find((r) => r.symbol === 'α');
  assert.equal(a.value, '39°59\'49"');
  assert.equal(a.unit, '°');
});

test('section titles and groups skip empty sections', () => {
  const g = F.sections(rec('9_mm_luger').cartridge);
  assert.ok(!g.some((s) => s.title === 'Junction cone'));
  assert.deepEqual(F.sections(rec('223_rem').cartridge).map((s) => s.title), [
    'Case head', 'Collar', 'Junction cone', 'Lengths', 'Miscellaneous', 'Powder chamber', 'Pressures', 'Projectile'
  ]);
});

test('label text', () => {
  assert.equal(F.labelText('L3', 51.18), 'L3 51.18');
  assert.equal(F.labelText('L3', 19.15, -0.25), 'L3 19.15 -0.25');
  assert.equal(F.labelText('alpha', 46), 'α 46°');
});

test('an undefined tolerance is no tolerance', () => {
  const rows = F.sectionRows({ L3: 44.7, L3Tol: undefined });
  assert.deepEqual(rows.map((r) => F.valueText(r)), ['44.7']);
  assert.equal(F.formatTol(0), '0');
});
