const test = require('node:test');
const assert = require('node:assert/strict');
const G = require('../../js/geometry.js');
const data = require('../../js/data.js');
const rec = (k) => data.find((r) => r.key === k);
const model = (k) => G.build(rec(k));
const near = (a, b, eps = 1e-6) => assert.ok(Math.abs(a - b) <= eps, `${a} != ${b}`);
const has = (pts, r, z) => pts.some((p) => Math.abs(p.r - r) < 1e-6 && Math.abs(p.z - z) < 1e-6);

test('rim types', () => {
  const t = (k) => model(k).rimType;
  assert.equal(t('9_3_x_74_r'), 'rimmed');
  assert.equal(t('7_x_65_r'), 'rimmed');
  assert.equal(t('38_special'), 'rimmed');
  assert.equal(t('300_win_mag'), 'belted');
  assert.equal(t('7_mm_rem_mag'), 'belted');
  assert.equal(t('22_long_rifle'), 'rimfire');
  assert.equal(t('17_hmr'), 'rimfire');
  assert.equal(t('308_win'), 'rimless');
  assert.equal(t('6_5_x_55_se'), 'rimless');
  assert.equal(t('9_mm_luger'), 'rimless');
  assert.equal(G.rimType({ family: 'pistol', cartridge: { caseHead: { R1: 9, }, powderChamber: { P1: 10 } } }), 'rebated');
});

test('all records build and the outer profile runs head to mouth', () => {
  for (const r of data) {
    const m = G.build(r);
    const o = m.outer;
    assert.deepEqual(o[0], { r: 0, z: 0 }, r.key);
    const last = o[o.length - 1];
    near(last.z, r.cartridge.lengths.L3);
    near(last.r, r.cartridge.collar.H2 / 2);
    for (let i = 1; i < o.length; i++) assert.ok(o[i].z >= o[i - 1].z - 1e-9, `${r.key} z not monotonic at ${i}`);
    assert.ok(m.inner.length > 2, r.key);
    for (const p of m.inner) assert.ok(p.r > 0 && p.r < m.rMax, r.key);
  }
});

test('head chamfer, groove and ramp of 308 Win.', () => {
  const m = model('308_win');
  const c = Math.min(0.38 * Math.tan((35 * Math.PI) / 180), 12.01 / 4);
  assert.ok(has(m.outer, 12.01 / 2 - c, 0));
  assert.ok(has(m.outer, 12.01 / 2, 0.38));
  assert.ok(has(m.outer, 12.01 / 2, 1.37));
  assert.ok(has(m.outer, 10.39 / 2, 1.37));
  assert.ok(has(m.outer, 10.39 / 2, 1.37 + 1.4));
  assert.ok(has(m.outer, 11.96 / 2, 3.85));
  assert.equal(m.anchors.bodyStartZ, 3.85);
});

test('shoulder points and alpha of 223 Rem.', () => {
  const m = model('223_rem');
  assert.deepEqual(m.shoulder.P, { r: 4.5, z: 36.52 });
  assert.deepEqual(m.shoulder.N, { r: 3.215, z: 39.55 });
  assert.equal(m.shoulder.alpha, 46);
  near(m.shoulder.halfAngle * 2, 46, 0.1);
});

test('rounded corners stay on tangent points and keep the end point', () => {
  const m = model('6_5_x_55_se');
  const body = m.outer.filter((p) => p.z > 3.25);
  assert.ok(body.length > 20);
  for (const p of body) assert.ok(p.r <= 6.1 + 1e-9 && p.r >= 3.75 - 1e-9);
});

test('straight case ends at (H2/2, L3)', () => {
  const m = model('9_mm_luger');
  assert.equal(m.shoulder, null);
  const last = m.outer[m.outer.length - 1];
  assert.deepEqual(last, { r: 9.65 / 2, z: 19.15 });
});

test('belted case ramps at delta to the belt, follows it to E and steps in', () => {
  const m = model('300_win_mag');
  const zr = 1.27 + 0.94 + (13.51 / 2 - 12.07 / 2) / Math.tan((35 * Math.PI) / 180);
  assert.ok(has(m.outer, 13.51 / 2, zr));
  assert.ok(has(m.outer, 13.51 / 2, 5.59));
  assert.ok(has(m.outer, 13.03 / 2, 5.59));
  near(m.head.w, Math.max(2.5, 0.25 * 13.03 / 2, 3.3 + 1.5, zr + 0.6));
});

test('rimmed case without groove steps in at z = R', () => {
  const m = model('9_3_x_74_r');
  assert.ok(has(m.outer, 13.35 / 2, 1.4));
  assert.ok(has(m.outer, 11.9 / 2, 1.4));
  assert.equal(m.notes.length, 0);
});

test('rimfire rim edge is a half-round with outermost point at R1/2', () => {
  const m = model('22_long_rifle');
  const rho = Math.min(1.09 / 2, (7.06 - 5.74) / 2);
  assert.ok(has(m.outer, 7.06 / 2, 1.09 / 2));
  near(Math.max(...m.outer.map((p) => p.r)), 7.06 / 2);
  assert.ok(m.outer.some((p) => Math.abs(p.r - (7.06 / 2 - rho)) < 1e-9 && p.z > 0));
  assert.equal(m.head.pocket, null);
});

test('pointy bullet of 308 Win.', () => {
  const b = model('308_win').bullet;
  near(b.s, 7.85);
  near(b.zb, 51.18 - 7.85);
  near(b.zc, b.zb + 0.4 * (71.12 - b.zb));
  near(b.m, 1.27);
  const tip = b.profile[b.profile.length - 2];
  near(tip.z, 71.12);
  near(tip.r, 1.27 / 2);
  assert.ok(b.exposed[0].z === 51.18);
  near(b.exposed[0].r, 7.85 / 2);
  // tangent ogive: every nose point lies on the arc of radius rho
  const n = 71.12 - b.zc, a = 7.85 / 2 - 1.27 / 2;
  const rho = (a * a + n * n) / (2 * a);
  for (const p of b.nose) near(Math.hypot(p.r - (7.85 / 2 - rho), p.z - b.zc), rho, 1e-6);
});

test('rounded, flat and semi-wadcutter parameters', () => {
  const r9 = model('9_mm_luger').bullet;
  near(r9.s, 0.4 * 9.03);
  near(r9.m, 0.15 * 9.03);
  near(r9.zc, r9.zb + 0.65 * (29.69 - r9.zb));
  const lr = model('22_win_mag_r_f').bullet;
  near(lr.s, 0.8 * 5.7);
  near(lr.zc, lr.zb + 0.55 * (34.29 - lr.zb));
  const fl = model('40_s_w').bullet;
  near(fl.s, 0.4 * 10.17);
  near(fl.m, 0.55 * 10.17);
  near(fl.zc, fl.zb + 0.7 * (28.83 - fl.zb));
  const sw = model('357_magnum').bullet;
  near(sw.s, 0.6 * 9.12);
  near(sw.m, 0.6 * 9.12);
  near(sw.zc, sw.zb + 0.78 * (40.39 - sw.zb));
});

test('heeled 22 Long Rifle', () => {
  const m = model('22_long_rifle');
  assert.equal(m.walls.heeled, true);
  near(m.bullet.exposedD, 5.72);
  near(m.bullet.heelD, 5.72 - 2 * 0.6);
  near(m.bullet.exposed[0].r, 5.72 / 2);
});

test('walls and head of 308 Win.', () => {
  const m = model('308_win');
  near(m.walls.tn, 0.435);
  near(m.walls.tb, 0.6);
  assert.deepEqual(m.head.pocket, { d: 5.33, h: 3.3 });
  near(m.head.w, 4.8);
  assert.equal(model('9_mm_luger').head.pocket.d, 4.45);
  assert.equal(model('9_mm_luger').head.pocket.h, 3.04);
  near(model('9_mm_luger').head.w, 3.04 + 1.5);
  assert.equal(model('44_rem_mag').head.pocket.d, 5.33);
  assert.equal(model('44_rem_mag').head.pocket.h, 3.04);
});

test('inner line: tb on the body, tn on the neck, linear across the shoulder', () => {
  const m = model('308_win');
  const outerAt = (z) => {
    for (let i = 1; i < m.outer.length; i++) {
      const a = m.outer[i - 1], b = m.outer[i];
      if (z >= a.z && z <= b.z && b.z > a.z) return a.r + ((b.r - a.r) * (z - a.z)) / (b.z - a.z);
    }
  };
  const innerAt = (z) => {
    for (let i = 1; i < m.inner.length; i++) {
      const a = m.inner[i - 1], b = m.inner[i];
      if (z >= a.z && z <= b.z && b.z > a.z) return a.r + ((b.r - a.r) * (z - a.z)) / (b.z - a.z);
    }
  };
  near(outerAt(20) - innerAt(20), 0.6, 1e-3);
  near(outerAt(48) - innerAt(48), 0.435, 1e-3);
  near(outerAt(41.55) - innerAt(41.55), (0.6 + 0.435) / 2, 0.02);
});

test('missing values are named and the feature is skipped', () => {
  const r = JSON.parse(JSON.stringify(rec('308_win')));
  delete r.cartridge.caseHead.E1;
  const m = G.build(r);
  assert.deepEqual(m.notes, [{ feature: 'Extractor groove', missing: ['E1'] }]);
  assert.ok(!has(m.outer, 10.39 / 2, 1.37));
  assert.ok(has(m.outer, 11.96 / 2, 1.37));
  assert.equal(G.noteText(m.notes[0]), 'Extractor groove not drawn: E1 not published');
  assert.deepEqual(model('338_lapua_mag').notes, [{ feature: 'Shoulder corner rounding (body side)', missing: ['r1 min'] }]);
  assert.deepEqual(model('17_hmr').notes.map((n) => n.missing), [['r1 min'], ['r2']]);
  assert.equal(model('308_win').notes.length, 0);
});

test('no invented numbers: a record without G1 draws no bullet and says so', () => {
  const r = JSON.parse(JSON.stringify(rec('308_win')));
  delete r.cartridge.projectile.G1;
  const m = G.build(r);
  assert.equal(m.bullet, null);
  assert.ok(m.notes.some((n) => n.feature === 'Bullet' && n.missing.includes('G1')));
});
