# 01: Start page: list, search, family filter

**What to build:** Opening index.html from disk shows the heading Cartridges, all 25 cartridges (name link, family, L3), a Search field, a Family select and the text '<n> cartridges'; typing or choosing filters the list.

**Blocked by:** None (can start immediately)

**Status:** done

- [x] Data script holds the 25 records verbatim
- [x] '7,62 x 51' finds '308 Win.'
- [x] Family select filters; count text follows
- [x] Works over file:// with no network requests
