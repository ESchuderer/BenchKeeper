# 02: Detail view: metadata and value tables

**What to build:** Each name opens a bookmarkable detail view with metadata and tables of all cartridge and chamber values (Symbol, Value, Unit), tolerances beside values, angles as published, All cartridges link and Print button.

**Blocked by:** 01

**Status:** done

- [x] Address #/cartridge/<key> survives reload
- [x] Tolerance never a row of its own
- [x] Angles shown 40° and 39°59'49"
- [x] Heading is the name; water capacity links its source
