# 03: Computed 2D drawing

**What to build:** Every detail view shows an inline SVG drawing 'name drawing' computed from the record with the brief's geometry rules: outline, section hatching, bullet, dimensions, title block, missing-value notes.

**Blocked by:** 02

**Status:** done

- [x] buildDrawing geometry matches rules 1-9 (unit tests)
- [x] Labels do not overlap each other or outline, all 25 records
- [x] SVG scales to phone width
- [x] Missing values named, no number invented
