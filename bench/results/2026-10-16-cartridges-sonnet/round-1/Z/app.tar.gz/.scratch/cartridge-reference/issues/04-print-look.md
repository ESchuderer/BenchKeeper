# 04: Print layout and look and feel

**What to build:** Print produces one A4 portrait black-on-white page per detail view with header, full-width drawing, tables and source footer; light/dark and phone layout are polished.

**Blocked by:** 03

**Status:** done

- [x] All 25 print to exactly one A4 page
- [x] No navigation, search or buttons in print
- [x] Dark scheme on screen, print always light
- [x] Usable at 360 px width
