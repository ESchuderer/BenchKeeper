Status: implemented

# Spec: C.I.P. cartridge reference (static web app)

## Problem Statement

Reloaders, gunsmiths and engineers who need the C.I.P. dimensions of a cartridge and its chamber have to open scattered PDFs or tools that need a server or network. They want one fast, dense, offline reference that lists cartridges, finds them by any of their names, shows every published value with its unit and tolerance, shows a true-to-scale drawing, and prints cleanly.

## Solution

A static web app (`index.html` plus CSS and JS, no framework, no build, no network) modelled on the OpenBallistics cartridge database. A start page lists the 25 cartridges with search and a family filter. Each cartridge has a bookmarkable detail view: metadata, a computed 2D drawing (outside view above the axis, section below, dimension lines, title block), tables of all cartridge and chamber values, and a Print button that produces one A4 page. It opens directly from disk in Chromium.

## User Stories

1. As a reloader, I want a list of all cartridges with name, family and case length L3, so that I can scan the database at a glance.
2. As a reloader, I want each name to be a link to the cartridge, so that I can open its detail view.
3. As a reloader, I want to type "7,62 x 51" and find "308 Win.", so that I can search by an alternative name.
4. As a reloader, I want the list to filter as I type, so that I need no submit button.
5. As a reloader, I want to filter by family (All, rimless, rimmed, belted, pistol, rimfire), so that I can narrow the list.
6. As a reloader, I want to see "<n> cartridges", so that I know how many match.
7. As an engineer, I want names shown exactly as published (for example "6,5 Creedmoor"), so that I can match them to C.I.P. documents.
8. As an engineer, I want each detail view to show alternative names, family, category, primer type, C.I.P. table, country, published and revised dates, pressure method and the water capacity with its source link, so that I know the provenance of the data.
9. As an engineer, I want all cartridge values and all chamber values in tables grouped by section with Symbol, Value and Unit columns, so that I can look up any dimension.
10. As an engineer, I want a tolerance shown next to its value (for example "39.62 -0.2") and never as its own row, so that the tables stay compact and correct.
11. As an engineer, I want values as published (decimal point, no thousands separator, "4150 bar"), so that nothing is reformatted.
12. As an engineer, I want angles as "40°" or "39°59'49\"", so that degrees, minutes and seconds are legible.
13. As an engineer, I want the symbols the way C.I.P. writes them (α, β, δ, "e min", "L3 + G"), so that I recognise them.
14. As a gunsmith, I want a 2D drawing computed from the record, true to scale (1 user unit = 1 mm), so that I can judge shape and proportions.
15. As a gunsmith, I want the upper half as outside view and the lower half as a hatched section, so that I see wall and head thickness.
16. As a gunsmith, I want dimension lines with arrowheads and extension lines labelled with symbol and value for L3, L6, R1, R, P1 and, where published, P2, H1, H2, G1, L1, L2, E1 and the shoulder angle α, so that I can read the key dimensions off the drawing.
17. As a gunsmith, I want labels that never overlap each other or the outline, so that the drawing is readable.
18. As a gunsmith, I want a title block with name, C.I.P. table, revision date, "Dimensions in mm" and the scale, so that the drawing is self-describing.
19. As an engineer, I want the drawing to say which published value is missing when a feature cannot be drawn, and never to invent a number, so that I can trust it.
20. As a phone user, I want the drawing to scale to my screen width and the layout to stay usable, so that I can use the reference at the bench.
21. As a user, I want each detail view to have its own address that survives reload and can be bookmarked, so that I can return to it.
22. As a user, I want a link "All cartridges" back to the list, so that I can navigate.
23. As a user, I want a "Print" button that opens the print dialog and prints one A4 portrait page (header with name, drawing at full width, tables, footer with source and revision date, black on white, no navigation), so that I can pin it to the wall.
24. As a user, I want light and dark appearance following my system setting while print stays light, so that it is comfortable on screen and on paper.
25. As an offline user, I want the app to work when `index.html` is opened from disk and make no network requests, so that I can use it anywhere.

## Implementation Decisions

- Classic scripts only (ADR 0001), one global namespace; data as one script holding the 25 records verbatim.
- Hash routing `#/cartridge/<key>` (ADR 0002); empty hash is the list.
- Modules (deep, small interfaces):
  - **Catalogue**: records plus `filter(records, query, family)`; search matches name and alternative names, case-insensitive, decimal comma and space around "x" tolerant.
  - **Format**: published number, angle, tolerance, unit and symbol rules; builds the detail view-model (meta rows and sections of rows). Tolerances fold into their base value; empty sections are omitted.
  - **Drawing**: `buildDrawing(record)` returns a model (outer half-profile points, rim type, bullet, dimensions, label boxes, notes, view box, scale, SVG string) from the brief's geometry rules 1-9. Pure, no DOM.
  - **App**: list view, detail view, router, print button.
- Drawing layout: font size grows with drawing width (readable on phones and print); labels get collision-free positions from a small placement solver over outline segments, extension lines and already placed labels; vertical (diameter) dimension labels are rotated.
- Straight (non-heeled) cases: the inner wall blends linearly from tb at the end of the solid head to tn at the bullet base so the seated bullet never overlaps the wall; heeled cases use tb throughout. (Documented interpretation: the brief defines tb/tn for bottleneck cases only.)
- Interpretations the brief leaves open: the inner wall is offset radially (in r) from the outer profile, not perpendicular to it; fillet radii are scaled down only when both do not fit on the shoulder; the meplat of a heeled bullet follows the exposed (case outside) diameter; the title-block scale is the A4 print scale; narrow, tall drawings get empty side space in the view box so the A4 print stays one page; the caption under the drawing names the rim type and lists the drawing notes.
- Print: `@page` A4 portrait, light palette forced, drawing at 190 mm, tables in three columns, footer "Source: C.I.P. TDCC, revised <date>". The title-block scale is the A4 print scale (190 mm / view box width).
- Language: English UI.

## Testing Decisions

Seams (decided without further user check-in, per the user's instruction to proceed):

1. **Browser seam**: the real `index.html` opened over `file://` in Chromium via Playwright (dev dependency). Covers list, search, family filter, count, links, routing and reload, detail meta, value formatting, tables, drawing presence and accessible name, label overlap measured on rendered text, print (PDF page count, print media rules), dark/light, phone viewport, no network requests.
2. **Drawing seam**: `buildDrawing(record)` in Node (`node:test`). Covers the geometry rules with literal expected numbers worked from the brief (rim type, chamfer, groove, belt, bottleneck, shoulder angle, bullet shapes and seating, heeled case, walls, head, missing-value notes), plus label-overlap on the model for all 25 records.

Good tests assert externally visible behaviour with literals from the brief or hand-worked examples, never recompute the implementation's formula. Prior art: none (new repo).

## Out of Scope

Fetching or changing data; editing records; units conversion; comparing cartridges; ballistic calculations; the `implausible`/`confidence` annotations; any server code; build tooling for the app.

## Further Notes

Source data: OpenBallistics (MIT, commit e83db43). Drawing text uses a monospace stack so label widths are predictable.
