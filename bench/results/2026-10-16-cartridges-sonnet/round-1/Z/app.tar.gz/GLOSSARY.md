# Cartridge reference

A static reference database of C.I.P. cartridges and their chambers, for reloaders, gunsmiths and engineers, with a computed 2D drawing per cartridge.

## Language

**Cartridge**:
One C.I.P. record: a named set of cartridge values and chamber values with its publication metadata.
_Avoid_: Round, load, entry

**Cartridge values**:
The dimensions and pressures C.I.P. publishes for the case and bullet (`cartridge` in a record).
_Avoid_: Case data, specs

**Chamber values**:
The dimensions C.I.P. publishes for the chamber and barrel that fires the cartridge (`chamber` in a record).
_Avoid_: Gun data

**Value set**:
Either the cartridge values or the chamber values of a cartridge.

**Section** (of values):
A named group of related values inside a value set, such as case head or powder chamber. Shown as one table.
_Avoid_: Category (that is the cartridge's own `category`), group

**Symbol**:
The short label of a value: the field name, or its published notation (for example "r1 min", "α").
_Avoid_: Key, field, name

**Tolerance**:
The published tolerance `<X>Tol` of a value X; shown beside X, never on its own row.
_Avoid_: Deviation, error

**Angle**:
A value given as decimal degrees or as degrees, minutes and seconds.

**Family**:
The cartridge's rim family: rimless, rimmed, belted, pistol or rimfire. Used for filtering the list.
_Avoid_: Type, class

**Category**:
The cartridge's use: rifle, pistol or rimfire. Not the same as family.

**Rim type**:
How the drawing treats the head: belted, rimfire, rimmed, rebated or rimless. Derived from family and R1/P1.
_Avoid_: Family (family is the published label; rim type is the drawing's decision)

**Drawing**:
The computed 2D SVG of one cartridge: outside view above the axis, section below, dimension lines, title block.

**Outer half-profile**:
The ordered points `(r, z)` of the case's outside from the axis at the head face to the mouth. The drawing mirrors it at the axis.

**Heeled case**:
A case whose mouth diameter H2 equals the bullet diameter G1 within 0.015 mm, so the bullet has a narrower heel inside the case (22 Long Rifle).

**Drawing note**:
A line under the drawing saying that a feature was left out and why, usually naming the value the record does not publish. Nothing is ever drawn from an invented number.
