# C.I.P. cartridge reference

A static reference database of 25 C.I.P. cartridges and their chambers, with a computed 2D drawing and an A4 print view per cartridge. Plain HTML, CSS and JavaScript: no framework, no build step, no server code, no runtime dependencies, no network requests.

## Use

Open `index.html` directly from disk in Chromium (`file://`), or serve the folder with any static file server (`npm run serve` starts a tiny one on http://127.0.0.1:8080/).

- Start page: search (name and alternative names, e.g. `7,62 x 51` finds 308 Win.), family filter, count.
- Detail view: `index.html#/cartridge/<key>` (bookmarkable), metadata, drawing, value tables, Print.

## Files

| Path | Role |
| --- | --- |
| `index.html`, `css/app.css` | page, styles (light/dark, phone, print) |
| `data/cartridges.js` | the 25 records as given (OpenBallistics, MIT, commit e83db43) |
| `js/format.js` | published-value formatting, symbols, units, detail view-model |
| `js/catalogue.js` | list filter |
| `js/geometry.js` | outer half-profile, bullet, walls (brief rules 1-9) |
| `js/layout.js` | linework, dimension lines, label placement |
| `js/drawing.js` | drawing model and SVG |
| `js/dom.js`, `js/detail.js`, `js/app.js` | views and hash router |

All scripts are classic scripts (no modules) so `file://` works; see `docs/adr/`. Vocabulary: `GLOSSARY.md`. Spec and tickets: `.scratch/cartridge-reference/`.

## How it was built

Spec first (`.scratch/cartridge-reference/spec.md`, tickets in `issues/`), vocabulary in `GLOSSARY.md`, decisions in `docs/adr/`; then four test-first slices (list, detail, drawing, print) at two seams: the browser (real `index.html`) and `build(record)`; verification in Chromium over `file://`, over http and as A4 PDFs; finally a two-axis code review (standards and spec) whose findings were fixed.

## Tests (development only)

```
npm install
npx playwright install chromium   # once; Linux may also need Chromium's system libraries
npm test                          # unit (node:test) + browser (Playwright over file:// and http)
```

- `test/unit`: the drawing seam, `build(record)`.
- `test/e2e`: the browser seam, the real `index.html`: list, search, detail, formatting, drawing labels as rendered, print (A4 PDF page count), theme, phone width, static server.
