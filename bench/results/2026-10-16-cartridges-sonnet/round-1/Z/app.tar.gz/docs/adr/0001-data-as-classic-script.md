# The 25 records ship as a classic script, and all app code is classic scripts

The app must work from `file://` in Chromium, where `fetch()` of a JSON file and ES module imports are blocked. The records therefore live in a classic `<script>` that assigns a global, and every other file is a classic script too (a small UMD wrapper lets Node tests `require` them). The cost is a global namespace (`CIP`) instead of modules; the alternative of inlining the data in `index.html` was rejected to keep records separate from markup.
