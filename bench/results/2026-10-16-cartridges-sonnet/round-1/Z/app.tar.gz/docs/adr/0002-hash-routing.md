# Detail views are addressed by URL hash

Each cartridge detail view is `index.html#/cartridge/<key>`. A hash address survives reload and bookmarking on `file://` and on any static server without server rewrite rules; History-API paths would need server support and break on `file://`.
