/* App: router and views. Classic script; needs CIP.records and CIP.catalogue. */
(function () {
  'use strict';
  var CIP = window.CIP;
  var main = document.getElementById('main');
  var listState = { query: '', family: 'all' };

  var h = CIP.h;

  function detailHref(record) { return '#/cartridge/' + record.key; }

  /* ---------- list view ---------- */

  function renderList() {
    document.title = 'Cartridges';
    var count = h('p', { class: 'count', role: 'status' });
    var tbody = h('tbody');
    var empty = h('p', { class: 'empty', hidden: true }, 'No cartridge matches.');

    var search = h('input', { id: 'search', type: 'search', autocomplete: 'off', spellcheck: 'false', value: listState.query });
    var family = h('select', { id: 'family' });
    [['all', 'All']].concat(CIP.catalogue.FAMILIES.map(function (f) { return [f, f]; })).forEach(function (o) {
      family.appendChild(h('option', { value: o[0] }, o[1]));
    });
    family.value = listState.family;

    function update() {
      listState.query = search.value;
      listState.family = family.value;
      var rows = CIP.catalogue.filter(CIP.records, listState.query, listState.family);
      tbody.textContent = '';
      rows.forEach(function (r) {
        tbody.appendChild(h('tr', null,
          h('td', null, h('a', { href: detailHref(r) }, r.name)),
          h('td', null, r.family),
          h('td', { class: 'num' }, String(r.cartridge.lengths.L3) + ' mm')));
      });
      count.textContent = rows.length + ' cartridges';
      empty.hidden = rows.length !== 0;
    }
    search.addEventListener('input', update);
    family.addEventListener('change', update);

    main.replaceChildren(
      h('h1', { tabindex: '-1' }, 'Cartridges'),
      h('form', { class: 'filters', role: 'search', onsubmit: function (e) { e.preventDefault(); } },
        h('div', { class: 'field' }, h('label', { for: 'search' }, 'Search'), search),
        h('div', { class: 'field' }, h('label', { for: 'family' }, 'Family'), family),
        count),
      h('table', { class: 'list' },
        h('thead', null, h('tr', null,
          h('th', { scope: 'col' }, 'Name'),
          h('th', { scope: 'col' }, 'Family'),
          h('th', { scope: 'col', class: 'num' }, 'Case length L3'))),
        tbody),
      empty);
    update();
  }

  /* ---------- router ---------- */

  function safeDecode(text) {
    try { return decodeURIComponent(text); } catch (e) { return text; }
  }

  function route(event) {
    var hash = location.hash.replace(/^#/, '');
    var m = /^\/cartridge\/([^/]+)$/.exec(hash);
    if (m) CIP.renderDetail(main, safeDecode(m[1]));
    else renderList();
    window.scrollTo(0, 0);
    var heading = main.querySelector('h1');
    if (event && heading) heading.focus({ preventScroll: true }); // announce the new view; not on first load
  }

  window.addEventListener('hashchange', route);
  route(null);
})();
