/* Catalogue: list filter and lookup over the records (CIP.records). Classic script (docs/adr/0001). */
(function (root, factory) {
  var api = factory();
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  else { root.CIP = root.CIP || {}; root.CIP.catalogue = api; }
})(typeof self !== 'undefined' ? self : this, function () {
  var FAMILIES = ['rimless', 'rimmed', 'belted', 'pistol', 'rimfire'];

  /** Lower case, decimal comma to point, single spaces. */
  function normalize(text) {
    return String(text).toLowerCase().replace(/,/g, '.').replace(/\s+/g, ' ').trim();
  }

  function compact(text) { return normalize(text).replace(/ /g, ''); }

  function names(record) {
    return [record.name].concat(record.alternativeNames || []);
  }

  function matchesQuery(record, query) {
    var q = normalize(query);
    if (!q) return true;
    var qc = compact(query);
    return names(record).some(function (n) {
      return normalize(n).indexOf(q) !== -1 || compact(n).indexOf(qc) !== -1;
    });
  }

  /** family '' or 'all' means every family. */
  function filter(records, query, family) {
    return records.filter(function (r) {
      return (!family || family === 'all' || r.family === family) && matchesQuery(r, query);
    });
  }

  function findByKey(records, key) {
    for (var i = 0; i < records.length; i++) if (records[i].key === key) return records[i];
    return null;
  }

  return { FAMILIES: FAMILIES, filter: filter, findByKey: findByKey };
});
