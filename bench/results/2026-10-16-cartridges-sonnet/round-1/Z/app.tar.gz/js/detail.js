/* Detail view: metadata, drawing, tables. Classic script; needs CIP.h, CIP.format, CIP.catalogue. */
(function () {
  'use strict';
  var CIP = window.CIP, h = CIP.h;

  var VALUE_SETS = [['cartridge', 'Cartridge values'], ['chamber', 'Chamber values']];

  function metaList(record) {
    var dl = h('dl', { class: 'meta' });
    CIP.format.meta(record).forEach(function (m) {
      var dd = h('dd', null);
      if (!m.text) dd.appendChild(h('span', { class: 'none' }, m.missing || '\u2014'));
      else {
        dd.appendChild(document.createTextNode(m.text));
        if (m.source) {
          dd.appendChild(document.createTextNode(', source '));
          dd.appendChild(m.url ? h('a', { href: m.url, rel: 'noopener noreferrer' }, m.source) : document.createTextNode(m.source));
        }
        if (m.note) dd.appendChild(h('span', { class: 'note' }, ' (' + m.note + ')'));
      }
      dl.appendChild(h('div', { class: 'meta-row' }, h('dt', null, m.label), dd));
    });
    return dl;
  }

  function sectionTable(section, first) {
    var rows = section.rows.map(function (r) {
      return h('tr', null,
        h('th', { scope: 'row', class: 'sym' }, r.symbol),
        h('td', { class: 'val' }, r.value, r.tolerance ? ' ' : null, r.tolerance ? h('span', { class: 'tol' }, r.tolerance) : null),
        h('td', { class: 'unit' }, r.unit));
    });
    return h('table', { class: 'values' + (first ? ' first' : '') },
      h('caption', null, section.title),
      h('thead', null, h('tr', null,
        h('th', { scope: 'col' }, 'Symbol'), h('th', { scope: 'col' }, 'Value'), h('th', { scope: 'col' }, 'Unit'))),
      h('tbody', null, rows));
  }

  function valuesRegion(record, valueSet, title) {
    var id = 'values-' + valueSet;
    var tables = CIP.format.sections(record, valueSet).map(function (s, i) { return sectionTable(s, i === 0); });
    return h('section', { class: 'value-set', 'aria-labelledby': id },
      h('h2', { id: id }, title), h('div', { class: 'tables' }, tables));
  }

  function notFound(main, key) {
    document.title = 'Not found - Cartridges';
    main.replaceChildren(
      h('h1', { tabindex: '-1' }, 'Not found'),
      h('p', null, 'No cartridge with the address \u201c' + key + '\u201d.'),
      h('p', null, h('a', { href: '#/' }, 'All cartridges')));
  }

  CIP.renderDetail = function renderDetail(main, key) {
    var record = CIP.catalogue.findByKey(CIP.records, key);
    if (!record) return notFound(main, key);
    document.title = record.name + ' - Cartridges';

    var children = [
      h('div', { class: 'toolbar' },
        h('a', { class: 'back', href: '#/' }, 'All cartridges'),
        h('button', { type: 'button', class: 'print-button', onclick: function () { window.print(); } }, 'Print')),
      h('h1', { tabindex: '-1' }, record.name),
      metaList(record)
    ];
    if (CIP.drawing) children.push(CIP.drawing.figure(record));
    VALUE_SETS.forEach(function (s) { children.push(valuesRegion(record, s[0], s[1])); });
    children.push(h('footer', { class: 'source' }, 'Source: C.I.P. TDCC, revised ' + record.revised));
    main.replaceChildren.apply(main, children);
  };
})();
