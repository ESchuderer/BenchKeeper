/* DOM helper: CIP.h(tag, attrs, ...children). Classic script. */
(function () {
  'use strict';
  window.CIP = window.CIP || {};

  /** h('a', {href: '#'}, 'text', child) -> element. Falsy/null attrs and children are skipped; arrays are flattened. */
  window.CIP.h = function h(tag, attrs) {
    var el = document.createElement(tag);
    Object.keys(attrs || {}).forEach(function (k) {
      var v = attrs[k];
      if (v === false || v == null) return;
      if (k === 'class') el.className = v;
      else if (k.slice(0, 2) === 'on') el.addEventListener(k.slice(2), v);
      else el.setAttribute(k, v === true ? '' : v);
    });
    function add(c) {
      if (c == null || c === false) return;
      if (Array.isArray(c)) c.forEach(add);
      else el.appendChild(typeof c === 'string' || typeof c === 'number' ? document.createTextNode(c) : c);
    }
    for (var i = 2; i < arguments.length; i++) add(arguments[i]);
    return el;
  };
})();
