/* Drawing: the model and SVG of the 2D drawing of one cartridge. Classic script (docs/adr/0001).
   build(record) -> { name, rimType, profile, bullet, walls, notes, dimensions, labels, outline, centre, viewBox,
                      scale, fontSize, titleBlock, svg }
   Units: view box and all points are mm (1 user unit = 1 mm); fontSize and `em` are the label font size in mm. */
(function (root, factory) {
  var node = typeof module !== 'undefined' && module.exports;
  var geometry = node ? require('./geometry.js') : root.CIP.geometry;
  var layout = node ? require('./layout.js') : root.CIP.layout;
  var api = factory(geometry, layout, node ? null : root);
  if (node) module.exports = api;
  else { root.CIP = root.CIP || {}; root.CIP.drawing = api; }
})(typeof self !== 'undefined' ? self : this, function (geometry, layout, root) {
  var PRINT_WIDTH_MM = 190;      // A4 portrait with 10 mm margins
  var FONT_MIN = 1.6, FONT_MAX = 4.0, WIDTHS_PER_FONT = 40; // font size = view box width / 40, clamped
  var MARGIN = 1.0;              // em around everything
  var MAX_PRINT_HEIGHT_MM = 118; // tall, narrow drawings get empty side space so the print stays one page
  var TITLE_TEXT_SCALE = 0.85;   // title block text size relative to the label font
  var WIDEST_SCALE = 99.9;       // sizes the title block for the longest scale text

  function clamp(x, lo, hi) { return Math.max(lo, Math.min(hi, x)); }
  function round(x) { return Math.round(x * 1000) / 1000; }
  function esc(s) {
    return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  }
  function pts(arr) { return arr.map(function (p) { return round(p[0]) + ',' + round(p[1]); }).join(' '); }
  function pathD(arr, close) {
    return 'M' + arr.map(function (p) { return round(p[0]) + ' ' + round(p[1]); }).join('L') + (close ? 'Z' : '');
  }
  function seg(s) { return 'M' + round(s[0][0]) + ' ' + round(s[0][1]) + 'L' + round(s[1][0]) + ' ' + round(s[1][1]); }

  /* ---------- title block ---------- */

  function titleLines(record, scaleText) {
    return [
      { text: record.name, bold: true },
      { text: 'C.I.P. table ' + record.tab + ', revised ' + record.revised },
      { text: 'Dimensions in mm' },
      { text: scaleText }
    ];
  }

  function scaleText(scale) { return 'Scale ' + scale.toFixed(1) + ' : 1 (A4 print)'; }

  /** Title block box below the bounds, right-aligned with them (it may stick out to the left). */
  function titleBlock(record, bounds, em) {
    var lines = titleLines(record, scaleText(WIDEST_SCALE)), t = TITLE_TEXT_SCALE * em;
    var inner = Math.max.apply(null, lines.map(function (l) { return layout.textWidth(l.text, t); }));
    var w = inner + 1.2 * t, h = lines.length * 1.5 * t + 0.8 * t;
    return { x: bounds.maxX - w, y: bounds.maxY + 1.0 * em, w: w, h: h, text: t };
  }

  /* ---------- one pass at font size em ---------- */

  function pass(record, g, em) {
    var c = layout.compose(g, em);
    var b = { minX: c.bounds.minX, maxX: c.bounds.maxX, minY: c.bounds.minY, maxY: c.bounds.maxY };
    var tb = titleBlock(record, b, em);
    b.minX = Math.min(b.minX, tb.x);
    var margin = MARGIN * em;
    var view = {
      x: round(b.minX - margin), y: round(b.minY - margin),
      w: round(b.maxX - b.minX + 2 * margin), h: round(tb.y + tb.h - b.minY + 2 * margin)
    };
    return { c: c, view: view, titleBlock: tb, notes: c.notes };
  }

  /** Adds empty space left and right when the A4 print would be taller than the page leaves room for. */
  function widenForPrint(p) {
    var view = p.view, wanted = (view.h * PRINT_WIDTH_MM) / MAX_PRINT_HEIGHT_MM;
    if (wanted <= view.w) return p;
    var extra = wanted - view.w, tb = p.titleBlock;
    return {
      c: p.c, notes: p.notes,
      view: { x: round(view.x - extra / 2), y: view.y, w: round(wanted), h: view.h },
      titleBlock: { x: tb.x + extra / 2, y: tb.y, w: tb.w, h: tb.h, text: tb.text }
    };
  }

  /* ---------- svg ---------- */

  function renderSvg(record, g, p, em, scale, notes) {
    var c = p.c, lw = c.lw, view = p.view, id = 'hatch-' + record.key;
    var sw = clamp(view.w / 380, 0.22, 0.5), thin = sw * 0.55;
    var hs = clamp(view.w / 160, 0.55, 0.9), k = em / 2.4;
    var out = [];
    var open = '<svg xmlns="http://www.w3.org/2000/svg" class="drawing-svg" role="img" aria-label="' + esc(record.name) + ' drawing"' +
      ' viewBox="' + view.x + ' ' + view.y + ' ' + view.w + ' ' + view.h + '" width="' + view.w + 'mm" height="' + view.h + 'mm"' +
      ' font-size="' + round(em) + '" preserveAspectRatio="xMidYMid meet">';
    out.push(open);
    out.push('<title>' + esc(record.name) + ' drawing</title>');
    out.push('<desc>' + esc(record.name) + ', rim type ' + g.rimType + '. Upper half: outside view. Lower half: section, cut walls hatched. 1 user unit = 1 mm.' +
      (notes.length ? ' ' + esc(notes.join(' ')) : '') + '</desc>');
    out.push('<defs><pattern id="' + id + '" patternUnits="userSpaceOnUse" width="' + round(hs) + '" height="' + round(hs) +
      '" patternTransform="rotate(45)"><line class="hatch-line" x1="0" y1="0" x2="0" y2="' + round(hs) + '" stroke-width="' + round(thin) + '"/></pattern></defs>');

    out.push('<g class="art">');
    if (lw.bulletFillUpper) out.push('<polygon class="bullet-fill" points="' + pts(lw.bulletFillUpper) + '"/>');
    if (lw.bulletFillLower) out.push('<polygon class="bullet-fill" points="' + pts(lw.bulletFillLower) + '"/>');
    out.push('<path class="hatch" fill="url(#' + id + ')" d="' + pathD(lw.hatch, true) + '"/>');
    out.push('<g class="outline" fill="none" stroke-width="' + round(sw) + '" stroke-linejoin="round" stroke-linecap="round">');
    lw.polylines.forEach(function (poly) {
      out.push('<path class="' + poly.cls + '" d="' + pathD(poly.points, false) + '"/>');
    });
    out.push('</g>');
    out.push('<path class="centre" fill="none" stroke-width="' + round(thin) + '" stroke-dasharray="' +
      [6, 1.2, 1, 1.2].map(function (n) { return round(n * k); }).join(' ') + '" d="' + seg(lw.centre) + '"/>');
    out.push('</g>');

    out.push('<g class="dims" fill="none" stroke-width="' + round(thin) + '">');
    c.dims.forEach(function (d) {
      out.push('<g class="dim" data-dim="' + d.id + '">');
      d.extensions.forEach(function (s) { out.push('<path class="ext" d="' + seg(s) + '"/>'); });
      if (d.line) out.push('<path class="dim-line" d="' + seg(d.line) + '"/>');
      if (d.tail) out.push('<path class="dim-line" d="' + seg(d.tail) + '"/>');
      if (d.leader) out.push('<path class="dim-line" d="' + seg(d.leader) + '"/>');
      d.arrows.forEach(function (a) { out.push('<polygon class="arrow" stroke="none" points="' + pts(a) + '"/>'); });
      var cx = d.box.x + d.box.w / 2, cy = d.box.y + d.box.h / 2, base = round(cy + 0.34 * em);
      out.push('<text class="dim-label" data-label="' + d.id + '" x="' + round(cx) + '" y="' + base + '" text-anchor="middle" stroke="none"' +
        (d.rotate ? ' transform="rotate(-90 ' + round(cx) + ' ' + round(cy) + ')"' : '') + '>' + esc(d.text) + '</text>');
      out.push('</g>');
    });
    out.push('</g>');

    var tb = p.titleBlock, lines = titleLines(record, scaleText(scale));
    var t = tb.text;
    out.push('<g class="title-block" font-size="' + round(t) + '"><rect x="' + round(tb.x) + '" y="' + round(tb.y) + '" width="' + round(tb.w) + '" height="' + round(tb.h) +
      '" fill="none" stroke-width="' + round(sw * 0.8) + '"/>');
    lines.forEach(function (l, i) {
      out.push('<text class="tb-text' + (l.bold ? ' tb-name' : '') + '" x="' + round(tb.x + 0.6 * t) + '" y="' + round(tb.y + (i + 1) * 1.5 * t) +
        '" stroke="none">' + esc(l.text) + '</text>');
    });
    out.push('</g></svg>');
    return out.join('');
  }

  function unavailableSvg(record, notes) {
    var w = 120, h = 20;
    return '<svg xmlns="http://www.w3.org/2000/svg" class="drawing-svg" role="img" aria-label="' + esc(record.name) + ' drawing" viewBox="0 0 ' + w + ' ' + h +
      '" width="' + w + 'mm" height="' + h + 'mm"><title>' + esc(record.name) + ' drawing</title><text class="tb-text" x="2" y="12" font-size="3.5">' +
      esc(notes.join(' ')) + '</text></svg>';
  }

  /** Model of a drawing that cannot be made; the notes say why. */
  function unavailableModel(record, notes) {
    return { name: record.name, rimType: null, profile: [], bullet: null, walls: null, notes: notes, dimensions: [], labels: [],
             outline: [], centre: [[0, 0], [0, 0]], viewBox: { x: 0, y: 0, w: 120, h: 20 }, scale: PRINT_WIDTH_MM / 120, fontSize: 3.5,
             titleBlock: { x: 0, y: 0, w: 0, h: 0 }, svg: unavailableSvg(record, notes) };
  }

  /* ---------- entry ---------- */

  /** The drawing model of a record (contract: test/unit/drawing-*.test.js). */
  function build(record) {
    var g = geometry.compute(record);
    if (!g.ok) return unavailableModel(record, g.notes);
    var em = 2.4, p;
    try {
      p = pass(record, g, em);
      for (var i = 0; i < 3; i++) { // the font size follows the drawing width; three damped passes settle it
        var next = clamp(p.view.w / WIDTHS_PER_FONT, FONT_MIN, FONT_MAX);
        em = (em + next) / 2;
        p = pass(record, g, em);
      }
    } catch (e) {
      return unavailableModel(record, g.notes.concat('Drawing not possible: ' + e.message + '.'));
    }
    p = widenForPrint(p);
    var notes = g.notes.concat(p.notes);
    var scale = PRINT_WIDTH_MM / p.view.w;
    var c = p.c;
    return {
      name: record.name, rimType: g.rimType, profile: g.profile, bullet: g.bullet, walls: g.walls, notes: notes,
      dimensions: c.dims.map(function (d) {
        return { id: d.id, text: d.text, extensions: d.extensions, line: d.line, leader: d.leader, arrows: d.arrows, tail: d.tail || null };
      }),
      labels: c.dims.map(function (d) { return { id: d.id, text: d.text, box: d.box, rotate: !!d.rotate }; }),
      outline: c.lw.outline, centre: c.lw.centre, viewBox: p.view, scale: scale, fontSize: em, titleBlock: p.titleBlock,
      svg: renderSvg(record, g, p, em, scale, notes)
    };
  }

  /** <figure> for the detail view (browser only). */
  function figure(record) {
    var h = root.CIP.h, m = build(record);
    var fig = h('figure', { class: 'drawing' });
    fig.innerHTML = m.svg;
    var caption = [h('span', { class: 'rim-type' }, 'Rim type: ' + m.rimType + '.')].concat(m.notes.map(function (n) { return h('span', { class: 'note' }, n); }));
    fig.appendChild(h('figcaption', { class: 'drawing-notes' }, caption));
    return fig;
  }

  return { build: build, figure: figure };
});
