/* Format: published-value presentation and the detail view-model. Classic script (docs/adr/0001). */
(function (root, factory) {
  var api = factory();
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  else { root.CIP = root.CIP || {}; root.CIP.format = api; }
})(typeof self !== 'undefined' ? self : this, function () {
  var SYMBOLS = {
    eMin: 'e min', r1Min: 'r1 min', r1Max: 'r1 max', alpha: '\u03b1', alpha1: '\u03b11',
    beta: '\u03b2', delta: '\u03b4', deltaL: 'delta L', L3PlusG: 'L3 + G'
  };
  var ANGLES = { alpha: 1, alpha1: 1, beta: 1, delta: 1, i: 1 };
  var UNITS = { Pmax: 'bar', PK: 'bar', PE: 'bar', EE: 'J', M: 'g', Q: 'mm\u00b2', N: '' };

  /* Sections shared by both value sets: [field name in the record, title, preferred row order] */
  var COLLAR = ['collar', 'Collar', ['H1', 'H2']];
  var JUNCTION_CONE = ['junctionCone', 'Junction cone', ['S', 'alpha', 'r1Min', 'r1Max', 'r2']];
  var POWDER_CHAMBER = ['powderChamber', 'Powder chamber', ['E', 'P1', 'P2']];

  var SECTIONS = {
    cartridge: [
      ['caseHead', 'Case head', ['R1', 'R', 'E', 'E1', 'eMin', 'R3', 'beta', 'delta', 'f']],
      COLLAR,
      JUNCTION_CONE,
      ['lengths', 'Lengths', ['L1', 'L2', 'L3', 'L4', 'L5', 'L6']],
      ['misc', 'Miscellaneous', ['Fe', 'deltaL']],
      POWDER_CHAMBER,
      ['pressures', 'Pressures', ['Pmax', 'PK', 'PE', 'EE', 'M']],
      ['projectile', 'Projectile', ['G1', 'G2', 'L3PlusG']]
    ],
    chamber: [
      ['barrel', 'Barrel', ['F', 'Z']],
      ['breech', 'Breech', ['R1', 'R', 'r', 'R3']],
      COLLAR,
      ['grooves', 'Grooves', ['N', 'Q', 'b', 'u']],
      JUNCTION_CONE,
      ['lengths', 'Lengths', ['L1', 'L2', 'L3']],
      POWDER_CHAMBER,
      ['rifling', 'Rifling', ['G', 'G1', 'alpha1', 'h', 'i', 's']]
    ]
  };

  function isNumber(x) { return typeof x === 'number' && isFinite(x); }

  /** A number as published: decimal point, no thousands separator. */
  function number(n) { return String(n); }

  /** Degrees as a number or {degrees, minutes, seconds}: 40° or 39°59'49". */
  function angle(a) {
    if (isNumber(a)) return number(a) + '\u00b0';
    return number(a.degrees || 0) + '\u00b0' + number(a.minutes || 0) + "'" + number(a.seconds || 0) + '"';
  }

  /** Decimal degrees of an angle value, or null. */
  function degrees(a) {
    if (isNumber(a)) return a;
    if (a && typeof a === 'object') return (a.degrees || 0) + (a.minutes || 0) / 60 + (a.seconds || 0) / 3600;
    return null;
  }

  function symbol(field) { return SYMBOLS[field] || field; }
  function unit(field) {
    if (ANGLES[field]) return '';
    return Object.prototype.hasOwnProperty.call(UNITS, field) ? UNITS[field] : 'mm';
  }
  function value(field, v) { return ANGLES[field] ? angle(v) : number(v); }
  function tolerance(t) { return (t > 0 ? '+' : '') + number(t); }

  function orderedFields(section, preferred) {
    var present = Object.keys(section).filter(function (f) { return !/Tol$/.test(f); });
    var first = preferred.filter(function (f) { return present.indexOf(f) !== -1; });
    return first.concat(present.filter(function (f) { return preferred.indexOf(f) === -1; }));
  }

  function sectionRows(section, preferred) {
    return orderedFields(section, preferred).map(function (f) {
      var tol = section[f + 'Tol'];
      return {
        symbol: symbol(f), value: value(f, section[f]),
        tolerance: isNumber(tol) ? tolerance(tol) : '', unit: unit(f)
      };
    });
  }

  /** Sections of one value set ('cartridge' or 'chamber'), empty sections omitted. */
  function sections(record, valueSet) {
    var data = record[valueSet] || {};
    var known = SECTIONS[valueSet].map(function (s) { return s[0]; });
    var defs = SECTIONS[valueSet].concat(Object.keys(data).filter(function (k) { return known.indexOf(k) === -1; })
      .map(function (k) { return [k, k, []]; }));
    return defs.filter(function (d) { return data[d[0]]; }).map(function (d) {
      return { title: d[1], rows: sectionRows(data[d[0]], d[2]) };
    }).filter(function (s) { return s.rows.length > 0; });
  }

  /** Metadata rows for the detail view; `missing` is shown when the record has no text. */
  function meta(record) {
    var a = record.annotations || {};
    var cap = a.publishedCapacity;
    return [
      { label: 'Alternative names', text: (record.alternativeNames || []).join(', '), missing: '\u2014' },
      { label: 'Family', text: record.family },
      { label: 'Category', text: a.category },
      { label: 'Primer type', text: a.primerType },
      { label: 'C.I.P. table', text: record.tab },
      { label: 'Country', text: record.country },
      { label: 'Published', text: record.published },
      { label: 'Revised', text: record.revised },
      { label: 'Pressure method', text: record.pressureMethod },
      cap ? { label: 'Water capacity', text: number(cap.grH2O) + ' gr H2O', source: cap.source, url: cap.url, note: cap.note }
          : { label: 'Water capacity', text: '', missing: 'not published' }
    ];
  }

  return {
    number: number, angle: angle, degrees: degrees, sections: sections, meta: meta
  };
});
