/* Geometry: outer half-profile, bullet and section walls of one cartridge (brief rules 1-9).
   Points are [r, z]: r radius, z along the axis from the head face. Pure; no DOM. Classic script. */
(function (root, factory) {
  var format = (typeof module !== 'undefined' && module.exports) ? require('./format.js') : root.CIP.format;
  var api = factory(format);
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  else { root.CIP = root.CIP || {}; root.CIP.geometry = api; }
})(typeof self !== 'undefined' ? self : this, function (format) {
  var DEG = Math.PI / 180;
  var EPS = 1e-9;
  var ARC_STEP = 5 * DEG;
  var HEEL_TOLERANCE = 0.015;

  var SMALL_POCKET = { diameter: 4.45, depth: 3.04 };
  var LARGE_POCKET = { diameter: 5.33, depth: 3.04 };
  var LARGE_RIFLE_POCKET = { diameter: 5.33, depth: 3.3 };
  var PRIMERS = {
    sp: SMALL_POCKET, spm: SMALL_POCKET, sr: SMALL_POCKET,
    lp: LARGE_POCKET, lpm: LARGE_POCKET,
    lr: LARGE_RIFLE_POCKET, lrm: LARGE_RIFLE_POCKET
  };

  /* seating depth factor of G1, cylinder fraction k, meplat factor of G1 */
  var BULLETS = {
    pointy: { seat: function () { return 1.0; }, k: function () { return 0.40; } },
    rounded: { seat: function (p) { return p ? 0.4 : 0.8; }, k: function (p) { return p ? 0.65 : 0.55; }, meplat: 0.15 },
    flat: { seat: function (p) { return p ? 0.4 : 0.8; }, k: function (p) { return p ? 0.70 : 0.60; }, meplat: 0.55 },
    semi_wadcutter: { seat: function () { return 0.6; }, k: function () { return 0.78; }, meplat: 0.6 }
  };

  function num(x) { return typeof x === 'number' && isFinite(x) ? x : null; }

  /* ---------- small vector helpers on [r, z] ---------- */
  function sub(a, b) { return [a[0] - b[0], a[1] - b[1]]; }
  function add(a, b) { return [a[0] + b[0], a[1] + b[1]]; }
  function mul(a, k) { return [a[0] * k, a[1] * k]; }
  function len(a) { return Math.hypot(a[0], a[1]); }
  function direction(a) { var l = len(a); return [a[0] / l, a[1] / l]; }

  /** Appends p unless it repeats the previous point. */
  function push(pts, r, z) {
    var last = pts[pts.length - 1];
    if (last && Math.abs(last[0] - r) < EPS && Math.abs(last[1] - z) < EPS) return;
    pts.push([r, z]);
  }

  /** Radius of the z-monotonic polyline at z (last matching segment wins), or null outside it. */
  function radiusAt(pts, z) {
    var found = null;
    for (var i = 0; i + 1 < pts.length; i++) {
      var a = pts[i], b = pts[i + 1];
      if (a[1] <= z + EPS && z <= b[1] + EPS && b[1] > a[1]) found = a[0] + ((z - a[1]) / (b[1] - a[1])) * (b[0] - a[0]);
    }
    return found;
  }

  /* ---------- fillet ---------- */

  function corner(p0, p1, p2) {
    var d1 = direction(sub(p0, p1)), d2 = direction(sub(p2, p1));
    var c = Math.max(-1, Math.min(1, d1[0] * d2[0] + d1[1] * d2[1]));
    return { d1: d1, d2: d2, theta: Math.acos(c) };
  }

  function tangentLength(c, radius) {
    return c.theta > Math.PI - 1e-6 ? 0 : radius / Math.tan(c.theta / 2);
  }

  /** Points of the fillet of `radius` at p1 between segments p0-p1 and p1-p2 (tangent point to tangent point). */
  function filletPoints(p0, p1, p2, radius) {
    var c = corner(p0, p1, p2);
    var t = tangentLength(c, radius);
    if (t === 0) return [p1];
    var t1 = add(p1, mul(c.d1, t)), t2 = add(p1, mul(c.d2, t));
    var centre = add(p1, mul(direction(add(c.d1, c.d2)), radius / Math.sin(c.theta / 2)));
    var a1 = Math.atan2(t1[1] - centre[1], t1[0] - centre[0]);
    var a2 = Math.atan2(t2[1] - centre[1], t2[0] - centre[0]);
    var d = a2 - a1;
    while (d > Math.PI) d -= 2 * Math.PI;
    while (d < -Math.PI) d += 2 * Math.PI;
    var n = Math.max(2, Math.ceil(Math.abs(d) / ARC_STEP));
    var pts = [];
    for (var i = 0; i <= n; i++) {
      var a = a1 + (d * i) / n;
      pts.push([centre[0] + radius * Math.cos(a), centre[1] + radius * Math.sin(a)]);
    }
    return pts;
  }

  /** Largest scale (<= 1) so both fillets of the shoulder fit on their segments. */
  function filletScale(body, A, B, C, r1, r2) {
    var tA = r1 ? tangentLength(corner(body, A, B), r1) : 0;
    var tB = r2 ? tangentLength(corner(A, B, C), r2) : 0;
    var k = 1;
    if (tA + tB > 0) k = Math.min(k, (0.98 * len(sub(B, A))) / (tA + tB));
    if (tA > 0) k = Math.min(k, (0.9 * len(sub(A, body))) / tA);
    if (tB > 0) k = Math.min(k, (0.9 * len(sub(C, B))) / tB);
    return k;
  }

  /* ---------- values ---------- */

  function readValues(rec) {
    var c = rec.cartridge || {}, head = c.caseHead || {}, col = c.collar || {}, jc = c.junctionCone || {};
    var lengths = c.lengths || {}, pc = c.powderChamber || {}, pr = c.projectile || {}, an = rec.annotations || {};
    return {
      R1: num(head.R1), R: num(head.R), E: num(head.E), E1: num(head.E1), eMin: num(head.eMin), R3: num(head.R3),
      f: num(head.f), beta: format.degrees(head.beta), delta: format.degrees(head.delta),
      H1: num(col.H1), H2: num(col.H2),
      alpha: format.degrees(jc.alpha), alphaRaw: jc.alpha, r1Min: num(jc.r1Min), r2: num(jc.r2),
      L1: num(lengths.L1), L2: num(lengths.L2), L3: num(lengths.L3), L6: num(lengths.L6),
      P1: num(pc.P1), P2: num(pc.P2), G1: num(pr.G1),
      family: rec.family, category: an.category, primerType: an.primerType, shape: an.defaultBulletShape
    };
  }

  /** Rule 1. */
  function rimType(v) {
    if (v.family === 'belted') return 'belted';
    if (v.family === 'rimfire') return 'rimfire';
    var ratio = v.R1 / v.P1;
    if (ratio >= 1.05) return 'rimmed';
    if (ratio < 0.98) return 'rebated';
    return 'rimless';
  }

  /* ---------- outer half-profile (rules 2-6) ---------- */

  function headProfile(v, type, pts) {
    var rim = v.R1 / 2;
    push(pts, 0, 0);
    if (type === 'rimfire') {
      var rho = Math.min(v.R / 2, (v.R1 - v.P1) / 2);
      if (rho > EPS) {
        var cr = rim - rho, cz = v.R / 2;
        push(pts, cr, 0);
        var n = Math.ceil(Math.PI / ARC_STEP);
        for (var i = 0; i <= n; i++) {
          var a = -Math.PI / 2 + (Math.PI * i) / n;
          push(pts, cr + rho * Math.cos(a), cz + rho * Math.sin(a));
        }
        push(pts, cr, v.R);
        return { chamfer: false };
      }
    }
    var chamfer = type !== 'rimfire' && v.beta != null && v.f != null && v.beta < 90;
    if (chamfer) {
      push(pts, rim - Math.min(v.f * Math.tan(v.beta * DEG), v.R1 / 4), 0);
      push(pts, rim, v.f);
    } else push(pts, rim, 0);
    push(pts, rim, v.R);
    return { chamfer: chamfer };
  }

  /** Groove, belt or step-in. Returns the body start point and what was drawn. */
  function grooveProfile(v, type, pts, notes) {
    var rim = v.R1 / 2, body = v.P1 / 2;
    var hasE = v.E != null, hasE1 = v.E1 != null;
    var out = { groove: false, belt: false, beltRampEnd: null, bodyStartZ: v.R };
    if (hasE && hasE1) {
      out.groove = true;
      push(pts, v.E1 / 2, v.R);
      var floorEnd = v.R;
      if (v.eMin != null) { floorEnd = v.R + v.eMin; push(pts, v.E1 / 2, floorEnd); }
      else notes.push('Extractor groove floor not drawn: e min is not published.');
      var beltOk = type === 'belted' && v.delta != null && v.R3 != null && v.R3 / 2 > v.E1 / 2 && v.delta > 0;
      if (type === 'belted' && !beltOk) {
        var missing = [];
        if (v.delta == null) missing.push('\u03b4');
        if (v.R3 == null) missing.push('R3');
        notes.push('Belt not drawn: ' + (missing.length ? missing.join(', ') + ' not published.' : 'R3 is not larger than E1.'));
      }
      if (beltOk) {
        var belt = v.R3 / 2;
        var zRamp = Math.min(floorEnd + (belt - v.E1 / 2) / Math.tan(v.delta * DEG), v.E);
        var rRamp = v.E1 / 2 + (zRamp - floorEnd) * Math.tan(v.delta * DEG);
        push(pts, rRamp, zRamp);
        push(pts, belt, v.E);
        out.belt = true;
        out.beltRampEnd = zRamp;
      }
      push(pts, body, v.E);
      out.bodyStartZ = v.E;
    } else {
      if (hasE !== hasE1) notes.push('Extractor groove not drawn: ' + (hasE ? 'E1' : 'E') + ' is not published.');
      if (type === 'belted') notes.push('Belt not drawn: ' + [hasE ? null : 'E', hasE1 ? null : 'E1'].filter(Boolean).join(', ') + ' not published.');
      push(pts, body, v.R);
    }
    return out;
  }

  function bodyProfile(v, pts, notes, bodyStartZ) {
    var start = [v.P1 / 2, bodyStartZ];
    var shoulderValues = { '\u03b1': v.alpha, L1: v.L1, L2: v.L2 };
    var absent = Object.keys(shoulderValues).filter(function (k) { return shoulderValues[k] == null; });
    var complete = absent.length === 0;
    var missing = [];
    if (absent.length > 0 && absent.length < 3) notes.push('Shoulder not drawn: ' + absent.join(', ') + ' not published; case drawn straight.');
    if (complete) {
      if (v.P2 == null) missing.push('P2');
      if (v.H1 == null) missing.push('H1');
    }
    if (complete && missing.length === 0) {
      var A = [v.P2 / 2, v.L1], B = [v.H1 / 2, v.L2], C = [v.H2 / 2, v.L3];
      var k = filletScale(start, A, B, C, v.r1Min || 0, v.r2 || 0);
      var aPts = v.r1Min ? filletPoints(start, A, B, v.r1Min * k) : [A];
      var bPts = v.r2 ? filletPoints(A, B, C, v.r2 * k) : [B];
      aPts.concat(bPts).forEach(function (p) { push(pts, p[0], p[1]); });
      push(pts, C[0], C[1]);
      return { bottleneck: true, A: A, B: B };
    }
    if (complete) notes.push('Shoulder not drawn: ' + missing.join(', ') + ' not published; case drawn straight.');
    push(pts, v.H2 / 2, v.L3);
    return { bottleneck: false };
  }

  /* ---------- bullet (rule 7) ---------- */

  function samples(n, fn) {
    var out = [];
    for (var i = 1; i <= n; i++) out.push(fn(i / n));
    return out;
  }

  /** Shank [r, z] points from the base at radius `rad` to the meplat corner; also meplat and ogive radius. */
  function shank(shape, rad, zb, zc, tip) {
    var spec = BULLETS[shape];
    var n = tip - zc;
    var m, pts = [[rad, zb], [rad, zc]], rho = null, N = 24;
    if (shape === 'pointy') {
      m = Math.max(0.08 * (2 * rad), 1.27);
      var a = rad - m / 2;
      rho = (a * a + n * n) / (2 * a);
      var centre = rad - rho, phiEnd = Math.atan2(n, m / 2 - centre);
      samples(N, function (t) {
        var phi = phiEnd * t;
        return [centre + rho * Math.cos(phi), zc + rho * Math.sin(phi)];
      }).forEach(function (p) { pts.push(p); });
      pts[pts.length - 1] = [m / 2, tip];
    } else if (shape === 'rounded') {
      m = spec.meplat * 2 * rad;
      var ra = rad - m / 2;
      samples(N, function (t) {
        var th = (Math.PI / 2) * t;
        return [m / 2 + ra * Math.cos(th), zc + n * Math.sin(th)];
      }).forEach(function (p) { pts.push(p); });
      pts[pts.length - 1] = [m / 2, tip];
    } else {
      m = spec.meplat * 2 * rad;
      pts.push([m / 2, tip]);
    }
    return { points: pts, meplat: m, ogiveRadius: rho };
  }

  /** Part of a z-monotonic polyline at z >= z0, starting exactly at z0. */
  function clipFrom(pts, z0) {
    var out = [];
    for (var i = 0; i < pts.length; i++) {
      var p = pts[i];
      if (p[1] >= z0 - EPS) {
        if (!out.length && i > 0 && pts[i - 1][1] < z0 - EPS) {
          var q = pts[i - 1], t = (z0 - q[1]) / (p[1] - q[1]);
          out.push([q[0] + t * (p[0] - q[0]), z0]);
        }
        out.push([p[0], Math.max(p[1], z0)]);
      }
    }
    return out;
  }

  function bulletGeometry(v, walls, notes) {
    var missing = [];
    if (v.G1 == null) missing.push('G1');
    if (v.L6 == null) missing.push('L6');
    if (!v.shape || !BULLETS[v.shape]) missing.push('defaultBulletShape');
    if (missing.length) {
      notes.push('Bullet not drawn: ' + missing.join(', ') + ' not published.');
      return null;
    }
    var spec = BULLETS[v.shape], pistol = v.category === 'pistol';
    var s = spec.seat(pistol) * v.G1;
    var zb = v.L3 - s, Lb = v.L6 - zb, zc = zb + spec.k(pistol) * Lb;
    var heeled = v.H2 - v.G1 <= HEEL_TOLERANCE;
    var rad = heeled ? v.H2 / 2 : v.G1 / 2;
    var sh = shank(v.shape, rad, zb, zc, v.L6);
    var exposed = clipFrom(sh.points, v.L3);
    exposed.push([0, v.L6]);
    var seatedRadius = heeled ? v.H2 / 2 - walls.tb : rad;
    var section = [[0, zb]];
    if (heeled) { section.push([seatedRadius, zb], [seatedRadius, v.L3]); section = section.concat(exposed); }
    else section = section.concat(sh.points, [[0, v.L6]]);
    return {
      shape: v.shape, heeled: heeled, seatingDepth: s, baseZ: zb, length: Lb, cylinderEnd: zc,
      meplat: sh.meplat, ogiveRadius: sh.ogiveRadius, radius: rad, seatedRadius: seatedRadius,
      exposed: exposed, section: section
    };
  }

  /* ---------- walls and head (rule 8) ---------- */

  function wallThickness(v) {
    var tn = v.G1 != null ? Math.max(0, (v.H2 - v.G1) / 2) : null;
    var cap = 0.35 * v.P1 / 2;
    var tb = Math.min(Math.max(tn != null ? 1.3 * tn : 0, 0.6), cap);
    return { tn: tn, tb: tb };
  }

  function pocketFor(v, type, notes) {
    if (type === 'rimfire' || v.primerType === 'rimfire') return null;
    var p = PRIMERS[v.primerType];
    if (!p) { notes.push('Primer pocket not drawn: primer type is not published.'); return null; }
    return { diameter: p.diameter, depth: p.depth };
  }

  function solidHeadLength(v, thickness, pocket, groove) {
    var c = [2.5, 0.25 * v.P1 / 2];
    if (pocket) c.push(pocket.depth + 1.5);
    if (groove.belt) c.push(groove.beltRampEnd + thickness.tb);
    else if (groove.groove) c.push(v.E + thickness.tb);
    return Math.max.apply(null, c);
  }

  /** Inner line from z = w to the mouth: outer body radius minus the wall at each z. */
  function innerProfile(v, profile, bodyIndex, bottleneck, bullet, thickness, w) {
    var bodyPts = profile.slice(bodyIndex);
    var zs = bodyPts[0][1];
    function outer(z) { return z <= zs ? bodyPts[0][0] : radiusAt(bodyPts, z); }
    var tb = thickness.tb, tn = thickness.tn, heeled = bullet && bullet.heeled;
    var blend = null; // [z0, z1]: wall tb at z0 to tn at z1
    if (tn != null && !heeled) {
      if (bottleneck) blend = [v.L1, v.L2];
      else if (bullet) blend = [w, bullet.baseZ];
    }
    function wall(z) {
      if (!blend) return tb;
      if (z <= blend[0]) return tb;
      if (z >= blend[1]) return tn;
      return tb + ((tn - tb) * (z - blend[0])) / (blend[1] - blend[0]);
    }
    var zs2 = [w];
    bodyPts.forEach(function (p) { if (p[1] > w + EPS) zs2.push(p[1]); });
    if (blend) blend.forEach(function (z) { if (z > w + EPS && z < v.L3 - EPS) zs2.push(z); });
    zs2.sort(function (a, b) { return a - b; });
    var inner = [];
    zs2.forEach(function (z) {
      if (inner.length && z - inner[inner.length - 1][1] < EPS) return;
      inner.push([outer(z) - wall(z), z]);
    });
    return inner;
  }

  /* ---------- entry ---------- */

  /** All geometry of a record: { ok, rimType, profile, bodyIndex, bottleneck, groove, bullet, walls, notes, values }. */
  function compute(rec) {
    var v = readValues(rec), notes = [];
    var core = ['L3', 'R1', 'P1', 'R', 'H2'].filter(function (k) { return v[k] == null; });
    if (core.length) {
      notes.push('Drawing not possible: ' + core.join(', ') + ' not published.');
      return { ok: false, values: v, notes: notes };
    }
    var type = rimType(v);
    var profile = [];
    var head = headProfile(v, type, profile);
    var groove = grooveProfile(v, type, profile, notes);
    var bodyIndex = profile.length - 1;
    var body = bodyProfile(v, profile, notes, groove.bodyStartZ);
    var thickness = wallThickness(v);
    if (v.G1 == null) notes.push('Neck wall tn not computed: G1 is not published; wall drawn at tb.');
    var pocket = pocketFor(v, type, notes);
    var w = solidHeadLength(v, thickness, pocket, groove);
    var bullet = bulletGeometry(v, thickness, notes);
    var inner = innerProfile(v, profile, bodyIndex, body.bottleneck, bullet, thickness, w);
    return {
      ok: true, values: v, rimType: type, profile: profile, bodyIndex: bodyIndex,
      chamfer: head.chamfer, groove: groove, bottleneck: body.bottleneck, shoulder: body.bottleneck ? { A: body.A, B: body.B } : null,
      bullet: bullet,
      walls: { tn: thickness.tn, tb: thickness.tb, head: w, pocket: pocket, inner: inner },
      notes: notes
    };
  }

  return { compute: compute };
});
