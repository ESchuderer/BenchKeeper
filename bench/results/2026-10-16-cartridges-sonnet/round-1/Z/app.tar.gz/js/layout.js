/* Layout: linework, dimension lines and collision-free labels of a drawing.
   SVG coordinates: x = z (mm), y = -r above the axis (outside view), +r below it (section). Pure. Classic script. */
(function (root, factory) {
  var node = typeof module !== 'undefined' && module.exports;
  var format = node ? require('./format.js') : root.CIP.format;
  var api = factory(format);
  if (node) module.exports = api;
  else { root.CIP = root.CIP || {}; root.CIP.layout = api; }
})(typeof self !== 'undefined' ? self : this, function (format) {
  var CHAR_WIDTH = 0.62;   // monospace advance in em, with margin (real fonts: 0.6)
  var LABEL_PAD = 0.5;     // em added to the text width
  var LABEL_HEIGHT = 1.15; // em
  var SLOT = 2.2;          // em between parallel dimension lines
  var FIRST_SLOT = 1.8;    // em from the part to the first dimension line
  var LABEL_GAP = 0.45;    // em between a dimension line and its label
  var EXT_START = 0.25;    // em gap between the part and an extension line
  var EXT_OVERSHOOT = 0.1; // em an extension line runs past its dimension line

  /* ---------- geometry predicates ---------- */

  /** Does segment s = [[x1,y1],[x2,y2]] touch box b = {x,y,w,h} (grown by pad)? */
  function segmentHitsBox(s, b, pad) {
    pad = pad || 0;
    var x1 = s[0][0], y1 = s[0][1], dx = s[1][0] - x1, dy = s[1][1] - y1;
    var t0 = 0, t1 = 1;
    function clip(p, q) {
      if (p === 0) return q >= 0;
      var r = q / p;
      if (p < 0) { if (r > t1) return false; if (r > t0) t0 = r; }
      else { if (r < t0) return false; if (r < t1) t1 = r; }
      return true;
    }
    return clip(-dx, x1 - (b.x - pad)) && clip(dx, b.x + b.w + pad - x1) &&
           clip(-dy, y1 - (b.y - pad)) && clip(dy, b.y + b.h + pad - y1);
  }

  function boxesOverlap(a, b, pad) {
    pad = pad || 0;
    return a.x < b.x + b.w + pad && b.x < a.x + a.w + pad && a.y < b.y + b.h + pad && b.y < a.y + a.h + pad;
  }

  function polylineSegments(pts) {
    var out = [];
    for (var i = 0; i + 1 < pts.length; i++) out.push([pts[i], pts[i + 1]]);
    return out;
  }

  /** [r, z] points to SVG points; sign -1 above the axis, +1 below. */
  function toSvg(pts, sign) { return pts.map(function (p) { return [p[1], sign * p[0]]; }); }

  /* ---------- linework ---------- */

  /** Everything drawn of the part itself: polylines (class 'line' or 'inner'), hatch and bullet fills, centre line. */
  function linework(g, em) {
    var v = g.values, p = g.profile, inner = g.walls.inner, bullet = g.bullet, pocket = g.walls.pocket;
    var mouthOuter = p[p.length - 1][0], mouthInner = inner[inner.length - 1][0];
    var polylines = [];
    function line(points) { polylines.push({ cls: 'line', points: points }); }

    // outside view, above the axis
    line(toSvg(p, -1));
    var bulletUpper = null, bulletLower = null, bulletFillUpper = null;
    if (bullet) {
      var r0 = bullet.exposed[0][0];
      if (mouthOuter - r0 > 1e-9) line([[v.L3, -mouthOuter], [v.L3, -r0]]);
      bulletUpper = toSvg(bullet.exposed, -1);
      bulletFillUpper = [[v.L3, 0]].concat(bulletUpper); // closes along the axis
      line(bulletUpper);
      bulletLower = toSvg(bullet.section, 1);
    } else line([[v.L3, -mouthOuter], [v.L3, -mouthInner]]);

    // section, below the axis: outer wall (starting at the pocket edge), mouth face, inner wall, head, pocket, bullet
    var lowerOuter = p.slice();
    if (pocket && pocket.diameter / 2 < p[1][0]) lowerOuter[0] = [pocket.diameter / 2, 0];
    var innerSvg = toSvg(inner, 1);
    line(toSvg(lowerOuter, 1));
    line([[v.L3, mouthOuter], [v.L3, mouthInner]]);
    polylines.push({ cls: 'inner', points: innerSvg });
    line([[g.walls.head, inner[0][0]], [g.walls.head, 0]]);
    if (pocket) line([[0, pocket.diameter / 2], [pocket.depth, pocket.diameter / 2], [pocket.depth, 0]]);
    if (bulletLower) line(bulletLower);

    var zEnd = bullet ? v.L6 : v.L3;
    var centre = [[-0.9 * em, 0], [zEnd + 0.9 * em, 0]];

    // hatched section of the case: outer wall, mouth face, inner wall back to the head, pocket notch
    var hatch = toSvg(lowerOuter, 1).concat([[v.L3, mouthInner]], innerSvg.slice().reverse(), [[g.walls.head, 0]]);
    if (pocket) hatch.push([pocket.depth, 0], [pocket.depth, pocket.diameter / 2]);

    var outline = [];
    polylines.forEach(function (poly) { outline = outline.concat(polylineSegments(poly.points)); });

    var rMax = Math.max.apply(null, p.map(function (q) { return q[0]; }).concat(bullet ? bullet.exposed.map(function (q) { return q[0]; }) : [0]));
    return {
      polylines: polylines, centre: centre, hatch: hatch, outline: outline, rMax: rMax,
      bulletFillUpper: bulletFillUpper, bulletFillLower: bulletLower, zEnd: zEnd
    };
  }

  /* ---------- dimension building ---------- */

  function arrowhead(tip, dir, em) {
    var len = 0.9 * em, half = 0.25 * em;
    var b = [tip[0] - dir[0] * len, tip[1] - dir[1] * len], n = [-dir[1], dir[0]];
    return [tip, [b[0] + n[0] * half, b[1] + n[1] * half], [b[0] - n[0] * half, b[1] - n[1] * half]];
  }

  /** Dimension line p1-p2 with arrowheads inside, or outside (with tails) when the span is short. */
  function dimensionLine(p1, p2, em) {
    var dx = p2[0] - p1[0], dy = p2[1] - p1[1], span = Math.hypot(dx, dy);
    var d = [dx / span, dy / span], A = 0.9 * em;
    if (span >= 2.4 * A) {
      return { line: [p1, p2], arrows: [arrowhead(p1, [-d[0], -d[1]], em), arrowhead(p2, d, em)] };
    }
    var tail = A + 0.7 * em;
    return {
      line: [[p1[0] - d[0] * tail, p1[1] - d[1] * tail], [p2[0] + d[0] * tail, p2[1] + d[1] * tail]],
      arrows: [arrowhead(p1, d, em), arrowhead(p2, [-d[0], -d[1]], em)]
    };
  }

  function textWidth(text, em) { return text.length * CHAR_WIDTH * em + LABEL_PAD * em; }

  /** Axial dimension z1..z2 on a row above (top) or below (bottom) the part. */
  function axialDimension(spec, ctx) {
    var em = ctx.em, sgn = spec.side === 'top' ? -1 : 1;
    var y = sgn * (ctx.lw.rMax + FIRST_SLOT * em + spec.row * SLOT * em);
    var ext = [spec.z1, spec.z2].map(function (z, i) {
      return [[z, spec.anchors[i] + sgn * EXT_START * em], [z, y + sgn * EXT_OVERSHOOT * em]];
    });
    var dl = dimensionLine([spec.z1, y], [spec.z2, y], em);
    return {
      id: spec.id, text: spec.text, kind: 'axial', extensions: ext, line: dl.line, arrows: dl.arrows,
      leader: null, cy: y + sgn * (LABEL_GAP + LABEL_HEIGHT / 2) * em, cx: (spec.z1 + spec.z2) / 2, sgn: sgn,
      span: spec.z2 - spec.z1
    };
  }

  /** Diameter dimension across the axis at x, on the left or right of the part. */
  function diameterDimension(spec, ctx) {
    var em = ctx.em, left = spec.side === 'left';
    var x = left ? -(FIRST_SLOT + spec.row * SLOT) * em : ctx.lw.zEnd + (FIRST_SLOT + spec.row * SLOT) * em;
    var dir = left ? -1 : 1;
    var ext = [-spec.r, spec.r].map(function (y) {
      return [[spec.z + dir * EXT_START * em, y], [x + dir * EXT_OVERSHOOT * em, y]];
    });
    var dl = dimensionLine([x, -spec.r], [x, spec.r], em);
    return {
      id: spec.id, text: spec.text, kind: 'diameter', extensions: ext, line: dl.line, arrows: dl.arrows,
      leader: null, x: x, r: spec.r, dir: dir, rotate: true
    };
  }

  /* ---------- label placement ---------- */

  function Placer(obstacles, em) {
    this.obstacles = obstacles.slice();
    this.boxes = [];
    this.em = em;
  }
  Placer.prototype.free = function (box) {
    var pad = 0.15 * this.em, i;
    for (i = 0; i < this.obstacles.length; i++) if (segmentHitsBox(this.obstacles[i], box, pad)) return false;
    for (i = 0; i < this.boxes.length; i++) if (boxesOverlap(this.boxes[i], box, pad)) return false;
    return true;
  };
  Placer.prototype.segmentFree = function (seg) {
    for (var i = 0; i < this.boxes.length; i++) if (segmentHitsBox(seg, this.boxes[i], 0.1 * this.em)) return false;
    return true;
  };
  Placer.prototype.take = function (box, segs) {
    this.boxes.push(box);
    (segs || []).forEach(function (s) { this.obstacles.push(s); }, this);
  };

  function dimensionObstacles(d) {
    var segs = d.extensions.concat([d.line]);
    if (d.leader) segs.push(d.leader);
    d.arrows.forEach(function (a) { segs = segs.concat(polylineSegments(a.concat([a[0]]))); });
    return segs;
  }

  /** Candidate offsets 0, +s, -s, +2s, -2s ... up to limit. */
  function offsets(step, limit) {
    var out = [0];
    for (var o = step; o <= limit + 1e-9; o += step) out.push(o, -o);
    return out;
  }

  function placeAxialLabel(d, placer, em) {
    var w = textWidth(d.text, em), h = LABEL_HEIGHT * em;
    var limit = d.span / 2 + w;
    var cand = offsets(0.5 * em, limit);
    for (var i = 0; i < cand.length; i++) {
      var box = { x: d.cx + cand[i] - w / 2, y: d.cy - h / 2, w: w, h: h };
      if (placer.free(box)) return box;
    }
    return null;
  }

  /** Rotated label beside the vertical line: centred on it, or on a tail beyond either end. */
  function placeDiameterLabel(d, placer, em) {
    var w = textWidth(d.text, em), h = LABEL_HEIGHT * em;
    var cx = d.x + d.dir * (LABEL_GAP + LABEL_HEIGHT / 2) * em;
    var tries = [{ cy: 0, tail: null }];
    for (var e = 0; e <= 24; e += 0.5) {
      var off = d.r + 0.5 * em + e * em + w / 2;
      tries.push({ cy: -off, tail: [[d.x, -d.r], [d.x, -off - w / 2]] }, { cy: off, tail: [[d.x, d.r], [d.x, off + w / 2]] });
    }
    for (var i = 0; i < tries.length; i++) {
      var t = tries[i], box = { x: cx - h / 2, y: t.cy - w / 2, w: h, h: w };
      if (placer.free(box) && (!t.tail || placer.segmentFree(t.tail))) {
        if (t.tail) d.tail = t.tail;
        return box;
      }
    }
    return null;
  }

  /** Leader from the middle of the shoulder outward, label at its end. */
  function placeAngle(spec, placer, em) {
    var A = spec.A, B = spec.B; // svg points on the shoulder (above the axis)
    var M = [(A[0] + B[0]) / 2, (A[1] + B[1]) / 2];
    var tx = B[0] - A[0], ty = B[1] - A[1], tl = Math.hypot(tx, ty);
    var n = [ty / tl, -tx / tl];
    if (n[1] > 0) n = [-n[0], -n[1]];
    var w = textWidth(spec.text, em), h = LABEL_HEIGHT * em;
    for (var dist = 2; dist <= 40; dist += 0.5) {
      for (var side = 1; side >= -1; side -= 2) {
        var E = [M[0] + n[0] * dist * em, M[1] + n[1] * dist * em];
        var box = { x: side > 0 ? E[0] + 0.2 * em : E[0] - 0.2 * em - w, y: E[1] - h + 0.1 * em, w: w, h: h };
        var leader = [M, E];
        if (placer.free(box) && placer.segmentFree(leader)) {
          return { box: box, leader: leader, arrows: [arrowhead(M, [-n[0], -n[1]], em)] };
        }
      }
    }
    return null;
  }

  /* ---------- composition ---------- */

  /** Sorts specs by key and numbers them 0.. in s.row (row 0 is nearest the part). */
  function assignRows(specs, key) {
    specs.sort(function (a, b) { return key(a) - key(b); }).forEach(function (spec, i) { spec.row = i; });
  }

  /** Dimension specs in placement order from the geometry. */
  function dimensionSpecs(g, lw, em, notes) {
    var v = g.values, f = format.number, b = g.bullet;
    var rim = v.R1 / 2;
    var headTop = g.profile[1][0]; // radius where the head face meets the chamfer
    var top = [], bottom = [], right = [], left = [];
    var label = function (sym, val) { return sym + ' ' + f(val); };

    bottom.push({ id: 'L3', text: label('L3', v.L3), z1: 0, z2: v.L3, side: 'bottom', anchors: [headTop, v.H2 / 2] });
    if (b) bottom.push({ id: 'L6', text: label('L6', v.L6), z1: 0, z2: v.L6, side: 'bottom', anchors: [headTop, b.meplat / 2] });
    top.push({ id: 'R', text: label('R', v.R), z1: 0, z2: v.R, side: 'top', anchors: [-headTop, -rim] });
    if (g.shoulder) {
      top.push({ id: 'L1', text: label('L1', v.L1), z1: 0, z2: v.L1, side: 'top', anchors: [-headTop, -v.P2 / 2] });
      top.push({ id: 'L2', text: label('L2', v.L2), z1: 0, z2: v.L2, side: 'top', anchors: [-headTop, -v.H1 / 2] });
    }
    var chamferZ = g.chamfer ? v.f : 0;
    left.push({ id: 'R1', text: label('R1', v.R1), r: rim, z: chamferZ, side: 'left', order: 2 });
    if (g.groove.groove) left.push({ id: 'E1', text: label('E1', v.E1), r: v.E1 / 2, z: v.R, side: 'left', order: 1 });

    right.push({ id: 'P1', text: label('P1', v.P1), r: v.P1 / 2, z: g.groove.bodyStartZ, side: 'right' });
    right.push({ id: 'H2', text: label('H2', v.H2), r: v.H2 / 2, z: v.L3, side: 'right' });
    if (b && b.cylinderEnd >= v.L3) right.push({ id: 'G1', text: label('G1', v.G1), r: v.G1 / 2, z: b.cylinderEnd, side: 'right' });
    else if (b) notes.push('G1 dimension not drawn: the bullet shank ends inside the case.');
    if (g.shoulder) {
      right.push({ id: 'P2', text: label('P2', v.P2), r: v.P2 / 2, z: v.L1, side: 'right' });
      right.push({ id: 'H1', text: label('H1', v.H1), r: v.H1 / 2, z: v.L2, side: 'right' });
    }
    // nearest row to the smallest: diameters ascending, then axial spans ascending
    assignRows(right, function (s) { return s.r; });
    assignRows(left, function (s) { return s.order; });
    assignRows(top, function (s) { return s.z2; });
    assignRows(bottom, function (s) { return s.z2; });
    return { top: top, bottom: bottom, right: right, left: left };
  }

  /** The complete layout at font size em (mm): linework, dimensions with label boxes, bounds, notes. */
  function compose(g, em) {
    var lw = linework(g, em), ctx = { em: em, lw: lw }, notes = [];
    var specs = dimensionSpecs(g, lw, em, notes);
    var dims = [];
    specs.bottom.concat(specs.top).forEach(function (s) { dims.push(axialDimension(s, ctx)); });
    specs.right.concat(specs.left).forEach(function (s) { dims.push(diameterDimension(s, ctx)); });

    var obstacles = lw.outline.concat([lw.centre]);
    dims.forEach(function (d) { obstacles = obstacles.concat(dimensionObstacles(d)); });
    var placer = new Placer(obstacles, em);

    dims.forEach(function (d) {
      var box = d.kind === 'axial' ? placeAxialLabel(d, placer, em) : placeDiameterLabel(d, placer, em);
      if (!box) throw new Error('No free place for label ' + d.id);
      d.box = box;
      placer.take(box, d.tail ? [d.tail] : []);
    });

    var v = g.values;
    if (g.shoulder && v.alpha != null) {
      var spec = {
        A: [v.L1, -v.P2 / 2], B: [v.L2, -v.H1 / 2], text: '\u03b1 ' + format.angle(v.alphaRaw)
      };
      var a = placeAngle(spec, placer, em);
      if (a) {
        dims.push({ id: 'alpha', text: spec.text, kind: 'angle', extensions: [], line: null, leader: a.leader, arrows: a.arrows, box: a.box, rotate: false });
        placer.take(a.box, [a.leader]);
      } else notes.push('\u03b1 label not drawn: no free place for it.');
    }

    var bounds = { minX: Infinity, minY: Infinity, maxX: -Infinity, maxY: -Infinity };
    function grow(x, y) { bounds.minX = Math.min(bounds.minX, x); bounds.maxX = Math.max(bounds.maxX, x); bounds.minY = Math.min(bounds.minY, y); bounds.maxY = Math.max(bounds.maxY, y); }
    placer.obstacles.forEach(function (s) { grow(s[0][0], s[0][1]); grow(s[1][0], s[1][1]); });
    dims.forEach(function (d) { if (d.box) { grow(d.box.x, d.box.y); grow(d.box.x + d.box.w, d.box.y + d.box.h); } });
    return { lw: lw, dims: dims, bounds: bounds, notes: notes };
  }

  return { compose: compose, textWidth: textWidth };
});
