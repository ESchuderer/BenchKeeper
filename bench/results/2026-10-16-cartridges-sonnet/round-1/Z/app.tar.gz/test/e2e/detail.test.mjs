import { test, before, after } from 'node:test';
import assert from 'node:assert/strict';
import { launch, openPage, detailUrl } from './helpers.mjs';

let browser;
before(async () => { browser = await launch(); });
after(async () => { await browser.close(); });

/** All rows of a values region as [symbol, value, unit] with whitespace normalised. */
async function rows(page, regionName) {
  const region = page.getByRole('region', { name: regionName, exact: true });
  return region.locator('tbody tr').evaluateAll((trs) =>
    trs.map((tr) => [...tr.children].map((c) => c.textContent.replace(/\s+/g, ' ').trim())));
}
/** Waits for the (hash-routed) view whose h1 is `name`. */
const h1 = (page, name) => page.getByRole('heading', { level: 1, name, exact: true }).waitFor({ timeout: 3000 });
const find = (list, symbol) => list.find((r) => r[0] === symbol);

test('a name link opens the detail view at its own address, which survives reload', async () => {
  const page = await openPage(browser);
  await page.getByRole('link', { name: '308 Win.', exact: true }).click();
  assert.match(page.url(), /#\/cartridge\/308_win$/);
  await h1(page, '308 Win.');
  await page.reload();
  await h1(page, '308 Win.');
  assert.equal(await page.title(), '308 Win. - Cartridges');
  await page.getByRole('link', { name: 'All cartridges', exact: true }).click();
  await h1(page, 'Cartridges');
  assert.equal(await page.getByText('25 cartridges', { exact: true }).count(), 1);
  await page.goBack();
  await h1(page, '308 Win.');
  await page.context().close();
});

test('opening a detail address directly works; an unknown address says so and links back', async () => {
  const page = await openPage(browser, { url: detailUrl('6_5_creedmoor') });
  await h1(page, '6,5 Creedmoor');
  await page.goto(detailUrl('nope') );
  assert.equal(await page.getByText('No cartridge', { exact: false }).count() > 0, true);
  assert.equal(await page.getByRole('link', { name: 'All cartridges', exact: true }).count(), 1);
  await page.context().close();
});

test('detail view shows the metadata, the water capacity with its source link, Print and All cartridges', async () => {
  const page = await openPage(browser, { url: detailUrl('308_win') });
  const meta = await page.locator('dl.meta').evaluate((dl) => {
    const o = {};
    for (const dt of dl.querySelectorAll('dt')) o[dt.textContent.trim()] = dt.nextElementSibling.textContent.replace(/\s+/g, ' ').trim();
    return o;
  });
  assert.equal(meta['Alternative names'], '308 Winchester, 7,62 x 51');
  assert.equal(meta['Family'], 'rimless');
  assert.equal(meta['Category'], 'rifle');
  assert.equal(meta['Primer type'], 'lr');
  assert.equal(meta['C.I.P. table'], 'I');
  assert.equal(meta['Country'], 'US');
  assert.equal(meta['Published'], '1984-06-14');
  assert.equal(meta['Revised'], '2008-09-23');
  assert.equal(meta['Pressure method'], 'Transducer');
  assert.match(meta['Water capacity'], /^56 gr H2O/);
  const src = page.locator('dl.meta').getByRole('link', { name: 'kwk', exact: true });
  assert.equal(await src.getAttribute('href'), 'http://kwk.us/cases.html');
  assert.equal(await page.getByRole('button', { name: 'Print', exact: true }).count(), 1);
  assert.equal(await page.getByRole('link', { name: 'All cartridges', exact: true }).count(), 1);
  assert.deepEqual(page.foreignRequests, []);
  assert.deepEqual(page.consoleErrors, []);
  await page.context().close();
});

test('cartridge and chamber values: columns, units, tolerances beside values, angles as published', async () => {
  const page = await openPage(browser, { url: detailUrl('308_win') });
  for (const name of ['Cartridge values', 'Chamber values']) {
    const region = page.getByRole('region', { name, exact: true });
    for (const col of ['Symbol', 'Value', 'Unit']) {
      assert.ok(await region.getByRole('columnheader', { name: col, exact: true }).count() >= 1, `${name} ${col}`);
    }
  }
  const cart = await rows(page, 'Cartridge values');
  assert.deepEqual(find(cart, 'L3'), ['L3', '51.18', 'mm']);
  assert.deepEqual(find(cart, 'L1'), ['L1', '39.62 -0.2', 'mm']);
  assert.deepEqual(find(cart, 'P2'), ['P2', '11.53 -0.2', 'mm']);
  assert.deepEqual(find(cart, 'Pmax'), ['Pmax', '4150', 'bar']);
  assert.deepEqual(find(cart, 'PK'), ['PK', '4773', 'bar']);
  assert.deepEqual(find(cart, 'PE'), ['PE', '5190', 'bar']);
  assert.deepEqual(find(cart, 'EE'), ['EE', '3920', 'J']);
  assert.deepEqual(find(cart, 'M'), ['M', '25', 'g']);
  assert.deepEqual(find(cart, 'α'), ['α', '40°', '']);
  assert.deepEqual(find(cart, 'β'), ['β', '35°', '']);
  assert.deepEqual(find(cart, 'δ'), ['δ', '36°', '']);
  assert.deepEqual(find(cart, 'e min'), ['e min', '1.4', 'mm']);
  assert.deepEqual(find(cart, 'r1 min'), ['r1 min', '0.76', 'mm']);
  assert.deepEqual(find(cart, 'delta L'), ['delta L', '0.1', 'mm']);
  assert.deepEqual(find(cart, 'L3 + G'), ['L3 + G', '58.16', 'mm']);
  assert.equal(cart.filter((r) => /Tol$/.test(r[0])).length, 0, 'tolerance has no row of its own');
  assert.equal(cart.filter((r) => r[0] === 'L1').length, 1);

  const ch = await rows(page, 'Chamber values');
  assert.deepEqual(find(ch, 'N'), ['N', '4', '']);
  assert.deepEqual(find(ch, 'Q'), ['Q', '47.51', 'mm²']);
  assert.deepEqual(find(ch, 'u'), ['u', '305', 'mm']);
  assert.deepEqual(find(ch, 'r1 max'), ['r1 max', '0.76', 'mm']);
  assert.deepEqual(find(ch, 'α1'), ['α1', "71°25'59\"", '']);
  assert.deepEqual(find(ch, 'i'), ['i', "1°45'0\"", '']);
  assert.deepEqual(find(ch, 'α'), ['α', '40°', '']);
  await page.context().close();
});

test('every record: no Tol rows, tolerance beside its value, no thousands separators, nothing invented', async () => {
  const page = await openPage(browser);
  const keys = await page.evaluate(() => window.CIP.records.map((r) => r.key));
  assert.equal(keys.length, 25);
  for (const key of keys) {
    await page.goto(detailUrl(key));
    const all = [...(await rows(page, 'Cartridge values')), ...(await rows(page, 'Chamber values'))];
    assert.ok(all.length > 10, key);
    assert.equal(all.filter((r) => /Tol$/.test(r[0])).length, 0, key);
    assert.equal(all.filter((r) => /[0-9],[0-9]{3}/.test(r[1])).length, 0, key);
    assert.equal(all.filter((r) => /NaN|undefined|null/.test(r.join(' '))).length, 0, key);
  }
  // counts: published values (non-Tol leaf fields) equal rows shown
  const expected = await page.evaluate(() => window.CIP.records.reduce((n, r) =>
    n + ['cartridge', 'chamber'].reduce((m, g) => m + Object.values(r[g]).reduce((k, sec) =>
      k + Object.keys(sec).filter((f) => !/Tol$/.test(f)).length, 0), 0), 0));
  let shown = 0;
  for (const key of keys) {
    await page.goto(detailUrl(key));
    shown += (await rows(page, 'Cartridge values')).length + (await rows(page, 'Chamber values')).length;
  }
  assert.equal(shown, expected);
  await page.context().close();
});

test('the Print button opens the print dialog', async () => {
  const page = await openPage(browser, { url: detailUrl('223_rem') });
  await page.evaluate(() => { window.__printed = 0; window.print = () => { window.__printed++; }; });
  await page.getByRole('button', { name: 'Print', exact: true }).click();
  assert.equal(await page.evaluate(() => window.__printed), 1);
  await page.context().close();
});

test('after navigating, keyboard focus moves to the new heading; the first load does not steal focus', async () => {
  const page = await openPage(browser);
  assert.equal(await page.evaluate(() => document.activeElement === document.body), true);
  await page.getByRole('link', { name: '243 Win.', exact: true }).click();
  await h1(page, '243 Win.');
  assert.equal(await page.evaluate(() => document.activeElement && document.activeElement.textContent), '243 Win.');
  await page.getByRole('link', { name: 'All cartridges', exact: true }).click();
  await h1(page, 'Cartridges');
  assert.equal(await page.evaluate(() => document.activeElement && document.activeElement.textContent), 'Cartridges');
  await page.context().close();
});

test('a malformed address does not break the app', async () => {
  const page = await openPage(browser, { url: detailUrl('%E0%A4%A') });
  assert.equal(await page.getByRole('link', { name: 'All cartridges', exact: true }).count(), 1);
  assert.deepEqual(page.consoleErrors, []);
  await page.context().close();
});
