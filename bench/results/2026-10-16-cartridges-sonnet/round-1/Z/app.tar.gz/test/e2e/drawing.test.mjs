import { test, before, after } from 'node:test';
import assert from 'node:assert/strict';
import { launch, openPage, detailUrl } from './helpers.mjs';

let browser;
before(async () => { browser = await launch(); });
after(async () => { await browser.close(); });

/** Measures the rendered drawing in user units (= mm). */
function measure() {
  const svg = document.querySelector('figure.drawing svg');
  const inv = svg.getScreenCTM().inverse();
  const toUser = (r) => {
    const a = new DOMPoint(r.left, r.top).matrixTransform(inv), b = new DOMPoint(r.right, r.bottom).matrixTransform(inv);
    return { x: Math.min(a.x, b.x), y: Math.min(a.y, b.y), w: Math.abs(b.x - a.x), h: Math.abs(b.y - a.y) };
  };
  const texts = [...svg.querySelectorAll('text.dim-label')].map((t) => ({ id: t.dataset.label, text: t.textContent, ...toUser(t.getBoundingClientRect()) }));
  const outline = [];
  for (const p of svg.querySelectorAll('.outline path, .centre')) {
    const n = Math.max(2, Math.ceil(p.getTotalLength() / 0.15));
    for (let i = 0; i <= n; i++) { const q = p.getPointAtLength((p.getTotalLength() * i) / n); outline.push([q.x, q.y]); }
  }
  const lines = [...svg.querySelectorAll('.dim')].map((g) => ({
    id: g.dataset.dim,
    pts: [...g.querySelectorAll('path')].flatMap((p) => {
      const n = Math.max(2, Math.ceil(p.getTotalLength() / 0.15)), out = [];
      for (let i = 0; i <= n; i++) { const q = p.getPointAtLength((p.getTotalLength() * i) / n); out.push([q.x, q.y]); }
      return out;
    })
  }));
  const hatch = [...svg.querySelectorAll('path.hatch')].map((p) => { const b = p.getBBox(); return { y: b.y, h: b.height }; });
  const vb = svg.viewBox.baseVal;
  return { texts, outline, lines, hatch, view: { x: vb.x, y: vb.y, w: vb.width, h: vb.height }, fontSize: Number(svg.getAttribute('font-size')) };
}

const inside = (p, b, pad = 0) => p[0] > b.x - pad && p[0] < b.x + b.w + pad && p[1] > b.y - pad && p[1] < b.y + b.h + pad;
const overlap = (a, b) => a.x < b.x + b.w && b.x < a.x + a.w && a.y < b.y + b.h && b.y < a.y + a.h;

test('the detail view shows the drawing as an image named "<name> drawing"', async () => {
  const page = await openPage(browser, { url: detailUrl('308_win') });
  const img = page.getByRole('img', { name: '308 Win. drawing', exact: true });
  assert.equal(await img.count(), 1);
  assert.equal(await img.evaluate((e) => e.tagName.toLowerCase()), 'svg');
  // true to scale: natural size is 1 user unit = 1 mm
  const dims = await img.evaluate((e) => ({ w: e.getAttribute('width'), vb: e.viewBox.baseVal.width }));
  assert.ok(dims.w.endsWith("mm") && Math.abs(parseFloat(dims.w) - dims.vb) < 1e-3, `width ${dims.w} vs view box ${dims.vb}`);
  assert.deepEqual(page.foreignRequests, []);
  assert.deepEqual(page.consoleErrors, []);
  await page.context().close();
});

test('all 25 drawings: rendered labels do not overlap each other, the outline or other dimension lines; hatching is below the axis', async () => {
  const page = await openPage(browser);
  const keys = await page.evaluate(() => window.CIP.records.map((r) => r.key));
  for (const key of keys) {
    await page.goto(detailUrl(key));
    await page.getByRole('img', { name: /drawing$/ }).waitFor();
    const m = await page.evaluate(measure);
    assert.ok(m.texts.length >= 7, `${key}: ${m.texts.length} labels`);
    for (const [i, a] of m.texts.entries()) {
      assert.ok(a.x >= m.view.x && a.y >= m.view.y && a.x + a.w <= m.view.x + m.view.w && a.y + a.h <= m.view.y + m.view.h, `${key} ${a.id} inside view`);
      for (let j = i + 1; j < m.texts.length; j++) assert.ok(!overlap(a, m.texts[j]), `${key}: ${a.id} overlaps ${m.texts[j].id}`);
      const hit = m.outline.find((p) => inside(p, a));
      assert.equal(hit, undefined, `${key}: ${a.id} touches the outline at ${hit}`);
      for (const l of m.lines) {
        if (l.id === a.id) continue;
        assert.equal(l.pts.find((p) => inside(p, a)), undefined, `${key}: ${a.id} touches a line of ${l.id}`);
      }
    }
    for (const h of m.hatch) assert.ok(h.y >= -1e-6, `${key}: hatching starts below the axis`);
    assert.equal(m.hatch.length, 1, key);
  }
  await page.context().close();
});

test('the drawing scales to a phone screen without horizontal overflow and keeps text readable', async () => {
  for (const key of ['9_3_x_74_r', '22_long_rifle']) {
    const page = await openPage(browser, { url: detailUrl(key), viewport: { width: 360, height: 740 } });
    const r = await page.evaluate(() => {
      const svg = document.querySelector('figure.drawing svg');
      const box = svg.getBoundingClientRect();
      const t = document.querySelector('figure.drawing text.dim-label').getBoundingClientRect();
      return { svgWidth: box.width, innerWidth, scrollWidth: document.documentElement.scrollWidth, textHeight: Math.min(t.width, t.height) };
    });
    assert.ok(r.svgWidth <= r.innerWidth + 0.5, `${key}: svg ${r.svgWidth} <= ${r.innerWidth}`);
    assert.ok(r.scrollWidth <= r.innerWidth, `${key}: no horizontal scroll (${r.scrollWidth})`);
    assert.ok(r.svgWidth > 300, `${key}: uses the screen width`);
    assert.ok(r.textHeight >= 6, `${key}: label text height ${r.textHeight}px`);
    await page.context().close();
  }
});

test('light and dark follow the system on screen', async () => {
  const color = async (scheme) => {
    const page = await openPage(browser, { url: detailUrl('308_win'), colorScheme: scheme });
    const c = await page.evaluate(() => ({
      bg: getComputedStyle(document.body).backgroundColor,
      ink: getComputedStyle(document.querySelector('.drawing-svg text.tb-text')).fill
    }));
    await page.context().close();
    return c;
  };
  const light = await color('light'), dark = await color('dark');
  assert.notEqual(light.bg, dark.bg);
  assert.notEqual(light.ink, dark.ink);
  assert.equal(light.bg, 'rgb(244, 245, 247)');
});

test('the drawing caption names the rim type', async () => {
  const page = await openPage(browser, { url: detailUrl('300_win_mag') });
  assert.equal((await page.locator('figure.drawing figcaption').innerText()).trim(), 'Rim type: belted.');
  await page.context().close();
});
