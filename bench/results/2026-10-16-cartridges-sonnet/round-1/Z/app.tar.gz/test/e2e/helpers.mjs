// Browser seam helpers: the real index.html opened over file:// in Chromium.
import { chromium } from 'playwright';
import { pathToFileURL } from 'node:url';
import path from 'node:path';

export const ROOT = path.resolve(import.meta.dirname, '..', '..');
export const INDEX_URL = pathToFileURL(path.join(ROOT, 'index.html')).href;

export async function launch() {
  return chromium.launch();
}

/** Opens a page and records every request that is not file: or data: (must stay empty). */
export async function openPage(browser, { url = INDEX_URL, viewport, colorScheme = 'light' } = {}) {
  const context = await browser.newContext({ viewport: viewport ?? { width: 1100, height: 900 }, colorScheme });
  const page = await context.newPage();
  page.foreignRequests = [];
  page.consoleErrors = [];
  page.on('request', (r) => { if (!/^(file|data|blob):/.test(r.url())) page.foreignRequests.push(r.url()); });
  page.on('console', (m) => { if (m.type() === 'error') page.consoleErrors.push(m.text()); });
  page.on('pageerror', (e) => page.consoleErrors.push(String(e)));
  await page.goto(url);
  return page;
}

export const detailUrl = (key) => `${INDEX_URL}#/cartridge/${key}`;
