import { test, before, after } from 'node:test';
import assert from 'node:assert/strict';
import { launch, openPage } from './helpers.mjs';

let browser;
before(async () => { browser = await launch(); });
after(async () => { await browser.close(); });

test('start page lists all 25 cartridges with name link, family and L3', async () => {
  const page = await openPage(browser);
  assert.equal(await page.getByRole('heading', { level: 1, name: 'Cartridges' }).count(), 1);
  assert.equal(await page.getByText('25 cartridges', { exact: true }).count(), 1);
  const links = page.locator('main a[href^="#/cartridge/"]');
  assert.equal(await links.count(), 25);
  const row = page.getByRole('row').filter({ has: page.getByRole('link', { name: '308 Win.', exact: true }) });
  const text = (await row.innerText()).replace(/\s+/g, ' ');
  assert.match(text, /308 Win\. rimless 51\.18 mm/);
  // names are shown as published
  assert.equal(await page.getByRole('link', { name: '6,5 Creedmoor', exact: true }).count(), 1);
  assert.deepEqual(page.foreignRequests, []);
  assert.deepEqual(page.consoleErrors, []);
  await page.context().close();
});

test('search finds a cartridge by alternative name while typing', async () => {
  const page = await openPage(browser);
  const search = page.getByLabel('Search', { exact: true });
  await search.pressSequentially('7,62 x 51');
  assert.equal(await page.getByText('1 cartridges', { exact: true }).count(), 1);
  assert.equal(await page.getByRole('link', { name: '308 Win.', exact: true }).count(), 1);
  assert.equal(await page.locator('main a[href^="#/cartridge/"]').count(), 1);
  await search.fill('');
  assert.equal(await page.getByText('25 cartridges', { exact: true }).count(), 1);
  await page.context().close();
});

test('search matches names, ignores case, decimal comma and spacing around x', async () => {
  const page = await openPage(browser);
  const search = page.getByLabel('Search', { exact: true });
  await search.fill('CREEDMOOR');
  assert.equal(await page.locator('main a[href^="#/cartridge/"]').count(), 1);
  await search.fill('7.62x39');
  assert.equal(await page.getByRole('link', { name: '7,62 x 39', exact: true }).count(), 1);
  await search.fill('30-06');
  assert.equal(await page.getByRole('link', { name: '30-06 Spring.', exact: true }).count(), 1);
  await search.fill('no such cartridge');
  assert.equal(await page.getByText('0 cartridges', { exact: true }).count(), 1);
  assert.equal(await page.locator('main a[href^="#/cartridge/"]').count(), 0);
  await page.context().close();
});

test('family select filters the list and combines with search', async () => {
  const page = await openPage(browser);
  const family = page.getByLabel('Family', { exact: true });
  const options = await family.locator('option').allInnerTexts();
  assert.deepEqual(options, ['All', 'rimless', 'rimmed', 'belted', 'pistol', 'rimfire']);
  const expected = { rimless: 12, rimmed: 2, belted: 2, pistol: 6, rimfire: 3 };
  for (const [name, n] of Object.entries(expected)) {
    await family.selectOption({ label: name });
    assert.equal(await page.getByText(`${n} cartridges`, { exact: true }).count(), 1, name);
    assert.equal(await page.locator('main a[href^="#/cartridge/"]').count(), n, name);
  }
  await family.selectOption({ label: 'pistol' });
  await page.getByLabel('Search', { exact: true }).fill('rem. mag');
  assert.equal(await page.getByRole('link', { name: '44 Rem. Mag.', exact: true }).count(), 1);
  assert.equal(await page.locator('main a[href^="#/cartridge/"]').count(), 1);
  await family.selectOption({ label: 'All' });
  await page.getByLabel('Search', { exact: true }).fill('');
  assert.equal(await page.getByText('25 cartridges', { exact: true }).count(), 1);
  await page.context().close();
});
