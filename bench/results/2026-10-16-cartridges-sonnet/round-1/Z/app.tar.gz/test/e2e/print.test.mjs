import { test, before, after } from 'node:test';
import assert from 'node:assert/strict';
import { launch, openPage, detailUrl } from './helpers.mjs';

let browser;
before(async () => { browser = await launch(); });
after(async () => { await browser.close(); });

const MM = 96 / 25.4;

test('print view: no navigation, search or buttons; header, drawing at full width, tables, source footer; always black on white', async () => {
  const page = await openPage(browser, { url: detailUrl('308_win'), colorScheme: 'dark', viewport: { width: Math.round(190 * MM), height: 1000 } });
  await page.emulateMedia({ media: 'print', colorScheme: 'dark' });
  const visible = (loc) => loc.evaluateAll((els) => els.filter((e) => e.getClientRects().length > 0 && getComputedStyle(e).visibility !== 'hidden').length);
  assert.equal(await visible(page.getByRole('button', { name: 'Print' })), 0);
  assert.equal(await visible(page.getByRole('link', { name: 'All cartridges' })), 0);
  assert.equal(await visible(page.getByRole('link', { name: 'C.I.P. cartridge reference' })), 0);
  assert.equal(await visible(page.locator('input, select')), 0);
  assert.equal(await visible(page.getByRole('heading', { level: 1, name: '308 Win.' })), 1);
  assert.equal(await visible(page.getByRole('region', { name: 'Cartridge values' })), 1);
  assert.equal(await visible(page.getByRole('region', { name: 'Chamber values' })), 1);
  const footer = page.locator('footer.source');
  assert.equal(await visible(footer), 1);
  assert.equal((await footer.innerText()).trim(), 'Source: C.I.P. TDCC, revised 2008-09-23');
  const look = await page.evaluate(() => {
    const svg = document.querySelector('figure.drawing svg');
    return {
      bg: getComputedStyle(document.body).backgroundColor, ink: getComputedStyle(document.body).color,
      label: getComputedStyle(document.querySelector('.dim-label')).fill, line: getComputedStyle(document.querySelector('.dim-line')).stroke,
      width: svg.getBoundingClientRect().width, pageWidth: document.documentElement.clientWidth
    };
  });
  assert.equal(look.bg, 'rgb(255, 255, 255)');
  assert.equal(look.ink, 'rgb(0, 0, 0)');
  assert.equal(look.label, 'rgb(0, 0, 0)');
  assert.equal(look.line, 'rgb(0, 0, 0)');
  assert.ok(Math.abs(look.width - 190 * MM) < 1.5, `drawing width ${look.width}px vs ${190 * MM}px`);
  await page.context().close();
});

test('print view paints a white page even when the system is dark', async () => {
  const page = await openPage(browser, { url: detailUrl('308_win'), colorScheme: 'dark' });
  await page.emulateMedia({ media: 'print', colorScheme: 'dark' });
  const bg = await page.evaluate(() => [getComputedStyle(document.documentElement).backgroundColor, getComputedStyle(document.body).backgroundColor]);
  assert.ok(bg.every((c) => c === 'rgb(255, 255, 255)'), bg.join(' / '));
  await page.context().close();
});

test('every detail view prints on exactly one A4 portrait page', async () => {
  const page = await openPage(browser);
  const keys = await page.evaluate(() => window.CIP.records.map((r) => r.key));
  const failures = [];
  for (const key of keys) {
    await page.goto(detailUrl(key));
    await page.getByRole('img', { name: /drawing$/ }).waitFor();
    const pdf = await page.pdf({ preferCSSPageSize: true, printBackground: true });
    const text = pdf.toString('latin1');
    const pages = (text.match(/\/Type\s*\/Page[^s]/g) || []).length;
    const box = /\/MediaBox\s*\[\s*0\s+0\s+([\d.]+)\s+([\d.]+)\s*\]/.exec(text);
    if (pages !== 1) failures.push(`${key}: ${pages} pages`);
    if (!box || Math.abs(box[1] - 595) > 2 || Math.abs(box[2] - 842) > 2) failures.push(`${key}: media box ${box && box[1]}x${box && box[2]}`);
  }
  assert.deepEqual(failures, []);
  await page.context().close();
});

test('printed drawing labels stay legible: text between 2.4 and 7 mm on paper', async () => {
  const page = await openPage(browser);
  const sizes = await page.evaluate(() => window.CIP.records.map((r) => {
    const m = window.CIP.drawing.build(r);
    return [r.key, m.fontSize * m.scale];
  }));
  for (const [key, mm] of sizes) assert.ok(mm >= 2.4 && mm <= 7, `${key}: ${mm.toFixed(2)} mm`);
  await page.context().close();
});

test('the screen view still shows navigation, search and the print button', async () => {
  const page = await openPage(browser, { url: detailUrl('308_win') });
  assert.equal(await page.getByRole('button', { name: 'Print' }).isVisible(), true);
  assert.equal(await page.getByRole('link', { name: 'All cartridges' }).isVisible(), true);
  await page.context().close();
});
