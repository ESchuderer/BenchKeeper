import { test, before, after } from 'node:test';
import assert from 'node:assert/strict';
import { launch } from './helpers.mjs';
import { start } from '../../scripts/serve.mjs';

let browser, server;
before(async () => { browser = await launch(); server = await start(0); });
after(async () => { await browser.close(); await new Promise((r) => server.close(r)); });

test('the folder also works when served by a static file server (list, detail address, reload, drawing)', async () => {
  const base = `http://127.0.0.1:${server.address().port}`;
  const context = await browser.newContext();
  const page = await context.newPage();
  const foreign = [], errors = [];
  page.on('request', (r) => { if (!r.url().startsWith(base) && !/^(data|blob):/.test(r.url())) foreign.push(r.url()); });
  page.on('console', (m) => { if (m.type() === 'error') errors.push(m.text()); });
  page.on('pageerror', (e) => errors.push(String(e)));
  await page.goto(`${base}/`);
  await page.getByText('25 cartridges', { exact: true }).waitFor();
  await page.getByLabel('Search', { exact: true }).fill('7,62 x 51');
  await page.getByRole('link', { name: '308 Win.', exact: true }).click();
  await page.getByRole('heading', { level: 1, name: '308 Win.', exact: true }).waitFor();
  assert.match(page.url(), /\/index\.html#\/cartridge\/308_win$|\/#\/cartridge\/308_win$/);
  await page.reload();
  await page.getByRole('img', { name: '308 Win. drawing', exact: true }).waitFor();
  assert.deepEqual(foreign, []);
  assert.deepEqual(errors, []);
  await context.close();
});
