'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const drawing = require('../../js/drawing.js');
const { records, byKey, variant, close, closePoint, distanceToPolyline, radiusAt } = require('./helpers.js');

const build = (r) => drawing.build(typeof r === 'string' ? byKey(r) : r);

test('rule 1: rim type from family and R1/P1', () => {
  assert.equal(build('308_win').rimType, 'rimless'); // 12.01/11.96
  assert.equal(build('9_3_x_74_r').rimType, 'rimmed'); // 13.35/11.9 = 1.12
  assert.equal(build('38_special').rimType, 'rimmed'); // family pistol, 11.18/9.63
  assert.equal(build('300_win_mag').rimType, 'belted');
  assert.equal(build('22_long_rifle').rimType, 'rimfire');
  const withR1 = (R1) => build(variant('308_win', (r) => { r.cartridge.caseHead.R1 = R1; })).rimType;
  assert.equal(withR1(10), 'rebated'); // 0.836
  assert.equal(withR1(11.7), 'rebated'); // 0.978 < 0.98
  assert.equal(withR1(11.73), 'rimless'); // 0.9808
  assert.equal(withR1(12.5), 'rimless'); // 1.045 < 1.05
  assert.equal(withR1(12.58), 'rimmed'); // 1.0519
});

test('rules 2-4: head face, chamfer, extractor groove, body and neck of 308 Win. (rimless, bottleneck)', () => {
  const p = build('308_win').profile;
  closePoint(p[0], [0, 0], 1e-9, 'axis at head face');
  // chamfer: R1/2 - min(f*tan35deg, R1/4) = 6.005 - 0.26608 at z = 0, then (R1/2, f), then up to (R1/2, R)
  closePoint(p[1], [5.73892, 0], 1e-4, 'chamfer start');
  closePoint(p[2], [6.005, 0.38], 1e-9, 'chamfer end');
  closePoint(p[3], [6.005, 1.37], 1e-9, 'rim corner');
  // groove: in to E1/2, floor to R + e min, ramp out to (P1/2, E)
  closePoint(p[4], [5.195, 1.37], 1e-9, 'groove start');
  closePoint(p[5], [5.195, 2.77], 1e-9, 'groove floor end');
  closePoint(p[6], [5.98, 3.85], 1e-9, 'groove ramp end');
  // mouth is the last point: (H2/2, L3)
  closePoint(p[p.length - 1], [4.36, 51.18], 1e-9, 'mouth');
  for (let i = 1; i < p.length; i++) assert.ok(p[i][1] >= p[i - 1][1] - 1e-9, 'z never decreases');
});

test('rule 3: belted case ramps out at delta to the belt, follows it to z = E and steps in', () => {
  const p = build('300_win_mag').profile;
  closePoint(p[4], [6.035, 1.27], 1e-9, 'groove start (E1/2)');
  closePoint(p[5], [6.035, 2.21], 1e-9, 'floor end (R + e min)');
  // ramp at 35 deg to the axis up to R3/2 = 6.755: dz = 0.72 / tan(35deg) = 1.02827
  closePoint(p[6], [6.755, 3.23827], 1e-4, 'belt ramp end');
  closePoint(p[7], [6.755, 5.59], 1e-9, 'belt end at z = E');
  closePoint(p[8], [6.515, 5.59], 1e-9, 'step in to P1/2');
});

test('rule 2 and 3: rimmed case without groove steps in from the rim', () => {
  const p = build('9_3_x_74_r').profile;
  closePoint(p[3], [6.675, 1.4], 1e-9, 'rim corner (R1/2, R)');
  closePoint(p[4], [5.95, 1.4], 1e-9, 'step in to (P1/2, R)');
});

test('rule 2: rimfire rim edge is a half-round of radius min(R/2, (R1-P1)/2)', () => {
  const p = build('17_hmr').profile; // R 1.27, R1 7.47, P1 6.15 -> radius 0.635
  closePoint(p[0], [0, 0], 1e-9);
  closePoint(p[1], [3.1, 0], 1e-9, 'head face ends where the half-round starts');
  const head = p.filter((q) => q[1] <= 1.27 + 1e-9 && q[0] > 3.1 - 1e-9);
  const outermost = head.reduce((a, b) => (b[0] > a[0] ? b : a));
  close(outermost[0], 3.735, 1e-9, 'outermost point lies at R1/2');
  close(outermost[1], 0.635, 1e-3, 'at half the rim thickness');
  for (const q of head) close(Math.hypot(q[0] - 3.1, q[1] - 0.635), 0.635, 1e-6, 'on the half-round') ;
  assert.ok(p.some((q) => Math.abs(q[0] - 3.075) < 1e-9 && Math.abs(q[1] - 1.27) < 1e-9), 'then steps in to P1/2 at z = R');
});

test('rules 4-6: shoulder runs through the published points; corners rounded only where r is published', () => {
  // 17 HMR publishes no r1 min / r2: sharp corners, points exactly as given
  const p = build('17_hmr').profile;
  assert.ok(p.some((q) => Math.abs(q[0] - 3.075) < 1e-9 && Math.abs(q[1] - 22.2) < 1e-9), '(P2/2, L1)');
  assert.ok(p.some((q) => Math.abs(q[0] - 2.45) < 1e-9 && Math.abs(q[1] - 23.54) < 1e-9), '(H1/2, L2)');
  closePoint(p[p.length - 1], [2.45, 27.03], 1e-9, 'mouth (H2/2, L3)');
  // 223 Rem.: both corners rounded; distance from each corner to the arc is the sagitta r(1/cos(turn/2) - 1)
  const q = build('223_rem').profile;
  const bodyCorner = [4.5, 36.52], neckCorner = [3.215, 39.55];
  close(distanceToPolyline(bodyCorner, q), 0.01227, 0.002, 'r1 min 0.64 at body-side corner');
  close(distanceToPolyline(neckCorner, q), 0.05206, 0.003, 'r2 2.54 at neck-side corner');
  // 338 Lapua Mag. publishes r2 only: body-side corner stays sharp
  const l = build('338_lapua_mag').profile;
  assert.ok(l.some((pt) => Math.abs(pt[0] - 6.91) < 1e-9 && Math.abs(pt[1] - 54.9) < 1e-9), 'sharp (P2/2, L1)');
  assert.ok(distanceToPolyline([4.73, 60.89], l) > 0.02, 'rounded (H1/2, L2)');
});

test('rule 4: a case without alpha, L1 or L2 is straight and runs to (H2/2, L3)', () => {
  const p = build('9_mm_luger').profile;
  const last = p[p.length - 1];
  closePoint(last, [4.825, 19.15], 1e-9);
  closePoint(p[p.length - 2], [4.965, 2.98], 1e-9, 'body start: (P1/2, E)');
  const noAlpha = build(variant('223_rem', (r) => { delete r.cartridge.junctionCone.alpha; }));
  closePoint(noAlpha.profile[noAlpha.profile.length - 2], [4.79, 3.13], 1e-9);
  closePoint(noAlpha.profile[noAlpha.profile.length - 1], [3.215, 44.7], 1e-9);
});

test('rule 7: pointy bullet - seating, cylinder, tangent ogive, meplat (223 Rem.)', () => {
  const b = build('223_rem').bullet;
  assert.equal(b.shape, 'pointy');
  close(b.seatingDepth, 5.7, 1e-9); // 1.0 * G1
  close(b.baseZ, 39.0, 1e-9); // L3 - s
  close(b.length, 18.4, 1e-9); // L6 - zb
  close(b.cylinderEnd, 46.36, 1e-9); // zb + 0.40 * Lb
  close(b.meplat, 1.27, 1e-9); // max(0.08 * 5.7, 1.27)
  close(b.ogiveRadius, 28.6204, 1e-3); // ((2.85 - 0.635)^2 + 11.04^2) / (2 * 2.215)
  const ex = b.exposed;
  closePoint(ex[0], [2.85, 44.7], 1e-9, 'bullet leaves the mouth at the shank radius');
  closePoint(ex[ex.length - 1], [0, 57.4], 1e-9, 'tip on the axis at L6');
  closePoint(ex[ex.length - 2], [0.635, 57.4], 1e-9, 'flat tip of diameter m');
  // ogive points lie on the arc: centre r = G1/2 - rho at z = cylinder end
  for (const q of ex.filter((pt) => pt[1] > 46.4 && pt[1] < 57.3)) {
    close(Math.hypot(q[0] - (2.85 - 28.6204), q[1] - 46.36), 28.6204, 2e-3, 'on tangent ogive');
  }
});

test('rule 7: rounded pistol bullet (9 mm Luger) is a quarter ellipse with m = 0.15 G1', () => {
  const b = build('9_mm_luger').bullet;
  close(b.seatingDepth, 3.612, 1e-9); // 0.4 * 9.03 on a pistol cartridge
  close(b.baseZ, 15.538, 1e-9);
  close(b.cylinderEnd, 24.7368, 1e-4); // zb + 0.65 * 14.152
  close(b.meplat, 1.3545, 1e-9);
  const n = 29.69 - 24.7368, a = 4.515 - 1.3545 / 2;
  for (const q of b.exposed.filter((pt) => pt[1] > 24.8 && pt[1] < 29.6)) {
    close(Math.hypot((q[0] - 1.3545 / 2) / a, (q[1] - 24.7368) / n), 1, 2e-3, 'on quarter ellipse');
  }
});

test('rule 7: rounded on rifle and rimfire seats 0.8 G1 with k = 0.55; flat and semi-wadcutter', () => {
  const lr = build('22_long_rifle').bullet; // rimfire, rounded
  close(lr.seatingDepth, 4.576, 1e-9);
  close(lr.cylinderEnd, lr.baseZ + 0.55 * lr.length, 1e-9);
  const rifleRounded = build(variant('308_win', (r) => { r.annotations.defaultBulletShape = 'rounded'; })).bullet;
  close(rifleRounded.seatingDepth, 0.8 * 7.85, 1e-9);
  close(rifleRounded.cylinderEnd, rifleRounded.baseZ + 0.55 * rifleRounded.length, 1e-9);
  close(rifleRounded.meplat, 0.15 * 7.85, 1e-9);
  const rifleFlat = build(variant('223_rem', (r) => { r.annotations.defaultBulletShape = 'flat'; })).bullet;
  close(rifleFlat.seatingDepth, 4.56, 1e-9);
  close(rifleFlat.cylinderEnd, rifleFlat.baseZ + 0.6 * rifleFlat.length, 1e-9);
  close(rifleFlat.meplat, 3.135, 1e-9); // 0.55 * 5.7
  const pistolFlat = build('40_s_w').bullet;
  close(pistolFlat.seatingDepth, 0.4 * 10.17, 1e-9);
  close(pistolFlat.cylinderEnd, pistolFlat.baseZ + 0.7 * pistolFlat.length, 1e-9);
  close(pistolFlat.meplat, 0.55 * 10.17, 1e-9);
  const sw = build('357_magnum').bullet;
  close(sw.seatingDepth, 0.6 * 9.12, 1e-9);
  close(sw.cylinderEnd, sw.baseZ + 0.78 * sw.length, 1e-9);
  close(sw.meplat, 0.6 * 9.12, 1e-9);
  // flat and semi-wadcutter noses are straight cones: points are collinear
  const ex = sw.exposed.filter((pt) => pt[1] > sw.cylinderEnd - 1e-9 && pt[0] > sw.meplat / 2 - 1e-9);
  const slope = (ex[ex.length - 1][0] - ex[0][0]) / (ex[ex.length - 1][1] - ex[0][1]);
  for (const q of ex) close(q[0], ex[0][0] + slope * (q[1] - ex[0][1]), 1e-6, 'straight cone');
});

test('rule 7: heeled case (22 Long Rifle) - exposed bullet has the case outside diameter, seated heel the inside diameter', () => {
  const m = build('22_long_rifle');
  assert.equal(m.bullet.heeled, true);
  assert.equal(build('9_mm_luger').bullet.heeled, false);
  closePoint(m.bullet.exposed[0], [2.86, 15.57], 1e-9, 'exposed radius = H2/2');
  const section = m.bullet.section;
  assert.ok(section.some((q) => Math.abs(q[0] - 2.26) < 1e-9 && Math.abs(q[1] - m.bullet.baseZ) < 1e-9), 'heel radius H2/2 - tb');
  assert.ok(section.some((q) => Math.abs(q[0] - 2.26) < 1e-9 && Math.abs(q[1] - 15.57) < 1e-9), 'heel reaches the mouth');
});

test('rule 8: walls tn, tb, solid head w and primer pocket', () => {
  let w = build('223_rem').walls; // sr, groove: E + tb = 3.73 < pocket 3.04 + 1.5
  close(w.tn, 0.365, 1e-9);
  close(w.tb, 0.6, 1e-9);
  assert.deepEqual(w.pocket, { diameter: 4.45, depth: 3.04 });
  close(w.head, 4.54, 1e-9);
  w = build('308_win').walls; // lr
  close(w.tn, 0.435, 1e-9);
  assert.deepEqual(w.pocket, { diameter: 5.33, depth: 3.3 });
  close(w.head, 4.8, 1e-9);
  w = build('300_win_mag').walls; // lrm, belted
  close(w.tn, 0.39, 1e-9);
  assert.deepEqual(w.pocket, { diameter: 5.33, depth: 3.3 });
  close(w.head, 4.8, 1e-9); // belt ramp end + tb = 3.838 < 4.8
  w = build('45_auto').walls; // lp, E + tb = 4.71 beats pocket depth + 1.5 = 4.54
  assert.deepEqual(w.pocket, { diameter: 5.33, depth: 3.04 });
  close(w.head, 4.71, 1e-9);
  assert.deepEqual(build('44_rem_mag').walls.pocket, { diameter: 5.33, depth: 3.04 }); // lpm
  assert.deepEqual(build('357_magnum').walls.pocket, { diameter: 4.45, depth: 3.04 }); // spm
  w = build('22_long_rifle').walls; // rimfire: no pocket, w = max(2.5, 0.25 * P1/2)
  assert.equal(w.pocket, null);
  close(w.tb, 0.6, 1e-9);
  close(w.head, 2.5, 1e-9);
  // tb is capped at 0.35 * P1/2
  const thin = build(variant('22_long_rifle', (r) => { r.cartridge.powderChamber.P1 = 1.2; r.cartridge.caseHead.R1 = 2; }));
  close(thin.walls.tb, 0.21, 1e-9);
  // tb = 1.3 tn when that exceeds 0.6: tn = (8.72 - 7.0) / 2 = 0.86 -> 1.118
  const thick = build(variant('308_win', (r) => { r.cartridge.projectile.G1 = 7.0; }));
  close(thick.walls.tb, 1.118, 1e-9);
});

test('rule 8: inner line follows the outer profile at tb along the body and tn along the neck', () => {
  const m = build('223_rem');
  const inner = m.walls.inner;
  // at z = w the outer body radius is 4.79 - 0.29 * (4.54 - 3.13) / 33.39 = 4.77775
  closePoint(inner[0], [4.17775, 4.54], 1e-4, 'inner line starts at the end of the solid head');
  closePoint(inner[inner.length - 1], [2.85, 44.7], 1e-9, 'mouth: H2/2 - tn = G1/2');
  for (const q of inner) assert.ok(q[1] >= 4.54 - 1e-9 && q[0] > 0, 'inside the case beyond the head');
  // wall is tb up to the shoulder start and tn along the neck
  close(radiusAt(m.profile, 30) - radiusAt(inner, 30), 0.6, 1e-3, 'tb along the body');
  close(radiusAt(m.profile, 42) - radiusAt(inner, 42), 0.365, 1e-3, 'tn along the neck');
  // blended linearly across the shoulder: halfway between L1 and L2 the wall is (tb + tn) / 2 (sharp-corner case)
  const h = build('17_hmr');
  const mid = (22.2 + 23.54) / 2;
  const tbH = h.walls.tb, tnH = h.walls.tn;
  close(radiusAt(h.profile, mid) - radiusAt(h.walls.inner, mid), (tbH + tnH) / 2, 1e-6, 'shoulder blend');
  // heeled case: tb throughout
  const lr = build('22_long_rifle');
  close(lr.walls.inner[lr.walls.inner.length - 1][0], 2.26, 1e-9);
});

test('rule 8: a seated bullet never overlaps the case wall (all 25 cartridges)', () => {
  for (const r of records) {
    const m = build(r);
    assert.ok(m.bullet, r.key);
    for (const q of m.bullet.section) {
      if (q[1] < m.bullet.baseZ - 1e-9 || q[1] >= r.cartridge.lengths.L3 - 1e-9) continue; // the mouth plane itself has no wall
      const rin = radiusAt(m.walls.inner, q[1]);
      if (rin == null) continue; // below the solid head
      assert.ok(q[0] <= rin + 1e-6, `${r.key}: bullet r ${q[0]} > inner ${rin} at z ${q[1]}`);
    }
  }
});

test('rule 9: a missing value switches off only the feature that needs it and is named in notes', () => {
  const clean = build('223_rem');
  assert.deepEqual(clean.notes, []);
  const noE1 = build(variant('223_rem', (r) => { delete r.cartridge.caseHead.E1; }));
  assert.ok(noE1.notes.some((n) => /E1/.test(n) && /groove/i.test(n)), noE1.notes.join('|'));
  closePoint(noE1.profile[4], [4.79, 1.14], 1e-9, 'steps in from the rim without groove');
  assert.ok(!noE1.dimensions.some((d) => d.id === 'E1'));
  const noEmin = build(variant('223_rem', (r) => { delete r.cartridge.caseHead.eMin; }));
  assert.ok(noEmin.notes.some((n) => /e min/.test(n)), noEmin.notes.join('|'));
  const noG1 = build(variant('223_rem', (r) => { delete r.cartridge.projectile.G1; }));
  assert.equal(noG1.bullet, null);
  assert.ok(noG1.notes.some((n) => /G1/.test(n) && /bullet/i.test(n)));
  const noL6 = build(variant('223_rem', (r) => { delete r.cartridge.lengths.L6; }));
  assert.equal(noL6.bullet, null);
  assert.ok(noL6.notes.some((n) => /L6/.test(n)));
  assert.ok(!noL6.dimensions.some((d) => d.id === 'L6'));
  const noShape = build(variant('223_rem', (r) => { delete r.annotations.defaultBulletShape; }));
  assert.equal(noShape.bullet, null);
  assert.ok(noShape.notes.some((n) => /defaultBulletShape/.test(n)));
  const noDelta = build(variant('300_win_mag', (r) => { delete r.cartridge.caseHead.delta; }));
  assert.ok(noDelta.notes.some((n) => /\u03b4/.test(n) && /belt/i.test(n)), noDelta.notes.join('|'));
  const noP2 = build(variant('223_rem', (r) => { delete r.cartridge.powderChamber.P2; }));
  assert.ok(noP2.notes.some((n) => /P2/.test(n) && /shoulder/i.test(n)), noP2.notes.join('|'));
  const noPrimer = build(variant('223_rem', (r) => { delete r.annotations.primerType; }));
  assert.equal(noPrimer.walls.pocket, null);
  assert.ok(noPrimer.notes.some((n) => /primer/i.test(n)));
  const noP1 = build(variant('223_rem', (r) => { delete r.cartridge.powderChamber.P1; }));
  assert.ok(noP1.notes.some((n) => /P1/.test(n)));
});

test('all 25 records build, publish every value they need, and produce no notes', () => {
  assert.equal(records.length, 25);
  for (const r of records) {
    const m = build(r);
    assert.deepEqual(m.notes, [], r.key);
    assert.ok(m.profile.length > 5, r.key);
    assert.ok(m.profile.every((q) => q[0] >= 0 && Number.isFinite(q[0]) && Number.isFinite(q[1])), r.key);
    for (let i = 1; i < m.profile.length; i++) assert.ok(m.profile[i][1] >= m.profile[i - 1][1] - 1e-9, `${r.key} z order at ${i}`);
    for (let i = 1; i < m.walls.inner.length; i++) assert.ok(m.walls.inner[i][1] >= m.walls.inner[i - 1][1] - 1e-9, `${r.key} inner z order`);
    assert.ok(m.walls.inner.every((q) => q[0] > 0), `${r.key} inner radius positive`);
  }
});

test('rule 9: a shoulder with only some of alpha, L1, L2 published is drawn straight and says which are missing', () => {
  const m = build(variant('223_rem', (r) => { delete r.cartridge.lengths.L2; }));
  assert.ok(m.notes.some((n) => /Shoulder/.test(n) && /L2/.test(n)), m.notes.join('|'));
  closePoint(m.profile[m.profile.length - 1], [3.215, 44.7], 1e-9);
  assert.ok(!m.dimensions.some((d) => ['L1', 'L2', 'P2', 'H1', 'alpha'].includes(d.id)));
  // none published at all: straight by rule 4, nothing to report
  assert.deepEqual(build('9_mm_luger').notes, []);
});

test('rule 9: a G1 dimension that would not touch the visible shank is left out and noted', () => {
  const m = build(variant('223_rem', (r) => { r.cartridge.lengths.L6 = 45.2; })); // nose starts inside the case
  assert.ok(!m.dimensions.some((d) => d.id === 'G1'));
  assert.ok(m.notes.some((n) => /G1 dimension/.test(n)), m.notes.join('|'));
});

test('a record that cannot be drawn gives a model with notes, never an exception', () => {
  const m = build(variant('223_rem', (r) => { delete r.cartridge.lengths.L3; }));
  assert.ok(m.notes.some((n) => /L3/.test(n)));
  assert.ok(m.svg.includes('aria-label="223 Rem. drawing"'));
  assert.deepEqual(m.dimensions, []);
});
