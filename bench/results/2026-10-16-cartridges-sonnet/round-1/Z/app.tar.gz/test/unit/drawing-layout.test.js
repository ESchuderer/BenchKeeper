'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const drawing = require('../../js/drawing.js');
const { records, byKey, variant, close } = require('./helpers.js');

const build = (r) => drawing.build(typeof r === 'string' ? byKey(r) : r);
const ids = (m) => m.dimensions.map((d) => d.id).sort();

/* independent geometry helpers for the checks */
function segHitsBox(s, b, pad = 0) {
  const [[x1, y1], [x2, y2]] = s;
  let t0 = 0, t1 = 1;
  const dx = x2 - x1, dy = y2 - y1;
  const clip = (p, q) => {
    if (p === 0) return q >= 0;
    const r = q / p;
    if (p < 0) { if (r > t1) return false; if (r > t0) t0 = r; } else { if (r < t0) return false; if (r < t1) t1 = r; }
    return true;
  };
  return clip(-dx, x1 - (b.x - pad)) && clip(dx, b.x + b.w + pad - x1) && clip(-dy, y1 - (b.y - pad)) && clip(dy, b.y + b.h + pad - y1);
}
const boxesOverlap = (a, b, pad = 0) => a.x < b.x + b.w + pad && b.x < a.x + a.w + pad && a.y < b.y + b.h + pad && b.y < a.y + a.h + pad;

test('dimensions: L3, L6, R1, R, P1 always; P2, H1, H2, G1, L1, L2, E1 and alpha where published', () => {
  assert.deepEqual(ids(build('223_rem')), ['E1', 'G1', 'H1', 'H2', 'L1', 'L2', 'L3', 'L6', 'P1', 'P2', 'R', 'R1', 'alpha']);
  assert.deepEqual(ids(build('9_mm_luger')), ['E1', 'G1', 'H2', 'L3', 'L6', 'P1', 'R', 'R1']);
  assert.deepEqual(ids(build('9_3_x_74_r')), ['G1', 'H1', 'H2', 'L1', 'L2', 'L3', 'L6', 'P1', 'P2', 'R', 'R1', 'alpha']);
  assert.deepEqual(ids(build('22_long_rifle')), ['G1', 'H2', 'L3', 'L6', 'P1', 'R', 'R1']);
  assert.deepEqual(ids(build('17_hmr')), ['G1', 'H1', 'H2', 'L1', 'L2', 'L3', 'L6', 'P1', 'P2', 'R', 'R1', 'alpha']);
});

test('every dimension is labelled with its symbol and value as published', () => {
  const text = (key) => Object.fromEntries(build(key).dimensions.map((d) => [d.id, d.text]));
  const t = text('223_rem');
  assert.equal(t.L3, 'L3 44.7');
  assert.equal(t.L6, 'L6 57.4');
  assert.equal(t.R1, 'R1 9.6');
  assert.equal(t.R, 'R 1.14');
  assert.equal(t.P1, 'P1 9.58');
  assert.equal(t.P2, 'P2 9');
  assert.equal(t.H1, 'H1 6.43');
  assert.equal(t.H2, 'H2 6.43');
  assert.equal(t.G1, 'G1 5.7');
  assert.equal(t.L1, 'L1 36.52');
  assert.equal(t.L2, 'L2 39.55');
  assert.equal(t.E1, 'E1 8.43');
  assert.equal(t.alpha, '\u03b1 46\u00b0');
  assert.equal(text('308_win').L3, 'L3 51.18');
  assert.equal(text('6_5_x_55_se').alpha, '\u03b1 50\u00b035\'2"');
});

test('dimension lines have arrowheads and extension lines', () => {
  for (const d of build('308_win').dimensions) {
    if (d.id === 'alpha') { assert.ok(d.arrows.length >= 1 && d.leader, 'alpha leader with arrowhead'); continue; }
    assert.equal(d.extensions.length, 2, `${d.id} extension lines`);
    assert.equal(d.arrows.length, 2, `${d.id} arrowheads`);
    assert.ok(d.line, `${d.id} dimension line`);
  }
});

test('true to scale: 1 user unit = 1 mm, axis horizontal, head on the left, outside view above, section below', () => {
  const m = build('223_rem');
  const xs = m.outline.flat().map((p) => p[0]);
  close(Math.min(...xs.filter((x) => x > -1e-9)), 0, 1e-9, 'head face at x = 0');
  close(Math.max(...xs), 57.4, 1e-9, 'bullet tip at x = L6');
  const ys = m.outline.flat().map((p) => p[1]);
  close(Math.min(...ys), -4.8, 1e-9, 'rim edge above the axis: -R1/2');
  close(Math.max(...ys), 4.8, 1e-9, 'and below it (mirror)');
  const hit = (x, y) => m.outline.some(([[x1, y1], [x2, y2]]) => Math.abs(x1 - x2) < 1e-9 && Math.abs(x1 - x) < 1e-9 && Math.min(y1, y2) - 1e-6 <= y && y <= Math.max(y1, y2) + 1e-6);
  assert.ok(hit(44.7, -3.215), 'mouth face above the axis at H2/2');
  assert.ok(hit(44.7, 3.215), 'mouth face below the axis at H2/2');
  assert.ok(hit(0, 0.5) || hit(0, -0.5), 'head face');
});

test('view box and svg: width and height in mm equal the view box, accessible name, title block, hatching', () => {
  const m = build('223_rem');
  const { x, y, w, h } = m.viewBox;
  const svg = m.svg;
  assert.ok(svg.startsWith('<svg'));
  assert.ok(svg.includes(`viewBox="${x} ${y} ${w} ${h}"`));
  assert.ok(svg.includes(`width="${w}mm"`) && svg.includes(`height="${h}mm"`));
  assert.ok(svg.includes('role="img"') && svg.includes('aria-label="223 Rem. drawing"'));
  assert.ok(svg.includes('<pattern'));
  assert.match(svg, /class="hatch"[^>]*fill="url\(#hatch-223_rem\)"|fill="url\(#hatch-223_rem\)"[^>]*class="hatch"/);
  assert.match(svg, /class="centre"/);
  for (const s of ['223 Rem.', 'C.I.P. table I', '2017-05-17', 'Dimensions in mm', 'Scale']) assert.ok(svg.includes(s), s);
  // scale of the A4 print (190 mm wide) is shown in the title block
  close(m.scale, 190 / w, 1e-9);
  assert.ok(svg.includes(`Scale ${m.scale.toFixed(1)} : 1`), `scale text ${m.scale.toFixed(1)}`);
  assert.ok(m.titleBlock.w > 0 && m.titleBlock.h > 0);
  // special characters in names are escaped
  assert.ok(build('40_s_w').svg.includes('aria-label="40 S.&amp; W. drawing"'));
  assert.equal(build('40_s_w').svg.includes('S.& W'), false);
});

test('font size grows with the drawing so that text stays readable when scaled to a phone', () => {
  const small = build('22_long_rifle'), big = build('9_3_x_74_r');
  assert.ok(small.fontSize >= 1.6 && big.fontSize <= 4.0);
  assert.ok(big.fontSize > small.fontSize);
});

test('labels never overlap each other, the outline, other dimension lines or the title block (all 25 records)', () => {
  for (const r of records) {
    const m = build(r);
    assert.equal(m.labels.length, m.dimensions.length, r.key);
    const boxes = m.labels.map((l) => l.box);
    const vb = m.viewBox;
    for (const [i, a] of boxes.entries()) {
      const id = m.labels[i].id;
      assert.ok(a.x >= vb.x - 1e-6 && a.y >= vb.y - 1e-6 && a.x + a.w <= vb.x + vb.w + 1e-6 && a.y + a.h <= vb.y + vb.h + 1e-6, `${r.key} ${id} inside view box`);
      for (let j = i + 1; j < boxes.length; j++) assert.ok(!boxesOverlap(a, boxes[j]), `${r.key}: ${id} overlaps ${m.labels[j].id}`);
      for (const s of [...m.outline, m.centre]) assert.ok(!segHitsBox(s, a), `${r.key}: ${id} touches the outline or centre line`);
      for (const d of m.dimensions) {
        if (d.id === id) continue;
        for (const s of [...d.extensions, d.line, d.leader].filter(Boolean)) {
          assert.ok(!segHitsBox(s, a), `${r.key}: ${id} touches a line of ${d.id}`);
        }
      }
      assert.ok(!boxesOverlap(a, m.titleBlock), `${r.key}: ${id} overlaps the title block`);
    }
  }
});

test('label boxes are large enough for their text (monospace width 0.6 em)', () => {
  for (const r of records) {
    const m = build(r);
    for (const l of m.labels) {
      const along = l.rotate ? l.box.h : l.box.w;
      assert.ok(along >= l.text.length * 0.6 * m.fontSize, `${r.key} ${l.id} box ${along} for "${l.text}"`);
    }
  }
});

test('missing values: dimensions of features that are not drawn are omitted, the drawing stays whole', () => {
  const m = build(variant('223_rem', (r) => { delete r.cartridge.caseHead.E1; delete r.cartridge.projectile.G1; }));
  assert.ok(!ids(m).includes('E1') && !ids(m).includes('G1'));
  assert.ok(m.svg.includes('<svg'));
  assert.ok(m.notes.length >= 2);
});
