'use strict';
const records = require('../../data/cartridges.js');

const byKey = (key) => records.find((r) => r.key === key);
const clone = (o) => JSON.parse(JSON.stringify(o));

/** Copy of a record with `mutate(copy)` applied (never touches the data). */
function variant(key, mutate) {
  const r = clone(byKey(key));
  mutate(r);
  return r;
}

function close(actual, expected, eps, message) {
  if (!(Math.abs(actual - expected) <= eps)) {
    throw new Error(`${message || 'value'}: expected ${expected} +/- ${eps}, got ${actual}`);
  }
}

function closePoint(actual, expected, eps, message) {
  close(actual[0], expected[0], eps, `${message || 'point'} r`);
  close(actual[1], expected[1], eps, `${message || 'point'} z`);
}

/** Smallest distance from point p=[r,z] to the polyline pts. */
function distanceToPolyline(p, pts) {
  let best = Infinity;
  for (let i = 0; i + 1 < pts.length; i++) {
    const [r1, z1] = pts[i], [r2, z2] = pts[i + 1];
    const dr = r2 - r1, dz = z2 - z1, len2 = dr * dr + dz * dz;
    let t = len2 ? ((p[0] - r1) * dr + (p[1] - z1) * dz) / len2 : 0;
    t = Math.max(0, Math.min(1, t));
    best = Math.min(best, Math.hypot(p[0] - (r1 + t * dr), p[1] - (z1 + t * dz)));
  }
  return best;
}

/** Radius of a z-monotonic polyline [[r,z]...] at z (last match wins on vertical steps). */
function radiusAt(pts, z) {
  let found = null;
  for (let i = 0; i + 1 < pts.length; i++) {
    const [r1, z1] = pts[i], [r2, z2] = pts[i + 1];
    if (z1 <= z && z <= z2 && z2 > z1) found = r1 + ((z - z1) / (z2 - z1)) * (r2 - r1);
  }
  return found;
}

module.exports = { records, byKey, variant, close, closePoint, distanceToPolyline, radiusAt, clone };
