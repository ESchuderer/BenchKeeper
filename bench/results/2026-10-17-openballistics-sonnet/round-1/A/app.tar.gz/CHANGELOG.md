# Changelog

All notable changes to OpenBallistics are recorded in this file.

The format follows [Keep a Changelog 1.1.0](https://keepachangelog.com/en/1.1.0/), and the project
follows [Semantic Versioning 2.0.0](https://semver.org/spec/v2.0.0.html); RELEASING.md says what
those mean for a repository that is a dataset, a set of libraries and a website at once.

Each release has a heading `## [X.Y.Z] - YYYY-MM-DD`, newest first, under an `## [Unreleased]`
section that collects changes as they merge. Under a heading, entries are grouped as **Added**,
**Changed**, **Deprecated**, **Removed**, **Fixed** and **Security**, one bullet per change. The
release workflow publishes the text of a release's section as the release description, so write
each entry for a reader of the release page.

## [Unreleased]

### Added

- The dataset: C.I.P. cartridge and chamber records grouped by family, synthetic sample bullet
  records and published target faces, as JSON in `data/`.
- Framework-free TypeScript libraries in `lib/` for geometry, drawing, bullets, targets and
  personal data.
- The Svelte website in `site/`, which browses the dataset and draws its records.
- Continuous integration, deployment of the site to GitHub Pages, tag-triggered releases and
  Dependabot updates.
- A comparison of two cartridges at `#/compare/<a>/<b>`: their case profiles overlaid at one scale
  and a table of every dimension either publishes, with the difference where both do, in the chosen
  units. It opens
  from the `Compare with` control on a cartridge's page, in English and German.

[Unreleased]: https://github.com/PiMetry/OpenBallistics/commits/main
