# Contributing to OpenBallistics

Thank you for helping. The README explains how to install, develop, test and build; this file
covers how a change gets into `main`.

## Before you start

- **Found a wrong figure or drawing?** Open an issue with one of the
  [templates](.github/ISSUE_TEMPLATE) and name the source you are reading the right value from.
  That is the most useful thing you can send, and you do not need to touch any JSON.
- **Want to fix it yourself, or to change code?** Open a pull request. For anything larger than a
  correction (a new feature, a change to the shape of the records, new records), open an issue first
  so the idea can be agreed before you spend time on it.

## Making a change

1. Fork the repository and branch from `main`.
2. Make the change. Keep a pull request to one subject.
3. In `site/`, run `npm test` and `npm run build`. They are what CI runs, and a pull request
   needs both to pass.
4. If the change is something a user of the data, libraries or site would notice, add a line to the
   `## [Unreleased]` section of [CHANGELOG.md](CHANGELOG.md), under the right heading
   (Added, Changed, Deprecated, Removed, Fixed or Security). Maintainers will help with the wording.
5. Open a pull request against `main` with a title in the format below and fill in the template.

### Data changes

- A record is one JSON file in `data/cartridges/<family>/`, `data/bullets/` or `data/targets/`. Keep
  the file name equal to the record's key (`key` or `id`) and keep the existing formatting: two-space
  indentation, keys in the order the file already uses.
- Cite your source in the pull request: the document and its revision, or the measurement and
  how you took it. Do not paste copyrighted tables or text; a figure and a reference are enough.
- Corrections to the cartridge records are checked against the C.I.P. sheet they come from. If a
  record disagrees with the sheet on purpose (a correction of the sheet itself), say so and why.
- Run `npm test` in `site/`. The tests parse and draw every record, and some of them state how many
  records each folder has. If your change adds or removes a file and a count fails, say so in the
  pull request rather than editing the tests unasked; a maintainer will decide.
- Do not edit generated files. `site/src/lib/*.generated.json` and `site/public/flags/` are
  produced by `npm run prepare-data` and are git-ignored.

### Code changes

- `lib/` stays free of any UI framework and free of import cycles; `site/src/lib/boundaries.test.ts`
  enforces both.
- Add or update a test with the change. The tests for `lib/` live beside the code and run with
  `npm test` in `site/`.
- `site/UI.md` describes the components and styling conventions of the site.
- Files in `fixtures/` are reference data for the tests; change them only together with the drawings
  they describe.

## Commit convention

The project uses [Conventional Commits 1.0.0](https://www.conventionalcommits.org/en/v1.0.0/).

```
<type>(<optional scope>): <summary>

<optional body: what and why, wrapped at about 72 columns>

<optional footers, e.g. BREAKING CHANGE: ..., Closes #123>
```

| Type       | Use it for                                                              |
| ---------- | ----------------------------------------------------------------------- |
| `feat`     | a new capability of the site or the libraries                           |
| `fix`      | a bug fix in the site or the libraries                                  |
| `data`     | adding, correcting or removing records in `data/`                       |
| `perf`     | a change that improves performance                                      |
| `refactor` | a change that neither fixes a bug nor adds a capability                 |
| `docs`     | documentation only                                                      |
| `test`     | tests and fixtures only                                                 |
| `build`    | the build, the dependencies and `site/package.json`                     |
| `ci`       | workflows and other automation in `.github/`                            |
| `chore`    | anything else that does not touch what users see                        |
| `revert`   | reverting an earlier commit                                             |

- The scope is optional and lowercase. Useful ones are `cartridges`, `bullets`, `targets`, `lib`,
  `site`, `deps` and the name of a module (`render2d`).
- Write the summary in the imperative, lowercase, without a final full stop, and keep the first
  line to about 72 characters.
- A breaking change has `!` after the type or scope and a `BREAKING CHANGE:` footer saying what
  breaks. A breaking change is one that makes a published record, a library API or a URL of the
  site stop working for someone who relied on it.

Examples:

```
data(cartridges): correct the L3 of 9 mm Luger
feat(site): add a unit selector to the target scoring page
fix(render2d): stop the bullet drawing overflowing at a zero meplat
ci: build the site with the Pages base path
feat(lib)!: rename the userdata export format version
```

Pull requests are squash-merged, so the **pull request title** is what lands on `main` and it is
what the `PR title` check validates. The commits inside the pull request are not checked, but
following the convention there too makes them easier to review. Releases are numbered from these
types: see [RELEASING.md](RELEASING.md).

## Review

A maintainer reviews every pull request. Expect questions about sources for data and about tests
for code; both are part of keeping the dataset trustworthy.
