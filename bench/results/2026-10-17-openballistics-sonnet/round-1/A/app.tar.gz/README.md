# OpenBallistics

An open database of cartridges, bullets and targets, with the code that draws them.

- **`data/`**: the database, as one JSON record per file: C.I.P. cartridge and chamber
  records grouped by family (`data/cartridges/`), bullet records (`data/bullets/`) and target
  faces (`data/targets/`).
- **`lib/`**: framework-free TypeScript libraries: geometry, SVG rendering of cartridges, chambers
  and bullets, target scoring, and the import/export of personal data.
- **`site/`**: the Svelte website that browses the data and uses the libraries. It is what is
  published to GitHub Pages, and it is where the repository's `package.json` lives.
- **`fixtures/`**: reference drawings and profiles that the tests compare against.

The repository is one npm project, in `site/`. `lib/` has no `package.json` of its own: its tests
run with the site's.

## Requirements

Node.js 22 (the version in `.nvmrc`) with npm. Nothing else is needed.

## Install

```sh
cd site
npm ci
```

## Develop

```sh
cd site
npm run dev
```

This builds the generated search index and field sets from `data/`, then starts the Vite dev
server, which serves the records straight from `data/`. Edit a record or a library and reload.

The two generated steps can also be run alone: `npm run index` and `npm run fieldsets`, or both
with `npm run prepare-data`. Their output is git-ignored.

## Test

```sh
cd site
npm test
```

This runs every test in the repository, including those under `lib/`. It regenerates the index
first, so the tests always see the current `data/`. To run one file, pass its path:
`npm test -- src/lib/data.test.ts`.

## Build

```sh
cd site
npm run build
npm run preview
```

`build` regenerates the index, type-checks the site with `svelte-check` and writes the static site
to `site/dist/`. `preview` serves that directory locally. To build for a project page, set the base
path: `PAGES_BASE=/OpenBallistics/ npm run build`. The default, `/`, suits `npm run dev` and a
site served from the root of a domain.

## Continuous integration and deployment

- `.github/workflows/ci.yml` runs `npm test` and `npm run build` on every pull request and on
  every push to `main`.
- `.github/workflows/pr-title.yml` checks that a pull request's title follows the commit
  convention below.
- `.github/workflows/pages.yml` publishes the site to GitHub Pages on every push to `main`.
- `.github/workflows/release.yml` publishes a release when a version tag is pushed.
- `.github/dependabot.yml` opens weekly pull requests for npm and GitHub Actions updates.

## Contributing

Pull requests are welcome. [CONTRIBUTING.md](CONTRIBUTING.md) has the whole workflow; in short:

1. Fork, branch from `main`, and make the change.
2. Run `npm test` and `npm run build` in `site/`; CI runs the same two commands.
3. Open a pull request with a title in the commit convention.

### Contributing data

Every record is a JSON file named after its key, in `data/`. Fix a wrong or missing value by
editing the file that holds it, and say **where you read the correct value** (the C.I.P. sheet and
its revision, a manufacturer's page, a measurement and the instrument) in the pull request. A
change to a record is checked against its source, so a change without one cannot be merged. If
you only have a suspicion, or no pull request to offer, use one of the
[issue templates](.github/ISSUE_TEMPLATE) instead. They ask for the same details.

After a data change, run `npm test` in `site/`. The tests read the files in `data/`, so a record
that cannot be parsed, drawn or listed fails them. The cartridge, bullet and target tests also
state how many records there are, so adding or removing a file fails a test too; mention it in
the pull request, or open an issue first. `data/bullets/README.md` says what the bullet catalogue
holds today.

### Commit convention

Commits, and the titles of pull requests (which become commits, since pull requests are squash
merged), follow [Conventional Commits 1.0.0](https://www.conventionalcommits.org/en/v1.0.0/):

```
<type>(<optional scope>): <summary>
```

The types are `feat`, `fix`, `data`, `perf`, `refactor`, `docs`, `test`, `build`, `ci`, `chore`
and `revert`. `data` is this project's own type, for changes to the records in `data/`; a
breaking change is marked with `!` after the type or scope. For example:
`data(cartridges): correct the L3 of 9 mm Luger`. CONTRIBUTING.md has the details.

## Releases

The version is kept in `site/package.json`, releases are tags named `v<version>`, and
[CHANGELOG.md](CHANGELOG.md) records them in the [Keep a Changelog](https://keepachangelog.com/en/1.1.0/)
format. [RELEASING.md](RELEASING.md) describes how a maintainer makes a release.

## License

The code and the data are released under the [MIT License](LICENSE). Third-party software that
the site uses or redistributes, and the terms it comes with, are listed in
[THIRD-PARTY.md](THIRD-PARTY.md). By contributing you agree that your contribution is released
under the same license, so submit only data you are free to share: your own measurements, or
published dimensions with a citation.
