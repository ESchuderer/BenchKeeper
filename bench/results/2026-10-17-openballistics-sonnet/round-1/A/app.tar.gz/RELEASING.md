# Releasing

This file is for maintainers.

## Versioning

OpenBallistics uses [Semantic Versioning 2.0.0](https://semver.org/spec/v2.0.0.html). One version
covers the whole repository (data, libraries and site), because they change together and the site
is built from the data.

**The version is kept in `site/package.json`**, with `site/package-lock.json` following it. A
release is a git tag `v<version>` on a commit on `main`, and `CHANGELOG.md` holds its notes.

What the numbers mean:

| Bump  | When                                                                                         |
| ----- | -------------------------------------------------------------------------------------------- |
| major | a breaking change: a field of a record is renamed or removed, a library API or a URL changes incompatibly |
| minor | something is added: a feature, records, an optional field                                    |
| patch | something is fixed: a corrected value or drawing, a bug fix, no new capability               |

Before 1.0.0 a breaking change bumps the minor version instead. The commit types in
[CONTRIBUTING.md](CONTRIBUTING.md) map onto this: `feat` is minor, `fix` and `data` corrections are
patch, `!` or a `BREAKING CHANGE:` footer is major, and the rest do not need a release by
themselves. Choosing the number is a maintainer's call.

## Changelog

`CHANGELOG.md` follows [Keep a Changelog 1.1.0](https://keepachangelog.com/en/1.1.0/). Entries
collect under `## [Unreleased]` as changes merge. A release heading is exactly
`## [X.Y.Z] - YYYY-MM-DD`; the release workflow looks for it and fails without it.

## Making a release

1. Branch from an up-to-date `main`.
2. Set the version:

   ```sh
   cd site
   npm version 0.2.0 --no-git-tag-version
   ```

   This edits `site/package.json` and `site/package-lock.json` and nothing else.
3. In `CHANGELOG.md`, rename `## [Unreleased]` to `## [0.2.0] - <today>` and add a new empty
   `## [Unreleased]` above it. Update the link definitions at the foot of the file:
   `[Unreleased]` becomes `https://github.com/PiMetry/OpenBallistics/compare/v0.2.0...HEAD` and a
   `[0.2.0]` definition points to the comparison with the previous tag (or to
   `https://github.com/PiMetry/OpenBallistics/releases/tag/v0.2.0` for the first release).
4. Check the result without publishing anything:

   ```sh
   node scripts/release-notes.mjs v0.2.0
   ```

   It prints the release notes, or says what disagrees.
5. Open a pull request titled `chore(release): 0.2.0`, wait for CI and merge it.
6. Tag the merge commit and push the tag:

   ```sh
   git checkout main && git pull
   git tag -a v0.2.0 -m "v0.2.0"
   git push origin v0.2.0
   ```

The `Release` workflow then checks that the tag is on `main` and that the tag, `site/package.json`,
`site/package-lock.json` and `CHANGELOG.md` agree, runs the tests and the build, and creates a
GitHub release whose description is the changelog section and which carries a tarball of the built
site. A version with a hyphen (`0.3.0-rc.1`) is published as a pre-release. If the workflow fails
before the release exists, fix the cause, delete the tag (`git push --delete origin v0.2.0`) and tag
again.

The site is deployed by the `Deploy site` workflow on every push to `main`, not by the release, so
the released site is the one already live when the release pull request merges.

## One-time repository setup

These are settings on GitHub; they are not in the repository.

- **Pages**: Settings > Pages > Build and deployment > Source: *GitHub Actions*. The `github-pages`
  environment that the deploy job uses is then created, and by default only `main` may deploy to it.
- **Merging**: Settings > General > Pull Requests: allow squash merging only, with the default
  commit message set to *Pull request title*, so that the validated title becomes the commit.
- **Branch protection** for `main`: require a pull request and require the status checks
  `Test and build` and `Conventional title`.
- **Tags**: add a tag ruleset for `v*` so that only maintainers can create release tags.
- **Dependabot**: it is enabled by `.github/dependabot.yml`. Its pull requests run the same checks
  as any other and have conventional titles (`chore(deps): …`, `ci(deps): …`).

The workflows need no secrets: they use only the token
GitHub gives each run. Actions are pinned by commit hash, with the version in a comment, and
Dependabot keeps both up to date.
