// Check that a release is consistent and print its notes.
//
//   node scripts/release-notes.mjs v0.2.0
//
// The version lives in site/package.json and site/package-lock.json (`npm version` keeps the two
// together). A release names it three times - the tag, those files and a CHANGELOG.md heading - and
// this script fails unless all three agree. On success it prints the body of that changelog
// section, which the release workflow uses as the release description. It has no dependencies, so
// it runs before `npm ci`.

import { readFileSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = join(dirname(fileURLToPath(import.meta.url)), '..');
const fail = (message) => {
  console.error(`release-notes: ${message}`);
  process.exit(1);
};

const argument = process.argv[2];
if (!argument) fail('usage: node scripts/release-notes.mjs <version or vX.Y.Z tag>');
const version = argument.replace(/^v/, '');
if (!/^\d+\.\d+\.\d+(-[0-9A-Za-z.-]+)?$/.test(version)) fail(`"${argument}" is not a semantic version`);

const json = (path) => JSON.parse(readFileSync(join(root, path), 'utf8'));
const lock = json('site/package-lock.json');
const recorded = {
  'site/package.json': json('site/package.json').version,
  'site/package-lock.json': lock.version,
  'site/package-lock.json (packages[""])': lock.packages?.['']?.version
};
for (const [where, found] of Object.entries(recorded)) {
  if (found !== version) fail(`${where} says ${found}, the release is ${version}. Run: cd site && npm version ${version} --no-git-tag-version`);
}

const lines = readFileSync(join(root, 'CHANGELOG.md'), 'utf8').split(/\r?\n/);
const escaped = version.replace(/[.+*?^${}()|[\]\\]/g, '\\$&');
const heading = new RegExp(`^## \\[${escaped}\\] - \\d{4}-\\d{2}-\\d{2}\\s*$`);
const start = lines.findIndex((line) => heading.test(line));
if (start < 0) fail(`CHANGELOG.md has no "## [${version}] - YYYY-MM-DD" section`);

// The section runs to the next version heading, or to the link definitions at the foot of the file.
let end = lines.findIndex((line, index) => index > start && (/^## /.test(line) || /^\[[^\]]+\]: /.test(line)));
if (end < 0) end = lines.length;
const notes = lines.slice(start + 1, end).join('\n').trim();
if (!notes) fail(`the CHANGELOG.md section for ${version} is empty`);

process.stdout.write(`${notes}\n`);
