import { readFileSync } from 'node:fs';
import { resolve } from 'node:path';
import { describe, expect, it } from 'vitest';
import { FIELD_LABELS, FIELD_UNITS, formatValue, type Record_ } from '@lib/core';
import { caseOuterProfile, adaptMetallic, type CartridgeRecord } from '@lib/shapes2d';
import { compareRows, difference, dimensionsOf, lengthText, outerProfile, overlay } from './compare';
import { entries } from './data';
import { displayNumber } from './units';
import { setLang, t } from './i18n.svelte';

const DATA = resolve(__dirname, '../../../data/cartridges');
const record = (key: string): Record_ => {
  const family = entries.find((entry) => entry.key === key)!.family;
  return JSON.parse(readFileSync(resolve(DATA, family, `${key}.json`), 'utf8'));
};

const a = record('308_win');
const b = record('300_win_mag');

describe('dimensionsOf', () => {
  it('lists the millimetre figures of the cartridge part in the detail page order, without tolerances', () => {
    const symbols = dimensionsOf(a).map((d) => d.symbol);
    expect(symbols).toEqual([
      'L1', 'L2', 'L3', 'L6', 'R', 'R1', 'E', 'E1', 'e min', 'f', 'P1', 'P2', 'S', 'r1 min', 'r2', 'H1', 'H2', 'G1',
      'L3 + G', 'Fe', 'delta L'
    ]);
    expect(symbols.some((symbol) => symbol.endsWith('Tol'))).toBe(false);
  });

  it('leaves out angles, pressures, energies and every other field that has a unit of its own', () => {
    const fields = dimensionsOf(a).map((d) => d.field);
    for (const field of ['alpha', 'beta', 'delta', 'Pmax', 'PK', 'PE', 'EE', 'M']) expect(fields).not.toContain(field);
    for (const field of fields) expect(Object.keys(FIELD_UNITS)).not.toContain(field);
  });

  it('does not take values from the chamber', () => {
    // The chamber publishes F, Z, D and others too; none of them is a dimension of the cartridge.
    expect(dimensionsOf(a).map((d) => d.field)).not.toContain('Z');
  });

  it('writes a symbol as the detail page does', () => {
    const e = dimensionsOf(a).find((d) => d.field === 'eMin');
    expect(e?.symbol).toBe(FIELD_LABELS.eMin);
    expect(e?.symbol).toBe('e min');
  });

  it('skips repeating groups, strings, nulls and non-finite numbers', () => {
    const odd = {
      cartridge: {
        lengths: [{ marking: '12/70', l: 70 }],
        collar: { H1: null, H2: '8.7' },
        misc: { Fe: Number.NaN, deltaL: 0.1 }
      }
    } as unknown as Record_;
    expect(dimensionsOf(odd)).toEqual([{ field: 'deltaL', symbol: 'delta L', value: 0.1 }]);
  });
});

describe('difference', () => {
  it('is B minus A in decimal, not in binary floating point', () => {
    expect(12.01 - 11.96).not.toBe(0.05);
    expect(difference(11.96, 12.01)).toBe(0.05);
    expect(difference(0.1, 0.3)).toBe(0.2);
    expect(difference(51.18, 48.26)).toBe(-2.92);
    expect(difference(1.37, 1.37)).toBe(0);
    expect(Object.is(difference(1.37, 1.37), 0)).toBe(true);
  });
  it('falls back to subtraction where the decimals cannot be counted', () => {
    expect(difference(1e-7, 3e-7)).toBeCloseTo(2e-7, 20);
  });
});

describe('compareRows', () => {
  it('has one row for each symbol either cartridge publishes, and no other', () => {
    const rows = compareRows(a, b, 'metric');
    const symbols = rows.map((row) => row.symbol);
    const published = new Set([...dimensionsOf(a), ...dimensionsOf(b)].map((d) => d.symbol));
    expect(new Set(symbols)).toEqual(published);
    expect(new Set(symbols).size).toBe(symbols.length);
    expect(symbols).toContain('delta L');
    expect(symbols).toContain('R3');
  });

  it('leaves a cartridge\'s cell and the difference empty where it does not publish the dimension', () => {
    const rows = compareRows(a, b, 'metric');
    const deltaL = rows.find((row) => row.symbol === 'delta L')!;
    expect(deltaL).toEqual({ symbol: 'delta L', a: formatValue(dimensionsOf(a).find((d) => d.symbol === 'delta L')!.value), b: '', difference: '' });
    const r3 = rows.find((row) => row.symbol === 'R3')!;
    expect(r3).toEqual({ symbol: 'R3', a: '', b: formatValue(dimensionsOf(b).find((d) => d.symbol === 'R3')!.value), difference: '' });
    for (const row of rows.filter((row) => row.a && row.b)) expect(row.difference).not.toBe('');
  });

  it('keeps A\'s order and puts a dimension only B publishes after the one before it in B', () => {
    const rows = compareRows(a, b, 'metric').map((row) => row.symbol);
    const own = dimensionsOf(a).map((d) => d.symbol);
    expect(rows.filter((symbol) => own.includes(symbol))).toEqual(own);
    const theirs = dimensionsOf(b).map((d) => d.symbol);
    const before = theirs[theirs.indexOf('R3') - 1]!;
    expect(rows.indexOf('R3')).toBe(rows.indexOf(before) + 1);
  });

  it('writes metric values as the detail page does, with Difference as B minus A', () => {
    const rows = compareRows(a, b, 'metric');
    const l3 = rows.find((row) => row.symbol === 'L3')!;
    expect(l3.a).toBe(formatValue(51.18));
    expect(l3.b).toBe(formatValue((b.cartridge.lengths as Record<string, number>).L3!));
    expect(l3.difference).toBe(formatValue(difference(51.18, (b.cartridge.lengths as Record<string, number>).L3!)));
    const r1 = rows.find((row) => row.symbol === 'R1')!;
    expect(r1.a).toBe('12.01');
  });

  it('converts imperial lengths and differences with displayNumber, and rounds nothing else', () => {
    const rows = compareRows(a, b, 'imperial');
    const l3 = rows.find((row) => row.symbol === 'L3')!;
    const [x, y] = [51.18, (b.cartridge.lengths as Record<string, number>).L3!];
    expect(l3.a).toBe(displayNumber(x, 'in'));
    expect(l3.b).toBe(displayNumber(y, 'in'));
    expect(l3.difference).toBe(displayNumber(difference(x, y), 'in'));
    expect(l3.a).toBe('2.01496062992');
  });

  it('lists dimensions that nothing shares, each with one cell empty', () => {
    const none = { cartridge: { lengths: { L1: 1 } } } as unknown as Record_;
    const other = { cartridge: { lengths: { L2: 1 } } } as unknown as Record_;
    expect(compareRows(none, other, 'metric')).toEqual([
      { symbol: 'L2', a: '', b: '1', difference: '' },
      { symbol: 'L1', a: '1', b: '', difference: '' }
    ]);
    expect(compareRows({ cartridge: {} }, { cartridge: {} }, 'metric')).toEqual([]);
  });

  it('writes a zero difference as 0', () => {
    expect(lengthText(0, 'metric')).toBe('0');
    expect(lengthText(0, 'imperial')).toBe('0');
  });
});

describe('the profile overlay', () => {
  const [pa, pb] = [outerProfile(a)!, outerProfile(b)!];

  it('uses the profile caseOuterProfile computes', () => {
    expect(pa).toEqual(caseOuterProfile(adaptMetallic(a as unknown as CartridgeRecord)));
  });

  it('has no profile for a shot cartridge or for a record too thin to draw', () => {
    expect(outerProfile({ family: 'shotshell' })).toBeNull();
    expect(outerProfile({ family: 'rimless', cartridge: {} } as unknown as Record_)).toBeNull();
  });

  it('draws each case as one closed path, at one scale, on one axis with the head faces together', () => {
    const o = overlay([pa, pb]);
    expect(o.paths).toHaveLength(2);
    const box = (d: string) => {
      const points = [...d.matchAll(/[ML]([-\d.]+),([-\d.]+)/g)].map((m) => [Number(m[1]), Number(m[2])] as const);
      const xs = points.map((p) => p[0]), ys = points.map((p) => p[1]);
      return { x0: Math.min(...xs), x1: Math.max(...xs), y0: Math.min(...ys), y1: Math.max(...ys) };
    };
    const [boxA, boxB] = o.paths.map(box) as [ReturnType<typeof box>, ReturnType<typeof box>];
    for (const d of o.paths) expect(d.trim().endsWith('Z')).toBe(true);
    // Head faces at one x; one unit is one millimetre, so lengths are the records' own.
    expect(boxA.x0).toBeCloseTo(o.headX, 6);
    expect(boxB.x0).toBeCloseTo(o.headX, 6);
    expect(boxA.x1 - boxA.x0).toBeCloseTo(51.18, 6);
    expect(boxB.x1 - boxB.x0).toBeCloseTo((b.cartridge.lengths as Record<string, number>).L3!, 6);
    // Both are symmetric about the one axis.
    for (const bx of [boxA, boxB]) expect((bx.y0 + bx.y1) / 2).toBeCloseTo(o.axisY, 6);
    // The 308's widest part is its 12.01 mm rim.
    expect(boxA.y1 - boxA.y0).toBeCloseTo(12.01, 6);
    expect(o.width).toBeGreaterThan(Math.max(boxA.x1, boxB.x1));
  });
});

describe('the German texts', () => {
  it('names the controls in German, and the English ones are the spec\'s', () => {
    const english = ['compare.with', 'compare.action', 'compare.symbol', 'compare.difference'].map((key) => t(key));
    expect(english).toEqual(['Compare with', 'Compare', 'Symbol', 'Difference']);
    expect(t('compare.profiles', { a: '308 Win.', b: '300 Win. Mag.' })).toBe('Profiles of 308 Win. and 300 Win. Mag.');
    expect(t('compare.dimensions', { unit: 'in' })).toBe('Dimensions (in)');
    setLang('de');
    try {
      expect(t('compare.with')).toBe('Vergleichen mit');
      expect(t('compare.action')).toBe('Vergleichen');
      expect(t('compare.difference')).toBe('Differenz');
      expect(t('compare.profiles', { a: 'A', b: 'B' })).toBe('Profile von A und B');
      expect(t('compare.dimensions', { unit: 'mm' })).toBe('Maße (mm)');
    } finally {
      setLang('en');
    }
  });
});
