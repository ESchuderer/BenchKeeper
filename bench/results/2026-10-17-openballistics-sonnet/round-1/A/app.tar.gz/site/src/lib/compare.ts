/**
 * What the comparison page puts side by side: the dimensions two records publish, and the
 * outer profiles of their cases on one axis.
 *
 * Framework-free, so the page stays markup and the rules are testable without a browser. The
 * figures are the records' own: nothing is rounded here, and the one thing computed - a
 * difference - is computed in decimal, so that 12.01 - 11.96 is the 0.05 the two sheets differ by
 * and not the 0.05000000000000071 that binary floating point makes of it.
 */

import {
  FIELD_LABELS,
  FIELD_UNITS,
  GROUP_ORDER,
  formatValue,
  orderedFields,
  type Group,
  type Record_
} from '@lib/core';
import { fullSectionPath, viewportFor, type Profile } from '@lib/geom';
import { adaptMetallic, caseOuterProfile, type CartridgeRecord } from '@lib/shapes2d';
import { displayNumber, type UnitSystem } from './units';

/** One dimension of a record: the field it is stored under, how the sheet writes it, its value. */
export interface Dimension {
  field: string;
  symbol: string;
  value: number;
}

export interface ComparedRow {
  symbol: string;
  /** `a` and `b` are empty where that cartridge does not publish the dimension. */
  a: string;
  b: string;
  /** B minus A; empty unless both publish the dimension. */
  difference: string;
}

const hasUnit = (field: string): boolean => Object.hasOwn(FIELD_UNITS, field);

/**
 * The dimensions a record's `cartridge` part publishes, in the order the detail page lists them.
 *
 * A dimension is a number in millimetres: a field with an entry in `FIELD_UNITS` is a pressure, an
 * energy, an angle or a count, a tolerance belongs to the dimension before it, and a repeating
 * group (a shot cartridge's hull lengths) has no single value for a symbol. The chamber is the
 * other side of the sheet and is not compared. A symbol that two groups share keeps its first
 * value, which is the one the page lists first.
 */
export function dimensionsOf(record: Pick<Record_, 'cartridge'>): Dimension[] {
  const groups = record.cartridge ?? {};
  const known = GROUP_ORDER.cartridge.filter((name) => name in groups);
  const placed = new Set(known);
  const rest = Object.keys(groups).filter((name) => !placed.has(name)).sort();
  const found = new Map<string, Dimension>();
  for (const name of [...known, ...rest]) {
    const group = groups[name];
    if (!group || Array.isArray(group)) continue;
    for (const field of orderedFields('cartridge', name, group)) {
      const value = (group as Group)[field];
      if (typeof value !== 'number' || !Number.isFinite(value)) continue;
      if (field.endsWith('Tol') || hasUnit(field)) continue;
      const symbol = FIELD_LABELS[field] ?? field;
      if (!found.has(symbol)) found.set(symbol, { field, symbol, value });
    }
  }
  return [...found.values()];
}

function decimalPlaces(value: number): number | null {
  const text = String(value);
  if (/e/i.test(text)) return null;
  const point = text.indexOf('.');
  return point < 0 ? 0 : text.length - point - 1;
}

/** `b - a` as the decimals the two numbers are written with, free of floating-point noise. */
export function difference(a: number, b: number): number {
  const placesA = decimalPlaces(a);
  const placesB = decimalPlaces(b);
  if (placesA === null || placesB === null) return b - a;
  const scale = 10 ** Math.max(placesA, placesB);
  const [scaledA, scaledB] = [Math.round(a * scale), Math.round(b * scale)];
  if (!Number.isSafeInteger(scaledA) || !Number.isSafeInteger(scaledB)) return b - a;
  // A quotient by a power of ten is the nearest double to the decimal, which prints as itself.
  return (scaledB - scaledA) / scale + 0;
}

/** A length in millimetres as the page writes it in the chosen system: the sheet's text or inches. */
export function lengthText(millimetres: number, system: UnitSystem): string {
  return system === 'metric' ? (formatValue(millimetres) ?? '') : displayNumber(millimetres, 'in');
}

/**
 * One row for each symbol either record publishes. Where a record does not publish it, its cell
 * and the difference are empty.
 *
 * The rows follow the detail page's order (A's); a symbol only B publishes goes after the symbol
 * that precedes it in B, so that it sits where B's page lists it.
 */
export function compareRows(a: Pick<Record_, 'cartridge'>, b: Pick<Record_, 'cartridge'>, system: UnitSystem): ComparedRow[] {
  const first = dimensionsOf(a);
  const second = dimensionsOf(b);
  const symbols = first.map((dimension) => dimension.symbol);
  let last = -1;
  for (const { symbol } of second) {
    const at = symbols.indexOf(symbol);
    if (at >= 0) last = at;
    else symbols.splice(++last, 0, symbol);
  }
  const ofA = new Map(first.map((dimension) => [dimension.symbol, dimension]));
  const ofB = new Map(second.map((dimension) => [dimension.symbol, dimension]));
  return symbols.map((symbol) => {
    const [x, y] = [ofA.get(symbol), ofB.get(symbol)];
    return {
      symbol,
      a: x ? lengthText(x.value, system) : '',
      b: y ? lengthText(y.value, system) : '',
      difference: x && y ? lengthText(difference(x.value, y.value), system) : ''
    };
  });
}

/**
 * The case's outer half-profile, or `null` where the record has none to give: a shot cartridge
 * (out of scope for the drawing) or a metallic record that publishes too little to draw.
 */
export function outerProfile(record: Pick<Record_, 'family'>): Profile | null {
  if (record.family === 'shotshell') return null;
  try {
    return caseOuterProfile(adaptMetallic(record as unknown as CartridgeRecord));
  } catch {
    return null;
  }
}

export interface Overlay {
  /** The extent of the drawing, in millimetres: the viewBox is `0 0 width height`. */
  width: number;
  height: number;
  /** Where the common axis lies, as a y coordinate. */
  axisY: number;
  /** Where the head faces lie, as an x coordinate. */
  headX: number;
  /** One closed outline per case, in the order given. */
  paths: string[];
}

/**
 * The full outlines of the given half-profiles in one frame.
 *
 * One viewport from all of them, at one millimetre to a unit: the scale is shared by
 * construction, the cases lie along one axis, and both head faces are at z = 0, which the
 * viewport puts at the same x. The cases lie as the site draws them on its cards, head to the left.
 */
export function overlay(profiles: Profile[]): Overlay {
  const view = viewportFor(profiles, { scale: 1, marginMm: 2, frame: 'landscape' });
  const [headX, axisY] = view.xy(0, 0);
  return {
    width: view.width,
    height: view.height,
    axisY,
    headX,
    paths: profiles.map((profile) => fullSectionPath(profile, view))
  };
}
