<script lang="ts">
  import PageHeader from '../components/PageHeader.svelte';
  import ScaleRuler from '../components/ScaleRuler.svelte';
  import { PX_PER_MM } from '@lib/core';
  import { compareRows, outerProfile, overlay } from '../lib/compare';
  import { load } from '../lib/data';
  import { t } from '../lib/i18n.svelte';
  import { href } from '../lib/router';
  import { unitSystem } from '../lib/units.svelte';

  interface Props {
    /** The keys of the two cartridges, as `#/c/<key>` writes them. */
    a: string;
    b: string;
  }
  let { a, b }: Props = $props();

  // Both at once: the page is of no use with one of them, and they are fetched in parallel.
  const records = $derived(Promise.all([load(a), load(b)]));
  const system = $derived(unitSystem());
</script>

<div data-ui="Compare" class="contents">
{#await records}
  <p class="status">{t('site.loading')}</p>
{:then [first, second]}
  {@const profiles = [outerProfile(first), outerProfile(second)]}
  {@const drawn = profiles[0] && profiles[1] ? overlay([profiles[0], profiles[1]]) : null}
  {@const undrawn = [first, second].filter((_, index) => !profiles[index]).map((record) => record.name)}
  {@const rows = compareRows(first, second, system)}
  {@const unit = system === 'metric' ? 'mm' : 'in'}

  <PageHeader
    title={t('compare.title')}
    description={`${first.name} · ${second.name}`}
    backHref={href.cartridge(a)}
    backLabel={t('compare.back', { name: first.name })}
  />

  {#if drawn}
    <figure class="profiles">
      <svg
        role="img"
        aria-label={t('compare.profiles', { a: first.name, b: second.name })}
        viewBox={`0 0 ${drawn.width} ${drawn.height}`}
        style={`width:${drawn.width * PX_PER_MM}px`}
      >
        <line class="axis" x1="0" x2={drawn.width} y1={drawn.axisY} y2={drawn.axisY} vector-effect="non-scaling-stroke" />
        <path class="case a" d={drawn.paths[0]} vector-effect="non-scaling-stroke" />
        <path class="case b" d={drawn.paths[1]} vector-effect="non-scaling-stroke" />
      </svg>
      {#if system === 'metric'}
        <ScaleRuler widthMm={drawn.width} />
      {:else}
        <ScaleRuler unitsPerUnit={25.4} unit="in" />
      {/if}
      <!-- Colour alone is not a key: the second outline is also dashed, and the legend says so. -->
      <figcaption class="legend" aria-hidden="true">
        <span class="swatch a"></span>{first.name}
        <span class="swatch b"></span>{second.name}
      </figcaption>
    </figure>
  {/if}
  {#if undrawn.length}
    <p class="note">{t('compare.noDrawing', { names: undrawn.join(', ') })}</p>
  {/if}

  {#if rows.length}
    <table class="dimensions">
      <caption>{t('compare.dimensions', { unit })}</caption>
      <thead>
        <tr>
          <th scope="col">{t('compare.symbol')}</th>
          <th scope="col" class="num">{first.name}</th>
          <th scope="col" class="num">{second.name}</th>
          <th scope="col" class="num">{t('compare.difference')}</th>
        </tr>
      </thead>
      <tbody>
        {#each rows as row (row.symbol)}
          <tr>
            <td class="num symbol">{row.symbol}</td>
            <td class="num">{row.a}</td>
            <td class="num">{row.b}</td>
            <td class="num">{row.difference}</td>
          </tr>
        {/each}
      </tbody>
    </table>
    <p class="note">{t('compare.differenceNote', { a: first.name, b: second.name })}</p>
  {:else}
    <p class="note">{t('compare.noShared')}</p>
  {/if}
{:catch error}
  <p class="status error">
    {t('compare.unavailable', { message: error.message })}
    <a href={href.list()}>{t('record.back')}</a>
  </p>
{/await}
</div>

<style>
  @layer legacy {
    :global([data-ui="Compare"]) {
      --compare-a: #1d4ed8;
      --compare-b: #c2410c;
    }
    :global([data-theme="dark"] [data-ui="Compare"]) {
      --compare-a: #93c5fd;
      --compare-b: #fdba74;
    }
    :global([data-ui="Compare"] .status),
    :global([data-ui="Compare"] .note) { color: var(--ink-2); font-size: var(--step-0); }
    :global([data-ui="Compare"] .profiles) {
      margin: 0 0 2rem;
      padding: var(--panel-padding, 1rem);
      background: var(--surface);
      border: 1px solid var(--rule);
      border-radius: var(--radius);
      display: flex;
      flex-direction: column;
      align-items: center;
    }
    :global([data-ui="Compare"] .profiles svg) { max-width: 100%; height: auto; }
    :global([data-ui="Compare"] .axis) { stroke: var(--ink-3); stroke-width: 1; stroke-dasharray: 6 3 1 3; }
    :global([data-ui="Compare"] .case) { stroke-width: 2; stroke-linejoin: round; }
    :global([data-ui="Compare"] .case.a) { stroke: var(--compare-a); fill: var(--compare-a); fill-opacity: 0.12; }
    :global([data-ui="Compare"] .case.b) { stroke: var(--compare-b); fill: var(--compare-b); fill-opacity: 0.12; stroke-dasharray: 8 4; }
    :global([data-ui="Compare"] .legend) {
      display: flex; flex-wrap: wrap; align-items: center; gap: 0.4rem 0.6rem;
      margin-top: 0.75rem; font-size: var(--step-0);
    }
    :global([data-ui="Compare"] .swatch) { display: inline-block; width: 1.5rem; border-top: 3px solid; }
    :global([data-ui="Compare"] .swatch.a) { border-color: var(--compare-a); }
    :global([data-ui="Compare"] .swatch.b) { border-color: var(--compare-b); border-top-style: dashed; margin-left: 1rem; }
    :global([data-ui="Compare"] .dimensions) { width: 100%; border-collapse: collapse; font-size: var(--step-0); }
    :global([data-ui="Compare"] .dimensions caption) { caption-side: top; text-align: left; font-weight: 600; padding-bottom: 0.5rem; }
    :global([data-ui="Compare"] .dimensions th),
    :global([data-ui="Compare"] .dimensions td) { padding: 0.35rem 0.75rem; border-bottom: 1px solid var(--rule); text-align: right; }
    :global([data-ui="Compare"] .dimensions th:first-child),
    :global([data-ui="Compare"] .dimensions td.symbol) { text-align: left; }
    :global([data-ui="Compare"] .dimensions th) { color: var(--ink-3); font-weight: 500; }
    @media print {
      :global([data-ui="Compare"] .profiles) { break-inside: avoid; }
    }
  }
</style>
