## What and why

<!-- What does this change, and why? Link the issue it closes, if there is one. -->

## Source (for data changes)

<!-- Where is each figure from? The sheet and revision, the maker's page, the rulebook edition.
     A change to a record without a source cannot be merged. Delete this section for code changes. -->

## Checks

- [ ] The title follows [Conventional Commits](https://github.com/PiMetry/OpenBallistics/blob/main/CONTRIBUTING.md#commit-messages)
- [ ] `npm test` and `npm run build` pass in `site/`
- [ ] If a drawing changed, the matching file under `fixtures/` was reviewed and updated
