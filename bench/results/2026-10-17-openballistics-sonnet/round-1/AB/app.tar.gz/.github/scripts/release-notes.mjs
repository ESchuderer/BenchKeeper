// Check that a release tag is consistent with the repository, and print its release notes.
//
//   node .github/scripts/release-notes.mjs v0.2.0
//
// The tag, the version in site/package.json (and its lockfile) and the CHANGELOG.md section must
// all name the same version. The release workflow runs this before it builds anything, and a
// maintainer can run it before pushing the tag. On success the notes - the body of that
// changelog section - go to stdout; on failure the reasons go to stderr and the exit code is 1.

import { readFileSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = join(dirname(fileURLToPath(import.meta.url)), '..', '..');
const read = (path) => readFileSync(join(root, path), 'utf8');

// Semantic Versioning 2.0.0, section 2 and 9, with the leading `v` the tags carry.
const SEMVER = /^(0|[1-9]\d*)\.(0|[1-9]\d*)\.(0|[1-9]\d*)(-[0-9A-Za-z-]+(\.[0-9A-Za-z-]+)*)?$/;
const escape = (text) => text.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

const problems = [];
const tag = process.argv[2] ?? '';
const version = tag.replace(/^v/, '');

if (!tag.startsWith('v') || !SEMVER.test(version)) {
  problems.push(`"${tag}" is not a version tag: expected v<major>.<minor>.<patch>[-<prerelease>], e.g. v1.2.3`);
}

const manifest = JSON.parse(read('site/package.json'));
if (manifest.version !== version) {
  problems.push(`site/package.json has version ${manifest.version}, the tag has ${version}`);
}
const lock = JSON.parse(read('site/package-lock.json'));
for (const [where, found] of [['version', lock.version], ['packages[""].version', lock.packages?.['']?.version]]) {
  if (found !== version) problems.push(`site/package-lock.json ${where} is ${found}, the tag has ${version}`);
}

// A section starts at `## [<version>]` and ends at the next `## ` heading. The link references
// at the foot of the file (`[0.2.0]: https://...`) are not part of the last section.
const changelog = read('CHANGELOG.md').replace(/\r\n/g, '\n');
const heading = new RegExp(`^## \\[${escape(version)}\\] - \\d{4}-\\d{2}-\\d{2}[ \\t]*$`, 'm').exec(changelog);
let notes = '';
if (!heading) {
  problems.push(`CHANGELOG.md has no "## [${version}] - YYYY-MM-DD" section`);
} else {
  const rest = changelog.slice(heading.index + heading[0].length);
  const next = rest.search(/^## |^\[[^\]]+\]: /m);
  notes = (next === -1 ? rest : rest.slice(0, next)).trim();
  if (!notes) problems.push(`The CHANGELOG.md section for ${version} is empty`);
}

if (problems.length) {
  console.error(problems.map((problem) => `- ${problem}`).join('\n'));
  process.exit(1);
}
console.log(notes);
