# Changelog

All notable changes to OpenBallistics are recorded in this file.

The format follows [Keep a Changelog 1.1.0](https://keepachangelog.com/en/1.1.0/), and the project
follows [Semantic Versioning 2.0.0](https://semver.org/spec/v2.0.0.html). What a version number
promises for a database is spelled out in [RELEASING.md](RELEASING.md).

How this file is kept:

- Newest release first, under an `## [Unreleased]` heading that collects changes not yet released.
- Each release is a `## [x.y.z] - YYYY-MM-DD` heading (ISO 8601 date) followed by groups named
  `### Added`, `### Changed`, `### Deprecated`, `### Removed`, `### Fixed` and `### Security`, in
  that order, leaving out the empty ones. Each entry is one bullet.
- Corrections to existing records go under `Fixed`, new records and fields under `Added`, and
  changes to a field's meaning or a record's key under `Changed` and `Removed`.
- Maintainers write it when a release is prepared, from the Conventional Commit history, not
  contributors in their pull requests. The release workflow publishes the section for the tagged
  version as the release notes.
- Each version heading is linked to its release by a reference at the foot of the file.

## [Unreleased]

### Added

- The database: C.I.P. cartridge and chamber records in `data/cartridges/`, synthetic sample bullet
  records in `data/bullets/` and target specifications in `data/targets/`.
- The shared TypeScript libraries in `lib/` and the Svelte website in `site/`.
- Continuous integration on pull requests, deployment of the site to GitHub Pages, tag-triggered
  releases and automated dependency updates.
- Contributor documentation: `README.md`, `CONTRIBUTING.md` and `RELEASING.md`.

[Unreleased]: https://github.com/PiMetry/OpenBallistics/commits/main
