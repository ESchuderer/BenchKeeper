# OpenBallistics

An open database of cartridges, bullets and targets, with the libraries that draw and measure them
and a website to browse them.

- **`data/`** – the database, one JSON record per file: cartridge and chamber dimensions after the
  C.I.P. tables (`data/cartridges/<family>/`), bullets (`data/bullets/`) and target faces
  (`data/targets/`).
- **`lib/`** – framework-free TypeScript libraries: geometry, 2D drawing, target scoring, the
  cartridge and bullet designers and the user-data store.
- **`site/`** – the Svelte website. It is built with Vite, and published to GitHub Pages from `main`.
  The npm project lives here, so every `npm` command below runs in `site/`.
- **`fixtures/`** – reference output the rendering tests compare against.

The website, once Pages is enabled, is at <https://pimetry.github.io/OpenBallistics/>.

## Install

You need [Node.js](https://nodejs.org/) 22 (the version in [`.node-version`](.node-version)) and
npm, which comes with it.

```sh
git clone https://github.com/PiMetry/OpenBallistics.git
cd OpenBallistics/site
npm ci
```

`npm ci` installs exactly what `package-lock.json` says.

## Develop

From `site/`:

```sh
npm run dev
```

This regenerates the search indexes from `data/`, then starts the Vite dev server and prints its
address (`http://localhost:5173/` by default). Edits to `site/src/` and `lib/` reload in the
browser. The dev server serves the records straight from `data/`, so an edited record shows up
without a rebuild, though the search index is only regenerated when you restart `npm run dev` or
run `npm run index`.

The other scripts in `site/package.json`:

| Command                  | What it does                                                                      |
| ------------------------ | --------------------------------------------------------------------------------- |
| `npm run index`          | Builds the catalogue index and the flag set from `data/`.                         |
| `npm run fieldsets`      | Builds the field lists the forms use.                                             |
| `npm run prepare-data`   | Runs both of the above. `dev`, `test` and `build` run it for you.                 |
| `npm run sample-bullets` | Regenerates the synthetic bullets in `data/bullets/` (see its [README](data/bullets/README.md)). |
| `npm run preview`        | Serves the output of `npm run build` locally.                                     |

The generated indexes are ignored by git. Do not commit them.

## Test

From `site/`:

```sh
npm test
```

This runs [Vitest](https://vitest.dev/) over the tests in `site/src/` and in `lib/`. To run part of
the suite, pass a path:

```sh
npx vitest run src/lib/units.test.ts
npx vitest run ../lib/targets
```

## Build

From `site/`:

```sh
npm run build
```

This prepares the data, type-checks everything with `svelte-check`, and writes the site to
`site/dist/`. `npm run preview` serves it.

The site is served from the root of a domain by default. To build it for a path such as a
GitHub project page, set the base the way the Pages workflow does:

```sh
PAGES_BASE=/OpenBallistics/ npm run build
```

## Continuous integration and deployment

| Workflow                                                        | Runs on                  | Does                                                       |
| --------------------------------------------------------------- | ------------------------ | ---------------------------------------------------------- |
| [`ci.yml`](.github/workflows/ci.yml)                            | every pull request       | `npm ci`, `npm test`, `npm run build`                      |
| [`pr-title.yml`](.github/workflows/pr-title.yml)                | every pull request       | checks the title follows [Conventional Commits](#commit-messages) |
| [`pages.yml`](.github/workflows/pages.yml)                      | every push to `main`     | runs the same checks, then deploys the site to GitHub Pages |
| [`release.yml`](.github/workflows/release.yml)                  | a pushed `v*` tag        | runs the checks, then publishes a GitHub release           |

[Dependabot](.github/dependabot.yml) opens weekly pull requests for npm and GitHub Actions updates.

Run `npm test` and `npm run build` before opening a pull request, and you will have run what CI runs.

## Contribute

Everyone is welcome to send corrections, new records and fixes. [CONTRIBUTING.md](CONTRIBUTING.md)
has the details; in short:

- **Data.** Records are JSON files in `data/`. Fix a value or add a record by editing or adding a
  file, and say where the figure comes from. [CONTRIBUTING.md](CONTRIBUTING.md#contributing-data)
  describes the layout and what a record needs. If you would rather not edit JSON, open an issue
  with one of the templates: [a cartridge problem](https://github.com/PiMetry/OpenBallistics/issues/new?template=data.yml), [a bullet
  problem](https://github.com/PiMetry/OpenBallistics/issues/new?template=bullet.yml) or [a site problem](https://github.com/PiMetry/OpenBallistics/issues/new?template=site-feedback.yml).
- **Code.** Fork, branch from `main`, make a change, run the tests and the build, and open a pull
  request.
- **Commit messages and pull request titles** follow [Conventional Commits](https://www.conventionalcommits.org/en/v1.0.0/),
  for example `fix(cartridges): correct L3 of 308 Win.` See [below](#commit-messages).

### Commit messages

```
<type>(<scope>): <summary>
```

Types: `feat`, `fix`, `data`, `docs`, `style`, `refactor`, `perf`, `test`, `build`, `ci`, `chore`,
`revert`. The scope is optional. A `!` after the type or scope, or a `BREAKING CHANGE:` footer,
marks a change that breaks users of the data or the libraries. The full convention, with examples,
is in [CONTRIBUTING.md](CONTRIBUTING.md#commit-messages).

## Versions and releases

The version is kept in one place: the `version` field of [`site/package.json`](site/package.json)
(and its copy in `site/package-lock.json`). It follows [Semantic Versioning](https://semver.org/).
Releases are made by pushing a tag `vX.Y.Z`; the release workflow publishes the site build and a
data archive. Changes are recorded in [CHANGELOG.md](CHANGELOG.md), in the
[Keep a Changelog](https://keepachangelog.com/en/1.1.0/) format. [RELEASING.md](RELEASING.md)
explains how a release is made and what the version numbers mean for a database.

## License

The project is released under the [MIT License](LICENSE), Copyright (c) 2026 PiMetry. The software
the project uses and the files it redistributes in the built site (flags, Svelte, IBM Plex fonts)
are listed with their own licenses in [THIRD-PARTY.md](THIRD-PARTY.md). By contributing you agree
that your contribution is released under the same MIT License.
