# Releasing OpenBallistics

Notes for maintainers: where the version lives, what a version number means, how a release is made
and the settings the repository needs once.

## Where the version is kept

In one place: the `version` field of [`site/package.json`](site/package.json), together with its
copy in `site/package-lock.json` (the top-level `version` and the `packages[""]` entry). The git
tag is derived from it: version `1.2.3` is released as tag `v1.2.3`.

The release workflow refuses to publish unless the tag, those three fields and
[CHANGELOG.md](CHANGELOG.md) all name the same version. Use `npm version` (below) rather than
editing the fields by hand, because it changes all of them together.

## What a version number means

The project follows [Semantic Versioning 2.0.0](https://semver.org/). A release is one number for
the whole repository: the database in `data/`, the libraries in `lib/` and the website in `site/`.
For a database the "public API" is the shape and meaning of the records, and the exports of `lib/`.

| Bump      | When                                                                                                                                                  | Commits since the last release                              |
| --------- | ----------------------------------------------------------------------------------------------------------------------------------------------------- | ----------------------------------------------------------- |
| **Major** | A change that can break something reading the data or using the libraries: a field removed, renamed or given another meaning or unit, a record key changed or a record removed, a `lib/` export removed or changed incompatibly. | any commit marked `!` or with a `BREAKING CHANGE:` footer   |
| **Minor** | Backward-compatible additions: new records, new optional fields, new features of the site or the libraries.                                           | `feat` and `data` commits that add                          |
| **Patch** | Corrections that change no shape: a corrected figure or source, a bug fix, a dependency update.                                                       | `fix` and `data` commits that correct                       |

Before 1.0.0 (the `0.y.z` versions) anything may change: a breaking change bumps the minor version,
and additions and fixes bump the patch version.

Docs, tests, build, CI and refactoring commits alone do not need a release.

## Making a release

You need push rights to `main` and tags. Nothing here is run by hand that the workflow can do.

1. **Decide the version.** List what has landed since the last tag and apply the table above. For
   the first release, the version in `site/package.json` (`0.1.0`) is already the one to ship.

   ```sh
   git switch main && git pull
   git log --oneline "$(git describe --tags --abbrev=0)"..HEAD   # before the first release: git log --oneline
   ```

2. **Prepare the release on a branch** named `release/vX.Y.Z`, from `main`.

   - Set the version in `site/` (skip this for the very first release):

     ```sh
     cd site
     npm version X.Y.Z --no-git-tag-version
     ```

   - In `CHANGELOG.md`, turn what is under `## [Unreleased]` into `## [X.Y.Z] - YYYY-MM-DD`,
     sorted into the `Added`, `Changed`, `Deprecated`, `Removed`, `Fixed` and `Security` groups,
     and leave an empty `## [Unreleased]` above it. Write entries for people, not commit subjects.
   - At the foot of the file, add the link
     `[X.Y.Z]: https://github.com/PiMetry/OpenBallistics/releases/tag/vX.Y.Z` and change the
     `[Unreleased]` link to `https://github.com/PiMetry/OpenBallistics/compare/vX.Y.Z...HEAD`.

3. **Check it** from the repository root, the way the workflow will:

   ```sh
   node .github/scripts/release-notes.mjs vX.Y.Z    # prints the release notes, or says what disagrees
   cd site && npm test && npm run build
   ```

4. **Merge it.** Commit as `chore(release): vX.Y.Z`, open a pull request with that title, and
   squash-merge it once the checks pass.

5. **Tag the merge commit and push the tag.**

   ```sh
   git switch main && git pull
   git tag -a vX.Y.Z -m "vX.Y.Z"
   git push origin vX.Y.Z
   ```

6. **Watch the Release workflow.** It runs the same checks as a pull request, confirms the tag is
   on `main` and that the version, lockfile and changelog agree, builds the site, and creates a
   GitHub release titled `vX.Y.Z` whose notes are the changelog section. It attaches:

   - `openballistics-site-vX.Y.Z.tar.gz`, the static site, built for the root of a domain;
   - `openballistics-data-vX.Y.Z.tar.gz`, the `data/` directory alone;
   - `SHA256SUMS`, their checksums.

   A tag with a suffix, such as `v1.0.0-rc.1`, is published as a pre-release. Its changelog
   heading is `## [1.0.0-rc.1] - YYYY-MM-DD`.

The released site is the one already on GitHub Pages: the [Deploy site](.github/workflows/pages.yml)
workflow publishes every push to `main`, so the merge in step 4 deployed it.

### If a release fails

If the workflow fails before it creates the release, nothing was published. Fix the cause on
`main`, then move the tag:

```sh
git push --delete origin vX.Y.Z
git tag -d vX.Y.Z
git tag -a vX.Y.Z -m "vX.Y.Z" && git push origin vX.Y.Z
```

Once a release exists, do not move its tag. Delete the release, or leave it and publish the next
patch version.

## One-time repository setup

These are settings of the repository on GitHub, not files, so they cannot be committed.

- **Pages.** Settings > Pages > Source: *GitHub Actions*. The Deploy site workflow publishes to
  the `github-pages` environment it creates.
- **Merging.** Settings > General: allow squash merging only, and set the default commit message
  to the pull request title. The title check exists because the title becomes the commit.
- **Protect `main`.** Require a pull request and require the status checks `Test and build` (from
  CI) and `Conventional title` (from Pull request title) before merging.
- **Protect release tags.** A tag ruleset on `v*` so only maintainers can create them; a tag
  triggers a release.
- **Fork pull requests.** Settings > Actions > General: require approval for workflows from
  first-time contributors. The workflows use the `pull_request` event with a read-only token and
  no secrets, so a fork cannot reach anything with them.
- **Dependabot.** Enable Dependabot alerts and security updates. Version updates are configured in
  [`.github/dependabot.yml`](.github/dependabot.yml) and open weekly.
- **Private vulnerability reporting**, which [CONTRIBUTING.md](CONTRIBUTING.md) points to.

## Notes on the automation

- The workflows reference actions by major version (`actions/checkout@v4`), which Dependabot keeps
  current. Pinning them to commit SHAs is stricter, and Dependabot can maintain SHA pins too, if
  you want that.
- Node is set by [`.node-version`](.node-version), which all workflows read.
- Dependabot pull requests are titled in the Conventional Commits format (`build(deps): ...`,
  `ci: ...`), so they pass the title check.
