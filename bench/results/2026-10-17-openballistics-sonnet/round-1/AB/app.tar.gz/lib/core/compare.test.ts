/**
 * Which dimensions two cartridges are compared on, read from the dataset rather than invented, so
 * that a change to what the records publish cannot quietly diverge from what these expect.
 */

import { existsSync, readFileSync } from 'node:fs';
import { join } from 'node:path';
import { describe, expect, it } from 'vitest';
import { comparedDimensions, dimensionsOf } from './compare';
import type { Record_ } from './types';
import { CARTRIDGES } from '../testing/fixtures';

function record(key: string): Record_ {
  for (const family of ['rimless', 'rimmed', 'belted', 'pistol', 'rimfire', 'shotshell']) {
    const path = join(CARTRIDGES, family, `${key}.json`);
    if (existsSync(path)) return JSON.parse(readFileSync(path, 'utf8')) as Record_;
  }
  throw new Error(`no record for ${key}`);
}

const made = (cartridge: Record_['cartridge']): Pick<Record_, 'cartridge'> => ({ cartridge });

describe('the dimensions of a record', () => {
  it('are the numbers in millimetres, and nothing else', () => {
    const dims = dimensionsOf(record('300_win_mag'));
    expect(dims.get('L3')).toBe(66.55);
    expect(dims.get('eMin')).toBe(0.94);
    expect(dims.get('L3PlusG')).toBe(74.41);
    expect(dims.get('Fe')).toBe(0.1);
    // Pressures, energies and the case mass have their own units.
    for (const field of ['Pmax', 'PK', 'PE', 'EE', 'M']) expect(dims.has(field)).toBe(false);
    // Angles are not lengths, and a tolerance is not a dimension of its own.
    for (const field of ['alpha', 'delta', 'beta', 'ETol']) expect(dims.has(field)).toBe(false);
  });

  it('skip blanks, angle objects, strings and repeating groups', () => {
    const dims = dimensionsOf(
      made({
        lengths: { L1: 10, L2: null, L3: { degrees: 1 } as never, L4: '4' },
        caseHead: { R: 1, RTol: 0.1, delta: 35 },
        collar: [{ l: 1 }] as never
      })
    );
    expect([...dims.entries()]).toEqual([['L1', 10], ['R', 1]]);
  });

  it('keep the first of a symbol that two groups both carry', () => {
    const dims = dimensionsOf(made({ misc: { F: 2 }, projectile: { F: 1 } }));
    expect(dims.get('F')).toBe(1);
  });
});

describe('the dimensions two records are compared on', () => {
  it('are those either publishes, written as the detail page writes the symbol', () => {
    const rows = comparedDimensions(record('308_win'), record('300_win_mag'));
    const symbols = rows.map((row) => row.symbol);
    expect(symbols).toContain('e min');
    expect(symbols).toContain('L3 + G');
    expect(symbols).toContain('r1 min');
    expect(new Set(symbols).size).toBe(symbols.length);
    const l3 = rows.find((row) => row.field === 'L3');
    expect(l3).toMatchObject({ symbol: 'L3', a: 51.18, b: 66.55 });
  });

  it('keep a dimension only one of them publishes, empty on the other side', () => {
    const rows = comparedDimensions(record('308_win'), record('300_win_mag'));
    expect(rows.find((row) => row.field === 'deltaL')).toEqual({ field: 'deltaL', symbol: 'delta L', a: 0.1, b: null });
    expect(rows.find((row) => row.field === 'R3')).toEqual({ field: 'R3', symbol: 'R3', a: null, b: 13.51 });
  });

  it('list each one once, whichever record has it', () => {
    const rows = comparedDimensions(made({ lengths: { L1: 1, L2: 2 } }), made({ lengths: { L2: 3, L3: 4 } }));
    expect(rows).toEqual([
      { field: 'L1', symbol: 'L1', a: 1, b: null },
      { field: 'L2', symbol: 'L2', a: 2, b: 3 },
      { field: 'L3', symbol: 'L3', a: null, b: 4 }
    ]);
  });

  it('follow the detail page order, not the alphabet', () => {
    const rows = comparedDimensions(
      made({ powderChamber: { P1: 1 }, lengths: { L3: 1, L1: 1 }, caseHead: { R: 1 } }),
      made({ lengths: { L1: 2, L3: 2 }, caseHead: { R: 2 }, powderChamber: { P1: 2 } })
    );
    expect(rows.map((row) => row.field)).toEqual(['L1', 'L3', 'R', 'P1']);
  });

  it('place a dimension only the second publishes after its predecessor in that record', () => {
    const rows = comparedDimensions(
      made({ lengths: { L1: 1, L3: 1 }, caseHead: { R: 1, E: 1 } }),
      made({ lengths: { L1: 2, L2: 2, L3: 2 }, caseHead: { R: 2, R1: 2, E: 2 } })
    );
    expect(rows.map((row) => row.field)).toEqual(['L1', 'L2', 'L3', 'R', 'R1', 'E']);
    expect(comparedDimensions(made({ caseHead: { R: 1 } }), made({ lengths: { L1: 2 }, caseHead: { R: 2 } })).map((row) => row.field)).toEqual(['L1', 'R']);
  });

  it('are none for two records that publish none', () => {
    expect(comparedDimensions(made({}), made({}))).toEqual([]);
  });
});
