/**
 * What two cartridges can be set side by side on: the dimensions either of them publishes.
 *
 * Framework-free and unit-free. Values stay in the record's millimetres; writing them in the
 * reader's unit is the app's job (`site/src/lib/compare.ts`).
 */

import { FIELD_LABELS, FIELD_UNITS, GROUP_ORDER, orderedFields } from './fields';
import { toleranceFor } from './format';
import type { Record_ } from './types';

/** One dimension at least one of the cartridges publishes, with the symbol the detail page writes it as. */
export interface ComparedDimension {
  /** The field name in the record, which is what matches the two records up. */
  field: string;
  /** The sheet's notation: `e min`, `L3 + G`. */
  symbol: string;
  /** Millimetres, as the record has it; `null` where the first cartridge does not publish it. */
  a: number | null;
  /** Millimetres, as the record has it; `null` where the second cartridge does not publish it. */
  b: number | null;
}

/**
 * The record's dimensions: the numbers of its `cartridge` part that are lengths in millimetres.
 *
 * A field is a dimension unless the sheet gives it another unit (`FIELD_UNITS`: pressures,
 * energies, angles, the marking) or it is the tolerance on another field. An angle is an object
 * and a blank is `null`, so neither is a number. Where two groups carry the same symbol the one
 * the detail page lists first wins. Keyed by field name, in the order the detail page lists them.
 */
export function dimensionsOf(record: Pick<Record_, 'cartridge'>): Map<string, number> {
  const found = new Map<string, number>();
  const groups = record.cartridge ?? {};
  const names = [
    ...GROUP_ORDER.cartridge.filter((name) => name in groups),
    ...Object.keys(groups).filter((name) => !GROUP_ORDER.cartridge.includes(name)).sort()
  ];
  for (const name of names) {
    const group = groups[name];
    // A repeating group (a shot cartridge's hull lengths) is a table of rows, not a field.
    if (!group || Array.isArray(group)) continue;
    for (const field of orderedFields('cartridge', name, group)) {
      const value = group[field];
      if (typeof value !== 'number' || !Number.isFinite(value)) continue;
      if (field in FIELD_UNITS || toleranceFor(field) !== null) continue;
      if (!found.has(field)) found.set(field, value);
    }
  }
  return found;
}

/**
 * The dimensions either record publishes, in the order the detail page lists them. A dimension
 * only the second record publishes goes in after the one that precedes it in that record's list,
 * so it stays beside its neighbours instead of collecting at the end.
 */
export function comparedDimensions(a: Pick<Record_, 'cartridge'>, b: Pick<Record_, 'cartridge'>): ComparedDimension[] {
  const first = dimensionsOf(a);
  const second = dimensionsOf(b);
  const fields = [...first.keys()];
  let anchor = -1;
  for (const field of second.keys()) {
    const at = fields.indexOf(field);
    if (at >= 0) anchor = at;
    else fields.splice(++anchor, 0, field);
  }
  return fields.map((field) => ({
    field,
    symbol: FIELD_LABELS[field] ?? field,
    a: first.get(field) ?? null,
    b: second.get(field) ?? null
  }));
}
