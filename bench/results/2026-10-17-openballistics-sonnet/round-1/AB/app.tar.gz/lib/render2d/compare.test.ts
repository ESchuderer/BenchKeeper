import { existsSync, readFileSync } from 'node:fs';
import { join } from 'node:path';
import { describe, expect, it } from 'vitest';
import { renderProfileOverlaySvg } from './compare';
import { adaptMetallic, caseOuterProfile, type CartridgeRecord } from '../shapes2d';
import { CARTRIDGES } from '../testing/fixtures';

function outline(key: string) {
  for (const family of ['rimless', 'rimmed', 'belted', 'pistol', 'rimfire']) {
    const path = join(CARTRIDGES, family, `${key}.json`);
    if (existsSync(path)) return caseOuterProfile(adaptMetallic(JSON.parse(readFileSync(path, 'utf8')) as CartridgeRecord));
  }
  throw new Error(`no record for ${key}`);
}

/** The points of each closed outline in the markup, in user units. */
function outlines(svg: string): [number, number][][] {
  return [...svg.matchAll(/<path [^>]*\bd="([^"]+)"/g)].map((m) =>
    [...m[1]!.matchAll(/[ML]([-\d.]+),([-\d.]+)/g)].map((p) => [Number(p[1]), Number(p[2])] as [number, number])
  );
}
const span = (values: number[]) => [Math.min(...values), Math.max(...values)] as const;

describe('the overlay of two case outlines', () => {
  const a = outline('308_win');
  const b = outline('300_win_mag');
  const svg = renderProfileOverlaySvg([a, b], { label: 'Profiles of 308 Win. and 300 Win. Mag.' });
  const [first, second] = outlines(svg);

  it('is one image with the label as its name, and one path per outline', () => {
    expect(svg).toMatch(/^<svg [^>]*role="img"/);
    expect(svg).toContain('aria-label="Profiles of 308 Win. and 300 Win. Mag."');
    expect(outlines(svg)).toHaveLength(2);
    expect(svg).not.toMatch(/<(polyline|polygon)/);
  });

  it('escapes the name it is given', () => {
    const named = renderProfileOverlaySvg([a], { label: 'a "b" <c> & d' });
    expect(named).toContain('aria-label="a &quot;b&quot; &lt;c&gt; &amp; d"');
  });

  it('draws both at one scale, in millimetres, along the same axis', () => {
    const scale = 8;
    const [x1, x2] = span(first!.map((p) => p[0]));
    const [x3, x4] = span(second!.map((p) => p[0]));
    // Case length: the mouth lies L3 from the head face.
    expect(x2 - x1).toBeCloseTo(51.18 * scale, 3);
    expect(x4 - x3).toBeCloseTo(66.55 * scale, 3);
    // Heads on the same line.
    expect(x1).toBeCloseTo(x3, 6);
    // The widest point of each is its rim; both are centred on one axis.
    const [y1, y2] = span(first!.map((p) => p[1]));
    const [y3, y4] = span(second!.map((p) => p[1]));
    expect((y1 + y2) / 2).toBeCloseTo((y3 + y4) / 2, 6);
    expect(y2 - y1).toBeCloseTo(12.01 * scale, 2);
    expect(y4 - y3).toBeCloseTo(13.51 * scale, 2);
    const axis = svg.match(/<line class="axis"[^>]*y1="([-\d.]+)"/)!;
    expect(Number(axis[1])).toBeCloseTo((y1 + y2) / 2, 6);
  });

  it('fits both in the viewBox', () => {
    const [, , w, h] = svg.match(/viewBox="([^"]+)"/)![1]!.split(' ').map(Number);
    for (const [x, y] of [...first!, ...second!]) {
      expect(x).toBeGreaterThanOrEqual(0);
      expect(x).toBeLessThanOrEqual(w!);
      expect(y).toBeGreaterThanOrEqual(0);
      expect(y).toBeLessThanOrEqual(h!);
    }
  });
});
