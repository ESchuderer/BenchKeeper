/**
 * Case outlines overlaid: the same profile `caseOuterProfile` gives each case, drawn at one scale
 * on one axis with the head faces at one point, so that what differs between two cases is the
 * distance between their lines.
 */

import type { Profile } from '../geom/profile';
import { ANNOTATION_STROKE_MM, OUTLINE_STROKE_MM, fmt, fullSectionPath, num, viewportFor } from '../geom/svg';
import { escapeXml } from './drawing';

/** Distinguishable by hue and, with the dashes the page adds to the second, without it. */
export const COMPARE_COLOURS = ['#1f6fb2', '#c2410c'];

export interface OverlayOptions {
  /** User units per millimetre. The viewBox lets the page size the picture; this fixes the ratio. */
  scale?: number;
  /** The accessible name of the picture. */
  label: string;
  colours?: string[];
}

/**
 * One `<svg>` with each profile as one closed `<path class="profile profile-<n>">`, the case lying
 * down with its head face on the left and its axis on the horizontal centre line `<line class="axis">`.
 */
export function renderProfileOverlaySvg(profiles: Profile[], options: OverlayOptions): string {
  const view = viewportFor(profiles, { scale: options.scale ?? 8, marginMm: 2, frame: 'landscape' });
  const colours = options.colours ?? COMPARE_COLOURS;
  const [x1, y] = view.xy(0, view.zMin);
  const [x2] = view.xy(0, view.zMax);
  const stroke = num(view.length(OUTLINE_STROKE_MM * 2));
  const paths = profiles.map(
    (profile, index) =>
      `<path class="profile profile-${index}" d="${fullSectionPath(profile, view)}" fill="none" ` +
      `stroke="${colours[index % colours.length]}" stroke-width="${stroke}" stroke-linejoin="round"/>`
  );
  return [
    `<svg xmlns="http://www.w3.org/2000/svg" role="img" aria-label="${escapeXml(options.label)}" ` +
      `width="${fmt(view.width)}" height="${fmt(view.height)}" viewBox="0 0 ${fmt(view.width)} ${fmt(view.height)}">`,
    `<line class="axis" x1="${fmt(x1)}" y1="${fmt(y)}" x2="${fmt(x2)}" y2="${fmt(y)}" stroke="currentColor" ` +
      `stroke-opacity="0.45" stroke-width="${num(view.length(ANNOTATION_STROKE_MM))}" stroke-dasharray="${fmt(view.length(2))} ${fmt(view.length(1))}"/>`,
    ...paths,
    '</svg>'
  ].join('');
}
