import { existsSync, readFileSync } from 'node:fs';
import { join } from 'node:path';
import { describe, expect, it } from 'vitest';
import type { Record_ } from '@lib/core';
import { compareRows, outerProfileOf, overlaySvg, tableUnit } from './compare';
import { displayNumber } from './units';

const CARTRIDGES = join(__dirname, '../../../data/cartridges');
function record(key: string): Record_ {
  for (const family of ['rimless', 'rimmed', 'belted', 'pistol', 'rimfire', 'shotshell']) {
    const path = join(CARTRIDGES, family, `${key}.json`);
    if (existsSync(path)) return JSON.parse(readFileSync(path, 'utf8')) as Record_;
  }
  throw new Error(`no record for ${key}`);
}
const a = record('308_win');
const b = record('300_win_mag');
const row = (rows: ReturnType<typeof compareRows>, symbol: string) => rows.find((r) => r.symbol === symbol)!;

describe('the comparison table', () => {
  it('writes metric figures as the detail page does, nothing rounded', () => {
    const rows = compareRows(a, b, 'metric');
    expect(row(rows, 'L3')).toEqual({ symbol: 'L3', a: '51.18', b: '66.55', difference: '15.37' });
    // `e min` is a symbol of the sheet and not the field name.
    expect(row(rows, 'e min').b).toBe('0.94');
    expect(rows.map((r) => r.symbol)).not.toContain('eMin');
  });

  it('subtracts the first from the second without binary noise', () => {
    // 66.55 - 51 is 15.549999999999997 in floating point.
    const rows = compareRows(
      { ...a, cartridge: { lengths: { L3: 51 } } },
      { ...b, cartridge: { lengths: { L3: 66.55 } } },
      'metric'
    );
    expect(rows).toEqual([{ symbol: 'L3', a: '51', b: '66.55', difference: '15.55' }]);
    const opposite = compareRows(
      { ...b, cartridge: { lengths: { L3: 66.55 } } },
      { ...a, cartridge: { lengths: { L3: 51 } } },
      'metric'
    );
    expect(opposite[0]!.difference).toBe('-15.55');
  });

  it('writes a difference of nothing as 0', () => {
    expect(compareRows(a, a, 'metric').every((r) => r.difference === '0')).toBe(true);
    expect(compareRows(a, a, 'imperial').every((r) => r.difference === '0')).toBe(true);
  });

  it('converts lengths to inches with the unit helper, differences too', () => {
    const rows = compareRows(a, b, 'imperial');
    expect(row(rows, 'L3')).toEqual({
      symbol: 'L3',
      a: displayNumber(51.18, 'in'),
      b: displayNumber(66.55, 'in'),
      difference: displayNumber(66.55 - 51.18, 'in')
    });
    expect(row(rows, 'L3').a).toBe('2.01496062992');
  });

  it('lists a dimension only one of them publishes, leaving the other cell and the difference empty', () => {
    const rows = compareRows(a, b, 'metric');
    expect(row(rows, 'delta L')).toEqual({ symbol: 'delta L', a: '0.1', b: '', difference: '' });
    expect(row(rows, 'R3')).toEqual({ symbol: 'R3', a: '', b: '13.51', difference: '' });
    expect(row(compareRows(a, b, 'imperial'), 'R3')).toEqual({ symbol: 'R3', a: '', b: displayNumber(13.51, 'in'), difference: '' });
    // The same two cartridges the other way round swap the sides.
    expect(row(compareRows(b, a, 'metric'), 'R3')).toEqual({ symbol: 'R3', a: '13.51', b: '', difference: '' });
  });

  it('has the same rows in both unit systems', () => {
    expect(compareRows(a, b, 'imperial').map((r) => r.symbol)).toEqual(compareRows(a, b, 'metric').map((r) => r.symbol));
  });

  it('names the unit', () => {
    expect(tableUnit('metric')).toBe('mm');
    expect(tableUnit('imperial')).toBe('in');
  });
});

describe('the overlay', () => {
  it('is drawn for two cases, with the two names in its label', () => {
    const svg = overlaySvg(a, b, 'Profiles of 308 Win. and 300 Win. Mag.');
    expect(svg).toContain('role="img"');
    expect(svg).toContain('aria-label="Profiles of 308 Win. and 300 Win. Mag."');
  });

  it('is not drawn for a shot cartridge, or a record too short to draw', () => {
    const shot = record('12');
    expect(outerProfileOf(shot)).toBeNull();
    expect(overlaySvg(a, shot, 'x')).toBeNull();
    expect(outerProfileOf({ ...a, cartridge: {} })).toBeNull();
    expect(outerProfileOf(a)).not.toBeNull();
  });
});
