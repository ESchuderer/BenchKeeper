/**
 * What the comparison page shows for two cartridges: the table's rows in the reader's unit, and
 * each case's outline where the record has enough to draw one.
 *
 * Which dimensions are compared is `@lib/core/compare`, and the outline is `caseOuterProfile`; this
 * is only the part that needs the reader's unit.
 */

import { formatValue, comparedDimensions, type Record_ } from '@lib/core';
import { renderProfileOverlaySvg } from '@lib/render2d';
import type { Profile } from '@lib/geom';
import { adaptMetallic, caseOuterProfile, type CartridgeRecord } from '@lib/shapes2d';
import { defaultUnit, displayNumber, type UnitSystem } from './units';

export interface CompareRow {
  symbol: string;
  /** Empty where the first cartridge does not publish the dimension. */
  a: string;
  /** Empty where the second cartridge does not publish the dimension. */
  b: string;
  /** B minus A; empty where either cartridge does not publish the dimension. */
  difference: string;
}

/** The unit the table's lengths are written in. */
export const tableUnit = (system: UnitSystem): 'mm' | 'in' => defaultUnit('length', system) as 'mm' | 'in';

/** A published figure in millimetres as the reader's unit writes it, nothing rounded. */
function figure(millimetres: number, system: UnitSystem): string {
  return system === 'imperial' ? displayNumber(millimetres, 'in') : (formatValue(millimetres) ?? '');
}

/**
 * B minus A, written the same way. A subtraction of two published figures carries binary noise
 * (66.55 - 51 is 15.549999999999997), so a metric difference keeps the twelve significant digits
 * that `displayNumber` keeps for inches, which is the figure and not a rounding of it.
 */
function difference(a: number, b: number, system: UnitSystem): string {
  const millimetres = b - a;
  return figure(system === 'imperial' ? millimetres : Number(millimetres.toPrecision(12)), system);
}

/** One row per dimension either record publishes, in the order the detail page lists them. */
export function compareRows(a: Record_, b: Record_, system: UnitSystem): CompareRow[] {
  return comparedDimensions(a, b).map((row) => ({
    symbol: row.symbol,
    a: row.a === null ? '' : figure(row.a, system),
    b: row.b === null ? '' : figure(row.b, system),
    difference: row.a === null || row.b === null ? '' : difference(row.a, row.b, system)
  }));
}

/**
 * The outer profile of the record's case, or `null` where there is none to draw: a shot cartridge
 * has a hull and not a case, and a few records publish too little to build one.
 */
export function outerProfileOf(record: Record_): Profile | null {
  if (record.family === 'shotshell') return null;
  try {
    return caseOuterProfile(adaptMetallic(record as unknown as CartridgeRecord));
  } catch {
    return null;
  }
}

/** Both outlines in one picture, or `null` if either cannot be drawn. */
export function overlaySvg(a: Record_, b: Record_, label: string): string | null {
  const first = outerProfileOf(a);
  const second = outerProfileOf(b);
  return first && second ? renderProfileOverlaySvg([first, second], { label }) : null;
}
