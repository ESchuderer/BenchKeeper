<script lang="ts">
  import { byKey, load } from '../lib/data';
  import { compareRows, overlaySvg, tableUnit } from '../lib/compare';
  import { href } from '../lib/router';
  import { t } from '../lib/i18n.svelte';
  import { unitSystem } from '../lib/units.svelte';

  interface Props {
    a: string;
    b: string;
  }
  let { a, b }: Props = $props();

  const first = $derived(byKey(a));
  const second = $derived(byKey(b));
  const records = $derived(Promise.all([load(a), load(b)]));
</script>

<div data-ui="Compare" class="contents">
  {#await records}
    <p class="status">{t('compare.loading')}</p>
  {:then [one, two]}
    {@const system = unitSystem()}
    {@const rows = compareRows(one, two, system)}
    {@const svg = overlaySvg(one, two, t('compare.profiles', { a: one.name, b: two.name }))}
    <header class="head">
      <h1>{t('compare.heading', { a: one.name, b: two.name })}</h1>
    </header>

    <section class="profiles">
      {#if svg}
        <figure>
          <!-- The markup is the library's own, built from the records' numbers; the names reach it escaped. -->
          <div class="overlay">{@html svg}</div>
          <figcaption>
            <ul class="legend">
              <li class="first"><span class="swatch"></span><a href={href.cartridge(a)}>{one.name}</a></li>
              <li class="second"><span class="swatch"></span><a href={href.cartridge(b)}>{two.name}</a></li>
            </ul>
            <p>{t('compare.profilesNote')}</p>
          </figcaption>
        </figure>
      {:else}
        <p class="status">{t('compare.noDrawing')}</p>
      {/if}
    </section>

    <section class="dimensions">
      {#if rows.length}
        <div class="scroll">
          <table>
            <caption>{t('compare.table', { unit: tableUnit(system) })}</caption>
            <thead>
              <tr>
                <th scope="col">{t('compare.symbol')}</th>
                <th scope="col" class="num">{one.name}</th>
                <th scope="col" class="num">{two.name}</th>
                <th scope="col" class="num">{t('compare.difference')}</th>
              </tr>
            </thead>
            <tbody>
              {#each rows as row (row.symbol)}
                <tr>
                  <td class="num">{row.symbol}</td>
                  <td class="num">{row.a}</td>
                  <td class="num">{row.b}</td>
                  <td class="num">{row.difference}</td>
                </tr>
              {/each}
            </tbody>
          </table>
        </div>
        <p class="note">{t('compare.differenceNote')}</p>
      {:else}
        <p class="status">{t('compare.noDimensions')}</p>
      {/if}
    </section>

    <p class="foot">
      <a href={href.cartridge(a)}>{one.name}</a> · <a href={href.cartridge(b)}>{two.name}</a> ·
      <a href={href.list()}>{t('record.back')}</a>
    </p>
  {:catch error}
    <p class="status error">
      {error.message}
      {#if !first || !second}<a href={href.list()}>{t('record.back')}</a>{/if}
    </p>
  {/await}
</div>

<style>
  @layer legacy {
    :global([data-ui="Compare"] .head) {
      padding-bottom: var(--space-6);
      border-bottom: 1px solid var(--rule);
    }
    :global([data-ui="Compare"] h1) {
      font-size: clamp(var(--step-3), 1.2rem + 2vw, var(--step-4));
      line-height: 1.15;
      letter-spacing: -0.01em;
    }
    :global([data-ui="Compare"] section) { margin-top: 1.5rem; }
    :global([data-ui="Compare"] figure) { margin: 0; }
    :global([data-ui="Compare"] .overlay) {
      padding: var(--panel-padding);
      background: var(--surface);
      border: 1px solid var(--rule);
      border-radius: var(--radius);
      overflow-x: auto;
      color: var(--ink-3);
    }
    :global([data-ui="Compare"] .overlay svg) { display: block; width: 100%; height: auto; min-width: 20rem; }
    /* Colour for the two outlines, kept to the page so the dark theme can have its own. The second
       is dashed as well, so the pair reads in greyscale and for colour-blind readers. */
    :global([data-ui="Compare"] .profile-0) { stroke: var(--compare-a, #1f6fb2); }
    :global([data-ui="Compare"] .profile-1) { stroke: var(--compare-b, #c2410c); stroke-dasharray: 6 3; }
    :global([data-theme="dark"] [data-ui="Compare"]) { --compare-a: #6cb4f0; --compare-b: #f08a5d; }
    :global([data-ui="Compare"] .legend) { display: flex; flex-wrap: wrap; gap: 0.5rem 1.5rem; list-style: none; padding: 0; margin: 0.75rem 0 0.25rem; }
    :global([data-ui="Compare"] .legend li) { display: flex; align-items: center; gap: 0.5rem; }
    :global([data-ui="Compare"] .swatch) { display: inline-block; width: 1.5rem; border-top: 3px solid var(--compare-a, #1f6fb2); }
    :global([data-ui="Compare"] .legend .second .swatch) { border-top: 3px dashed var(--compare-b, #c2410c); }
    :global([data-ui="Compare"] figcaption p),
    :global([data-ui="Compare"] .note) { margin: 0.25rem 0 0; color: var(--ink-3); font-size: 0.78rem; }
    :global([data-ui="Compare"] .scroll) { overflow-x: auto; }
    :global([data-ui="Compare"] table) { border-collapse: collapse; font-size: var(--step-0); width: 100%; }
    :global([data-ui="Compare"] caption) {
      text-align: left;
      font-size: var(--step-1);
      letter-spacing: 0.08em;
      text-transform: uppercase;
      padding-bottom: 0.5rem;
      border-bottom: 2px solid var(--rule-strong);
      margin-bottom: 0.5rem;
    }
    :global([data-ui="Compare"] th),
    :global([data-ui="Compare"] td) { text-align: right; padding: 0.2rem 0.6rem 0.2rem 0; white-space: nowrap; }
    :global([data-ui="Compare"] th) { color: var(--ink-2); font-weight: 500; border-bottom: 1px solid var(--rule); }
    :global([data-ui="Compare"] td) { font-weight: 500; }
    :global([data-ui="Compare"] th:first-child),
    :global([data-ui="Compare"] td:first-child) { text-align: left; }
    :global([data-ui="Compare"] .status) { color: var(--ink-3); padding: 1rem 0; }
    :global([data-ui="Compare"] .status.error) { color: var(--warn); }
    :global([data-ui="Compare"] .foot) { margin-top: 2rem; }
  }
</style>
