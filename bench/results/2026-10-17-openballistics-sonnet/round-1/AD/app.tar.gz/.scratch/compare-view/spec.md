# Compare two cartridges

Status: ready-for-agent

Route `#/compare/<a>/<b>` (keys as in `#/c/<key>`), opened directly and after reload.

## Decisions

- Logic that needs no framework is in `lib/core/compare.ts` (dimension rows) and `lib/render2d/overlay.ts` (overlay geometry). The page is `site/src/routes/Compare.svelte`.
- Rows: numeric fields of the record's `cartridge` part, unit mm (no `FIELD_UNITS` entry), not ending in `Tol`, published by either record. Symbol is `FIELD_LABELS[field] ?? field`. Order is the detail page's order for A, then the symbols only B publishes in B's order. A cartridge that does not publish a symbol has an empty cell, and so does Difference.
- Difference is B minus A. Metric: `formatValue(b - a)`. Imperial: `displayNumber(value, 'in')` on each value and on the difference.
- Drawing: one SVG, `role="img"`, name `Profiles of <A> and <B>`. Full section (profile mirrored about the axis) of `caseOuterProfile`, one `path` per cartridge, common `viewportFor`, head faces at z = 0. The axis is a `line`.
- Shot cartridges, unknown keys and records that cannot be drawn show a message instead of the drawing. The table still shows where it can.
- Detail page: select `Compare with` (other cartridges by name) and button `Compare`.
- English and German texts.

## Tests

- `lib/core/compare.test.ts`, `lib/render2d/overlay.test.ts`, `site/src/lib/router.test.ts`, `site/src/lib/compare.test.ts` (formatting).
