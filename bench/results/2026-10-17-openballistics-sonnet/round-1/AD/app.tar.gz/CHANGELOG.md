# Changelog

All notable changes to OpenBallistics are recorded here.

The format follows [Keep a Changelog 1.1.0](https://keepachangelog.com/en/1.1.0/) and the project
follows [Semantic Versioning 2.0.0](https://semver.org/spec/v2.0.0.html). Each release has a
`## [x.y.z] - YYYY-MM-DD` heading, and its entries sit under the subheadings Added, Changed,
Deprecated, Removed, Fixed and Security. Unreleased changes go under `## [Unreleased]`. The release
workflow publishes the section of the tagged version as the release notes.

## [Unreleased]

### Added

- GitHub Actions workflows for pull request checks, GitHub Pages deployment and releases.
- Dependabot configuration for npm and GitHub Actions updates.
- README and CONTRIBUTING guide.
- Comparison view at `#/compare/<a>/<b>`: overlaid case outlines and the dimensions either cartridge publishes (an empty cell where one does not), in metric or imperial units. A `Compare with` select and a `Compare` button on each cartridge page open it.
