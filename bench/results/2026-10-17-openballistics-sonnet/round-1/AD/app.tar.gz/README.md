# OpenBallistics

An open database of cartridges, bullets and targets, with the libraries that draw and measure them and a website that browses them.

| Directory | Content |
|---|---|
| `data/` | The records, one JSON file each: `cartridges/<family>/`, `bullets/`, `targets/` |
| `lib/` | Shared TypeScript libraries (geometry, drawing, measurement, targets, user data) |
| `site/` | The Svelte website. It holds `package.json`, so every npm command runs from this directory |
| `fixtures/` | Reference files used by the tests |

The site is deployed to GitHub Pages at <https://pimetry.github.io/OpenBallistics/> from the `main` branch.

## Requirements

- Node.js 22 (the version in `.devcontainer/devcontainer.json` and in CI)
- npm

## Install

```sh
cd site
npm ci
```

## Develop

```sh
cd site
npm run dev
```

`dev` first runs `prepare-data`, which generates the search indexes from `data/`. The generated files are git-ignored.

## Test

```sh
cd site
npm test
```

This runs the generated-index step, then Vitest over `site/src` and `lib`.

## Build

```sh
cd site
npm run build
npm run preview
```

`build` runs `prepare-data`, `svelte-check` and the Vite production build into `site/dist/`. `preview` serves that build. For a build served below a path, as on a GitHub project page, set `PAGES_BASE`, for example `PAGES_BASE=/OpenBallistics/ npm run build`.

## Contribute

Read [CONTRIBUTING.md](CONTRIBUTING.md). In short:

- **Data:** edit or add a JSON record under `data/`, run `npm test` and `npm run build` in `site/`, and open a pull request that names the source of every changed value. To report a wrong value without editing, use the issue forms under [Issues](https://github.com/PiMetry/OpenBallistics/issues/new/choose).
- **Code:** open an issue or comment on one first for anything larger than a fix.
- **Commits and pull request titles** follow [Conventional Commits](https://www.conventionalcommits.org/en/v1.0.0/), for example `fix(site): correct the unit label` or `data(rimless): correct L3 of 308_win`.

## Versioning and releases

The version is the `version` field of `site/package.json` and follows [Semantic Versioning](https://semver.org/spec/v2.0.0.html). Releases are git tags `vX.Y.Z`, listed in [CHANGELOG.md](CHANGELOG.md) (Keep a Changelog format). The release steps are in [CONTRIBUTING.md](CONTRIBUTING.md#releasing).

## Continuous integration and updates

- `.github/workflows/ci.yml` runs `npm test` and `npm run build` on every pull request and checks the pull request title.
- `.github/workflows/pages.yml` deploys the site on every push to `main`.
- `.github/workflows/release.yml` publishes a GitHub release when a `v*.*.*` tag is pushed.
- `.github/dependabot.yml` opens weekly pull requests for npm and GitHub Actions updates.

## License

[MIT](LICENSE), copyright 2026 PiMetry. Third-party software and its notices: [THIRD-PARTY.md](THIRD-PARTY.md).
