import { readFileSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { describe, expect, it } from 'vitest';
import { dimensionRows } from './compare';
import type { Record_ } from './types';

const CARTRIDGES = join(dirname(fileURLToPath(import.meta.url)), '..', '..', 'data', 'cartridges');
const record = (family: string, key: string) =>
  JSON.parse(readFileSync(join(CARTRIDGES, family, `${key}.json`), 'utf8')) as Record_;

const make = (cartridge: Record_['cartridge']): Record_ => ({ key: 'x', name: 'X', family: 'other', cartridge, chamber: {} });

describe('dimensionRows', () => {
  it('lists numeric millimetre fields either record publishes: those of a in the detail page order, then those only b publishes', () => {
    const a = make({ lengths: { L3: 50, L1: 40, L2: null }, caseHead: { eMin: 1, R: 12 } });
    const b = make({ lengths: { L1: 41, L3: 52, L2: 9 }, caseHead: { eMin: 1.5 } });
    expect(dimensionRows(a, b)).toEqual([
      { symbol: 'L1', a: 40, b: 41 },
      { symbol: 'L3', a: 50, b: 52 },
      { symbol: 'R', a: 12, b: null },
      { symbol: 'e min', a: 1, b: 1.5 },
      { symbol: 'L2', a: null, b: 9 }
    ]);
  });

  it('leaves out tolerances, angles, pressures, strings and repeating groups', () => {
    const shared = {
      lengths: { L1: 40, L1Tol: -0.2 },
      caseHead: { delta: 35, beta: { degrees: 35 } },
      pressures: { Pmax: 4300, M: 25 },
      junctionCone: { alpha: 15 },
      misc: { note: 'text' as unknown as number }
    };
    const list = { hulls: [{ l: 76, marking: '10/76' }] as never };
    expect(dimensionRows(make({ ...shared, ...list }), make({ ...shared, ...list })).map((row) => row.symbol)).toEqual(['L1']);
  });

  it('reads real records', () => {
    const rows = dimensionRows(record('rimless', '308_win'), record('belted', '300_win_mag'));
    const l3 = rows.find((row) => row.symbol === 'L3')!;
    expect(l3.a).toBe(51.18);
    expect(l3.b).toBe(66.55);
    expect(rows.find((row) => row.symbol === 'delta L')).toMatchObject({ b: null });
    expect(rows.find((row) => row.symbol === 'R3')).toMatchObject({ a: null });
    expect(rows.map((row) => row.symbol)).toContain('e min');
    expect(rows.map((row) => row.symbol)).not.toContain('Pmax');
    expect(new Set(rows.map((row) => row.symbol)).size).toBe(rows.length);
  });
});
