/**
 * The dimensions two cartridges publish, for the side-by-side view.
 *
 * Framework-free. A dimension is a number in the record's `cartridge` part whose unit is
 * millimetres: a field with an entry in `FIELD_UNITS` is a pressure, an energy, an angle or a
 * count, and a field ending in `Tol` is a tolerance on the field before it. Neither is a row.
 */

import { FIELD_LABELS, FIELD_UNITS, GROUP_ORDER, orderedFields } from './fields';
import type { Group, Record_ } from './types';

export interface DimensionRow {
  /** The symbol as the detail page writes it, for example `e min`. */
  symbol: string;
  /** `null` where the cartridge does not publish the dimension. */
  a: number | null;
  b: number | null;
}

function dimensions(record: Record_): Map<string, number> {
  const found = new Map<string, number>();
  const groups = record.cartridge ?? {};
  const names = [...GROUP_ORDER.cartridge.filter((name) => name in groups), ...Object.keys(groups).filter((name) => !GROUP_ORDER.cartridge.includes(name)).sort()];
  for (const name of names) {
    const group = groups[name];
    // A repeating group (a shot cartridge's hull lengths) is a list of rows, not a symbol.
    if (!group || Array.isArray(group)) continue;
    for (const field of orderedFields('cartridge', name, group as Group)) {
      const value = (group as Group)[field];
      if (typeof value !== 'number' || field.endsWith('Tol') || Object.hasOwn(FIELD_UNITS, field)) continue;
      const symbol = FIELD_LABELS[field] ?? field;
      if (!found.has(symbol)) found.set(symbol, value);
    }
  }
  return found;
}

/** One row per symbol either record publishes: those of `a` in the detail page's order, then those only `b` publishes. */
export function dimensionRows(a: Record_, b: Record_): DimensionRow[] {
  const first = dimensions(a);
  const second = dimensions(b);
  return [...new Set([...first.keys(), ...second.keys()])].map((symbol) => ({
    symbol,
    a: first.get(symbol) ?? null,
    b: second.get(symbol) ?? null
  }));
}
