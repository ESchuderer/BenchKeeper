import { describe, expect, it } from 'vitest';
import { overlay } from './overlay';
import type { Profile } from '../geom';

const short: Profile = [[0, 0], [5, 0], [5, 20], [0, 20]];
const long: Profile = [[0, 0], [6, 0], [6, 40], [0, 40]];

describe('overlay', () => {
  const o = overlay([short, long], 10);

  it('makes one path per profile', () => {
    expect(o.paths).toHaveLength(2);
  });

  it('draws both at one scale with the head faces at the same x', () => {
    const xs = (path: string) => [...path.matchAll(/[ML]([\d.-]+),([\d.-]+)/g)].map((m) => [Number(m[1]), Number(m[2])] as const);
    const [a, b] = o.paths.map(xs);
    expect(Math.min(...a!.map(([x]) => x))).toBe(Math.min(...b!.map(([x]) => x)));
    const length = (p: typeof a) => Math.max(...p!.map(([x]) => x)) - Math.min(...p!.map(([x]) => x));
    expect(length(b)).toBeCloseTo(2 * length(a), 6);
  });

  it('puts the axis on the middle of the page, along the page', () => {
    expect(o.axis.y1).toBe(o.axis.y2);
    expect(o.axis.y1).toBeCloseTo(o.height / 2, 6);
    expect(o.axis.x2).toBeGreaterThan(o.axis.x1);
  });
});
