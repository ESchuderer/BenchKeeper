/** Case outlines of several cartridges overlaid on one axis at one scale, head faces together. */

import { fullSectionPath, viewportFor, type Profile } from '../geom';

export interface Overlay {
  width: number;
  height: number;
  /** One closed path per profile, in the order given. */
  paths: string[];
  /** The common axis of revolution, as page coordinates. */
  axis: { x1: number; y1: number; x2: number; y2: number };
}

const MARGIN_MM = 4;

/** Lying down, head at the left: every profile is a half profile `[radius, z]` with z = 0 at the head face. */
export function overlay(profiles: Profile[], scale = 6): Overlay {
  const view = viewportFor(profiles, { scale, marginMm: MARGIN_MM, frame: 'landscape' });
  const [x1, y] = view.xy(0, view.zMin - MARGIN_MM / 2);
  const [x2] = view.xy(0, view.zMax + MARGIN_MM / 2);
  return {
    width: view.width,
    height: view.height,
    paths: profiles.map((profile) => fullSectionPath(profile, view)),
    axis: { x1, y1: y, x2, y2: y }
  };
}
