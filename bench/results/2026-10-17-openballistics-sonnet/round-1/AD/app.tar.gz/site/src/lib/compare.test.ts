import { describe, expect, it } from 'vitest';
import { lengthText } from './compare';

describe('lengthText', () => {
  it('writes metric values as the record has them, with no rounding', () => {
    expect(lengthText(51.18, 'metric')).toBe('51.18');
    expect(lengthText(55.78 - 39.62, 'metric')).toBe('16.16');
    expect(lengthText(0.94 - 1.4, 'metric')).toBe('-0.46');
  });
  it('converts to inches with displayNumber', () => {
    expect(lengthText(25.4, 'imperial')).toBe('1');
    expect(lengthText(51.18, 'imperial')).toBe('2.01496062992');
    expect(lengthText(-0.2, 'imperial')).toBe('-0.00787401574803');
  });
});
