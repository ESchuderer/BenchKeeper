import { formatValue } from '@lib/core';
import { displayNumber, type UnitSystem } from './units';

/**
 * A length in millimetres as the page writes it: the record's own figure, or inches without
 * further rounding. The 12 significant digits are what `displayNumber` keeps; they only remove
 * binary noise from a difference (`16.160000000000004`) and leave every published figure as is.
 */
export function lengthText(mm: number, system: UnitSystem): string {
  return system === 'metric' ? (formatValue(Number(mm.toPrecision(12))) ?? '') : displayNumber(mm, 'in');
}
