<script lang="ts">
  import { overlay } from '@lib/render2d';
  import { adaptMetallic, caseOuterProfile } from '@lib/shapes2d';
  import { dimensionRows, type Record_ } from '@lib/core';
  import type { CartridgeRecord } from '@lib/shapes2d';
  import { byKey, load } from '../lib/data';
  import { lengthText } from '../lib/compare';
  import { href } from '../lib/router';
  import { t } from '../lib/i18n.svelte';
  import { unitSystem } from '../lib/units.svelte';

  let { a, b }: { a: string; b: string } = $props();

  const missing = $derived([a, b].find((key) => !byKey(key)));
  const records = $derived(Promise.all([load(a), load(b)]));

  /** The half profile of the case as manufactured, or `null` for a shot cartridge or a record that does not dimension a case. */
  function outline(record: Record_): [number, number][] | null {
    if (record.family === 'shotshell') return null;
    try {
      return caseOuterProfile(adaptMetallic(record as unknown as CartridgeRecord));
    } catch {
      return null;
    }
  }
</script>

<div data-ui="Compare" class="contents">
{#if missing}
  <p class="status error">{t('compare.unknown', { key: missing })} <a href={href.list()}>{t('record.back')}</a></p>
{:else}
{#await records}
  <p class="status">{t('record.loading', { name: `${byKey(a)?.name} / ${byKey(b)?.name}` })}</p>
{:then [first, second]}
  {@const profiles = [outline(first), outline(second)]}
  {@const undrawn = [first, second].filter((_, i) => !profiles[i]).map((record) => record.name)}
  {@const drawn = undrawn.length ? null : overlay(profiles as [number, number][][])}
  {@const system = unitSystem()}
  {@const unit = system === 'metric' ? 'mm' : 'in'}
  {@const rows = dimensionRows(first, second)}
  <header class="head">
    <h1>{t('compare.title')}</h1>
    <p class="legend">
      <a href={href.cartridge(a)} class="a">{first.name}</a> ·
      <a href={href.cartridge(b)} class="b">{second.name}</a>
    </p>
  </header>

  {#if drawn}
    <svg
      class="profiles"
      viewBox={`0 0 ${drawn.width} ${drawn.height}`}
      role="img"
      aria-label={t('compare.profiles', { a: first.name, b: second.name })}
    >
      <line x1={drawn.axis.x1} y1={drawn.axis.y1} x2={drawn.axis.x2} y2={drawn.axis.y2} stroke="currentColor" stroke-opacity="0.4" stroke-dasharray="6 4" vector-effect="non-scaling-stroke" />
      <path d={drawn.paths[0]} class="a" fill="none" stroke-width="2" vector-effect="non-scaling-stroke" />
      <path d={drawn.paths[1]} class="b" fill="none" stroke-width="2" vector-effect="non-scaling-stroke" />
    </svg>
  {:else}
    <p class="status">{t('compare.noProfile', { names: undrawn.join(', ') })}</p>
  {/if}

  {#if rows.length}
    <div class="scroll">
      <table>
        <caption>{t('compare.dimensions', { unit })}</caption>
        <thead>
          <tr>
            <th scope="col">{t('compare.symbol')}</th>
            <th scope="col" class="num">{first.name}</th>
            <th scope="col" class="num">{second.name}</th>
            <th scope="col" class="num">{t('compare.difference')}</th>
          </tr>
        </thead>
        <tbody>
          {#each rows as row (row.symbol)}
            <tr>
              <td class="num">{row.symbol}</td>
              <td class="num">{row.a === null ? '' : lengthText(row.a, system)}</td>
              <td class="num">{row.b === null ? '' : lengthText(row.b, system)}</td>
              <td class="num">{row.a === null || row.b === null ? '' : lengthText(row.b - row.a, system)}</td>
            </tr>
          {/each}
        </tbody>
      </table>
    </div>
  {:else}
    <p class="status">{t('compare.none')}</p>
  {/if}

  <p class="foot"><a href={href.list()}>{t('record.back')}</a></p>
{:catch error}
  <p class="status error">{error.message} <a href={href.list()}>{t('record.back')}</a></p>
{/await}
{/if}
</div>

<style>
  :global([data-ui="Compare"] h1) { font-size: var(--step-3); line-height: 1.15; }
  :global([data-ui="Compare"] .a) { color: #2563eb; stroke: #2563eb; }
  :global([data-ui="Compare"] .b) { color: #ea580c; stroke: #ea580c; }
  :global([data-ui="Compare"] .profiles) { width: 100%; max-height: 60vh; margin: 1.5rem 0; }
  :global([data-ui="Compare"] .scroll) { overflow-x: auto; }
  :global([data-ui="Compare"] table) { border-collapse: collapse; width: 100%; }
  :global([data-ui="Compare"] caption) { text-align: left; font-weight: 600; padding: 0.5rem 0; }
  :global([data-ui="Compare"] th), :global([data-ui="Compare"] td) { padding: 0.25rem 0.75rem; border-bottom: 1px solid var(--rule); text-align: right; }
  :global([data-ui="Compare"] tr > :first-child) { text-align: left; }
</style>
