# Changelog

All notable changes to this project are listed here. The format follows
[Keep a Changelog 1.1.0](https://keepachangelog.com/en/1.1.0/) and versions follow
[Semantic Versioning 2.0.0](https://semver.org/spec/v2.0.0.html). See CONTRIBUTING.md.

## [Unreleased]

### Added

- Compare view at `#/compare/<a>/<b>`: both case profiles at one scale and every dimension either cartridge publishes (an empty cell where one does not), with a `Compare with` control on the cartridge page.
- GitHub Actions: CI on pull requests, GitHub Pages deployment, tag-triggered release.
- Dependabot configuration for npm and GitHub Actions.
- README, CONTRIBUTING.md and this changelog.
