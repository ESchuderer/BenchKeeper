# Contributing

Setup, commands and data locations are in [README.md](README.md).

## Pull requests

1. Branch from `main`.
2. Make the change. Run `npm test` and `npm run build` in `site/`.
3. Open a pull request against `main`. The CI workflow (`.github/workflows/ci.yml`) runs on it.
4. For a change users can see (data, site behavior), add a line under `## [Unreleased]` in `CHANGELOG.md`.

By contributing you agree that your contribution is licensed under the MIT license in `LICENSE`.

## Commit convention

[Conventional Commits 1.0.0](https://www.conventionalcommits.org/en/v1.0.0/):

```
<type>(<optional scope>): <summary>
```

| Type | Use for |
| --- | --- |
| `feat` | New site or library behavior |
| `fix` | Bug fix in the site or libraries |
| `data` | Added, corrected or removed records in `data/` |
| `docs` | Documentation only |
| `style` | Formatting, no behavior change |
| `refactor` | Code change without behavior change |
| `perf` | Performance |
| `test` | Tests only |
| `build` | Dependencies, build scripts |
| `ci` | GitHub Actions and repository automation |
| `chore` | Anything else that does not change released behavior |
| `revert` | Reverts an earlier commit |

- Summary: imperative, lower case, no trailing period.
- A breaking change gets `!` after the type or scope (`feat!: ...`), or a `BREAKING CHANGE:` footer.
- Pull requests are squash-merged. The pull request title is the commit message, and CI rejects a title that does not match the convention.

## Versioning

[Semantic Versioning 2.0.0](https://semver.org/spec/v2.0.0.html). The version is kept in one place: the `version` field of `site/package.json` (`site/package-lock.json` follows it). Git tags are `vMAJOR.MINOR.PATCH`.

| Bump | When |
| --- | --- |
| MAJOR | A change that breaks the record JSON format, the user data export format (`USER_DATA_VERSION` in `lib/userdata/`) or the site's documented URLs. Before 1.0.0, such changes bump MINOR. |
| MINOR | New site feature, new records, new record fields |
| PATCH | Bug fixes and corrections to existing values |

## Changelog

`CHANGELOG.md` follows [Keep a Changelog 1.1.0](https://keepachangelog.com/en/1.1.0/):

- Newest release first, under an `## [Unreleased]` section that collects changes not yet released.
- Release headings: `## [X.Y.Z] - YYYY-MM-DD`.
- Entries are grouped under `### Added`, `### Changed`, `### Deprecated`, `### Removed`, `### Fixed`, `### Security`. Empty groups are omitted.

## Releases (maintainers)

One-time: in the repository settings, set Pages source to "GitHub Actions".

On every push to `main`, `.github/workflows/pages.yml` deploys the site. A release is made by pushing a tag, which triggers `.github/workflows/release.yml`.

1. Update `main` and confirm CI is green.
2. Open a pull request titled `chore(release): vX.Y.Z` that:
   - runs `npm version X.Y.Z --no-git-tag-version` in `site/`,
   - renames `## [Unreleased]` in `CHANGELOG.md` to `## [X.Y.Z] - YYYY-MM-DD` and adds a new empty `## [Unreleased]` above it.
3. Merge it, update local `main`, then tag and push the tag:

   ```sh
   git tag vX.Y.Z
   git push origin vX.Y.Z
   ```

4. The release workflow checks that the tag equals the `site/package.json` version and that `CHANGELOG.md` has a section for it, runs `npm test` and `npm run build`, then creates the GitHub release with that section as its notes. A tag with a suffix (`v1.0.0-rc.1`) is marked as a pre-release.

## Dependency updates

Dependabot (`.github/dependabot.yml`) opens weekly pull requests for npm packages in `site/` (minor and patch updates grouped) and for GitHub Actions. Its commits use the `build` and `ci` types.
