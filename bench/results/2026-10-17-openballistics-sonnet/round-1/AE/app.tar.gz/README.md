# OpenBallistics

An open database of cartridges, bullets and targets, with a website to browse it.

- `data/`: the records, one JSON file each. `cartridges/<family>/`, `bullets/`, `targets/`.
- `lib/`: TypeScript libraries shared by the site (geometry, drawing, scoring, user data).
- `site/`: the Svelte website. It is the only npm package in the repository.

## Requirements

- Node.js 22
- npm

The repository has a development container (`.devcontainer/devcontainer.json`) with Node.js 22.

## Install

```sh
cd site
npm ci
```

All npm commands below run in `site/`.

## Develop

```sh
npm run dev
```

Regenerates the search indexes from `data/`, then starts the Vite dev server.

| Command | What it does |
| --- | --- |
| `npm run dev` | Regenerate indexes, start the dev server |
| `npm test` | Regenerate indexes, run all tests in `site/src/` and `lib/` (Vitest) |
| `npm run build` | Regenerate indexes, type-check with `svelte-check`, build into `site/dist/` |
| `npm run preview` | Serve the built `site/dist/` |
| `npm run prepare-data` | Regenerate the search indexes and field sets only (`index`, `fieldsets`) |
| `npm run sample-bullets` | Regenerate the synthetic sample bullets (see `data/bullets/README.md`) |

The generated index files are git-ignored (`site/.gitignore`).

## Test

```sh
npm test
```

The pull request check (`.github/workflows/ci.yml`) runs `npm ci`, `npm test` and `npm run build`. Run the same three before opening a pull request.

## Build and deploy

`npm run build` writes the site to `site/dist/`. The build base path comes from the `PAGES_BASE` environment variable and defaults to `/`:

```sh
PAGES_BASE=/OpenBallistics/ npm run build
```

Every push to `main` runs `.github/workflows/pages.yml`, which builds with `PAGES_BASE=/<repository name>/` and deploys `site/dist/` to GitHub Pages.

## Contribute data

- Report a wrong or missing value with an issue form: [new issue](https://github.com/PiMetry/OpenBallistics/issues/new/choose). Name the source of the correct value.
- To change a record, edit its JSON file in `data/` and open a pull request:
  - cartridges: `data/cartridges/<family>/<key>.json`
  - bullets: `data/bullets/<key>.json`
  - targets: `data/targets/<id>.json`
- State the source of every changed value in the pull request.
- Run `npm test` and `npm run build` in `site/`. Both must pass.

See [CONTRIBUTING.md](CONTRIBUTING.md) for the commit convention, pull requests, versioning and releases.

## Versioning and changelog

Versions follow [Semantic Versioning](https://semver.org/spec/v2.0.0.html). The version is the `version` field of `site/package.json`. Changes are listed in [CHANGELOG.md](CHANGELOG.md) in the [Keep a Changelog 1.1.0](https://keepachangelog.com/en/1.1.0/) format.

## License

MIT, see [LICENSE](LICENSE). Third-party software and its terms: [THIRD-PARTY.md](THIRD-PARTY.md).
