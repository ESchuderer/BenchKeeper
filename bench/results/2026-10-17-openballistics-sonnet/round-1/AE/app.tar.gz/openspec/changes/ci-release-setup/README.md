# ci-release-setup

CI, Pages deploy, README, release strategy, Dependabot
