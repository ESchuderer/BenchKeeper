## Why

The repository accepts outside pull requests but has no CI, deployment, contributor docs, release process or dependency updates.

## What Changes

- `.github/workflows/ci.yml`: `npm ci`, `npm test`, `npm run build` in `site/` on pull requests and pushes to `main`; PR title check against Conventional Commits.
- `.github/workflows/pages.yml`: build with `PAGES_BASE=/<repository>/` and deploy `site/dist/` to GitHub Pages on push to `main`.
- `.github/workflows/release.yml`: tag `vX.Y.Z` creates a GitHub release, notes taken from `CHANGELOG.md`.
- `.github/dependabot.yml`: weekly npm (`site/`) and GitHub Actions updates.
- `README.md`, `CONTRIBUTING.md`, `CHANGELOG.md`, pull request template.

## Decisions

- Version kept in `site/package.json` only (the single npm package). Tag-triggered workflow chosen over release-please: no token or bot PR flow to configure.
- Changelog: Keep a Changelog 1.1.0, SemVer 2.0.0.
- Commit convention: Conventional Commits, plus a `data` type; squash merge, PR title checked in CI.
- Dependabot chosen over Renovate: built into GitHub, no app install.
- Action versions are major tags, kept current by Dependabot.

## Out of scope

Application code, tests, data, a lint step (the repository has none), running or publishing anything.
