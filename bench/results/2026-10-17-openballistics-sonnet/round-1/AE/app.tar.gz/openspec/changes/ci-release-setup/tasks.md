## 1. Implementation

- [x] 1.1 CI workflow and pull request template
- [x] 1.2 Pages workflow
- [x] 1.3 Release workflow and `CHANGELOG.md`
- [x] 1.4 Dependabot
- [x] 1.5 README and CONTRIBUTING

## 2. Verification

- [x] 2.1 `actionlint` on the workflows
- [x] 2.2 `npm test` and `PAGES_BASE=/OpenBallistics/ npm run build` pass in `site/`
