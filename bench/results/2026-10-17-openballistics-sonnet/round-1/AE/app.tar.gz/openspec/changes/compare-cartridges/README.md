# compare-cartridges

A view that compares two cartridges: overlaid case profiles and a dimension table
