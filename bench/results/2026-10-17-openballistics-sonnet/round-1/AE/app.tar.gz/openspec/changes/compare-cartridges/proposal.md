## Why

Comparing two cartridges means opening two detail pages. The site has no view that puts their case profiles and dimensions side by side.

## What Changes

- Route `#/compare/<a>/<b>` (keys as in `#/c/<key>`), opened directly and after reload.
- One SVG with both case outer profiles (`caseOuterProfile`), one scale, one axis, head faces at the same point. Role `img`, name `Profiles of <name A> and <name B>`. Each outline is one `path`.
- A table named `Dimensions (mm)` or `Dimensions (in)`: one row per symbol that either cartridge publishes as a number in `cartridge`, in millimetres (not in `FIELD_UNITS`), tolerances excluded. Where a cartridge does not publish the symbol, its cell and `Difference` are empty. Cells of the two cartridge columns and `Difference`, headers included, are right-aligned with the `num` class. Columns `Symbol`, name A, name B, `Difference` (B minus A).
- Values follow the unit preference. Metric: `formatValue`. Imperial: `displayNumber(value, 'in')`. Differences are converted, not subtracted after conversion.
- Detail page: select `Compare with` (other cartridges by name) and button `Compare`.
- English and German texts.

## Decisions

- Logic (rows, outline paths) in `site/src/lib/compare.ts`, framework-free, tested with the real records. The view is `site/src/routes/Compare.svelte`, lazy-loaded like the other pages.
- Outlines are the half profile mirrored with `fullSectionPath` and drawn with `viewportFor`, so one viewport gives both the same scale and axis.
- The metric difference is cleaned of floating-point noise with `displayNumber(diff, 'mm')` (12 significant digits), so `0.3` is not shown as `0.30000000000000004`. Values themselves are written unrounded by `formatValue`.
- Shot cartridges (family `shotshell`) are not offered in the select and the route shows a message for them.
- A cartridge whose case profile cannot be built (missing dimensions) is named in a message in place of the drawing. The table still renders.

## Out of scope

Shot cartridges, chambers, bullets, more than two cartridges, printing.
