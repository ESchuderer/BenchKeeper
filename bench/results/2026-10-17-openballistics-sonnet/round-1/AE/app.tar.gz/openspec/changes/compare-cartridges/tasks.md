## 1. Implementation

- [x] 1.1 `compare.ts`: rows and outline paths, with tests
- [x] 1.2 Route `compare`, metadata, lazy page
- [x] 1.3 `Compare.svelte` with English and German texts
- [x] 1.4 `Compare with` select and `Compare` button on the detail page
- [x] 1.5 `CHANGELOG.md` entry

## 2. Verification

- [x] 2.1 `npm test` and `npm run build` in `site/`
- [x] 2.2 Browser check of `#/compare/308_win/300_win_mag`, reload, imperial units
