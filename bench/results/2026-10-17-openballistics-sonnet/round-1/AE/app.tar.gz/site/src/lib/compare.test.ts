import { readdirSync, readFileSync } from 'node:fs';
import { join } from 'node:path';
import { describe, expect, it } from 'vitest';
import { CARTRIDGES } from '../../../lib/testing/fixtures';
import type { Record_ } from '@lib/core';
import { adaptMetallic, MissingDimensionError, type CartridgeRecord } from '@lib/shapes2d';
import { dimensionRows, formatRow, outlinePaths } from './compare';

const read = (family: string, key: string) =>
  JSON.parse(readFileSync(join(CARTRIDGES, family, `${key}.json`), 'utf8')) as Record_;
const win308 = read('rimless', '308_win');
const mag300 = read('belted', '300_win_mag');
const symbols = (rows: { symbol: string }[]) => rows.map((row) => row.symbol);

describe('dimension rows', () => {
  const rows = dimensionRows(win308, mag300);

  it('lists the symbols either publishes, as the detail page writes them', () => {
    expect(symbols(rows)).toContain('e min');
    expect(symbols(rows)).toContain('L1');
    expect(new Set(symbols(rows)).size).toBe(rows.length);
  });

  it('leaves a cell empty where only one cartridge publishes the dimension', () => {
    const only = (symbol: string) => rows.find((row) => row.symbol === symbol)!;
    expect(only('delta L').b).toBeUndefined();
    expect(only('delta L').a).toBeTypeOf('number');
    expect(only('R3').a).toBeUndefined();
    expect(only('R3').b).toBeTypeOf('number');
    expect(formatRow(only('delta L'), 'metric')).toMatchObject({ b: '', difference: '' });
    expect(formatRow(only('R3'), 'imperial')).toMatchObject({ a: '', difference: '' });
  });

  it('leaves out other units, tolerances and angles', () => {
    for (const out of ['Pmax', 'M', 'Q', 'α', 'δ', 'β', 'L1Tol', 'L1 Tol']) expect(symbols(rows)).not.toContain(out);
    const belted = { ...mag300, cartridge: { ...mag300.cartridge, extra: { onlyB: 1 } } } as Record_;
    expect(symbols(dimensionRows(win308, belted))).toContain('onlyB');
  });

  it('takes numbers from the cartridge part only', () => {
    const a = { ...win308, chamber: { x: { onlyChamber: 1 } } } as Record_;
    const b = { ...mag300, chamber: { x: { onlyChamber: 2 } } } as Record_;
    expect(symbols(dimensionRows(a, b))).not.toContain('onlyChamber');
  });

  it('writes metric values as formatValue does, with the difference B minus A', () => {
    const l1 = rows.find((row) => row.symbol === 'L1')!;
    const [a, b] = [win308.cartridge.lengths as Record<string, number>, mag300.cartridge.lengths as Record<string, number>];
    expect(formatRow(l1, 'metric')).toEqual({
      symbol: 'L1', a: String(a.L1), b: String(b.L1), difference: String(Number((b.L1! - a.L1!).toPrecision(12)))
    });
  });

  it('shows no floating point noise in a difference', () => {
    expect(formatRow({ symbol: 'x', a: 0.1, b: 0.4 }, 'metric').difference).toBe('0.3');
  });

  it('converts values and the difference to inches without further rounding', () => {
    expect(formatRow({ symbol: 'x', a: 25.4, b: 76.2 }, 'imperial')).toEqual({ symbol: 'x', a: '1', b: '3', difference: '2' });
    expect(formatRow({ symbol: 'x', a: 10, b: 10 }, 'imperial').difference).toBe('0');
  });
});

describe('outline paths', () => {
  it('draws both outlines in one viewport, each as one path, head faces level', () => {
    const drawing = outlinePaths(win308, mag300);
    expect(drawing.paths).toHaveLength(2);
    for (const d of drawing.paths) expect(d).toMatch(/^M[^M]*Z$/);
    expect(drawing.width).toBeGreaterThan(0);
    // The head face is the lowest point of both, at the same y.
    const lowest = drawing.paths.map((d) =>
      Math.max(...[...d.matchAll(/[ML]([-\d.]+),([-\d.]+)/g)].map((m) => Number(m[2])))
    );
    expect(lowest[0]).toBeCloseTo(lowest[1]!, 6);
    // And the axis is the one both are symmetric about.
    for (const d of drawing.paths) {
      const xs = [...d.matchAll(/[ML]([-\d.]+),/g)].map((m) => Number(m[1]));
      expect((Math.min(...xs) + Math.max(...xs)) / 2).toBeCloseTo(drawing.axis, 3);
    }
  });

  it('draws the longer case longer, at one scale', () => {
    const height = (d: string) => {
      const ys = [...d.matchAll(/[ML][-\d.]+,([-\d.]+)/g)].map((m) => Number(m[1]));
      return Math.max(...ys) - Math.min(...ys);
    };
    const [a, b] = outlinePaths(win308, mag300).paths.map(height) as [number, number];
    const mouth = (r: Record_) => adaptMetallic(r as unknown as CartridgeRecord).mouth.z;
    expect(a / b).toBeCloseTo(mouth(win308) / mouth(mag300), 6);
    expect(a / 8).toBeCloseTo(mouth(win308), 5);
  });
});

describe('every metallic record', () => {
  it('has an outline, or fails by naming the missing dimension', () => {
    const failed: string[] = [];
    for (const family of readdirSync(CARTRIDGES).filter((name) => name !== 'shotshell')) {
      for (const file of readdirSync(join(CARTRIDGES, family))) {
        const record = read(family, file.replace(/\.json$/, ''));
        try { outlinePaths(win308, record); } catch (error) { if (!(error instanceof MissingDimensionError)) failed.push(record.key); }
      }
    }
    expect(failed).toEqual([]);
  });
});
