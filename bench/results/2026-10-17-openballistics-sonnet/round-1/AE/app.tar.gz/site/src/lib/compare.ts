/**
 * What the comparison view shows: the dimension rows either of two records publishes, and their case outlines
 * in one drawing. Framework-free so the figures can be tested against the real records.
 */

import { FIELD_LABELS, FIELD_UNITS, GROUP_ORDER, formatValue, type Record_ } from '@lib/core';
import { fullSectionPath, viewportFor } from '@lib/geom';
import { adaptMetallic, caseOuterProfile, type CartridgeRecord } from '@lib/shapes2d';
import { displayNumber, type UnitSystem } from './units';

export interface Row {
  symbol: string;
  a?: number;
  b?: number;
}

/** Millimetre dimensions of a record's cartridge part, by field name, in the order the detail page lists them. */
function dimensions(record: Record_): Map<string, number> {
  const groups = Object.keys(record.cartridge);
  const ordered = [...GROUP_ORDER.cartridge.filter((name) => groups.includes(name)), ...groups.filter((name) => !GROUP_ORDER.cartridge.includes(name))];
  const found = new Map<string, number>();
  for (const name of ordered) {
    const group = record.cartridge[name];
    if (!group || Array.isArray(group)) continue;
    for (const [field, value] of Object.entries(group)) {
      if (typeof value === 'number' && !field.endsWith('Tol') && !(field in FIELD_UNITS) && !found.has(field)) {
        found.set(field, value);
      }
    }
  }
  return found;
}

/** One row per dimension either record publishes: A's in the detail page order, then those only B publishes. */
export function dimensionRows(a: Record_, b: Record_): Row[] {
  const first = dimensions(a);
  const second = dimensions(b);
  return [...new Set([...first.keys(), ...second.keys()])].map((field) => ({
    symbol: FIELD_LABELS[field] ?? field,
    a: first.get(field),
    b: second.get(field)
  }));
}

/**
 * A row as text. The difference is B minus A, cut to 12 significant digits to drop floating point
 * noise. A value a record does not publish, and the difference then, is an empty string.
 */
export function formatRow(row: Row, system: UnitSystem) {
  const cell = (value: number | undefined) =>
    value === undefined ? '' : system === 'imperial' ? displayNumber(value, 'in') : formatValue(value)!;
  const difference = row.a === undefined || row.b === undefined ? undefined : row.b - row.a;
  return {
    symbol: row.symbol,
    a: cell(row.a),
    b: cell(row.b),
    difference: cell(difference === undefined || system === 'imperial' ? difference : Number(difference.toPrecision(12)))
  };
}

/**
 * Both case outlines as closed paths in one viewport: one scale, one axis (`axis`, in pixels), head
 * faces level. Throws where a record lacks a dimension the case needs.
 */
export function outlinePaths(a: Record_, b: Record_) {
  const profiles = [a, b].map((record) => caseOuterProfile(adaptMetallic(record as unknown as CartridgeRecord)));
  const view = viewportFor(profiles, { scale: 8, marginMm: 2, frame: 'upright' });
  return {
    width: view.width,
    height: view.height,
    axis: view.xy(0, 0)[0],
    paths: profiles.map((profile) => fullSectionPath(profile, view))
  };
}
