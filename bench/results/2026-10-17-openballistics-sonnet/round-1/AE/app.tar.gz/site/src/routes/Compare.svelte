<script lang="ts">
  import PageLoadError from '../components/PageLoadError.svelte';
  import { byKey, load } from '../lib/data';
  import { dimensionRows, formatRow, outlinePaths } from '../lib/compare';
  import { href } from '../lib/router';
  import { t } from '../lib/i18n.svelte';
  import { unitSystem } from '../lib/units.svelte';
  import type { Record_ } from '@lib/core';

  /** Two cartridges, as keys of `#/c/<key>`: their case profiles at one scale, and the dimensions either publishes. */
  let { a, b }: { a: string; b: string } = $props();

  const entries = $derived([byKey(a), byKey(b)]);
  const missing = $derived([a, b].find((key) => !byKey(key)));
  const shot = $derived(entries.find((entry) => entry?.family === 'shotshell'));
  const records = $derived(missing === undefined && !shot ? Promise.all([load(a), load(b)]) : null);
  const system = $derived(unitSystem());

  function draw(first: Record_, second: Record_) {
    try {
      return { drawing: outlinePaths(first, second), error: null };
    } catch (error) {
      return { drawing: null, error: error instanceof Error ? error.message : String(error) };
    }
  }
</script>

<div data-ui="Compare" class="contents">
  {#if missing !== undefined}
    <p class="status">{t('compare.unknown', { key: missing })}</p>
  {:else if shot}
    <p class="status">{t('compare.shot', { name: shot.name })}</p>
  {:else}
    {#await records}
      <p class="status" role="status">{t('site.loading')}</p>
    {:then loaded}
      {@const [first, second] = loaded!}
      {@const { drawing, error } = draw(first, second)}
      {@const rows = dimensionRows(first, second).map((row) => formatRow(row, system))}
      <h1>{first.name} / {second.name}</h1>
      <p><a href={href.cartridge(first.key)}>{t('compare.back', { name: first.name })}</a></p>

      {#if drawing}
        <svg
          class="profiles"
          role="img"
          aria-label={t('compare.profiles', { a: first.name, b: second.name })}
          width={drawing.width}
          height={drawing.height}
          viewBox="0 0 {drawing.width} {drawing.height}"
        >
          <line class="axis" x1={drawing.axis} x2={drawing.axis} y1="0" y2={drawing.height} />
          <path class="outline a" d={drawing.paths[0]} />
          <path class="outline b" d={drawing.paths[1]} />
        </svg>
        <ul class="legend">
          <li><span class="swatch a"></span>{first.name}</li>
          <li><span class="swatch b"></span>{second.name}</li>
        </ul>
      {:else}
        <p class="status">{t('compare.noProfile', { reason: error ?? '' })}</p>
      {/if}

      {#if rows.length}
        <table>
          <caption>{t('compare.dimensions', { unit: system === 'imperial' ? 'in' : 'mm' })}</caption>
          <thead>
            <tr>
              <th>{t('compare.symbol')}</th>
              <th class="num">{first.name}</th>
              <th class="num">{second.name}</th>
              <th class="num">{t('compare.difference')}</th>
            </tr>
          </thead>
          <tbody>
            {#each rows as row (row.symbol)}
              <tr>
                <td>{row.symbol}</td>
                <td class="num">{row.a}</td>
                <td class="num">{row.b}</td>
                <td class="num">{row.difference}</td>
              </tr>
            {/each}
          </tbody>
        </table>
      {:else}
        <p class="status">{t('compare.none')}</p>
      {/if}
    {:catch}
      <PageLoadError />
    {/await}
  {/if}
</div>

<style>
  @layer legacy {
    .status { color: var(--muted-foreground); padding: 2rem 0; }
    .profiles { display: block; max-width: 100%; height: auto; margin: 1.5rem 0 .5rem; }
    .axis { stroke: var(--rule-strong); stroke-width: 1; stroke-dasharray: 6 4; }
    .outline { fill: none; stroke-width: 1.5; vector-effect: non-scaling-stroke; stroke-linejoin: round; }
    .outline.a, .swatch.a { stroke: var(--ink); border-color: var(--ink); }
    .outline.b, .swatch.b { stroke: var(--link); border-color: var(--link); }
    .outline.b { stroke-dasharray: 6 3; }
    .legend { display: flex; flex-wrap: wrap; gap: .25rem 1.5rem; list-style: none; padding: 0; margin: 0 0 1.5rem; }
    .swatch { display: inline-block; width: 1.5rem; margin-right: .5rem; vertical-align: middle; border-top: 2px solid; }
    .swatch.b { border-top-style: dashed; }
    table { border-collapse: collapse; font-size: var(--step-0); }
    caption { text-align: left; font-weight: 600; padding-bottom: .4rem; }
    th, td { padding: .2rem 1rem .2rem 0; white-space: nowrap; text-align: right; }
    th:first-child, td:first-child { text-align: left; }
    th { color: var(--ink-2); font-weight: 500; border-bottom: 1px solid var(--rule); }
    td { font-weight: 500; }
  }
</style>
