# Compare two cartridges

Status: ready-for-agent

Route `#/compare/<a>/<b>`: overlaid case outer profiles (one SVG, one scale, common axis, head faces aligned) and a table of shared mm dimensions (Symbol, A, B, Difference = B minus A). Units follow the user's preference. The detail page gets a `Compare with` select and a `Compare` button. English and German texts. Shot cartridges are out of scope.

## Decisions

- Shotshell records are not offered in the select and are not compared.
- The Difference column is converted from the canonical difference and written with `displayNumber`, which removes binary floating-point noise (11.9 - 9.6 prints 2.3).
- Rows follow the detail page's group and field order.
