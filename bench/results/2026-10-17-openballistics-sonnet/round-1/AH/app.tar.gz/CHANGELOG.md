# Changelog

All notable changes to OpenBallistics are recorded in this file.

The format follows [Keep a Changelog 1.1.0](https://keepachangelog.com/en/1.1.0/). The project
follows [Semantic Versioning 2.0.0](https://semver.org/spec/v2.0.0.html), with the meaning of each
number defined in [CONTRIBUTING.md](CONTRIBUTING.md#versioning).

Each version has a heading `## [X.Y.Z] - YYYY-MM-DD`, with entries grouped under `### Added`,
`### Changed`, `### Deprecated`, `### Removed`, `### Fixed` and `### Security`, and only the groups
that have entries. Unreleased changes go under `## [Unreleased]`. The release workflow publishes the
section whose heading matches the tag as the release notes.

## [Unreleased]

### Added

- GitHub Actions workflows for pull request checks, deployment to GitHub Pages and tagged releases.
- Dependabot configuration for npm and GitHub Actions updates.
- Contributor documentation: `README.md` and `CONTRIBUTING.md`.
- Compare view at `#/compare/<a>/<b>`: the outer case profiles of two cartridges overlaid at one scale, and a table of the millimetre dimensions either publishes (empty where one does not) with the difference, in the chosen units. A `Compare with` select and `Compare` button on each cartridge page open it. German texts included.
