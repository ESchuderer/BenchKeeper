# Contributing

Setup, test and build commands are in [README.md](README.md). Contributions are made as pull requests to `main`, under the MIT license in [LICENSE](LICENSE).

## Before you open a pull request

- `npm test` and `npm run build` pass in `site/`. CI runs the same two commands.
- The pull request does one thing and says what changed and why. Data changes name their source.
- A user-visible change adds an entry under `## [Unreleased]` in `CHANGELOG.md`.

## Commit convention

[Conventional Commits 1.0.0](https://www.conventionalcommits.org/en/v1.0.0/): `<type>(<optional scope>): <summary>`.

| Type | Use for |
| --- | --- |
| `feat` | a new feature of the site or libraries |
| `fix` | a bug fix |
| `data` | a new or corrected record in `data/` |
| `docs` | documentation only |
| `test` | tests only |
| `refactor` | a change that keeps behavior |
| `perf` | a performance change |
| `build` | the build, scripts or dependencies |
| `ci` | workflows and repository automation |
| `chore` | anything else, including releases |

- The summary is in the imperative, lower case, without a final period, and at most 72 characters.
- A breaking change has `!` after the type or scope (`feat!: ...`) and a `BREAKING CHANGE:` footer.
- If you squash on merge, the pull request title is the commit message and follows the same convention.
- Dependabot commits use `chore(deps)` and `ci(deps)`.

CI does not check commit messages.

## Versioning

[Semantic Versioning 2.0.0](https://semver.org/spec/v2.0.0.html). The version covers the site, the libraries and the data together.

- Major: a record field is renamed or removed, a record key changes, or the user-data backup format breaks.
- Minor: new records, new fields, or a new feature.
- Patch: corrected record values and bug fixes.

The version lives in one place, the `version` field of `site/package.json` (and the matching entry in `site/package-lock.json`). Tags are `v<version>`.

## Changelog

`CHANGELOG.md` follows [Keep a Changelog 1.1.0](https://keepachangelog.com/en/1.1.0/). Its format is stated at the top of the file.

## Releasing

For maintainers. The release workflow (`.github/workflows/release.yml`) runs when a tag matching `v<major>.<minor>.<patch>` is pushed. It stops unless the tag equals `site/package.json`'s version and `CHANGELOG.md` has a `## [<version>]` section. Then it runs the tests and the build, and creates a GitHub release with that changelog section as the notes, the built site and the `data/` directory as attachments. A tag with a suffix such as `v1.0.0-rc.1` is marked as a pre-release.

1. From `main`, up to date and with CI passing, create a branch `chore/release-<version>`.
2. In `site/`, set the version: `npm version <major|minor|patch|X.Y.Z> --no-git-tag-version`. The first release, `0.1.0`, is already in `package.json`: skip this step.
3. In `CHANGELOG.md`, rename `## [Unreleased]` to `## [<version>] - <YYYY-MM-DD>` and add an empty `## [Unreleased]` above it.
4. Commit as `chore(release): v<version>`, open a pull request and merge it.
5. Tag the merge commit on `main` and push the tag:

   ```sh
   git tag -a v<version> -m "v<version>"
   git push origin v<version>
   ```

A failed release run is fixed by deleting the tag and any release it created, correcting the cause on `main`, and tagging again.

## GitHub settings

Set once by a maintainer:

- Settings, Pages, Source: GitHub Actions. The site deploys to `https://<owner>.github.io/<repository>/`. For a custom domain, change `PAGES_BASE` in `.github/workflows/pages.yml` to `/`.
- Settings, Branches: require the `CI / check` status on `main`.
- Dependabot opens weekly pull requests for npm (in `site/`) and GitHub Actions, with minor and patch updates grouped.
