# OpenBallistics

An open database of cartridges, bullets and targets, with a website to browse it.

- `data/`: the records, one JSON file each. `data/cartridges/<family>/`, `data/bullets/`, `data/targets/`.
- `lib/`: shared TypeScript libraries (geometry, drawing, targets, user data), with their tests.
- `site/`: the Svelte website. It builds the search index from `data/` and is the only place with a `package.json`.
- `fixtures/`: stored drawings and profiles that the tests compare against.

## Requirements

- Node.js 22 and npm.

## Install

All npm commands run in `site/`.

```sh
cd site
npm ci
```

## Develop

```sh
npm run dev       # builds the index, then starts the Vite dev server
npm run preview   # serves the output of npm run build
```

`npm run dev` and `npm run build` regenerate `site/src/lib/*.generated.json` and `site/public/flags/`. Both are git-ignored.

## Test

```sh
npm test
```

This builds the index, then runs Vitest over `site/src/` and `lib/`. The suite includes comparisons of every cartridge record with the profiles in `fixtures/profiles/`.

## Build

```sh
npm run build
```

This builds the index, runs `svelte-check`, then writes the site to `site/dist/`. Set `PAGES_BASE` (for example `PAGES_BASE=/OpenBallistics/ npm run build`) to build for a path other than `/`.

Pull requests run `npm test` and `npm run build` in GitHub Actions (`.github/workflows/ci.yml`). A push to `main` deploys the site to GitHub Pages (`.github/workflows/pages.yml`).

## Contribute data

1. Open an issue with one of the templates (cartridge, bullet or site feedback), or edit the record directly.
2. Records are JSON files. Edit the existing file, or add a new one named after the key:
   - cartridges: `data/cartridges/<family>/<key>.json`, family one of `belted`, `pistol`, `rimfire`, `rimless`, `rimmed`, `shotshell`
   - bullets: `data/bullets/<key>.json`
   - targets: `data/targets/<id>.json`
3. Name the source of every figure you add or change (the C.I.P. sheet, a maker's datasheet, a standard) in the pull request, and in the record's `sources` field where the record has one.
4. Run `npm test` and `npm run build` in `site/`. A changed cartridge dimension that alters the drawing fails the comparison with `fixtures/profiles/`. Do not edit the fixture to make it pass: say in the pull request which figure changed and why.
5. Open a pull request. See [CONTRIBUTING.md](CONTRIBUTING.md) for the commit convention and pull request rules.

The 75 bullets in `data/bullets/` with a `sample_` key are synthetic demonstration records, not measurements. See `data/bullets/README.md`.

## Versions and releases

The version is the `version` field of `site/package.json`. Releases are tags named `v<version>`, and `CHANGELOG.md` records the changes. See [CONTRIBUTING.md](CONTRIBUTING.md#releasing).

## License

MIT, copyright (c) 2026 PiMetry. See [LICENSE](LICENSE). Third-party software and its licenses are listed in [THIRD-PARTY.md](THIRD-PARTY.md).
