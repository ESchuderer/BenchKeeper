import { readFileSync } from 'node:fs';
import { join } from 'node:path';
import { describe, expect, it } from 'vitest';
import { CARTRIDGES } from '@lib/testing/fixtures';
import type { Record_ } from '@lib/core';
import { cells, compareRows, outlines } from './compare';

const load = (family: string, key: string) =>
  JSON.parse(readFileSync(join(CARTRIDGES, family, `${key}.json`), 'utf8')) as Record_;
const a = load('rimless', '308_win');
const b = load('belted', '300_win_mag');

describe('compareRows', () => {
  const rows = compareRows(a, b);
  const symbols = rows.map((row) => row.symbol);

  it('lists millimetre dimensions with the sheet notation, without tolerances, pressures or angles', () => {
    expect(symbols).toContain('e min');
    expect(symbols).toContain('L1');
    expect(symbols.filter((symbol) => symbol === 'L1')).toHaveLength(1);
    for (const gone of ['Pmax', 'PK', 'M', 'α', 'β', 'δ', 'L1Tol', 'R3Tol']) expect(symbols).not.toContain(gone);
  });
  it('lists a symbol only one record publishes, with the other side null', () => {
    const lone = { ...a, cartridge: { ...a.cartridge, collar: { H1: 8.72, H2: 8.72 } } };
    const other = { ...b, cartridge: { ...b.cartridge, collar: { H1: 9 } } };
    const found = compareRows(lone, other);
    expect(found.find((row) => row.field === 'H1')).toMatchObject({ a: 8.72, b: 9 });
    expect(found.find((row) => row.field === 'H2')).toMatchObject({ a: 8.72, b: null });
  });
  it('lists delta L (308 Win. only) and R3 (300 Win. Mag. only)', () => {
    expect(rows.find((row) => row.symbol === 'delta L')).toMatchObject({ b: null });
    expect(rows.find((row) => row.symbol === 'delta L')?.a).toEqual(expect.any(Number));
    expect(rows.find((row) => row.symbol === 'R3')).toMatchObject({ a: null });
    expect(rows.find((row) => row.symbol === 'R3')?.b).toEqual(expect.any(Number));
  });
});

describe('cells', () => {
  it('leaves the cell of an unpublished value and the difference empty', () => {
    expect(cells({ field: 'R3', symbol: 'R3', a: null, b: 5 }, 'metric')).toEqual({ a: '', b: '5', difference: '' });
    expect(cells({ field: 'R3', symbol: 'R3', a: 5, b: null }, 'imperial')).toMatchObject({ b: '', difference: '' });
  });
  const row = { field: 'L1', symbol: 'L1', a: 9.6, b: 11.9 };
  it('writes metric values as published and the difference without float noise', () => {
    expect(cells(row, 'metric')).toEqual({ a: '9.6', b: '11.9', difference: '2.3' });
  });
  it('writes inches from the canonical values, the difference converted', () => {
    expect(cells({ ...row, a: 25.4, b: 76.2 }, 'imperial')).toEqual({ a: '1', b: '3', difference: '2' });
  });
});

describe('outlines', () => {
  it('draws one path per case in one viewport', () => {
    const drawing = outlines(a, b);
    expect(drawing.paths).toHaveLength(2);
    expect(drawing.paths[0]).not.toBe(drawing.paths[1]);
    expect(drawing.width).toBeGreaterThan(0);
  });
});
