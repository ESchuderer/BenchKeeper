/** What the compare view shows: the millimetre dimensions of two records and their outlines. */

import { FIELD_LABELS, FIELD_UNITS, GROUP_ORDER, formatValue, orderedFields, type Group, type Record_ } from '@lib/core';
import { fullSectionPath, viewportFor } from '@lib/geom';
import { adaptMetallic, caseOuterProfile, type CartridgeRecord } from '@lib/shapes2d';
import { displayNumber, type UnitSystem } from './units';

export interface CompareRow {
  field: string;
  symbol: string;
  /** Null where that record does not publish the dimension. */
  a: number | null;
  b: number | null;
}

/** One row per symbol that either record publishes as a number in millimetres, in the detail page's order. */
export function compareRows(a: Record_, b: Record_): CompareRow[] {
  const rows: CompareRow[] = [];
  for (const group of GROUP_ORDER.cartridge) {
    const left = a.cartridge[group];
    const right = b.cartridge[group];
    if (Array.isArray(left) || Array.isArray(right)) continue;
    const x = (left ?? {}) as Group;
    const y = (right ?? {}) as Group;
    for (const field of orderedFields('cartridge', group, { ...y, ...x })) {
      if (field in FIELD_UNITS) continue;
      const published = (value: unknown) => (typeof value === 'number' ? value : null);
      const row = { field, symbol: FIELD_LABELS[field] ?? field, a: published(x[field]), b: published(y[field]) };
      if (row.a !== null || row.b !== null) rows.push(row);
    }
  }
  return rows;
}

/** A value, and the difference B minus A, as text in the given unit system; empty where unpublished. */
export function cells(row: CompareRow, system: UnitSystem): { a: string; b: string; difference: string } {
  const unit = system === 'metric' ? 'mm' : 'in';
  const show = (value: number | null) =>
    value === null ? '' : system === 'metric' ? (formatValue(value) ?? '') : displayNumber(value, 'in');
  return {
    a: show(row.a),
    b: show(row.b),
    difference: row.a === null || row.b === null ? '' : displayNumber(row.b - row.a, unit)
  };
}

/** Both cases' outer profiles in one viewport: one scale, one axis, head faces at the same height. */
export function outlines(a: Record_, b: Record_, scale = 4): { width: number; height: number; paths: [string, string] } {
  const profiles = [a, b].map((record) => caseOuterProfile(adaptMetallic(record as unknown as CartridgeRecord)));
  const view = viewportFor(profiles, { scale });
  const [first, second] = profiles.map((profile) => fullSectionPath(profile, view));
  return { width: view.width, height: view.height, paths: [first!, second!] };
}
