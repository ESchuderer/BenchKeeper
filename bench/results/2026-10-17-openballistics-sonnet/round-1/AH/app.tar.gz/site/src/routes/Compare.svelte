<script lang="ts">
  import PageHeader from '../components/PageHeader.svelte';
  import { load } from '../lib/data';
  import { cells, compareRows, outlines } from '../lib/compare';
  import { t } from '../lib/i18n.svelte';
  import { href } from '../lib/router';
  import { unitSystem } from '../lib/units.svelte';

  let { a, b }: { a: string; b: string } = $props();

  const records = $derived(Promise.all([load(a), load(b)]));
  const system = $derived(unitSystem());
</script>

{#await records}
  <p class="text-muted-foreground" role="status">{t('site.loading')}</p>
{:then [first, second]}
  {@const drawing = (() => { try { return outlines(first, second); } catch (error) { return error as Error; } })()}
  {@const rows = compareRows(first, second)}
  <PageHeader title={`${first.name} / ${second.name}`} description={t('compare.lede')} backHref={href.cartridge(a)} backLabel={first.name} />

  {#if drawing instanceof Error}
    <p role="alert">{t('compare.unavailable', { reason: drawing.message })}</p>
  {:else}
    <svg role="img" aria-label={t('compare.profiles', { a: first.name, b: second.name })}
      viewBox={`0 0 ${drawing.width} ${drawing.height}`} class="mx-auto mb-8 block max-h-[70vh] w-full max-w-xl" fill="none" stroke-width="1.5">
      <path d={drawing.paths[0]} stroke="var(--foreground)" vector-effect="non-scaling-stroke" />
      <path d={drawing.paths[1]} stroke="#d9480f" vector-effect="non-scaling-stroke" />
    </svg>
    <p class="mb-6 flex flex-wrap justify-center gap-x-6 text-sm">
      <span style="border-left: .75rem solid var(--foreground); padding-left: .5rem">{first.name}</span>
      <span style="border-left: .75rem solid #d9480f; padding-left: .5rem">{second.name}</span>
    </p>
    {#if rows.length}
      <table class="w-full text-sm">
        <caption class="mb-2 text-left font-semibold">{t('compare.dimensions', { unit: system === 'metric' ? 'mm' : 'in' })}</caption>
        <thead>
          <tr class="border-b text-left">
            <th scope="col" class="py-1 pr-4">{t('compare.symbol')}</th>
            <th scope="col" class="py-1 pr-4 text-right">{first.name}</th>
            <th scope="col" class="py-1 pr-4 text-right">{second.name}</th>
            <th scope="col" class="py-1 text-right">{t('compare.difference')}</th>
          </tr>
        </thead>
        <tbody>
          {#each rows as row (row.field)}
            {@const text = cells(row, system)}
            <tr class="border-b">
              <th scope="row" class="py-1 pr-4 text-left font-normal">{row.symbol}</th>
              <td class="num py-1 pr-4 text-right">{text.a}</td>
              <td class="num py-1 pr-4 text-right">{text.b}</td>
              <td class="num py-1 text-right">{text.difference}</td>
            </tr>
          {/each}
        </tbody>
      </table>
    {:else}
      <p>{t('compare.none')}</p>
    {/if}
  {/if}
{:catch error}
  <p role="alert">{t('compare.unavailable', { reason: (error as Error).message })}</p>
{/await}
