# Changelog

All notable changes to OpenBallistics are recorded here, newest first.

The format follows [Keep a Changelog 1.1.0](https://keepachangelog.com/en/1.1.0/). The project
follows [Semantic Versioning 2.0.0](https://semver.org/spec/v2.0.0.html), as described in
[CONTRIBUTING.md](CONTRIBUTING.md#versioning).

Each release has a heading `## [X.Y.Z] - YYYY-MM-DD`. Entries sit under the groups `Added`,
`Changed`, `Deprecated`, `Removed`, `Fixed` and `Security`, one line each. Unreleased changes
go under `## [Unreleased]`. The release workflow publishes the section whose version matches the tag.

## [Unreleased]

### Added

- GitHub Actions: CI on pull requests, deployment of the site to GitHub Pages, and a tag-triggered release.
- Dependabot updates for npm and GitHub Actions.
- README, CONTRIBUTING.md and this changelog.
- A comparison view at `#/compare/<a>/<b>`: both case profiles overlaid and a table of the dimensions either cartridge publishes with their differences, opened from the `Compare with` control on a cartridge page.
