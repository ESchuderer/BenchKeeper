# OpenBallistics

An open database of cartridges, bullets and targets, and a website to browse it.

- `data/`: the records, one JSON file each. `cartridges/<family>/`, `bullets/` and `targets/`.
- `lib/`: TypeScript libraries shared by the site and the tests (geometry, drawing, targets, user data).
- `site/`: the Svelte website. Its `package.json` is the only one in the repository.
- `fixtures/`: reference drawings and profiles that the tests compare against.

The site is deployed to GitHub Pages at <https://pimetry.github.io/OpenBallistics/> after Pages is enabled for the repository (see [CONTRIBUTING.md](CONTRIBUTING.md#maintainers)).

## Requirements

Node.js 22 and npm, the versions CI uses. Run every command below from `site/`.

## Install

```sh
cd site
npm ci
```

## Develop

```sh
npm run dev
```

This builds the search index and field sets from `data/`, then starts the Vite dev server. The URL is printed in the terminal.

## Test

```sh
npm test
```

Runs the Vitest suites of `site/src` and `lib/`. The index and field sets are rebuilt first.

## Build

```sh
npm run build
```

Rebuilds the index and field sets, type-checks with `svelte-check`, and writes the site to `site/dist/`. To serve the result locally:

```sh
npm run preview
```

The base path is `/` unless the `PAGES_BASE` environment variable is set, for example `PAGES_BASE=/OpenBallistics/ npm run build`.

Other scripts: `npm run prepare-data` (index and field sets only) and `npm run sample-bullets` (regenerates the sample bullet records, see [data/bullets/README.md](data/bullets/README.md)).

## Contribute data

- Wrong or missing value: open an issue with the form for [a cartridge](https://github.com/PiMetry/OpenBallistics/issues/new?template=data.yml) or [a bullet](https://github.com/PiMetry/OpenBallistics/issues/new?template=bullet.yml) and name the source of the correct figure.
- Fix or addition as a pull request: edit or add the JSON record in `data/`, run `npm test` and `npm run build` from `site/`, and cite the source in the pull request.

Details are in [CONTRIBUTING.md](CONTRIBUTING.md).

## Contribute code

Branch from `main`, use [Conventional Commits](https://www.conventionalcommits.org/en/v1.0.0/) for commit messages and pull request titles, and open a pull request. CI must pass. See [CONTRIBUTING.md](CONTRIBUTING.md) for the commit types, versioning and releases. Changes are recorded in [CHANGELOG.md](CHANGELOG.md).

## License

[MIT](LICENSE). Third-party software and fonts are listed in [THIRD-PARTY.md](THIRD-PARTY.md).
