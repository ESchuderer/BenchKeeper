<script lang="ts">
  import { t } from '../lib/i18n.svelte';
  import type { profileOverlay } from '../lib/compare';

  interface Props {
    overlay: ReturnType<typeof profileOverlay>;
    names: [string, string];
  }
  let { overlay, names }: Props = $props();
</script>

<!-- Both outlines share one viewport, so scale, axis and head face agree by construction. B is dashed so the two differ without colour. -->
<svg
  role="img"
  aria-label={t('compare.profiles', { a: names[0], b: names[1] })}
  viewBox={`0 0 ${overlay.width} ${overlay.height}`}
  class="h-auto max-h-[60vh] w-full"
>
  <line x1={overlay.axis.x1} x2={overlay.axis.x2} y1={overlay.axis.y} y2={overlay.axis.y} stroke="var(--rule-strong)" stroke-width="1" stroke-dasharray="2 4" vector-effect="non-scaling-stroke" />
  <path d={overlay.paths[0]} fill="none" stroke="var(--ink)" stroke-width="1.5" vector-effect="non-scaling-stroke" />
  <path d={overlay.paths[1]} fill="none" stroke="var(--link)" stroke-width="1.5" stroke-dasharray="6 3" vector-effect="non-scaling-stroke" />
</svg>
