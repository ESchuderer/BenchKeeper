import { readFileSync } from 'node:fs';
import { join } from 'node:path';
import { render } from 'svelte/server';
import { describe, expect, it } from 'vitest';
import type { Record_ } from '@lib/core';
import { CARTRIDGES } from '@lib/testing/fixtures';
import { profileOverlay } from '../lib/compare';
import CompareFigure from './CompareFigure.svelte';

const record = (family: string, key: string) =>
  JSON.parse(readFileSync(join(CARTRIDGES, family, `${key}.json`), 'utf8')) as Record_;

describe('CompareFigure', () => {
  const a = record('rimless', '308_win');
  const b = record('belted', '300_win_mag');
  const { body } = render(CompareFigure, { props: { overlay: profileOverlay(a, b), names: [a.name, b.name] } });

  it('is one image named for both cartridges', () => {
    expect(body).toContain('role="img"');
    expect(body).toContain('aria-label="Profiles of 308 Win. and 300 Win. Mag."');
  });

  it('has exactly one path per outline', () => {
    expect(body.match(/<(path|polyline|polygon)\b/g)).toHaveLength(2);
  });
});
