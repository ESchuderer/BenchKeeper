<script lang="ts">
  import { t } from '../lib/i18n.svelte';
  import type { CompareRow } from '../lib/compare';

  interface Props {
    rows: CompareRow[];
    names: [string, string];
    unit: 'mm' | 'in';
  }
  let { rows, names, unit }: Props = $props();
</script>

<div class="overflow-x-auto">
  <table class="w-full border-collapse text-sm">
    <caption class="mb-2 text-left font-semibold">{t('compare.dimensions', { unit })}</caption>
    <thead>
      <tr class="border-b">
        <th scope="col" class="py-1 pr-4 text-left font-medium">{t('compare.symbol')}</th>
        <th scope="col" class="py-1 pr-4 text-right font-medium">{names[0]}</th>
        <th scope="col" class="py-1 pr-4 text-right font-medium">{names[1]}</th>
        <th scope="col" class="py-1 text-right font-medium">{t('compare.difference')}</th>
      </tr>
    </thead>
    <tbody>
      {#each rows as row (row.symbol)}
        <tr class="border-b border-border/50">
          <td class="num py-1 pr-4 text-left">{row.symbol}</td>
          <td class="num py-1 pr-4 text-right">{row.a}</td>
          <td class="num py-1 pr-4 text-right">{row.b}</td>
          <td class="num py-1 text-right">{row.difference}</td>
        </tr>
      {/each}
    </tbody>
  </table>
</div>
