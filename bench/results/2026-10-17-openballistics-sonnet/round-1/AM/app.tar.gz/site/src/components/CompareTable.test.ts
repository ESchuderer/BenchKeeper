import { render } from 'svelte/server';
import { describe, expect, it } from 'vitest';
import CompareTable from './CompareTable.svelte';

const rows = [{ symbol: 'e min', a: '1.4', b: '0.94', difference: '-0.46' }];
const html = (unit: 'mm' | 'in') => render(CompareTable, { props: { rows, names: ['308 Win.', '300 Win. Mag.'], unit } }).body;
const text = (markup: string) => [...markup.matchAll(/<(th|td|caption)\b[^>]*>(.*?)<\/\1>/g)].map((m) => m[2]);

describe('CompareTable', () => {
  it('names the table by unit and heads the columns', () => {
    expect(text(html('mm')).slice(0, 5)).toEqual(['Dimensions (mm)', 'Symbol', '308 Win.', '300 Win. Mag.', 'Difference']);
    expect(text(html('in'))[0]).toBe('Dimensions (in)');
  });

  it('starts each row with the symbol, then the two values and the difference', () => {
    const cells = [...html('mm').matchAll(/<td\b[^>]*>(.*?)<\/td>/g)].map((m) => m[1]);
    expect(cells).toEqual(['e min', '1.4', '0.94', '-0.46']);
  });
});
