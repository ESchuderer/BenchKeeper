<script lang="ts">
  import {
  FIELD_LABELS,
  FIELD_UNITS,
  orderedColumns,
  orderedFields
} from '@lib/core';
import { orderedGroups } from '../lib/fields';
  import { formatValue, twistInInches } from '@lib/core';
  import type { Snippet } from 'svelte';
  import type {
  Group,
  GroupList,
  Value
} from '@lib/core';

  interface Props {
    side: 'cartridge' | 'chamber';
    heading: string;
    groups: Record<string, Group | GroupList>;
    /**
     * Anything else that belongs among this side's groups - the bullet the drawing puts in the
     * mouth is a property of the cartridge, not of the page. Rendered last, inside the same
     * columns, so it flows with the rest instead of hanging off the bottom of the side.
     */
    children?: Snippet;
    /**
     * The marking of the hull length the reader has picked, where the cartridge publishes several.
     * A shot cartridge's two repeating groups are the same list read from either side - the hull
     * lengths and the chambers cut for them - and both name each row with the same marking, so
     * picking 12/70 marks the row in both tables and the reader can read one cartridge across the
     * page instead of counting rows down two of them.
     */
    selected?: string | null;
  }
  let { side, heading, groups, selected = null, children }: Props = $props();

  function label(field: string): string {
    return FIELD_LABELS[field] ?? field;
  }
  function unit(field: string): string {
    return FIELD_UNITS[field] ?? 'mm';
  }
  function tolerance(group: Group, field: string): string | null {
    return formatValue((group[`${field}Tol`] ?? null) as Value);
  }

  /**
   * Whether a group has anything to show.
   *
   * A sheet that dimensions no junction cone still carries the heading with every row blank, and
   * rendering that is rendering a heading over nothing - on a straight-walled pistol case it is
   * most of the page. The heading appears only where the sheet actually states a value.
   *
   * Tolerances do not count. A `L1Tol` with no `L1` would be a tolerance on a dimension that is not
   * published, which is not something to build a section around.
   */
  function hasValues(group: Group | GroupList): boolean {
    if (Array.isArray(group)) return group.length > 0;
    return Object.entries(group).some(
      ([field, value]) => !field.endsWith('Tol') && value !== null && value !== undefined
    );
  }
</script>

<section class="side">
  <h2>{heading}</h2>

  <!--
    The groups flow into two columns where the side is wide enough for them, and always on paper.

    A side is a stack of short groups - Lengths, Case Head, Powder Chamber - each a few rows of
    "L1  39.62 mm", and stacked in one column they made the page three screens tall with the right
    half of every column empty. Two columns halve that, and a group is never split between them,
    so a heading always sits over its own rows. A repeating group is a table with a column per
    field and needs the whole width, so it spans both.
  -->
  <div class="groups">
  {#each orderedGroups(side, groups) as [name, title] (name)}
    {@const group = groups[name] ?? {}}
    {#if hasValues(group) && Array.isArray(group)}
    <!--
      A repeating group - a shot cartridge's hull lengths, its chamber's lengths - is a table
      with one row per entry. It used to fall through the field renderer, which showed each entry
      as "0: [object Object]" (reported 2026-09-03).
    -->
    {@const columns = orderedColumns(side, name, group)}
    <div class="group wide">
      <h3>{title}</h3>
      <div class="scroll">
        <table>
          <thead>
            <tr>
              {#each columns as column (column)}
                <th class="num">{label(column)}{#if unit(column)} <span class="unit">{unit(column)}</span>{/if}</th>
              {/each}
            </tr>
          </thead>
          <tbody>
            {#each group as row, index (index)}
              <tr class:selected={selected !== null && row.marking === selected}>
                {#each columns as column (column)}
                  {@const shown = formatValue((row[column] ?? null) as Value)}
                  <td class="num" class:silent={shown === null}>{shown ?? '-'}</td>
                {/each}
              </tr>
            {/each}
          </tbody>
        </table>
      </div>
    </div>
    {:else if hasValues(group) && !Array.isArray(group)}
    <div class="group">
      <h3>{title}</h3>
      <dl>
        {#each orderedFields(side, name, group) as field (field)}
          {@const shown = formatValue(group[field] ?? null)}
          {@const tol = tolerance(group, field)}
          <dt class="num">{label(field)}</dt>
          <dd class:silent={shown === null}>
            {#if shown === null}
              <span title="Not published">-</span>
            {:else}
              <span class="num value">{shown}</span>
              {#if unit(field)}<span class="unit">{unit(field)}</span>{/if}
              {#if tol}<span class="num tol">{tol}</span>{/if}
              {#if field === 'u' && typeof group[field] === 'number'}
                <span class="alt-unit num">{twistInInches(group[field] as number)}</span>
              {/if}
            {/if}
          </dd>
        {/each}
      </dl>
    </div>
    {/if}
  {/each}
  {@render children?.()}
  </div>
</section>

<style>
  @layer legacy {
  .side {
    min-width: 0;
    /* Sized by its own width rather than the window's: the side is one of two columns on a wide
       page and the only column on a phone, and how many sub-columns it can hold depends on which. */
    container-type: inline-size;
  }
  h2 {
    font-size: var(--step-1);
    letter-spacing: 0.08em;
    text-transform: uppercase;
    padding-bottom: 0.5rem;
    border-bottom: 2px solid var(--rule-strong);
    margin-bottom: 1rem;
  }
  .groups {
    column-gap: 2rem;
  }
  .group {
    break-inside: avoid;
    margin-bottom: 1.1rem;
  }
  /* A group that spans both sub-columns interrupts the flow, so it carries its own space above:
     without it the heading of whatever follows sits on the last row of the table. */
  .group.wide {
    column-span: all;
  }
  .group.wide + .group,
  .group + .group.wide {
    margin-top: 0.6rem;
  }
  /* Room for two: a label column and a value each side of a 2rem gutter, in a side 36rem wide. */
  @container (min-width: 36rem) {
    .groups {
      columns: 2;
    }
  }
  h3 {
    font-size: var(--step-0);
    color: var(--ink);
    margin-bottom: 0.3rem;
  }
  dl {
    display: grid;
    grid-template-columns: 5.5rem 1fr;
    gap: 0.15rem 0.75rem;
    margin: 0;
    align-items: baseline;
  }
  dt {
    color: var(--ink-2);
    font-size: var(--step-0);
  }
  dd {
    margin: 0;
    display: flex;
    align-items: baseline;
    gap: 0.4rem;
    flex-wrap: wrap;
  }
  .value {
    font-weight: 500;
  }
  /* Sized against the value they annotate rather than against the root: at a fixed `rem` these
     came out larger than the figure on a printed sheet, where the page's own type is 8pt and the
     "mm" after 39.62 was the loudest thing in the row. */
  .unit,
  .tol,
  .alt-unit {
    font-size: 0.78em;
    color: var(--ink-3);
  }
  .tol::before {
    content: '';
  }
  .alt-unit {
    color: var(--link);
  }
  .silent {
    color: var(--ink-3);
  }
  .scroll {
    overflow-x: auto;
  }
  table {
    border-collapse: collapse;
    font-size: var(--step-0);
    width: 100%;
  }
  th,
  td {
    text-align: right;
    padding: 0.2rem 0.6rem 0.2rem 0;
    white-space: nowrap;
  }
  th {
    color: var(--ink-2);
    font-weight: 500;
    border-bottom: 1px solid var(--rule);
  }
  td:first-child,
  th:first-child {
    text-align: left;
  }
  td {
    font-weight: 500;
  }
  /* The picked length, in both tables. Marked with weight and a rule rather than a fill, so that
     it survives a print, where backgrounds are dropped by default. */
  tbody tr.selected td {
    color: var(--ink);
    font-weight: 700;
    background: var(--accent-soft);
    box-shadow: inset 0 -1px 0 var(--link), inset 0 1px 0 var(--link);
  }
  tbody tr.selected td:first-child {
    box-shadow: inset 0 -1px 0 var(--link), inset 0 1px 0 var(--link),
      inset 2px 0 0 var(--link);
  }
  @media print {
    /* Two sub-columns whatever the side measures: the sheet is 180 mm across, each side has 88 of
       them, and one column of rows per side is what used to push the tables onto a second page. */
    .groups {
      columns: 2;
      column-gap: 4mm;
    }
    .group {
      margin-bottom: 2mm;
    }
    .group.wide + .group,
    .group + .group.wide {
      margin-top: 3mm;
    }
    tbody tr.selected td,
    tbody tr.selected td:first-child {
      background: transparent;
      box-shadow: none;
      text-decoration: underline;
    }
  }
  }
</style>
