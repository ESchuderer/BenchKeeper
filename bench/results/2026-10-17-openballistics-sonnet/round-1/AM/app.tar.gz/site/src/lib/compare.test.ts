import { readFileSync } from 'node:fs';
import { join } from 'node:path';
import { describe, expect, it } from 'vitest';
import { FIELD_LABELS, FIELD_UNITS, type Record_ } from '@lib/core';
import { CARTRIDGES } from '@lib/testing/fixtures';
import { compareRows, profileOverlay } from './compare';

const record = (family: string, key: string) =>
  JSON.parse(readFileSync(join(CARTRIDGES, family, `${key}.json`), 'utf8')) as Record_;
const a = record('rimless', '308_win');
const b = record('belted', '300_win_mag');
const row = (rows: ReturnType<typeof compareRows>, symbol: string) => rows.find((r) => r.symbol === symbol);

describe('compareRows', () => {
  const rows = compareRows(a, b, 'mm');

  it('lists the millimetre dimensions either cartridge publishes, in the order of the detail page', () => {
    expect(rows.map((r) => r.symbol)).toEqual([
      'L1', 'L2', 'L3', 'L6', 'R', 'R1', 'R3', 'E', 'E1', 'e min', 'f', 'P1', 'P2', 'S', 'r1 min', 'r2', 'H1', 'H2', 'G1',
      'L3 + G', 'Fe', 'delta L'
    ]);
  });

  it('leaves out tolerances, pressures and angles', () => {
    const symbols = new Set(rows.map((r) => r.symbol));
    for (const field of Object.keys(FIELD_UNITS)) expect(symbols.has(FIELD_LABELS[field] ?? field)).toBe(false);
    expect([...symbols].some((s) => /Tol$/.test(s))).toBe(false);
  });

  it('leaves the cell of a cartridge that does not publish a dimension, and the difference, empty', () => {
    expect(row(rows, 'delta L')).toEqual({ symbol: 'delta L', a: '0.1', b: '', difference: '' });
    expect(row(rows, 'R3')).toEqual({ symbol: 'R3', a: '', b: '13.51', difference: '' });
  });

  it('writes the symbol as the detail page does', () => {
    expect(row(rows, 'e min')).toBeDefined();
    expect(row(rows, 'eMin')).toBeUndefined();
  });

  it('writes values as published and the difference as B minus A without float noise', () => {
    expect(row(rows, 'L6')).toEqual({ symbol: 'L6', a: '71.12', b: '84.84', difference: '13.72' });
    expect(row(rows, 'f')).toEqual({ symbol: 'f', a: '0.38', b: '0.41', difference: '0.03' });
    expect(row(rows, 'e min')).toEqual({ symbol: 'e min', a: '1.4', b: '0.94', difference: '-0.46' });
  });

  it('converts values and differences to inches in imperial units', () => {
    const inch = compareRows(a, b, 'in');
    expect(row(inch, 'L1')).toEqual({
      symbol: 'L1', a: '1.55984251969', b: '2.19606299213', difference: '0.636220472441'
    });
  });

  it('shows a difference of zero as 0', () => {
    expect(compareRows(a, a, 'mm').every((r) => r.difference === '0')).toBe(true);
  });
});

describe('profileOverlay', () => {
  const overlay = profileOverlay(a, b);

  it('draws both outlines in one frame, head faces on one line', () => {
    expect(overlay.paths).toHaveLength(2);
    const head = overlay.paths.map((d) => Number(d.match(/^M([\d.]+),/)![1]));
    expect(head[0]).toBe(head[1]);
    expect(head[0]).toBeGreaterThan(0);
  });

  it('draws the longer case longer, at one scale', () => {
    const reach = (d: string) => Math.max(...[...d.matchAll(/[ML]([\d.]+),/g)].map((m) => Number(m[1])));
    expect(reach(overlay.paths[1]!)).toBeGreaterThan(reach(overlay.paths[0]!));
    expect(overlay.axis.y).toBeGreaterThan(0);
  });

  it('reports a case that cannot be drawn', () => {
    const bad = record('rimmed', '297_230_morris_lg');
    expect(() => profileOverlay(a, bad)).toThrow(/R1 is not published/);
  });
});
