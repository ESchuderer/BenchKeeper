/** What the comparison view shows: the dimensions two cartridges publish and their outlines overlaid. */

import { FIELD_LABELS, FIELD_UNITS, GROUP_ORDER, formatValue, orderedFields, type Record_ } from '@lib/core';
import { fullSectionPath, viewportFor } from '@lib/geom';
import { adaptMetallic, caseOuterProfile, type CartridgeRecord } from '@lib/shapes2d';
import { displayNumber, type Unit } from './units';

export interface CompareRow {
  symbol: string;
  a: string;
  b: string;
  /** B minus A. */
  difference: string;
}

/** The millimetre dimensions of the `cartridge` part, by symbol, in the order the detail page prints them. */
function dimensions(record: Record_): Map<string, number> {
  const groups = record.cartridge;
  const known = GROUP_ORDER.cartridge.filter((name) => name in groups);
  const rest = Object.keys(groups).filter((name) => !known.includes(name)).sort();
  const out = new Map<string, number>();
  for (const name of [...known, ...rest]) {
    const group = groups[name];
    if (!group || Array.isArray(group)) continue;
    for (const field of orderedFields('cartridge', name, group)) {
      const value = group[field];
      if (typeof value === 'number' && !Object.hasOwn(FIELD_UNITS, field)) out.set(FIELD_LABELS[field] ?? field, value);
    }
  }
  return out;
}

/** One row per dimension either record publishes. Where one does not, its cell and the difference are empty. Millimetres are written as the detail page does, inches converted. */
export function compareRows(a: Record_, b: Record_, unit: Extract<Unit, 'mm' | 'in'>): CompareRow[] {
  const first = dimensions(a);
  const second = dimensions(b);
  // A symbol only B publishes goes after the symbol that precedes it in B.
  const order = [...first.keys()];
  let at = -1;
  for (const symbol of second.keys()) {
    const i = order.indexOf(symbol);
    if (i >= 0) at = i;
    else order.splice(++at, 0, symbol);
  }
  const show = (mm: number | undefined) =>
    mm === undefined ? '' : unit === 'mm' ? formatValue(mm)! : displayNumber(mm, unit);
  return order.map((symbol) => {
    const x = first.get(symbol);
    const y = second.get(symbol);
    // `displayNumber` also drops the float noise of the subtraction (84.84 - 71.12).
    const difference = x === undefined || y === undefined ? '' : displayNumber(y - x, unit);
    return { symbol, a: show(x), b: show(y), difference };
  });
}

/** Both outer profiles in one frame (head face at z = 0, one axis, one scale), as closed section paths. Throws where a case cannot be built. */
export function profileOverlay(a: Record_, b: Record_) {
  const outline = (record: Record_) => caseOuterProfile(adaptMetallic(record as unknown as CartridgeRecord));
  const profiles = [outline(a), outline(b)];
  const view = viewportFor(profiles, { scale: 10, marginMm: 2, frame: 'landscape' });
  const [x1, y] = view.xy(0, view.zMin);
  return {
    width: view.width,
    height: view.height,
    paths: profiles.map((profile) => fullSectionPath(profile, view)),
    axis: { x1, x2: view.xy(0, view.zMax)[0], y }
  };
}
