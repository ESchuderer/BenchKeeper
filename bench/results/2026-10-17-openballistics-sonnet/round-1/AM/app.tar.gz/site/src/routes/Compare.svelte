<script lang="ts">
  import CompareFigure from '../components/CompareFigure.svelte';
  import CompareTable from '../components/CompareTable.svelte';
  import { compareRows, profileOverlay } from '../lib/compare';
  import { load } from '../lib/data';
  import { t } from '../lib/i18n.svelte';
  import { href } from '../lib/router';
  import { unitSystem } from '../lib/units.svelte';

  interface Props {
    a: string;
    b: string;
  }
  let { a, b }: Props = $props();

  const records = $derived(Promise.all([load(a), load(b)]));
  const unit = $derived(unitSystem() === 'metric' ? 'mm' : 'in');

  /** The overlay, or the reason the profiles cannot be drawn (two records lack a dimension the case needs). */
  function drawn(x: Parameters<typeof profileOverlay>[0], y: Parameters<typeof profileOverlay>[1]) {
    try {
      return { overlay: profileOverlay(x, y) };
    } catch (error) {
      return { reason: error instanceof Error ? error.message : String(error) };
    }
  }
</script>

<div data-ui="Compare" class="contents">
{#await records}
  <p class="py-8 text-muted-foreground" role="status">{t('site.loading')}</p>
{:then [x, y]}
  <h1 class="mb-6 text-3xl font-semibold">{t('compare.heading', { a: x.name, b: y.name })}</h1>
  {#if x.family === 'shotshell' || y.family === 'shotshell'}
    <p>{t('compare.shot')}</p>
  {:else}
    {@const figure = drawn(x, y)}
    {@const rows = compareRows(x, y, unit)}
    {#if figure.overlay}
      <figure class="mb-8 rounded-lg border bg-card p-4">
        <CompareFigure overlay={figure.overlay} names={[x.name, y.name]} />
        <figcaption class="mt-3 flex flex-wrap gap-x-6 gap-y-1 text-sm">
          <a href={href.cartridge(x.key)} class="underline"><span aria-hidden="true" class="mr-1 inline-block w-6 border-t-2 border-solid align-middle" style="border-color: var(--ink)"></span> {x.name}</a>
          <a href={href.cartridge(y.key)} class="underline"><span aria-hidden="true" class="mr-1 inline-block w-6 border-t-2 border-dashed align-middle" style="border-color: var(--link)"></span> {y.name}</a>
        </figcaption>
      </figure>
    {:else}
      <p class="mb-8 text-sm" role="status">{t('compare.notDrawn', { reason: figure.reason ?? '' })}</p>
    {/if}
    {#if rows.length}
      <CompareTable {rows} names={[x.name, y.name]} {unit} />
    {:else}
      <p>{t('compare.noShared')}</p>
    {/if}
  {/if}
{:catch error}
  <p class="py-8" role="alert">{error.message} <a href={href.list()} class="underline">{t('record.back')}</a></p>
{/await}
</div>
