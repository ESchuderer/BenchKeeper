# Compare two cartridges

Status: ready-for-agent

## Goal

A view at `#/compare/<a>/<b>` (keys as in `#/c/<key>`) that compares two cartridges. It opens from the URL and survives a reload.

## Acceptance criteria

- One SVG, role `img`, accessible name `Profiles of <name A> and <name B>`. It holds the `caseOuterProfile` outlines of both cases at one scale on one axis, head faces at the same point. One `path` per outline. Shot cartridges are out of scope.
- A table named `Dimensions (mm)` or `Dimensions (in)` with the headers `Symbol`, name A, name B, `Difference`. One row per symbol that either record publishes as a number in `cartridge` with no entry in `FIELD_UNITS` and no `Tol` suffix. The first cell is the `FIELD_LABELS` symbol. `Difference` is B minus A. Where a record does not publish the symbol, its cell and `Difference` are empty. The cells of the two cartridge columns and of `Difference`, headers included, are right-aligned.
- Metric values are written with `formatValue`. Imperial values and differences are converted with `displayNumber`. No further rounding.
- Units follow the `Default units` setting.
- The detail page has a select labelled `Compare with` (other cartridges by name) and a button `Compare` that opens `#/compare/<this key>/<chosen key>`.
- English and German texts.
- Tests for the new code; existing tests pass.
