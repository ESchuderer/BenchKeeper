<script lang="ts">
  import { Button } from '$lib/components/ui/button/index.js';
  import { Label } from '$lib/components/ui/label/index.js';
  import { NativeSelect } from '$lib/components/ui/native-select/index.js';
  import { entries } from '../lib/data';
  import { href } from '../lib/router';
  import { t } from '../lib/i18n.svelte';

  /** Picks a second cartridge and opens the comparison of the two. */
  let { cartridge }: { cartridge: string } = $props();
  const id = $props.id();

  const others = $derived(
    entries.filter((entry) => entry.key !== cartridge).sort((a, b) => a.name.localeCompare(b.name, 'en'))
  );
  let picked = $state('');
  const target = $derived(others.some((entry) => entry.key === picked) ? picked : (others[0]?.key ?? ''));
</script>

<form
  class="mb-6 flex flex-wrap items-end gap-3 print:hidden"
  onsubmit={(event) => {
    event.preventDefault();
    if (target) location.hash = href.compare(cartridge, target).slice(1);
  }}
>
  <div class="grid w-full max-w-xs gap-1.5">
    <Label for={`${id}-with`}>{t('compare.with')}</Label>
    <NativeSelect id={`${id}-with`} value={target} onchange={(event) => (picked = event.currentTarget.value)}>
      {#each others as entry (entry.key)}<option value={entry.key}>{entry.name}</option>{/each}
    </NativeSelect>
  </div>
  <Button type="submit" variant="outline" disabled={!target}>{t('compare.action')}</Button>
</form>
