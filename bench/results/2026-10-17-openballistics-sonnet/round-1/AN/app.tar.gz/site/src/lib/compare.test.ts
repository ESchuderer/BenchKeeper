import { readFileSync } from 'node:fs';
import { join } from 'node:path';
import { describe, expect, it } from 'vitest';
import { FIELD_LABELS, FIELD_UNITS, formatValue, type Group, type Record_ } from '@lib/core';
import { adaptMetallic, caseOuterProfile, type CartridgeRecord } from '@lib/shapes2d';
import { CARTRIDGES } from '../../../lib/testing/fixtures';
import { compareRows, dimensionsOf, lengthUnit, overlayOf } from './compare';
import { displayNumber } from './units';

const read = (family: string, key: string): Record_ => JSON.parse(readFileSync(join(CARTRIDGES, family, `${key}.json`), 'utf8'));
const a = read('rimless', '308_win');
const b = read('belted', '300_win_mag');

const l3 = (record: Record_): number => (record.cartridge.lengths as Group).L3 as number;

const numbers = (d: string): number[] => (d.match(/-?\d+(?:\.\d+)?/g) ?? []).map(Number);
const coordinates = (d: string) => {
  const values = numbers(d);
  const xs = values.filter((_, i) => i % 2 === 0);
  const ys = values.filter((_, i) => i % 2 === 1);
  return { xs, ys };
};

describe('dimensions', () => {
  it('keeps millimetre numbers of the cartridge part and drops tolerances and other units', () => {
    const fields = dimensionsOf(a).map((dimension) => dimension.field);
    expect(fields).toEqual(expect.arrayContaining(['L1', 'L3', 'L6', 'R', 'R1', 'E', 'E1', 'eMin', 'P1', 'P2', 'G1']));
    for (const field of fields) {
      expect(field.endsWith('Tol')).toBe(false);
      expect(FIELD_UNITS).not.toHaveProperty(field);
    }
    for (const field of ['Pmax', 'PK', 'PE', 'EE', 'M', 'alpha', 'beta', 'delta', 'L1Tol', 'F', 'Z']) {
      expect(fields).not.toContain(field);
    }
  });

  it('does not take the chamber or a repeating group', () => {
    const record = {
      cartridge: { lengths: [{ l: 70 }], collar: { H1: 8 } },
      chamber: { barrel: { F: 7.62 } }
    } as unknown as Record_;
    expect(dimensionsOf(record).map((dimension) => dimension.field)).toEqual(['H1']);
  });
});

describe('table rows', () => {
  const rows = compareRows(a, b, 'metric');

  const fieldsA = dimensionsOf(a).map((d) => d.field);
  const fieldsB = dimensionsOf(b).map((d) => d.field);
  const label = (field: string): string => FIELD_LABELS[field] ?? field;
  const rowOf = (field: string) => rows.find((row) => row.symbol === label(field))!;

  it('has a row per symbol either record publishes, A\'s first, with the detail page symbol', () => {
    const union = [...fieldsA, ...fieldsB.filter((f) => !fieldsA.includes(f))];
    expect(rows.map((row) => row.symbol)).toEqual(union.map(label));
    expect(rows.map((row) => row.symbol)).toContain('e min');
  });

  it('lists a symbol only one cartridge publishes, with the other cells empty', () => {
    const onlyA = fieldsA.filter((f) => !fieldsB.includes(f));
    const onlyB = fieldsB.filter((f) => !fieldsA.includes(f));
    expect(onlyA).toContain('deltaL');
    expect(onlyB).toContain('R3');
    for (const field of onlyA) expect(rowOf(field)).toMatchObject({ b: '', difference: '' });
    for (const field of onlyB) expect(rowOf(field)).toMatchObject({ a: '', difference: '' });
    for (const field of onlyA) expect(rowOf(field).a).not.toBe('');
    for (const field of onlyB) expect(rowOf(field).b).not.toBe('');
  });

  it('writes metric values as the detail page does and the difference as B minus A', () => {
    const row = rows.find((r) => r.symbol === 'L3')!;
    const valueA = l3(a);
    const valueB = l3(b);
    expect(row).toEqual({
      symbol: 'L3',
      a: formatValue(valueA),
      b: formatValue(valueB),
      difference: formatValue(valueB - valueA)
    });
  });

  it('converts values and differences to inches without further rounding', () => {
    const inches = compareRows(a, b, 'imperial');
    const row = inches.find((r) => r.symbol === 'L3')!;
    const valueA = l3(a);
    const valueB = l3(b);
    expect(row).toEqual({
      symbol: 'L3',
      a: displayNumber(valueA, 'in'),
      b: displayNumber(valueB, 'in'),
      difference: displayNumber(valueB - valueA, 'in')
    });
    expect(inches).toHaveLength(rows.length);
    expect(inches.find((r) => r.symbol === label('R3'))).toMatchObject({ a: '', difference: '' });
  });

  it('keeps the symbols of records that share nothing', () => {
    const first = { ...a, cartridge: { collar: { H1: 1 } } } as unknown as Record_;
    const second = { ...b, cartridge: { collar: { H2: 2 } } } as unknown as Record_;
    expect(compareRows(first, second, 'metric')).toEqual([
      { symbol: label('H1'), a: formatValue(1), b: '', difference: '' },
      { symbol: label('H2'), a: '', b: formatValue(2), difference: '' }
    ]);
  });

  it('is empty when neither record publishes a dimension', () => {
    const none = { ...a, cartridge: {} } as unknown as Record_;
    expect(compareRows(none, none, 'metric')).toEqual([]);
  });

  it('names the unit of the preference', () => {
    expect(lengthUnit('metric')).toBe('mm');
    expect(lengthUnit('imperial')).toBe('in');
  });
});

describe('profile overlay', () => {
  const overlay = overlayOf(a, b)!;
  const [boxA, boxB] = overlay.paths.map((d) => coordinates(d));
  const range = (values: number[]) => [Math.min(...values), Math.max(...values)] as const;

  it('draws one closed outline per cartridge', () => {
    expect(overlay.paths).toHaveLength(2);
    for (const d of overlay.paths) {
      expect(d.startsWith('M')).toBe(true);
      expect(d.endsWith('Z')).toBe(true);
      expect(d.match(/M/g)).toHaveLength(1);
    }
  });

  it('puts the head faces at the same height and the axes in the same place', () => {
    const [, bottomA] = range(boxA!.ys);
    const [, bottomB] = range(boxB!.ys);
    expect(bottomA).toBe(bottomB);
    const [leftA, rightA] = range(boxA!.xs);
    const [leftB, rightB] = range(boxB!.xs);
    expect((leftA + rightA) / 2).toBeCloseTo((leftB + rightB) / 2, 4);
  });

  it('uses one scale for both outlines', () => {
    const profileA = caseOuterProfile(adaptMetallic(a as unknown as CartridgeRecord));
    const profileB = caseOuterProfile(adaptMetallic(b as unknown as CartridgeRecord));
    const length = (profile: [number, number][]) => Math.max(...profile.map((p) => p[1]));
    const width = (profile: [number, number][]) => Math.max(...profile.map((p) => p[0]));
    const [topA, bottomA] = range(boxA!.ys);
    const [topB, bottomB] = range(boxB!.ys);
    const [leftA, rightA] = range(boxA!.xs);
    const [leftB, rightB] = range(boxB!.xs);
    const scale = (bottomA - topA) / length(profileA);
    expect((bottomB - topB) / length(profileB)).toBeCloseTo(scale, 4);
    expect((rightA - leftA) / (2 * width(profileA))).toBeCloseTo(scale, 4);
    expect((rightB - leftB) / (2 * width(profileB))).toBeCloseTo(scale, 4);
  });

  it('has no outline for a shot cartridge', () => {
    const shot = read('shotshell', '12');
    expect(overlayOf(a, shot)).toBeNull();
  });
});
