/**
 * What the comparison view shows: the dimensions two cartridges publish, and their case
 * outlines drawn on one axis. Framework-free, so the view itself only lays it out.
 */

import {
  FIELD_LABELS,
  FIELD_UNITS,
  GROUP_ORDER,
  PX_PER_MM,
  formatValue,
  orderedFields,
  toleranceFor,
  type Group,
  type Record_
} from '@lib/core';
import { fullSectionPath, viewportFor } from '@lib/geom';
import { adaptMetallic, caseOuterProfile, type CartridgeRecord } from '@lib/shapes2d';
import { defaultUnit, displayNumber, type UnitSystem } from './units';

const has = (object: object, key: string): boolean => Object.prototype.hasOwnProperty.call(object, key);

/** A dimension of the cartridge: a number in millimetres, keyed by the symbol the sheet uses. */
export interface Dimension {
  field: string;
  value: number;
}

/**
 * The record's dimensions in the order the detail page shows them. Tolerances and fields with a
 * unit of their own (pressures, angles, energy) are not dimensions, and neither are the repeating
 * groups of a shot cartridge.
 */
export function dimensionsOf(record: Record_): Dimension[] {
  const groups = Object.keys(record.cartridge);
  const order = [
    ...GROUP_ORDER.cartridge.filter((name) => has(record.cartridge, name)),
    ...groups.filter((name) => !GROUP_ORDER.cartridge.includes(name)).sort()
  ];
  const found = new Map<string, Dimension>();
  for (const name of order) {
    const group = record.cartridge[name];
    if (!group || Array.isArray(group)) continue;
    for (const field of orderedFields('cartridge', name, group)) {
      const value = (group as Group)[field];
      if (typeof value !== 'number' || !Number.isFinite(value)) continue;
      if (toleranceFor(field) !== null || has(FIELD_UNITS, field) || found.has(field)) continue;
      found.set(field, { field, value });
    }
  }
  return [...found.values()];
}

export interface Row {
  symbol: string;
  a: string;
  b: string;
  difference: string;
}

/** The unit the table is written in. */
export const lengthUnit = (system: UnitSystem): 'mm' | 'in' => defaultUnit('length', system) as 'mm' | 'in';

/**
 * One row per symbol either record publishes: A's symbols in A's order, then those only B
 * publishes. Metric figures are written as the detail page writes them; inches go through
 * `displayNumber`. The difference is B minus A in millimetres, converted and written like the
 * values. The cell of a record that does not publish the symbol is empty, and so is the
 * difference.
 */
export function compareRows(a: Record_, b: Record_, system: UnitSystem): Row[] {
  const unit = lengthUnit(system);
  const write = (millimetres: number): string =>
    unit === 'mm' ? (formatValue(millimetres) as string) : displayNumber(millimetres, unit);
  const first = new Map(dimensionsOf(a).map((dimension) => [dimension.field, dimension.value]));
  const second = new Map(dimensionsOf(b).map((dimension) => [dimension.field, dimension.value]));
  const fields = [...first.keys(), ...[...second.keys()].filter((field) => !first.has(field))];
  return fields.map((field) => {
    const valueA = first.get(field);
    const valueB = second.get(field);
    return {
      symbol: has(FIELD_LABELS, field) ? FIELD_LABELS[field]! : field,
      a: valueA === undefined ? '' : write(valueA),
      b: valueB === undefined ? '' : write(valueB),
      difference: valueA === undefined || valueB === undefined ? '' : write(valueB - valueA)
    };
  });
}

export interface Overlay {
  width: number;
  height: number;
  /** One closed outline per cartridge, A then B. */
  paths: [string, string];
  /** The stroke width, in the drawing's units. */
  stroke: number;
}

const MARGIN_MM = 2;
const STROKE_MM = 0.25;

/**
 * Both case outlines in one viewport: one scale, the case axis in the same place and the head
 * faces at the same height. `null` for a cartridge that has no case outline (a shot cartridge,
 * or a record too short of dimensions to draw one).
 */
export function overlayOf(a: Record_, b: Record_): Overlay | null {
  try {
    if (a.family === 'shotshell' || b.family === 'shotshell') return null;
    const profiles = [a, b].map((record) => caseOuterProfile(adaptMetallic(record as unknown as CartridgeRecord)));
    const view = viewportFor(profiles, { scale: PX_PER_MM, marginMm: MARGIN_MM });
    const [first, second] = profiles.map((profile) => fullSectionPath(profile, view)) as [string, string];
    return { width: view.width, height: view.height, paths: [first, second], stroke: view.length(STROKE_MM) };
  } catch {
    return null;
  }
}
