<script lang="ts">
  import PageHeader from '../components/PageHeader.svelte';
  import PageLoadError from '../components/PageLoadError.svelte';
  import { byKey, load } from '../lib/data';
  import { compareRows, lengthUnit, overlayOf } from '../lib/compare';
  import { href } from '../lib/router';
  import { t } from '../lib/i18n.svelte';
  import { unitSystem } from '../lib/units.svelte';

  interface Props {
    a: string;
    b: string;
  }
  let { a, b }: Props = $props();

  const unknown = $derived([a, b].find((key) => !byKey(key)));
  const records = $derived(unknown ? null : Promise.all([load(a), load(b)]));
</script>

<div data-ui="Compare" class="contents">
  <PageHeader title={t('compare.title')} description={t('compare.lede')} backHref={href.cartridge(a)} backLabel={byKey(a)?.name ?? a} />

  {#if unknown}
    <p class="status" role="alert">{t('compare.unknown', { key: unknown })}</p>
  {:else}
    {#await records}
      <p class="status" role="status">{t('site.loading')}</p>
    {:then [first, second]}
      {@const overlay = overlayOf(first, second)}
      {@const rows = compareRows(first, second, unitSystem())}
      <figure class="overlay">
        {#if overlay}
          <svg
            role="img"
            aria-label={t('compare.profiles', { a: first.name, b: second.name })}
            width={overlay.width}
            height={overlay.height}
            viewBox={`0 0 ${overlay.width} ${overlay.height}`}
          >
            <path class="a" d={overlay.paths[0]} fill="none" stroke-width={overlay.stroke} stroke-linejoin="round" />
            <path class="b" d={overlay.paths[1]} fill="none" stroke-width={overlay.stroke} stroke-linejoin="round" stroke-dasharray={`${overlay.stroke * 4} ${overlay.stroke * 2}`} />
          </svg>
        {:else}
          <p class="status">{t('compare.noProfile')}</p>
        {/if}
        <figcaption>
          <ul class="legend">
            <li><span class="swatch a" aria-hidden="true"></span><a href={href.cartridge(first.key)}>{first.name}</a></li>
            <li><span class="swatch b" aria-hidden="true"></span><a href={href.cartridge(second.key)}>{second.name}</a></li>
          </ul>
        </figcaption>
      </figure>

      {#if rows.length}
        <div class="scroll-x">
          <table>
            <caption>{t('compare.dimensions', { unit: lengthUnit(unitSystem()) })}</caption>
            <thead>
              <tr>
                <th>{t('compare.symbol')}</th>
                <th class="num">{first.name}</th>
                <th class="num">{second.name}</th>
                <th class="num">{t('compare.difference')}</th>
              </tr>
            </thead>
            <tbody>
              {#each rows as row (row.symbol)}
                <tr>
                  <td>{row.symbol}</td>
                  <td class="num">{row.a}</td>
                  <td class="num">{row.b}</td>
                  <td class="num">{row.difference}</td>
                </tr>
              {/each}
            </tbody>
          </table>
        </div>
        <p class="note">{t('compare.differenceNote', { a: first.name, b: second.name })}</p>
      {:else}
        <p class="status">{t('compare.noShared')}</p>
      {/if}
    {:catch}
      <PageLoadError />
    {/await}
  {/if}
</div>

<style>
  @layer legacy {
    .status, .note { color: var(--ink-2); font-size: var(--step-0); }
    .overlay { margin: 0 0 2rem; padding: 1rem; border: 1px solid var(--rule); border-radius: var(--panel-radius); background: var(--surface); overflow-x: auto; }
    svg { display: block; max-width: 100%; height: auto; margin-inline: auto; }
    /* Series 1 and 2 of the categorical palette; the second is also dashed so the pair never
       depends on hue alone. */
    .a { stroke: #2a78d6; }
    .b { stroke: #eb6834; }
    .swatch { display: inline-block; width: 1.5rem; height: 0; margin-right: .5rem; vertical-align: middle; border-top: 3px solid; }
    .swatch.a { border-color: #2a78d6; }
    .swatch.b { border-color: #eb6834; border-top-style: dashed; }
    :global([data-theme='dark']) .a { stroke: #3987e5; }
    :global([data-theme='dark']) .b { stroke: #d95926; }
    :global([data-theme='dark']) .swatch.a { border-color: #3987e5; }
    :global([data-theme='dark']) .swatch.b { border-color: #d95926; }
    .legend { display: flex; flex-wrap: wrap; gap: .5rem 1.5rem; margin: .75rem 0 0; padding: 0; list-style: none; font-size: var(--step-0); }
    .scroll-x { overflow-x: auto; border: 1px solid var(--rule); border-radius: var(--panel-radius); background: var(--surface); }
    table { width: 100%; border-collapse: collapse; font-size: var(--step-0); }
    caption { padding: .55rem .7rem; text-align: left; font-weight: 600; }
    th, td { padding: .55rem .7rem; text-align: right; border-bottom: 1px solid var(--rule); font-variant-numeric: tabular-nums; }
    th:first-child, td:first-child { text-align: left; }
    th { color: var(--ink-2); font-weight: 500; border-bottom: 2px solid var(--rule-strong); }
  }
</style>
