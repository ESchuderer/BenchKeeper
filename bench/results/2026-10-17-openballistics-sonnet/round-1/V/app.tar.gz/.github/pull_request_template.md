<!-- The title follows Conventional Commits, e.g. `fix(data): correct 308 Win. case length L3`.
     It becomes the commit message when the pull request is squash-merged. -->

## What and why

## Source

<!-- For a data change: where each figure comes from (C.I.P. sheet and revision, manufacturer
     specification, or your measurement and instrument). Delete if the change touches no data. -->

## Checklist

- [ ] `npm test` and `npm run build` pass in `site/`
- [ ] The title follows the commit convention in CONTRIBUTING.md
- [ ] `CHANGELOG.md` has an entry under Unreleased, if the change is visible to users
