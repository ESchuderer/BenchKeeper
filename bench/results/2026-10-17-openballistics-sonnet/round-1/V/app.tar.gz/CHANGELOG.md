# Changelog

All notable changes to OpenBallistics are recorded here.

The format follows [Keep a Changelog 1.1.0](https://keepachangelog.com/en/1.1.0/) and the project
follows [Semantic Versioning 2.0.0](https://semver.org/spec/v2.0.0.html). Each release has a
heading `## [X.Y.Z] - YYYY-MM-DD` with the sections Added, Changed, Deprecated, Removed, Fixed and
Security, in that order and only those that apply. Entries are written for readers of the
database and the site, not copied from commit subjects. Work in progress goes under
`## [Unreleased]`. The release workflow publishes the section matching the tag as the release
notes. How a release is made is described in [CONTRIBUTING.md](CONTRIBUTING.md#releases).

## [Unreleased]

### Added

- A compare view at `#/compare/<a>/<b>`: the case outlines of two cartridges overlaid at one
  scale with their head faces together, and a table of the dimensions either publishes with the
  difference where both do, in the unit chosen under Default units. A cartridge's page opens it from a
  **Compare with** list. English and German.
- Continuous integration on every pull request: tests, `svelte-check` and a production build.
- Deployment of the site to GitHub Pages from `main`.
- A tag-triggered release workflow that publishes the changelog section and a snapshot of
  `data/`.
- Weekly Dependabot updates for the npm packages and the GitHub Actions in use.
- A README and contributing guide, with the commit convention.
