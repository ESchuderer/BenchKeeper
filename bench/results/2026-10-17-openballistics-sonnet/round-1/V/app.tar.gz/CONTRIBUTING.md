# Contributing to OpenBallistics

Thank you for helping. Corrections to the data are the most valuable contribution, and every
change, however small, goes through a pull request. This guide covers how to propose a change,
how commits and pull requests are written, and how releases are made. The commands to install,
run and test the project are in the [README](README.md#development).

## Proposing a change

1. For anything larger than a correction, open an issue first so the approach can be agreed. A
   wrong value or a missing record can go straight to a pull request, or be reported with one of
   the issue forms.
2. Fork the repository and branch from `main`.
3. Make the change, and run the checks from `site/`: `npm test` and `npm run build`. CI runs
   exactly these on every pull request, and a pull request is merged only when they pass.
4. Add an entry under `## [Unreleased]` in [CHANGELOG.md](CHANGELOG.md) if the change is visible
   to someone using the data or the site. Changes to tooling, tests and docs need no entry.
5. Open the pull request against `main` and fill in the template.

Do not edit generated files: the search indexes under `site/src/lib/*.generated.json` and the
flags in `site/public/flags/` are rebuilt from `data/` and are not tracked.

## Contributing data

The records are plain JSON files in `data/`, and a change to the data is a change to one of them:

- `data/cartridges/<family>/<key>.json`, where the family is one of `belted`, `pistol`,
  `rimfire`, `rimless`, `rimmed` or `shotshell`;
- `data/bullets/<key>.json`;
- `data/targets/<id>.json`.

To correct a record, edit the file. To add one, copy a neighbouring record of the same kind and
change it, so that the field names, the nesting and the units match. File names are the record's
key in lower case with underscores. Keep the existing formatting: two-space indentation, keys in
the order the neighbouring files use, and a final newline. Then run `npm test` and
`npm run build` from `site/`. Both read every record and render its drawings, so malformed JSON
or a record the renderer cannot draw fails there. They cannot tell a wrong figure from a right
one; that is what the source is for.

Some rules for the content:

- **Cite a source.** Say where each figure comes from in the pull request: the C.I.P. sheet and
  its revision, a manufacturer's published specification, or a measurement and the instrument
  used. A change that cannot be checked against its source cannot be reviewed, and will be asked
  for one. Fill in the record's own `sources` field where its kind has one.
- **Do not guess.** Leave out a figure the source does not give. Do not fill the gap with a
  plausible value.
- **No synthetic records presented as real.** The bullets named `sample_*` are generated
  demonstration records, flagged `"sample": true`. Do not edit them by hand; they are rebuilt
  with `npm run sample-bullets` from `site/` (see [data/bullets/README.md](data/bullets/README.md)).
- **Fixtures are test data.** Files under `fixtures/` are the reference the drawing tests compare
  against. Change them only when a drawing is meant to change, and say so in the pull request.

By contributing you agree that your contribution is licensed under the project's
[MIT licence](LICENSE).

## Commits

Commits follow [Conventional Commits 1.0.0](https://www.conventionalcommits.org/en/v1.0.0/):

```
<type>(<scope>): <summary>

<body: what and why, wrapped at about 72 columns>

<footer: BREAKING CHANGE:, Fixes #123>
```

- **type** is one of `feat` (new behaviour or new records), `fix` (a correction, to code or to
  data), `docs`, `refactor`, `perf`, `test`, `build` (the build and dependencies), `ci`, `chore`
  or `revert`.
- **scope** is optional and names the area: `data`, `site`, `lib`, `ci`, `deps` or `release`.
  Several areas, or none in particular, means no scope.
- **summary** is imperative, in lower case, without a final full stop, and at most 72 characters:
  `fix(data): correct 308 Win. case length L3`.
- A breaking change has a `!` after the type or scope (`feat(data)!: rename the family key`)
  and a `BREAKING CHANGE:` footer saying what changes for the user.

Pull requests are squash-merged, so the **pull request title** is what lands in the history and
follows the same convention. Write the title that way even if the commits inside it do not.

## Releases

Versions follow [Semantic Versioning](https://semver.org/). The one version number covers the
site, the libraries and the dataset together, and is kept in the `version` field of
[`site/package.json`](site/package.json) (and the matching entries of `site/package-lock.json`).
Until 1.0.0, a breaking change raises the minor version instead of the major one.

| Change since the last release                  | Bump  |
| ---------------------------------------------- | ----- |
| Only corrections and fixes (`fix`)             | patch |
| New records or features (`feat`)               | minor |
| A breaking change (`!` or `BREAKING CHANGE:`)  | major |

A release is a version commit on `main` plus a tag. [CHANGELOG.md](CHANGELOG.md) is written by
hand, in the [Keep a Changelog](https://keepachangelog.com/en/1.1.0/) format its introduction
describes. A maintainer makes a release like this:

1. Start from an up-to-date `main` with CI passing: `git switch main && git pull`.
2. Choose the version from the table above. In `site/`, set it without tagging:
   `npm version <patch|minor|major> --no-git-tag-version`. The first release, 0.1.0, is already
   the version in `package.json`, so skip this step for it.
3. In `CHANGELOG.md`, rename `## [Unreleased]` to `## [X.Y.Z] - YYYY-MM-DD` and add a fresh,
   empty `## [Unreleased]` above it.
4. Commit as `chore(release): vX.Y.Z` through a pull request, and merge it.
5. Tag the merge commit on `main` and push the tag:
   `git tag -a vX.Y.Z -m "vX.Y.Z" && git push origin vX.Y.Z`.

Pushing the tag starts the [release workflow](.github/workflows/release.yml). It stops unless the
tag equals the version in `site/package.json`, the tagged commit is on `main`, and the changelog
has entries under that version. It then runs the tests and the build, and publishes a GitHub
Release whose notes are that changelog section and which carries a tarball of `data/`. A tag
with a suffix such as `v0.2.0-rc.1` is published as a pre-release. The site itself is not tied to
releases: it is deployed from `main` on every merge.

## Maintainer setup

These are settings on GitHub that no file in the repository can make:

- Settings > Pages > Build and deployment > Source: **GitHub Actions**, so that the
  [deploy workflow](.github/workflows/pages.yml) can publish.
- Require the `Test and build` check of the CI workflow, and a pull request, before merging to
  `main`; allow squash merging.
- Protect the `v*` tags so that only maintainers can create them.
