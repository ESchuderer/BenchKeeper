# OpenBallistics

An open database of cartridges, bullets and targets, kept as JSON records, with the shared
libraries that draw and measure them and a website to browse it all. The cartridge and chamber
dimensions follow the C.I.P. tables of dimensions.

Once GitHub Pages is enabled the site is served at <https://pimetry.github.io/OpenBallistics/>.

| Directory   | Contents                                                                     |
| ----------- | ---------------------------------------------------------------------------- |
| `data/`     | The database: `cartridges/<family>/`, `bullets/` and `targets/`, as JSON     |
| `lib/`      | Shared TypeScript libraries: geometry, 2D rendering, targets, user data      |
| `site/`     | The Svelte website, and the only npm package (it also runs the tests of `lib/`) |
| `fixtures/` | Reference drawings and profiles that the tests compare against               |

## Development

You need Node.js 22 (the version in `.nvmrc`) and npm. Every npm command below runs in `site/`.

```sh
git clone https://github.com/PiMetry/OpenBallistics.git
cd OpenBallistics/site
npm ci
```

Start the development server with `npm run dev`. It first rebuilds the search index and field
sets from `data/`, then serves the site with hot reload. Records in `data/` are served as they
are on disk.

### Test

```sh
npm test                                   # the whole suite: site/ and lib/
npx vitest run src/lib/router.test.ts      # one test file
npx svelte-check --tsconfig ./tsconfig.json  # type-check the site and lib/
```

`npm test` first regenerates the search index and field sets from `data/` (`pretest`).

### Build

```sh
npm run build     # prepare-data, svelte-check, then the production bundle in site/dist
npm run preview   # serve site/dist locally
```

The site is deployed under `/<repository>/` on GitHub Pages. To check a build for that path, set
`PAGES_BASE` with a trailing slash, for example `PAGES_BASE=/OpenBallistics/ npm run build`.

### Other scripts

- `npm run prepare-data` rebuilds the search index and field sets, which are generated and not
  tracked. `npm run index` and `npm run fieldsets` are its two halves.
- `npm run sample-bullets` regenerates the synthetic `sample_*` bullet records.

### Continuous integration

Every pull request runs `npm ci`, `npm test` and `npm run build` in GitHub Actions
(`.github/workflows/ci.yml`), so run the same two commands before you push. The `main` branch is
deployed to GitHub Pages by `.github/workflows/pages.yml`.

## Contributing data

The records are JSON files: edit one to correct it, or copy a neighbour to add one. Name your
source for every figure, leave out what the source does not give, and run `npm test` and
`npm run build`. [CONTRIBUTING.md](CONTRIBUTING.md#contributing-data) has the details. To report
a mistake without fixing it, use one of the
[issue forms](https://github.com/PiMetry/OpenBallistics/issues/new/choose).

## Commit convention

Commits and pull request titles follow [Conventional Commits](https://www.conventionalcommits.org/en/v1.0.0/),
for example `fix(data): correct 308 Win. case length L3`. The types, scopes and the rest are in
[CONTRIBUTING.md](CONTRIBUTING.md#commits).

## Versions and releases

The version is kept in `site/package.json` and follows [Semantic Versioning](https://semver.org/).
Releases are made by pushing a `vX.Y.Z` tag, which publishes a GitHub Release. What changed in
each is in [CHANGELOG.md](CHANGELOG.md), which uses the
[Keep a Changelog](https://keepachangelog.com/en/1.1.0/) format. The steps are in
[CONTRIBUTING.md](CONTRIBUTING.md#releases).

## License

[MIT](LICENSE), Copyright (c) 2026 PiMetry. The third-party software the site is built with and
serves is listed, with its licences, in [THIRD-PARTY.md](THIRD-PARTY.md).
