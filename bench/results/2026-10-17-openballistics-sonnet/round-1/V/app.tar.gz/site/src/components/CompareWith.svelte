<script lang="ts">
  import { Button as ShadcnButton } from '$lib/components/ui/button/index.js';
  import { Label } from '$lib/components/ui/label/index.js';
  import { NativeSelect } from '$lib/components/ui/native-select/index.js';
  import { entries } from '../lib/data';
  import { t } from '../lib/i18n.svelte';
  import { href } from '../lib/router';

  /** The cartridge whose page this is. */
  let { key }: { key: string } = $props();
  const id = $props.id();

  const others = $derived(
    entries.filter((entry) => entry.key !== key).sort((x, y) => x.name.localeCompare(y.name, 'en'))
  );
  /** What the reader picked; the first of the list until they pick, and again on another page. */
  let picked = $state<string | null>(null);
  const target = $derived(others.find((entry) => entry.key === picked)?.key ?? others[0]?.key);
</script>

<div data-ui="CompareWith" class="contents">
  <form
    class="compare-with"
    onsubmit={(event) => {
      event.preventDefault();
      if (target) location.hash = href.compare(key, target);
    }}
  >
    <Label for={`${id}-with`}>{t('compare.with')}</Label>
    <NativeSelect id={`${id}-with`} value={target} onchange={(event) => (picked = event.currentTarget.value)}>
      {#each others as entry (entry.key)}
        <option value={entry.key}>{entry.name}</option>
      {/each}
    </NativeSelect>
    <ShadcnButton variant="outline" type="submit" disabled={!target}>{t('compare.go')}</ShadcnButton>
  </form>
</div>

<style>
  @layer legacy {
    :global([data-ui="CompareWith"] .compare-with) {
      display: flex;
      flex-wrap: wrap;
      align-items: center;
      gap: .5rem .75rem;
      margin: var(--space-6) 0 0;
      max-width: 36rem;
    }
    :global([data-ui="CompareWith"] [data-slot="native-select-wrapper"]) { flex: 1 1 14rem; width: auto; }
    @media print {
      :global([data-ui="CompareWith"]) { display: none; }
    }
  }
</style>
