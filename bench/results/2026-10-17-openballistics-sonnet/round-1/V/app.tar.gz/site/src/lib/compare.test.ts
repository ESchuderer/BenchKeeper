import { readFileSync } from 'node:fs';
import { join } from 'node:path';
import { describe, expect, it } from 'vitest';
import { FIELD_LABELS, FIELD_UNITS, type Record_ } from '@lib/core';
import { caseOuterProfile, adaptMetallic, type CartridgeRecord } from '@lib/shapes2d';
import { CARTRIDGES } from '../../../lib/testing/fixtures';
import { displayNumber } from './units';
import {
  compareRows, dimensionsOf, formatDifference, formatLength, outlineOf, overlay, tableUnit
} from './compare';

const record = (family: string, key: string): Record_ =>
  JSON.parse(readFileSync(join(CARTRIDGES, family, `${key}.json`), 'utf8')) as Record_;

const win308 = record('rimless', '308_win');
const mag300 = record('belted', '300_win_mag');

describe('the dimensions a record publishes', () => {
  const found = dimensionsOf(win308);

  it('are the millimetre numbers of the cartridge part, under the detail page symbols', () => {
    expect(found.get('L1')).toBe(39.62);
    expect(found.get('e min')).toBe(1.4);
    expect(found.get('r1 min')).toBe(0.76);
    expect(found.get('L3 + G')).toBe(58.16);
    expect(found.has('eMin')).toBe(false);
  });

  it('leave out pressures, energies, angles and every tolerance', () => {
    for (const symbol of ['Pmax', 'PK', 'PE', 'EE', 'M', 'α', 'β', 'δ', 'alpha', 'beta', 'delta']) {
      expect(found.has(symbol), symbol).toBe(false);
    }
    expect([...found.keys()].filter((symbol) => symbol.endsWith('Tol'))).toEqual([]);
  });

  it('never include a field with a unit of its own', () => {
    const units = new Set(Object.keys(FIELD_UNITS).map((field) => FIELD_LABELS[field] ?? field));
    expect([...found.keys()].filter((symbol) => units.has(symbol))).toEqual([]);
  });

  it('follow the order of the detail page, a group at a time', () => {
    const symbols = [...found.keys()];
    expect(symbols.indexOf('L1')).toBeLessThan(symbols.indexOf('R'));
    expect(symbols.indexOf('R')).toBeLessThan(symbols.indexOf('P1'));
    expect(symbols.indexOf('P1')).toBeLessThan(symbols.indexOf('S'));
  });

  it('skip a group that repeats, as a shot cartridge has', () => {
    const shot = record('shotshell', '12');
    expect(() => dimensionsOf(shot)).not.toThrow();
    expect(dimensionsOf(shot).has('marking')).toBe(false);
  });
});

describe('the rows of the table', () => {
  const rows = compareRows(win308, mag300);

  it('are the symbols either cartridge publishes', () => {
    const a = dimensionsOf(win308);
    const b = dimensionsOf(mag300);
    expect(new Set(rows.map((row) => row.symbol))).toEqual(new Set([...a.keys(), ...b.keys()]));
    expect(rows).toHaveLength(new Set([...a.keys(), ...b.keys()]).size);
    for (const row of rows) {
      expect(row.a).toBe(a.get(row.symbol));
      expect(row.b).toBe(b.get(row.symbol));
    }
  });

  it('include delta L of the 308 Win. and R3 of the 300 Win. Mag., each with the other figure absent', () => {
    expect(rows.find((row) => row.symbol === 'delta L')).toEqual({
      symbol: 'delta L', a: dimensionsOf(win308).get('delta L'), b: undefined
    });
    expect(rows.find((row) => row.symbol === 'R3')).toEqual({
      symbol: 'R3', a: undefined, b: dimensionsOf(mag300).get('R3')
    });
    expect(dimensionsOf(win308).has('delta L')).toBe(true);
    expect(dimensionsOf(mag300).has('R3')).toBe(true);
  });

  it('keep the first record in its order and put a symbol only the second publishes after its predecessor', () => {
    const only = { cartridge: { lengths: { L1: 10, L2: 20 } } } as unknown as Record_;
    const other = { cartridge: { lengths: { L1: 12, L3: 30 }, collar: { H1: 3 } } } as unknown as Record_;
    expect(compareRows(only, other)).toEqual([
      { symbol: 'L1', a: 10, b: 12 },
      { symbol: 'L3', a: undefined, b: 30 },
      { symbol: 'H1', a: undefined, b: 3 },
      { symbol: 'L2', a: 20, b: undefined }
    ]);
  });

  it('have no figure in common for two records with nothing in common', () => {
    const left = { cartridge: { lengths: { L1: 10 } } } as unknown as Record_;
    const right = { cartridge: { collar: { H1: 3 } } } as unknown as Record_;
    const found = compareRows(left, right);
    expect(found).toHaveLength(2);
    expect(found.filter((row) => row.a !== undefined && row.b !== undefined)).toEqual([]);
  });

  it('are empty where neither publishes a dimension', () => {
    expect(compareRows({ cartridge: {} } as unknown as Record_, { cartridge: {} } as unknown as Record_)).toEqual([]);
  });

  it('compare every record with itself without a difference', () => {
    for (const row of compareRows(mag300, mag300)) expect(row.a).toBe(row.b);
  });
});

describe('the figures', () => {
  it('are the detail page text in metric, without rounding', () => {
    expect(formatLength(39.62, 'metric')).toBe('39.62');
    expect(formatLength(7.8500001, 'metric')).toBe('7.8500001');
    expect(tableUnit('metric')).toBe('mm');
  });

  it('are inches in imperial, converted and not rounded further', () => {
    expect(formatLength(25.4, 'imperial')).toBe('1');
    expect(formatLength(39.62, 'imperial')).toBe(displayNumber(39.62, 'in'));
    expect(tableUnit('imperial')).toBe('in');
  });

  it('give the difference as B minus A', () => {
    expect(formatDifference(11.53, 11.96, 'metric')).toBe('0.43');
    expect(formatDifference(11.96, 11.53, 'metric')).toBe('-0.43');
    expect(formatDifference(5, 5, 'metric')).toBe('0');
  });

  it('convert the difference, not the difference of two rounded inches', () => {
    expect(formatDifference(11.53, 11.96, 'imperial')).toBe(displayNumber(0.43, 'in'));
    expect(formatDifference(0, 25.4, 'imperial')).toBe('1');
    expect(formatDifference(25.4, 0, 'imperial')).toBe('-1');
  });
});

describe('the outlines', () => {
  it('are the case outer profiles the drawings use', () => {
    expect(outlineOf(win308)).toEqual(caseOuterProfile(adaptMetallic(win308 as unknown as CartridgeRecord)));
  });

  it('are missing for a shot cartridge and for a record that does not publish its rim', () => {
    expect(outlineOf(record('shotshell', '12'))).toBeNull();
    expect(outlineOf(record('rimmed', '7_x_67_r_luyven'))).toBeNull();
  });
});

describe('the overlay', () => {
  const profiles = [outlineOf(win308)!, outlineOf(mag300)!];
  const picture = overlay(profiles);

  /** The extent of a closed path, from its coordinates. */
  function extent(d: string) {
    const points = [...d.matchAll(/[ML]([-\d.]+),([-\d.]+)/g)].map((m) => [Number(m[1]), Number(m[2])] as const);
    const xs = points.map((p) => p[0]);
    const ys = points.map((p) => p[1]);
    return { left: Math.min(...xs), right: Math.max(...xs), top: Math.min(...ys), bottom: Math.max(...ys) };
  }

  it('has one closed path per cartridge', () => {
    expect(picture.outlines).toHaveLength(2);
    for (const outline of picture.outlines) expect(outline.d).toMatch(/^M.*Z$/);
  });

  it('puts the head faces at one height and both cases on one axis', () => {
    for (const outline of picture.outlines) {
      const box = extent(outline.d);
      expect(box.bottom).toBeCloseTo(picture.headY, 4);
      expect((box.left + box.right) / 2).toBeCloseTo(picture.axisX, 4);
    }
  });

  it('draws both at one scale', () => {
    const [a, b] = picture.outlines.map((outline) => extent(outline.d));
    expect((b!.right - b!.left) / (a!.right - a!.left)).toBeCloseTo(
      (2 * Math.max(...profiles[1]!.map((p) => p[0]))) / (2 * Math.max(...profiles[0]!.map((p) => p[0]))),
      4
    );
    // The longer case stands taller by exactly the difference in their lengths.
    const length = (c: Record_) => (c.cartridge.lengths as Record<string, number>).L3!;
    const lengthRatio = (a!.bottom - a!.top) / (b!.bottom - b!.top);
    expect(lengthRatio).toBeCloseTo(length(win308) / length(mag300), 2);
  });

  it('fits the page around both', () => {
    for (const outline of picture.outlines) {
      const box = extent(outline.d);
      expect(box.left).toBeGreaterThanOrEqual(0);
      expect(box.right).toBeLessThanOrEqual(picture.width);
      expect(box.top).toBeGreaterThanOrEqual(0);
      expect(box.bottom).toBeLessThanOrEqual(picture.height);
    }
  });
});
