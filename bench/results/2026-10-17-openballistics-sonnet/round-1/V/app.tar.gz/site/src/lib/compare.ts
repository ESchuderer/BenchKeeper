/**
 * What the compare view shows, worked out from two records: the table of shared dimensions and
 * the overlaid outlines. Framework-free, so the page stays a thin layer over figures that tests
 * can check; the drawing and the field tables themselves are the shared libraries'.
 */

import { FIELD_LABELS, FIELD_UNITS, GROUP_ORDER, formatValue, orderedFields, type Record_ } from '@lib/core';
import { adaptMetallic, caseOuterProfile, type CartridgeRecord } from '@lib/shapes2d';
import { fullSectionPath, viewportFor, type Profile } from '@lib/geom';
import { displayNumber, type UnitSystem } from './units';

/**
 * One symbol either cartridge publishes, with the figures in the record's millimetres. A figure is
 * absent where that cartridge does not publish the symbol.
 */
export interface DimensionRow {
  symbol: string;
  a?: number;
  b?: number;
}

/**
 * Every dimension a record's cartridge part publishes, by the symbol the detail page writes.
 *
 * A dimension is a number in a group of fields whose unit is millimetres: pressures, energies, the
 * angles and the counts have an entry in `FIELD_UNITS` and are not dimensions, and a tolerance is
 * shown beside its dimension rather than as a figure of its own. A symbol that two groups both
 * carry is the one the detail page lists first. Keyed in the detail page's order.
 */
export function dimensionsOf(record: Pick<Record_, 'cartridge'>): Map<string, number> {
  const found = new Map<string, number>();
  const groups = record.cartridge ?? {};
  const known = GROUP_ORDER.cartridge.filter((name) => name in groups);
  const rest = Object.keys(groups).filter((name) => !known.includes(name)).sort();
  for (const name of [...known, ...rest]) {
    const group = groups[name];
    // A repeating group is a table of its own and has no single figure to compare.
    if (!group || Array.isArray(group)) continue;
    for (const field of orderedFields('cartridge', name, group)) {
      const value = group[field];
      if (typeof value !== 'number' || !Number.isFinite(value)) continue;
      if (field.endsWith('Tol') || Object.hasOwn(FIELD_UNITS, field)) continue;
      const symbol = FIELD_LABELS[field] ?? field;
      if (!found.has(symbol)) found.set(symbol, value);
    }
  }
  return found;
}

/**
 * The rows either cartridge publishes, in the order the detail page lists them. A symbol only the
 * second publishes stands after the symbol that precedes it in the second's own order.
 */
export function compareRows(a: Pick<Record_, 'cartridge'>, b: Pick<Record_, 'cartridge'>): DimensionRow[] {
  const first = dimensionsOf(a);
  const second = dimensionsOf(b);
  const symbols = [...first.keys()];
  let previous = -1;
  for (const symbol of second.keys()) {
    if (first.has(symbol)) previous = symbols.indexOf(symbol);
    else symbols.splice(++previous, 0, symbol);
  }
  return symbols.map((symbol) => ({ symbol, a: first.get(symbol), b: second.get(symbol) }));
}

/** The unit the table's lengths are written in, for the reader's unit preference. */
export const tableUnit = (system: UnitSystem): 'mm' | 'in' => (system === 'imperial' ? 'in' : 'mm');

/** A length as the table writes it: the detail page's own text in metric, inches without rounding. */
export function formatLength(mm: number, system: UnitSystem): string {
  return system === 'imperial' ? displayNumber(mm, 'in') : (formatValue(mm) ?? '');
}

/**
 * B minus A, taken on the published millimetres and then written like any other length.
 *
 * Subtracting two published figures leaves binary noise (11.96 - 11.53 is 0.4299999999999997). It
 * is cleaned to twelve significant digits, which is what `displayNumber` does for inches; that is
 * far beyond what any sheet publishes, so nothing a sheet says is rounded away.
 */
export function formatDifference(a: number, b: number, system: UnitSystem): string {
  const difference = b - a;
  return system === 'imperial'
    ? displayNumber(difference, 'in')
    : (formatValue(Number(difference.toPrecision(12))) ?? '');
}

/**
 * The outer profile of a record's case, as the drawings use it, or `null` where there is none to
 * draw: a shot cartridge (out of scope here), or a record that does not publish what the case
 * needs.
 */
export function outlineOf(record: Record_): Profile | null {
  if (record.family === 'shotshell') return null;
  try {
    return caseOuterProfile(adaptMetallic(record as unknown as CartridgeRecord));
  } catch {
    return null;
  }
}

export interface OverlayOutline {
  /** The closed outline, both sides of the axis, as one SVG path. */
  d: string;
}

export interface Overlay {
  width: number;
  height: number;
  /** x of the common axis. */
  axisX: number;
  /** y of the head faces, shared by every outline. */
  headY: number;
  /** One per profile given, in order. */
  outlines: OverlayOutline[];
}

const OVERLAY_SCALE = 10;
const OVERLAY_MARGIN_MM = 3;

/**
 * The profiles in one coordinate system: one scale, the axis at one x and the head faces at one y.
 *
 * Both profiles are measured from the head face along the axis, so a viewport over all of them is
 * all it takes; each is then mirrored about the axis into one closed outline.
 */
export function overlay(profiles: Profile[]): Overlay {
  const view = viewportFor(profiles, { scale: OVERLAY_SCALE, marginMm: OVERLAY_MARGIN_MM });
  return {
    width: view.width,
    height: view.height,
    axisX: view.xy(0, 0)[0],
    headY: view.xy(0, 0)[1],
    outlines: profiles.map((profile) => ({ d: fullSectionPath(profile, view) }))
  };
}
