<script lang="ts">
  import PageLoadError from '../components/PageLoadError.svelte';
  import { byKey, load } from '../lib/data';
  import { compareRows, formatDifference, formatLength, outlineOf, overlay, tableUnit } from '../lib/compare';
  import { t } from '../lib/i18n.svelte';
  import { href } from '../lib/router';
  import { unitSystem } from '../lib/units.svelte';

  interface Props {
    a: string;
    b: string;
  }
  let { a, b }: Props = $props();

  const entryA = $derived(byKey(a));
  const entryB = $derived(byKey(b));
  const records = $derived(entryA && entryB ? Promise.all([load(a), load(b)]) : null);
  const system = $derived(unitSystem());
  const unknown = $derived([a, b].find((key) => !byKey(key)));
</script>

<div data-ui="Compare" class="contents">
  {#if !records}
    <h1>{t('compare.title')}</h1>
    <p class="status" role="alert">{t('compare.unknown', { key: unknown ?? '' })}</p>
    <p><a href={href.list()}>{t('record.back')}</a></p>
  {:else}
    {#await records}
      <p class="status" role="status">{t('record.loading', { name: `${entryA?.name} / ${entryB?.name}` })}</p>
    {:then [first, second]}
      {@const outlines = [outlineOf(first), outlineOf(second)]}
      {@const drawn = [
        { record: first, profile: outlines[0], tone: 'a' },
        { record: second, profile: outlines[1], tone: 'b' }
      ].flatMap((item) => (item.profile ? [{ ...item, profile: item.profile }] : []))}
      {@const missing = [first, second].filter((_, index) => !outlines[index])}
      {@const picture = drawn.length ? overlay(drawn.map((item) => item.profile)) : null}
      {@const rows = compareRows(first, second)}
      {@const unit = tableUnit(system)}

      <header class="head">
        <p class="eyebrow">{t('compare.title')}</p>
        <h1>
          <a class="key a" href={href.cartridge(first.key)}><span class="swatch" aria-hidden="true"></span>{first.name}</a>
          <span class="versus" aria-hidden="true">/</span>
          <a class="key b" href={href.cartridge(second.key)}><span class="swatch" aria-hidden="true"></span>{second.name}</a>
        </h1>
      </header>

      {#if picture}
        <figure class="overlay">
          <svg
            role="img"
            aria-label={t('compare.profiles', { a: first.name, b: second.name })}
            viewBox={`0 0 ${picture.width} ${picture.height}`}
            style={`aspect-ratio:${picture.width} / ${picture.height}; height:min(${Math.round(picture.height)}px, 70vh)`}
          >
            <line class="guide" x1={picture.axisX} x2={picture.axisX} y1="0" y2={picture.height} />
            <line class="guide" x1="0" x2={picture.width} y1={picture.headY} y2={picture.headY} />
            {#each drawn as item, index (item.record.key + index)}
              <path class={`outline ${item.tone}`} d={picture.outlines[index]?.d} />
            {/each}
          </svg>
        </figure>
      {/if}
      {#if missing.length}
        <p class="note">{t('compare.notDrawn', { names: missing.map((record) => record.name).join(', ') })}</p>
      {/if}

      {#if rows.length}
        <div class="scroll">
          <table>
            <caption>{t('compare.dimensions', { unit })}</caption>
            <thead>
              <tr>
                <th scope="col">{t('compare.symbol')}</th>
                <th scope="col" class="figure">{first.name}</th>
                <th scope="col" class="figure">{second.name}</th>
                <th scope="col" class="figure">{t('compare.difference')}</th>
              </tr>
            </thead>
            <tbody>
              {#each rows as row (row.symbol)}
                <tr>
                  <td class="num">{row.symbol}</td>
                  <td class="num figure">{row.a === undefined ? '' : formatLength(row.a, system)}</td>
                  <td class="num figure">{row.b === undefined ? '' : formatLength(row.b, system)}</td>
                  <td class="num figure">{row.a === undefined || row.b === undefined ? '' : formatDifference(row.a, row.b, system)}</td>
                </tr>
              {/each}
            </tbody>
          </table>
        </div>
        <p class="note">{t('compare.differenceNote')}</p>
      {:else}
        <p class="status">{t('compare.none')}</p>
      {/if}
    {:catch}
      <PageLoadError />
    {/await}
  {/if}
</div>

<style>
  @layer legacy {
    :global([data-ui="Compare"]) {
      --compare-a: #1d4ed8;
      --compare-b: #c2410c;
    }
    :global(:root[data-theme='dark'] [data-ui="Compare"]) {
      --compare-a: #93c5fd;
      --compare-b: #fdba74;
    }
    :global([data-ui="Compare"] .head) { padding-bottom: var(--space-6); border-bottom: 1px solid var(--rule); }
    :global([data-ui="Compare"] .head .eyebrow) { margin: 0 0 .375rem; }
    :global([data-ui="Compare"] h1) {
      font-size: clamp(var(--step-3), 1.2rem + 2vw, var(--step-4));
      line-height: 1.15;
      letter-spacing: -0.01em;
    }
    :global([data-ui="Compare"] h1 a) { color: var(--ink); flex-wrap: wrap; }
    :global([data-ui="Compare"] .versus) { color: var(--ink-3); margin-inline: .25em; }
    :global([data-ui="Compare"] .overlay) {
      margin: var(--space-6) 0;
      padding: var(--panel-padding);
      background: var(--surface);
      border: 1px solid var(--rule);
      border-radius: var(--radius);
      display: flex;
      flex-direction: column;
      align-items: center;
      gap: .75rem;
    }
    :global([data-ui="Compare"] svg) { display: block; max-width: 100%; }
    :global([data-ui="Compare"] .guide) {
      stroke: var(--rule-strong);
      stroke-width: 1;
      stroke-dasharray: 2 4;
      vector-effect: non-scaling-stroke;
    }
    :global([data-ui="Compare"] .outline) {
      fill: none;
      stroke-width: 2;
      stroke-linejoin: round;
      vector-effect: non-scaling-stroke;
    }
    :global([data-ui="Compare"] .outline.a) { stroke: var(--compare-a); }
    /* Dashed as well as another colour, so the two read apart without telling the colours apart. */
    :global([data-ui="Compare"] .outline.b) { stroke: var(--compare-b); stroke-dasharray: 8 4; }
    /* The names in the heading are the key to the drawing: a line in each outline's colour and dash. */
    :global([data-ui="Compare"] .key) { display: inline-flex; align-items: center; gap: .5rem; }
    :global([data-ui="Compare"] .swatch) { width: 1.75rem; border-top: 3px solid var(--compare-a); }
    :global([data-ui="Compare"] .key.b .swatch) { border-top-color: var(--compare-b); border-top-style: dashed; }
    :global([data-ui="Compare"] .scroll) { overflow-x: auto; }
    :global([data-ui="Compare"] table) { border-collapse: collapse; font-size: var(--step-0); width: 100%; }
    :global([data-ui="Compare"] caption) {
      caption-side: top;
      text-align: left;
      font-weight: 600;
      padding-bottom: .5rem;
    }
    :global([data-ui="Compare"] th),
    :global([data-ui="Compare"] td) { text-align: right; padding: .25rem .75rem .25rem 0; white-space: nowrap; }
    :global([data-ui="Compare"] th) { color: var(--ink-2); font-weight: 500; border-bottom: 1px solid var(--rule); }
    :global([data-ui="Compare"] td) { font-weight: 500; border-bottom: 1px solid var(--rule); }
    :global([data-ui="Compare"] th:first-child),
    :global([data-ui="Compare"] td:first-child) { text-align: left; }
    /* The figures line up on the right whatever the column order, as the detail page's tables do. */
    :global([data-ui="Compare"] th.figure),
    :global([data-ui="Compare"] td.figure) { text-align: right; }
    :global([data-ui="Compare"] .note) { color: var(--ink-2); font-size: var(--step-0); margin: .5rem 0 0; }
    @media print {
      :global([data-ui="Compare"] .overlay) { break-inside: avoid; }
    }
  }
</style>
