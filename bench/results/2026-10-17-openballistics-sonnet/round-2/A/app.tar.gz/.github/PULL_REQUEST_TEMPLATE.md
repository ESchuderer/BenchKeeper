<!-- The title becomes the commit message: `<type>(<scope>): <description>`, e.g.
     `data(cartridges): correct L3 of 308 Win.` See CONTRIBUTING.md for the types. -->

## What and why

## Source (for data changes)

<!-- The C.I.P. sheet, manufacturer's drawing or measurement the new value comes from. -->

## Checklist

- [ ] `npm test` and `npm run build` pass in `site/`
- [ ] Data changes name their source
- [ ] User-visible changes have a line under `## [Unreleased]` in `CHANGELOG.md`
