#!/usr/bin/env bash
# Print the body of one release's section of CHANGELOG.md.
#
#   .github/scripts/changelog-section.sh 1.2.0
#
# The section is the lines under "## [1.2.0] - YYYY-MM-DD", up to the next "## " heading or the
# link definitions at the foot of the file. Exits non-zero, printing nothing, when the heading is
# missing, is not dated, or the section is empty. The release workflow uses it for the release notes.
set -euo pipefail

version="${1:?usage: changelog-section.sh <version, without the leading v>}"
changelog="${CHANGELOG:-CHANGELOG.md}"

section="$(awk -v version="$version" '
  BEGIN { heading = "## [" version "] - " }
  index($0, heading) == 1 && $0 ~ /^## \[[^]]+\] - [0-9][0-9][0-9][0-9]-[0-9][0-9]-[0-9][0-9]$/ { found = 1; next }
  found && (/^## / || /^\[[^]]+\]: /) { exit }
  found { print }
' "$changelog")"

# Trim leading and trailing blank lines.
section="$(printf '%s\n' "$section" | sed -e '/./,$!d' | sed -e ':a' -e '/^\n*$/{$d;N;ba' -e '}')"

if [ -z "$section" ]; then
  echo "No dated, non-empty section for version $version in $changelog" >&2
  echo "Expected a heading like: ## [$version] - $(date -u +%Y-%m-%d)" >&2
  exit 1
fi

printf '%s\n' "$section"
