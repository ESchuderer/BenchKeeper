# Changelog

All notable changes to OpenBallistics are recorded in this file.

The format is [Keep a Changelog 1.1.0](https://keepachangelog.com/en/1.1.0/), and the project
follows [Semantic Versioning 2.0.0](https://semver.org/spec/v2.0.0.html); what counts as a major,
minor or patch change for a data project is spelled out in [RELEASING.md](RELEASING.md).

Each release has a heading `## [X.Y.Z] - YYYY-MM-DD` (ISO 8601 date, newest first) with entries
grouped under `### Added`, `### Changed`, `### Deprecated`, `### Removed`, `### Fixed` and
`### Security`, omitting the groups that are empty. Changes to the records in `data/` are listed
under the same groups, naming the records. Unreleased changes collect under `## [Unreleased]` and
are moved under a new heading when a release is made.

## [Unreleased]

### Added

- A comparison view at `#/compare/<a>/<b>`: the outer profiles of two cases overlaid at one scale with
  their head faces aligned, and a table of every millimetre dimension either cartridge publishes, with
  the difference between them where both do, in the unit chosen under My data. A cartridge's page links to it
  with a **Compare with** list. German texts included.
- Continuous integration on every pull request: tests, type check, production build and a check
  that the generated sample bullets are current.
- Deployment of the site to GitHub Pages from `main`.
- A tag-triggered release workflow that publishes GitHub releases with the notes from this file,
  an archive of `data/` and the built site.
- Weekly dependency updates through Dependabot for npm packages and GitHub Actions.
- A contributor README, `CONTRIBUTING.md` with the commit convention, and `RELEASING.md`.
