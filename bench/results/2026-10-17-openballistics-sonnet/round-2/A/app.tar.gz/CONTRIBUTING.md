# Contributing

Thank you for helping. The [README](README.md) explains how to install, run, test and build the
project and how to report or fix data. This file covers the conventions for changes.

## Before you open a pull request

1. Branch from `main` and keep the change to one subject.
2. In `site/`, run `npm test` and `npm run build`. CI runs the same commands.
3. Add a line under `## [Unreleased]` in [`CHANGELOG.md`](CHANGELOG.md) if the change is
   visible to someone using the data, the libraries or the site. Refactors, tests and CI changes
   do not need one.
4. If you add or update a dependency, check that [`THIRD-PARTY.md`](THIRD-PARTY.md) still lists what
   the built site redistributes.
5. Do not edit `data/bullets/sample_*.json` by hand; see the README.

## Commit convention

This repository uses [Conventional Commits 1.0.0](https://www.conventionalcommits.org/en/v1.0.0/):

```
<type>(<scope>): <description>

[optional body]

[optional footer, e.g. BREAKING CHANGE: ... or Closes #123]
```

The description is imperative, lower-case, without a final full stop, and the first line is at most
100 characters. Pull requests are squash-merged, so **the pull request title is the commit message
on `main`** and is checked by CI. Commits inside a pull request should follow the convention too,
but only the title is enforced.

| Type       | Use it for                                                              |
| ---------- | ----------------------------------------------------------------------- |
| `feat`     | A new capability of the site or the libraries                           |
| `fix`      | A bug fix                                                               |
| `data`     | A change to records in `data/`: additions, corrections, removals        |
| `docs`     | Documentation only                                                      |
| `style`    | Formatting that changes no behaviour                                    |
| `refactor` | A code change that is neither a fix nor a feature                       |
| `perf`     | A performance improvement                                               |
| `test`     | Tests and fixtures only                                                 |
| `build`    | The build, scripts or dependencies                                      |
| `ci`       | GitHub Actions and other automation                                     |
| `chore`    | Anything else that does not touch the shipped output, e.g. releases      |
| `revert`   | Reverting an earlier commit                                             |

The scope is optional and lower-case. Common ones: `cartridges`, `bullets`, `targets`, `site`,
`lib`, `deps` and `release`. Mark a breaking change with `!` before the colon (`fix(lib)!: ...`) or
a `BREAKING CHANGE:` footer.

Examples:

```
data(cartridges): correct L3 of 308 Win.
data(targets): add DSB 50 m rifle face
feat(site): show chamber drawings on the cartridge page
fix(lib): keep bullet meplat inside the nose length
ci: cache npm downloads
chore(release): 0.2.0
```

The type decides the release's version bump; see [RELEASING.md](RELEASING.md).

## Data contributions

- Name the source of every figure you add or change. A claim about the data has to be checkable.
- Contribute only what you may share: published standards values, manufacturer data you cite, or
  your own measurements. Do not copy someone else's database wholesale.
- By contributing you agree that your contribution is licensed under the project's
  [MIT license](LICENSE).
- Bullets and target faces: open an issue before a pull request, because the tests pin the size of
  those catalogues (see the README).

## Reporting problems

Use the [issue forms](https://github.com/PiMetry/OpenBallistics/issues/new/choose): one for a
cartridge, one for a bullet and one for the site.
