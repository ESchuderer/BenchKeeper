# Releasing

For maintainers. A release is a Git tag `vX.Y.Z` on a commit of `main`; the
[release workflow](.github/workflows/release.yml) does the rest.

## Where the version lives

In one place: the `version` field of [`site/package.json`](site/package.json), mirrored in
`site/package-lock.json` by `npm version`. `main` always carries the version of the latest
release, except inside a release pull request. The Git tag is `v` plus that version.

## What the version number means

[Semantic Versioning 2.0.0](https://semver.org/spec/v2.0.0.html), read for a data project. The
public interface is the JSON in `data/`, the modules in `lib/` and the site's URLs (`#/…` routes).

| Bump  | When                                                                                                    |
| ----- | ------------------------------------------------------------------------------------------------------- |
| Major | A record key is renamed or removed, a record's structure changes incompatibly, or a `lib/` export breaks |
| Minor | New records, new fields, new site features or new `lib/` exports                                         |
| Patch | Corrected values in existing records, bug fixes and documentation                                        |

Before 1.0.0 the interface may change in a minor release; the changelog says when it does. Commit
types suggest the bump: `feat` and `data` additions are minor, `fix` and `data` corrections are
patch, and anything marked `!` or `BREAKING CHANGE` is major.

## The changelog

[`CHANGELOG.md`](CHANGELOG.md) follows [Keep a Changelog 1.1.0](https://keepachangelog.com/en/1.1.0/).
Contributors add lines under `## [Unreleased]` in their pull requests. A release turns that section
into `## [X.Y.Z] - YYYY-MM-DD` (UTC date) and starts a new empty `## [Unreleased]`. The release
workflow publishes the dated section as the release notes and fails when it is missing.

## Making a release

1. Create a branch `release/X.Y.Z` from an up-to-date `main`.
2. Bump the version, without letting npm tag or commit:

   ```sh
   cd site
   npm version X.Y.Z --no-git-tag-version
   ```

3. In `CHANGELOG.md`, rename `## [Unreleased]` to `## [X.Y.Z] - YYYY-MM-DD`, add a fresh empty
   `## [Unreleased]` above it, and tidy the entries. Check that the notes extract:

   ```sh
   .github/scripts/changelog-section.sh X.Y.Z
   ```

4. Commit as `chore(release): X.Y.Z`, open a pull request, wait for CI and squash-merge it.
5. Tag the merge commit and push the tag:

   ```sh
   git switch main && git pull
   git tag -a vX.Y.Z -m "vX.Y.Z"
   git push origin vX.Y.Z
   ```

The workflow then checks that the tag equals the version in `site/package.json` and points into
`main`, runs the tests and the build, and creates the GitHub release with the changelog section as
notes and two archives: `openballistics-data-vX.Y.Z.tar.gz` (`data/` and the license) and
`openballistics-site-vX.Y.Z.tar.gz` (the built site, for the root of a domain). A tag with a
suffix such as `v1.0.0-rc.1` is published as a pre-release.

The first release is `0.1.0`, the version already in `site/package.json`: skip step 2 and give the
current `[Unreleased]` section that version and a date.

If the workflow fails, fix the cause, delete the tag (`git push --delete origin vX.Y.Z` and
`git tag -d vX.Y.Z`) and tag again.

## The website

The site is not tied to releases: [`pages.yml`](.github/workflows/pages.yml) deploys every push to
`main`. A repository admin has to select **Settings → Pages → Source → GitHub Actions** once, and
the `github-pages` environment must allow deployments from `main`.

## Repository settings that these workflows assume

- Merge method: squash only, with "Pull request title" as the default commit message, so that the
  checked title becomes the commit on `main`.
- Branch protection on `main`: require the `Test and build` and `Conventional Commits title` checks.
- Actions: workflows may read and write contents (the release workflow requests this itself).
