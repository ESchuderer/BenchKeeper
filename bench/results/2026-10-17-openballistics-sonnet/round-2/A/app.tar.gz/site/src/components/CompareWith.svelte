<script lang="ts">
  import { Button } from '$lib/components/ui/button/index.js';
  import { Label } from '$lib/components/ui/label/index.js';
  import { NativeSelect } from '$lib/components/ui/native-select/index.js';
  import { entries } from '../lib/data';
  import { t } from '../lib/i18n.svelte';
  import { href } from '../lib/router';

  /**
   * Picks the cartridge to hold this one against and opens `#/compare/<this>/<picked>`.
   *
   * The control sits on a page that outlives a change of cartridge, so what was picked is kept
   * only while it is still one of the others: opened on the cartridge that was picked, it falls
   * back to the first of the list rather than offering to compare a cartridge with itself.
   */
  let { key }: { key: string } = $props();
  const id = $props.id();

  const others = $derived(
    entries.filter((entry) => entry.key !== key).sort((x, y) => x.name.localeCompare(y.name, 'en'))
  );
  let picked = $state('');
  const chosen = $derived(others.some((entry) => entry.key === picked) ? picked : (others[0]?.key ?? ''));
</script>

<div class="flex flex-wrap items-end gap-3">
  <div class="grid w-full max-w-xs gap-2">
    <Label for={`${id}-with`}>{t('compare.with')}</Label>
    <NativeSelect id={`${id}-with`} value={chosen} onchange={(event) => (picked = event.currentTarget.value)}>
      {#each others as entry (entry.key)}
        <option value={entry.key}>{entry.name}</option>
      {/each}
    </NativeSelect>
  </div>
  <Button type="button" variant="outline" disabled={!chosen} onclick={() => (location.hash = href.compare(key, chosen))}>
    {t('compare.go')}
  </Button>
</div>
