import { readdirSync, readFileSync } from 'node:fs';
import { join } from 'node:path';
import { describe, expect, it } from 'vitest';
import { FIELD_LABELS, FIELD_UNITS, formatValue, type Record_ } from '@lib/core';
import { CARTRIDGES } from '../../../lib/testing/fixtures';
import {
  compareRows,
  dimensionsOf,
  formatDifference,
  formatLength,
  lengthUnit,
  outerProfileOf,
  overlayProfiles
} from './compare';
import { displayNumber } from './units';

const records = new Map<string, Record_>();
for (const family of readdirSync(CARTRIDGES)) {
  for (const file of readdirSync(join(CARTRIDGES, family))) {
    const record = JSON.parse(readFileSync(join(CARTRIDGES, family, file), 'utf8')) as Record_;
    records.set(record.key, record);
  }
}
const record = (key: string): Record_ => {
  const found = records.get(key);
  if (!found) throw new Error(`no record ${key}`);
  return found;
};

const rows = compareRows(record('308_win'), record('300_win_mag'));
const bySymbol = (symbol: string) => rows.find((row) => row.symbol === symbol);

describe('the dimensions a record publishes', () => {
  it('are the millimetre figures of the cartridge part, as the detail page labels them', () => {
    const symbols = dimensionsOf(record('308_win')).map((d) => d.symbol);
    expect(symbols).toEqual(expect.arrayContaining(['L1', 'L3', 'L6', 'R1', 'e min', 'r1 min', 'P1', 'G1', 'L3 + G', 'Fe']));
    // Tolerances, the pressures (bar, J, g) and the angles are not dimensions in millimetres.
    for (const absent of ['L1Tol', 'P2Tol', 'Pmax', 'PK', 'PE', 'EE', 'M', 'α', 'δ', 'β', 'S ']) {
      expect(symbols).not.toContain(absent);
    }
    expect(symbols.some((s) => /Tol/.test(s))).toBe(false);
  });

  it('never read the chamber', () => {
    const withChamberOnly = { cartridge: {}, chamber: { barrel: { F: 7.62 } } } as unknown as Record_;
    expect(dimensionsOf(withChamberOnly)).toEqual([]);
  });

  it('skips repeating groups, which hold rows and not figures', () => {
    const shot = [...records.values()].find((r) => r.family === 'shotshell')!;
    expect(Array.isArray(shot.cartridge.lengths)).toBe(true);
    expect(dimensionsOf(shot).map((d) => d.field)).not.toContain('l');
  });

  it('count a symbol published in two groups once', () => {
    const doubled = { cartridge: { lengths: { L1: 1 }, misc: { L1: 2 } } } as unknown as Record_;
    expect(dimensionsOf(doubled)).toEqual([{ field: 'L1', symbol: 'L1', value: 1 }]);
  });

  it('never include a field with a unit entry or a tolerance, in any record', () => {
    for (const r of records.values()) {
      for (const d of dimensionsOf(r)) {
        expect(d.field.endsWith('Tol')).toBe(false);
        expect(Object.hasOwn(FIELD_UNITS, d.field)).toBe(false);
        expect(d.symbol).toBe(FIELD_LABELS[d.field] ?? d.field);
      }
    }
  });
});

describe('the comparison rows', () => {
  it('has one row per symbol either cartridge publishes, difference being B minus A where both do', () => {
    const a = record('308_win');
    const b = record('300_win_mag');
    const first = new Map(dimensionsOf(a).map((d) => [d.field, d.value]));
    const second = new Map(dimensionsOf(b).map((d) => [d.field, d.value]));
    const either = new Set([...first.keys(), ...second.keys()]);
    expect(rows.map((row) => row.field).sort()).toEqual([...either].sort());
    expect(new Set(rows.map((row) => row.symbol)).size).toBe(rows.length);
    for (const row of rows) {
      expect(row.a).toBe(first.get(row.field) ?? null);
      expect(row.b).toBe(second.get(row.field) ?? null);
      expect(row.difference).toBe(row.a !== null && row.b !== null ? row.b - row.a : null);
    }
  });

  it('lists delta L and R3 of 308 Win. and 300 Win. Mag. with the other cell and the difference empty', () => {
    expect(bySymbol('delta L')).toMatchObject({ b: null, difference: null });
    expect(bySymbol('delta L')!.a).toBe(0.1);
    expect(bySymbol('R3')).toMatchObject({ a: null, difference: null });
    expect(bySymbol('R3')!.b).not.toBeNull();
  });

  it('puts the case head symbol where the sheet writes it', () => {
    expect(bySymbol('e min')).toMatchObject({ a: 1.4, b: 0.94 });
    expect(bySymbol('e min')!.difference).toBeCloseTo(-0.46, 9);
    expect(bySymbol('L3')).toMatchObject({ a: 51.18, b: 66.55 });
  });

  it('lists a symbol only one of them publishes, with the other cell and the difference empty', () => {
    const a = { cartridge: { lengths: { L1: 1, L2: 2 } } } as unknown as Record_;
    const b = { cartridge: { lengths: { L1: 4, L3: 3 } } } as unknown as Record_;
    expect(compareRows(a, b)).toEqual([
      { field: 'L1', symbol: 'L1', a: 1, b: 4, difference: 3 },
      { field: 'L3', symbol: 'L3', a: null, b: 3, difference: null },
      { field: 'L2', symbol: 'L2', a: 2, b: null, difference: null }
    ]);
    expect(compareRows(a, { cartridge: {} } as unknown as Record_)).toEqual([
      { field: 'L1', symbol: 'L1', a: 1, b: null, difference: null },
      { field: 'L2', symbol: 'L2', a: 2, b: null, difference: null }
    ]);
    expect(compareRows({ cartridge: {} } as unknown as Record_, { cartridge: {} } as unknown as Record_)).toEqual([]);
  });

  it('puts a symbol only the second publishes after the one before it in the second\'s order', () => {
    const a = { cartridge: { lengths: { L1: 1, L3: 3 } } } as unknown as Record_;
    const b = { cartridge: { lengths: { L1: 1, L2: 2, L3: 3 } } } as unknown as Record_;
    expect(compareRows(a, b).map((row) => row.field)).toEqual(['L1', 'L2', 'L3']);
  });
});

describe('the figures in the reader\'s units', () => {
  it('writes metric values with formatValue and does not round', () => {
    for (const row of rows) {
      if (row.a !== null) expect(formatLength(row.a, 'metric')).toBe(formatValue(row.a));
      if (row.b !== null) expect(formatLength(row.b, 'metric')).toBe(formatValue(row.b));
    }
    expect(formatLength(12.345678, 'metric')).toBe('12.345678');
    expect(lengthUnit('metric')).toBe('mm');
  });

  it('converts imperial lengths to inches with displayNumber and does not round further', () => {
    expect(lengthUnit('imperial')).toBe('in');
    expect(formatLength(25.4, 'imperial')).toBe('1');
    expect(formatLength(51.18, 'imperial')).toBe(displayNumber(51.18, 'in'));
    expect(formatLength(51.18, 'imperial')).toBe('2.01496062992');
  });

  it('writes a difference like a length, without binary noise in either system', () => {
    // The subtraction leaves noise that is not part of what was published.
    expect(71.12 - 51.18).toBe(19.940000000000005);
    expect(formatDifference(71.12 - 51.18, 'metric')).toBe('19.94');
    expect(formatDifference(bySymbol('L6')!.difference!, 'metric')).toBe('13.72');
    expect(formatDifference(-0.5, 'metric')).toBe('-0.5');
    expect(formatDifference(0, 'metric')).toBe('0');
    expect(formatDifference(12.7, 'imperial')).toBe('0.5');
    expect(formatDifference(-2.54, 'imperial')).toBe('-0.1');
  });
});

/** The coordinates of a path of `M x,y L x,y ... Z`. */
function points(d: string): [number, number][] {
  return [...d.matchAll(/[ML]\s*(-?[\d.]+),(-?[\d.]+)/g)].map((m) => [Number(m[1]), Number(m[2])]);
}
const extent = (list: number[]) => [Math.min(...list), Math.max(...list)] as const;

describe('the overlaid profiles', () => {
  const a = outerProfileOf(record('308_win'))!;
  const b = outerProfileOf(record('300_win_mag'))!;
  const overlay = overlayProfiles(a, b);
  const pa = points(overlay.paths[0]);
  const pb = points(overlay.paths[1]);

  it('are the outlines caseOuterProfile computes, one path each', () => {
    expect(a.length).toBeGreaterThan(10);
    expect(pa).toHaveLength(2 * a.length);
    expect(pb).toHaveLength(2 * b.length);
    expect(overlay.paths[0]).toMatch(/^M.*Z$/);
  });

  it('share one scale: lengths on the page are proportional to millimetres for both', () => {
    const length = (profile: [number, number][]) => Math.max(...profile.map(([, z]) => z));
    const [ax0, ax1] = extent(pa.map(([x]) => x));
    const [bx0, bx1] = extent(pb.map(([x]) => x));
    const [ay0, ay1] = extent(pa.map(([, y]) => y));
    const [by0, by1] = extent(pb.map(([, y]) => y));
    const scale = (ax1 - ax0) / length(a);
    expect((bx1 - bx0) / length(b)).toBeCloseTo(scale, 4);
    const radius = (profile: [number, number][]) => Math.max(...profile.map(([r]) => r));
    expect((ay1 - ay0) / (2 * radius(a))).toBeCloseTo(scale, 4);
    expect((by1 - by0) / (2 * radius(b))).toBeCloseTo(scale, 4);
  });

  it('put the head faces at the same place and the axes on the same line', () => {
    expect(extent(pa.map(([x]) => x))[0]).toBeCloseTo(extent(pb.map(([x]) => x))[0], 6);
    expect(overlay.axis.y1).toBe(overlay.axis.y2);
    for (const profile of [pa, pb]) {
      const [low, high] = extent(profile.map(([, y]) => y));
      expect((low + high) / 2).toBeCloseTo(overlay.axis.y1, 4);
    }
    // 300 Win. Mag. is the longer case: the common box ends at its mouth.
    expect(extent(pb.map(([x]) => x))[1]).toBeGreaterThan(extent(pa.map(([x]) => x))[1]);
    expect(overlay.axis.x2 - overlay.axis.x1).toBeCloseTo(extent(pb.map(([x]) => x))[1] - overlay.axis.x1, 4);
  });

  it('keeps both outlines inside the box', () => {
    for (const [x, y] of [...pa, ...pb]) {
      expect(x).toBeGreaterThanOrEqual(0);
      expect(x).toBeLessThanOrEqual(overlay.width);
      expect(y).toBeGreaterThanOrEqual(0);
      expect(y).toBeLessThanOrEqual(overlay.height);
    }
  });

  it('draws an outline the same wherever it is compared', () => {
    const alone = overlayProfiles(a, a);
    expect(alone.paths[0]).toBe(alone.paths[1]);
  });
});

describe('which cases can be drawn', () => {
  it('draws the metallic records of the catalogue but the two whose sheet gives no rim diameter', () => {
    const undrawn = [...records.values()].filter((r) => r.family !== 'shotshell' && outerProfileOf(r) === null);
    expect(undrawn.map((r) => r.key).sort()).toEqual(['297_230_morris_lg', '7_x_67_r_luyven']);
  });
  it('does not draw a shot cartridge or a record without the figures', () => {
    expect(outerProfileOf({ ...record('308_win'), family: 'shotshell' })).toBeNull();
    expect(outerProfileOf({ ...record('308_win'), cartridge: {} })).toBeNull();
  });
});
