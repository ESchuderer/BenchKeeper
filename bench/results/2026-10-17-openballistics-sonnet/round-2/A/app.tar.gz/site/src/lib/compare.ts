/**
 * Comparing two cartridges: which dimensions the table has a row for, how a figure is written in
 * the reader's units, and the two outlines laid over each other.
 *
 * Framework-free, so the rules are tested without a page. The figures and the outlines come from
 * `@lib/core`, `@lib/shapes2d` and `@lib/geom`; nothing is re-derived here.
 */

import {
  FIELD_LABELS,
  FIELD_UNITS,
  GROUP_ORDER,
  formatValue,
  orderedFields,
  toleranceFor,
  type Group,
  type Record_
} from '@lib/core';
import { fullSectionPath, viewportFor, type Profile } from '@lib/geom';
import { adaptMetallic, caseOuterProfile, type CartridgeRecord } from '@lib/shapes2d';
import { displayNumber, type UnitSystem } from './units';

export interface Dimension {
  /** The field's name in the record, which is what two records are matched on. */
  field: string;
  /** The symbol as the detail page writes it. */
  symbol: string;
  /** Millimetres, as published. */
  value: number;
}

export interface ComparedRow {
  field: string;
  symbol: string;
  /** Millimetres, or `null` where the first cartridge does not publish the dimension. */
  a: number | null;
  /** Millimetres, or `null` where the second cartridge does not publish the dimension. */
  b: number | null;
  /** `b - a`, in millimetres; `null` unless both publish the dimension. */
  difference: number | null;
}

/**
 * Whether a published figure is a dimension in millimetres: a plain number, not a tolerance on one
 * and not a figure the tables give another unit (`FIELD_UNITS`: bar, joule, gram, the angles).
 */
function isDimension(field: string, value: unknown): value is number {
  return (
    typeof value === 'number' &&
    Number.isFinite(value) &&
    toleranceFor(field) === null &&
    !Object.hasOwn(FIELD_UNITS, field)
  );
}

/**
 * The dimensions a record's `cartridge` part publishes, in the order the detail page shows them.
 * The chamber is not the cartridge, and a repeating group (a shot cartridge's hull lengths) holds
 * rows rather than figures; neither is read. A symbol published in two groups counts once, at its
 * first place.
 */
export function dimensionsOf(record: Pick<Record_, 'cartridge'>): Dimension[] {
  const groups = record.cartridge ?? {};
  const known = GROUP_ORDER.cartridge.filter((name) => name in groups);
  const placed = new Set(known);
  const rest = Object.keys(groups).filter((name) => !placed.has(name)).sort();
  const found = new Map<string, Dimension>();
  for (const name of [...known, ...rest]) {
    const group = groups[name];
    if (!group || Array.isArray(group)) continue;
    for (const field of orderedFields('cartridge', name, group as Group)) {
      const value = (group as Group)[field];
      if (!isDimension(field, value) || found.has(field)) continue;
      found.set(field, { field, symbol: FIELD_LABELS[field] ?? field, value });
    }
  }
  return [...found.values()];
}

/**
 * One row per symbol either record publishes. The rows follow the detail page's order for the first
 * record; a symbol only the second publishes goes after the symbol that precedes it in the second's
 * own order, so the table keeps both pages' reading order.
 */
export function compareRows(a: Pick<Record_, 'cartridge'>, b: Pick<Record_, 'cartridge'>): ComparedRow[] {
  const first = dimensionsOf(a);
  const second = dimensionsOf(b);
  const mine = new Map(first.map((dimension) => [dimension.field, dimension]));
  const theirs = new Map(second.map((dimension) => [dimension.field, dimension]));
  const order = first.map((dimension) => dimension.field);
  let before = -1;
  for (const dimension of second) {
    if (!mine.has(dimension.field)) order.splice(before + 1, 0, dimension.field);
    before = order.indexOf(dimension.field);
  }
  return order.map((field) => {
    const x = mine.get(field);
    const y = theirs.get(field);
    return {
      field,
      symbol: (x ?? y)!.symbol,
      a: x?.value ?? null,
      b: y?.value ?? null,
      difference: x && y ? y.value - x.value : null
    };
  });
}

/** What the table's caption says the figures are in. */
export const lengthUnit = (system: UnitSystem): 'mm' | 'in' => (system === 'imperial' ? 'in' : 'mm');

/**
 * A published length as text. Metric is the detail page's own writing, `formatValue`; imperial is
 * the preference's conversion, `displayNumber`. Neither rounds.
 */
export function formatLength(millimetres: number, system: UnitSystem): string {
  return system === 'imperial' ? displayNumber(millimetres, 'in') : (formatValue(millimetres) ?? '');
}

/**
 * `b - a`, converted and written the way a length is. The subtraction is done in millimetres and
 * `displayNumber` drops the binary noise it leaves (`11.96 - 8.72` is not `3.24` to the last bit)
 * without cutting a digit of what was published.
 */
export function formatDifference(difference: number, system: UnitSystem): string {
  return displayNumber(difference, lengthUnit(system));
}

// ---- The drawing -----------------------------------------------------------------------------

export interface Overlay {
  /** The user-space box of the drawing: both outlines share it, so they share its scale. */
  width: number;
  height: number;
  /** One closed outline per cartridge, `a` first. */
  paths: [string, string];
  /** The case axis, common to both: from the head face to the longer mouth. */
  axis: { x1: number; y1: number; x2: number; y2: number };
}

/** User units per millimetre. Only the ratio to the margin matters: the SVG is sized by its box. */
const SCALE = 10;
const MARGIN_MM = 2;

/**
 * The outer profiles of two cases, `caseOuterProfile` as it computes them, in one viewport: one
 * scale, the head faces (`z = 0`) at the same place and the axes of revolution on the same line.
 */
export function overlayProfiles(a: Profile, b: Profile): Overlay {
  const view = viewportFor([a, b], { scale: SCALE, marginMm: MARGIN_MM, frame: 'landscape' });
  const [x1, y1] = view.xy(0, view.zMin);
  const [x2, y2] = view.xy(0, view.zMax);
  return {
    width: view.width,
    height: view.height,
    paths: [fullSectionPath(a, view), fullSectionPath(b, view)],
    axis: { x1, y1, x2, y2 }
  };
}

/** The outer profile of a metallic record's case, or `null` where it cannot be drawn. */
export function outerProfileOf(record: Record_): Profile | null {
  if (record.family === 'shotshell') return null;
  try {
    return caseOuterProfile(adaptMetallic(record as unknown as CartridgeRecord));
  } catch {
    return null;
  }
}
