<script lang="ts">
  import PageHeader from '../components/PageHeader.svelte';
  import { load } from '../lib/data';
  import {
    compareRows,
    formatDifference,
    formatLength,
    lengthUnit,
    outerProfileOf,
    overlayProfiles
  } from '../lib/compare';
  import { t } from '../lib/i18n.svelte';
  import { href } from '../lib/router';
  import { unitSystem } from '../lib/units.svelte';

  /**
   * Two cartridges side by side: their outer profiles over one another at one scale, and a table
   * of every dimension both publish with the difference between them.
   *
   * Both records are fetched here and nothing is computed from the index, so a direct visit to
   * `#/compare/<a>/<b>`, or a reload of it, shows the same page as a click from a cartridge.
   */
  interface Props {
    a: string;
    b: string;
  }
  let { a, b }: Props = $props();

  const records = $derived(Promise.all([load(a), load(b)]));
  const system = $derived(unitSystem());
  const unit = $derived(lengthUnit(system));
</script>

<div data-ui="Compare" class="contents">
  {#await records}
    <p class="status" role="status">{t('record.loading', { name: `${a} / ${b}` })}</p>
  {:then [first, second]}
    {@const rows = compareRows(first, second)}
    {@const profiles = [outerProfileOf(first), outerProfileOf(second)]}
    {@const overlay = profiles[0] && profiles[1] ? overlayProfiles(profiles[0], profiles[1]) : null}
    {@const missing = [first, second].filter((_, index) => !profiles[index]).map((record) => record.name)}

    <PageHeader
      title={t('compare.title')}
      description={`${first.name} / ${second.name}`}
      backHref={href.cartridge(a)}
      backLabel={t('compare.back', { name: first.name })}
    />

    <section class="drawing">
      {#if overlay}
        <svg
          role="img"
          aria-label={t('compare.profiles', { a: first.name, b: second.name })}
          viewBox={`0 0 ${overlay.width} ${overlay.height}`}
          preserveAspectRatio="xMinYMid meet"
        >
          <line class="axis" aria-hidden="true" {...overlay.axis} />
          <path class="profile a" d={overlay.paths[0]} />
          <path class="profile b" d={overlay.paths[1]} />
        </svg>
        <ul class="legend">
          <li><span class="swatch a" aria-hidden="true"></span>{first.name} <span class="muted">({t('compare.solid')})</span></li>
          <li><span class="swatch b" aria-hidden="true"></span>{second.name} <span class="muted">({t('compare.dashed')})</span></li>
        </ul>
        <p class="note">{t('compare.drawingNote')}</p>
      {:else}
        <p class="note">{t('compare.noDrawing', { names: missing.join(', ') })}</p>
      {/if}
    </section>

    <section class="dimensions">
      {#if rows.length}
        <div class="scroll">
          <table>
            <caption>{t('compare.table', { unit })}</caption>
            <thead>
              <tr>
                <th scope="col">{t('compare.symbol')}</th>
                <th scope="col" class="n">{first.name}</th>
                <th scope="col" class="n">{second.name}</th>
                <th scope="col" class="n">{t('compare.difference')}</th>
              </tr>
            </thead>
            <tbody>
              {#each rows as row (row.field)}
                <tr>
                  <td class="num">{row.symbol}</td>
                  <td class="num n">{row.a === null ? '' : formatLength(row.a, system)}</td>
                  <td class="num n">{row.b === null ? '' : formatLength(row.b, system)}</td>
                  <td class="num n">{row.difference === null ? '' : formatDifference(row.difference, system)}</td>
                </tr>
              {/each}
            </tbody>
          </table>
        </div>
        <p class="note">{t('compare.differenceNote')}</p>
      {:else}
        <p class="note">{t('compare.noRows')}</p>
      {/if}
    </section>
  {:catch error}
    <p class="status error">{error.message} <a href={href.list()}>{t('record.back')}</a></p>
  {/await}
</div>

<style>
  @layer legacy {
    :global([data-ui="Compare"] section) { margin-top: 1.5rem; }
    :global([data-ui="Compare"] .status) { color: var(--ink-2); padding: 2rem 0; }
    :global([data-ui="Compare"] .error) { color: var(--alert); }
    :global([data-ui="Compare"] .drawing) {
      padding: var(--panel-padding, 1rem);
      background: var(--surface);
      border: 1px solid var(--rule);
      border-radius: var(--radius);
    }
    :global([data-ui="Compare"] svg) { display: block; width: 100%; height: auto; max-height: 28rem; }
    :global([data-ui="Compare"] .axis) {
      stroke: var(--ink-3);
      stroke-width: 1;
      stroke-dasharray: 2 4;
      vector-effect: non-scaling-stroke;
    }
    :global([data-ui="Compare"] .profile) {
      fill: none;
      stroke-width: 2;
      stroke-linejoin: round;
      vector-effect: non-scaling-stroke;
    }
    /* Two lines that differ by dashing as well as by colour, so they stay apart without it. */
    :global([data-ui="Compare"] .profile.a) { stroke: var(--link); }
    :global([data-ui="Compare"] .profile.b) { stroke: var(--alert); stroke-dasharray: 8 5; }
    :global([data-ui="Compare"] .legend) {
      display: flex;
      flex-wrap: wrap;
      gap: .25rem 1.5rem;
      margin: .75rem 0 0;
      padding: 0;
      list-style: none;
      font-size: var(--step-0);
    }
    :global([data-ui="Compare"] .swatch) {
      display: inline-block;
      width: 1.75rem;
      margin-right: .5rem;
      vertical-align: middle;
      border-top: 2px solid var(--link);
    }
    :global([data-ui="Compare"] .swatch.b) { border-top: 2px dashed var(--alert); }
    :global([data-ui="Compare"] .muted) { color: var(--ink-3); }
    :global([data-ui="Compare"] .note) { margin: .5rem 0 0; color: var(--ink-2); font-size: .8rem; }
    :global([data-ui="Compare"] .scroll) { overflow-x: auto; }
    :global([data-ui="Compare"] table) { border-collapse: collapse; font-size: var(--step-0); width: 100%; }
    :global([data-ui="Compare"] caption) {
      text-align: left;
      font-weight: 600;
      padding-bottom: .5rem;
    }
    :global([data-ui="Compare"] th),
    :global([data-ui="Compare"] td) { text-align: right; padding: .2rem .75rem .2rem 0; white-space: nowrap; }
    :global([data-ui="Compare"] thead th) { color: var(--ink-2); font-weight: 500; border-bottom: 1px solid var(--rule); }
    :global([data-ui="Compare"] td) { font-weight: 500; }
    :global([data-ui="Compare"] th:first-child),
    :global([data-ui="Compare"] td:first-child) { text-align: left; }
    /* The cartridge columns and the difference, headers included, as the detail page's tables. */
    :global([data-ui="Compare"] th.n),
    :global([data-ui="Compare"] td.n) { text-align: right; }
  }
</style>
