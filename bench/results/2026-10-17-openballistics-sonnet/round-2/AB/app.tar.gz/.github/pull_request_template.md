## What changes, and why

## Sources

<!-- For data changes: where each changed figure comes from (C.I.P. sheet and date, rulebook and
page, maker's page). Delete this section if the change touches no data. -->

## Checked

- [ ] `npm test` and `npm run build` pass in `site/`
- [ ] The pull request title, and each commit, follows the Conventional Commits convention in CONTRIBUTING.md
