# Changelog

All notable changes to this project are recorded here.

The format is based on [Keep a Changelog 1.1.0](https://keepachangelog.com/en/1.1.0/), and the
project adheres to [Semantic Versioning 2.0.0](https://semver.org/spec/v2.0.0.html). How versions
are numbered and released is described in [RELEASING.md](RELEASING.md).

## [Unreleased]

### Added

- Cartridge and chamber records for 525 cartridges in six families: belted, pistol, rimfire,
  rimless, rimmed and shotshell.
- 75 synthetic sample bullet records, three for each of 25 common calibres.
- 24 target faces published by BDS and DSB.
- Shared TypeScript libraries for geometry, drawing, targets and user data.
- A website to browse the data, draw cartridges, chambers and bullets, and score shots on targets,
  with personal data kept in the browser and exportable.
- Continuous integration, deployment to GitHub Pages, tag-triggered releases and automated
  dependency updates.
- A comparison view at `#/compare/<a>/<b>`, reached from the "Compare with" choice on a cartridge's
  page: the two cases drawn over each other at one scale, and a table of every dimension either
  publishes with the difference between them, in millimetres or inches as set under Default units.
  A dimension only one cartridge publishes is listed with the other cells left empty.
