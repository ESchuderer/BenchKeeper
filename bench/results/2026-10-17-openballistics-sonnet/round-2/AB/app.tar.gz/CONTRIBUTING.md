# Contributing

Thank you for helping. This file covers how a change gets into the repository. For setting up,
running and testing, see [README.md](README.md).

## Before you start

- For a data mistake, an issue from the templates is enough, as long as it names where the correct
  figure is published.
- For anything bigger than a fix, such as a new feature, a change to how records are laid out, or
  real bullet records, open an issue first so we can agree on the shape before you spend the time.
- Contributions are accepted under the project's [MIT License](LICENSE). Only submit what you
  have the right to share, and do not copy figures from sources that forbid it.

## Making a change

1. Fork the repository and branch from `main`.
2. Make the change. Edit the data, the libraries and the site as the task needs, and add or update
   tests for behaviour you change.
3. From `site/`, run `npm test` and `npm run build`. These are the checks CI runs.
4. Open a pull request against `main`, and fill in the template. Say where changed figures come
   from.

CI must pass before a pull request is merged. If a pull request is squash-merged, its title
becomes the commit message, so give it a title that follows the convention below too.

## Commit convention

Commit subjects follow [Conventional Commits 1.0.0](https://www.conventionalcommits.org/en/v1.0.0/):

```text
<type>(<scope>): <summary>

<optional body: what and why>
```

The scope is optional. Write the summary in the imperative, in lower case, without a final full
stop.

**Types**

| Type       | Use it for                                                    |
| ---------- | ------------------------------------------------------------- |
| `feat`     | a new feature, or new records in `data/`                      |
| `fix`      | a bug fix, or a correction to a value in `data/`              |
| `docs`     | documentation only                                            |
| `style`    | formatting that changes no behaviour                          |
| `refactor` | a change that is neither a fix nor a feature                  |
| `perf`     | a performance improvement                                     |
| `test`     | adding or correcting tests                                    |
| `build`    | the build, scripts and dependencies                           |
| `ci`       | workflows and other CI configuration                          |
| `chore`    | anything else that does not touch what users receive          |
| `revert`   | reverting an earlier commit                                   |

**Scopes** are free-form lower-case words. These are in use: `data` (anything under `data/`),
`lib`, `site`, `deps` (dependency updates), `release`.

**Breaking changes** add `!` after the type or scope, and a `BREAKING CHANGE:` footer saying what
breaks. In this project that means a change to the record format that existing readers of
`data/` would not survive; see [RELEASING.md](RELEASING.md).

Examples:

```text
fix(data): correct the case length of 308 Win.
feat(data): add the 6.5 PRC cartridge
feat(site): add a unit toggle to the cartridge page
docs: explain how to build for a sub-path
feat(data)!: rename the pressures field of cartridge records
```

CI checks every non-merge commit subject in a pull request against this pattern, so it is worth
getting right locally. To fix subjects after the fact, use `git commit --amend` for the last
commit or an interactive rebase for earlier ones, then force-push your branch.

## Changelog

[CHANGELOG.md](CHANGELOG.md) is written by maintainers when a release is prepared, from the
history of commits. You do not need to edit it, but you may add a line under `Unreleased` if you
want to word it yourself.
