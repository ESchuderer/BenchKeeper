# OpenBallistics

An open database of cartridges, bullets and targets, kept as JSON records in `data/`, with the
shared TypeScript libraries that draw and measure them in `lib/` and a Svelte website that browses
them in `site/`.

- **Cartridges and chambers** - 525 records in six families (belted, pistol, rimfire, rimless,
  rimmed, shotshell), after the C.I.P. tables of dimensions.
- **Bullets** - a catalogue of synthetic sample records for demonstrating the drawings.
- **Targets** - 24 target faces published by BDS and DSB.

OpenBallistics is independent of C.I.P., BDS and DSB.

## Repository layout

| Path        | What it holds                                                                  |
| ----------- | ------------------------------------------------------------------------------ |
| `data/`     | The records: `cartridges/<family>/`, `bullets/` and `targets/`, one JSON file each |
| `lib/`      | Framework-free TypeScript libraries (geometry, drawing, targets, user data) and their tests |
| `site/`     | The Svelte website, its build scripts, and the only `package.json` and lockfile |
| `fixtures/` | Reference SVGs and inputs that the drawing tests compare against               |

## Install

You need [Node.js](https://nodejs.org/) 22 (the version in `.nvmrc`) and npm. Every npm command
below runs from `site/`:

```sh
git clone https://github.com/PiMetry/OpenBallistics.git
cd OpenBallistics/site
npm ci
```

## Develop

```sh
npm run dev       # builds the search indexes from data/, then starts the Vite dev server
```

The dev server serves the records in `data/` directly, so an edited record shows up on reload.
The search index is rebuilt only when `npm run dev` starts, so run `npm run index` again after a
change to a value the lists show.

The site keeps its search indexes in `site/src/lib/*.generated.json`. They are built from `data/`,
ignored by git, and rebuilt by `dev`, `test` and `build`. To rebuild them on their own:

```sh
npm run index         # the cartridge, bullet and flag indexes
npm run fieldsets     # which fields each cartridge family has
npm run prepare-data  # both of the above
```

## Test

```sh
npm test                                  # all tests in site/ and lib/, after rebuilding the indexes
npm test -- src/lib/router.test.ts        # one file; extra arguments go to Vitest
```

The tests also check the data: the indexes must build from every record, each target face must
be valid, and the bullet catalogue must match its description.

## Build

```sh
npm run build     # builds the indexes, type-checks with svelte-check, then writes site/dist/
npm run preview   # serves site/dist/ locally
```

The site is built for the root of a domain by default. To build for a sub-path, as GitHub Pages
does for a project page, set `PAGES_BASE`:

```sh
PAGES_BASE=/OpenBallistics/ npm run build
```

Pull requests are checked by GitHub Actions with exactly `npm ci`, `npm test` and
`npm run build`. If those pass on your machine, CI will pass too.

## Contribute data

The data is the heart of the project, and a correction is as welcome as a new record.

**Found a mistake?** Open an issue from one of the templates: a wrong cartridge value, a wrong
bullet, or a problem with the site. Each asks where the right figure comes from. A report that
cites its source can be checked, and one that does not usually cannot be acted on. The site links
to these templates from its pages, with the record already filled in.

**Want to fix it yourself?** Open a pull request that edits the JSON.

- Cartridge records are `data/cartridges/<family>/<key>.json`. The file name is the record's
  `key`, and `<family>` is its family. Start from a neighbouring record rather than from nothing.
- Target faces are `data/targets/<id>.json`, named after their `id`. They come from a published
  BDS or DSB rulebook, which the record names in `ruleSources`. The tests expect exactly 24
  faces, so a pull request that adds one also updates that count in
  `site/src/lib/target-catalogue.test.ts`.
- Bullet records are `data/bullets/<key>.json`. Today the catalogue holds only the 75 synthetic
  samples, which `npm run sample-bullets` regenerates, so do not edit them by hand. A test
  requires that every file there is such a sample, so real bullet records need a change to that
  test; please open an issue to agree on it first.
- Write JSON the way the existing files do: two-space indentation, a final newline.
- Run `npm test` and `npm run build` before you push.
- Say in the pull request where each changed figure comes from: the C.I.P. sheet and its date, the
  rulebook and page, or the maker's page. Only submit figures you may share.

[CONTRIBUTING.md](CONTRIBUTING.md) has the details, including the commit convention.

## Commit convention

Commits follow [Conventional Commits](https://www.conventionalcommits.org/), for example
`fix(data): correct the case length of 308 Win.` or `feat(site): add a unit toggle`. CI checks
each commit subject in a pull request. The types and scopes are listed in
[CONTRIBUTING.md](CONTRIBUTING.md).

## Releases

Versions follow [Semantic Versioning](https://semver.org/) and are kept in `site/package.json`.
Changes are recorded in [CHANGELOG.md](CHANGELOG.md), which follows
[Keep a Changelog](https://keepachangelog.com/en/1.1.0/). A release is made by pushing a `v*` tag,
as described in [RELEASING.md](RELEASING.md). The site is deployed to GitHub Pages from `main`.

## License

The project's code, records and drawings are released under the [MIT License](LICENSE). The
third-party software it uses, and its licences, are listed in [THIRD-PARTY.md](THIRD-PARTY.md).
