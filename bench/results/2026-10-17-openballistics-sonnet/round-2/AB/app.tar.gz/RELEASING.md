# Releasing

How the version is kept, how a release is made, and what has to be set up once on GitHub.
Everyone else can skip this file.

## Where the version is

The version is the `version` field of **`site/package.json`**, mirrored in
`site/package-lock.json`. `npm version` keeps the two together, which is why it is the only way
the version should change. There is one version for the whole repository: the data, the libraries
and the site are released together.

## What the version number means

[Semantic Versioning 2.0.0](https://semver.org/spec/v2.0.0.html), with the public surface being
the layout of `data/`: the paths, the `key` of each record, and the fields in it.

| Bump  | When                                                                                       |
| ----- | ------------------------------------------------------------------------------------------ |
| major | a record field is removed, renamed or changes meaning, or a record's `key` changes or goes |
| minor | new records, new fields that old readers can ignore, or new features of the site           |
| patch | corrections to values, and bug fixes                                                       |

While the version is `0.y.z`, anything may change in a minor release.

## Releasing

A release is a tag `vX.Y.Z` on `main`. Pushing it starts `.github/workflows/release.yml`.

1. Decide the version from the changes since the last release (see above).
2. On a branch from `main`, run from `site/`:

   ```sh
   npm version X.Y.Z --no-git-tag-version
   ```

   This edits `site/package.json` and `site/package-lock.json` and does nothing else. The first
   release, `0.1.0`, is already the version in the repository, so skip this step.
3. In `CHANGELOG.md`, rename `## [Unreleased]` to `## [X.Y.Z] - YYYY-MM-DD`, check that its
   entries describe the release, and add a fresh empty `## [Unreleased]` above it. Update the
   link definitions at the bottom of the file, if it has any (see the format below).
4. Commit as `chore(release): vX.Y.Z`, open a pull request, and merge it once CI passes.
5. Tag the merge commit on `main` and push the tag:

   ```sh
   git switch main && git pull
   git tag -a vX.Y.Z -m "vX.Y.Z"
   git push origin vX.Y.Z
   ```

The release workflow refuses to publish unless the tag is a semantic version, matches both files
under `site/`, points at a commit on `main`, and has a dated section in `CHANGELOG.md`. It then
runs the tests and the build, and creates a GitHub Release whose notes are that changelog
section. The release carries three files:

- `openballistics-data-X.Y.Z.zip` - `data/` and the licence, as committed at the tag
- `openballistics-site-X.Y.Z.tar.gz` - the built site, for the root of a domain
- `SHA256SUMS`

A version with a suffix, such as `1.0.0-rc.1`, is published as a pre-release.

The merge in step 4 already deployed the site to GitHub Pages, as every merge to `main` does
(`.github/workflows/pages.yml`). A release does not deploy anything else.

If the workflow fails before it creates the release, fix the cause, delete the tag
(`git push origin :refs/tags/vX.Y.Z`, and `git tag -d vX.Y.Z` locally), and tag again. A tag that
has been released should never be moved; make a new patch version instead.

## Changelog format

[`CHANGELOG.md`](CHANGELOG.md) follows [Keep a Changelog 1.1.0](https://keepachangelog.com/en/1.1.0/):

- Newest version first, under a top-level `## [Unreleased]` section for changes not yet released.
- A released version is a heading of exactly the form `## [X.Y.Z] - YYYY-MM-DD`. The release
  workflow looks for this form.
- Under each version, entries go in `###` groups named `Added`, `Changed`, `Deprecated`,
  `Removed`, `Fixed` or `Security`, in that order, leaving out the empty ones.
- Entries are short sentences for readers of the data and users of the site, not commit subjects.
  Name the records or pages affected.
- Optionally, link definitions at the bottom of the file: `[X.Y.Z]: <compare URL>` and
  `[Unreleased]: <compare URL>`. The release workflow ignores them when it extracts the notes.
  They can be added from the second release on, once there is a previous tag to compare against.

## One-time repository setup

These are GitHub settings; the files in the repository cannot make them.

- **Pages**: Settings > Pages > Build and deployment > Source: *GitHub Actions*. Without it the
  deploy job in `pages.yml` fails.
- **Branch protection on `main`**: require a pull request and the `Test and build` and `Commit
  messages` checks from `ci.yml` to pass before merging.
- **Tag protection**: add a ruleset for `v*` tags that restricts who can create them, since a tag
  publishes a release.
- **Actions**: Settings > Actions > General > Workflow permissions can stay on *read repository
  contents*; each workflow asks for what it needs.
- **Dependabot**: enable Dependabot alerts and version updates; `.github/dependabot.yml` has the
  schedule. Its pull requests use `build(deps)` and `ci(deps)` subjects, which pass the commit check.
