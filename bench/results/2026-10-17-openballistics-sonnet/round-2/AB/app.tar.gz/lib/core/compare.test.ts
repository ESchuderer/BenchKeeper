/**
 * Which dimensions two cartridges publish, and what their difference is.
 *
 * Read from the dataset in data/cartridges, so a change to what the records publish shows up here
 * rather than as a silently shorter table.
 */

import { readFileSync } from 'node:fs';
import { join } from 'node:path';
import { describe, expect, it } from 'vitest';
import { comparedDimensions, difference, publishedDimensions } from './compare';
import type { Record_ } from './types';
import { CARTRIDGES } from '../testing/fixtures';

function record(family: string, key: string): Record_ {
  return JSON.parse(readFileSync(join(CARTRIDGES, family, `${key}.json`), 'utf8')) as Record_;
}

const only = (cartridge: Record_['cartridge']): Pick<Record_, 'cartridge'> => ({ cartridge });

describe('published dimensions', () => {
  it('keeps the lengths of the cartridge part, in the order of the detail page', () => {
    const symbols = [...publishedDimensions(record('rimless', '308_win')).keys()];
    expect(symbols.slice(0, 4)).toEqual(['L1', 'L2', 'L3', 'L6']);
    expect(symbols.indexOf('R')).toBeLessThan(symbols.indexOf('E'));
    expect(symbols.indexOf('P1')).toBeLessThan(symbols.indexOf('S'));
  });

  it('leaves out angles, pressures, energies, masses and tolerances', () => {
    const symbols = new Set(publishedDimensions(record('belted', '300_win_mag')).keys());
    for (const left of ['alpha', 'delta', 'beta', 'Pmax', 'PK', 'PE', 'EE', 'EK', 'M', 'ETol']) {
      expect(symbols.has(left), left).toBe(false);
    }
    expect(symbols.has('eMin')).toBe(true);
  });

  it('does not count a blank, a string, or the chamber', () => {
    const found = publishedDimensions(only({
      lengths: { L1: 10, L2: null, L3: '12' as unknown as number },
      misc: { Fe: 0 }
    }));
    expect([...found]).toEqual([['L1', 10], ['Fe', 0]]);
  });

  it('skips the repeating groups of a shot cartridge', () => {
    const found = publishedDimensions(record('shotshell', '12'));
    for (const value of found.values()) expect(typeof value).toBe('number');
  });
});

describe('compared dimensions', () => {
  const a = record('rimless', '308_win');
  const b = record('belted', '300_win_mag');

  it('has one row per symbol either publishes, written as the detail page writes it', () => {
    const rows = comparedDimensions(a, b);
    const symbols = rows.map((row) => row.symbol);
    expect(new Set(symbols).size).toBe(symbols.length);
    expect(symbols).toContain('e min');
    expect(symbols).toContain('r1 min');
    expect(symbols).toContain('L3 + G');
    expect(rows.find((row) => row.symbol === 'L3')).toMatchObject({ a: 51.18, b: 66.55 });
  });

  it('keeps a symbol only one of them publishes, with the other side absent', () => {
    const rows = comparedDimensions(
      only({ lengths: { L1: 1, L2: 2 } }),
      only({ lengths: { L2: 5, L3: 6 } })
    );
    expect(rows).toEqual([
      { field: 'L1', symbol: 'L1', a: 1 },
      { field: 'L2', symbol: 'L2', a: 2, b: 5 },
      { field: 'L3', symbol: 'L3', b: 6 }
    ]);
  });

  it('lists the symbols of the two real sheets that only one publishes', () => {
    const rows = comparedDimensions(a, b);
    const deltaL = rows.find((row) => row.symbol === 'delta L');
    const r3 = rows.find((row) => row.symbol === 'R3');
    expect(deltaL?.a).toEqual(expect.any(Number));
    expect(deltaL).not.toHaveProperty('b');
    expect(r3?.b).toEqual(expect.any(Number));
    expect(r3).not.toHaveProperty('a');
  });

  it('places a symbol only B publishes after the one before it in B', () => {
    const middle = comparedDimensions(
      only({ lengths: { L1: 1, L3: 3 } }),
      only({ lengths: { L1: 1, L2: 2, L3: 3 } })
    );
    expect(middle.map((row) => row.field)).toEqual(['L1', 'L2', 'L3']);
    const front = comparedDimensions(only({ lengths: { L2: 2 } }), only({ lengths: { L1: 1, L2: 2 } }));
    expect(front.map((row) => row.field)).toEqual(['L1', 'L2']);
  });


  it('finds a symbol in different groups of the two records', () => {
    const rows = comparedDimensions(only({ collar: { H1: 1 } }), only({ misc: { H1: 3 } }));
    expect(rows).toEqual([{ field: 'H1', symbol: 'H1', a: 1, b: 3 }]);
  });

  it('is empty for two records that publish nothing', () => {
    expect(comparedDimensions(only({}), only({}))).toEqual([]);
  });
});

describe('difference', () => {
  it('is B minus A', () => {
    expect(difference(51.18, 66.55)).toBe(15.37);
    expect(difference(1.37, 1.27)).toBe(-0.1);
  });

  it('carries no float noise from the subtraction', () => {
    expect(66.55 - 51.18).not.toBe(15.37);
    expect(difference(11.96, 13.03)).toBe(1.07);
    expect(difference(0.1, 0.3)).toBe(0.2);
  });

  it('is a plain zero when the figures agree', () => {
    expect(Object.is(difference(7.85, 7.85), 0)).toBe(true);
  });
});
