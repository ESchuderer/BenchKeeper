/**
 * What two cartridges publish to compare: every dimension either sheet gives.
 *
 * Framework-free. The rows are in the order the detail page lists the same fields, and carry the
 * canonical millimetres; how a figure is written - metric as the sheet prints it, or in inches -
 * is the page's business, since it depends on the reader's unit preference.
 */

import { FIELD_LABELS, FIELD_UNITS, GROUP_ORDER, orderedFields } from './fields';
import type { Record_ } from './types';

export interface DimensionRow {
  /** The JSON name of the field, which is the symbol's identity across records. */
  field: string;
  /** The symbol as the detail page writes it: `e min`, `L3 + G`. */
  symbol: string;
  /** Absent where that cartridge's sheet does not publish the dimension. */
  a?: number;
  b?: number;
}

/**
 * Every length a cartridge publishes, keyed by symbol, in the order the detail page shows them.
 *
 * A dimension is a number in the record's `cartridge` part whose unit is millimetres. Angles,
 * pressures, energies, masses and counts have an entry in `FIELD_UNITS` and are left out, as are
 * tolerances and the repeating groups of a shot cartridge. A field the sheet leaves blank is not
 * published, which is not the same as zero.
 */
export function publishedDimensions(record: Pick<Record_, 'cartridge'>): Map<string, number> {
  const found = new Map<string, number>();
  const groups = record.cartridge;
  const known = GROUP_ORDER.cartridge.filter((name) => name in groups);
  const placed = new Set(known);
  const rest = Object.keys(groups).filter((name) => !placed.has(name)).sort();
  for (const name of [...known, ...rest]) {
    const group = groups[name];
    if (!group || Array.isArray(group)) continue;
    for (const field of orderedFields('cartridge', name, group)) {
      const value = group[field];
      if (typeof value !== 'number' || !Number.isFinite(value) || Object.hasOwn(FIELD_UNITS, field)) continue;
      // A symbol that two groups both publish keeps the first, as the page lists it first.
      if (!found.has(field)) found.set(field, value);
    }
  }
  return found;
}

/**
 * One row per dimension symbol either record publishes, in the order of the detail page.
 *
 * A's order leads. A symbol only B publishes goes right after the symbol that precedes it in B's
 * own order, so it stays beside its neighbours and not at the foot of the table.
 */
export function comparedDimensions(
  a: Pick<Record_, 'cartridge'>,
  b: Pick<Record_, 'cartridge'>
): DimensionRow[] {
  const first = publishedDimensions(a);
  const second = publishedDimensions(b);
  const order = [...first.keys()];
  let previous: string | undefined;
  for (const field of second.keys()) {
    if (!first.has(field)) {
      order.splice(previous === undefined ? 0 : order.indexOf(previous) + 1, 0, field);
    }
    previous = field;
  }
  return order.map((field) => {
    const row: DimensionRow = { field, symbol: FIELD_LABELS[field] ?? field };
    const valueA = first.get(field);
    const valueB = second.get(field);
    if (valueA !== undefined) row.a = valueA;
    if (valueB !== undefined) row.b = valueB;
    return row;
  });
}

/**
 * B minus A, as the decimal the two published figures differ by.
 *
 * Two figures with a few decimals subtract to something like `1.0700000000000003`, which says a
 * precision neither sheet has. Twelve significant digits is what `displayNumber` keeps for the
 * inch figures too, and it is far beyond anything C.I.P. publishes, so no published digit is lost.
 */
export function difference(a: number, b: number): number {
  return Number((b - a).toPrecision(12)) + 0;
}
