/** The overlay of two case profiles. */

import { readFileSync } from 'node:fs';
import { join } from 'node:path';
import { describe, expect, it } from 'vitest';
import { adaptMetallic, caseOuterProfile, type CartridgeRecord } from '../shapes2d';
import { compareProfiles } from './compare';
import { CARTRIDGES } from '../testing/fixtures';

function record(family: string, key: string): CartridgeRecord {
  return JSON.parse(readFileSync(join(CARTRIDGES, family, `${key}.json`), 'utf8')) as CartridgeRecord;
}

const a = record('rimless', '308_win');
const b = record('belted', '300_win_mag');

/** The numbers of a path, as [x, y] pairs. */
function points(path: string): [number, number][] {
  return [...path.matchAll(/[ML](-?[\d.]+),(-?[\d.]+)/g)].map((m) => [Number(m[1]), Number(m[2])]);
}

describe('compareProfiles', () => {
  const drawing = compareProfiles(a, b);
  const [first, second] = drawing.outlines.map((outline) => (outline.ok ? points(outline.path) : []));

  it('gives each case one closed outline', () => {
    for (const outline of drawing.outlines) {
      expect(outline.ok).toBe(true);
      if (outline.ok) {
        expect(outline.path.match(/M/g)).toHaveLength(1);
        expect(outline.path.endsWith('Z')).toBe(true);
      }
    }
  });

  it('draws the profile caseOuterProfile computes, mirrored about one axis', () => {
    const profile = caseOuterProfile(adaptMetallic(a));
    expect(first).toHaveLength(profile.length * 2);
    // The common axis is where r = 0, and the case is symmetrical about it.
    for (const [index, outline] of [first, second].entries()) {
      const count = outline!.length / 2;
      for (let i = 0; i < count; i++) {
        const left = outline![count + (count - 1 - i)]!;
        const right = outline![i]!;
        expect(left[0] + right[0], `outline ${index}, point ${i}`).toBeCloseTo(2 * drawing.axis.x, 4);
        expect(left[1]).toBeCloseTo(right[1], 4);
      }
    }
  });

  it('draws both at one scale: a millimetre is the same length in each', () => {
    const profileA = caseOuterProfile(adaptMetallic(a));
    const profileB = caseOuterProfile(adaptMetallic(b));
    const across = (outline: [number, number][]) =>
      Math.max(...outline.map(([x]) => x)) - Math.min(...outline.map(([x]) => x));
    const high = (outline: [number, number][]) => Math.max(...outline.map(([, y]) => y)) - Math.min(...outline.map(([, y]) => y));
    // The rims are 12.01 and 13.51 mm across, the mouths 51.18 and 66.55 mm from the head face.
    const scale = across(first!) / 12.01;
    expect(scale).toBeGreaterThan(0);
    expect(across(second!)).toBeCloseTo(13.51 * scale, 3);
    expect(high(first!)).toBeCloseTo(profileA[profileA.length - 1]![1] * scale, 3);
    expect(high(second!)).toBeCloseTo(profileB[profileB.length - 1]![1] * scale, 3);
  });

  it('puts the head faces at the same height, below everything else', () => {
    const profileA = caseOuterProfile(adaptMetallic(a));
    const profileB = caseOuterProfile(adaptMetallic(b));
    expect(first![0]![1]).toBeCloseTo(drawing.headFaceY, 4);
    expect(second![0]![1]).toBeCloseTo(drawing.headFaceY, 4);
    expect(profileA[0]![1]).toBe(0);
    expect(profileB[0]![1]).toBe(0);
    for (const [, y] of [...first!, ...second!]) expect(y).toBeLessThanOrEqual(drawing.headFaceY + 1e-6);
  });

  it('frames both with one box that holds them', () => {
    expect(drawing.width).toBeGreaterThan(0);
    for (const [x, y] of [...first!, ...second!]) {
      expect(x).toBeGreaterThan(0);
      expect(x).toBeLessThan(drawing.width);
      expect(y).toBeGreaterThan(0);
      expect(y).toBeLessThan(drawing.height);
    }
    expect(drawing.axis.x).toBeCloseTo(drawing.width / 2, 6);
  });

  it('is the same drawing the other way round, with the outlines swapped', () => {
    const swapped = compareProfiles(b, a);
    expect(swapped.width).toBe(drawing.width);
    expect(swapped.outlines).toEqual([drawing.outlines[1], drawing.outlines[0]]);
  });

  it('draws the one that can be drawn, and says why the other cannot', () => {
    const shot = record('shotshell', '12');
    const half = compareProfiles(a, shot);
    expect(half.outlines[0].ok).toBe(true);
    expect(half.outlines[1]).toMatchObject({ ok: false });
    expect(half.width).toBeGreaterThan(0);
  });

  it('draws nothing where neither can be drawn', () => {
    const shot = record('shotshell', '12');
    const none = compareProfiles(shot, shot);
    expect(none.width).toBe(0);
    expect(none.outlines.map((outline) => outline.ok)).toEqual([false, false]);
  });

  it('reports a record that leaves out what the case is built from', () => {
    const bare = record('rimmed', '7_x_67_r_luyven');
    const result = compareProfiles(a, bare);
    expect(result.outlines[1]).toMatchObject({ ok: false });
    expect(result.outlines[1].ok ? '' : (result.outlines[1] as { reason: string }).reason).toMatch(/R1/);
  });
});
