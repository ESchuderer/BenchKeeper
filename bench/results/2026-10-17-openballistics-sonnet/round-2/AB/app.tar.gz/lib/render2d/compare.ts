/** Two cases drawn over each other: one scale, one axis, the head faces on one line. */

import { fullSectionPath, viewportFor, type Profile } from '../geom';
import { adaptMetallic, caseOuterProfile, type CartridgeRecord } from '../shapes2d/case';

/** Pixels per millimetre of the viewBox. The page scales the drawing, so this only sets precision. */
const SCALE = 8;
const MARGIN_MM = 3;

export type Outline = { ok: true; path: string } | { ok: false; reason: string };

export interface ProfileComparison {
  width: number;
  height: number;
  /** Where the common axis is, in viewBox units, and the span of it. */
  axis: { x: number; y1: number; y2: number };
  /** The head face, which both outlines start on. */
  headFaceY: number;
  /** One per record, in the order given. */
  outlines: [Outline, Outline];
}

/**
 * The outer profile of a case as `caseOuterProfile` computes it, head face to mouth, or the
 * reason there is none. A shot cartridge is not drawn, and a record that leaves out a dimension
 * the case is built from cannot be.
 */
function profileOf(record: CartridgeRecord): Profile | string {
  if (record.family === 'shotshell') return 'A shot cartridge has no case profile.';
  try {
    return caseOuterProfile(adaptMetallic(record));
  } catch (error) {
    return error instanceof Error ? error.message : String(error);
  }
}

/**
 * The two cases in one frame. The viewport is built from both profiles, so both are scaled alike,
 * stand on the same axis, and have their head faces (z = 0) at the same height. Each outline is
 * the closed section, one side mirrored across the axis, as a single path.
 */
export function compareProfiles(a: CartridgeRecord, b: CartridgeRecord): ProfileComparison {
  const profiles = [profileOf(a), profileOf(b)];
  const drawable = profiles.filter((profile): profile is Profile => typeof profile !== 'string');
  if (!drawable.length) {
    return {
      width: 0,
      height: 0,
      axis: { x: 0, y1: 0, y2: 0 },
      headFaceY: 0,
      outlines: profiles.map((reason) => ({ ok: false, reason })) as [Outline, Outline]
    };
  }
  const view = viewportFor(drawable, { scale: SCALE, marginMm: MARGIN_MM });
  const [axisX, headFaceY] = view.xy(0, 0);
  const [, top] = view.xy(0, view.zMax);
  const outlines = profiles.map((profile): Outline =>
    typeof profile === 'string'
      ? { ok: false, reason: profile }
      : { ok: true, path: fullSectionPath(profile, view) }
  ) as [Outline, Outline];
  return { width: view.width, height: view.height, axis: { x: axisX, y1: top, y2: headFaceY }, headFaceY, outlines };
}
