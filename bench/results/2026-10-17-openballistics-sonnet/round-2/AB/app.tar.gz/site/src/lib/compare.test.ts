import { readFileSync } from 'node:fs';
import { join } from 'node:path';
import { describe, expect, it } from 'vitest';
import { formatValue, type Record_ } from '@lib/core';
import { CARTRIDGES } from '../../../lib/testing/fixtures';
import { comparisonRows, tableUnit } from './compare';
import { displayNumber } from './units';

function record(family: string, key: string): Record_ {
  return JSON.parse(readFileSync(join(CARTRIDGES, family, `${key}.json`), 'utf8')) as Record_;
}

const a = record('rimless', '308_win');
const b = record('belted', '300_win_mag');

describe('comparison table', () => {
  it('names the unit by the reader\'s preference', () => {
    expect(tableUnit('metric')).toBe('mm');
    expect(tableUnit('imperial')).toBe('in');
  });

  it('writes metric figures as the detail page does, and the difference as B minus A', () => {
    const rows = comparisonRows(a, b, 'metric');
    const row = (symbol: string) => rows.find((r) => r.symbol === symbol);
    expect(row('L3')).toEqual({ symbol: 'L3', a: '51.18', b: '66.55', difference: '15.37' });
    expect(row('e min')).toEqual({ symbol: 'e min', a: '1.4', b: '0.94', difference: '-0.46' });
    expect(row('G1')).toEqual({ symbol: 'G1', a: '7.85', b: '7.85', difference: '0' });
    const source = (a.cartridge.lengths as Record<string, number>).L1!;
    expect(row('L1')!.a).toBe(formatValue(source));
  });

  it('writes imperial figures in inches, converted and not rounded further', () => {
    const rows = comparisonRows(a, b, 'imperial');
    const row = rows.find((r) => r.symbol === 'L3')!;
    expect(row.a).toBe(displayNumber(51.18, 'in'));
    expect(row.b).toBe(displayNumber(66.55, 'in'));
    expect(row.difference).toBe(displayNumber(15.37, 'in'));
    expect(row.a).toBe('2.01496062992');
    expect(rows.find((r) => r.symbol === 'G1')!.difference).toBe('0');
  });

  it('lists a dimension only one cartridge publishes, with its other cells empty', () => {
    for (const system of ['metric', 'imperial'] as const) {
      const rows = comparisonRows(a, b, system);
      const deltaL = rows.find((r) => r.symbol === 'delta L')!;
      const r3 = rows.find((r) => r.symbol === 'R3')!;
      expect(deltaL.a).not.toBe('');
      expect([deltaL.b, deltaL.difference]).toEqual(['', '']);
      expect(r3.b).not.toBe('');
      expect([r3.a, r3.difference]).toEqual(['', '']);
    }
  });

  it('has the same rows, in the same order, in either unit', () => {
    expect(comparisonRows(a, b, 'imperial').map((r) => r.symbol)).toEqual(
      comparisonRows(a, b, 'metric').map((r) => r.symbol)
    );
  });

  it('negates the differences when the cartridges are swapped', () => {
    const forward = comparisonRows(a, b, 'metric');
    const backward = comparisonRows(b, a, 'metric');
    expect(backward.map((r) => r.symbol)).not.toEqual([]);
    for (const row of forward) {
      const other = backward.find((r) => r.symbol === row.symbol)!;
      expect(other.a).toBe(row.b);
      expect(other.difference).toBe(row.difference === '0' || row.difference === '' ? row.difference : row.difference.startsWith('-') ? row.difference.slice(1) : `-${row.difference}`);
    }
  });
});
