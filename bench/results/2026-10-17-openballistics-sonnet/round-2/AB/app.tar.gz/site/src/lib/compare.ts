/**
 * How the comparison table writes its figures.
 *
 * Metric figures are the sheet's own, written as the detail page writes them. Imperial ones are
 * lengths in inches, converted with the same `displayNumber` the rest of the site uses. Neither
 * rounds: the difference is converted from the millimetre difference, not subtracted from two
 * rounded inch figures.
 */

import { comparedDimensions, difference, formatValue, type Record_ } from '@lib/core';
import { defaultUnit, displayNumber, type UnitSystem } from './units';

/** A cell is empty where a cartridge does not publish the dimension; so is the difference. */
export interface ComparisonRow {
  symbol: string;
  a: string;
  b: string;
  difference: string;
}

/** The unit the table's lengths are written in. */
export const tableUnit = (system: UnitSystem): 'mm' | 'in' => defaultUnit('length', system) as 'mm' | 'in';

function write(value: number, unit: 'mm' | 'in'): string {
  return unit === 'mm' ? formatValue(value) ?? '' : displayNumber(value, unit);
}

export function comparisonRows(a: Record_, b: Record_, system: UnitSystem): ComparisonRow[] {
  const unit = tableUnit(system);
  return comparedDimensions(a, b).map((row) => ({
    symbol: row.symbol,
    a: row.a === undefined ? '' : write(row.a, unit),
    b: row.b === undefined ? '' : write(row.b, unit),
    difference: row.a === undefined || row.b === undefined ? '' : write(difference(row.a, row.b), unit)
  }));
}
