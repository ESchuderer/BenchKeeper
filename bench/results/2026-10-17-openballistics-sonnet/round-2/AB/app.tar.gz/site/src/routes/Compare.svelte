<script lang="ts">
  import Flag from '../components/Flag.svelte';
  import { byKey, load } from '../lib/data';
  import { comparisonRows, tableUnit } from '../lib/compare';
  import { href } from '../lib/router';
  import { t } from '../lib/i18n.svelte';
  import { unitSystem } from '../lib/units.svelte';
  import { compareProfiles } from '@lib/render2d/compare';
  import type { CartridgeRecord } from '@lib/shapes2d';

  interface Props {
    /** The keys of the two cartridges, as the site uses them in `#/c/<key>`. */
    a: string;
    b: string;
  }
  let { a, b }: Props = $props();

  const missing = $derived([a, b].find((key) => !byKey(key)));
  const records = $derived(missing === undefined ? Promise.all([load(a), load(b)]) : null);
</script>

<div data-ui="Compare" class="contents compare">
{#if missing !== undefined}
  <p class="status error">{t('compare.unknown', { key: missing })} <a href={href.list()}>{t('record.back')}</a></p>
{:else}
  {#await records}
    <p class="status">{t('record.loading', { name: `${byKey(a)?.name ?? a} / ${byKey(b)?.name ?? b}` })}</p>
  {:then pair}
    {#if pair}
      {@const [first, second] = pair}
      {@const drawing = compareProfiles(first as unknown as CartridgeRecord, second as unknown as CartridgeRecord)}
      {@const rows = comparisonRows(first, second, unitSystem())}
      {@const undrawn = [first, second].filter((_, index) => !drawing.outlines[index]?.ok)}
      <header class="head">
        <h1>{t('compare.title', { a: first.name, b: second.name })}</h1>
        <ul class="legend">
          {#each [first, second] as record, index (index)}
            <li class={index === 0 ? 'a' : 'b'}>
              <span class="swatch" aria-hidden="true"></span>
              <a href={href.cartridge(record.key)}>{record.name}</a>
              {#if byKey(record.key)?.countries.length}<Flag codes={byKey(record.key)?.countries ?? []} />{/if}
            </li>
          {/each}
        </ul>
      </header>

      <div class="body">
        <figure class="profiles">
          {#if drawing.width > 0}
            <svg
              class="plot"
              viewBox={`0 0 ${drawing.width} ${drawing.height}`}
              role="img"
              aria-label={t('compare.profiles', { a: first.name, b: second.name })}
            >
              <line class="axis" x1={drawing.axis.x} y1={drawing.axis.y1} x2={drawing.axis.x} y2={drawing.axis.y2} />
              {#each drawing.outlines as outline, index (index)}
                {#if outline.ok}<path class={index === 0 ? 'a' : 'b'} d={outline.path} />{/if}
              {/each}
            </svg>
          {/if}
          {#if undrawn.length === 2}
            <p class="note">{t('compare.noProfiles')}</p>
          {:else}
            {#each undrawn as record (record.key)}
              <p class="note">{t('compare.noProfile', { name: record.name })}</p>
            {/each}
          {/if}
        </figure>

        <div class="figures">
          {#if rows.length}
            <div class="scroll">
              <table>
                <caption>{t('compare.dimensions', { unit: tableUnit(unitSystem()) })}</caption>
                <thead>
                  <tr>
                    <th scope="col">{t('compare.symbol')}</th>
                    <th scope="col" class="num">{first.name}</th>
                    <th scope="col" class="num">{second.name}</th>
                    <th scope="col" class="num">{t('compare.difference')}</th>
                  </tr>
                </thead>
                <tbody>
                  {#each rows as row (row.symbol)}
                    <tr>
                      <td class="num symbol">{row.symbol}</td>
                      <td class="num">{row.a}</td>
                      <td class="num">{row.b}</td>
                      <td class="num">{row.difference}</td>
                    </tr>
                  {/each}
                </tbody>
              </table>
            </div>
            <p class="hint">{t('compare.differenceNote', { a: first.name, b: second.name })}</p>
          {:else}
            <p class="note">{t('compare.none')}</p>
          {/if}
        </div>
      </div>
    {/if}
    <p class="foot">
      <a href={href.list()}>{t('record.back')}</a>
    </p>
  {:catch error}
    <p class="status error">{error.message} <a href={href.list()}>{t('record.back')}</a></p>
  {/await}
{/if}
</div>

<style>
  @layer legacy {
    .compare { --compare-a: #1d4ed8; --compare-b: #b45309; }
    :global([data-theme='dark']) .compare { --compare-a: #93c5fd; --compare-b: #fbbf24; }
    .status { color: var(--muted-foreground); padding: 2rem 0; }
    .status.error { color: var(--destructive, #b91c1c); }
    .head { padding-bottom: var(--space-6); border-bottom: 1px solid var(--rule); }
    h1 { font-size: clamp(var(--step-3), 1.2rem + 2vw, var(--step-4)); line-height: 1.15; letter-spacing: -0.01em; }
    /* The two cartridges are told apart by stroke style as well as colour. */
    .legend { list-style: none; display: flex; flex-wrap: wrap; gap: .5rem 1.5rem; margin: .75rem 0 0; padding: 0; }
    .legend li { display: flex; align-items: center; gap: .5rem; }
    .swatch { width: 1.75rem; border-top: 3px solid var(--compare-a); }
    .legend .b .swatch { border-top: 3px dashed var(--compare-b); }
    .body { display: grid; gap: 2rem; margin-top: 1.5rem; align-items: start; }
    @media (min-width: 56rem) { .body { grid-template-columns: minmax(0, 2fr) minmax(0, 3fr); } }
    .profiles { margin: 0; }
    .plot { display: block; width: 100%; height: auto; max-height: min(70vh, 40rem); }
    .plot path { fill-opacity: .08; stroke-width: 1.5; stroke-linejoin: round; vector-effect: non-scaling-stroke; }
    .plot path.a { fill: var(--compare-a); stroke: var(--compare-a); }
    .plot path.b { fill: var(--compare-b); stroke: var(--compare-b); stroke-dasharray: 6 3; }
    .plot .axis { stroke: var(--ink-3); stroke-width: 1; stroke-dasharray: 2 4; vector-effect: non-scaling-stroke; }
    .scroll { overflow-x: auto; }
    table { border-collapse: collapse; font-size: var(--step-0); width: 100%; }
    caption { text-align: left; font-weight: 600; padding-bottom: .5rem; }
    th, td { text-align: right; padding: .2rem .75rem .2rem 0; white-space: nowrap; }
    th { color: var(--ink-2); font-weight: 500; border-bottom: 1px solid var(--rule); }
    th:first-child, td:first-child { text-align: left; }
    td { font-weight: 500; }
    td.symbol { color: var(--ink-2); }
    .hint, .note { color: var(--ink-2); font-size: var(--step-0); margin: .75rem 0 0; }
    .foot { margin-top: 2rem; }
  }
</style>
