# 01 Compare view

Status: ready-for-agent

Implements `spec.md`: `site/src/lib/compare.ts` (rows, profiles, SVG), route `compare`, `site/src/routes/Compare.svelte`, the picker on `Cartridge.svelte`, i18n en/de, tests, CHANGELOG entry.
