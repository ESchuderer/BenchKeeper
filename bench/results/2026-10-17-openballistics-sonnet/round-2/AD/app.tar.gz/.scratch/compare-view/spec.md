# Compare two cartridges

Status: ready-for-agent

Route `#/compare/<a>/<b>` (keys as in `#/c/<key>`), reload-safe.

- Drawing: `caseOuterProfile` of both cases in one SVG (`role="img"`, name `Profiles of <name A> and <name B>`), one scale, common axis, head faces at the same point, one `path` per outline.
- Table (`Dimensions (mm)` or `Dimensions (in)`, a caption): one row per symbol that either record publishes as a number in `cartridge` with no entry in `FIELD_UNITS`, tolerances excluded; A's symbols first, then those only B publishes. Where a record does not publish a symbol, its cell and `Difference` are empty. Columns `Symbol`, name A, name B, `Difference` (B minus A). Symbol as `FIELD_LABELS` writes it.
- Units follow Settings, Default units: metric through `formatValue`, imperial through `displayNumber(value, 'in')`, differences converted the same way.
- Detail page: select `Compare with` (other cartridges by name) and button `Compare`.
- English and German texts.

Decisions: shot cartridges are not offered and the view says so for a shot key. A cartridge that publishes too little to draw shows the table and a note instead of the drawing. The difference is computed in mm, then written with `displayNumber` (12 significant digits, removes float noise such as 7.699999999999996).
