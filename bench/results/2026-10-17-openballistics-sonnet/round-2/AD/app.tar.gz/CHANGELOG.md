# Changelog

All notable changes to this project are recorded in this file.

The format follows [Keep a Changelog 1.1.0](https://keepachangelog.com/en/1.1.0/). Versions follow
[Semantic Versioning 2.0.0](https://semver.org/spec/v2.0.0.html), as defined in
[CONTRIBUTING.md](CONTRIBUTING.md#versioning).

Rules for this file:

- Newest version first, under a `## [Unreleased]` section that collects changes not yet released.
- Each version heading is `## [X.Y.Z] - YYYY-MM-DD`.
- Entries sit under `### Added`, `### Changed`, `### Deprecated`, `### Removed`, `### Fixed` or
  `### Security`. Empty groups are left out.
- The release workflow publishes the section of the tagged version as the release notes.

## [Unreleased]

### Added

- Comparison of two cartridges at `#/compare/<a>/<b>`: overlaid case profiles and a table of the
  dimensions either publishes, opened from `Compare with` on a cartridge's page.
- GitHub Actions workflows: checks on pull requests, deployment of the site to GitHub Pages, and
  a tag-triggered release.
- Dependabot configuration for npm packages and GitHub Actions.
- Contributor documentation: `README.md` and `CONTRIBUTING.md`.
