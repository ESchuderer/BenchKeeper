# Contributing

Contributions are made as pull requests to `main`. For setup and commands see
[README.md](README.md). Report problems with the data or the site through the issue forms in
[.github/ISSUE_TEMPLATE](.github/ISSUE_TEMPLATE).

## Before opening a pull request

Run from `site/`:

```sh
npm test
npm run build
```

Both run in the pull request checks (`.github/workflows/ci.yml`) and must pass.

## Commit convention

Commits and pull request titles follow [Conventional Commits 1.0.0](https://www.conventionalcommits.org/en/v1.0.0/):

```
<type>(<optional scope>): <summary>
```

| Type | Use for |
|---|---|
| `feat` | New site feature, new record kind, new record |
| `fix` | Bug fix, corrected data value |
| `docs` | Documentation only |
| `test` | Tests only |
| `refactor` | Code change without behavior change |
| `perf` | Performance |
| `build` | Build system, dependencies |
| `ci` | Workflows in `.github/` |
| `chore` | Anything else, including releases (`chore(release): v1.2.3`) |

- Summary: imperative, lower case, no trailing period, at most 72 characters.
- Breaking change: `!` after the type or scope, and a `BREAKING CHANGE:` footer.
- Pull requests are squash-merged, so the pull request title is the commit message on `main`.

## Contributing data

Records are JSON files in `data/`:

| Path | Content |
|---|---|
| `data/cartridges/<family>/<key>.json` | Cartridges and chambers. Families: `belted`, `pistol`, `rimfire`, `rimless`, `rimmed`, `shotshell` |
| `data/bullets/<key>.json` | Bullets (see `data/bullets/README.md`) |
| `data/targets/<id>.json` | Target faces |

1. Copy the closest existing record and keep its field names and units.
2. The file name is the record key (`308_win.json`: `308_win`). Keys are unique within their folder.
3. Name the source of every changed or added figure in the pull request description: document, edition and page, or URL. A figure without a source is not merged.
4. Do not edit `data/bullets/sample_*.json` by hand. Regenerate them with `npm run sample-bullets` in `site/`.
5. Run `npm test` and `npm run build` in `site/`. The build regenerates the search index, which is not committed.
6. Commit type: `feat(data): ...` for added records, `fix(data): ...` for corrections.

## Versioning

- The version is `version` in `site/package.json` (and the matching entries in `site/package-lock.json`). The git tag is `v` plus that version.
- [Semantic Versioning](https://semver.org/spec/v2.0.0.html):
  - MAJOR: a change to the record JSON layout or to the export format of user data that breaks existing files.
  - MINOR: new records, new site features, other backward-compatible changes.
  - PATCH: corrected record values and bug fixes.
- While the major version is 0, a minor bump may include breaking changes.

## Making a release

Maintainers only. The release workflow (`.github/workflows/release.yml`) runs when a tag `vX.Y.Z` is pushed.

1. On a branch from `main`, in `site/`: `npm version X.Y.Z --no-git-tag-version`.
2. In `CHANGELOG.md`, rename `## [Unreleased]` to `## [X.Y.Z] - YYYY-MM-DD` and add a new empty `## [Unreleased]` above it.
3. Commit as `chore(release): vX.Y.Z`, open a pull request and merge it.
4. On `main` at the merge commit: `git tag vX.Y.Z` and `git push origin vX.Y.Z`.

The workflow fails if the tag differs from `site/package.json`, if `CHANGELOG.md` has no non-empty `## [X.Y.Z]` section, or if tests or the build fail. Otherwise it creates the GitHub release with that section as notes and the built site as `openballistics-site-vX.Y.Z.zip`.

## Deployment

`.github/workflows/pages.yml` builds the site and deploys it to GitHub Pages on every push to `main`. Once per repository, set Settings, Pages, Source to "GitHub Actions".

## Dependency updates

Dependabot (`.github/dependabot.yml`) opens weekly pull requests for npm packages in `site/` and for GitHub Actions. Their commit messages follow the convention above.
