# OpenBallistics

An open database of cartridges, bullets and targets as JSON records, with shared TypeScript libraries and a Svelte website that browses and draws them.

| Directory | Content |
|---|---|
| `data/` | JSON records: `cartridges/`, `bullets/`, `targets/` |
| `lib/` | Framework-free TypeScript libraries (geometry, drawing, targets, user data) |
| `site/` | Svelte website and the npm project (`package.json`) |
| `fixtures/` | Test fixtures |

The repository has one npm project, in `site/`. Run every npm command from there.

## Requirements

- Node.js 22
- npm

## Install

```sh
cd site
npm ci
```

## Develop

```sh
npm run dev
```

This regenerates the search index and field sets from `data/`, then starts Vite. Open the URL it prints.

## Test

```sh
npm test
```

Runs the Vitest tests of `site/src/` and `lib/`. The index is regenerated first.

## Build

```sh
npm run build
npm run preview
```

`build` regenerates the index, runs `svelte-check` and writes the site to `site/dist/`. `preview` serves that directory.

Other scripts: `npm run index`, `npm run fieldsets`, `npm run prepare-data` (both of those), `npm run sample-bullets` (regenerates `data/bullets/sample_*.json`).

Set `PAGES_BASE` to build for a sub-path, for example `PAGES_BASE=/OpenBallistics/ npm run build`.

## Contribute

- Data: records are JSON files in `data/`. Steps and the source requirement are in [CONTRIBUTING.md](CONTRIBUTING.md#contributing-data).
- Corrections without a pull request: use the [issue forms](https://github.com/PiMetry/OpenBallistics/issues/new/choose).
- Commits and pull request titles follow [Conventional Commits](CONTRIBUTING.md#commit-convention).
- Pull requests run `npm test` and `npm run build` (`.github/workflows/ci.yml`).

## Releases

Versions follow [Semantic Versioning](https://semver.org/spec/v2.0.0.html). The version is kept in `site/package.json`. A release is a `vX.Y.Z` tag. Changes are listed in [CHANGELOG.md](CHANGELOG.md) in the [Keep a Changelog](https://keepachangelog.com/en/1.1.0/) format. Procedure: [CONTRIBUTING.md](CONTRIBUTING.md#making-a-release).

The site is deployed to GitHub Pages from `main` (`.github/workflows/pages.yml`).

## License

[MIT](LICENSE). Third-party software and its licenses: [THIRD-PARTY.md](THIRD-PARTY.md).
