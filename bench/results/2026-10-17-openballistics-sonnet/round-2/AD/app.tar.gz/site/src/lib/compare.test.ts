import { readFileSync } from 'node:fs';
import { join } from 'node:path';
import { describe, expect, it } from 'vitest';
import { CARTRIDGES } from '@lib/testing/fixtures';
import type { Record_ } from '@lib/core';
import { compareDrawing, compareRows } from './compare';
import { displayNumber } from './units';

const read = (family: string, key: string) =>
  JSON.parse(readFileSync(join(CARTRIDGES, family, `${key}.json`), 'utf8')) as Record_;
const a = read('rimless', '308_win');
const b = read('belted', '300_win_mag');

describe('compareRows', () => {
  const rows = compareRows(a, b, 'metric');
  const row = (symbol: string) => rows.find((r) => r.symbol === symbol)!;

  it('writes symbols as the detail page does', () => {
    expect(row('e min')).toEqual({ symbol: 'e min', a: '1.4', b: '0.94', difference: '-0.46' });
    expect(row('L3 + G')).toBeDefined();
  });
  it('has one row per symbol and leaves out tolerances, angles and other units', () => {
    const symbols = rows.map((r) => r.symbol);
    expect(new Set(symbols).size).toBe(symbols.length);
    for (const absent of ['L1Tol', 'α', 'δ', 'β', 'Pmax', 'EE', 'M']) expect(symbols).not.toContain(absent);
  });
  it('subtracts A from B without float noise', () => {
    expect(66.55 - 51.18).not.toBe(15.37);
    expect(row('L3').difference).toBe('15.37');
    expect(row('L3').a).toBe('51.18');
  });
  it('lists symbols either record publishes and leaves the missing cells empty', () => {
    expect(row('delta L')).toEqual({ symbol: 'delta L', a: expect.stringMatching(/\d/), b: '', difference: '' });
    expect(row('R3')).toEqual({ symbol: 'R3', a: '', b: expect.stringMatching(/\d/), difference: '' });
    expect(row('Fe').difference).not.toBe('');
  });
  it('converts lengths and differences to inches', () => {
    const imperial = compareRows(a, b, 'imperial').find((r) => r.symbol === 'L3')!;
    expect(imperial.a).toBe(displayNumber(51.18, 'in'));
    expect(imperial.difference).toBe(displayNumber(66.55 - 51.18, 'in'));
  });
});

describe('compareDrawing', () => {
  it('overlays both outlines in one viewBox with one path each', () => {
    const drawing = compareDrawing(a, b)!;
    expect(drawing.paths).toHaveLength(2);
    expect(drawing.paths.every((d) => d.startsWith('M'))).toBe(true);
    expect(drawing.width).toBeGreaterThan(0);
  });
  it('puts both head faces at the same x and both axes at the same y', () => {
    const [pa, pb] = compareDrawing(a, b)!.paths.map((d) => [...d.matchAll(/[ML]([\d.-]+),([\d.-]+)/g)].map((m) => [+m[1]!, +m[2]!]));
    expect(Math.min(...pa!.map((p) => p[0]!))).toBeCloseTo(Math.min(...pb!.map((p) => p[0]!)));
    const mid = (p: number[][]) => (Math.min(...p.map((q) => q[1]!)) + Math.max(...p.map((q) => q[1]!))) / 2;
    expect(mid(pa!)).toBeCloseTo(mid(pb!));
  });
  it('returns null where a record publishes too little to draw', () => {
    expect(compareDrawing({ ...a, cartridge: {} } as Record_, b)).toBeNull();
  });
});
