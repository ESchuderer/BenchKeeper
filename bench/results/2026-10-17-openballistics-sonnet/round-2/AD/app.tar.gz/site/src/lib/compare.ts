/** The comparison of two cartridge records: the table's rows and the overlaid outlines. */

import { FIELD_LABELS, FIELD_UNITS, GROUP_ORDER, formatValue, orderedFields, type Record_ } from '@lib/core';
import { fullSectionPath, fmt, viewportFor } from '@lib/geom';
import { caseOuterProfile, adaptMetallic, type CartridgeRecord } from '@lib/shapes2d';
import { displayNumber, type UnitSystem } from './units';

export interface CompareRow {
  symbol: string;
  a: string;
  b: string;
  difference: string;
}

/** The millimetre dimensions of a record's `cartridge` part by symbol, in the order the page shows them. */
function dimensions(record: Record_): Map<string, number> {
  const found = new Map<string, number>();
  const groups = Object.keys(record.cartridge);
  const order = [...GROUP_ORDER.cartridge.filter((g) => g in record.cartridge), ...groups.filter((g) => !GROUP_ORDER.cartridge.includes(g))];
  for (const group of order) {
    const fields = record.cartridge[group];
    if (Array.isArray(fields)) continue;
    for (const field of orderedFields('cartridge', group, fields!)) {
      const value = fields![field];
      if (typeof value !== 'number' || Object.hasOwn(FIELD_UNITS, field)) continue;
      const symbol = FIELD_LABELS[field] ?? field;
      if (!found.has(symbol)) found.set(symbol, value);
    }
  }
  return found;
}

/** One row per dimension either record publishes, A's first. The difference is B minus A, taken in millimetres. */
export function compareRows(a: Record_, b: Record_, system: UnitSystem): CompareRow[] {
  const first = dimensions(a);
  const second = dimensions(b);
  const write = (mm: number | undefined) => (mm === undefined ? '' : system === 'metric' ? formatValue(mm)! : displayNumber(mm, 'in'));
  return [...new Set([...first.keys(), ...second.keys()])].map((symbol) => {
    const x = first.get(symbol);
    const y = second.get(symbol);
    const difference = x === undefined || y === undefined ? '' : displayNumber(y - x, system === 'metric' ? 'mm' : 'in');
    return { symbol, a: write(x), b: write(y), difference };
  });
}

export interface CompareDrawing {
  width: number;
  height: number;
  /** Outline of A, then of B: head face at the left, one scale, one axis. */
  paths: [string, string];
}

/** The outer profiles of both cases on one viewport, or `null` where either record cannot be drawn. */
export function compareDrawing(a: Record_, b: Record_): CompareDrawing | null {
  try {
    const profiles = [a, b].map((r) => caseOuterProfile(adaptMetallic(r as unknown as CartridgeRecord)));
    const view = viewportFor(profiles, { frame: 'landscape' });
    const paths = profiles.map((p) => fullSectionPath(p, view)) as [string, string];
    return { width: +fmt(view.width), height: +fmt(view.height), paths };
  } catch {
    return null;
  }
}
