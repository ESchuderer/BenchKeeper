<script lang="ts">
  import PageHeader from '../components/PageHeader.svelte';
  import { compareDrawing, compareRows } from '../lib/compare';
  import { load } from '../lib/data';
  import { href } from '../lib/router';
  import { t } from '../lib/i18n.svelte';
  import { unitSystem } from '../lib/units.svelte';

  let { a, b }: { a: string; b: string } = $props();

  // Shot cartridges publish lists of hull lengths rather than one case, so they are not compared.
  const records = $derived(
    Promise.all([load(a), load(b)]).then((pair) => {
      if (pair.some((record) => record.family === 'shotshell')) throw new Error('shotshell');
      return pair;
    })
  );
  const system = $derived(unitSystem());
</script>

<div data-ui="Compare">
  {#await records}
    <p class="loading" role="status">{t('site.loading')}</p>
  {:then [first, second]}
    {@const drawing = compareDrawing(first, second)}
    <PageHeader title={t('compare.title')} description={t('compare.lede')} backHref={href.cartridge(a)} backLabel={first.name} />
    {#if drawing}
      <figure class="mb-8">
        <svg
          role="img"
          aria-label={t('compare.profiles', { a: first.name, b: second.name })}
          viewBox={`0 0 ${drawing.width} ${drawing.height}`}
          width={drawing.width}
          style="max-width: 100%; height: auto"
          fill="none"
          stroke-width="1.5"
        >
          <path d={drawing.paths[0]} stroke="currentColor" />
          <path d={drawing.paths[1]} stroke="var(--chart-2)" stroke-dasharray="6 3" />
        </svg>
        <figcaption class="mt-2 text-sm">
          <span class="mr-4"><span aria-hidden="true">&mdash;</span> {first.name}</span>
          <span><span aria-hidden="true">- -</span> {second.name}</span>
        </figcaption>
      </figure>
    {:else}
      <p class="mb-8 text-sm text-muted-foreground">{t('compare.undrawn')}</p>
    {/if}
    <div class="overflow-x-auto">
      <table class="w-full text-sm">
        <caption class="mb-2 text-left font-semibold">{t('compare.dimensions', { unit: system === 'metric' ? 'mm' : 'in' })}</caption>
        <thead>
          <tr>
            <th scope="col" class="text-left">{t('compare.symbol')}</th>
            <th scope="col" class="text-right">{first.name}</th>
            <th scope="col" class="text-right">{second.name}</th>
            <th scope="col" class="text-right">{t('compare.difference')}</th>
          </tr>
        </thead>
        <tbody>
          {#each compareRows(first, second, system) as row (row.symbol)}
            <tr class="border-t">
              <th scope="row" class="text-left font-normal">{row.symbol}</th>
              <td class="num text-right">{row.a}</td>
              <td class="num text-right">{row.b}</td>
              <td class="num text-right">{row.difference}</td>
            </tr>
          {/each}
        </tbody>
      </table>
    </div>
    <p class="mt-2 text-xs text-muted-foreground">{t('compare.note')}</p>
  {:catch}
    <p class="status error" role="alert">{t('compare.unavailable')} <a href={href.list()}>{t('record.back')}</a></p>
  {/await}
</div>
