# Changelog

All notable changes to this project are recorded in this file.

The format follows [Keep a Changelog 1.1.0](https://keepachangelog.com/en/1.1.0/). Versions follow
[Semantic Versioning 2.0.0](https://semver.org/spec/v2.0.0.html), as defined in
[CONTRIBUTING.md](CONTRIBUTING.md#versioning).

Each release has a heading `## [X.Y.Z] - YYYY-MM-DD`, with entries grouped under `Added`,
`Changed`, `Deprecated`, `Removed`, `Fixed` and `Security`. Unreleased work is listed under
`## [Unreleased]`.

## [Unreleased]

### Added

- Compare view at `#/compare/<a>/<b>`: the case outlines of two cartridges overlaid at one scale, and a table of the dimensions either publishes. A `Compare with` select on each cartridge page opens it. English and German.
- GitHub Actions workflows for continuous integration, deployment of the site to GitHub Pages and
  tag-triggered releases.
- Dependabot configuration for npm and GitHub Actions updates.
- README, contribution guide and this changelog.
