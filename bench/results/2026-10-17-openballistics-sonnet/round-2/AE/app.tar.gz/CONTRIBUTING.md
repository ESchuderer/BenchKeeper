# Contributing

Set up, test and build the project as described in [README.md](README.md). Data contributions are described there too.

## Pull requests

- Branch from `main`. Keep a pull request to one change.
- `npm test` and `npm run build` pass, in `site/`. CI runs both.
- A change to setup or behavior updates the README in the same pull request.
- A user-visible change adds a line under `## [Unreleased]` in [CHANGELOG.md](CHANGELOG.md).

## Commit messages

Commits follow [Conventional Commits 1.0.0](https://www.conventionalcommits.org/en/v1.0.0/):

```
<type>(<optional scope>): <summary>
```

| Type | Use for |
|---|---|
| `feat` | A new feature or new records |
| `fix` | A bug fix or a corrected record value |
| `docs` | Documentation only |
| `refactor` | A change that keeps behavior |
| `test` | Tests only |
| `build` | Dependencies and the build |
| `ci` | Workflows |
| `chore` | Anything else |

Mark a breaking change with `!` after the type or a `BREAKING CHANGE:` footer. Dependabot commits use `build(deps)` and `ci(deps)`. The convention is not checked automatically. If a pull request is squash-merged, its title follows the same format.

## Versioning

The version lives in `site/package.json` (`version`) and the top entry of `site/package-lock.json`. Versions follow Semantic Versioning, applied to this project as:

- Major: a change to the record JSON format that breaks existing records, or removal or renaming of a record key.
- Minor: new records or new features.
- Patch: corrected values and bug fixes.

Releases are tagged `vX.Y.Z` on `main`.

## Releases

A maintainer makes a release with these steps:

1. In `CHANGELOG.md`, rename `## [Unreleased]` to `## [X.Y.Z] - YYYY-MM-DD` and add an empty `## [Unreleased]` above it.
2. Set the version: `cd site && npm version X.Y.Z --no-git-tag-version`. The first release, 0.1.0, is already set.
3. Commit both files on `main` as `chore(release): X.Y.Z`.
4. Tag and push: `git tag vX.Y.Z && git push origin vX.Y.Z`.

The tag triggers `.github/workflows/release.yml`. It stops unless the tag matches `site/package.json`, the tagged commit is on `main` and `CHANGELOG.md` has a section for the version. Then it runs the tests and the build and creates a GitHub release whose notes are that changelog section. A tag with a suffix such as `v1.0.0-rc.1` is marked as a pre-release.

## Repository settings

Set once by a maintainer, in the GitHub repository settings:

- Pages: set the source to GitHub Actions. The site is then served at `https://<owner>.github.io/<repository>/`.
- Branch protection on `main`: require the `Test and build` and `Lint workflows` checks.

## Dependency updates

Dependabot (`.github/dependabot.yml`) opens weekly pull requests for npm packages in `site/` and for GitHub Actions. Minor and patch npm updates arrive in one grouped pull request.
