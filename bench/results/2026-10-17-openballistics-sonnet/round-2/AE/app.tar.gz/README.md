# OpenBallistics

An open database of cartridges, bullets and targets, with a website to browse it.

- `data/`: the records, one JSON file each: `cartridges/` (by family), `bullets/`, `targets/`.
- `lib/`: TypeScript libraries shared by the site (geometry, 2D rendering, targets, user data).
- `site/`: the Svelte website. It is the only npm package in the repository, so every command below runs in `site/`.

## Requirements

- Node.js 22
- npm

## Install

```sh
cd site
npm ci
```

## Develop

```sh
npm run dev
```

This regenerates the data indexes, then starts the Vite dev server.

## Test

```sh
npm test
```

This regenerates the data indexes, then runs Vitest over `site/src/` and `lib/`. The tests also read the files in `data/`.

## Build

```sh
npm run build
npm run preview
```

`build` regenerates the data indexes, runs `svelte-check` and writes the site to `site/dist/`. `preview` serves that directory.

Other scripts:

| Command | Effect |
|---|---|
| `npm run index` | Build the search index from `data/` |
| `npm run fieldsets` | Build the field sets |
| `npm run prepare-data` | `index` and `fieldsets` |
| `npm run sample-bullets` | Regenerate the sample bullets in `data/bullets/` (see `data/bullets/README.md`) |

## Contribute data

1. Open an issue with the matching template (cartridge, bullet or site feedback) and name your source.
2. To fix a record, edit its JSON file in `data/`. Leave generated files alone: `site/src/lib/*.generated.json` is git-ignored.
3. Run `npm test` and `npm run build`. Both must pass.
4. Open a pull request. Say where each changed value comes from.

Adding a new kind of record, or a target face, can require code changes. Open an issue first.

Code contributions, commit messages, versioning and releases are covered in [CONTRIBUTING.md](CONTRIBUTING.md). Changes are listed in [CHANGELOG.md](CHANGELOG.md).

## Continuous integration and deployment

- Every pull request runs `npm test` and `npm run build` and lints the workflow files (`.github/workflows/ci.yml`).
- A push to `main` deploys the site to GitHub Pages (`.github/workflows/pages.yml`).

## License

MIT, see [LICENSE](LICENSE). Third-party software used by the site is listed in [THIRD-PARTY.md](THIRD-PARTY.md).
