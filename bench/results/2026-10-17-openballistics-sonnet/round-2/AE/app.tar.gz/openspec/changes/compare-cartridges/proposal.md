## Why

The catalogue shows one cartridge per page. Comparing two means opening both and reading the figures side by side by hand.

## What Changes

- New route `#/compare/<a>/<b>` that overlays the outer case profiles of two cartridges and tables the dimensions either publishes.
- The cartridge detail page gets a `Compare with` select and a `Compare` button.
- English and German texts.

Out of scope: shot cartridges, chambers, bullets, more than two cartridges.

## Impact

- `site/src/lib/router.ts`, `site/src/lib/metadata.ts`, `site/src/App.svelte`, `site/src/routes/Cartridge.svelte`, `site/src/lib/i18n.svelte.ts`
- New: `site/src/lib/compare.ts`, `site/src/routes/Compare.svelte`
- `CHANGELOG.md`
