## ADDED Requirements

### Requirement: Compare route
The site SHALL open `#/compare/<a>/<b>` directly and after a reload, where `<a>` and `<b>` are cartridge keys as used in `#/c/<key>`.

#### Scenario: Direct link
- **WHEN** the URL is `#/compare/308_win/300_win_mag`
- **THEN** the compare view for those two cartridges is shown

### Requirement: Overlaid profiles
The view SHALL draw the outer profiles of both cases, as `caseOuterProfile` computes them, in one SVG with role `img` and name `Profiles of <name A> and <name B>`, at one scale, on one axis, with the head faces at the same point. Each outline is one path element. Shot cartridges are not compared.

#### Scenario: Two outlines
- **WHEN** both cartridges are metallic
- **THEN** the SVG holds one path per cartridge

### Requirement: Dimension table
The view SHALL list one row per dimension symbol published by at least one of the two cartridges. A dimension is a number in the record's `cartridge` part, in millimetres (no entry in `FIELD_UNITS`), and not a tolerance. The table is named `Dimensions (mm)` or `Dimensions (in)`. Columns: `Symbol`, name of A, name of B, `Difference` (B minus A). The cells of the two cartridge columns and of `Difference`, headers included, are right-aligned.

#### Scenario: Metric
- **WHEN** the unit preference is metric
- **THEN** values and differences are written with `formatValue`, unrounded

#### Scenario: Imperial
- **WHEN** the unit preference is imperial
- **THEN** values and differences are converted to inches with `displayNumber`

#### Scenario: One cartridge publishes a dimension
- **WHEN** only one cartridge publishes a dimension, such as `delta L` for `308_win` against `300_win_mag`
- **THEN** the row is listed, and the cell of the other cartridge and the `Difference` cell are empty

### Requirement: Entry point
The cartridge detail page SHALL have a select `Compare with` listing the other cartridges by name and a button `Compare` that opens `#/compare/<this key>/<chosen key>`.
