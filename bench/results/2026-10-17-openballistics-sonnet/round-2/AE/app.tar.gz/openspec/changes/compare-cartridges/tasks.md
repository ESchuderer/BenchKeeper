## 1. Logic
- [x] 1.1 `compare.ts`: dimension rows, unit formatting, outlines (tests first)
- [x] 1.2 Route `compare` in `router.ts`, with tests

## 2. UI
- [x] 2.1 `Compare.svelte` and its chunk in `App.svelte`, page metadata, navigation highlight
- [x] 2.2 `Compare with` select and `Compare` button on the detail page
- [x] 2.3 English and German texts

## 3. Docs and checks
- [x] 3.1 CHANGELOG (the README does not describe site routes)
- [x] 3.2 `npm test`, `npm run build`, browser check
