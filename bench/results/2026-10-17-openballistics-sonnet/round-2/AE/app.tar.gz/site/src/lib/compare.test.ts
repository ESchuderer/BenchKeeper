import { readFileSync } from 'node:fs';
import { join } from 'node:path';
import { describe, expect, it } from 'vitest';
import type { Record_ } from '@lib/core';
import { CARTRIDGES } from '@lib/testing/fixtures';
import { formatDimension, outlines, dimensionRows } from './compare';

const record = (family: string, key: string) =>
  JSON.parse(readFileSync(join(CARTRIDGES, family, `${key}.json`), 'utf8')) as Record_;
const a = record('rimless', '308_win');
const b = record('belted', '300_win_mag');

describe('dimensionRows', () => {
  const rows = dimensionRows(a, b);
  const symbols = rows.map((row) => row.symbol);

  it('lists published millimetre dimensions with the sheet symbols', () => {
    expect(symbols).toContain('e min');
    expect(symbols).toContain('L3');
    expect(rows.find((row) => row.symbol === 'L1')).toMatchObject({ a: 39.62, b: (b.cartridge.lengths as Record<string, number>).L1 });
  });

  it('leaves out tolerances, angles, pressures and the chamber', () => {
    for (const symbol of ['L1Tol', 'δ', 'β', 'α', 'Pmax', 'PK', 'M', 'EE', 'D']) expect(symbols).not.toContain(symbol);
  });

  it('lists a symbol once, with no value where a cartridge does not publish it', () => {
    expect(new Set(symbols).size).toBe(symbols.length);
    const sparse = { ...b, cartridge: { lengths: { L1: 40 } } } as Record_;
    const sparseRows = dimensionRows(a, sparse);
    expect(sparseRows.find((row) => row.symbol === 'L1')).toEqual({ symbol: 'L1', a: 39.62, b: 40 });
    expect(sparseRows.find((row) => row.symbol === 'L3')).toEqual({ symbol: 'L3', a: expect.any(Number) });
  });

  it('lists the dimensions only one of the two publishes', () => {
    expect(rows.find((row) => row.symbol === 'delta L')).toMatchObject({ a: expect.any(Number) });
    expect(rows.find((row) => row.symbol === 'delta L')?.b).toBeUndefined();
    expect(rows.find((row) => row.symbol === 'R3')?.a).toBeUndefined();
    expect(rows.find((row) => row.symbol === 'R3')?.b).toEqual(expect.any(Number));
  });
});

describe('formatDimension', () => {
  const row = { symbol: 'R1', a: 12.01, b: 13.03 };
  it('writes metric values unrounded with formatValue', () => {
    expect(formatDimension(row, 'metric')).toEqual({ a: '12.01', b: '13.03', difference: String(13.03 - 12.01) });
  });
  it('leaves a cell and the difference empty where a cartridge does not publish the dimension', () => {
    expect(formatDimension({ symbol: 'R3', b: 5 }, 'metric')).toEqual({ a: '', b: '5', difference: '' });
    expect(formatDimension({ symbol: 'delta L', a: 5 }, 'imperial')).toMatchObject({ b: '', difference: '' });
  });
  it('converts imperial values and the difference to inches', () => {
    expect(formatDimension({ symbol: 'L1', a: 25.4, b: 50.8 }, 'imperial')).toEqual({ a: '1', b: '2', difference: '1' });
    expect(formatDimension({ symbol: 'L1', a: 50.8, b: 25.4 }, 'imperial').difference).toBe('-1');
  });
});

describe('outlines', () => {
  it('draws both cases at one scale, head faces level', () => {
    const drawn = outlines(a, b)!;
    expect(drawn.a).toMatch(/^M/);
    expect(drawn.b).toMatch(/^M/);
    const lowest = (d: string) => Math.max(...[...d.matchAll(/,(-?[\d.]+)/g)].map((m) => Number(m[1])));
    expect(lowest(drawn.a)).toBeCloseTo(lowest(drawn.b), 6);
  });
  it('is null for a shot cartridge', () => {
    expect(outlines(a, record('shotshell', '12'))).toBeNull();
  });
});
