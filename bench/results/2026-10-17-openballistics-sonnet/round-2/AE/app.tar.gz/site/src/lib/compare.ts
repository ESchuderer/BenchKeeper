/** What the compare view shows: the dimensions either cartridge publishes, and their case outlines overlaid. */

import { FIELD_LABELS, FIELD_UNITS, GROUP_ORDER, PX_PER_MM, formatValue, orderedFields } from '@lib/core';
import type { Group, Record_ } from '@lib/core';
import { fullSectionPath, viewportFor } from '@lib/geom';
import { adaptMetallic, caseOuterProfile, type CartridgeRecord } from '@lib/shapes2d';
import { displayNumber, type UnitSystem } from './units';

export interface DimensionRow {
  symbol: string;
  a?: number;
  b?: number;
}

const groupsOf = (a: Record_, b: Record_): string[] => {
  const known = GROUP_ORDER.cartridge;
  const rank = (name: string) => (known.includes(name) ? known.indexOf(name) : known.length);
  return [...new Set([...Object.keys(a.cartridge), ...Object.keys(b.cartridge)])].sort((x, y) => rank(x) - rank(y));
};

/** Millimetre dimensions of the `cartridge` part that either record publishes, in the detail page's order. */
export function dimensionRows(a: Record_, b: Record_): DimensionRow[] {
  const rows: DimensionRow[] = [];
  const seen = new Set<string>();
  for (const group of groupsOf(a, b)) {
    const left = a.cartridge[group];
    const right = b.cartridge[group];
    if (Array.isArray(left) || Array.isArray(right)) continue;
    for (const field of orderedFields('cartridge', group, { ...right, ...left })) {
      const symbol = FIELD_LABELS[field] ?? field;
      const [x, y] = [(left as Group | undefined)?.[field], (right as Group | undefined)?.[field]];
      if (field.endsWith('Tol') || Object.hasOwn(FIELD_UNITS, field) || seen.has(symbol)) continue;
      const [valueA, valueB] = [x, y].map((value) => (typeof value === 'number' ? value : undefined));
      if (valueA === undefined && valueB === undefined) continue;
      seen.add(symbol);
      rows.push({ symbol, a: valueA, b: valueB });
    }
  }
  return rows;
}

/** The cells of one row: metric as `formatValue` writes them, imperial as inches. Difference is B minus A. Empty where a cartridge does not publish the dimension. */
export function formatDimension(row: DimensionRow, system: UnitSystem): { a: string; b: string; difference: string } {
  const write = (value?: number) => (value === undefined ? '' : system === 'metric' ? formatValue(value) ?? '' : displayNumber(value, 'in'));
  const both = row.a !== undefined && row.b !== undefined;
  return { a: write(row.a), b: write(row.b), difference: both ? write(row.b! - row.a!) : '' };
}

/**
 * The two outer case profiles as closed full-section paths in one viewport, so both share one
 * scale and one axis and sit with their head faces level. `null` for a shot cartridge, or where
 * a record lacks the dimensions to draw its case.
 */
export function outlines(a: Record_, b: Record_): { a: string; b: string; width: number; height: number } | null {
  try {
    if (a.family === 'shotshell' || b.family === 'shotshell') return null;
    const [pa, pb] = [a, b].map((record) => caseOuterProfile(adaptMetallic(record as unknown as CartridgeRecord)));
    const view = viewportFor([pa!, pb!], { scale: PX_PER_MM, marginMm: 2 });
    return { a: fullSectionPath(pa!, view), b: fullSectionPath(pb!, view), width: view.width, height: view.height };
  } catch {
    return null;
  }
}
