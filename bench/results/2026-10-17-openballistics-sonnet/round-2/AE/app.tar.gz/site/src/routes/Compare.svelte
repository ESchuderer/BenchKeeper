<script lang="ts">
  import PageHeader from '../components/PageHeader.svelte';
  import { byKey, load } from '../lib/data';
  import { formatDimension, outlines, dimensionRows } from '../lib/compare';
  import { href } from '../lib/router';
  import { t } from '../lib/i18n.svelte';
  import { unitSystem } from '../lib/units.svelte';

  let { a, b }: { a: string; b: string } = $props();

  const missing = $derived([a, b].find((key) => !byKey(key)));
  const records = $derived(missing ? null : Promise.all([load(a), load(b)]));
  const imperial = $derived(unitSystem() === 'imperial');
</script>

<div data-ui="Compare" class="contents">
  {#if missing}
    <p class="status error">{t('compare.unknown', { key: missing })} <a href={href.list()}>{t('record.back')}</a></p>
  {:else}
    {#await records}
      <p class="loading" role="status">{t('site.loading')}</p>
    {:then pair}
      {@const [first, second] = pair!}
      {@const drawn = outlines(first, second)}
      {@const rows = dimensionRows(first, second)}
      <PageHeader
        title={t('compare.heading', { a: first.name, b: second.name })}
        description={t('compare.differenceNote', { a: first.name, b: second.name })}
        backHref={href.cartridge(a)}
        backLabel={first.name}
      />

      {#if drawn}
        <figure class="m-0 mb-8 flex flex-col items-center gap-3 rounded-lg border border-[var(--rule)] bg-[var(--surface)] p-4">
          <svg
            role="img"
            aria-label={t('compare.profiles', { a: first.name, b: second.name })}
            viewBox={`0 0 ${drawn.width} ${drawn.height}`}
            width={drawn.width}
            height={drawn.height}
            class="h-auto max-h-[70vh] max-w-full"
            fill="none"
          >
            <path d={drawn.a} stroke="var(--ink)" stroke-width="1.5" vector-effect="non-scaling-stroke" />
            <path d={drawn.b} stroke="var(--link, #1d4ed8)" stroke-width="1.5" stroke-dasharray="6 4" vector-effect="non-scaling-stroke" />
          </svg>
          <figcaption class="flex flex-wrap justify-center gap-x-6 gap-y-1 text-sm">
            <span class="inline-flex items-center gap-2"><span class="inline-block w-6 border-t-2 border-solid" style="border-color: var(--ink)"></span>{first.name}</span>
            <span class="inline-flex items-center gap-2"><span class="inline-block w-6 border-t-2 border-dashed" style="border-color: var(--link, #1d4ed8)"></span>{second.name}</span>
          </figcaption>
        </figure>
      {:else}
        <p class="status">{t('compare.noProfile')}</p>
      {/if}

      {#if rows.length}
        <div class="overflow-x-auto">
          <table class="w-full border-collapse text-sm">
            <caption class="pb-2 text-left font-semibold">{imperial ? t('compare.dimensionsIn') : t('compare.dimensionsMm')}</caption>
            <thead>
              <tr class="border-b border-[var(--rule)] text-left">
                <th scope="col" class="py-2 pr-4">{t('compare.symbol')}</th>
                <th scope="col" class="py-2 pr-4 text-right">{first.name}</th>
                <th scope="col" class="py-2 pr-4 text-right">{second.name}</th>
                <th scope="col" class="py-2 text-right">{t('compare.difference')}</th>
              </tr>
            </thead>
            <tbody>
              {#each rows as row (row.symbol)}
                {@const cells = formatDimension(row, imperial ? 'imperial' : 'metric')}
                <tr class="border-b border-[var(--rule)]">
                  <td class="py-1.5 pr-4">{row.symbol}</td>
                  <td class="num py-1.5 pr-4 text-right">{cells.a}</td>
                  <td class="num py-1.5 pr-4 text-right">{cells.b}</td>
                  <td class="num py-1.5 text-right">{cells.difference}</td>
                </tr>
              {/each}
            </tbody>
          </table>
        </div>
      {:else}
        <p class="status">{t('compare.noShared')}</p>
      {/if}

      <p class="mt-8"><a href={href.list()}>{t('record.back')}</a></p>
    {:catch error}
      <p class="status error">{error.message} <a href={href.list()}>{t('record.back')}</a></p>
    {/await}
  {/if}
</div>
