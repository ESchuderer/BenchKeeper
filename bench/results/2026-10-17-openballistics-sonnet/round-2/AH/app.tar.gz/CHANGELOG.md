# Changelog

All notable changes to this project are recorded in this file. The format follows
[Keep a Changelog 1.1.0](https://keepachangelog.com/en/1.1.0/) and the versions follow
[Semantic Versioning 2.0.0](https://semver.org/spec/v2.0.0.html), as defined in
[CONTRIBUTING.md](CONTRIBUTING.md#versioning).

Each release has a heading `## [X.Y.Z] - YYYY-MM-DD`, with entries under `Added`, `Changed`,
`Deprecated`, `Removed`, `Fixed` or `Security`. The release workflow publishes the text under that
heading as the GitHub release notes.

## [Unreleased]

### Added

- Continuous integration on pull requests, deployment of the site to GitHub Pages, tag-triggered
  releases and Dependabot updates.
- README and CONTRIBUTING with setup, contribution, commit and release rules.
- Compare view at `#/compare/<a>/<b>`: both case outlines overlaid at one scale, and a table of the
  dimensions either cartridge publishes with their difference (empty where only one does). Opened
  from the `Compare with` select on a cartridge page. English and German texts.
