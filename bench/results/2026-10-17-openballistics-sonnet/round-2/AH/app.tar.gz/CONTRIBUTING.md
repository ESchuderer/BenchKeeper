# Contributing

Setup, commands and the data layout are in [README.md](README.md). This file covers how changes are
submitted, how commits are written, and how releases are made.

## Pull requests

1. Fork the repository and create a branch from `main`.
2. Make the change. Run `npm test` and `npm run build` in `site/`. CI runs the same two commands.
3. Open a pull request against `main`. Describe what changed and, for data, where the values come from.

Maintainers squash-merge, so the pull request title becomes the commit on `main`. CI fails a pull
request whose title does not follow the convention below.

## Commit convention

[Conventional Commits 1.0.0](https://www.conventionalcommits.org/en/v1.0.0/):

```
<type>(<optional scope>): <summary>
```

- Types: `feat`, `fix`, `data`, `docs`, `style`, `refactor`, `perf`, `test`, `build`, `ci`,
  `chore`, `revert`.
- `data` is used for changes under `data/` (new or corrected records).
- Summary: imperative mood, lower case, no trailing full stop.
- A breaking change has `!` after the type or scope (`feat!: ...`), or a `BREAKING CHANGE:` footer.
- Reference an issue in the footer: `Refs #123`.

Examples: `data(rimless): correct case length of 6.5 Creedmoor`, `fix(site): keep the filter on reload`.

## Versioning

The version follows [Semantic Versioning](https://semver.org/spec/v2.0.0.html) and is kept in one
place: the `version` field of `site/package.json` (`site/package-lock.json` is updated with it).
Releases are tags named `v<version>`.

| Bump  | When                                                                                             |
| ----- | ------------------------------------------------------------------------------------------------ |
| MAJOR | A breaking change: record fields removed or renamed, record keys or URLs changed, a feature removed |
| MINOR | New records, new site features, or new record fields that do not break existing ones             |
| PATCH | Corrected record values and bug fixes                                                            |

While the version is `0.x`, a MINOR bump may also contain breaking changes.

## Changelog

`CHANGELOG.md` follows [Keep a Changelog 1.1.0](https://keepachangelog.com/en/1.1.0/). A pull
request that changes data or site behaviour adds a line under `## [Unreleased]`, in the matching
section (`Added`, `Changed`, `Deprecated`, `Removed`, `Fixed`, `Security`). Pull requests that only
touch CI, docs or dependencies need no entry.

## Making a release (maintainers)

1. Create a branch `chore/release-<version>` from `main`.
2. In `site/`, set the version: `npm version <version> --no-git-tag-version`.
3. In `CHANGELOG.md`, rename `## [Unreleased]` to `## [<version>] - <YYYY-MM-DD>` and add an empty
   `## [Unreleased]` above it.
4. Commit as `chore(release): v<version>`, open a pull request and merge it.
5. On `main`, tag the merge commit and push the tag: `git tag v<version>` then
   `git push origin v<version>`.

The tag starts `.github/workflows/release.yml`. It fails unless the tag commit is on `main`, the tag
matches `site/package.json`, and `CHANGELOG.md` has entries for that version. It then runs the tests
and the build, and creates the GitHub release with the changelog text as notes. A version with a
hyphen (`1.0.0-rc.1`) is published as a pre-release.

## Deployment

`.github/workflows/pages.yml` builds the site and deploys it to GitHub Pages on every push to
`main`. One-time setting for the repository owner: Settings, Pages, Source: GitHub Actions. The
base path is taken from the Pages configuration and passed to Vite as `PAGES_BASE`.

## Dependency updates

Dependabot (`.github/dependabot.yml`) opens weekly pull requests for npm packages in `site/` and
for GitHub Actions. Minor and patch updates are grouped, major updates are separate. Its commit
messages use the `build(deps)` and `ci(deps)` types.
