# OpenBallistics

An open database of cartridges, bullets and targets, stored as JSON records, with a website to
browse and draw them.

## Layout

| Path    | Content                                                                              |
| ------- | ------------------------------------------------------------------------------------ |
| `data/` | The records: `cartridges/<family>/`, `bullets/` and `targets/`, one JSON file per record |
| `lib/`  | Shared TypeScript libraries (geometry, rendering, measurement, targets, user data)   |
| `site/` | The Svelte website. It has the `package.json`, and all npm commands run from here    |

## Requirements

Node.js 22 and npm.

## Install

```sh
cd site
npm ci
```

## Develop

```sh
npm run dev
```

Starts the Vite dev server. It first regenerates the search index and field sets from `data/`.

Other scripts, all from `site/`:

| Command                  | Does                                                                 |
| ------------------------ | -------------------------------------------------------------------- |
| `npm run index`          | Builds the search index from `data/`                                 |
| `npm run fieldsets`      | Builds the field sets from `data/`                                   |
| `npm run prepare-data`   | Runs `index` and `fieldsets`                                         |
| `npm run sample-bullets` | Regenerates the synthetic sample bullets (see `data/bullets/README.md`) |
| `npm run preview`        | Serves the production build from `dist/`                             |

The generated index files are git-ignored. Do not commit them.

## Test

```sh
npm test
```

Runs Vitest over `site/src` and `lib/`. It regenerates the index first.

## Build

```sh
npm run build
```

Regenerates the index, type-checks with `svelte-check`, and writes the site to `site/dist/`.
Set `PAGES_BASE` (for example `PAGES_BASE=/OpenBallistics/ npm run build`) to build for a Pages
project path. The default is `/`.

## Contribute data

- A wrong or missing value: open an issue with the matching template (cartridge, bullet or site
  feedback) and name the source you read the correct value from.
- A fix or a new record: edit or add the JSON file in `data/` and open a pull request. For a new
  cartridge, copy a record from the same family under `data/cartridges/` and change its values.
  State the source of every value in the pull request description.
- Before opening the pull request, run `npm test` and `npm run build` in `site/`.
- Add a line under `## [Unreleased]` in `CHANGELOG.md`.

Commit convention, pull request rules and releases: [CONTRIBUTING.md](CONTRIBUTING.md).
Changes are recorded in [CHANGELOG.md](CHANGELOG.md).

## License

[MIT](LICENSE), Copyright (c) 2026 PiMetry. Third-party notices are in
[THIRD-PARTY.md](THIRD-PARTY.md).
