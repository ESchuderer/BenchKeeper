import { readFileSync } from 'node:fs';
import { describe, expect, it } from 'vitest';
import type { Record_ } from '@lib/core';
import { CARTRIDGES } from '@lib/testing/fixtures';
import { compareRows, differenceText, lengthText, outlines } from './compare';

const record = (family: string, key: string) =>
  JSON.parse(readFileSync(`${CARTRIDGES}/${family}/${key}.json`, 'utf8')) as Record_;
const a = record('rimless', '308_win');
const b = record('belted', '300_win_mag');

describe('compare rows', () => {
  const rows = compareRows(a, b);
  const symbols = rows.map((row) => row.symbol);
  it('lists every millimetre dimension either publishes, labelled as the detail page does', () => {
    expect(symbols).toContain('e min');
    expect(symbols).toContain('L1');
    expect(rows.find((row) => row.symbol === 'e min')).toEqual({ symbol: 'e min', a: 1.4, b: 0.94 });
  });
  it('leaves a dimension only one publishes empty on the other side', () => {
    const deltaL = rows.find((row) => row.symbol === 'delta L')!;
    const r3 = rows.find((row) => row.symbol === 'R3')!;
    expect(deltaL.a).toEqual(expect.any(Number));
    expect(deltaL.b).toBeNull();
    expect(r3.a).toBeNull();
    expect(r3.b).toEqual(expect.any(Number));
  });
  it('leaves out tolerances, other units and angles', () => {
    for (const out of ['L1Tol', 'ETol', 'δ', 'β', 'α', 'Pmax', 'M', 'EE']) expect(symbols).not.toContain(out);
  });
  it('writes metric as published and imperial in inches', () => {
    expect(lengthText(39.62, 'metric')).toBe('39.62');
    expect(lengthText(25.4, 'imperial')).toBe('1');
  });
  it('writes the difference as B minus A without float noise', () => {
    expect(differenceText(0.1, 0.4, 'metric')).toBe('0.3');
    expect(differenceText(1.4, 0.94, 'metric')).toBe('-0.46');
    expect(differenceText(25.4, 50.8, 'imperial')).toBe('1');
    expect(differenceText(3, 3, 'metric')).toBe('0');
  });
  it('writes nothing for a dimension a cartridge does not publish', () => {
    expect(lengthText(null, 'metric')).toBe('');
    expect(differenceText(null, 3, 'imperial')).toBe('');
    expect(differenceText(3, null, 'metric')).toBe('');
  });
});

describe('outlines', () => {
  it('draws both cases on one viewport with their head faces together', () => {
    const drawn = outlines(a, b)!;
    const first = (d: string) => Number(d.match(/^M([\d.]+)/)![1]);
    // Landscape: x runs along the case, so the head faces share the first point's x.
    expect(first(drawn.a)).toBeCloseTo(first(drawn.b), 6);
    expect(drawn.a).not.toBe(drawn.b);
    expect(drawn.width).toBeGreaterThan(0);
  });
  it('has no drawing for a shot cartridge', () => {
    expect(outlines(a, record('shotshell', '12'))).toBeNull();
  });
});
