/** What the compare view shows of two records: the dimensions either publishes, and the two outlines. */

import { FIELD_LABELS, FIELD_UNITS, GROUP_ORDER, formatValue, orderedFields, type Record_ } from '@lib/core';
import { fullSectionPath, viewportFor, type Viewport } from '@lib/geom';
import { adaptMetallic, caseOuterProfile, type CartridgeRecord } from '@lib/shapes2d';
import { displayNumber, type UnitSystem } from './units';

export interface CompareRow {
  symbol: string;
  /** Null where that cartridge does not publish the dimension. */
  a: number | null;
  b: number | null;
}

/** The millimetre dimensions of a record's cartridge part, by field name, in the detail page's order. */
function dimensionsOf(record: Record_): Map<string, number> {
  const found = new Map<string, number>();
  const groups = [...GROUP_ORDER.cartridge, ...Object.keys(record.cartridge).filter((g) => !GROUP_ORDER.cartridge.includes(g))];
  for (const name of groups) {
    const group = record.cartridge[name];
    if (!group || Array.isArray(group)) continue;
    for (const field of orderedFields('cartridge', name, group)) {
      const value = group[field];
      if (typeof value === 'number' && Number.isFinite(value) && !Object.hasOwn(FIELD_UNITS, field) && !found.has(field)) {
        found.set(field, value);
      }
    }
  }
  return found;
}

/** One row per dimension either record publishes: A's in the detail page's order, then those only B publishes. */
export function compareRows(a: Record_, b: Record_): CompareRow[] {
  const first = dimensionsOf(a);
  const second = dimensionsOf(b);
  return [...new Set([...first.keys(), ...second.keys()])].map((field) => ({
    symbol: FIELD_LABELS[field] ?? field,
    a: first.get(field) ?? null,
    b: second.get(field) ?? null,
  }));
}

/** A length as the reader's unit preference writes it: the published figure in mm, converted in inches. */
export const lengthText = (mm: number | null, system: UnitSystem): string =>
  mm === null ? '' : system === 'metric' ? formatValue(mm)! : displayNumber(mm, 'in');

/** B minus A. Metric goes through `displayNumber` as well, which drops the float noise of the subtraction. */
export const differenceText = (a: number | null, b: number | null, system: UnitSystem): string =>
  a === null || b === null ? '' : displayNumber(b - a, system === 'metric' ? 'mm' : 'in');

export interface Outlines {
  width: number;
  height: number;
  a: string;
  b: string;
}

/** Both case outlines as closed paths on one viewport: one scale, one centre line, head faces together. */
export function outlines(a: Record_, b: Record_): Outlines | null {
  if (a.family === 'shotshell' || b.family === 'shotshell') return null;
  try {
    const profiles = [a, b].map((record) => caseOuterProfile(adaptMetallic(record as unknown as CartridgeRecord)));
    const view: Viewport = viewportFor(profiles, { frame: 'landscape', marginMm: 2 });
    const [pa, pb] = profiles.map((profile) => fullSectionPath(profile, view)) as [string, string];
    return { width: view.width, height: view.height, a: pa, b: pb };
  } catch {
    // A record too sparse to draw: the table still compares.
    return null;
  }
}
