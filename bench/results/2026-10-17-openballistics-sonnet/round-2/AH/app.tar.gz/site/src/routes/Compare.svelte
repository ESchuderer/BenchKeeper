<script lang="ts">
  import { load } from '../lib/data';
  import { compareRows, differenceText, lengthText, outlines } from '../lib/compare';
  import { href } from '../lib/router';
  import { t } from '../lib/i18n.svelte';
  import { unitSystem } from '../lib/units.svelte';

  interface Props {
    a: string;
    b: string;
  }
  let { a, b }: Props = $props();

  const records = $derived(Promise.all([load(a), load(b)]));
  const system = $derived(unitSystem());
</script>

<div data-ui="Compare" class="contents">
  <h1>{t('compare.title')}</h1>
  {#await records}
    <p role="status" class="status">{t('site.loading')}</p>
  {:then [first, second]}
    {@const drawn = outlines(first, second)}
    {@const rows = compareRows(first, second)}
    {#if drawn}
      <svg
        role="img"
        aria-label={t('compare.profiles', { a: first.name, b: second.name })}
        viewBox={`0 0 ${drawn.width} ${drawn.height}`}
        class="profiles"
      >
        <path d={drawn.a} fill="none" stroke="var(--ink)" stroke-width="1.5" vector-effect="non-scaling-stroke" />
        <path d={drawn.b} fill="none" stroke="var(--link)" stroke-width="1.5" stroke-dasharray="6 3" vector-effect="non-scaling-stroke" />
      </svg>
      <p class="legend" aria-hidden="true">
        <span class="a">{first.name}</span>
        <span class="b">{second.name}</span>
      </p>
    {:else}
      <p class="status">{t('compare.unavailable')}</p>
    {/if}
    {#if rows.length}
      <table>
        <caption>{t('compare.dimensions', { unit: system === 'metric' ? 'mm' : 'in' })}</caption>
        <thead>
          <tr>
            <th scope="col">{t('compare.symbol')}</th>
            <th scope="col"><a href={href.cartridge(a)}>{first.name}</a></th>
            <th scope="col"><a href={href.cartridge(b)}>{second.name}</a></th>
            <th scope="col">{t('compare.difference')}</th>
          </tr>
        </thead>
        <tbody>
          {#each rows as row (row.symbol)}
            <tr>
              <th scope="row" class="num">{row.symbol}</th>
              <td class="num">{lengthText(row.a, system)}</td>
              <td class="num">{lengthText(row.b, system)}</td>
              <td class="num">{differenceText(row.a, row.b, system)}</td>
            </tr>
          {/each}
        </tbody>
      </table>
    {:else}
      <p class="status">{t('compare.none')}</p>
    {/if}
  {:catch}
    <p role="alert" class="status">{t('compare.error')}</p>
  {/await}
</div>

<style>
  @layer legacy {
    h1 { margin-bottom: 1rem; }
    .status { color: var(--muted-foreground); padding: 1rem 0; }
    .profiles { width: 100%; max-height: 24rem; margin-bottom: .5rem; }
    .legend { display: flex; gap: 1.5rem; font-size: var(--step-0); margin-bottom: 1.5rem; }
    .legend .a { border-bottom: 2px solid var(--ink); }
    .legend .b { border-bottom: 2px dashed var(--link); }
    table { border-collapse: collapse; width: 100%; max-width: 48rem; }
    caption { text-align: left; font-weight: 600; padding-bottom: .5rem; }
    th, td { padding: .3rem .75rem; border-bottom: 1px solid var(--rule); text-align: right; }
    thead th:first-child, tbody th { text-align: left; }
  }
</style>
