# Compare two cartridges

Status: ready-for-agent

Route `#/compare/<a>/<b>` (cartridge keys). One SVG with both case outer profiles (`caseOuterProfile`) at one scale on one axis, head faces aligned, one path per outline, role `img`, name `Profiles of <A> and <B>`. One table `Dimensions (mm|in)`: a row per mm symbol in the `cartridge` part published as a number by either (no `FIELD_UNITS` entry, no `Tol`); a cell for a cartridge that does not publish it, and the `Difference` cell, are empty, columns `Symbol`, A, B, `Difference` (B minus A). Units follow `Default units`. Detail page: select `Compare with` and button `Compare`. English and German texts.

Out of scope: shot cartridges (message instead of a drawing).
Decision: metric differences go through `displayNumber(x, 'mm')` (12 significant digits) so binary noise such as `15.369999999999997` is not shown. Values use `formatValue`.
