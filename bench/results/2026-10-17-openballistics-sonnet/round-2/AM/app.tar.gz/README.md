# OpenBallistics

An open database of cartridges, bullets and targets, with the code that draws and browses it.

- `data/`: the records, one JSON file each. `cartridges/` (grouped by family), `bullets/`, `targets/`.
- `lib/`: TypeScript libraries shared by the site: geometry, drawing, targets, user data.
- `site/`: the Svelte website, built with Vite. All npm commands run from this directory.
- `fixtures/`: reference drawings and profiles the tests compare against.

## Requirements

Node.js 22 and npm. CI uses Node 22.

## Install

```sh
cd site
npm ci
```

## Develop

```sh
npm run dev       # builds the search indexes, then starts the Vite dev server
npm run preview   # serves the output of npm run build
```

Scripts that `dev`, `test` and `build` call, which can also be run alone:

| Command | Does |
|---|---|
| `npm run index` | builds the search index and copies flags from the records in `data/` |
| `npm run fieldsets` | builds the field sets |
| `npm run prepare-data` | runs `index`, then `fieldsets` |
| `npm run sample-bullets` | regenerates the synthetic sample bullets (see `data/bullets/README.md`) |

## Test

```sh
npm test
```

Runs Vitest over `site/src/` and `lib/`. It runs `prepare-data` first.

## Build

```sh
npm run build
```

Runs `prepare-data`, `svelte-check` (the type check) and `vite build`. The output is `site/dist/`. The repository has no separate lint script.

To build for a project page on GitHub Pages, set the base path: `PAGES_BASE=/OpenBallistics/ npm run build`.

## Contribute data

- Each record is one JSON file under `data/`: `cartridges/<family>/<key>.json`, `bullets/<key>.json` or `targets/<id>.json`. The file name equals the record's `key` or `id`.
- Name the source of every figure you add or change.
- Run `npm test` and `npm run build` in `site/`.
- Open a pull request with a Conventional Commits title, for example `fix(data): correct 308 Win. case length`.

[CONTRIBUTING.md](CONTRIBUTING.md) has the field references, what the checks cover, the commit convention and the pull request rules. To report a wrong value without a pull request, use an [issue template](.github/ISSUE_TEMPLATE).

## Releases

The version is in `version.txt`, mirrored into `site/package.json` and `site/package-lock.json`. Releases are made by release-please from the commit history. Release notes are in [CHANGELOG.md](CHANGELOG.md). Details are in [CONTRIBUTING.md](CONTRIBUTING.md#releases).

## License

[MIT](LICENSE), Copyright (c) 2026 PiMetry. Third-party software the project uses or redistributes is listed in [THIRD-PARTY.md](THIRD-PARTY.md).
