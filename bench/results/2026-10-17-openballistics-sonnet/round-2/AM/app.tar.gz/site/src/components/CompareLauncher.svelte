<script lang="ts">
  import { Button } from '$lib/components/ui/button/index.js';
  import { Label } from '$lib/components/ui/label/index.js';
  import { NativeSelect } from '$lib/components/ui/native-select/index.js';
  import { entries } from '../lib/data';
  import { t } from '../lib/i18n.svelte';
  import { href } from '../lib/router';

  let { from }: { from: string } = $props();
  const id = $props.id();
  const others = $derived(entries.filter((entry) => entry.key !== from));
  // Unset until the reader picks: the select then shows, and the button opens, the first one.
  let picked = $state<string>();
</script>

<div class="flex flex-wrap items-end gap-3 py-4 print:hidden">
  <div class="grid gap-1.5">
    <Label for={`${id}-with`}>{t('compare.with')}</Label>
    <NativeSelect id={`${id}-with`} bind:value={picked} class="min-w-56">
      {#each others as entry (entry.key)}<option value={entry.key}>{entry.name}</option>{/each}
    </NativeSelect>
  </div>
  <Button type="button" variant="outline" onclick={() => { location.hash = href.compare(from, picked ?? others[0]!.key); }}>{t('compare.action')}</Button>
</div>
