import { readFileSync } from 'node:fs';
import { join } from 'node:path';
import { describe, expect, it } from 'vitest';
import { CARTRIDGES } from '@lib/testing/fixtures';
import type { Record_ } from '@lib/core';
import { dimensionRows, overlay } from './compare';

const read = (family: string, key: string) =>
  JSON.parse(readFileSync(join(CARTRIDGES, family, `${key}.json`), 'utf8')) as Record_;
const a = read('rimless', '308_win');
const b = read('belted', '300_win_mag');

describe('dimensionRows', () => {
  it('lists the shared millimetre symbols, labelled as the detail page labels them', () => {
    const symbols = dimensionRows(a, b, 'metric').map((row) => row.symbol);
    expect(symbols).toContain('e min');
    expect(symbols).toContain('r1 min');
    expect(symbols).toContain('L3 + G');
    // Not dimensions: tolerances, angles, pressures, and the chamber.
    for (const absent of ['L1Tol', 'P2Tol', 'α', 'β', 'δ', 'Pmax', 'PK', 'M', 'EE']) expect(symbols).not.toContain(absent);
    expect(new Set(symbols).size).toBe(symbols.length);
  });
  it('writes metric values with formatValue and the difference as B minus A', () => {
    const row = dimensionRows(a, b, 'metric').find((r) => r.symbol === 'P1')!;
    expect(row).toEqual({ symbol: 'P1', a: '11.96', b: '13.03', difference: '1.07' });
  });
  it('keeps symbols that differ only by case apart and leaves a missing value and its difference empty', () => {
    const one = { ...a, cartridge: { x: { F: 1, f: 2, only: 5 } } } as unknown as Record_;
    const two = { ...b, cartridge: { x: { F: 4, f: 8, other: 7 } } } as unknown as Record_;
    expect(dimensionRows(one, two, 'metric')).toEqual([
      { symbol: 'F', a: '1', b: '4', difference: '3' },
      { symbol: 'f', a: '2', b: '8', difference: '6' },
      { symbol: 'only', a: '5', b: '', difference: '' },
      { symbol: 'other', a: '', b: '7', difference: '' }
    ]);
  });
  it('lists a symbol only one cartridge publishes', () => {
    const rows = dimensionRows(a, b, 'metric');
    expect(rows.find((r) => r.symbol === 'delta L')).toMatchObject({ b: '', difference: '' });
    expect(rows.find((r) => r.symbol === 'delta L')!.a).not.toBe('');
    expect(rows.find((r) => r.symbol === 'R3')).toMatchObject({ a: '', difference: '' });
    expect(rows.find((r) => r.symbol === 'R3')!.b).not.toBe('');
  });
  it('converts values and differences to inches without further rounding', () => {
    const row = dimensionRows(a, b, 'imperial').find((r) => r.symbol === 'P1')!;
    expect(row).toEqual({ symbol: 'P1', a: String(Number((11.96 / 25.4).toPrecision(12))), b: String(Number((13.03 / 25.4).toPrecision(12))), difference: String(Number((1.07 / 25.4).toPrecision(12))) });
  });
  it('does not show binary noise in a metric difference', () => {
    const one = { ...a, cartridge: { x: { L: 51.18 } } } as unknown as Record_;
    const two = { ...b, cartridge: { x: { L: 66.55 } } } as unknown as Record_;
    expect(66.55 - 51.18).not.toBe(15.37);
    expect(dimensionRows(one, two, 'metric')[0]!.difference).toBe('15.37');
  });
});

describe('overlay', () => {
  it('draws one closed path per case in one viewport', () => {
    const drawing = overlay(a, b)!;
    expect(drawing.paths).toHaveLength(2);
    for (const path of drawing.paths) expect(path).toMatch(/^M[^M]*Z$/);
    expect(drawing.paths[0]).not.toBe(drawing.paths[1]);
  });
  it('puts both head faces at the same left edge, on the same axis', () => {
    const lefts = overlay(a, b)!.paths.map((path) => Math.min(...[...path.matchAll(/[ML]([-\d.]+),/g)].map((m) => Number(m[1]))));
    expect(lefts[0]).toBeCloseTo(lefts[1]!, 6);
    const drawing = overlay(a, b)!;
    expect(drawing.axisY).toBeCloseTo(drawing.height / 2, 6);
  });
  it('draws nothing for a shot cartridge', () => {
    expect(overlay({ ...a, family: 'shotshell' }, b)).toBeNull();
  });
  it('throws where the case lacks a dimension', () => {
    expect(() => overlay({ ...a, cartridge: {} }, b)).toThrow();
  });
});
