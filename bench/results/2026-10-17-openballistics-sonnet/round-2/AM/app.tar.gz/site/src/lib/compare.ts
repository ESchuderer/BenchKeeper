/**
 * What the comparison view shows: the two cases' outer profiles in one viewport, and a table of
 * the millimetre dimensions either cartridge publishes. Framework-free so the unit preference comes
 * in as an argument and the module can be tested without a page.
 */

import {
  FIELD_LABELS,
  FIELD_UNITS,
  GROUP_ORDER,
  formatValue,
  orderedFields,
  type Group,
  type Record_
} from '@lib/core';
import { fullSectionPath, viewportFor } from '@lib/geom';
import { adaptMetallic, caseOuterProfile, type CartridgeRecord } from '@lib/shapes2d';
import { displayNumber, type UnitSystem } from './units';

export interface Row {
  symbol: string;
  a: string;
  b: string;
  difference: string;
}

/** The `cartridge` groups of a record that are objects. */
function groupsOf(record: Record_): Record<string, Group> {
  return Object.fromEntries(
    Object.entries(record.cartridge).filter(
      (entry): entry is [string, Group] => !Array.isArray(entry[1]) && entry[1] !== null && typeof entry[1] === 'object'
    )
  );
}

type Pair = [number | undefined, number | undefined];

/**
 * Every millimetre dimension either record publishes, by symbol, in the detail page's order over
 * both records' groups. A record that does not publish a symbol has `undefined` in its place.
 */
function dimensions(a: Record_, b: Record_): Map<string, Pair> {
  const [x, y] = [groupsOf(a), groupsOf(b)];
  const names = [...new Set([...Object.keys(x), ...Object.keys(y)])];
  const known = GROUP_ORDER.cartridge.filter((name) => names.includes(name));
  const rest = names.filter((name) => !GROUP_ORDER.cartridge.includes(name)).sort((p, q) => p.localeCompare(q));
  const published = (group: Group | undefined, field: string) => {
    const value = group?.[field];
    return typeof value === 'number' && Number.isFinite(value) ? value : undefined;
  };
  const found = new Map<string, Pair>();
  for (const name of [...known, ...rest]) {
    for (const field of orderedFields('cartridge', name, { ...x[name], ...y[name] })) {
      if (Object.hasOwn(FIELD_UNITS, field)) continue;
      const pair: Pair = [published(x[name], field), published(y[name], field)];
      if (pair[0] !== undefined || pair[1] !== undefined) found.set(field, pair);
    }
  }
  return found;
}

/**
 * One row per symbol either record publishes; a value the record does not publish is empty, and so
 * is the difference. Metric values are written by `formatValue`, as the detail page does. The
 * difference is B minus A in millimetres, written through `displayNumber` (12 significant digits)
 * so that binary noise, `66.55 - 51.18` = `15.369999999999997`, does not appear in a column the
 * records give to two decimals.
 */
export function dimensionRows(a: Record_, b: Record_, system: UnitSystem): Row[] {
  const unit = system === 'imperial' ? 'in' : 'mm';
  const show = (value: number | undefined) =>
    value === undefined ? '' : system === 'imperial' ? displayNumber(value, unit) : (formatValue(value) ?? '');
  return [...dimensions(a, b)].map(([field, [x, y]]) => ({
    symbol: FIELD_LABELS[field] ?? field,
    a: show(x),
    b: show(y),
    difference: x === undefined || y === undefined ? '' : displayNumber(y - x, unit)
  }));
}

export interface Overlay {
  width: number;
  height: number;
  /** Millimetre to SVG user unit. */
  scale: number;
  /** Where the common axis runs, in user units. */
  axisY: number;
  paths: [string, string];
}

/**
 * Both outer profiles in one viewport: one scale, one axis, and the head faces (z = 0) at the same
 * point. `null` for a shot cartridge, which has no metallic case to draw.
 * Throws `MissingDimensionError` where a record lacks a dimension the case needs.
 */
export function overlay(a: Record_, b: Record_): Overlay | null {
  if (a.family === 'shotshell' || b.family === 'shotshell') return null;
  const profiles = [a, b].map((record) => caseOuterProfile(adaptMetallic(record as unknown as CartridgeRecord)));
  const view = viewportFor(profiles, { frame: 'landscape' });
  const [first, second] = profiles.map((profile) => fullSectionPath(profile, view));
  return {
    width: view.width,
    height: view.height,
    scale: view.scale,
    axisY: view.xy(0, 0)[1],
    paths: [first!, second!]
  };
}
