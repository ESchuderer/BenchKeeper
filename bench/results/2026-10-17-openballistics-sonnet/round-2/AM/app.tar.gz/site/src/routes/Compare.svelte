<script lang="ts">
  import { PX_PER_MM, type Record_ } from '@lib/core';
  import { byKey, load } from '../lib/data';
  import { dimensionRows, overlay } from '../lib/compare';
  import { t } from '../lib/i18n.svelte';
  import { href } from '../lib/router';
  import { unitSystem } from '../lib/units.svelte';

  interface Props {
    a: string;
    b: string;
  }
  let { a, b }: Props = $props();

  const unknown = $derived([a, b].find((key) => !byKey(key)));
  const records = $derived(unknown === undefined ? Promise.all([load(a), load(b)]) : null);

  function draw(first: Record_, second: Record_) {
    try {
      return overlay(first, second);
    } catch {
      return null;
    }
  }
</script>

<div data-ui="Compare" class="contents">
{#if unknown !== undefined}
  <p class="status error">{t('compare.unknown', { key: unknown })} <a href={href.list()}>{t('record.back')}</a></p>
{:else}
  {#await records}
    <p class="status">{t('site.loading')}</p>
  {:then loaded}
    {@const [first, second] = loaded!}
    {@const drawing = draw(first, second)}
    {@const rows = dimensionRows(first, second, unitSystem())}
    <header class="head">
      <h1>{first.name} / {second.name}</h1>
    </header>

    {#if drawing}
      <svg
        role="img"
        aria-label={t('compare.profiles', { a: first.name, b: second.name })}
        viewBox="0 0 {drawing.width} {drawing.height}"
        style:width="{(drawing.width / drawing.scale) * PX_PER_MM}px"
        class="overlay"
      >
        <line class="axis" x1="0" x2={drawing.width} y1={drawing.axisY} y2={drawing.axisY} />
        <path class="outline a" d={drawing.paths[0]} />
        <path class="outline b" d={drawing.paths[1]} />
      </svg>
      <ul class="legend">
        <li class="a">{first.name}</li>
        <li class="b">{second.name}</li>
      </ul>
    {:else}
      <p class="status">{t('compare.noDrawing', { names: `${first.name} / ${second.name}` })}</p>
    {/if}

    {#if rows.length}
      <div class="scroll">
        <table>
          <caption>{t('compare.dimensions', { unit: unitSystem() === 'imperial' ? 'in' : 'mm' })}</caption>
          <thead>
            <tr>
              <th scope="col">{t('compare.symbol')}</th>
              <th scope="col" class="num">{first.name}</th>
              <th scope="col" class="num">{second.name}</th>
              <th scope="col" class="num">{t('compare.difference')}</th>
            </tr>
          </thead>
          <tbody>
            {#each rows as row, index (index)}
              <tr>
                <td class="num">{row.symbol}</td>
                <td class="num">{row.a}</td>
                <td class="num">{row.b}</td>
                <td class="num">{row.difference}</td>
              </tr>
            {/each}
          </tbody>
        </table>
      </div>
    {:else}
      <p class="status">{t('compare.noCommon')}</p>
    {/if}

    <p class="foot"><a href={href.list()}>{t('record.back')}</a></p>
  {:catch error}
    <p class="status error">{error.message} <a href={href.list()}>{t('record.back')}</a></p>
  {/await}
{/if}
</div>

<style>
  @layer legacy {
    :global([data-ui="Compare"] .head) { padding-bottom: var(--space-6); border-bottom: 1px solid var(--rule); }
    :global([data-ui="Compare"] h1) { font-size: clamp(var(--step-3), 1.2rem + 2vw, var(--step-4)); line-height: 1.15; }
    :global([data-ui="Compare"] .overlay) { display: block; max-width: 100%; height: auto; margin: 1.5rem 0 .5rem; }
    :global([data-ui="Compare"] .axis) { stroke: var(--rule-strong); stroke-dasharray: 4 3; vector-effect: non-scaling-stroke; }
    :global([data-ui="Compare"] .outline) { fill: none; stroke-width: 1.5; vector-effect: non-scaling-stroke; }
    :global([data-ui="Compare"] .outline.a) { stroke: var(--link); }
    :global([data-ui="Compare"] .legend .a::before) { background: var(--link); }
    :global([data-ui="Compare"] .outline.b) { stroke: var(--warn); }
    :global([data-ui="Compare"] .legend .b::before) { background: var(--warn); }
    :global([data-ui="Compare"] .legend) { display: flex; flex-wrap: wrap; gap: .25rem 1.5rem; list-style: none; padding: 0; margin: 0 0 1.5rem; font-size: var(--step-0); }
    :global([data-ui="Compare"] .legend li::before) { content: ''; display: inline-block; width: 1.5rem; height: 3px; margin-right: .5rem; vertical-align: middle; }
    :global([data-ui="Compare"] .scroll) { overflow-x: auto; }
    :global([data-ui="Compare"] table) { border-collapse: collapse; font-size: var(--step-0); width: 100%; }
    :global([data-ui="Compare"] caption) { text-align: left; font-weight: 600; padding-bottom: .5rem; }
    :global([data-ui="Compare"] th), :global([data-ui="Compare"] td) { text-align: right; padding: .2rem .6rem .2rem 0; white-space: nowrap; }
    :global([data-ui="Compare"] th) { color: var(--ink-2); font-weight: 500; border-bottom: 1px solid var(--rule); }
    :global([data-ui="Compare"] td) { font-weight: 500; }
    :global([data-ui="Compare"] td:first-child), :global([data-ui="Compare"] th:first-child) { text-align: left; }
    :global([data-ui="Compare"] .status) { color: var(--ink-2); padding: 1.5rem 0; }
    :global([data-ui="Compare"] .foot) { margin-top: 2rem; }
  }
</style>
