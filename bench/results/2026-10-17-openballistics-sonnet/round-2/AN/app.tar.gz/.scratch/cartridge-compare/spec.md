# Compare two cartridges

Status: ready-for-agent

## Goal

A site view that compares two cartridges, at `#/compare/<a>/<b>`, reachable from a cartridge's detail page.

## Acceptance criteria

- The URL opens the view directly and survives a reload.
- One SVG (role `img`, name `Profiles of <name A> and <name B>`) overlays the `caseOuterProfile` outlines of both cases at one scale on one axis, head faces at the same point. Each outline is one `path`.
- One table (name `Dimensions (mm)` or `Dimensions (in)`), headers `Symbol`, name A, name B, `Difference` (B minus A). One row per symbol that either cartridge publishes as a number in the `cartridge` part, unit mm (no entry in `FIELD_UNITS`), not a `...Tol` field. Row label as `FIELD_LABELS` writes it. Where a cartridge does not publish the symbol, its cell and `Difference` are empty.
- The cells of both cartridge columns and of `Difference`, headers included, are right-aligned.
- Metric values via `formatValue`. Imperial values and differences via `displayNumber(..., 'in')`. Unit follows `Default units`.
- Detail page: select `Compare with` (other cartridges by name) and button `Compare`.
- English and German texts.
- Tests for the new code, CHANGELOG entry under Unreleased.

## Decisions

- Metric differences are cleaned of floating point noise with `toPrecision(12)`, as `displayNumber` does.
- `Compare with` starts on the first other cartridge by name.
- A case that cannot be drawn (shot cartridges, missing dimensions) gets a notice in place of the SVG. The table stays.
