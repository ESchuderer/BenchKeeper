# Changelog

All notable changes to OpenBallistics are recorded in this file.

The format follows [Keep a Changelog 1.1.0](https://keepachangelog.com/en/1.1.0/). The project follows [Semantic Versioning 2.0.0](https://semver.org/spec/v2.0.0.html), with the meaning of each part defined in [CONTRIBUTING.md](CONTRIBUTING.md#versioning).

Rules for this file:

- Each release has a section `## [X.Y.Z] - YYYY-MM-DD`. The release workflow reads this heading, so the format is fixed.
- Unreleased changes go under `## [Unreleased]`, in the subsections `Added`, `Changed`, `Deprecated`, `Removed`, `Fixed` and `Security`. Omit subsections that are empty.
- Entries describe the effect for a user of the data, the libraries or the site, not the commit.
- Data changes name the records, for example "Fixed: `308_win` case length".

## [Unreleased]

### Added

- GitHub Actions workflow that runs the site tests and the production build on every pull request.
- GitHub Actions workflow that deploys the site to GitHub Pages from `main`.
- GitHub Actions workflow that publishes a GitHub release from a version tag.
- Dependabot configuration for the npm dependencies in `site/` and for GitHub Actions.
- README, CONTRIBUTING guide, and this changelog.
- Site: a comparison view at `#/compare/<a>/<b>` that overlays the case profiles of two cartridges at one scale and tabulates the dimensions either publishes, with the difference where both do. A `Compare with` selection on each cartridge page opens it. English and German.
