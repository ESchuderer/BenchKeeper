# Contributing to OpenBallistics

Setup, test and build commands are in the [README](README.md). This file covers how changes are made and released.

## Reporting a problem

Use an issue form:

- A wrong or missing value in a cartridge: [`data.yml`](.github/ISSUE_TEMPLATE/data.yml)
- A wrong or missing value in a bullet: [`bullet.yml`](.github/ISSUE_TEMPLATE/bullet.yml)
- A problem with the site: [`site-feedback.yml`](.github/ISSUE_TEMPLATE/site-feedback.yml)

For data, name the source you read the correct value from.

## Making a change

1. Fork the repository and create a branch from `main`.
2. Make the change. Keep it to one purpose.
3. From `site/`, run `npm test` and `npm run build`. Both must pass. They are the same commands the CI workflow runs.
4. Commit with the convention below and open a pull request against `main`.

Do not edit generated files. The search indexes under `site/src/lib/*.generated.json` and the flags under `site/public/flags/` are git-ignored and rebuilt by `npm run prepare-data`.

### Data records

Records are JSON files in `data/`:

| Path | Record | File name |
| --- | --- | --- |
| `data/cartridges/<family>/` | one cartridge, with its chamber | `<key>.json` |
| `data/bullets/` | one bullet | `<key>.json` |
| `data/targets/` | one target face | `<id>.json` |

The families are `belted`, `pistol`, `rimfire`, `rimless`, `rimmed` and `shotshell`.

- Edit an existing record in place. Keep its key and file name.
- A new record is a new file in the matching directory. The index build reads every `.json` file there, so no list needs updating.
- Use the layout and 2-space indentation of the neighbouring files.
- Name the source of each changed value in the pull request description.
- Do not edit the `sample_` bullets by hand. `npm run sample-bullets` generates them (see [`data/bullets/README.md`](data/bullets/README.md)).
- Run `npm test` after changing a record. Check the result with `npm run dev`.

## Commit convention

Commits follow [Conventional Commits 1.0.0](https://www.conventionalcommits.org/en/v1.0.0/):

```
<type>(<scope>): <summary>

<optional body>

<optional footer>
```

- `type` is one of `feat`, `fix`, `docs`, `refactor`, `perf`, `test`, `build`, `ci`, `chore`, `revert`.
- `scope` is optional. Used scopes: `data`, `lib`, `site`, `deps`, `release`.
- `summary` is imperative, lower case, without a final full stop, at most 72 characters.
- A breaking change has `!` after the type or scope, or a `BREAKING CHANGE:` footer.
- Issue references go in the footer: `Refs #12` or `Closes #12`.

Examples:

```
fix(data): correct case length of 308_win
feat(data): add 6_5_prc cartridge
feat(site): add bullet comparison page
ci: run the build on pull requests
feat(data)!: rename the caseHead field to head
```

Commits that add or change records use `feat(data)` for new records and `fix(data)` for corrections.

When a pull request is squash-merged, its title becomes the commit message, so the title follows the same convention.

## Versioning

The project follows [Semantic Versioning 2.0.0](https://semver.org/spec/v2.0.0.html). One version covers the data, the libraries and the site.

- The version is the `version` field in [`site/package.json`](site/package.json), mirrored in `site/package-lock.json`. Git tags are `v<version>`.
- The public interface is the structure of the JSON records in `data/`, the exports of `lib/`, and the URLs of the site.
- MAJOR: a change that breaks a consumer of the records or the libraries, such as renaming or removing a record field, a record key or an export.
- MINOR: new records, new fields, new features.
- PATCH: corrected values and bug fixes.
- While the version is below 1.0.0, a breaking change raises MINOR instead of MAJOR.
- A tag with a suffix, such as `v0.2.0-rc.1`, is published as a pre-release.

## Changelog

[`CHANGELOG.md`](CHANGELOG.md) follows [Keep a Changelog 1.1.0](https://keepachangelog.com/en/1.1.0/). A pull request that changes data, library behaviour or the site adds a line under `## [Unreleased]`. Pull requests that only change CI, tests or documentation do not need one.

## Releasing

Maintainers release. Releases are tag-triggered: pushing a `v*` tag runs [`.github/workflows/release.yml`](.github/workflows/release.yml).

1. Create a branch `chore/release-X.Y.Z` from an up-to-date `main`.
2. In `site/`, run `npm version X.Y.Z --no-git-tag-version`. This updates `package.json` and `package-lock.json` without creating a commit or a tag.
3. In `CHANGELOG.md`, rename `## [Unreleased]` to `## [X.Y.Z] - YYYY-MM-DD`. Add an empty `## [Unreleased]` section above it.
4. Commit as `chore(release): vX.Y.Z`, open a pull request, and merge it after CI passes.
5. On the updated `main`, create and push the tag:

   ```
   git tag -a vX.Y.Z -m "vX.Y.Z"
   git push origin vX.Y.Z
   ```

The workflow then checks that:

- the tagged commit is on `main`,
- the tag equals `site/package.json` `version`,
- `CHANGELOG.md` has a section `## [X.Y.Z] - `,

and runs `npm test` and `npm run build`. It then creates the GitHub release with the changelog section as notes and two assets: `openballistics-site-X.Y.Z.tar.gz` (the built site) and `openballistics-data-X.Y.Z.tar.gz` (the `data/` directory).

The site is deployed by [`.github/workflows/pages.yml`](.github/workflows/pages.yml) on every push to `main`, not by the release workflow.

If the workflow fails before the release exists, fix the cause, delete the tag locally and on `origin`, and tag again.

## Dependency updates

[Dependabot](.github/dependabot.yml) opens weekly pull requests for the npm dependencies in `site/` and for the GitHub Actions in `.github/workflows/`. Minor and patch npm updates arrive as one grouped pull request. Their commit messages follow the convention above (`chore(deps)`, `ci(deps)`).

## Licence

By contributing you agree that your contribution is licensed under the [MIT licence](LICENSE).
