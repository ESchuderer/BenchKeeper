# OpenBallistics

An open database of cartridges, bullets and targets, stored as JSON records, with shared TypeScript libraries and a Svelte website that browses the records.

- Site: published to GitHub Pages from `main`. For `PiMetry/OpenBallistics` the address is <https://pimetry.github.io/OpenBallistics/> once Pages is enabled with the source "GitHub Actions".
- Changes: [CHANGELOG.md](CHANGELOG.md)
- Contributing: [CONTRIBUTING.md](CONTRIBUTING.md)

## Repository layout

| Path | Content |
| --- | --- |
| `data/cartridges/` | Cartridge records with their chambers, in one directory per family |
| `data/bullets/` | Bullet records |
| `data/targets/` | Target face records |
| `lib/` | Framework-free TypeScript libraries: geometry, drawing, targets, designer, user data |
| `site/` | The Svelte site. It holds the only `package.json` and the build |
| `fixtures/` | Reference files used by the tests |

## Requirements

- Node.js 22 and npm 10 (the versions CI uses)

## Install

All npm commands run in `site/`:

```
cd site
npm ci
```

## Develop

```
npm run dev
```

This builds the generated indexes, then starts the Vite dev server and prints its address. The dev server serves the records from `data/`.

Other scripts:

| Command | What it does |
| --- | --- |
| `npm run prepare-data` | Generates the search indexes and copies the flags. `dev`, `test` and `build` run it first |
| `npm run sample-bullets` | Regenerates the synthetic sample bullets in `data/bullets/` |
| `npm run preview` | Serves the output of `npm run build` |

## Test

```
npm test
```

This runs Vitest on the site tests in `site/src/` and the library tests in `lib/`. To run some of them, pass a file name filter:

```
npm test -- lib/targets
```

## Build

```
npm run build
```

This generates the indexes, type-checks with `svelte-check` and writes the site to `site/dist/`. The output is served from `/` unless `PAGES_BASE` is set, as the Pages workflow does:

```
PAGES_BASE=/OpenBallistics/ npm run build
```

## Continuous integration and deployment

| Workflow | Runs on | Does |
| --- | --- | --- |
| [`ci.yml`](.github/workflows/ci.yml) | every pull request | `npm ci`, `npm test`, `npm run build` |
| [`pages.yml`](.github/workflows/pages.yml) | push to `main` | tests, builds with `PAGES_BASE=/<repository>/`, deploys to GitHub Pages |
| [`release.yml`](.github/workflows/release.yml) | push of a `v*` tag | checks the version, tests, builds, creates a GitHub release |

[`dependabot.yml`](.github/dependabot.yml) opens weekly dependency update pull requests.

Repository setting needed once: Settings, Pages, Source: GitHub Actions.

## Contribute data

- Report a wrong or missing value: open an issue with the [cartridge](.github/ISSUE_TEMPLATE/data.yml) or [bullet](.github/ISSUE_TEMPLATE/bullet.yml) form. Each cartridge and bullet page on the site has a link that fills the form in. Name the source of the correct value.
- Fix or add a record: edit or add the JSON file under `data/`, run `npm test` in `site/`, and open a pull request that names the source. File layout and rules are in [CONTRIBUTING.md](CONTRIBUTING.md#data-records).

## Commits and releases

Commits follow Conventional Commits, for example `fix(data): correct case length of 308_win`. The full convention, the versioning rules and the release steps are in [CONTRIBUTING.md](CONTRIBUTING.md). The version is kept in `site/package.json`, and a release is made by pushing a `vX.Y.Z` tag.

## Licence

[MIT](LICENSE), Copyright (c) 2026 PiMetry. Third-party software the site redistributes is listed with its licences in [THIRD-PARTY.md](THIRD-PARTY.md).
