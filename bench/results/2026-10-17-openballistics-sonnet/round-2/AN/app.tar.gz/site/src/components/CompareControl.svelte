<script lang="ts">
  import Button from './ui/Button.svelte';
  import { Label } from '$lib/components/ui/label/index.js';
  import { NativeSelect } from '$lib/components/ui/native-select/index.js';
  import { entries } from '../lib/data';
  import { href } from '../lib/router';
  import { t } from '../lib/i18n.svelte';

  /** Picks a second cartridge and opens the comparison with it. */
  interface Props {
    current: string;
  }
  let { current }: Props = $props();

  const id = $props.id();
  const others = $derived(
    entries.filter((entry) => entry.key !== current).sort((a, b) => a.name.localeCompare(b.name, 'en'))
  );
  let picked = $state('');
  // The first other cartridge until one is picked, and again if the pick is the page being left.
  const chosen = $derived(others.some((entry) => entry.key === picked) ? picked : (others[0]?.key ?? ''));

  function open() {
    if (chosen) location.hash = href.compare(current, chosen);
  }
</script>

<form class="compare" onsubmit={(event) => { event.preventDefault(); open(); }}>
  <Label for={`${id}-with`}>{t('compare.with')}</Label>
  <NativeSelect id={`${id}-with`} value={chosen} onchange={(event) => (picked = event.currentTarget.value)}>
    {#each others as entry (entry.key)}
      <option value={entry.key}>{entry.name}</option>
    {/each}
  </NativeSelect>
  <Button type="submit" disabled={!chosen}>{t('compare.action')}</Button>
</form>

<style>
  @layer legacy {
    .compare { display: flex; flex-wrap: wrap; align-items: center; gap: .5rem 1rem; margin: 1rem 0; }
    @media print { .compare { display: none; } }
    .compare :global([data-slot='native-select-wrapper']) { width: auto; min-width: 12rem; max-width: 100%; }
  }
</style>
