import { readFileSync } from 'node:fs';
import { resolve } from 'node:path';
import { describe, expect, it } from 'vitest';
import type { Record_ } from '@lib/core';
import { dimensionRows, formatDifference, formatLength, outlineOf, overlay } from './compare';
import { displayNumber } from './units';

const DATA = resolve(__dirname, '../../../data/cartridges');
const read = (family: string, key: string) =>
  JSON.parse(readFileSync(resolve(DATA, family, `${key}.json`), 'utf8')) as Record_;

const a = read('rimless', '308_win');
const b = read('belted', '300_win_mag');

function record(cartridge: Record_['cartridge']): Record_ {
  return { key: 'x', name: 'X', family: 'rimless', cartridge, chamber: {} };
}

describe('dimension rows', () => {
  const rows = dimensionRows(a, b);

  const shared = rows.filter((row) => row.a !== undefined && row.b !== undefined);

  it('has one row per symbol both cartridges publish, in the order of the detail page', () => {
    expect(shared.map((row) => row.symbol)).toEqual([
      'L1', 'L2', 'L3', 'L6',
      'R', 'R1', 'E', 'E1', 'e min', 'f',
      'P1', 'P2',
      'S', 'r1 min', 'r2',
      'H1', 'H2',
      'G1', 'L3 + G',
      'Fe'
    ]);
  });

  it('lists symbols only one cartridge publishes, with the other value missing', () => {
    expect(rows.find((row) => row.symbol === 'delta L')).toMatchObject({ field: 'deltaL', b: undefined });
    expect(rows.find((row) => row.symbol === 'delta L')?.a).toBeTypeOf('number');
    expect(rows.find((row) => row.symbol === 'R3')).toMatchObject({ field: 'R3', a: undefined });
    expect(rows.find((row) => row.symbol === 'R3')?.b).toBeTypeOf('number');
  });

  it('lists every symbol either cartridge publishes once', () => {
    const fields = rows.map((row) => row.field);
    expect(new Set(fields).size).toBe(fields.length);
    expect(fields).toEqual(expect.arrayContaining([...dimensionRows(a, a), ...dimensionRows(b, b)].map((row) => row.field)));
    expect(rows).toHaveLength(dimensionRows(a, a).length + dimensionRows(b, b).length - shared.length);
  });

  it('leaves out tolerances, angles, pressures and masses', () => {
    const fields = rows.map((row) => row.field);
    for (const field of ['L1Tol', 'P2Tol', 'ETol', 'alpha', 'beta', 'delta', 'Pmax', 'PK', 'PE', 'EE', 'M']) {
      expect(fields).not.toContain(field);
    }
  });

  it('carries the published millimetre values', () => {
    expect(rows.find((row) => row.field === 'L1')).toMatchObject({ a: 39.62, b: 55.78 });
    expect(rows.find((row) => row.field === 'eMin')).toMatchObject({ symbol: 'e min', a: 1.4, b: 0.94 });
  });

  it('reads only the cartridge part and skips repeating groups', () => {
    const only = { ...record({ lengths: { L1: 1 } }), chamber: { barrel: { F: 7.62 } } };
    const other = record({ lengths: [{ marking: '12/70', l: 70 }], projectile: { F: 7.62 } });
    const found = dimensionRows(only, other);
    expect(found.map((row) => row.field).sort()).toEqual(['F', 'L1']);
    expect(found.find((row) => row.field === 'F')).toMatchObject({ a: undefined, b: 7.62 });
  });

  it('lists symbols that nothing is shared between, each with one value', () => {
    expect(dimensionRows(record({ lengths: { L1: 1 } }), record({ lengths: { L2: 2 } }))).toEqual([
      { field: 'L1', symbol: 'L1', a: 1, b: undefined },
      { field: 'L2', symbol: 'L2', a: undefined, b: 2 }
    ]);
  });

  it('is empty when neither cartridge publishes a dimension', () => {
    expect(dimensionRows(record({}), record({ lengths: { L1Tol: 0.1 } }))).toEqual([]);
  });

  it('keeps the first group in sheet order when a symbol repeats', () => {
    const first = record({ projectile: { G1: 9 }, lengths: { G1: 5 } });
    const second = record({ lengths: { G1: 7 } });
    expect(dimensionRows(first, second)).toEqual([{ field: 'G1', symbol: 'G1', a: 5, b: 7 }]);
  });
});

describe('number formatting', () => {
  it('writes metric values exactly as the detail page does', () => {
    expect(formatLength(39.62, 'metric')).toBe('39.62');
    expect(formatLength(0.1, 'metric')).toBe('0.1');
    expect(formatLength(71, 'metric')).toBe('71');
  });

  it('converts lengths to inches without further rounding', () => {
    expect(formatLength(25.4, 'imperial')).toBe('1');
    expect(formatLength(39.62, 'imperial')).toBe(displayNumber(39.62, 'in'));
    expect(formatLength(39.62, 'imperial')).toBe('1.55984251969');
  });

  it('writes B minus A, without binary noise', () => {
    expect(formatDifference(43.48, 51.18, 'metric')).toBe('7.7');
    expect(formatDifference(39.62, 55.78, 'metric')).toBe('16.16');
    expect(formatDifference(1.4, 0.94, 'metric')).toBe('-0.46');
    expect(formatDifference(0.1, 0.1, 'metric')).toBe('0');
  });

  it('converts the difference, not the difference of converted values', () => {
    expect(formatDifference(0, 25.4, 'imperial')).toBe('1');
    expect(formatDifference(1.4, 0.94, 'imperial')).toBe(displayNumber(0.94 - 1.4, 'in'));
    expect(formatDifference(5, 5, 'imperial')).toBe('0');
  });
});

/** The coordinates of a path made of `M`/`L` commands. */
function points(path: string): [number, number][] {
  return [...path.matchAll(/[ML]([-\d.]+),([-\d.]+)/g)].map((m) => [Number(m[1]), Number(m[2])]);
}
const span = (values: number[]) => [Math.min(...values), Math.max(...values)] as const;

describe('profile overlay', () => {
  const outlineA = outlineOf(a);
  const outlineB = outlineOf(b);

  it('draws both metallic cases', () => {
    expect(outlineA).not.toBeNull();
    expect(outlineB).not.toBeNull();
  });

  it('cannot draw a shot cartridge', () => {
    const hull = { ...a, family: 'shotshell' };
    expect(outlineOf(hull)).toBeNull();
  });

  it('cannot draw a record without the figures the case needs', () => {
    expect(outlineOf(record({ lengths: { L1: 1 } }))).toBeNull();
  });

  const drawn = overlay(outlineA!, outlineB!);
  const pa = points(drawn.a);
  const pb = points(drawn.b);

  it('makes each outline one closed path', () => {
    for (const path of [drawn.a, drawn.b]) {
      expect(path.startsWith('M')).toBe(true);
      expect(path.endsWith('Z')).toBe(true);
      expect(path.match(/M/g)).toHaveLength(1);
    }
  });

  it('puts both head faces at the same place', () => {
    expect(span(pa.map((p) => p[0]))[0]).toBeCloseTo(drawn.headX, 4);
    expect(span(pb.map((p) => p[0]))[0]).toBeCloseTo(drawn.headX, 4);
  });

  it('shares one axis: each outline is symmetric about it', () => {
    for (const set of [pa, pb]) {
      const [low, high] = span(set.map((p) => p[1]));
      expect((low + high) / 2).toBeCloseTo(drawn.axisY, 4);
    }
  });

  it('uses one scale for both', () => {
    const length = (outline: [number, number][]) => Math.max(...outline.map((p) => p[1]));
    const radius = (outline: [number, number][]) => Math.max(...outline.map((p) => p[0]));
    const [ax0, ax1] = span(pa.map((p) => p[0]));
    const [bx0, bx1] = span(pb.map((p) => p[0]));
    const [ay0, ay1] = span(pa.map((p) => p[1]));
    const [by0, by1] = span(pb.map((p) => p[1]));
    expect((ax1 - ax0) / length(outlineA!)).toBeCloseTo((bx1 - bx0) / length(outlineB!), 3);
    expect((ay1 - ay0) / (2 * radius(outlineA!))).toBeCloseTo((by1 - by0) / (2 * radius(outlineB!)), 3);
    expect((ax1 - ax0) / length(outlineA!)).toBeCloseTo((ay1 - ay0) / (2 * radius(outlineA!)), 3);
  });

  it('fits both outlines in the image', () => {
    for (const [x, y] of [...pa, ...pb]) {
      expect(x).toBeGreaterThanOrEqual(0);
      expect(x).toBeLessThanOrEqual(drawn.width);
      expect(y).toBeGreaterThanOrEqual(0);
      expect(y).toBeLessThanOrEqual(drawn.height);
    }
  });
});
