/**
 * Comparing two cartridges: the dimensions either publishes, and the two case outlines on one axis.
 *
 * Framework-free. The page that shows it is `routes/Compare.svelte`.
 */

import { FIELD_LABELS, FIELD_UNITS, GROUP_ORDER, formatValue, orderedFields } from '@lib/core';
import type { Group, Record_ } from '@lib/core';
import { fullSectionPath, viewportFor } from '@lib/geom';
import { adaptMetallic, caseOuterProfile, type CartridgeRecord } from '@lib/shapes2d';
import { displayNumber, type UnitSystem } from './units';

export interface DimensionRow {
  /** The JSON field name. */
  field: string;
  /** The symbol as the detail page writes it. */
  symbol: string;
  /** Millimetres, as published. `undefined` where that cartridge does not publish the dimension. */
  a: number | undefined;
  b: number | undefined;
}

/** Whether a field is a dimension: a number in millimetres, not a tolerance. */
function isDimension(field: string, value: unknown): value is number {
  return (
    typeof value === 'number' &&
    Number.isFinite(value) &&
    !field.endsWith('Tol') &&
    !Object.hasOwn(FIELD_UNITS, field)
  );
}

/** Group names in sheet order, those the sheet does not know last and sorted. */
function sheetOrder(names: Iterable<string>): string[] {
  const all = new Set(names);
  const known = GROUP_ORDER.cartridge.filter((name) => all.has(name));
  const rest = [...all].filter((name) => !known.includes(name)).sort();
  return [...known, ...rest];
}

/** A record's group of single values, or `undefined` for a missing or repeating group. */
function groupOf(record: Record_, name: string): Group | undefined {
  const group = record.cartridge[name];
  return !group || Array.isArray(group) ? undefined : (group as Group);
}

/** The dimensions of a record's `cartridge` part by field name, the first group in sheet order winning. */
function dimensionsOf(record: Record_): Map<string, number> {
  const found = new Map<string, number>();
  for (const name of sheetOrder(Object.keys(record.cartridge))) {
    const group = groupOf(record, name);
    if (!group) continue;
    for (const field of orderedFields('cartridge', name, group)) {
      const value = group[field];
      if (isDimension(field, value) && !found.has(field)) found.set(field, value);
    }
  }
  return found;
}

/** One row per dimension either record publishes, in the order of the detail page. */
export function dimensionRows(a: Record_, b: Record_): DimensionRow[] {
  const first = dimensionsOf(a);
  const second = dimensionsOf(b);
  const rows: DimensionRow[] = [];
  const listed = new Set<string>();
  for (const name of sheetOrder([...Object.keys(a.cartridge), ...Object.keys(b.cartridge)])) {
    const merged = { ...groupOf(a, name), ...groupOf(b, name) };
    for (const field of orderedFields('cartridge', name, merged)) {
      if (listed.has(field) || !(first.has(field) || second.has(field))) continue;
      listed.add(field);
      rows.push({ field, symbol: FIELD_LABELS[field] ?? field, a: first.get(field), b: second.get(field) });
    }
  }
  return rows;
}

/** A published length as the detail page writes it, or in inches. Nothing is rounded. */
export function formatLength(millimetres: number, system: UnitSystem): string {
  return system === 'imperial' ? displayNumber(millimetres, 'in') : (formatValue(millimetres) ?? '');
}

/**
 * B minus A, converted like a value. Subtracting two decimals leaves binary noise
 * (`51.18 - 43.48` is `7.699999999999996`), so the difference is cut at the 12 significant
 * digits `displayNumber` keeps.
 */
export function formatDifference(a: number, b: number, system: UnitSystem): string {
  const difference = b - a;
  return system === 'imperial'
    ? displayNumber(difference, 'in')
    : (formatValue(Number(difference.toPrecision(12))) ?? '');
}

export interface Overlay {
  width: number;
  height: number;
  /** Closed outline of each case, as one path. */
  a: string;
  b: string;
  /** Pixel positions of the common axis and of the common head face. */
  axisY: number;
  headX: number;
  spanY: [number, number];
  endX: number;
}

/** The outer profile of a record's case, or `null` where it cannot be drawn (shot cartridges, missing figures). */
export function outlineOf(record: Record_): [number, number][] | null {
  if (record.family === 'shotshell') return null;
  try {
    return caseOuterProfile(adaptMetallic(record as unknown as CartridgeRecord));
  } catch {
    return null;
  }
}

/** Both outlines in one viewport: one scale, one axis, the head faces at the same place. */
export function overlay(a: [number, number][], b: [number, number][]): Overlay {
  const view = viewportFor([a, b], { frame: 'landscape', scale: 10 });
  const [headX, axisY] = view.xy(0, 0);
  const [, top] = view.xy(view.rMax, 0);
  const [, bottom] = view.xy(-view.rMax, 0);
  const [endX] = view.xy(0, view.zMax);
  return {
    width: view.width,
    height: view.height,
    a: fullSectionPath(a, view),
    b: fullSectionPath(b, view),
    axisY,
    headX,
    spanY: [top, bottom],
    endX
  };
}
