<script lang="ts">
  import { byKey, load } from '../lib/data';
  import { dimensionRows, formatDifference, formatLength, outlineOf, overlay } from '../lib/compare';
  import { href } from '../lib/router';
  import { t } from '../lib/i18n.svelte';
  import { unitSystem } from '../lib/units.svelte';

  /**
   * Two cartridges side by side: their case outlines on one axis and the dimensions either publishes.
   * The pairing is the URL's, so the view opens directly and survives a reload.
   */
  interface Props {
    a: string;
    b: string;
  }
  let { a, b }: Props = $props();

  const records = $derived(
    byKey(a) && byKey(b) ? Promise.all([load(a), load(b)]) : Promise.reject(new Error(missing(a, b)))
  );

  function missing(first: string, second: string): string {
    return t('compare.unknown', { key: byKey(first) ? second : first });
  }

  const system = $derived(unitSystem());
</script>

<div data-ui="Compare" class="contents">
{#await records}
  <p class="status" role="status">{t('site.loading')}</p>
{:then [first, second]}
  {@const outlines = [outlineOf(first), outlineOf(second)] as const}
  {@const drawn = outlines[0] && outlines[1] ? overlay(outlines[0], outlines[1]) : null}
  {@const rows = dimensionRows(first, second)}
  <header class="head">
    <h1>{t('compare.title')}</h1>
    <p class="lede">{t('compare.lede')}</p>
    <ul class="legend">
      <li><span class="swatch first" aria-hidden="true"></span><a href={href.cartridge(first.key)}>{first.name}</a></li>
      <li><span class="swatch second" aria-hidden="true"></span><a href={href.cartridge(second.key)}>{second.name}</a></li>
    </ul>
  </header>

  {#if drawn}
    <svg
      role="img"
      aria-label={t('compare.profiles', { a: first.name, b: second.name })}
      viewBox={`0 0 ${drawn.width} ${drawn.height}`}
      preserveAspectRatio="xMidYMid meet"
      class="overlay"
    >
      <line class="axis" x1={drawn.headX} y1={drawn.axisY} x2={drawn.endX} y2={drawn.axisY} />
      <line class="axis" x1={drawn.headX} y1={drawn.spanY[0]} x2={drawn.headX} y2={drawn.spanY[1]} />
      <path class="outline first" d={drawn.a} />
      <path class="outline second" d={drawn.b} />
    </svg>
  {:else}
    <p class="status">{t('compare.noProfile', {
      names: [outlines[0] ? null : first.name, outlines[1] ? null : second.name].filter(Boolean).join(', ')
    })}</p>
  {/if}

  {#if rows.length}
    <div class="scroll">
      <table>
        <caption>{system === 'imperial' ? t('compare.tableIn') : t('compare.tableMm')}</caption>
        <thead>
          <tr>
            <th scope="col">{t('compare.symbol')}</th>
            <th scope="col" class="num">{first.name}</th>
            <th scope="col" class="num">{second.name}</th>
            <th scope="col" class="num">{t('compare.difference')}</th>
          </tr>
        </thead>
        <tbody>
          {#each rows as row (row.field)}
            <tr>
              <th scope="row" class="num">{row.symbol}</th>
              <td class="num">{row.a === undefined ? '' : formatLength(row.a, system)}</td>
              <td class="num">{row.b === undefined ? '' : formatLength(row.b, system)}</td>
              <td class="num">{row.a === undefined || row.b === undefined ? '' : formatDifference(row.a, row.b, system)}</td>
            </tr>
          {/each}
        </tbody>
      </table>
    </div>
    <p class="note">{t('compare.differenceNote')}</p>
  {:else}
    <p class="status">{t('compare.noDimensions')}</p>
  {/if}

  <p class="foot"><a href={href.cartridge(first.key)}>{t('record.back')}</a></p>
{:catch error}
  <p class="status error">{error.message} <a href={href.list()}>{t('record.back')}</a></p>
{/await}
</div>

<style>
  @layer legacy {
    .head { padding-bottom: var(--space-6); border-bottom: 1px solid var(--rule); }
    .lede, .note, .status { color: var(--ink-2); }
    .legend { display: flex; flex-wrap: wrap; gap: .5rem 1.5rem; list-style: none; padding: 0; margin: .75rem 0 0; }
    .legend li { display: flex; align-items: center; gap: .5rem; }
    .swatch { display: inline-block; width: 1.5rem; height: 0; border-top: 3px solid; }
    .swatch.first, .outline.first { color: #2563eb; }
    .swatch.second, .outline.second { color: #d97706; }
    .swatch.second { border-top-style: dashed; }
    .swatch { border-top-color: currentColor; }
    .overlay { display: block; width: 100%; max-height: 28rem; margin: 1.5rem 0; }
    .outline { fill: none; stroke: currentColor; stroke-width: 2; vector-effect: non-scaling-stroke; stroke-linejoin: round; }
    .outline.second { stroke-dasharray: 6 4; }
    .axis { stroke: var(--rule-strong); stroke-width: 1; stroke-dasharray: 2 3; vector-effect: non-scaling-stroke; }
    .scroll { overflow-x: auto; }
    table { border-collapse: collapse; width: 100%; max-width: 48rem; }
    caption { text-align: left; font-weight: 600; padding: .5rem 0; }
    th, td { padding: .35rem .75rem; border-bottom: 1px solid var(--rule); text-align: left; }
    th[scope='row'], thead th:first-child { font-weight: 500; }
    thead th.num, td.num { text-align: right; }
    .note { margin: .5rem 0 0; font-size: var(--step--1, .875rem); }
    .foot { margin-top: 2rem; }
  }
</style>
