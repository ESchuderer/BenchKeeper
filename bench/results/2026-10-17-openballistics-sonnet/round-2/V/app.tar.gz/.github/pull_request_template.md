<!--
The title of this pull request becomes the commit message on `main`, so it must follow the
convention in CONTRIBUTING.md, e.g. `fix(data): correct the 308 Win. case length`.
-->

## What and why

## Source (for data changes)

<!-- The C.I.P. sheet, manufacturer page or measurement each changed figure comes from. -->

## Checked

- [ ] `npm test` and `npm run build` pass in `site/`
