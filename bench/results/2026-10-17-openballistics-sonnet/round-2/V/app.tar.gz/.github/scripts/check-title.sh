#!/usr/bin/env bash
# Check that a commit or pull request title follows the Conventional Commits convention
# described in CONTRIBUTING.md.
#
#   .github/scripts/check-title.sh "fix(data): correct the 308 Win. case length"
set -euo pipefail

if [ "$#" -ne 1 ]; then
  echo "usage: $0 <title>" >&2
  exit 2
fi

title=$1
types='feat|fix|docs|style|refactor|perf|test|build|ci|chore|revert'
pattern="^(${types})(\\([a-z0-9][a-z0-9._/-]*\\))?!?: [^[:space:]].*$"
max=100

if [[ ! $title =~ $pattern ]]; then
  cat >&2 <<MSG
"$title" does not follow the commit convention.

Expected: <type>(<optional scope>)<optional !>: <description>
  type:  ${types//|/, }
  scope: for example data, site, lib, deps, ci
See CONTRIBUTING.md, "Commit messages".
MSG
  exit 1
fi

if [ "${#title}" -gt "$max" ]; then
  echo "The title is ${#title} characters long; the limit is ${max} (72 is better)." >&2
  exit 1
fi
