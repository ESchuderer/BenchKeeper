# Contributing to OpenBallistics

Thank you for helping. This page covers how a change gets into `main` and how a release is made.
How to install, run, test and build is in the [README](README.md).

## Reporting problems

Use the issue forms: one for a cartridge, one for a bullet, one for the website. For a data problem
the most useful thing you can send is the source you are reading the right figure from.

## Making a change

1. Fork the repository and create a branch from `main`.
2. Make the change. Keep a pull request to one subject: a correction to one cartridge, one feature.
3. In `site/`, run `npm test` and `npm run build`. They are the checks CI runs on every pull
   request; a pull request should not be merged while they fail.
4. Open a pull request against `main`. Its title must follow the commit convention below.

Pull requests are **squash-merged**, so the pull request title is the commit message that lands on
`main`. The individual commits in your branch can be as untidy as you like.

## Contributing data

- **Where records live.** A cartridge is `data/cartridges/<family>/<key>.json`, where the family is
  one of `belted`, `pistol`, `rimfire`, `rimless`, `rimmed` or `shotshell`. A bullet is
  `data/bullets/<key>.json` and a target is `data/targets/<id>.json`. The file name is the record's
  key.
- **Edit a record like its neighbours.** Two-space indented JSON, the same field names, and the
  same units as the records around it. Do not invent a field to hold something the existing fields
  can express.
- **Cite your source** in the pull request: the C.I.P. sheet and its revision, the maker's
  published figure, or your own measurement and the instrument. A figure that cannot be checked
  against something will not be merged.
- **Only submit what you have the right to.** Do not copy from a source whose terms forbid it.
  By contributing you agree that your contribution is licensed under the [MIT License](LICENSE),
  the same as the rest of the repository.
- **Sample bullets are generated.** The records in `data/bullets/` are synthetic samples written by
  `npm run sample-bullets` (in `site/`); change the generator, not the files. See
  [`data/bullets/README.md`](data/bullets/README.md).
- **Check it.** `npm test` reads every record when it builds the search index, and
  `npm run build` serves them in the site. Open the record in `npm run dev` and look at the drawing.

## Commit messages

Commit messages and pull request titles follow
[Conventional Commits 1.0](https://www.conventionalcommits.org/en/v1.0.0/):

```
<type>(<scope>): <description>
```

The scope is optional, the description is lower-case and in the imperative, and the whole line is
at most 72 characters (100 is the hard limit). Types:

| Type | Use it for | Version bump |
| ---- | ---------- | ------------ |
| `feat` | A new feature, or new records | minor |
| `fix` | A bug fix, or a correction to a record | patch |
| `perf` | A performance improvement | patch |
| `revert` | Reverting an earlier change | patch |
| `docs` | Documentation only | none |
| `refactor`, `test`, `style` | Changes that alter neither behaviour nor data | none |
| `build`, `ci`, `chore` | Tooling, dependencies, repository upkeep | none |

Suggested scopes: `data`, `site`, `lib`, `deps`, `ci`. Add `!` after the type or scope, or a
`BREAKING CHANGE:` footer, for a breaking change; it bumps the major version (the minor version
while the major version is 0).

Examples:

```
feat(data): add the .277 Fury cartridge
fix(data): correct the 308 Win. case length
fix(site): keep the filter when going back from a record
refactor(lib): split the drawing module
ci: run the tests on Node 22
feat(lib)!: rename the Entry fields
```

To check a title before you push it:

```sh
.github/scripts/check-title.sh "fix(data): correct the 308 Win. case length"
```

The same script runs on every pull request title.

## Versioning and releases

**What the version means.** The repository has one version, for the data, the libraries and the site
together. It follows [Semantic Versioning](https://semver.org/):

- **major**: a breaking change to the shape of a record in `data/` or to what `lib/` exports, so
  that something reading the data or importing the libraries has to change;
- **minor**: new records, new features;
- **patch**: corrections to records, bug fixes.

While the version is `0.x`, a breaking change bumps the minor version.

**Where it is kept.** In [`version.txt`](version.txt), which is the source of truth, and
[`.release-please-manifest.json`](.release-please-manifest.json). release-please copies it into
`site/package.json` and `site/package-lock.json`. Do not edit any of these by hand.

**How a release is made.** [release-please](https://github.com/googleapis/release-please)
(configured in [`release-please-config.json`](release-please-config.json), run by
[`.github/workflows/release.yml`](.github/workflows/release.yml)) reads the commit titles merged
into `main` and keeps a pull request open titled `chore(main): release X.Y.Z`, which updates the
version files and `CHANGELOG.md`. To release, a maintainer reviews that pull request and merges it.
The workflow then tags `vX.Y.Z`, creates the GitHub release with the changelog entry as its notes,
and attaches `openballistics-data-vX.Y.Z.tar.gz`, an archive of `data/`.

**The changelog.** [`CHANGELOG.md`](CHANGELOG.md) is generated by release-please, newest entry
first. Each entry is headed `## [X.Y.Z](compare link) (YYYY-MM-DD)` and lists the commits under
`### Features`, `### Bug Fixes`, `### Performance`, `### Reverts` and `### Documentation`, with
breaking changes under `### ⚠ BREAKING CHANGES`. Commits of type `refactor`, `test`, `style`,
`build`, `ci` and `chore` are left out. The text of an entry is the commit title, so write titles
that read well there.

The website is not tied to releases: it is deployed from `main` on every merge
([`.github/workflows/pages.yml`](.github/workflows/pages.yml)).

## Maintainers: one-time repository setup

These are settings that a file in the repository cannot make:

- Settings > Pages > Source: **GitHub Actions**.
- Settings > Actions > General > Workflow permissions: allow GitHub Actions to create and approve
  pull requests (for release-please).
- Settings > General > Pull Requests: allow squash merging, make it the only method, and use "Pull
  request title" as the default commit message.
- Settings > Branches: protect `main`; require the `Test and build` and `Conventional Commit title`
  checks.
- Optional: store a personal access token or GitHub App token as the secret `RELEASE_PLEASE_TOKEN`.
  Without it the release pull request is created with `GITHUB_TOKEN`, GitHub does not start CI for
  it, and a required check will stay pending on that pull request.

## Dependencies

[Dependabot](.github/dependabot.yml) opens weekly pull requests for the npm packages in `site/` and
for the GitHub Actions the workflows use. Minor and patch updates come as one pull request per
ecosystem; major updates come one at a time. Its titles follow the convention above (`build(deps)`,
`ci(deps)`), so they do not trigger a release. Merge one when CI passes.
