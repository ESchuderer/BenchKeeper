# OpenBallistics

An open database of cartridges, bullets and targets, with the libraries that draw and measure them
and a website that browses them.

| Directory | What is in it |
| --------- | ------------- |
| `data/`   | The database: one JSON record per cartridge (`data/cartridges/<family>/`), bullet (`data/bullets/`) and target (`data/targets/`). |
| `lib/`    | Shared TypeScript libraries: geometry, drawing, targets, scoring and the cartridge designer. They do not depend on the site. |
| `site/`   | The Svelte website, built with Vite. It is the only part with an `npm` package; `lib/` is compiled into it. |
| `fixtures/` | Reference drawings and inputs used by the tests. Not shipped. |

Issues and pull requests are welcome. Read [CONTRIBUTING.md](CONTRIBUTING.md) first.

## Install

You need Node.js 22 (the version in [`.node-version`](.node-version)) and npm. Everything runs from
`site/`:

```sh
cd site
npm ci
```

## Develop

```sh
npm run dev
```

This generates the search index from `data/` and starts the Vite dev server. The dev server serves
the records in `data/` directly, so an edited record shows up on reload.

The generated files (`site/src/lib/*.generated.json`, `site/public/flags/`) are git-ignored. To
regenerate them without starting the server:

```sh
npm run prepare-data
```

## Test

```sh
npm test
```

This runs Vitest over the site's tests and the tests in `lib/`. It regenerates the generated files
first. To run the tests whose path matches a name:

```sh
npx vitest run targets
```

## Build

```sh
npm run build
```

This prepares the data, type-checks with `svelte-check`, and writes the site to `site/dist/`.
`npm run preview` serves that build locally. When the site is not served from the root of its host,
set `PAGES_BASE` to the path, for example `PAGES_BASE=/OpenBallistics/ npm run build`.

## Contribute data

Records are plain JSON files, so a correction is a small pull request:

- A cartridge is `data/cartridges/<family>/<key>.json`; a bullet is `data/bullets/<key>.json`; a
  target is `data/targets/<id>.json`.
- Say where each figure comes from: the C.I.P. sheet, the maker's page, or a measurement.
- Run `npm test` and `npm run build` in `site/` before you open the pull request.

If you would rather not edit JSON, open an issue with the "cartridge" or "bullet" form and name your
source. [CONTRIBUTING.md](CONTRIBUTING.md#contributing-data) has the details.

## Commits and releases

Commit messages and pull request titles follow [Conventional Commits](https://www.conventionalcommits.org/en/v1.0.0/),
for example `fix(data): correct the 308 Win. case length`. Releases are made by release-please from
those messages, and the version and its history are in [CHANGELOG.md](CHANGELOG.md). Both are
described in [CONTRIBUTING.md](CONTRIBUTING.md).

## License

The code, the data and the documentation are released under the [MIT License](LICENSE). The website
includes third-party software and fonts under their own licenses, listed in
[THIRD-PARTY.md](THIRD-PARTY.md).
