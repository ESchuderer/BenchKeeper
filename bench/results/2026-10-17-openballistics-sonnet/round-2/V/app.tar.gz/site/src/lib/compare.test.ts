import { readdirSync, readFileSync } from 'node:fs';
import { join, resolve } from 'node:path';
import { describe, expect, it } from 'vitest';
import { FIELD_LABELS, FIELD_UNITS, formatValue } from '@lib/core';
import type { Record_ } from '@lib/core';
import { compareDimensions, dimensionsOf, overlayOf, tableUnit } from './compare';
import { displayNumber } from './units';

const CARTRIDGES = resolve(__dirname, '../../../data/cartridges');
const records = new Map<string, Record_>();
for (const family of readdirSync(CARTRIDGES)) {
  for (const file of readdirSync(join(CARTRIDGES, family))) {
    const record = JSON.parse(readFileSync(join(CARTRIDGES, family, file), 'utf8')) as Record_;
    records.set(record.key, record);
  }
}
const get = (key: string): Record_ => {
  const record = records.get(key);
  if (!record) throw new Error(`no record ${key}`);
  return record;
};
const rowOf = (rows: ReturnType<typeof compareDimensions>, symbol: string) => rows.find((row) => row.symbol === symbol);

describe('dimensions of a record', () => {
  const symbols = dimensionsOf(get('308_win')).map((dimension) => dimension.symbol);
  it('writes symbols as the detail page does', () => {
    expect(symbols).toContain('e min');
    expect(symbols).toContain('r1 min');
    expect(symbols).toContain('L3 + G');
    expect(symbols).not.toContain('eMin');
  });
  it('leaves out what is not a length in millimetres, and tolerances', () => {
    for (const excluded of ['Pmax', 'PK', 'PE', 'EE', 'M', 'α', 'β', 'δ', 'L1Tol', 'RTol', 'P2Tol']) {
      expect(symbols).not.toContain(excluded);
    }
    expect(symbols).toEqual(expect.arrayContaining(['L1', 'L2', 'L3', 'L6', 'R', 'R1', 'E', 'E1', 'f', 'P1', 'P2', 'H1', 'H2', 'S', 'r2', 'G1', 'Fe']));
  });
  it('lists a symbol once, in the order of the detail page', () => {
    expect(new Set(symbols).size).toBe(symbols.length);
    expect(symbols.indexOf('L1')).toBeLessThan(symbols.indexOf('R'));
    expect(symbols.indexOf('R')).toBeLessThan(symbols.indexOf('P1'));
  });
  it('reads only millimetre numbers in every record', () => {
    for (const record of records.values()) {
      for (const { symbol, value } of dimensionsOf(record)) {
        expect(Number.isFinite(value), `${record.key} ${symbol}`).toBe(true);
        expect(Object.keys(FIELD_UNITS).map((field) => FIELD_LABELS[field] ?? field)).not.toContain(symbol);
        expect(symbol.endsWith('Tol')).toBe(false);
      }
    }
  });
  it('does not read a shot cartridge\'s repeating groups', () => {
    const shot = { cartridge: { lengths: [{ marking: '12/70', l: 70 }], dimensions: { d: 18.5, dTol: 0.1, alpha: 3 } } } as unknown as Record_;
    expect(dimensionsOf(shot)).toEqual([{ symbol: 'd', value: 18.5 }]);
  });
  it('does not mistake an inherited property for a unit', () => {
    const odd = { cartridge: { lengths: { constructor: 1, toString: 2, L1: 3 } } } as unknown as Record_;
    expect(dimensionsOf(odd).map((dimension) => dimension.symbol)).toEqual(['L1', 'constructor', 'toString']);
  });
});

describe('the comparison table', () => {
  const a = get('308_win');
  const b = get('300_win_mag');

  it('has one row per symbol either publishes', () => {
    const rows = compareDimensions(a, b, 'metric');
    const symbols = rows.map((row) => row.symbol);
    const inA = dimensionsOf(a).map((dimension) => dimension.symbol);
    const inB = dimensionsOf(b).map((dimension) => dimension.symbol);
    expect(new Set(symbols).size).toBe(symbols.length);
    expect(new Set(symbols)).toEqual(new Set([...inA, ...inB]));
    expect(symbols.filter((symbol) => inA.includes(symbol))).toEqual(inA);
    expect(symbols.filter((symbol) => inB.includes(symbol))).toEqual(inB);
  });
  it('lists a dimension only one publishes, with empty cells for the other and for the difference', () => {
    const rows = compareDimensions(a, b, 'metric');
    expect(rowOf(rows, 'delta L')).toEqual({ symbol: 'delta L', a: expect.any(String), b: '', difference: '' });
    expect(rowOf(rows, 'delta L')!.a).not.toBe('');
    expect(rowOf(rows, 'R3')).toEqual({ symbol: 'R3', a: '', b: expect.any(String), difference: '' });
    expect(rowOf(rows, 'R3')!.b).not.toBe('');
  });
  it('puts a symbol only B publishes after its predecessor in B', () => {
    const one = { cartridge: { lengths: { L1: 1, L4: 2 } } } as unknown as Record_;
    const two = { cartridge: { lengths: { L1: 4, L5: 9, L6: 3 } } } as unknown as Record_;
    expect(compareDimensions(one, two, 'metric')).toEqual([
      { symbol: 'L1', a: '1', b: '4', difference: '3' },
      { symbol: 'L5', a: '', b: '9', difference: '' },
      { symbol: 'L6', a: '', b: '3', difference: '' },
      { symbol: 'L4', a: '2', b: '', difference: '' }
    ]);
  });
  it('writes metric values as the detail page does, and the difference as B minus A', () => {
    const rows = compareDimensions(a, b, 'metric');
    expect(rowOf(rows, 'e min')).toEqual({ symbol: 'e min', a: formatValue(1.4), b: formatValue(0.94), difference: '-0.46' });
    expect(rowOf(rows, 'L3')).toEqual({ symbol: 'L3', a: '51.18', b: '66.55', difference: '15.37' });
    expect(rowOf(rows, 'P1')).toMatchObject({ a: '11.96', b: '13.03', difference: '1.07' });
    expect(rowOf(rows, 'G1')).toMatchObject({ a: '7.85', b: '7.85', difference: '0' });
    expect(compareDimensions(b, a, 'metric').find((row) => row.symbol === 'L3')!.difference).toBe('-15.37');
  });
  it('converts imperial values and differences with displayNumber, without rounding further', () => {
    const rows = compareDimensions(a, b, 'imperial');
    expect(tableUnit('imperial')).toBe('in');
    expect(rowOf(rows, 'L3')).toEqual({
      symbol: 'L3', a: displayNumber(51.18, 'in'), b: displayNumber(66.55, 'in'), difference: displayNumber(66.55 - 51.18, 'in')
    });
    expect(rowOf(rows, 'L3')!.a).toBe('2.01496062992');
    expect(rowOf(rows, 'G1')!.difference).toBe('0');
    for (const row of rows) {
      expect(row.symbol).not.toMatch(/Tol$/);
    }
  });
  it('is empty for two cartridges that publish no dimension', () => {
    const bare = { cartridge: {} } as unknown as Record_;
    expect(compareDimensions(bare, bare, 'metric')).toEqual([]);
  });
  it('lists the dimensions of the one that publishes any, against a bare one', () => {
    const bare = { cartridge: {} } as unknown as Record_;
    const rows = compareDimensions(bare, a, 'metric');
    expect(rows.map((row) => row.symbol)).toEqual(dimensionsOf(a).map((dimension) => dimension.symbol));
    expect(rows.every((row) => row.a === '' && row.difference === '' && row.b !== '')).toBe(true);
  });
});

describe('the overlaid profiles', () => {
  const draw = (x: string, y: string) => {
    const result = overlayOf(get(x), get(y));
    if (!result.ok) throw new Error(`${x} and ${y} cannot be drawn`);
    return result.overlay;
  };
  /** The vertical extent of every vertex of a path, in order. */
  const ys = (path: string) => [...path.matchAll(/[ML]([-\d.]+),([-\d.]+)/g)].map((match) => Number(match[2]));
  const xs = (path: string) => [...path.matchAll(/[ML]([-\d.]+),([-\d.]+)/g)].map((match) => Number(match[1]));

  it('draws both outlines in one viewBox, one scale, on one axis', () => {
    const overlay = draw('308_win', '300_win_mag');
    for (const path of [overlay.a, overlay.b]) {
      expect(path.startsWith('M')).toBe(true);
      expect(path.endsWith('Z')).toBe(true);
      expect(Math.min(...xs(path))).toBeGreaterThanOrEqual(0);
      expect(Math.max(...xs(path))).toBeLessThanOrEqual(overlay.width + 1e-6);
      expect(Math.max(...ys(path))).toBeLessThanOrEqual(overlay.height + 1e-6);
    }
    // Both outlines are symmetric about the one axis.
    for (const path of [overlay.a, overlay.b]) {
      expect((Math.min(...xs(path)) + Math.max(...xs(path))) / 2).toBeCloseTo(overlay.axis.x, 3);
    }
  });
  it('puts the head faces at the same height', () => {
    const overlay = draw('308_win', '9_mm_luger');
    expect(Math.max(...ys(overlay.a))).toBeCloseTo(Math.max(...ys(overlay.b)), 6);
    expect(Math.max(...ys(overlay.a))).toBeCloseTo(overlay.axis.y2, 6);
  });
  it('draws the longer case longer, at the same scale', () => {
    const overlay = draw('308_win', '9_mm_luger');
    const length = (path: string) => Math.max(...ys(path)) - Math.min(...ys(path));
    const mm = (key: string) => get(key).cartridge.lengths as Record<string, number>;
    expect(length(overlay.a) / length(overlay.b)).toBeCloseTo(mm('308_win').L3! / mm('9_mm_luger').L3!, 1);
    expect(length(overlay.a) / overlay.scale).toBeCloseTo(mm('308_win').L3!, 1);
  });
  it('is the same drawing whichever order the cartridges are named in', () => {
    const forward = draw('308_win', '9_mm_luger');
    const backward = draw('9_mm_luger', '308_win');
    expect(backward.a).toBe(forward.b);
    expect(backward.b).toBe(forward.a);
  });
  it('says why a pair cannot be drawn', () => {
    const shot = [...records.values()].find((record) => record.family === 'shotshell')!;
    expect(overlayOf(shot, get('308_win'))).toEqual({ ok: false, reason: 'shot', names: [shot.name] });
    const bare = { key: 'x', name: 'Bare', family: 'rimless', cartridge: {}, chamber: {} } as Record_;
    expect(overlayOf(get('308_win'), bare)).toEqual({ ok: false, reason: 'unpublished', names: ['Bare'] });
  });
  it('draws every pair of metallic cartridges that publish enough to be drawn at all', () => {
    const metallic = [...records.values()].filter((record) => record.family !== 'shotshell');
    const drawable = metallic.filter((record) => overlayOf(record, get('308_win')).ok);
    expect(drawable.length).toBeGreaterThan(metallic.length * 0.9);
    for (const record of drawable) {
      const overlay = (overlayOf(record, get('308_win')) as { ok: true; overlay: ReturnType<typeof draw> }).overlay;
      expect(Math.max(...ys(overlay.a))).toBeCloseTo(overlay.axis.y2, 6);
      expect(Math.max(...ys(overlay.b))).toBeCloseTo(overlay.axis.y2, 6);
    }
  });
});
