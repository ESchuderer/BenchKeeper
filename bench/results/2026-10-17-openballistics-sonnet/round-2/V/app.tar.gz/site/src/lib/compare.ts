/**
 * Two cartridges side by side: the table of the dimensions either publishes, and their outer profiles
 * overlaid in one drawing.
 *
 * Framework-free on purpose, so the page is only markup. Nothing here measures or draws anything
 * of its own: the profile is `caseOuterProfile`, the outline is `fullSectionPath` and the
 * viewport is `viewportFor`, so the two cases are the ones the cartridge page draws; the symbols,
 * the units a field is published in and the way a figure is written are `@lib/core`'s.
 */

import { FIELD_LABELS, FIELD_UNITS, GROUP_ORDER, formatValue, orderedFields, toleranceFor } from '@lib/core';
import type { Group, GroupList, Record_ } from '@lib/core';
import { fullSectionPath, viewportFor, type Profile } from '@lib/geom';
import { adaptMetallic, caseOuterProfile, type CartridgeRecord } from '@lib/shapes2d';
import { defaultUnit, displayNumber, type UnitSystem } from './units';

// ---- The table ------------------------------------------------------------------------------

export interface Dimension {
  /** The symbol as the detail page writes it: `e min`, `L3`. */
  symbol: string;
  /** Millimetres, as the record has it. */
  value: number;
}

export interface ComparisonRow {
  symbol: string;
  /** Empty where A does not publish the dimension. */
  a: string;
  /** Empty where B does not publish the dimension. */
  b: string;
  /** B minus A; empty unless both publish the dimension. */
  difference: string;
}

/**
 * Every dimension the record's cartridge part publishes, in the order the detail page lists them.
 *
 * A dimension is a number in a group of the cartridge side that is published in millimetres: a
 * field with a unit of its own (pressures, energies, angles) is not one, and neither is a
 * tolerance, which belongs to the dimension it follows. A repeating group is a shot cartridge's
 * and is not read. Should a symbol turn up in two groups the first one stands, so a symbol is a
 * row at most once.
 */
export function dimensionsOf(record: Pick<Record_, 'cartridge'>): Dimension[] {
  const side = (record.cartridge ?? {}) as Record<string, Group | GroupList>;
  const known = GROUP_ORDER.cartridge.filter((name) => name in side);
  const placed = new Set(known);
  const groups = [...known, ...Object.keys(side).filter((name) => !placed.has(name)).sort()];
  const found = new Map<string, number>();
  for (const name of groups) {
    const group = side[name];
    if (!group || Array.isArray(group)) continue;
    for (const field of orderedFields('cartridge', name, group)) {
      const value = group[field];
      if (typeof value !== 'number' || !Number.isFinite(value)) continue;
      if (toleranceFor(field) !== null || Object.hasOwn(FIELD_UNITS, field)) continue;
      const symbol = Object.hasOwn(FIELD_LABELS, field) ? FIELD_LABELS[field]! : field;
      if (!found.has(symbol)) found.set(symbol, value);
    }
  }
  return [...found].map(([symbol, value]) => ({ symbol, value }));
}

/** The unit the table is written in. Every dimension is published in millimetres. */
export function tableUnit(system: UnitSystem): 'mm' | 'in' {
  return defaultUnit('length', system) as 'mm' | 'in';
}

/**
 * One row per symbol either cartridge publishes. A's come in A's order; one only B publishes is
 * put after the symbol that precedes it in B (first, if none does), so it stays among its neighbours.
 * A cell of the cartridge that does not publish the dimension is empty, and so is the difference.
 *
 * Metric figures are written as the detail page writes them. Imperial ones are converted by
 * `displayNumber`, and so is the difference - which is converted from the millimetre difference
 * rather than subtracted from two inches, and goes through the same twelve significant digits as
 * everything else, so 11.96 less 11.53 is 0.43 and not 0.4300000000000015.
 */
export function compareDimensions(a: Pick<Record_, 'cartridge'>, b: Pick<Record_, 'cartridge'>, system: UnitSystem): ComparisonRow[] {
  const unit = tableUnit(system);
  const write = (value: number): string => (unit === 'mm' ? formatValue(value) : displayNumber(value, unit)) ?? '';
  const first = dimensionsOf(a);
  const second = dimensionsOf(b);
  const inA = new Map(first.map((dimension) => [dimension.symbol, dimension.value]));
  const inB = new Map(second.map((dimension) => [dimension.symbol, dimension.value]));
  const symbols = first.map((dimension) => dimension.symbol);
  second.forEach(({ symbol }, index) => {
    if (inA.has(symbol)) return;
    const before = index === 0 ? undefined : second[index - 1]!.symbol;
    symbols.splice(before === undefined ? 0 : symbols.indexOf(before) + 1, 0, symbol);
  });
  return symbols.map((symbol) => {
    const one = inA.get(symbol);
    const other = inB.get(symbol);
    return {
      symbol,
      a: one === undefined ? '' : write(one),
      b: other === undefined ? '' : write(other),
      difference: one === undefined || other === undefined ? '' : displayNumber(other - one, unit)
    };
  });
}

// ---- The drawing ----------------------------------------------------------------------------

/** What the page draws: one outline each, in the user units of one viewBox. */
export interface Overlay {
  width: number;
  height: number;
  a: string;
  b: string;
  /** The common axis of both cases. */
  axis: { x: number; y1: number; y2: number };
  /** Pixels per millimetre, the same for both. */
  scale: number;
}

export type OverlayResult =
  | { ok: true; overlay: Overlay }
  | { ok: false; reason: 'shot' | 'unpublished'; /** The names of the records that cannot be drawn. */ names: string[] };

/** The tallest the drawing is made, in pixels; the scale is whatever makes the longer case fit. */
const MAX_HEIGHT_PX = 480;
const MAX_SCALE = 12;
const MARGIN_MM = 3;

/** The case as `caseOuterProfile` computes it, or why it cannot be. */
function outlineOf(record: Record_): Profile | 'shot' | 'unpublished' {
  if (record.family === 'shotshell') return 'shot';
  try {
    return caseOuterProfile(adaptMetallic(record as unknown as CartridgeRecord));
  } catch {
    return 'unpublished';
  }
}

/**
 * The two cases overlaid: one scale, one axis, and the head faces (z = 0 in both profiles) at the
 * same height. The outline is the closed silhouette, the profile mirrored about the axis.
 */
export function overlayOf(a: Record_, b: Record_): OverlayResult {
  const outlines = [outlineOf(a), outlineOf(b)] as const;
  const failed = [a, b].filter((_, index) => typeof outlines[index] === 'string');
  if (failed.length) {
    const reasons = outlines.filter((outline) => typeof outline === 'string');
    return { ok: false, reason: reasons.includes('shot') ? 'shot' : 'unpublished', names: failed.map((record) => record.name) };
  }
  const [first, second] = outlines as [Profile, Profile];
  const length = Math.max(...[...first, ...second].map(([, z]) => z));
  const scale = Math.min(MAX_SCALE, MAX_HEIGHT_PX / (length + 2 * MARGIN_MM));
  const view = viewportFor([first, second], { scale, marginMm: MARGIN_MM, frame: 'upright' });
  const [x, top] = view.xy(0, view.zMax);
  const [, bottom] = view.xy(0, view.zMin);
  return {
    ok: true,
    overlay: {
      width: view.width,
      height: view.height,
      a: fullSectionPath(first, view),
      b: fullSectionPath(second, view),
      axis: { x, y1: top, y2: bottom },
      scale
    }
  };
}
