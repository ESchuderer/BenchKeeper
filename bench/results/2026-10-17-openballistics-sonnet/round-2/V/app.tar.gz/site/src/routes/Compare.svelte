<script lang="ts">
  import PageHeader from '../components/PageHeader.svelte';
  import PageLoadError from '../components/PageLoadError.svelte';
  import { compareDimensions, overlayOf, tableUnit } from '../lib/compare';
  import { byKey, load } from '../lib/data';
  import { t } from '../lib/i18n.svelte';
  import { href } from '../lib/router';
  import { unitSystem } from '../lib/units.svelte';

  interface Props {
    /** The keys of the two cartridges, as `#/c/<key>` has them. */
    a: string;
    b: string;
  }
  let { a, b }: Props = $props();

  const missing = $derived([a, b].find((key) => !byKey(key)));
  const records = $derived(missing ? null : Promise.all([load(a), load(b)]));
</script>

<div data-ui="Compare" class="contents">
  {#if missing}
    <p class="status error" role="alert">
      {t('compare.unknown', { key: missing })} <a href={href.list()}>{t('record.back')}</a>
    </p>
  {:else}
    {#await records}
      <p class="status">{t('compare.loading', { a: byKey(a)?.name ?? a, b: byKey(b)?.name ?? b })}</p>
    {:then pair}
      {@const [first, second] = pair!}
      {@const drawing = overlayOf(first, second)}
      {@const system = unitSystem()}
      {@const rows = compareDimensions(first, second, system)}
      <PageHeader
        title={t('compare.heading', { a: first.name, b: second.name })}
        description={t('compare.lede')}
        eyebrow={t('compare.title')}
        backHref={href.cartridge(a)}
        backLabel={t('compare.back', { name: first.name })}
      />

      <div class="grid items-start gap-8 lg:grid-cols-[minmax(0,5fr)_minmax(0,7fr)]">
        <figure class="m-0 flex min-w-0 flex-col items-center gap-3 rounded-lg border bg-card p-4">
          {#if drawing.ok}
            {@const { overlay } = drawing}
            <svg
              role="img"
              aria-label={t('compare.profiles', { a: first.name, b: second.name })}
              width={overlay.width}
              height={overlay.height}
              viewBox={`0 0 ${overlay.width} ${overlay.height}`}
              class="outlines"
            >
              <line class="axis" x1={overlay.axis.x} y1={overlay.axis.y1} x2={overlay.axis.x} y2={overlay.axis.y2} />
              <path class="outline a" d={overlay.a} />
              <path class="outline b" d={overlay.b} />
            </svg>
            <figcaption class="flex flex-col items-center gap-2 text-sm">
              <ul class="m-0 flex list-none flex-wrap justify-center gap-x-5 gap-y-1 p-0">
                <li class="key a">{first.name}</li>
                <li class="key b">{second.name}</li>
              </ul>
              <span class="text-xs text-muted-foreground">{t('compare.axis')}</span>
            </figcaption>
          {:else}
            <p class="m-0 text-sm text-muted-foreground">
              {t(drawing.reason === 'shot' ? 'compare.shot' : 'compare.unpublished', { names: drawing.names.join(', ') })}
            </p>
          {/if}
        </figure>

        <div class="min-w-0">
          {#if rows.length}
            <div class="overflow-x-auto">
              <table class="w-full border-collapse text-sm">
                <caption class="pb-2 text-left font-semibold">{t('compare.table', { unit: tableUnit(system) })}</caption>
                <thead>
                  <tr>
                    <th scope="col" class="text-left">{t('compare.symbol')}</th>
                    <th scope="col" class="text-right">{first.name}</th>
                    <th scope="col" class="text-right">{second.name}</th>
                    <th scope="col" class="text-right">{t('compare.difference')}</th>
                  </tr>
                </thead>
                <tbody>
                  {#each rows as row (row.symbol)}
                    <tr>
                      <th scope="row" class="num text-left font-normal">{row.symbol}</th>
                      <td class="num text-right">{row.a}</td>
                      <td class="num text-right">{row.b}</td>
                      <td class="num text-right">{row.difference}</td>
                    </tr>
                  {/each}
                </tbody>
              </table>
            </div>
            <p class="mt-2 text-xs text-muted-foreground">{t('compare.differenceNote', { a: first.name, b: second.name })}</p>
          {:else}
            <p class="m-0 text-sm text-muted-foreground">{t('compare.noCommon')}</p>
          {/if}
        </div>
      </div>
    {:catch}
      <PageLoadError />
    {/await}
  {/if}
</div>

<style>
  @layer legacy {
    :global([data-ui="Compare"] th),
    :global([data-ui="Compare"] td) { padding: 0.35rem 0.6rem; border-bottom: 1px solid var(--rule); }
    /* The figures line up on their right edge, as in the detail page's tables; the symbol stays left. */
    :global([data-ui="Compare"] :is(th, td):not(:first-child)) { text-align: right; }
    :global([data-ui="Compare"] thead th) { color: var(--ink-2); font-weight: 600; border-bottom-color: var(--rule-strong); }
    :global([data-ui="Compare"] .outlines) { max-width: 100%; height: auto; }
    /* Two hues that stay apart for the common colour-vision deficiencies, and B dashed besides,
       so the outlines are told apart without colour as well. */
    :global([data-ui="Compare"] .outline) { fill: none; stroke-width: 2; stroke-linejoin: round; }
    :global([data-ui="Compare"] .outline.a) { stroke: var(--compare-a); }
    :global([data-ui="Compare"] .outline.b) { stroke: var(--compare-b); stroke-dasharray: 7 4; }
    :global([data-ui="Compare"] .axis) { stroke: var(--rule-strong); stroke-width: 1; stroke-dasharray: 2 4; }
    :global([data-ui="Compare"] .key) { display: inline-flex; align-items: center; gap: 0.5rem; }
    :global([data-ui="Compare"] .key::before) { content: ''; width: 1.6rem; border-top: 2px solid; }
    :global([data-ui="Compare"] .key.a::before) { border-color: var(--compare-a); }
    :global([data-ui="Compare"] .key.b::before) { border-color: var(--compare-b); border-top-style: dashed; }
    :global([data-ui="Compare"]) { --compare-a: #1d4ed8; --compare-b: #c2410c; }
    :global(:root[data-theme='dark'] [data-ui="Compare"]) { --compare-a: #7aa2ff; --compare-b: #fb923c; }
  }
</style>
