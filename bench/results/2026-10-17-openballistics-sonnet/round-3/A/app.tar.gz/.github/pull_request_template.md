<!-- The title becomes the commit message on main. Use: <type>(<scope>): <summary>
     for example "fix(data): correct the 308 Win. case length". See CONTRIBUTING.md. -->

## What and why


## Source (for changes to `data/`)

<!-- The C.I.P. sheet and its revision date, a manufacturer's page, a measurement and the
     instrument used. A value that cannot be checked will be asked about. -->

## Checked

- [ ] `npm test` passes (run from `site/`)
- [ ] `npm run build` passes
- [ ] The title follows the commit convention
