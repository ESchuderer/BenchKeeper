#!/usr/bin/env bash
# Print the CHANGELOG.md section of one release, for use as the GitHub release notes.
#
# Usage: .github/scripts/release-notes.sh <version> [changelog]
#   <version>   without the leading "v", e.g. 0.2.0
#   [changelog] defaults to CHANGELOG.md
#
# Reads from the "## [<version>]" heading to the next "## [" heading or to the link reference
# definitions at the end of the file. Exits non-zero when the section is missing or has no
# content, so a release cannot be published without its changelog entry.
set -euo pipefail

version="${1:?usage: release-notes.sh <version> [changelog]}"
changelog="${2:-CHANGELOG.md}"

notes="$(
  awk -v heading="## [${version}]" '
    index($0, heading) == 1 { found = 1; next }
    found && (/^## \[/ || /^\[[^]]+\]: /) { exit }
    found { print }
  ' "$changelog"
)"

# Trim blank lines at both ends.
notes="$(printf '%s\n' "$notes" | sed -e '/./,$!d' | sed -e ':a' -e '/^\n*$/{$d;N;ba' -e '}')"

if [[ -z "${notes//[[:space:]]/}" ]]; then
  echo "error: ${changelog} has no section, or an empty one, for version ${version}" >&2
  exit 1
fi

printf '%s\n' "$notes"
