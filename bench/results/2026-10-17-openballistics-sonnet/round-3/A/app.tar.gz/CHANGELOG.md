# Changelog

All notable changes to OpenBallistics are recorded here.

The format follows [Keep a Changelog 1.1.0](https://keepachangelog.com/en/1.1.0/), and the project
follows [Semantic Versioning 2.0.0](https://semver.org/spec/v2.0.0.html); what counts as a major,
minor or patch change for a dataset and a website is set out in
[CONTRIBUTING.md](CONTRIBUTING.md#versioning).

Each release has a `## [X.Y.Z] - YYYY-MM-DD` heading, newest first, and groups its entries under
these headings, leaving out any that are empty: **Added**, **Changed**, **Deprecated**,
**Removed**, **Fixed**, **Security**. Entries are written for people who use the data or the
site, not copied from commit subjects. Unreleased work collects under `## [Unreleased]`.

## [Unreleased]

### Added

- Continuous integration, deployment of the site to GitHub Pages, tag-triggered releases and
  automated dependency updates.
- Contributor documentation: install, develop, test and build instructions, how to contribute
  data, and the commit convention.

[Unreleased]: https://github.com/PiMetry/OpenBallistics/commits/main
