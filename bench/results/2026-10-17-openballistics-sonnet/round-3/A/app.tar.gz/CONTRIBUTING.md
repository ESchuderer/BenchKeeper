# Contributing

Thank you for helping. This file covers the rules a pull request is held to and how the project is
versioned and released. How to install, run, test and build, and how to fix a record in `data/`, is in
the [README](README.md).

## Before you open a pull request

1. Branch from `main` and keep the pull request to one change.
2. Run, from `site/`:
   ```sh
   npm test
   npm run build
   ```
   CI runs exactly these two commands on every pull request, so a failure there will fail here too.
3. Title the pull request following the convention below.
4. For a change to `data/`, give the source of the new value in the description.
5. Leave `CHANGELOG.md` and the version alone; the maintainer who makes the release writes the
   changelog entry from the commit history (see [Making a release](#making-a-release)). Two pull
   requests that both edit the same changelog line cannot both merge cleanly.

## What CI checks

`.github/workflows/ci.yml` runs on every pull request, with a read-only token and no secrets:

| Job | Checks |
| --- | --- |
| `check` | `npm ci`, `npm test` and `npm run build` in `site/`, on the Node version in `.nvmrc` |
| `pull-request-title` | The title follows the convention below |

Pull requests are **squash-merged**, so the pull request title becomes the commit message on `main`.
Commits inside your branch may be as untidy as you like, but if you would rather they be tidy, they
may follow the same convention.

## Commit messages and pull request titles

The project uses [Conventional Commits 1.0.0](https://www.conventionalcommits.org/en/v1.0.0/):

```
<type>(<scope>): <summary>

<optional body: what and why, wrapped at 72 characters>

<optional footers>
```

- **type** is one of the following.

  | Type | Use it for |
  | --- | --- |
  | `feat` | A new feature, or new records in `data/` |
  | `fix` | A bug fix, or a correction to an existing record |
  | `docs` | Documentation only |
  | `style` | Formatting that changes no behaviour |
  | `refactor` | Code restructuring that changes no behaviour |
  | `perf` | A performance improvement |
  | `test` | Adding or changing tests only |
  | `build` | The build, the scripts or the dependencies that make the site |
  | `ci` | Workflows and other CI configuration |
  | `chore` | Anything else that does not touch the data or the site's behaviour, including releases |
  | `revert` | Reverting an earlier commit; name it in the body |

- **scope** is optional, in lower case, and says what part is touched: `data`, `lib`, `site`, `ci`,
  `docs` or `release`, or something narrower such as `targets` or `designer`. Dependabot uses `deps` and
  `deps-dev`.
- **summary** is in the imperative ("correct", not "corrected"), starts with a lower-case letter
  unless it begins with a proper name, has no full stop, and keeps the whole first line to 72
  characters in a commit and 100 in a pull request title.
- A **breaking change** adds `!` after the type or scope, and a `BREAKING CHANGE:` footer saying what
  breaks and what to do about it. See [Versioning](#versioning) for what counts.

Examples:

```
fix(data): correct the 308 Win. case length from the 2008 C.I.P. sheet
feat(data): add the 6.5 PRC cartridge
feat(site): show the technical drawing on the cartridge page
refactor(lib): move the interior fit into measure2d
test(targets): cover scoring on the ring boundary
ci: cache npm downloads
chore(release): v0.2.0
feat(data)!: rename the key of the .38 Special record

BREAKING CHANGE: the key 38_special is now 38_spl; links and exports that use it must be updated.
```

The pull request check uses the pattern
`^(feat|fix|docs|style|refactor|perf|test|build|ci|chore|revert)(\([a-z0-9][a-z0-9._-]*\))?!?: [^[:space:]].*$`.

## Versioning

The project follows [Semantic Versioning 2.0.0](https://semver.org/spec/v2.0.0.html).

**The version is kept in one place: `version` in `site/package.json`** (`npm version` also writes it into
`site/package-lock.json`). Nothing else holds a copy. A release is the Git tag `v` + that version, and
the release workflow refuses a tag that does not match it.

The public interface that a version number promises is the **data**, because other people read the
records, and the site's shareable links, such as `#/c/<key>`.

| Bump | When | Conventional Commits that cause it |
| --- | --- | --- |
| Major | A record's `key`, file name or folder changes or goes; a field is renamed, moved or changes its unit or meaning; a site link stops working | Any commit marked `!` or with a `BREAKING CHANGE:` footer |
| Minor | New records, new fields, new site features or tools | `feat` |
| Patch | A corrected value, a drawing or a bug fix, a performance improvement | `fix`, `perf` |

`docs`, `test`, `ci`, `build`, `chore`, `style` and `refactor` do not by themselves call for a
release. While the version is below 1.0.0, a breaking change raises the minor number instead of the
major one.

The first release is `v0.1.0`, the version `site/package.json` already carries.

## Changelog

[`CHANGELOG.md`](CHANGELOG.md) follows [Keep a Changelog 1.1.0](https://keepachangelog.com/en/1.1.0/):
newest release first, each headed `## [X.Y.Z] - YYYY-MM-DD`, with entries under **Added**,
**Changed**, **Deprecated**, **Removed**, **Fixed** and **Security**, and an `## [Unreleased]` section on
top. Link references at the bottom give a comparison URL for each version. Entries describe the
effect for someone who uses the data or the site; they are not pasted commit subjects. Breaking
changes go first in their section and start with **Breaking:**.

## Making a release

For maintainers. A release is a tag pushed to `main`; `.github/workflows/release.yml` does the rest.

1. Decide the version from the commits since the last tag, using the table above:
   ```sh
   git log --pretty='%s' vPREVIOUS..main
   ```
   (For the first release, use `git log --pretty='%s' main`.)
2. On a branch, write the release into `CHANGELOG.md`: move the `[Unreleased]` entries under a new
   `## [X.Y.Z] - YYYY-MM-DD` heading, leave `[Unreleased]` empty, and update the link references:
   ```
   [Unreleased]: https://github.com/PiMetry/OpenBallistics/compare/vX.Y.Z...HEAD
   [X.Y.Z]: https://github.com/PiMetry/OpenBallistics/compare/vPREVIOUS...vX.Y.Z
   ```
   For the first release, the link for `[0.1.0]` is
   `https://github.com/PiMetry/OpenBallistics/releases/tag/v0.1.0`.
3. Set the version, from `site/`, unless it already is the version you want (as it is for `v0.1.0`):
   ```sh
   npm version X.Y.Z --no-git-tag-version
   ```
4. Preview the release notes, which are the section you wrote, exactly as GitHub will show them:
   ```sh
   .github/scripts/release-notes.sh X.Y.Z
   ```
5. Commit as `chore(release): vX.Y.Z`, open a pull request, and merge it.
6. Tag the merge commit on `main` and push the tag:
   ```sh
   git switch main
   git pull
   git tag -a vX.Y.Z -m "vX.Y.Z"
   git push origin vX.Y.Z
   ```

The workflow then checks that the tag is `vMAJOR.MINOR.PATCH` (or with a pre-release suffix such as
`-rc.1`, which makes a GitHub pre-release), that it matches `site/package.json`, that its commit is on
`main`, and that the changelog has a section for it. It runs `npm test` and `npm run build`, and
creates the GitHub release with the changelog section as its notes and three files: the data
(`openballistics-data-vX.Y.Z.tar.gz`), the built site (`openballistics-site-vX.Y.Z.tar.gz`) and
`SHA256SUMS`.

If a check fails, nothing is published. Fix the cause on `main`, then delete the tag with
`git tag -d vX.Y.Z` and `git push --delete origin vX.Y.Z`, and tag again.

The site on GitHub Pages is not part of the release: it is deployed from `main` by
`.github/workflows/pages.yml` after every merge.

## Dependency updates

Dependabot (`.github/dependabot.yml`) opens a weekly pull request for the npm packages in `site/` and
another for the GitHub Actions used in the workflows. The vite, vitest and Tailwind packages move
together in one pull request; other minor and patch updates are grouped, and other major updates come
one at a time. They go through the same CI as any other pull request. The workflows pin each action to
a commit SHA with the version in a comment; Dependabot updates both.

## Repository settings

The workflows expect these settings, which no file in the repository can set:

- **Settings → Pages → Build and deployment → Source:** `GitHub Actions`.
- **Branch protection on `main`:** require a pull request, and require the status checks `check` and
  `pull-request-title`.
- **Pull requests:** allow squash merging only, with the default commit message set to *Pull request
  title*, so that the title the check validated is the message that lands on `main`.
- **Actions → General → Fork pull request workflows:** require approval for first-time contributors.
- **Code security:** enable Dependabot alerts and security updates.
- A tag ruleset protecting `v*` is worth adding so a released tag cannot be moved.
