# OpenBallistics

An open database of cartridges, bullets and targets, with a website to browse it.

- **`data/`**: the database. One JSON record per cartridge, bullet and target face.
- **`lib/`**: shared TypeScript libraries: geometry, drawing, target scoring, designers and user-data import and export.
- **`site/`**: the website, written in Svelte 5 with Vite and Tailwind CSS.

The cartridge and chamber dimensions are the figures published in the C.I.P. Tables of Dimensions of
Cartridges and Chambers; the target faces follow the BDS and DSB rule books. OpenBallistics is
independent of C.I.P., BDS and DSB. Every value in the data should be traceable to a source, and
corrections that name theirs are the most useful contribution there is.

The site is deployed to GitHub Pages from `main`.

## Repository layout

| Path | Contents |
| --- | --- |
| `data/cartridges/<family>/` | Cartridge records, grouped into `belted`, `pistol`, `rimfire`, `rimless`, `rimmed` and `shotshell` |
| `data/bullets/` | Bullet records; the public catalogue is currently a set of synthetic samples, see [`data/bullets/README.md`](data/bullets/README.md) |
| `data/targets/` | Target faces, with the rule book each one comes from |
| `lib/` | Framework-free libraries; tests next to the code; a test enforces that they never import the UI framework |
| `site/` | The website, its build scripts (`site/scripts/`) and its tests (`site/src/`) |
| `fixtures/` | Reference files for the drawing tests; not shipped with the site |

There is no `package.json` at the repository root. The only package is `site/`, which also runs the
tests for `lib/`, so **every `npm` command below is run from `site/`**.

## Getting started

You need [Node.js](https://nodejs.org/) 22 (the version in [`.nvmrc`](.nvmrc), and the one CI uses) and
npm, which comes with it.

```sh
cd site
npm ci
```

`npm ci` installs exactly what `site/package-lock.json` says. Use `npm install` only when you mean to
change a dependency, and commit the lockfile with the change.

## Develop

```sh
npm run dev
```

This generates the search indexes from `data/`, then starts the Vite dev server, which prints a local
address (by default <http://localhost:5173/>). The server also serves the records in `data/` as the
site will, so an edit to a record shows up after a reload.

The indexes (`site/src/lib/*.generated.json`) and the country flags (`site/public/flags/`) are
generated, ignored by Git, and rebuilt by `dev`, `test` and `build`. Do not commit them. To rebuild
them by hand:

| Command | What it does |
| --- | --- |
| `npm run prepare-data` | Both of the steps below |
| `npm run index` | Rebuilds the cartridge, bullet and flag indexes from `data/` |
| `npm run fieldsets` | Works out which fields each cartridge family has, for the cartridge designer |
| `npm run sample-bullets` | Regenerates the synthetic sample bullets in `data/bullets/`; see the note on bullets below |

## Test

```sh
npm test
```

This is what CI runs. It prepares the indexes, then runs [Vitest](https://vitest.dev/) over the site's
tests in `site/src/` and the libraries' tests in `lib/`, including checks of the records in `data/`.
To run one file, pass it after `--`:

```sh
npm test -- src/lib/units.test.ts
```

## Build

```sh
npm run build
```

This prepares the indexes, type-checks with `svelte-check`, and writes the site to `site/dist/`.
CI runs it too, so a pull request that does not build cannot merge. To look at the result:

```sh
npm run preview
```

The site is built for the root of a domain by default. For a project page such as
`https://<user>.github.io/OpenBallistics/`, set the base path:

```sh
PAGES_BASE=/OpenBallistics/ npm run build
```

The deployment workflow does this for you.

## Contribute data

There are two ways, and both are welcome.

**Report a problem.** On the site, every cartridge and bullet page has a link that opens a prefilled
issue. Or [open an issue](https://github.com/PiMetry/OpenBallistics/issues/new/choose) with the *cartridge*, *bullet* or *site* form. Say
what is wrong and **where the right figure is published**: the C.I.P. sheet and its revision date, a
manufacturer's page, a measurement and the instrument used.

**Send a fix.** Edit the JSON record and open a pull request.

1. Find the record: `data/cartridges/<family>/<key>.json`, `data/bullets/<key>.json` or
   `data/targets/<id>.json`. A cartridge's file name is its `key` and its folder is its `family`; a
   target's file name is its `id`. The site looks records up by these, and a test checks it for
   targets, so keep them in step.
2. Copy the units and the formatting of the records around it. Cartridge records use two-space
   indentation and keys in alphabetical order; see
   [`data/cartridges/rimless/308_win.json`](data/cartridges/rimless/308_win.json) for a full example.
3. Run `npm test` from `site/`. Some tests state how many records the catalogue holds; if you add or
   remove one, update the count in the test in the same pull request.
4. Put the source in the pull request description. A change that cannot be checked against a source
   will be asked for one.
5. Title the pull request `fix(data): ...` for a correction or `feat(data): ...` for new records; see
   the [commit convention](CONTRIBUTING.md#commit-messages-and-pull-request-titles).

The bullets in `data/bullets/` are generated samples with no manufacturer behind them, so do not
edit them by hand: change `site/scripts/sample-bullets.ts` and run `npm run sample-bullets`. If you
want to propose real bullet records, open a bullet issue first so the approach can be agreed.

## Contributing code

Fork, branch, and open a pull request against `main`. [CONTRIBUTING.md](CONTRIBUTING.md) covers what CI
checks, the commit convention (**Conventional Commits**), how versions and releases work, and the
one-off repository settings the workflows expect.

## Releases

Versions follow [Semantic Versioning](https://semver.org/). The version lives in
`site/package.json` and a release is a Git tag `vX.Y.Z` pushed to `main`, which triggers
`.github/workflows/release.yml`. What changed in each release is in [CHANGELOG.md](CHANGELOG.md), which
follows [Keep a Changelog](https://keepachangelog.com/en/1.1.0/). The process is in
[CONTRIBUTING.md](CONTRIBUTING.md#making-a-release).

## License

MIT, Copyright (c) 2026 PiMetry; see [LICENSE](LICENSE). By contributing you agree that your
contribution is released under the same licence.

The website redistributes the country flags (flag-icons), Svelte and the IBM Plex typefaces; their
licences and notices are in [THIRD-PARTY.md](THIRD-PARTY.md), which the build also copies into the site.
