import { readdirSync, readFileSync } from 'node:fs';
import { join } from 'node:path';
import { describe, expect, it } from 'vitest';
import { CARTRIDGES } from '../../../lib/testing/fixtures';
import type { Record_ } from '@lib/core';
import { differenceText, dimensionRows, lengthText, outerProfileOf, overlay } from './compare';

function record(key: string): Record_ {
  for (const family of readdirSync(CARTRIDGES)) {
    try {
      return JSON.parse(readFileSync(join(CARTRIDGES, family, `${key}.json`), 'utf8'));
    } catch {
      // Not in this family.
    }
  }
  throw new Error(`no record ${key}`);
}

const a = record('308_win');
const b = record('300_win_mag');

describe('dimension rows', () => {
  const rows = dimensionRows(a, b);
  const symbols = rows.map((row) => row.symbol);

  it('lists the millimetre dimensions either record publishes, written as the detail page writes them', () => {
    expect(symbols).toContain('L3');
    expect(symbols).toContain('e min');
    expect(symbols).not.toContain('eMin');
    expect(new Set(symbols).size).toBe(symbols.length);
  });

  it('leaves out tolerances, other units, angles and the chamber', () => {
    for (const symbol of ['Pmax', 'PE', 'M', 'α', 'δ', 'β', 'Q', 'F + Tol', 'R Tol', 'RTol', 'L3Tol']) {
      expect(symbols).not.toContain(symbol);
    }
  });

  it('carries the published numbers', () => {
    const cartridge = (r: Record_) => r.cartridge as Record<string, Record<string, number>>;
    const l3 = rows.find((row) => row.symbol === 'L3')!;
    expect(l3.a).toBe(cartridge(a).lengths!.L3);
    expect(l3.b).toBe(cartridge(b).lengths!.L3);
  });

  it('lists a dimension only one record publishes, with nothing for the other', () => {
    const deltaL = rows.find((row) => row.symbol === 'delta L')!;
    const r3 = rows.find((row) => row.symbol === 'R3')!;
    expect(deltaL.a).not.toBeNull();
    expect(deltaL.b).toBeNull();
    expect(r3.a).toBeNull();
    expect(r3.b).not.toBeNull();
  });

  it("keeps A's order and puts a symbol only B publishes after its predecessor in B", () => {
    const left: Record_ = { ...a, cartridge: { lengths: { L3: 10, L4: 5 } } };
    const right: Record_ = { ...b, cartridge: { lengths: { L3: 12 }, collar: { H1: 1 } } };
    expect(dimensionRows(left, right)).toEqual([
      { symbol: 'L3', a: 10, b: 12 },
      { symbol: 'H1', a: null, b: 1 },
      { symbol: 'L4', a: 5, b: null }
    ]);
  });

  it('skips nulls, strings and repeating groups', () => {
    const left: Record_ = { ...a, cartridge: { lengths: [{ l: 1 }] as never, collar: { H1: null, H2: 'x' as never } } };
    expect(dimensionRows(left, left)).toEqual([]);
  });
});

describe('written values', () => {
  it('writes metric values as the record has them and the difference without float noise', () => {
    expect(lengthText(11.96, 'metric')).toBe('11.96');
    expect(differenceText(11.94, 11.96, 'metric')).toBe('0.02');
    expect(differenceText(11.96, 11.94, 'metric')).toBe('-0.02');
    expect(differenceText(5, 5, 'metric')).toBe('0');
  });

  it('writes nothing for a length a cartridge does not publish, nor a difference without both', () => {
    expect(lengthText(null, 'metric')).toBe('');
    expect(lengthText(null, 'imperial')).toBe('');
    expect(differenceText(null, 5, 'metric')).toBe('');
    expect(differenceText(5, null, 'imperial')).toBe('');
  });

  it('converts imperial lengths and differences from millimetres, without rounding', () => {
    expect(lengthText(25.4, 'imperial')).toBe('1');
    expect(lengthText(11.96, 'imperial')).toBe(String(Number((11.96 / 25.4).toPrecision(12))));
    expect(differenceText(25.4, 50.8, 'imperial')).toBe('1');
    expect(differenceText(50.8, 25.4, 'imperial')).toBe('-1');
  });
});

/** Every coordinate pair of a path of `M`/`L` commands. */
function points(path: string): [number, number][] {
  return [...path.matchAll(/[ML]([-\d.e]+),([-\d.e]+)/g)].map((m) => [Number(m[1]), Number(m[2])]);
}

describe('profile overlay', () => {
  const first = outerProfileOf(a)!;
  const second = outerProfileOf(b)!;
  const frame = overlay(first, second);

  it('draws each case as one closed outline', () => {
    for (const path of [frame.a, frame.b]) {
      expect(path.match(/M/g)).toHaveLength(1);
      expect(path.endsWith('Z')).toBe(true);
    }
  });

  it('puts the head faces on one line and both cases on one axis', () => {
    const [headA, headB] = [first, second].map((profile) => profile[0]![1]);
    expect(headA).toBe(0);
    expect(headB).toBe(0);
    const xa = points(frame.a).map(([x]) => x);
    const xb = points(frame.b).map(([x]) => x);
    expect(Math.min(...xa)).toBeCloseTo(Math.min(...xb), 6);
    const ya = points(frame.a).map(([, y]) => y);
    const yb = points(frame.b).map(([, y]) => y);
    // Both outlines are symmetric about the axis.
    expect((Math.min(...ya) + Math.max(...ya)) / 2).toBeCloseTo(frame.axis.y, 6);
    expect((Math.min(...yb) + Math.max(...yb)) / 2).toBeCloseTo(frame.axis.y, 6);
  });

  it('uses one scale, a user unit being a millimetre', () => {
    const length = (profile: [number, number][]) => Math.max(...profile.map(([, z]) => z));
    const span = (path: string) => {
      const xs = points(path).map(([x]) => x);
      return Math.max(...xs) - Math.min(...xs);
    };
    expect(span(frame.a)).toBeCloseTo(length(first), 5);
    expect(span(frame.b)).toBeCloseTo(length(second), 5);
    const ys = points(frame.b).map(([, y]) => y);
    expect(Math.max(...ys) - Math.min(...ys)).toBeCloseTo(2 * Math.max(...second.map(([r]) => r)), 5);
  });

  it('draws no profile for a shot cartridge or a sheet without a case', () => {
    expect(outerProfileOf(record('12'))).toBeNull();
    expect(outerProfileOf({ ...a, cartridge: {} })).toBeNull();
  });
});
