/**
 * What the comparison view shows, worked out away from the page so that it can be tested.
 *
 * Two cartridges, the dimensions either of them publishes, and their cases drawn one over the other.
 * Nothing here rounds a published figure: a value is written as the detail page writes it, and the
 * only arithmetic is the difference, which `displayNumber` cleans of floating-point noise
 * (11.96 - 11.94 is not 0.02 in a double) without dropping a digit the sheets print.
 */

import { FIELD_LABELS, FIELD_UNITS, GROUP_ORDER, formatValue, orderedFields, type Record_ } from '@lib/core';
import { fullSectionPath, viewportFor, type Profile } from '@lib/geom';
import { adaptMetallic, caseOuterProfile, type CartridgeRecord } from '@lib/shapes2d/case';
import { displayNumber } from './units';
import type { UnitSystem } from './units';

export interface DimensionRow {
  /** The symbol as the detail page writes it: `e min`, `L3`. */
  symbol: string;
  /** `null` where the first cartridge does not publish the dimension. */
  a: number | null;
  /** `null` where the second cartridge does not publish the dimension. */
  b: number | null;
}

/** The numbers of a record's `cartridge` part that are lengths in millimetres, by symbol. */
function dimensionsOf(record: Record_): Map<string, number> {
  const found = new Map<string, number>();
  const groups = record.cartridge as Record<string, unknown>;
  const known = GROUP_ORDER.cartridge.filter((name) => name in groups);
  const rest = Object.keys(groups).filter((name) => !known.includes(name)).sort();
  for (const name of [...known, ...rest]) {
    const group = groups[name];
    // A repeating group is a table of rows, not a symbol with a value.
    if (!group || typeof group !== 'object' || Array.isArray(group)) continue;
    for (const field of orderedFields('cartridge', name, group as Record<string, unknown>)) {
      const value = (group as Record<string, unknown>)[field];
      if (typeof value !== 'number' || !Number.isFinite(value)) continue;
      if (field.endsWith('Tol') || Object.hasOwn(FIELD_UNITS, field)) continue;
      const symbol = FIELD_LABELS[field] ?? field;
      if (!found.has(symbol)) found.set(symbol, value);
    }
  }
  return found;
}

/**
 * One row per dimension symbol either cartridge publishes. The rows follow the order the detail
 * page lists A's dimensions in; a symbol only B publishes goes after the one before it in B's list.
 */
export function dimensionRows(a: Record_, b: Record_): DimensionRow[] {
  const first = dimensionsOf(a);
  const second = dimensionsOf(b);
  const symbols = [...first.keys()];
  let previous = -1;
  for (const symbol of second.keys()) {
    let at = symbols.indexOf(symbol);
    if (at < 0) {
      at = previous + 1;
      symbols.splice(at, 0, symbol);
    }
    previous = at;
  }
  return symbols.map((symbol) => ({ symbol, a: first.get(symbol) ?? null, b: second.get(symbol) ?? null }));
}

/** A published length as the reader's unit setting has it: the record's own text, or inches. */
export function lengthText(millimetres: number | null, system: UnitSystem): string {
  if (millimetres === null) return '';
  return system === 'imperial' ? displayNumber(millimetres, 'in') : (formatValue(millimetres) ?? '');
}

/** B minus A, converted the way a length is; empty unless both cartridges publish the dimension. */
export function differenceText(a: number | null, b: number | null, system: UnitSystem): string {
  if (a === null || b === null) return '';
  return displayNumber(b - a, system === 'imperial' ? 'in' : 'mm');
}

export interface Overlay {
  /** The viewBox is in millimetres, so one user unit is one millimetre in both outlines. */
  width: number;
  height: number;
  a: string;
  b: string;
  /** The common axis, as the two ends of a horizontal line. */
  axis: { x1: number; x2: number; y: number };
}

/**
 * The outer profile of a case, head face to mouth, as `caseOuterProfile` computes it; or `null`
 * for a record that cannot be drawn (a shot cartridge, or a sheet that leaves out what the case
 * needs).
 */
export function outerProfileOf(record: Record_): Profile | null {
  if (record.family === 'shotshell') return null;
  try {
    return caseOuterProfile(adaptMetallic(record as unknown as CartridgeRecord));
  } catch {
    return null;
  }
}

const MARGIN_MM = 2;

/**
 * Both outlines in one frame: the case lying along a shared axis with the head faces on one
 * vertical line, at one scale for both. The viewport is built from the two profiles together,
 * which is what makes the frame common; each is then written as one closed outline.
 */
export function overlay(a: Profile, b: Profile): Overlay {
  const view = viewportFor([a, b], { scale: 1, marginMm: MARGIN_MM, frame: 'landscape' });
  const [x1, y] = view.xy(0, view.zMin);
  const [x2] = view.xy(0, view.zMax);
  return {
    width: view.width,
    height: view.height,
    a: fullSectionPath(a, view),
    b: fullSectionPath(b, view),
    axis: { x1, x2, y }
  };
}
