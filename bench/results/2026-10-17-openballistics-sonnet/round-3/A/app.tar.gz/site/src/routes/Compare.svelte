<script lang="ts">
  import PageHeader from '../components/PageHeader.svelte';
  import ScaleRuler from '../components/ScaleRuler.svelte';
  import { byKey, load } from '../lib/data';
  import { dimensionRows, differenceText, lengthText, outerProfileOf, overlay } from '../lib/compare';
  import { t } from '../lib/i18n.svelte';
  import { href } from '../lib/router';
  import { unitSystem } from '../lib/units.svelte';
  import { PX_PER_MM } from '@lib/core';

  interface Props {
    a: string;
    b: string;
  }
  let { a, b }: Props = $props();

  const records = $derived(Promise.all([load(a), load(b)]));
  const system = $derived(unitSystem());
  const unit = $derived(system === 'imperial' ? 'in' : 'mm');
  const missing = $derived([a, b].find((key) => !byKey(key)));
</script>

<div data-ui="Compare" class="contents">
{#if missing !== undefined}
  <PageHeader title={t('compare.title')} backHref={href.list()} backLabel={t('record.back')} />
  <p class="status error" role="alert">{t('compare.unknown', { key: missing })}</p>
{:else}
  {#await records}
    <p class="status">{t('record.loading', { name: `${byKey(a)?.name} / ${byKey(b)?.name}` })}</p>
  {:then [first, second]}
    {@const rows = dimensionRows(first, second)}
    {@const profiles = [outerProfileOf(first), outerProfileOf(second)]}
    {@const frame = profiles[0] && profiles[1] ? overlay(profiles[0], profiles[1]) : null}

    <PageHeader
      title={t('compare.heading', { a: first.name, b: second.name })}
      eyebrow={t('compare.title')}
      description={t('compare.lede')}
      backHref={href.cartridge(first.key)}
      backLabel={t('compare.back', { name: first.name })}
    />

    <section class="profiles">
      {#if frame}
        <!--
          One viewBox in millimetres for both outlines, so a unit is a millimetre in each and the
          scale is the same by construction. B is dashed as well as coloured: a reader who cannot
          tell the two colours apart can still tell the outlines apart.
        -->
        <svg
          class="overlay"
          role="img"
          aria-label={t('compare.profiles', { a: first.name, b: second.name })}
          viewBox={`0 0 ${frame.width} ${frame.height}`}
          style={`width:min(100%, ${frame.width * PX_PER_MM * 2}px)`}
        >
          <line class="axis" x1={frame.axis.x1} y1={frame.axis.y} x2={frame.axis.x2} y2={frame.axis.y} />
          <path class="outline a" d={frame.a} />
          <path class="outline b" d={frame.b} />
        </svg>
        <ScaleRuler widthMm={frame.width} />
        <ul class="legend">
          <li><span class="swatch a"></span>{first.name}</li>
          <li><span class="swatch b"></span>{second.name}</li>
        </ul>
      {:else}
        <p class="note">{t('compare.noProfile')}</p>
      {/if}
    </section>

    {#if rows.length}
      <div class="scroll">
        <table>
          <caption>{t('compare.dimensions', { unit })}</caption>
          <thead>
            <tr>
              <th scope="col">{t('compare.symbol')}</th>
              <th scope="col" class="num">{first.name}</th>
              <th scope="col" class="num">{second.name}</th>
              <th scope="col" class="num">{t('compare.difference')}</th>
            </tr>
          </thead>
          <tbody>
            {#each rows as row (row.symbol)}
              <tr>
                <td class="num">{row.symbol}</td>
                <td class="num">{lengthText(row.a, system)}</td>
                <td class="num">{lengthText(row.b, system)}</td>
                <td class="num">{differenceText(row.a, row.b, system)}</td>
              </tr>
            {/each}
          </tbody>
        </table>
      </div>
      <p class="note">{t('compare.differenceNote')}</p>
    {:else}
      <p class="note">{t('compare.noDimensions')}</p>
    {/if}
  {:catch error}
    <p class="status error" role="alert">{error.message} <a href={href.list()}>{t('record.back')}</a></p>
  {/await}
{/if}
</div>

<style>
  @layer legacy {
  :global([data-ui="Compare"] .profiles) {
    display: flex;
    flex-direction: column;
    align-items: center;
    margin-bottom: 2rem;
    padding: var(--panel-padding, 1rem);
    background: var(--surface);
    border: 1px solid var(--rule);
    border-radius: var(--radius);
  }
  :global([data-ui="Compare"] .overlay) { height: auto; flex: 0 0 auto; }
  :global([data-ui="Compare"] .axis) {
    stroke: var(--ink-3);
    stroke-width: 0.15;
    stroke-dasharray: 2 1 0.4 1;
  }
  :global([data-ui="Compare"] .outline) {
    fill: none;
    stroke-width: 0.3;
    stroke-linejoin: round;
  }
  :global([data-ui="Compare"] .outline.a) { stroke: var(--link); }
  :global([data-ui="Compare"] .outline.b) { stroke: var(--alert); stroke-dasharray: 1.2 0.6; }
  :global([data-ui="Compare"] .legend) {
    display: flex;
    flex-wrap: wrap;
    gap: 0.5rem 1.5rem;
    list-style: none;
    margin: 0.25rem 0 0;
    padding: 0;
    font-size: var(--step-0);
  }
  :global([data-ui="Compare"] .legend li) { display: flex; align-items: center; gap: 0.5rem; }
  :global([data-ui="Compare"] .swatch) { display: inline-block; width: 1.5rem; border-top: 3px solid; }
  :global([data-ui="Compare"] .swatch.a) { border-color: var(--link); }
  :global([data-ui="Compare"] .swatch.b) { border-color: var(--alert); border-top-style: dashed; }
  :global([data-ui="Compare"] .scroll) {
    overflow-x: auto;
    border: 1px solid var(--rule);
    border-radius: var(--panel-radius);
    background: var(--surface);
  }
  :global([data-ui="Compare"] table) {
    width: 100%;
    border-collapse: collapse;
    font-size: var(--step-0);
  }
  :global([data-ui="Compare"] caption) {
    padding: 0.55rem 0.7rem;
    text-align: left;
    font-weight: 600;
  }
  :global([data-ui="Compare"] th),
  :global([data-ui="Compare"] td) {
    padding: 0.4rem 0.7rem;
    border-bottom: 1px solid var(--rule);
    text-align: left;
    white-space: nowrap;
  }
  :global([data-ui="Compare"] th) {
    color: var(--ink-2);
    font-weight: 500;
    border-bottom: 2px solid var(--rule-strong);
  }
  :global([data-ui="Compare"] th.num),
  :global([data-ui="Compare"] td.num:not(:first-child)) { text-align: right; }
  :global([data-ui="Compare"] .note) { color: var(--ink-2); font-size: var(--step-0); margin: 0.75rem 0 0; }
  }
</style>
