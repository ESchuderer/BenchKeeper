<!-- The title becomes the commit on main, so it has to follow Conventional Commits:
     `type(scope): summary`, e.g. `data(rimless): correct 308 Win. L3`. See CONTRIBUTING.md. -->

## What and why

## Checklist

- [ ] `npm test` and `npm run build` pass in `site/`
- [ ] A change to a record names its source: the C.I.P. sheet, the maker's page or your measurement
- [ ] A user-visible change has a line under "Unreleased" in `CHANGELOG.md`
