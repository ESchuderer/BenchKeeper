# Changelog

All notable changes to OpenBallistics are recorded in this file.

The format follows [Keep a Changelog 1.1.0](https://keepachangelog.com/en/1.1.0/), and the project
follows [Semantic Versioning 2.0.0](https://semver.org/). How both are applied is described in
[CONTRIBUTING.md](CONTRIBUTING.md#changelog).

## [Unreleased]

### Added

- Continuous integration: the tests and the type-check and build of the site run on every pull
  request, and the pull request title is checked against the commit convention.
- Deployment of the site to GitHub Pages from `main`.
- Tag-triggered releases, with the changelog section as the release notes and the built site and a
  snapshot of the data attached.
- Weekly dependency updates with Dependabot.
- A README and CONTRIBUTING.md for contributors, and a pull request template.
- A comparison view, `#/compare/<a>/<b>`: the outer profiles of two cases overlaid at one scale, and a
  table of the dimensions either cartridge publishes with their difference (empty where only one
  publishes it), in the unit chosen under Default units. A cartridge's page has a `Compare with`
  choice and a `Compare` button to open it. The new texts are in English and German.
