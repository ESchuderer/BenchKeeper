# Contributing

Thank you for helping. The README covers how to install, run and test the project and how to change
the data; this file covers how a change is proposed, how it is worded and how a release is made.

## Proposing a change

1. Fork the repository and branch from `main`.
2. Make the change, and run `npm test` and `npm run build` in `site/`. These are the checks CI runs.
3. Open a pull request against `main`. A short description of what changed and why is enough; for a
   record, say where the figure comes from.

Every pull request runs the **CI** workflow: the tests, the type-check and build of the site, and a
check of the pull request's title (below). It has to pass before the change is merged. Changes are
squash-merged, so the title of the pull request becomes the commit on `main`.

If the change is one a reader of the changelog would care about (something added, changed, fixed or
removed on the site, in the libraries or in the data), add a line for it under `## [Unreleased]` in
[CHANGELOG.md](CHANGELOG.md).

## Commit messages

Commits, and the titles of pull requests, follow
[Conventional Commits 1.0.0](https://www.conventionalcommits.org/en/v1.0.0/):

```
<type>(<optional scope>): <summary>

<optional body: what and why, not how>

<optional footers, e.g. BREAKING CHANGE: ..., Refs: #123>
```

- The **summary** is in the imperative mood ("correct", not "corrected"), starts in lower case, has
  no full stop, and keeps the whole first line to 72 characters or fewer.
- The **type** is one of:

  | Type       | Use it for                                                              |
  | ---------- | ----------------------------------------------------------------------- |
  | `feat`     | a new feature of the site or the libraries                              |
  | `fix`      | a bug fix in the site or the libraries                                  |
  | `data`     | adding, correcting or removing records in `data/`                       |
  | `docs`     | documentation only                                                      |
  | `style`    | formatting that does not change behaviour                               |
  | `refactor` | a code change that neither fixes a bug nor adds a feature               |
  | `perf`     | a change that makes something faster or smaller                         |
  | `test`     | adding or correcting tests                                              |
  | `build`    | the build, the scripts or the dependencies' declaration                 |
  | `ci`       | the workflows in `.github/`                                             |
  | `chore`    | anything else that does not change the shipped site, library or data    |
  | `revert`   | undoing an earlier commit; name it in the body                          |

- The **scope** is optional and names the area: a data family (`data(rimless)`, `data(bullets)`,
  `data(targets)`), or `site`, `lib`, `deps`, `release`.
- A change that breaks a consumer (the shape of a record, a removed key, a changed library export)
  is marked with `!` after the type or scope, and has a `BREAKING CHANGE:` footer saying what to do
  about it.

Examples:

```
data(rimless): correct 308 Win. L3 to the 2023 sheet
feat(site): add a unit switch to the bullet list
fix(lib): keep the ogive tangent at zero meplat
chore(release): 0.2.0
data!: rename `defaultBulletShape` to `bulletShape`
```

The pull request title is checked by CI against this pattern, and against the 72-character limit.
Dependabot's titles (`chore(deps): ...`, `ci(deps): ...`) already match the pattern, and are exempt
from the limit.

## Versioning

The project follows [Semantic Versioning 2.0.0](https://semver.org/), and the version is kept in
exactly one place: the `version` field of `site/package.json` (and the same number in
`site/package-lock.json`, which `npm version` keeps in step). The repository is released as a whole:
the site, the libraries and the dataset share one version.

While the version is below 1.0.0, the shape of the records and the library exports may change in a
minor release; such changes are always marked as breaking in the changelog. From 1.0.0 on:

- **MAJOR**: a breaking change to the shape of a record, or to what the libraries export.
- **MINOR**: new functionality, or records added or corrected in bulk.
- **PATCH**: fixes to the site or the libraries, and individual data corrections.

Commit types map onto this: `feat` and larger `data` changes are minor, `fix` and small `data`
changes are patch, and `!` or a `BREAKING CHANGE:` footer is major. Whoever prepares a release makes
the final call.

## Changelog

[CHANGELOG.md](CHANGELOG.md) follows [Keep a Changelog 1.1.0](https://keepachangelog.com/en/1.1.0/):

- It is written for people, by hand, not copied from the commit log.
- The newest release is at the top, below a `## [Unreleased]` section that collects what has not
  been released yet.
- A release is a heading `## [X.Y.Z] - YYYY-MM-DD`, in ISO 8601 date format.
- Under it, changes are grouped by the headings `### Added`, `### Changed`, `### Deprecated`,
  `### Removed`, `### Fixed` and `### Security`, in that order, leaving out those with nothing in
  them. Data changes go under the same headings and are summarised (what was added or corrected and
  why), not listed record by record. Breaking changes are prefixed with **Breaking:**.
- A pre-release is written `## [1.0.0-rc.1] - YYYY-MM-DD`.

The release workflow publishes the section for the tagged version as the release notes, so a
release cannot be made without one.

## Releases

A release is made by pushing a tag `vX.Y.Z`; the **Release** workflow (`.github/workflows/release.yml`)
does the rest. To make one:

1. Branch from an up-to-date `main`.
2. Choose the version from the changes under `## [Unreleased]`, as described under
   [Versioning](#versioning).
3. Set it in the repository: `cd site && npm version X.Y.Z --no-git-tag-version`. This edits
   `package.json` and `package-lock.json` only, and creates no commit or tag. (The first release is
   0.1.0, which the files already say; skip this step for it.)
4. In `CHANGELOG.md`, rename `## [Unreleased]` to `## [X.Y.Z] - YYYY-MM-DD` and add a new, empty
   `## [Unreleased]` above it.
5. Commit as `chore(release): X.Y.Z`, open a pull request, and merge it once CI is green.
6. Tag the merge commit on `main` and push the tag:

   ```sh
   git checkout main && git pull
   git tag -a vX.Y.Z -m "vX.Y.Z"
   git push origin vX.Y.Z
   ```

The workflow then checks that the tag is on `main`, that it equals the version in `site/package.json`
and `site/package-lock.json`, and that `CHANGELOG.md` has a section for it; runs the tests and the
build; and creates the GitHub release, with that changelog section as its notes and these files
attached: `openballistics-site-vX.Y.Z.tar.gz` (the built site), `openballistics-data-vX.Y.Z.tar.gz`
(the `data/` directory and the licence) and `SHA256SUMS`. A version with a hyphen (`1.0.0-rc.1`) is
published as a pre-release.

Publishing the site is separate: the **Deploy site** workflow (`.github/workflows/pages.yml`)
deploys `main` to GitHub Pages on every push, so the live site can be ahead of the latest release.

### Repository settings the files cannot make

For the maintainers, once, in the GitHub settings:

- Pages: set the source to "GitHub Actions".
- Branch protection (or a ruleset) on `main`: require a pull request and the **Test and build** and
  **Pull request title** checks, and allow squash merging only, with the pull request title as the
  commit message.
- A tag ruleset for `v*`, so that only maintainers can create release tags.
- Actions: require approval to run workflows from first-time contributors.
