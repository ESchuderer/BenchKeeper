import { readFileSync } from 'node:fs';
import { join } from 'node:path';
import { describe, expect, it } from 'vitest';
import { caseOuterProfile, adaptMetallic, type CartridgeRecord } from '../shapes2d';
import { fmt, fullSectionPath, viewportFor } from '../geom/svg';
import { CARTRIDGES } from '../testing/fixtures';
import { overlayProfiles } from './compare';

const record = (family: string, key: string) =>
  JSON.parse(readFileSync(join(CARTRIDGES, family, `${key}.json`), 'utf8')) as CartridgeRecord;
const a = record('rimless', '308_win');
const b = record('belted', '300_win_mag');

/** The x coordinates of a path drawn with `M`/`L` commands, and the y ones. */
function coordinates(d: string): { xs: number[]; ys: number[] } {
  const points = [...d.matchAll(/[ML]\s*(-?[\d.e-]+),(-?[\d.e-]+)/g)].map((m) => [Number(m[1]), Number(m[2])] as const);
  return { xs: points.map((p) => p[0]), ys: points.map((p) => p[1]) };
}

describe('overlaid case profiles', () => {
  const overlay = overlayProfiles(a, b);

  it('draws each case outline as one closed path of caseOuterProfile, in one shared viewport', () => {
    const profiles = [a, b].map((r) => caseOuterProfile(adaptMetallic(r)));
    const view = viewportFor(profiles, { scale: 4, marginMm: 2, frame: 'landscape' });
    expect(overlay.paths).toEqual([fullSectionPath(profiles[0]!, view), fullSectionPath(profiles[1]!, view)]);
    expect(overlay.width).toBe(view.width);
    expect(overlay.height).toBe(view.height);
    for (const d of overlay.paths) expect(d.trim().endsWith('Z')).toBe(true);
  });
  it('puts both head faces at the same place and both axes on one line', () => {
    const [first, second] = overlay.paths.map(coordinates);
    expect(Math.min(...first!.xs)).toBeCloseTo(Math.min(...second!.xs), 9);
    // The axis is the middle of the mirrored section, which is the same height for both.
    const middle = (ys: number[]) => (Math.min(...ys) + Math.max(...ys)) / 2;
    expect(middle(first!.ys)).toBeCloseTo(middle(second!.ys), 9);
    expect(middle(first!.ys)).toBeCloseTo(overlay.height / 2, 9);
  });
  it('is to one scale: the longer case reaches further by the difference in length', () => {
    const [first, second] = overlay.paths.map(coordinates);
    const length = (xs: number[]) => Math.max(...xs) - Math.min(...xs);
    expect(length(second!.xs) - length(first!.xs)).toBeCloseTo((66.55 - 51.18) * 4, 6);
  });
  it('fits both outlines in the view box', () => {
    for (const { xs, ys } of overlay.paths.map(coordinates)) {
      expect(Math.min(...xs)).toBeGreaterThanOrEqual(0);
      expect(Math.max(...xs)).toBeLessThanOrEqual(overlay.width);
      expect(Math.min(...ys)).toBeGreaterThanOrEqual(0);
      expect(Math.max(...ys)).toBeLessThanOrEqual(overlay.height);
    }
    expect(overlay.viewBox).toBe(`0 0 ${fmt(overlay.width)} ${fmt(overlay.height)}`);
  });
  it('refuses a shot cartridge and a record that cannot be drawn', () => {
    expect(() => overlayProfiles(a, record('shotshell', '12'))).toThrow(/shot cartridge/);
    expect(() => overlayProfiles(a, { ...b, cartridge: {} })).toThrow(/not published/);
  });
});
