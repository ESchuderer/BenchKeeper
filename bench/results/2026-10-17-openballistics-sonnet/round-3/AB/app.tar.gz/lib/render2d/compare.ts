/** Two cases overlaid at one scale, for the comparison view. */

import { adaptMetallic, caseOuterProfile, type CartridgeRecord } from '../shapes2d/case';
import { fmt, fullSectionPath, viewportFor } from '../geom/svg';

const COMPARE_MARGIN_MM = 2;

export interface ProfileOverlay {
  width: number;
  height: number;
  viewBox: string;
  /** The closed outline of the first case, then of the second. */
  paths: [string, string];
}

/**
 * The outer profiles of two metallic cases in one viewport: the same scale, the same axis, and
 * the head faces at the same point, lying down with the head to the left as the site draws a
 * case. Throws what `adaptMetallic` throws where a record does not publish enough to draw.
 */
export function overlayProfiles(a: CartridgeRecord, b: CartridgeRecord, scale = 4): ProfileOverlay {
  for (const record of [a, b]) {
    if (record.family === 'shotshell') throw new Error(`${record.key}: a shot cartridge has no metallic case profile`);
  }
  const profiles = [a, b].map((record) => caseOuterProfile(adaptMetallic(record)));
  const view = viewportFor(profiles, { scale, marginMm: COMPARE_MARGIN_MM, frame: 'landscape' });
  return {
    width: view.width,
    height: view.height,
    viewBox: `0 0 ${fmt(view.width)} ${fmt(view.height)}`,
    paths: [fullSectionPath(profiles[0]!, view), fullSectionPath(profiles[1]!, view)]
  };
}
