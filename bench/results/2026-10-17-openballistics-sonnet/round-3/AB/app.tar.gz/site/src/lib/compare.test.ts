import { readFileSync } from 'node:fs';
import { join } from 'node:path';
import { describe, expect, it } from 'vitest';
import type { Record_ } from '@lib/core';
import { CARTRIDGES } from '@lib/testing/fixtures';
import { compareRows, tableUnit } from './compare';

const record = (family: string, key: string) =>
  JSON.parse(readFileSync(join(CARTRIDGES, family, `${key}.json`), 'utf8')) as Record_;
const a = record('rimless', '308_win');
const b = record('belted', '300_win_mag');

describe('compared dimensions', () => {
  const rows = compareRows(a, b, 'metric');
  const row = (symbol: string) => rows.find((r) => r.symbol === symbol);

  it('has one row per dimension either cartridge publishes, in the order of the detail page', () => {
    expect(rows.map((r) => r.symbol)).toEqual([
      'L1', 'L2', 'L3', 'L6', 'R', 'R1', 'R3', 'E', 'E1', 'e min', 'f', 'P1', 'P2',
      'S', 'r1 min', 'r2', 'H1', 'H2', 'G1', 'L3 + G', 'Fe', 'delta L'
    ]);
  });
  it('leaves a cell and the difference empty where a cartridge does not publish the dimension', () => {
    expect(row('delta L')).toEqual({ symbol: 'delta L', a: '0.1', b: '', difference: '' });
    expect(row('R3')).toEqual({ symbol: 'R3', a: '', b: '13.51', difference: '' });
    expect(compareRows(a, b, 'imperial').find((r) => r.symbol === 'R3')).toMatchObject({ a: '', difference: '' });
  });
  it('leaves out tolerances, angles, pressures and the chamber', () => {
    for (const symbol of ['L1Tol', 'ETol', 'L1 Tol', 'α', 'δ', 'β', 'Pmax', 'PK', 'M', 'EE']) {
      expect(row(symbol)).toBeUndefined();
    }
    // `E` in the chamber's powder chamber is a different dimension from the case head's.
    expect(rows.filter((r) => r.symbol === 'E')).toHaveLength(1);
  });
  it('writes metric values as the detail page does, and the difference as B minus A', () => {
    expect(row('L3')).toEqual({ symbol: 'L3', a: '51.18', b: '66.55', difference: '15.37' });
    expect(row('e min')).toEqual({ symbol: 'e min', a: '1.4', b: '0.94', difference: '-0.46' });
    expect(row('H1')).toEqual({ symbol: 'H1', a: '8.72', b: '8.63', difference: '-0.09' });
    expect(row('G1')?.difference).toBe('0');
  });
  it('does not show floating-point noise in a difference', () => {
    expect(row('L1')?.difference).toBe('16.16'); // 55.78 - 39.62 is 16.159999999999997 in binary
    expect(row('L6')?.difference).toBe('13.72');
  });
  it('writes imperial values and differences in inches', () => {
    const inches = compareRows(a, b, 'imperial');
    const L3 = inches.find((r) => r.symbol === 'L3');
    expect(L3).toEqual({ symbol: 'L3', a: '2.01496062992', b: '2.62007874016', difference: '0.605118110236' });
    expect(inches.map((r) => r.symbol)).toEqual(rows.map((r) => r.symbol));
  });
  it('lists what only one publishes after the symbol before it, and is symmetric in what it lists', () => {
    const bare = { ...a, cartridge: { misc: { deltaL: 1 } } } as Record_;
    expect(compareRows(bare, b, 'metric').map((r) => r.symbol)).toEqual(rows.map((r) => r.symbol));
    expect(compareRows(bare, bare, 'metric')).toEqual([{ symbol: 'delta L', a: '1', b: '1', difference: '0' }]);
    expect(compareRows(b, a, 'metric').map((r) => r.symbol).sort()).toEqual(rows.map((r) => r.symbol).sort());
    expect(compareRows(b, a, 'metric').find((r) => r.symbol === 'L3')?.difference).toBe('-15.37');
  });
  it('ignores a repeating group and non-numeric values', () => {
    const shot = { ...a, cartridge: { lengths: [{ l: 70 }], caseHead: { R: '1.37', R1: null } } } as unknown as Record_;
    expect(compareRows(shot, shot, 'metric')).toEqual([]);
  });
  it('names the table by the unit it is written in', () => {
    expect(tableUnit('metric')).toBe('mm');
    expect(tableUnit('imperial')).toBe('in');
  });
});
