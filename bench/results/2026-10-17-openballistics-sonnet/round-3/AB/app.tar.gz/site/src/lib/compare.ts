/**
 * What the comparison view tabulates: the dimensions either of two cartridges publishes.
 *
 * A dimension is a number in the record's `cartridge` part whose unit is millimetres. Tolerances
 * are shown beside their dimension on the detail page and are not rows here, and the chamber is
 * not part of a cartridge's own dimensions.
 */

import { FIELD_LABELS, FIELD_UNITS, GROUP_ORDER, formatValue, orderedFields, toleranceFor, type Record_ } from '@lib/core';
import { displayNumber, type UnitSystem } from './units';

export interface CompareRow {
  symbol: string;
  a: string;
  b: string;
  /** B minus A. */
  difference: string;
}

/** The dimensions of one record in millimetres, by the symbol the detail page writes them as, in page order. */
function dimensionsOf(record: Record_): Map<string, number> {
  const found = new Map<string, number>();
  const groups = record.cartridge ?? {};
  const order = [...GROUP_ORDER.cartridge, ...Object.keys(groups).filter((name) => !GROUP_ORDER.cartridge.includes(name)).sort()];
  for (const name of order) {
    const group = groups[name];
    if (!group || Array.isArray(group)) continue;
    for (const field of orderedFields('cartridge', name, group)) {
      const value = group[field];
      if (typeof value !== 'number' || !Number.isFinite(value)) continue;
      if (toleranceFor(field) !== null || field in FIELD_UNITS) continue;
      const symbol = FIELD_LABELS[field] ?? field;
      if (!found.has(symbol)) found.set(symbol, value);
    }
  }
  return found;
}

/** The unit the table is written in. */
export const tableUnit = (system: UnitSystem): 'mm' | 'in' => (system === 'imperial' ? 'in' : 'mm');

/**
 * One row per dimension symbol either record publishes, in the order of the first record's sheet.
 * A symbol only the second record publishes follows the symbol before it on the second's sheet.
 *
 * Metric values are written as the detail page writes them. Imperial values and every difference
 * go through `displayNumber`, which converts from millimetres and drops the floating-point noise
 * of the subtraction without rounding to any precision a sheet would not state. Where a record
 * does not publish a dimension its cell is empty, and so is the difference.
 */
export function compareRows(a: Record_, b: Record_, system: UnitSystem): CompareRow[] {
  const unit = tableUnit(system);
  const first = dimensionsOf(a);
  const second = dimensionsOf(b);
  const write = (value: number | undefined) =>
    value === undefined ? '' : unit === 'in' ? displayNumber(value, unit) : (formatValue(value) as string);
  const symbols = [...first.keys()];
  let previous = -1;
  for (const symbol of second.keys()) {
    const at = symbols.indexOf(symbol);
    if (at >= 0) previous = at;
    else symbols.splice(++previous, 0, symbol);
  }
  return symbols.map((symbol) => {
    const one = first.get(symbol);
    const other = second.get(symbol);
    const difference = one === undefined || other === undefined ? '' : displayNumber(other - one, unit);
    return { symbol, a: write(one), b: write(other), difference };
  });
}
