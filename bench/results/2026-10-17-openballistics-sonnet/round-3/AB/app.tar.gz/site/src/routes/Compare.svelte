<script lang="ts">
  import { overlayProfiles } from '@lib/render2d';
  import type { CartridgeRecord } from '@lib/shapes2d';
  import { load } from '../lib/data';
  import { compareRows, tableUnit } from '../lib/compare';
  import { href } from '../lib/router';
  import { t } from '../lib/i18n.svelte';
  import { unitSystem } from '../lib/units.svelte';

  interface Props {
    a: string;
    b: string;
  }
  let { a, b }: Props = $props();

  const records = $derived(Promise.all([load(a), load(b)]));
  const unit = $derived(tableUnit(unitSystem()));

  /** The overlay, or the reason there is none: a record may publish too little to draw its case. */
  function overlay(first: CartridgeRecord, second: CartridgeRecord) {
    try {
      return overlayProfiles(first, second);
    } catch {
      return null;
    }
  }
</script>

<div data-ui="Compare" class="contents">
  {#await records}
    <p class="status">{t('site.loading')}</p>
  {:then [first, second]}
    {@const drawing = overlay(first as unknown as CartridgeRecord, second as unknown as CartridgeRecord)}
    {@const rows = compareRows(first, second, unitSystem())}
    <h1>{t('compare.title')}: {first.name} / {second.name}</h1>

    <section class="profiles">
      {#if drawing}
        <svg
          role="img"
          aria-label={t('compare.profiles', { a: first.name, b: second.name })}
          viewBox={drawing.viewBox}
          style={`max-width:${drawing.width}px`}
        >
          <path class="outline a" d={drawing.paths[0]} />
          <path class="outline b" d={drawing.paths[1]} />
        </svg>
        <ul class="legend" aria-hidden="true">
          <li><span class="swatch a"></span>{first.name}</li>
          <li><span class="swatch b"></span>{second.name}</li>
        </ul>
      {:else}
        <p class="status">{t('compare.noProfile', { names: `${first.name} / ${second.name}` })}</p>
      {/if}
    </section>

    {#if rows.length}
      <div class="scroll">
        <table>
          <caption>{t('compare.dimensions', { unit })}</caption>
          <thead>
            <tr>
              <th scope="col">{t('compare.symbol')}</th>
              <th scope="col" class="num">{first.name}</th>
              <th scope="col" class="num">{second.name}</th>
              <th scope="col" class="num">{t('compare.difference')}</th>
            </tr>
          </thead>
          <tbody>
            {#each rows as row (row.symbol)}
              <tr>
                <td class="num symbol">{row.symbol}</td>
                <td class="num">{row.a}</td>
                <td class="num">{row.b}</td>
                <td class="num">{row.difference}</td>
              </tr>
            {/each}
          </tbody>
        </table>
      </div>
    {:else}
      <p class="status">{t('compare.none')}</p>
    {/if}

    <p class="foot"><a href={href.list()}>{t('record.back')}</a></p>
  {:catch error}
    <p class="status error">{t('compare.error', { message: error.message })} <a href={href.list()}>{t('record.back')}</a></p>
  {/await}
</div>

<style>
  @layer legacy {
    :global([data-ui="Compare"] h1) {
      font-size: clamp(var(--step-2), 1rem + 1.5vw, var(--step-3));
      line-height: 1.2;
      margin-bottom: 1.5rem;
    }
    :global([data-ui="Compare"] .profiles) {
      margin-bottom: 2rem;
      padding: var(--panel-padding, 1rem);
      background: var(--surface);
      border: 1px solid var(--rule);
      border-radius: var(--radius);
    }
    :global([data-ui="Compare"] svg) {
      display: block;
      width: 100%;
      height: auto;
      margin-inline: auto;
    }
    :global([data-ui="Compare"] .outline) {
      fill: none;
      stroke-width: 1.2;
      stroke-linejoin: round;
      vector-effect: non-scaling-stroke;
    }
    /* Two strokes told apart by colour and by dash, so that neither depends on seeing the colour. */
    :global([data-ui="Compare"] .outline.a) { stroke: var(--ink); }
    :global([data-ui="Compare"] .swatch.a) { background: var(--ink); }
    :global([data-ui="Compare"] .outline.b) { stroke: var(--link); stroke-dasharray: 6 3; stroke-width: 1.6; }
    :global([data-ui="Compare"] .swatch.b) { background: var(--link); }
    :global([data-ui="Compare"] .legend) {
      display: flex;
      flex-wrap: wrap;
      gap: 0.5rem 1.5rem;
      justify-content: center;
      list-style: none;
      margin: 0.75rem 0 0;
      padding: 0;
      font-size: var(--step-0);
    }
    :global([data-ui="Compare"] .swatch) {
      display: inline-block;
      width: 1.5rem;
      height: 0.2rem;
      margin-right: 0.5rem;
      vertical-align: middle;
    }
    :global([data-ui="Compare"] .scroll) { overflow-x: auto; }
    :global([data-ui="Compare"] table) { border-collapse: collapse; font-size: var(--step-0); width: 100%; }
    :global([data-ui="Compare"] caption) {
      caption-side: top;
      text-align: left;
      font-weight: 600;
      padding-bottom: 0.5rem;
    }
    :global([data-ui="Compare"] th),
    :global([data-ui="Compare"] td) { text-align: right; padding: 0.25rem 0.75rem 0.25rem 0; white-space: nowrap; }
    :global([data-ui="Compare"] th) { color: var(--ink-2); font-weight: 500; }
    :global([data-ui="Compare"] thead th) { border-bottom: 1px solid var(--rule); }
    :global([data-ui="Compare"] th:first-child),
    :global([data-ui="Compare"] td.symbol) { text-align: left; }
    :global([data-ui="Compare"] td) { font-weight: 500; }
    :global([data-ui="Compare"] .status) { color: var(--ink-2); }
    :global([data-ui="Compare"] .status.error) { color: var(--alert); }
    :global([data-ui="Compare"] .foot) { margin-top: 2rem; }
  }
</style>
