# 01 Compare view

Status: ready-for-agent

Implements `.scratch/compare/spec.md`: router, `compare.ts` with tests, `Compare.svelte`, detail page control, i18n (en, de), changelog line.
