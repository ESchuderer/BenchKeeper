# Compare two cartridges

Route `#/compare/<a>/<b>` (cartridge keys as in `#/c/<key>`). Opens directly and survives a reload.

- Drawing: `caseOuterProfile` of both cases in one SVG, one scale, head faces at one point, one common axis. One `path` per outline. `role="img"`, name `Profiles of <name A> and <name B>`. Shot cartridges: no drawing.
- Table: one row per symbol either record publishes as a number in `cartridge` (no `FIELD_UNITS` entry, not `*Tol`). Caption `Dimensions (mm)` / `Dimensions (in)`. Columns `Symbol`, name A, name B, `Difference` (B minus A). Symbol from `FIELD_LABELS`. Where a record does not publish a symbol its cell and `Difference` are empty.
- Units follow the `Default units` preference. Metric: `formatValue`. Imperial: `displayNumber(value, 'in')`. Differences converted the same way.
- Detail page: select `Compare with` (other cartridges by name) and button `Compare`.
- English and German texts.

Decisions: pure logic in `site/src/lib/compare.ts` (rows, SVG); the page `site/src/routes/Compare.svelte` only renders. Outlines are the half profiles (r >= 0) against the axis at r = 0, mouth up.
