# Changelog

All notable changes to this project are recorded in this file.

The format follows [Keep a Changelog 1.1.0](https://keepachangelog.com/en/1.1.0/). Versions follow
[Semantic Versioning 2.0.0](https://semver.org/spec/v2.0.0.html), as defined in
[CONTRIBUTING.md](CONTRIBUTING.md#releases).

- Newest release first, under `## [X.Y.Z] - YYYY-MM-DD`. Unreleased changes sit under `## [Unreleased]`.
- Sections within a release, in this order, only when used: `Added`, `Changed`, `Deprecated`,
  `Removed`, `Fixed`, `Security`.
- One bullet per change, written for a user of the data or the site.
- Each version heading links to its GitHub release at the bottom of the file.

## [Unreleased]

### Added

- Compare view at `#/compare/<a>/<b>`: the outer profiles of two cases on one scale and a table of the dimensions either publishes, with the difference. Opened from `Compare with` on a cartridge page.
- GitHub Actions workflow that runs the tests and the production build on every pull request.
- GitHub Actions workflow that deploys the site to GitHub Pages from `main`.
- Tag-triggered release workflow that publishes a GitHub release with the data as an archive.
- Dependabot updates for the npm packages in `site/` and for the GitHub Actions.
- README, CONTRIBUTING and this changelog.

[Unreleased]: https://github.com/PiMetry/OpenBallistics/commits/main
