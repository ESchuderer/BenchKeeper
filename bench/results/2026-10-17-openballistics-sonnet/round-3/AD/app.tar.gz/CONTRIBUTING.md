# Contributing

Setup, test and build commands are in [README.md](README.md). All npm commands run in `site/`.

## Pull requests

1. Fork the repository and branch from `main`.
2. Make the change. Run `npm test` and `npm run build` in `site/`. CI runs the same two commands on
   the pull request and both must pass.
3. Add a line under `## [Unreleased]` in [CHANGELOG.md](CHANGELOG.md) for a change a user of the
   data or the site would notice.
4. Open the pull request against `main`.

## Contributing data

Records are JSON files under `data/`:

| Kind | Location |
|---|---|
| Cartridge and chamber | `data/cartridges/<family>/<key>.json`, family one of `belted`, `pistol`, `rimfire`, `rimless`, `rimmed`, `shotshell` |
| Bullet | `data/bullets/<key>.json` |
| Target | `data/targets/<id>.json` |

- The file name is the record key.
- Copy a neighbouring record of the same kind and keep its fields, key names and units.
- Name the source of every changed or added value in the pull request description. Cartridge and chamber
  dimensions come from the C.I.P. tables.
- Do not edit generated files. The search index and field sets are rebuilt by `npm run prepare-data`
  and are not committed.
- Corrections without a pull request: use an issue template in `.github/ISSUE_TEMPLATE/`.

## Commit messages

Commits follow [Conventional Commits 1.0.0](https://www.conventionalcommits.org/en/v1.0.0/):

```
<type>[(scope)]: <summary>
```

- Types: `feat`, `fix`, `data`, `docs`, `style`, `refactor`, `perf`, `test`, `build`, `ci`, `chore`.
  `data` is for changes under `data/`. The other types are the standard ones.
- Summary: imperative, lower case, no final period.
- Breaking change: `!` after the type or scope, and a `BREAKING CHANGE:` footer.
- One logical change per commit.

## Releases

Version: `version` in `site/package.json` (and the root entries of `site/package-lock.json`). It is
the only place the version is kept. Versions follow Semantic Versioning, applied to the records
and the site together:

| Bump | When |
|---|---|
| Major | A record field is renamed or removed, or the layout of `data/` changes in a way that breaks consumers of the JSON files |
| Minor | New records, new record fields, new site features |
| Patch | Corrections to existing values, bug fixes |

Making a release (maintainers):

1. On a branch from `main`, run `npm version <major|minor|patch> --no-git-tag-version` in `site/`.
   The first release is `0.1.0`, the value already in `site/package.json`: skip this step for it.
2. In `CHANGELOG.md`, rename `## [Unreleased]` to `## [X.Y.Z] - YYYY-MM-DD`, add a new empty
   `## [Unreleased]` above it, and update the links at the bottom of the file.
3. Commit as `chore(release): vX.Y.Z` and merge the pull request into `main`.
4. Tag the merge commit and push the tag:

   ```sh
   git tag vX.Y.Z
   git push origin vX.Y.Z
   ```

The release workflow (`.github/workflows/release.yml`) then runs CI and checks that the tag equals
`version` in `site/package.json`, that the tagged commit is on `main`, and that `CHANGELOG.md` has a
section for the version. It creates the GitHub release with that section as notes and attaches
`openballistics-data-vX.Y.Z.tar.gz` (the `data/` directory and `LICENSE`). A tag with a suffix, such
as `v1.0.0-rc.1`, is published as a pre-release.

The site is deployed by `.github/workflows/pages.yml` on every push to `main`, not by the tag.

## Dependency updates

Dependabot (`.github/dependabot.yml`) opens weekly pull requests for the npm packages in `site/`
(minor and patch updates grouped) and for the GitHub Actions. They go through the same CI.
