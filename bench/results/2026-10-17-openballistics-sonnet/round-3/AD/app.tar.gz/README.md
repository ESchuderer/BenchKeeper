# OpenBallistics

An open database of cartridges, bullets and targets, with a website to browse it.

- `data/`: the records, one JSON file each. `cartridges/` (by family), `bullets/`, `targets/`.
- `lib/`: TypeScript libraries shared by the site: geometry, drawing, measurement, targets and user data.
- `site/`: the Svelte website. All npm scripts live here.

## Requirements

Node.js 22 and npm.

## Install

```sh
cd site
npm ci
```

## Develop

```sh
cd site
npm run dev
```

Vite prints the local URL. `npm run dev` first regenerates the search index and field sets from
`data/` (`npm run prepare-data`).

## Test

```sh
cd site
npm test
```

This runs the Vitest suites of `site/` and `lib/`, after `prepare-data`.

## Build

```sh
cd site
npm run build
npm run preview
```

`build` runs `prepare-data`, `svelte-check` and the production build into `site/dist/`. `preview`
serves that directory. For a build served from a sub-path, set `PAGES_BASE` (for example
`PAGES_BASE=/OpenBallistics/ npm run build`).

## Continuous integration and deployment

| Workflow | Trigger | What it does |
|---|---|---|
| `.github/workflows/ci.yml` | pull request | `npm ci`, `npm test`, `npm run build` |
| `.github/workflows/pages.yml` | push to `main` | tests, builds with the Pages base path, deploys to GitHub Pages |
| `.github/workflows/release.yml` | tag `vX.Y.Z` | runs CI, creates the GitHub release |

Maintainers: in the repository settings, set Pages, Source, to "GitHub Actions".

## Contribute data

- Wrong or missing value in an existing record: open an issue with one of the templates in
  `.github/ISSUE_TEMPLATE/` and name the source of the correct value.
- Edit or add a record: change or add the JSON file under `data/` and open a pull request. Copy a
  neighbouring file as the template, keep its fields and units, and cite the source in the pull
  request description. Run `npm test` in `site/` before pushing.

Details are in [CONTRIBUTING.md](CONTRIBUTING.md).

## Commit messages

[Conventional Commits](https://www.conventionalcommits.org/en/v1.0.0/): `<type>: <summary>`.
See [CONTRIBUTING.md](CONTRIBUTING.md#commit-messages).

## Versions and changes

The version is `version` in `site/package.json`. Changes are listed in [CHANGELOG.md](CHANGELOG.md)
(Keep a Changelog format). The release steps are in [CONTRIBUTING.md](CONTRIBUTING.md#releases).

## License

[MIT](LICENSE). Third-party software and its notices: [THIRD-PARTY.md](THIRD-PARTY.md).
