<script lang="ts">
  import { Button } from '$lib/components/ui/button/index.js';
  import { Label } from '$lib/components/ui/label/index.js';
  import { NativeSelect } from '$lib/components/ui/native-select/index.js';
  import { entries } from '../lib/data';
  import { t } from '../lib/i18n.svelte';
  import { href } from '../lib/router';

  let { key }: { key: string } = $props();
  const id = $props.id();
  const others = $derived(entries.filter((entry) => entry.key !== key).sort((a, b) => a.name.localeCompare(b.name, 'en')));
  let chosen = $state<string>();
  // The first cartridge until another is picked, which is what the select shows.
  const target = $derived(chosen && chosen !== key ? chosen : others[0]?.key);
</script>

<div class="mt-8 flex flex-wrap items-end gap-3 print:hidden">
  <div class="grid gap-1.5">
    <Label for={`${id}-with`}>{t('compare.with')}</Label>
    <NativeSelect id={`${id}-with`} bind:value={chosen} class="min-w-56">
      {#each others as entry (entry.key)}<option value={entry.key}>{entry.name}</option>{/each}
    </NativeSelect>
  </div>
  <Button type="button" disabled={!target} onclick={() => target && (location.hash = href.compare(key, target))}>{t('compare.go')}</Button>
</div>
