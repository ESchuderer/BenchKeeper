import { readFileSync } from 'node:fs';
import { join } from 'node:path';
import { describe, expect, it } from 'vitest';
import { adaptMetallic, caseOuterProfile, type CartridgeRecord } from '@lib/shapes2d';
import { formatValue, type Record_ } from '@lib/core';
import { CARTRIDGES } from '@lib/testing/fixtures';
import { displayNumber } from './units';
import { compareRows, compareSvg } from './compare';

const record = (family: string, key: string) =>
  JSON.parse(readFileSync(join(CARTRIDGES, family, `${key}.json`), 'utf8')) as Record_;
const a = record('rimless', '308_win');
const b = record('belted', '300_win_mag');

const row = (rows: ReturnType<typeof compareRows>, symbol: string) => rows.find((r) => r.symbol === symbol);

describe('compareRows', () => {
  it('lists each shared millimetre dimension once, as the detail page writes the symbol', () => {
    const rows = compareRows(a, b, 'metric');
    const symbols = rows.map((r) => r.symbol);
    expect(new Set(symbols).size).toBe(symbols.length);
    expect(symbols).toContain('e min');
    expect(symbols).toContain('L3');
    expect(symbols).not.toContain('eMin');
  });

  it('leaves out tolerances, angles and pressures', () => {
    const symbols = compareRows(a, b, 'metric').map((r) => r.symbol);
    expect(symbols.filter((s) => s.endsWith('Tol'))).toEqual([]);
    for (const left of ['α', 'β', 'δ', 'Pmax', 'PK', 'PE', 'Emax', 'M']) expect(symbols).not.toContain(left);
  });

  it('lists a dimension only one record publishes, with its other cells empty', () => {
    const rows = compareRows(a, b, 'metric');
    const deltaL = (a.cartridge.misc as Record<string, number>).deltaL!;
    expect(row(rows, 'delta L')).toEqual({ symbol: 'delta L', a: formatValue(deltaL), b: '', difference: '' });
    const r3 = (b.cartridge.caseHead as Record<string, number>).R3!;
    expect(row(rows, 'R3')).toEqual({ symbol: 'R3', a: '', b: formatValue(r3), difference: '' });
    expect(compareRows(a, b, 'imperial').find((r) => r.symbol === 'R3')).toMatchObject({ a: '', difference: '' });
  });

  it('writes metric values with formatValue and the difference as B minus A', () => {
    const l3a = (a.cartridge.lengths as Record<string, number>).L3!;
    const l3b = (b.cartridge.lengths as Record<string, number>).L3!;
    expect(row(compareRows(a, b, 'metric'), 'L3')).toEqual({
      symbol: 'L3', a: formatValue(l3a), b: formatValue(l3b), difference: formatValue(Number((l3b - l3a).toPrecision(12)))
    });
    expect(row(compareRows(a, b, 'metric'), 'L1')!.difference).toBe('16.16');
  });

  it('converts imperial values and differences with displayNumber, without rounding further', () => {
    const l3a = (a.cartridge.lengths as Record<string, number>).L3!;
    const l3b = (b.cartridge.lengths as Record<string, number>).L3!;
    expect(row(compareRows(a, b, 'imperial'), 'L3')).toEqual({
      symbol: 'L3', a: displayNumber(l3a, 'in'), b: displayNumber(l3b, 'in'), difference: displayNumber(l3b - l3a, 'in')
    });
  });

  it('skips chamber figures', () => {
    const chamberOnly = { ...a, cartridge: {}, chamber: a.chamber } as Record_;
    expect(compareRows(chamberOnly, chamberOnly, 'metric')).toEqual([]);
  });
});

describe('compareSvg', () => {
  it('draws both outer profiles as one path each, on one axis and one scale', () => {
    const svg = compareSvg(a, b)!;
    expect(svg.outlines).toHaveLength(2);
    const [pa, pb] = svg.outlines.map((o) => o.d);
    // The head face is the bottom edge of both, so both outlines reach the same lowest y.
    const lowest = (d: string) => Math.max(...[...d.matchAll(/[ML]([-\d.]+),([-\d.]+)/g)].map((m) => Number(m[2])));
    const headFace = (record: Record_) => {
      const profile = caseOuterProfile(adaptMetallic(record as unknown as CartridgeRecord));
      return Math.min(...profile.map(([, z]) => z));
    };
    expect(headFace(a)).toBe(0);
    expect(lowest(pa!)).toBeCloseTo(lowest(pb!), 6);
    // 300 Win. Mag. is longer and wider than 308 Win., so its outline is the larger of the two.
    const span = (d: string, i: 1 | 2) => {
      const values = [...d.matchAll(/[ML]([-\d.]+),([-\d.]+)/g)].map((m) => Number(m[i]));
      return Math.max(...values) - Math.min(...values);
    };
    expect(span(pb!, 2)).toBeGreaterThan(span(pa!, 2));
    expect(svg.axisX).toBeGreaterThan(0);
  });

  it('draws nothing for a shot cartridge', () => {
    const shot = record('shotshell', '12');
    expect(compareSvg(a, shot)).toBeNull();
  });
});

