/**
 * What the compare view shows, as data: the rows of the table and the outlines of the drawing.
 * The page only renders it.
 */

import { FIELD_LABELS, FIELD_UNITS, GROUP_ORDER, formatValue, orderedFields, type Record_ } from '@lib/core';
import { fmt, fullSectionPath, viewportFor } from '@lib/geom';
import { adaptMetallic, caseOuterProfile, type CartridgeRecord } from '@lib/shapes2d';
import { displayNumber, type UnitSystem } from './units';

export interface CompareRow {
  symbol: string;
  a: string;
  b: string;
  difference: string;
}

/** Every millimetre dimension of the cartridge side, by the field name the sheet's symbol has. */
function dimensions(record: Record_): Map<string, number> {
  const found = new Map<string, number>();
  const groups = Object.keys(record.cartridge);
  const ordered = [...GROUP_ORDER.cartridge.filter((g) => g in record.cartridge), ...groups.filter((g) => !GROUP_ORDER.cartridge.includes(g)).sort()];
  for (const name of ordered) {
    const group = record.cartridge[name];
    if (!group || Array.isArray(group)) continue;
    for (const field of orderedFields('cartridge', name, group)) {
      const value = group[field];
      if (typeof value === 'number' && !field.endsWith('Tol') && !(field in FIELD_UNITS) && !found.has(field)) {
        found.set(field, value);
      }
    }
  }
  return found;
}

/** The groups of both records merged, so that `dimensions` orders every field either record publishes. */
function union(a: Record_, b: Record_): Record_ {
  const plain = (group: unknown) => (group && typeof group === 'object' && !Array.isArray(group) ? group : {});
  const cartridge: Record<string, unknown> = {};
  for (const name of new Set([...Object.keys(a.cartridge), ...Object.keys(b.cartridge)])) {
    cartridge[name] = { ...plain(b.cartridge[name]), ...plain(a.cartridge[name]) };
  }
  return { cartridge } as unknown as Record_;
}

/** One row per dimension either record publishes, in the detail page's order; difference is B minus A. A record that does not publish a dimension has an empty cell, and the difference is empty. */
export function compareRows(a: Record_, b: Record_, system: UnitSystem): CompareRow[] {
  const valuesA = dimensions(a);
  const valuesB = dimensions(b);
  // 12 significant digits, as `displayNumber` keeps: far beyond what C.I.P. publishes, and it drops the
  // float noise of a subtraction (16.160000000000004).
  const write = (mm: number) => (system === 'imperial' ? displayNumber(mm, 'in') : formatValue(Number(mm.toPrecision(12)))!);
  return [...dimensions(union(a, b)).keys()].map((field) => {
    const valueA = valuesA.get(field);
    const valueB = valuesB.get(field);
    return {
      symbol: FIELD_LABELS[field] ?? field,
      a: valueA === undefined ? '' : write(valueA),
      b: valueB === undefined ? '' : write(valueB),
      difference: valueA === undefined || valueB === undefined ? '' : write(valueB - valueA)
    };
  });
}

export interface CompareSvg {
  width: number;
  height: number;
  /** x of the common axis, where both cases are centred. */
  axisX: number;
  /** The case outlines, A then B. */
  outlines: { d: string }[];
}

/** px per mm of the drawing's own units; the page scales the SVG to its column by the viewBox. */
const SCALE = 6;

/** Both cases on one scale and one axis, head faces level, or `null` where either cannot be drawn. */
export function compareSvg(a: Record_, b: Record_): CompareSvg | null {
  if (a.family === 'shotshell' || b.family === 'shotshell') return null;
  try {
    const profiles = [a, b].map((record) => caseOuterProfile(adaptMetallic(record as unknown as CartridgeRecord)));
    const view = viewportFor(profiles, { scale: SCALE, marginMm: 2 });
    return {
      width: view.width,
      height: view.height,
      axisX: Number(fmt(view.xy(0, 0)[0])),
      outlines: profiles.map((profile) => ({ d: fullSectionPath(profile, view) }))
    };
  } catch {
    // A record that publishes too little to draw (`MissingDimensionError`) has no profile to show.
    return null;
  }
}
