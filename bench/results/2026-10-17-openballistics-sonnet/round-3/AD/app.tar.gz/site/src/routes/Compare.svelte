<script lang="ts">
  import { byKey, load } from '../lib/data';
  import { compareRows, compareSvg } from '../lib/compare';
  import { t } from '../lib/i18n.svelte';
  import { href } from '../lib/router';
  import { unitSystem } from '../lib/units.svelte';

  let { a, b }: { a: string; b: string } = $props();

  const missing = $derived([a, b].find((key) => !byKey(key)));
  const unit = $derived(unitSystem() === 'imperial' ? 'in' : 'mm');
</script>

<div data-ui="Compare" class="contents">
  {#if missing}
    <p class="status error">{t('compare.unknown', { key: missing })} <a href={href.list()}>{t('record.back')}</a></p>
  {:else}
    {#await Promise.all([load(a), load(b)])}
      <p class="status">{t('site.loading')}</p>
    {:then [ra, rb]}
      {@const svg = compareSvg(ra!, rb!)}
      {@const rows = compareRows(ra!, rb!, unitSystem())}
      <h1>{t('compare.title')}</h1>
      <p class="mt-2 mb-6 text-muted-foreground">
        <a href={href.cartridge(a)}>{ra!.name}</a> · <a href={href.cartridge(b)}>{rb!.name}</a>
      </p>
      {#if svg}
        <figure class="m-0 mb-8 flex flex-col items-center gap-3">
          <svg
            role="img"
            aria-label={t('compare.profiles', { a: ra!.name, b: rb!.name })}
            viewBox={`0 0 ${svg.width} ${svg.height}`}
            class="h-auto max-h-[70vh] w-full max-w-md"
          >
            <line x1={svg.axisX} x2={svg.axisX} y1="0" y2={svg.height} stroke="var(--muted-foreground)" stroke-width="0.75" stroke-dasharray="6 4" />
            <path d={svg.outlines[0]!.d} fill="none" stroke="var(--foreground)" stroke-width="1.5" />
            <path d={svg.outlines[1]!.d} fill="none" stroke="var(--warn)" stroke-width="1.5" stroke-dasharray="5 3" />
          </svg>
          <figcaption class="flex flex-wrap gap-x-6 gap-y-1 text-sm">
            <span><span aria-hidden="true">━</span> {ra!.name}</span>
            <span><span aria-hidden="true" style="color: var(--warn)">╍</span> {rb!.name}</span>
          </figcaption>
        </figure>
      {:else}
        <p class="mb-8 text-muted-foreground">{t('compare.noDrawing')}</p>
      {/if}
      {#if rows.length}
        <div class="overflow-x-auto">
          <table class="w-full border-collapse text-sm">
            <caption class="pb-2 text-left font-semibold">{t('compare.table', { unit })}</caption>
            <thead>
              <tr class="border-b-2 border-border text-left">
                <th scope="col" class="py-1.5 pr-4">{t('compare.symbol')}</th>
                <th scope="col" class="py-1.5 pr-4 text-right">{ra!.name}</th>
                <th scope="col" class="py-1.5 pr-4 text-right">{rb!.name}</th>
                <th scope="col" class="py-1.5 text-right">{t('compare.difference')}</th>
              </tr>
            </thead>
            <tbody>
              {#each rows as row (row.symbol)}
                <tr class="border-b border-border">
                  <th scope="row" class="num py-1.5 pr-4 text-left font-normal">{row.symbol}</th>
                  <td class="num py-1.5 pr-4 text-right">{row.a}</td>
                  <td class="num py-1.5 pr-4 text-right">{row.b}</td>
                  <td class="num py-1.5 text-right">{row.difference}</td>
                </tr>
              {/each}
            </tbody>
          </table>
        </div>
      {:else}
        <p class="text-muted-foreground">{t('compare.noRows')}</p>
      {/if}
      <p class="mt-8"><a href={href.list()}>{t('record.back')}</a></p>
    {:catch error}
      <p class="status error">{error.message} <a href={href.list()}>{t('record.back')}</a></p>
    {/await}
  {/if}
</div>
