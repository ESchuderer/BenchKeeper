# Changelog

All notable changes are listed here. The format follows [Keep a Changelog 1.1.0](https://keepachangelog.com/en/1.1.0/) and the project follows [Semantic Versioning](https://semver.org). See [CONTRIBUTING.md](CONTRIBUTING.md#changelog).

## [Unreleased]

### Added

- GitHub Actions workflow that runs the tests and the build on every pull request.
- GitHub Pages deployment of the site from `main`.
- Tag-triggered release workflow that publishes a GitHub release from the changelog.
- Dependabot configuration for `site/` and the workflows.
- Contributor documentation: README and CONTRIBUTING.
