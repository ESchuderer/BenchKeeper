# Contributing

Setup, commands and the data workflow are in [README.md](README.md). Pull requests run the `CI` workflow (`.github/workflows/ci.yml`): `npm ci`, `npm test` and `npm run build` in `site/`. It must pass before a merge.

## Commit convention

Commits follow [Conventional Commits 1.0.0](https://www.conventionalcommits.org/en/v1.0.0/): `<type>(<optional scope>): <summary>`.

| Type | Use for |
|---|---|
| `feat` | A new site feature, or new records or fields in `data/` |
| `fix` | A bug fix, or a corrected value in `data/` |
| `docs` | Documentation only |
| `refactor` | A change that keeps behavior |
| `test` | Tests only |
| `perf` | A performance change |
| `build` | Build scripts, dependencies |
| `ci` | Workflows and CI configuration |
| `chore` | Anything else that is not user-visible |

- Summary: imperative mood, lower case, no final period.
- Breaking change: add `!` after the type (`feat!: ...`) and a `BREAKING CHANGE:` footer. A breaking change is a change to the record format or a removed or renamed record key.
- Dependabot commits use `chore(deps)`.

## Versioning

- The version is `version` in `site/package.json`. `site/package-lock.json` carries the same value.
- Semantic Versioning, with the data format as the public interface:
  - Major: a breaking change to the record format, or a removed or renamed record key.
  - Minor: new records, new record fields, new site features.
  - Patch: corrected values, bug fixes.
- While the major version is 0, a breaking change raises the minor version.

## Changelog

[CHANGELOG.md](CHANGELOG.md) follows [Keep a Changelog 1.1.0](https://keepachangelog.com/en/1.1.0/):

- Newest release first, under `## [X.Y.Z] - YYYY-MM-DD`. Unreleased changes go under `## [Unreleased]`.
- Subsections: `Added`, `Changed`, `Deprecated`, `Removed`, `Fixed`, `Security`.
- A pull request that changes user-visible behavior or data adds a line under `## [Unreleased]`.
- The file has no compare links. The release workflow reads the section whose heading contains `[X.Y.Z]`.

## Releasing

Maintainers only. Releases are made from `main` by a tag, with no release bot.

1. Create a branch. In `CHANGELOG.md`, rename `## [Unreleased]` to `## [X.Y.Z] - YYYY-MM-DD` and add an empty `## [Unreleased]` above it.
2. From `site/`, set the version: `npm version X.Y.Z --no-git-tag-version`. This updates `package.json` and `package-lock.json`.
3. Commit as `chore(release): vX.Y.Z`, open a pull request and merge it after CI passes.
4. Tag the merge commit and push the tag: `git tag vX.Y.Z && git push origin vX.Y.Z`.

The `Release` workflow (`.github/workflows/release.yml`) then:

- fails if the tag differs from `v` plus the version in `site/package.json`, or if `CHANGELOG.md` has no content for that version;
- runs `npm test` and `npm run build`;
- creates a GitHub release with the changelog section as notes and the built site as `openballistics-site-vX.Y.Z.tar.gz`. A version with a hyphen (`1.0.0-rc.1`) is marked as a pre-release.

## Site deployment

The `Deploy site` workflow (`.github/workflows/pages.yml`) runs on every push to `main`: it runs `npm test`, builds the site with `PAGES_BASE=/<repository name>/` and publishes `site/dist/` to GitHub Pages. Once per repository, set Settings > Pages > Source to "GitHub Actions".

## Dependency updates

Dependabot (`.github/dependabot.yml`) opens weekly pull requests for the npm packages in `site/` (minor and patch updates grouped into one) and for the GitHub Actions in the workflows.
