# OpenBallistics

An open database of cartridges, bullets and targets as JSON records, with shared TypeScript libraries and a Svelte website that browses and draws them.

| Directory | Contents |
|---|---|
| `data/` | The records: `data/cartridges/<family>/`, `data/bullets/`, `data/targets/` |
| `lib/` | Framework-free TypeScript libraries (geometry, drawing, targets, user data) |
| `site/` | The Svelte website. It is the only npm package in the repository |

## Requirements

Node.js 22 and npm. The repository also has a development container (`.devcontainer/devcontainer.json`).

## Install

```sh
cd site
npm ci
```

## Develop

Run these from `site/`.

| Command | What it does |
|---|---|
| `npm run dev` | Builds the search index and field sets, then starts the Vite dev server |
| `npm test` | Builds the search index and field sets, then runs the tests of `site/` and `lib/` with Vitest |
| `npm run build` | Builds the index and field sets, type-checks with svelte-check, then writes the site to `site/dist/` |
| `npm run preview` | Serves `site/dist/` locally |
| `npm run prepare-data` | Only builds the index and field sets (`npm run index`, `npm run fieldsets`) |
| `npm run sample-bullets` | Regenerates the sample bullet records in `data/bullets/` |

The site is served from `/` locally. To build for a project page, set the base path: `PAGES_BASE=/OpenBallistics/ npm run build`.

## Contribute data

1. Fork the repository and create a branch.
2. Add or edit a JSON record under `data/`. Follow the layout of the neighbouring records in the same directory.
3. From `site/`, run `npm test` and `npm run build`.
4. Open a pull request. Name the source of every value you add or change (a C.I.P. sheet, a manufacturer drawing, a measurement) so a reviewer can check it.

To report a wrong value without editing the files, use the issue templates in `.github/ISSUE_TEMPLATE/`. See [CONTRIBUTING.md](CONTRIBUTING.md) for the commit convention and code changes.

## Releases

Versions follow [Semantic Versioning](https://semver.org). The version is `version` in `site/package.json`. Changes are listed in [CHANGELOG.md](CHANGELOG.md) in the [Keep a Changelog](https://keepachangelog.com/en/1.1.0/) format. The release process is in [CONTRIBUTING.md](CONTRIBUTING.md#releasing).

## License

MIT, see [LICENSE](LICENSE). Third-party software and fonts that the built site redistributes are listed in [THIRD-PARTY.md](THIRD-PARTY.md).
