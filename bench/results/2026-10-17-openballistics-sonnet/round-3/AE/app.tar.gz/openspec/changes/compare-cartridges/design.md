# Design

## Context

Records load by key from `site/src/lib/data.ts`. `lib/shapes2d` (`adaptMetallic`, `caseOuterProfile`) builds the half-profile `[r, z][]` of a case, head face at `z = 0`. Unit conversion is `displayNumber` in `site/src/lib/units.ts`, the preference is `unitSystem()` in `site/src/lib/units.svelte.ts`. Symbols and units are `FIELD_LABELS`, `FIELD_UNITS` and `orderedFields` in `lib/core/fields.ts`.

## Goals / Non-Goals

**Goals:** reuse the shared modules; keep the row and outline logic in a framework-free module that vitest can test.

**Non-Goals:** shot cartridges, chambers, bullets, more than two cartridges, a changed record format.

## Decisions

- **Hash route with two keys.** `#/compare/<a>/<b>`, each key `encodeURIComponent`-ed like `#/c/<key>`. A path that does not split into exactly two non-empty, decodable keys falls back to the list, as `#/c/` does.
- **Logic in `site/src/lib/compare.ts`.** `compareRows(a, b, system)` and `comparePaths(a, b)` are pure. Rows: walk `GROUP_ORDER.cartridge` groups (then unknown groups sorted, as `orderedGroups`), skip arrays, skip `*Tol`, skip fields with an entry in `FIELD_UNITS`, keep finite numbers present in both records, first group wins on a repeated symbol. This is the detail page's order.
- **Outline in millimetres.** The viewBox is in millimetres, `x = z`, `y = -r`, so the profile points are used as computed and one scale holds for both by construction. The axis is the line `y = 0`, the head faces are both at `x = 0`. One `polyline` per cartridge, stroke width `OUTLINE_STROKE_MM`. Alternative, a mirrored closed polygon, rejected: it needs a second copy of the points and hides the axis.
- **Colours** are two CSS variables from the site palette, with a legend in HTML (the SVG is `role="img"`, so its children are not exposed).
- **Metric difference** is `displayNumber(b - a, 'mm')`, which drops floating-point noise (`40.1 - 39.6`) at 12 significant digits. Values use `formatValue`.
- **Shot cartridges** (`family === 'shotshell'`) are not listed in the select and get no control. A route naming one still shows its table rows and says it has no outline.
- **Page chunk.** `Compare.svelte` is a lazy chunk like the other pages. Texts in `i18n.svelte.ts`, `de` typed against `en`.

## Risks / Trade-offs

- A record without the dimensions an outline needs throws `MissingDimensionError` → caught per cartridge, message instead of outline.
- Hash route stays outside search indexing, as for other pages (see `site/UI.md`).
