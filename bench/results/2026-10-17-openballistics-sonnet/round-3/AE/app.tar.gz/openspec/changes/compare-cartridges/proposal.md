# Proposal

## Why

The site shows one cartridge at a time. A reader who weighs two cartridges (for example 308 Win. and 300 Win. Mag.) has to open two pages and compare drawings and figures by eye.

## What Changes

- A new view at `#/compare/<a>/<b>` shows the outer case profiles of two cartridges overlaid at one scale, and a table of the dimensions both publish with the difference.
- The cartridge detail page gets a `Compare with` select and a `Compare` button that open the view.
- The table follows the unit preference (metric or imperial).
- English and German texts for the new labels.

Out of scope: shot cartridges, chambers, bullets, tolerances.

## Capabilities

### New Capabilities

- `cartridge-comparison`: the compare route, its drawing, its dimension table, and the entry point on the detail page.

### Modified Capabilities

None. `openspec/specs/` holds no capabilities yet.

## Impact

- `site/src/lib/router.ts`, `site/src/lib/metadata.ts`, `site/src/App.svelte`: new route and page chunk.
- New `site/src/routes/Compare.svelte` and `site/src/lib/compare.ts`.
- `site/src/routes/Cartridge.svelte`: the select and button.
- `site/src/lib/i18n.svelte.ts`: new messages in `en` and `de`.
- `CHANGELOG.md`: an `Added` line under `Unreleased`.
- No change to `lib/` or to the record format.
