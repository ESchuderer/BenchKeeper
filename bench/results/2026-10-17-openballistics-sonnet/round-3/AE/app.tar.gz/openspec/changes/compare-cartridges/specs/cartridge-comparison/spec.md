# Spec Delta

## Purpose
Let a reader compare two metallic cartridges: their case outlines overlaid at one scale, and the dimensions both publish side by side with the difference.

## ADDED Requirements

### Requirement: Compare route
The site SHALL open a comparison of cartridges A and B at `#/compare/<a>/<b>`, where `<a>` and `<b>` are cartridge keys as used in `#/c/<key>`. The URL SHALL open the view directly and SHALL survive a reload.

#### Scenario: Direct open
- **WHEN** the reader loads `#/compare/308_win/300_win_mag`
- **THEN** the comparison of 308 Win. and 300 Win. Mag. is shown

#### Scenario: Unknown key
- **WHEN** either key is not in the catalogue, or is malformed
- **THEN** the view says the cartridge is not published and the page still mounts

### Requirement: Overlaid profiles
The view SHALL draw the outer case profile of both cartridges in one SVG with role `img` and the accessible name `Profiles of <name A> and <name B>`, at one scale, on one common axis, with the head faces at the same point. Each outline SHALL be one `path`, `polyline` or `polygon` element.

#### Scenario: Same scale
- **WHEN** a short and a long cartridge are compared
- **THEN** the lengths of the two outlines stand in the ratio of the cases' lengths

#### Scenario: Outline not available
- **WHEN** a cartridge lacks the dimensions its outline needs, or is a shot cartridge
- **THEN** the table is still shown for the dimensions both publish, and a message names the cartridge that has no outline

### Requirement: Dimension table
The view SHALL show a table with one row per dimension symbol that both cartridges publish. A dimension is a number in the record's `cartridge` part whose unit is millimetres. Tolerances are not rows. The table SHALL be named `Dimensions (mm)` or `Dimensions (in)`, with the column headers `Symbol`, the name of A, the name of B and `Difference`. The first cell of a row SHALL be the symbol as the detail page writes it. `Difference` SHALL be B minus A.

#### Scenario: Shared symbols only
- **WHEN** A publishes `L6` and `S`, and B publishes `L6` only
- **THEN** the table has a row for `L6` and none for `S`

### Requirement: Units
Values and differences SHALL follow the unit preference. Metric values are written as the detail page writes them. Imperial values are lengths in inches, converted from millimetres and not rounded further. A difference is converted and written the same way.

#### Scenario: Imperial preference
- **WHEN** the unit preference is imperial
- **THEN** the table is named `Dimensions (in)` and every figure is in inches

### Requirement: Entry point
On a metallic cartridge's detail page a select labelled `Compare with` SHALL list the other cartridges by name, and a button `Compare` SHALL open `#/compare/<this key>/<chosen key>`.

#### Scenario: Open from the detail page
- **WHEN** the reader chooses 300 Win. Mag. on the page of 308 Win. and presses `Compare`
- **THEN** the location becomes `#/compare/308_win/300_win_mag`

### Requirement: Languages
All new visible texts and accessible names SHALL exist in English and German.

#### Scenario: German site
- **WHEN** the site language is German
- **THEN** the labels of the view and the control are German
