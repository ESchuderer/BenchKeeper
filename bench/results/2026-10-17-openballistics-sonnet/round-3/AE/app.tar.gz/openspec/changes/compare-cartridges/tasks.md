# Tasks

## 1. Route

- [ ] 1.1 Test, then add `compare` to `Route`, `parse` and `href` in `site/src/lib/router.ts`; add it to `pageMetadata`.
- [ ] 1.2 Add the `Compare` page chunk to `App.svelte`.

## 2. Logic

- [ ] 2.1 Test, then write `site/src/lib/compare.ts`: `compareRows` (shared mm symbols, order, units, difference) and `comparePaths` (one polyline per outline, one scale, common head face).

## 3. Page

- [ ] 3.1 Add the English and German messages in `site/src/lib/i18n.svelte.ts`.
- [ ] 3.2 Write `site/src/routes/Compare.svelte`: SVG with role `img`, legend, `Dimensions` table, missing-outline and unknown-key messages.
- [ ] 3.3 Add the `Compare with` select and `Compare` button to `Cartridge.svelte`.

## 4. Finish

- [ ] 4.1 Run `npm test` and `npm run build` in `site/`; check the page in the browser (metric, imperial, German, reload).
- [ ] 4.2 Add the `Added` line to `CHANGELOG.md` under `Unreleased`.
- [ ] 4.3 Commit.
