# Compare two cartridges

Status: ready-for-agent

Route `#/compare/<a>/<b>` (keys as in `#/c/<key>`), opens directly and survives a reload.

- Drawing: `caseOuterProfile` of both cases in one SVG (`role="img"`, name `Profiles of <A> and <B>`), one scale, one axis, head faces aligned, one element per outline. Shot cartridges out of scope.
- Table: one row per `cartridge` dimension symbol either cartridge publishes, A's order first (number, no `FIELD_UNITS` entry, not `*Tol`). Caption `Dimensions (mm)` or `Dimensions (in)`. Headers: `Symbol`, name A, name B, `Difference` (B minus A). Symbol as `FIELD_LABELS`. A cartridge that does not publish a symbol gets an empty cell, and `Difference` is empty. The cartridge columns and `Difference` are right-aligned, headers included.
- Units follow Settings, Default units. Metric: `formatValue`. Imperial: `displayNumber(v, 'in')`. Difference converted the same way.
- Detail page: select `Compare with` (other cartridges by name) and button `Compare`.
- English and German texts.

## Decisions

- Outline drawn as the mirrored full silhouette (closed path), landscape frame, head face at the left.
- Metric difference is written with `displayNumber(d, 'mm')`, which removes float noise (`0.44`, not `0.4399999999999995`).
- A pair with a shot cartridge or an unpublished case dimension shows the table and a note instead of the drawing.
