# Changelog

All notable changes to OpenBallistics are recorded here.

The format follows [Keep a Changelog 1.1.0](https://keepachangelog.com/en/1.1.0/). The project
follows [Semantic Versioning 2.0.0](https://semver.org/spec/v2.0.0.html), as defined in
[CONTRIBUTING.md](CONTRIBUTING.md#versioning-and-releases).

Each release is a `## [X.Y.Z] - YYYY-MM-DD` heading. Entries sit under `### Added`,
`### Changed`, `### Deprecated`, `### Removed`, `### Fixed` or `### Security`. Changes not yet
released go under `## [Unreleased]`. The release workflow publishes the section of the tagged
version as the release notes, so the heading must match the tag exactly.

## [Unreleased]

### Added

- Comparison view at `#/compare/<a>/<b>`: both case profiles overlaid at one scale, and a table of
  the millimetre dimensions either cartridge publishes with their difference (empty where a
  cartridge does not publish a dimension), right-aligned. The cartridge page
  opens it from `Compare with`. Available in English and German.
- GitHub Actions workflows: CI on every pull request, deployment of the site to GitHub Pages,
  and a tag-triggered release.
- Dependabot updates for npm packages and GitHub Actions.
- README and CONTRIBUTING.md, with the commit convention and the release process.
