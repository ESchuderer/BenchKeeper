# Contributing

Pull requests from anyone are welcome. Setup, test and build commands are in the
[README](README.md). By contributing you agree that your contribution is licensed under the
repository's [MIT license](LICENSE).

## Contributing data

Records are JSON files in `data/`:

| Kind       | Location                                                                       |
|------------|--------------------------------------------------------------------------------|
| Cartridges | `data/cartridges/<family>/<key>.json`. Families: belted, pistol, rimfire, rimless, rimmed, shotshell |
| Bullets    | `data/bullets/<key>.json`                                                      |
| Targets    | `data/targets/<key>.json`                                                      |

1. To report a wrong or missing value without editing files, open an
   [issue](https://github.com/PiMetry/OpenBallistics/issues/new/choose) with the matching form.
   Name the source you read the correct value from.
2. To change a record, edit the existing file for the same kind. Copy its field layout, units and
   key naming. Do not reformat the rest of the file.
3. For a new record, copy a neighbouring file of the same kind and family. Cartridge and bullet files are named after their `key`; targets follow the naming of the existing target files.
4. Put the source in the record where the kind has a `sources` field. Submit only values you have
   the right to share.
5. From `site/`, run `npm test` and `npm run build`. Both regenerate the search index from
   `data/`. The generated index is not committed.
6. Do not edit the synthetic sample bullets (`sample: true`) by hand. Change the generator and run
   `npm run sample-bullets`, as described in `data/bullets/README.md`.

## Contributing code

1. Fork the repository, then branch from `main`.
2. Make the change. Add or update a test for new behavior.
3. From `site/`, run `npm test` and `npm run build`. A pull request runs the same two commands
   in CI and needs them to pass.
4. Open a pull request against `main`. Describe what changed and why. Link the issue it closes.
5. Update `CHANGELOG.md` under `## [Unreleased]` for any change a user of the data or the site
   would notice.

## Commit convention

Commits follow [Conventional Commits 1.0.0](https://www.conventionalcommits.org/en/v1.0.0/):

```
<type>(<optional scope>): <summary>

<optional body>
```

- Types: `feat`, `fix`, `data` (records in `data/`), `docs`, `style`, `refactor`, `perf`, `test`,
  `build`, `ci`, `chore`.
- Summary: imperative mood, lower case, no trailing period.
- Breaking change: `!` after the type or scope (`feat!: ...`), or a `BREAKING CHANGE:` footer.
- Reference issues in a footer: `Refs #12` or `Closes #12`.
- One logical change per commit.

Nothing enforces the convention yet. Reviewers ask for a rewritten message where a commit does not
follow it. Dependabot commits use the `chore(deps)` prefix.

## Versioning and releases

- The version is `version` in `site/package.json` (and the matching entries in
  `site/package-lock.json`). It starts at `0.1.0`.
- [Semantic Versioning 2.0.0](https://semver.org/spec/v2.0.0.html):
  - MAJOR: a change to the record JSON format or to the user-data export format that breaks
    existing files.
  - MINOR: new records, new features.
  - PATCH: corrected values, bug fixes.
  - While the version is below `1.0.0`, a breaking change raises MINOR.
- `CHANGELOG.md` uses [Keep a Changelog 1.1.0](https://keepachangelog.com/en/1.1.0/). Release
  headings are `## [X.Y.Z] - YYYY-MM-DD`.

### Making a release (maintainers)

1. On a branch, from `site/`, set the version in both files:

   ```sh
   npm version X.Y.Z --no-git-tag-version
   ```

2. In `CHANGELOG.md`, rename `## [Unreleased]` to `## [X.Y.Z] - YYYY-MM-DD` and add a new empty
   `## [Unreleased]` above it.
3. Commit as `chore(release): vX.Y.Z`, open a pull request, and merge it once CI passes.
4. Tag the merge commit on `main` and push the tag:

   ```sh
   git tag -a vX.Y.Z -m "vX.Y.Z"
   git push origin vX.Y.Z
   ```

5. The `Release` workflow (`.github/workflows/release.yml`) fails if the tag differs from the
   version in `site/package.json` or if `CHANGELOG.md` has no section for it. Otherwise it runs
   the tests and the build, then creates a GitHub release. The release notes are the changelog
   section, and the built site is attached as `openballistics-site-vX.Y.Z.tar.gz`. A tag with a
   hyphen (`v1.0.0-rc.1`) is published as a pre-release.

### Repository settings (maintainers, once)

- Settings, Pages, Source: GitHub Actions. The `Deploy site` workflow deploys on every push to
  `main`.
- Branch protection on `main`: require the `check` job of the `CI` workflow before merging.
