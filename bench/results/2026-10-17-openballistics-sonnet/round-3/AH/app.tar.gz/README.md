# OpenBallistics

An open database of cartridges, bullets and targets, with a website to browse it.

- `data/`: the records, one JSON file each. `cartridges/` (by family), `bullets/` and `targets/`.
- `lib/`: TypeScript libraries shared by the site and the tests: geometry, drawing, measurement,
  targets and user data.
- `site/`: the Svelte website. It holds the npm project, so every npm command below runs there.

The site is deployed to GitHub Pages from `main`. Report a wrong or missing record through the
[issue forms](https://github.com/PiMetry/OpenBallistics/issues/new/choose).

## Requirements

- Node.js 22
- npm

## Install

```sh
cd site
npm ci
```

## Develop

```sh
cd site
npm run dev
```

The command regenerates the search index and field sets from `data/`, then starts the Vite dev
server.

## Test

```sh
cd site
npm test
```

This runs Vitest over `site/src` and `lib/`. The tests read the records in `data/`.

## Build

```sh
cd site
npm run build
npm run preview
```

`build` runs `svelte-check` and then writes the site to `site/dist/`. `preview` serves that
directory. To build for a project page, set the base path:

```sh
PAGES_BASE=/OpenBallistics/ npm run build
```

Other scripts in `site/package.json`:

| Script                  | Purpose                                                            |
|-------------------------|--------------------------------------------------------------------|
| `npm run index`         | Regenerate the search index from `data/`                           |
| `npm run fieldsets`     | Regenerate the field sets from `data/`                             |
| `npm run prepare-data`  | Both of the above. `dev`, `test` and `build` run it first          |
| `npm run sample-bullets`| Regenerate the sample bullet records (see `data/bullets/README.md`)|

## Contribute

Read [CONTRIBUTING.md](CONTRIBUTING.md). It covers contributing data, the commit convention, the
pull request checks, versioning and releases.

Pull requests run the checks in `.github/workflows/ci.yml`: `npm ci`, `npm test` and
`npm run build`, in `site/`.

## Changelog

[CHANGELOG.md](CHANGELOG.md), in the [Keep a Changelog](https://keepachangelog.com/en/1.1.0/)
format. Versions follow [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## License

[MIT](LICENSE), Copyright (c) 2026 PiMetry. Third-party software used by the site and its terms
are listed in [THIRD-PARTY.md](THIRD-PARTY.md).
