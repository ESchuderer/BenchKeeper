import { readFileSync } from 'node:fs';
import { join } from 'node:path';
import { describe, expect, it } from 'vitest';
import { CARTRIDGES } from '@lib/testing/fixtures';
import { displayNumber } from './units';
import type { Record_ } from '@lib/core';
import { dimensionRows, outlines } from './compare';
import { entries } from './data';

const load = (key: string): Record_ => {
  const family = entries.find((entry) => entry.key === key)!.family;
  return JSON.parse(readFileSync(join(CARTRIDGES, family, `${key}.json`), 'utf8'));
};
const a = load('308_win');
const b = load('300_win_mag');

describe('dimension rows', () => {
  it('lists published millimetre dimensions with the detail page labels', () => {
    const rows = dimensionRows(a, b, 'metric');
    const symbols = rows.map((row) => row.symbol);
    expect(symbols).toContain('e min');
    expect(symbols).toContain('L3');
    expect(new Set(symbols).size).toBe(symbols.length);
    for (const unit of ['Pmax', 'PK', 'α', 'δ', 'β', 'M']) expect(symbols).not.toContain(unit);
    expect(symbols.some((symbol) => symbol.endsWith('Tol'))).toBe(false);
  });
  it('writes metric values unrounded and the difference as B minus A', () => {
    const row = dimensionRows(a, b, 'metric').find((r) => r.symbol === 'L3')!;
    const [x, y] = [a.cartridge.lengths as Record<string, number>, b.cartridge.lengths as Record<string, number>];
    expect(row.a).toBe(String(x.L3));
    expect(row.b).toBe(String(y.L3));
    expect(row.difference).toBe(displayNumber(y.L3! - x.L3!, 'mm'));
  });
  it('converts values and differences to inches', () => {
    const row = dimensionRows(a, b, 'imperial').find((r) => r.symbol === 'L3')!;
    const [x, y] = [(a.cartridge.lengths as Record<string, number>).L3!, (b.cartridge.lengths as Record<string, number>).L3!];
    expect(row.a).toBe(displayNumber(x, 'in'));
    expect(row.difference).toBe(displayNumber(y - x, 'in'));
  });
  it('lists every symbol either cartridge publishes, leaving unpublished cells empty', () => {
    const rows = dimensionRows(a, b, 'metric');
    const only = (symbol: string) => rows.find((row) => row.symbol === symbol)!;
    expect(only('delta L')).toMatchObject({ b: '', difference: '' });
    expect(only('delta L').a).not.toBe('');
    expect(only('R3')).toMatchObject({ a: '', difference: '' });
    expect(only('R3').b).not.toBe('');
    expect(new Set(rows.map((row) => row.symbol)).size).toBe(rows.length);
  });
  it('lists A first, then the symbols only B publishes', () => {
    const one = { ...a, cartridge: { lengths: { L3: 1 } } } as unknown as Record_;
    const two = { ...b, cartridge: { lengths: { L3: 2 }, radii: { R3: 3 } } } as unknown as Record_;
    expect(dimensionRows(one, two, 'metric').map((row) => row.symbol)).toEqual(['L3', 'R3']);
  });
  it('writes a difference without binary noise', () => {
    const make = (L3: number) => ({ ...a, cartridge: { lengths: { L3 } } }) as unknown as Record_;
    expect(dimensionRows(make(0.1), make(0.3), 'metric')[0]!.difference).toBe('0.2');
  });
});

describe('outlines', () => {
  it('puts both head faces at the same point on one axis', () => {
    const o = outlines(a, b)!;
    const points = (path: string) => [...path.matchAll(/[ML]([-\d.]+),([-\d.]+)/g)].map((m) => [Number(m[1]), Number(m[2])] as const);
    const left = (path: string) => Math.min(...points(path).map(([x]) => x));
    const middle = (path: string) => {
      const ys = points(path).map(([, y]) => y);
      return (Math.min(...ys) + Math.max(...ys)) / 2;
    };
    expect(left(o.a)).toBe(left(o.b));
    expect(middle(o.a)).toBeCloseTo(middle(o.b), 6);
    expect(o.width).toBeGreaterThan(0);
  });
  it('draws nothing for a shot cartridge', () => {
    const shot = load('12');
    expect(outlines(a, shot)).toBeNull();
  });
});
