/** What the comparison view shows: the rows either cartridge publishes, and their two outlines. */

import { FIELD_LABELS, FIELD_UNITS, GROUP_ORDER, formatValue, orderedFields, type Group, type Record_ } from '@lib/core';
import { viewportFor, fullSectionPath } from '@lib/geom';
import { adaptMetallic, caseOuterProfile, type CartridgeRecord } from '@lib/shapes2d';
import { displayNumber, type UnitSystem } from './units';

export interface Row {
  symbol: string;
  a: string;
  b: string;
  difference: string;
}

/** Pixels per millimetre of the comparison drawing. */
const SCALE = 8;

/** The millimetre dimensions of a record's `cartridge` part, by field name, in the detail page's order. */
function dimensions(record: Record_): Map<string, number> {
  const found = new Map<string, number>();
  const groups = [...GROUP_ORDER.cartridge, ...Object.keys(record.cartridge).filter((g) => !GROUP_ORDER.cartridge.includes(g)).sort()];
  for (const name of groups) {
    const group = record.cartridge[name];
    if (!group || Array.isArray(group)) continue;
    for (const field of orderedFields('cartridge', name, group as Group)) {
      const value = (group as Group)[field];
      if (typeof value === 'number' && !(field in FIELD_UNITS) && !field.endsWith('Tol') && !found.has(field)) found.set(field, value);
    }
  }
  return found;
}

export function dimensionRows(a: Record_, b: Record_, system: UnitSystem): Row[] {
  const [first, second] = [dimensions(a), dimensions(b)];
  const write = (mm: number | undefined) => (mm === undefined ? '' : system === 'metric' ? formatValue(mm)! : displayNumber(mm, 'in'));
  return [...new Set([...first.keys(), ...second.keys()])].map((field) => {
    const [x, y] = [first.get(field), second.get(field)];
    return {
      symbol: FIELD_LABELS[field] ?? field,
      a: write(x),
      b: write(y),
      // `displayNumber` also removes the binary noise of a subtraction (0.44, not 0.4399999999999995).
      difference: x === undefined || y === undefined ? '' : displayNumber(y - x, system === 'metric' ? 'mm' : 'in')
    };
  });
}

export interface Outlines {
  width: number;
  height: number;
  a: string;
  b: string;
}

/** Both cases' outlines in one viewport, or `null` for a shot cartridge or a case the record cannot draw. */
export function outlines(a: Record_, b: Record_): Outlines | null {
  if (a.family === 'shotshell' || b.family === 'shotshell') return null;
  try {
    const profiles = [a, b].map((record) => caseOuterProfile(adaptMetallic(record as unknown as CartridgeRecord)));
    const view = viewportFor(profiles, { scale: SCALE, frame: 'landscape' });
    return { width: view.width, height: view.height, a: fullSectionPath(profiles[0]!, view), b: fullSectionPath(profiles[1]!, view) };
  } catch {
    // shortcut: any failure hides the drawing, including a bug. The table stays.
    return null;
  }
}
