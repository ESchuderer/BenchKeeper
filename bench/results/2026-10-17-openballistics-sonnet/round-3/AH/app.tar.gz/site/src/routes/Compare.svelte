<script lang="ts">
  import PageHeader from '../components/PageHeader.svelte';
  import { load } from '../lib/data';
  import { dimensionRows, outlines } from '../lib/compare';
  import { href } from '../lib/router';
  import { t } from '../lib/i18n.svelte';
  import { unitSystem } from '../lib/units.svelte';

  let { a, b }: { a: string; b: string } = $props();
  const records = $derived(Promise.all([load(a), load(b)]));
</script>

<div data-ui="Compare" class="contents">
{#await records}
  <p class="status">{t('site.loading')}</p>
{:then [first, second]}
  {@const drawing = outlines(first, second)}
  {@const rows = dimensionRows(first, second, unitSystem())}
  <PageHeader title={`${first.name} / ${second.name}`} description={t('compare.lede')} backHref={href.cartridge(a)} backLabel={first.name} />

  {#if drawing}
    <svg role="img" aria-label={t('compare.profiles', { a: first.name, b: second.name })}
      viewBox={`0 0 ${drawing.width} ${drawing.height}`} width={drawing.width} height={drawing.height}
      class="mb-2 h-auto max-w-full" fill="none" stroke-width="1.5" stroke-linejoin="round">
      <path d={drawing.a} stroke="var(--foreground)" />
      <path d={drawing.b} stroke="var(--link)" stroke-dasharray="6 3" />
    </svg>
    <p class="mb-8 flex flex-wrap gap-x-6 text-sm">
      <span><span aria-hidden="true">―</span> {first.name}</span>
      <span><span aria-hidden="true">- -</span> {second.name}</span>
    </p>
  {:else}
    <p class="mb-8 text-sm text-muted-foreground">{t('compare.noDrawing')}</p>
  {/if}

  {#if rows.length}
    <div class="overflow-x-auto">
      <table class="w-full text-sm">
        <caption class="mb-2 text-left font-semibold">{t('compare.table', { unit: unitSystem() === 'metric' ? 'mm' : 'in' })}</caption>
        <thead>
          <tr class="border-b text-left">
            <th scope="col" class="py-2 pr-4">{t('compare.symbol')}</th>
            <th scope="col" class="py-2 pr-4 text-right">{first.name}</th>
            <th scope="col" class="py-2 pr-4 text-right">{second.name}</th>
            <th scope="col" class="py-2 text-right">{t('compare.difference')}</th>
          </tr>
        </thead>
        <tbody>
          {#each rows as row (row.symbol)}
            <tr class="border-b">
              <th scope="row" class="num py-2 pr-4 text-left font-normal">{row.symbol}</th>
              <td class="num py-2 pr-4 text-right">{row.a}</td>
              <td class="num py-2 pr-4 text-right">{row.b}</td>
              <td class="num py-2 text-right">{row.difference}</td>
            </tr>
          {/each}
        </tbody>
      </table>
    </div>
  {:else}
    <p>{t('compare.none')}</p>
  {/if}
{:catch error}
  <p class="status error">{error.message} <a href={href.list()}>{t('record.back')}</a></p>
{/await}
</div>
