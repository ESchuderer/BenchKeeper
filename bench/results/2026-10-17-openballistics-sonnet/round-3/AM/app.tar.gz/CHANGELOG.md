# Changelog

All notable changes to OpenBallistics are recorded in this file.

The format follows [Keep a Changelog 1.1.0](https://keepachangelog.com/en/1.1.0/) and the project
follows [Semantic Versioning 2.0.0](https://semver.org/spec/v2.0.0.html). Each release has a
heading `## [X.Y.Z] - YYYY-MM-DD`, newest first, with entries under any of `Added`, `Changed`,
`Deprecated`, `Removed`, `Fixed` and `Security`. Unreleased changes collect under `## [Unreleased]`.
The release workflow publishes the section of the tagged version as the release notes.

## [Unreleased]

### Added

- Compare view at `#/compare/<a>/<b>`: the case outlines of two cartridges on one axis and a table of the
  dimensions either publishes, in the chosen units. A `Compare with` control on each cartridge page opens it.
- GitHub Actions workflows: checks on every pull request, deployment of the site to GitHub Pages
  and a tag-triggered release.
- Dependabot updates for the site's npm packages and the workflow actions.
- Contributor documentation: `README.md` and `CONTRIBUTING.md`.
