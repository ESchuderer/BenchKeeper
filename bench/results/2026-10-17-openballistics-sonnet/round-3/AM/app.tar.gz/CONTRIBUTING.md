# Contributing

Setup, test and build commands are in [README.md](README.md). By contributing you agree that your
contribution is licensed under the [MIT license](LICENSE).

## Pull requests

1. Fork the repository and branch from `main`.
2. Make one change per pull request.
3. In `site/`, run `npm test` and `npm run build`. CI runs the same two commands on every pull
   request, and both must pass.
4. Add a line under `## [Unreleased]` in [CHANGELOG.md](CHANGELOG.md) for any change a user of the
   site or the data would notice.

## Commit messages

Commits follow [Conventional Commits 1.0.0](https://www.conventionalcommits.org/en/v1.0.0/):

```
<type>(<optional scope>): <summary in the imperative, no final period>
```

| Type | Use for |
| --- | --- |
| `feat` | A new feature of the site or the libraries |
| `fix` | A bug fix |
| `data` | Adding or correcting records in `data/` |
| `docs` | Documentation only |
| `test` | Tests only |
| `refactor` | A change that keeps behavior |
| `perf` | A performance change |
| `build` | Build scripts and dependencies |
| `ci` | Workflows in `.github/` |
| `chore` | Anything else |

Mark a breaking change with `!` after the type (`feat!: ...`) or a `BREAKING CHANGE:` footer.
Pull requests are squash-merged, so the pull request title follows the same format.

## Versioning

[Semantic Versioning 2.0.0](https://semver.org/spec/v2.0.0.html), for the site, the libraries and
the data together. The version is the `version` field in `site/package.json`.

- Major: a breaking change to the record format or to the user-data export format.
- Minor: new features, new records.
- Patch: fixes and corrected records.

Versions below 1.0.0 may break in a minor release.

## Releasing

For maintainers. A release is a tag `vX.Y.Z` on `main`.

1. Branch from `main`. In `site/`, run `npm version <X.Y.Z> --no-git-tag-version`. It updates
   `package.json` and `package-lock.json`.
2. In `CHANGELOG.md`, rename `## [Unreleased]` to `## [X.Y.Z] - YYYY-MM-DD` and add an empty
   `## [Unreleased]` above it.
3. Commit as `chore: release X.Y.Z`, open a pull request and merge it.
4. Tag the merge commit and push the tag:

   ```sh
   git tag vX.Y.Z
   git push origin vX.Y.Z
   ```

The [release workflow](.github/workflows/release.yml) runs the CI checks, fails if the tag differs
from `version` in `site/package.json` or if the changelog has no entries for the version, and then
creates the GitHub release with that changelog section as its notes. A tag with a suffix such as
`v1.0.0-rc.1` is marked as a pre-release.

## Maintainer setup

- Settings > Pages > Source: GitHub Actions. [pages.yml](.github/workflows/pages.yml) deploys
  `main` to `https://<owner>.github.io/<repository>/`. For a custom domain at the root, remove the
  `PAGES_BASE` variable from that workflow.
- Dependabot opens weekly pull requests for the npm packages in `site/` and for the actions in
  `.github/workflows/` ([dependabot.yml](.github/dependabot.yml)).
- Branch protection on `main`: require the `check` job of the CI workflow.
