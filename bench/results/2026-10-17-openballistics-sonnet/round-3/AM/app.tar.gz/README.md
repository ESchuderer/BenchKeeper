# OpenBallistics

An open database of cartridges, bullets and targets, with a website to browse it. The records are
JSON files in `data/`. The website is a Svelte app in `site/` that draws the records, and it is
published on GitHub Pages at <https://pimetry.github.io/OpenBallistics/>.

OpenBallistics is an independent project. Cartridge and chamber figures follow the C.I.P. tables.

## Layout

| Path | Contents |
| --- | --- |
| `data/cartridges/<family>/` | One record per cartridge, `<key>.json`. Families: `belted`, `pistol`, `rimfire`, `rimless`, `rimmed`, `shotshell`. |
| `data/bullets/` | One record per bullet, `<key>.json` (see `data/bullets/README.md`). |
| `data/targets/` | One record per target, `<id>.json`. |
| `lib/` | TypeScript libraries shared by the site: geometry, drawing, targets, user data. Their tests run with the site's. |
| `site/` | The Svelte website and its build scripts. All npm commands run here. |
| `fixtures/` | Test fixtures. |

## Requirements

Node.js 22 and npm. CI uses Node 22.

## Install

```sh
cd site
npm ci
```

## Develop

```sh
cd site
npm run dev
```

This prepares the data and starts the Vite dev server. Other scripts:

| Command | Does |
| --- | --- |
| `npm run prepare-data` | Generates the search index and field sets from `data/` (`npm run index`, `npm run fieldsets`). |
| `npm run sample-bullets` | Regenerates the synthetic sample bullets in `data/bullets/`. |
| `npm run preview` | Serves the production build from `site/dist/`. |

## Test

```sh
cd site
npm test
```

Runs Vitest over the site (`site/src/`) and the libraries (`lib/`), after preparing the data.

## Build

```sh
cd site
npm run build
```

Prepares the data, runs `svelte-check`, then builds the site into `site/dist/`. To build for a
project page, set the base path: `PAGES_BASE=/OpenBallistics/ npm run build`.

## Contribute data

- Report a wrong or missing value with one of the [issue templates](https://github.com/PiMetry/OpenBallistics/issues/new/choose).
  Name the source you read the correct value from.
- To change records yourself, edit or add the JSON file in `data/`, keeping the file name equal to
  the record's `key` (targets: `id`). Cite the source in the pull request. Run `npm test` and
  `npm run build` in `site/` before opening it.
- Bullet records marked `sample: true` are synthetic. Records for real bullets list their
  `sources`.

Code and documentation changes follow the same steps. Commit messages, pull requests and releases
are described in [CONTRIBUTING.md](CONTRIBUTING.md).

## Versions and releases

The version is the `version` field in `site/package.json`. Releases are tags `vX.Y.Z`, and
[CHANGELOG.md](CHANGELOG.md) lists the changes. The steps are in
[CONTRIBUTING.md](CONTRIBUTING.md#releasing).

## License

[MIT](LICENSE), Copyright (c) 2026 PiMetry. Third-party software and fonts the site redistributes
are listed in [THIRD-PARTY.md](THIRD-PARTY.md).
