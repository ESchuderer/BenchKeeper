import { readFileSync, readdirSync } from 'node:fs';
import { join } from 'node:path';
import { describe, expect, it } from 'vitest';
import { CARTRIDGES } from '@lib/testing/fixtures';
import type { Record_ } from '@lib/core';
import { compareProfiles, compareRows } from './compare';

function record(key: string): Record_ {
  for (const family of readdirSync(CARTRIDGES)) {
    try { return JSON.parse(readFileSync(join(CARTRIDGES, family, `${key}.json`), 'utf8')) as Record_; } catch { /* next family */ }
  }
  throw new Error(key);
}
const win308 = record('308_win');
const mag300 = record('300_win_mag');
const make = (cartridge: Record_['cartridge']): Record_ => ({ ...win308, cartridge });

describe('compareRows', () => {
  it('lists every published millimetre dimension of either record, A first, B minus A where both publish it', () => {
    const a = make({ lengths: { L1: 39.62, L1Tol: -0.2, L3: 51.18 }, caseHead: { eMin: 1.4, beta: 35, delta: 36 }, pressures: { Pmax: 4150 }, powderChamber: { P1: 1 } });
    const b = make({ lengths: { L1: 40, L1Tol: -0.1, L3: 51.18, L6: 3 }, caseHead: { eMin: 1.1, beta: 30, delta: 36 }, pressures: { Pmax: 4000 }, powderChamber: { P1: null } });
    expect(compareRows(a, b, 'metric')).toEqual([
      { symbol: 'L1', a: '39.62', b: '40', difference: '0.38' },
      { symbol: 'L3', a: '51.18', b: '51.18', difference: '0' },
      { symbol: 'e min', a: '1.4', b: '1.1', difference: '-0.3' },
      { symbol: 'P1', a: '1', b: '', difference: '' },
      { symbol: 'L6', a: '', b: '3', difference: '' }
    ]);
  });
  it('converts values and differences to inches without further rounding', () => {
    const rows = compareRows(make({ lengths: { L1: 25.4 } }), make({ lengths: { L1: 50.8 } }), 'imperial');
    expect(rows).toEqual([{ symbol: 'L1', a: '1', b: '2', difference: '1' }]);
  });
  it('skips the repeating groups of shot cartridges', () => {
    const shot = record('12');
    const rows = compareRows(shot, shot, 'metric');
    expect(rows.every((row) => row.difference === '0')).toBe(true);
    expect(compareRows(shot, win308, 'metric')).toBeInstanceOf(Array);
  });
  it('compares two real records', () => {
    const rows = compareRows(win308, mag300, 'metric');
    expect(rows.find((row) => row.symbol === 'L3')).toMatchObject({ a: '51.18', b: '66.55' });
    expect(rows.find((row) => row.symbol === 'delta L')).toMatchObject({ b: '', difference: '' });
    expect(rows.find((row) => row.symbol === 'R3')).toMatchObject({ a: '', difference: '' });
    expect(rows.map((row) => row.symbol)).not.toContain('Pmax');
    expect(rows.map((row) => row.symbol)).not.toContain('α');
  });
});

describe('compareProfiles', () => {
  it('draws both outlines in one frame, and nothing where a case cannot be drawn', () => {
    const drawn = compareProfiles(win308, mag300, 4)!;
    expect(drawn.a).not.toBe(drawn.b);
    expect(drawn.a.startsWith('M')).toBe(true);
    expect(compareProfiles(win308, make({}), 4)).toBeNull();
  });
});
