/** What the compare view shows: the dimensions two records publish and their outlines on one axis. */

import { FIELD_LABELS, FIELD_UNITS, GROUP_ORDER, formatValue, orderedFields, toleranceFor, type Record_ } from '@lib/core';
import { OUTLINE_STROKE_MM, fullSectionPath, viewportFor } from '@lib/geom';
import { adaptMetallic, caseOuterProfile, type CartridgeRecord } from '@lib/shapes2d/case';
import { displayNumber, type UnitSystem } from './units';

export interface Row {
  symbol: string;
  a: string;
  b: string;
  difference: string;
}

/** The numbers of the `cartridge` part published in millimetres, by symbol, in the detail page's order. */
function dimensions(record: Record_): Map<string, number> {
  const found = new Map<string, number>();
  const groups = [
    ...GROUP_ORDER.cartridge.filter((name) => name in record.cartridge),
    ...Object.keys(record.cartridge).filter((name) => !GROUP_ORDER.cartridge.includes(name)).sort()
  ];
  for (const name of groups) {
    const group = record.cartridge[name];
    if (!group || Array.isArray(group)) continue;
    for (const field of orderedFields('cartridge', name, group)) {
      const value = group[field];
      if (typeof value !== 'number' || toleranceFor(field) || field in FIELD_UNITS) continue;
      const symbol = FIELD_LABELS[field] ?? field;
      if (!found.has(symbol)) found.set(symbol, value);
    }
  }
  return found;
}

export function compareRows(a: Record_, b: Record_, system: UnitSystem): Row[] {
  const first = dimensions(a);
  const second = dimensions(b);
  const write = (mm: number | undefined) => (mm === undefined ? '' : system === 'imperial' ? displayNumber(mm, 'in') : formatValue(Number(mm.toPrecision(12))) ?? '');
  // A's order, then the symbols only B publishes in B's order.
  return [...new Set([...first.keys(), ...second.keys()])].map((symbol) => {
    const x = first.get(symbol);
    const y = second.get(symbol);
    return { symbol, a: write(x), b: write(y), difference: x === undefined || y === undefined ? '' : write(y - x) };
  });
}

export interface Profiles {
  width: number;
  height: number;
  strokeWidth: number;
  /** The two outlines as path data, in one coordinate system. */
  a: string;
  b: string;
}

/** `null` where a record publishes too little to draw its case. */
export function compareProfiles(a: Record_, b: Record_, scale: number): Profiles | null {
  try {
    const outlines = [a, b].map((record) => caseOuterProfile(adaptMetallic(record as unknown as CartridgeRecord)));
    const view = viewportFor(outlines, { scale, marginMm: 2 });
    return {
      width: view.width,
      height: view.height,
      strokeWidth: OUTLINE_STROKE_MM * scale,
      a: fullSectionPath(outlines[0]!, view),
      b: fullSectionPath(outlines[1]!, view)
    };
  } catch {
    return null;
  }
}
