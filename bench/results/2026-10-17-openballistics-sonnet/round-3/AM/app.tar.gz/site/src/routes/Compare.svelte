<script lang="ts">
  import { byKey, load } from '../lib/data';
  import { compareProfiles, compareRows } from '../lib/compare';
  import { href } from '../lib/router';
  import { t } from '../lib/i18n.svelte';
  import { unitSystem } from '../lib/units.svelte';
  import { PX_PER_MM } from '@lib/core';

  let { a, b }: { a: string; b: string } = $props();

  const entries = $derived([byKey(a), byKey(b)]);
  const missing = $derived(entries.findIndex((entry) => !entry));
  // Shot cartridges are out of scope for the drawing: their table is shown, their outline is not.
  const shot = $derived(entries.some((entry) => entry?.family === 'shotshell'));
</script>

<div data-ui="Compare" class="contents">
  {#if missing >= 0}
    <p class="status error">{t('compare.notFound', { key: missing ? b : a })}</p>
  {:else}
    {#await Promise.all([load(a), load(b)])}
      <p class="status">{t('site.loading')}</p>
    {:then [first, second]}
      {@const profiles = shot ? null : compareProfiles(first!, second!, PX_PER_MM)}
      {@const rows = compareRows(first!, second!, unitSystem())}
      <h1 class="text-2xl font-semibold">{t('compare.heading', { a: first!.name, b: second!.name })}</h1>

      {#if profiles}
        <ul class="my-4 flex gap-6">
          <li class="flex items-center gap-2"><span class="swatch" style="background: var(--dim-ink)"></span>{first!.name}</li>
          <li class="flex items-center gap-2"><span class="swatch" style="background: var(--alert)"></span>{second!.name}</li>
        </ul>
        <svg
          role="img"
          aria-label={t('compare.profiles', { a: first!.name, b: second!.name })}
          viewBox="0 0 {profiles.width} {profiles.height}"
          width={profiles.width}
          height={profiles.height}
          class="max-w-full h-auto"
          fill="none"
          stroke-width={profiles.strokeWidth}
        >
          <path d={profiles.a} style="stroke: var(--dim-ink)" />
          <path d={profiles.b} style="stroke: var(--alert)" />
        </svg>
      {:else}
        <p class="status">{t(shot ? 'compare.shot' : 'compare.noDrawing')}</p>
      {/if}

      {#if rows.length}
        <div class="overflow-x-auto">
          <table class="my-6 w-full text-left">
            <caption class="mb-2 text-left font-semibold">{t('compare.dimensions', { unit: unitSystem() === 'imperial' ? 'in' : 'mm' })}</caption>
            <thead>
              <tr>
                <th scope="col">{t('compare.symbol')}</th>
                <th scope="col" class="num">{first!.name}</th>
                <th scope="col" class="num">{second!.name}</th>
                <th scope="col" class="num">{t('compare.difference')}</th>
              </tr>
            </thead>
            <tbody>
              {#each rows as row (row.symbol)}
                <tr>
                  <th scope="row" class="num">{row.symbol}</th>
                  <td class="num">{row.a}</td>
                  <td class="num">{row.b}</td>
                  <td class="num">{row.difference}</td>
                </tr>
              {/each}
            </tbody>
          </table>
        </div>
      {:else}
        <p class="status">{t('compare.noShared')}</p>
      {/if}
    {:catch error}
      <p class="status error">{error.message}</p>
    {/await}
    <p class="foot"><a href={href.cartridge(a)}>{entries[0]?.name}</a> · <a href={href.cartridge(b)}>{entries[1]?.name}</a></p>
  {/if}
</div>

<style>
  .swatch { display: inline-block; width: 1.5rem; height: .25rem; }
  th, td { padding: .25rem .75rem .25rem 0; border-bottom: 1px solid var(--rule); }
  .num { font-variant-numeric: tabular-nums; }
  th, td { text-align: right; }
  th:first-child, td:first-child { text-align: left; }
</style>
