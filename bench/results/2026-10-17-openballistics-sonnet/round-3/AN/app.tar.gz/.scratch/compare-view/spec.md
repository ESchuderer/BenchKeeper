# Compare view

Status: ready-for-agent

## Goal

A view that compares two cartridges at `#/compare/<a>/<b>`, where `<a>` and `<b>` are the keys used in `#/c/<key>`.

## Acceptance criteria

- The URL opens the view directly and survives a reload.
- One SVG (`role="img"`, name `Profiles of <name A> and <name B>`) overlays `caseOuterProfile` of both cases at one scale, on one axis, head faces at the same point. Each outline is one element (`path`).
- A table named `Dimensions (mm)` or `Dimensions (in)` has one row per dimension symbol either cartridge publishes. Where a cartridge does not publish it, its cell and the `Difference` cell are empty. A dimension is a number in the record's `cartridge` part with no entry in `FIELD_UNITS`. Tolerances are not rows.
- Columns: `Symbol`, name of A, name of B, `Difference` (B minus A). The cells of the last three columns and their headers are right-aligned. The symbol is written as `FIELD_LABELS` writes it.
- Metric values use `formatValue`. Imperial values and differences use `displayNumber(value, 'in')`.
- The detail page has a select labelled `Compare with` (other cartridges by name) and a button `Compare` that opens `#/compare/<this key>/<chosen key>`.
- English and German texts.

## Decisions

- Shot cartridges are not drawn. If either case cannot be drawn, the table is still shown with a notice in place of the drawing.
- The silhouette is the half-profile mirrored about the axis (`fullSectionPath`).
- The metric difference is cut to 12 significant digits, as `displayNumber` does, to avoid binary float noise.
- The select lists every other cartridge and starts on the first by name.

## Comments
