# Changelog

All notable changes to this project are recorded in this file.

Format: one `## [x.y.z](compare-url) (YYYY-MM-DD)` heading per release, newest first, with `###`
sections for Features, Bug fixes, Performance, Reverts, Documentation and Refactoring, each entry
linking its commit. Versions follow [Semantic Versioning](https://semver.org/). The file is written
by [release-please](https://github.com/googleapis/release-please) from Conventional Commits when a
release PR is merged. Do not edit released entries by hand. See `CONTRIBUTING.md`.
