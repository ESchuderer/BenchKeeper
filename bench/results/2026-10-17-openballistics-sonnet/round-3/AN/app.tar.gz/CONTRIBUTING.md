# Contributing

Setup, test and build commands are in [README.md](README.md).

## Workflow

1. Fork the repository and branch from `main`.
2. Make the change. Run `npm test` and `npm run build` in `site/` (see the README).
3. Open a pull request against `main`. CI (`.github/workflows/ci.yml`) runs the same two commands, and
   `.github/workflows/pr-title.yml` checks the title.
4. Pull requests are squash-merged. The pull request title becomes the commit message on `main`.

## Commit convention

[Conventional Commits 1.0.0](https://www.conventionalcommits.org/en/v1.0.0/):

```
<type>(<scope>): <summary>

<body>

<footer>
```

- Types: `feat`, `fix`, `perf`, `docs`, `refactor`, `test`, `build`, `ci`, `chore`, `revert`.
- Scope is optional. In use: `data`, `lib`, `site`, `ci`, `deps`.
- Summary: imperative, starts with a lower-case letter or digit, no trailing period.
- Breaking change: `!` after the type or scope, or a `BREAKING CHANGE:` footer.
- Reference issues in the footer: `Refs #123`, `Closes #123`.
- The pull request title follows the same format. The `PR title` check fails otherwise.

Examples:

```
feat(data): add 6.5 PRC cartridge
fix(data): correct L3 of 308 Win.
feat(site): add chamber drawing export
docs: describe the release process
```

## Versioning and releases

- Scheme: [Semantic Versioning](https://semver.org/). The project is below 1.0.0, so a breaking
  change raises the minor version.
- Commit types decide the bump: `feat` raises the minor version, `fix` the patch version, a breaking
  change the major version (the minor version before 1.0.0). Other types do not release on their own.
- Where the version is kept: `.release-please-manifest.json` is the source of truth. release-please
  copies it to `version.txt` and `site/package.json`. Do not edit these by hand. The root `version` in
  `site/package-lock.json` is not updated by release-please, so npm rewrites it on the next install.
- How a release is made: [release-please](https://github.com/googleapis/release-please) runs from
  `.github/workflows/release.yml` on every push to `main` and keeps one release PR open. A maintainer
  merges that PR. The merge creates the tag `v<version>`, a GitHub release with notes from the changelog,
  and attaches `openballistics-data-v<version>.tar.gz` (the `data/` directory).
- To force a version, put `Release-As: x.y.z` in the footer of a commit on `main`.
- Changelog: `CHANGELOG.md`, format stated at its top. Visible sections: Features, Bug fixes,
  Performance, Reverts, Documentation, Refactoring. `test`, `build`, `ci` and `chore` commits are hidden.
- Data changes that should appear in the changelog and trigger a release use `feat(data)` or `fix(data)`.

## Contributing data

Records are JSON files in `data/`:

| Kind | Path | Key |
|---|---|---|
| Cartridge and chamber | `data/cartridges/<family>/<key>.json` | file name, e.g. `rimless/308_win.json` |
| Bullet | `data/bullets/<key>.json` | `key` field and file name |
| Target | `data/targets/<id>.json` | `id` field and file name |

Families: `belted`, `pistol`, `rimfire`, `rimless`, `rimmed`, `shotshell`.

- Cite a source for every value. The issue templates (`.github/ISSUE_TEMPLATE/`) ask for one: for
  cartridges the C.I.P. sheet, for bullets the maker's published figures. Records without a source
  are accepted only when marked as samples (`"sample": true`, see `data/bullets/README.md`).
- Start from a neighbouring record of the same kind and keep its structure and units.
- Run `npm test` in `site/`. It regenerates the search indexes from `data/` and runs the tests.
- Run `npm run build` in `site/` to confirm the site still builds with the new record.
- Do not edit `fixtures/` unless the drawings change on purpose. The tests compare renderer output
  with those files.
- To report a wrong value without a fix, open an issue from a template: cartridge data, bullet, or site.
- Contributions are licensed under the repository licence, see [LICENSE](LICENSE).

## Maintainer settings

Set once in the GitHub repository:

- Settings > Pages > Source: GitHub Actions.
- Settings > Actions > General > Workflow permissions: allow GitHub Actions to create and approve
  pull requests (release-please needs it).
- Settings > General > Pull Requests: allow squash merging only, default message "Pull request
  title".
- Branch protection on `main`: require the `Test and build` and `Conventional title` checks.
- Secret `RELEASE_PLEASE_TOKEN` (a personal access token or GitHub App token): required when those checks
  are required. Pull requests opened with the default `GITHUB_TOKEN` do not start workflows, so the
  release PR would wait for checks that never run. Without the secret, close and reopen the release PR
  to start them.
