# OpenBallistics

An open database of cartridges, bullets and targets as JSON records, with shared TypeScript
libraries and a Svelte website that browses the records and draws them.

The site is published with GitHub Pages: <https://pimetry.github.io/OpenBallistics/>.

## Repository layout

| Path | Content |
|---|---|
| `data/` | JSON records: `cartridges/<family>/`, `bullets/`, `targets/` |
| `lib/` | Shared TypeScript libraries (`core`, `geometry`, `render2d`, `targets`, `userdata`, ...) and their tests |
| `site/` | Svelte 5 + Vite website, its npm scripts and `package.json` |
| `fixtures/` | Reference data for the drawing tests |
| `THIRD-PARTY.md` | Third-party software and licences |

All npm commands run in `site/`. There is no `package.json` at the repository root.

## Requirements

- Node.js 22 (see `.node-version`) and npm.

## Install

```sh
cd site
npm ci
```

## Develop

```sh
npm run dev
```

Regenerates the search indexes from `data/`, then starts the Vite dev server.

## Test

```sh
npm test
```

Regenerates the indexes (`pretest`), then runs Vitest on `site/src/**` and `lib/**`.

## Build

```sh
npm run build
npm run preview
```

`build` regenerates the indexes, runs `svelte-check` and writes the site to `site/dist/`. `preview`
serves that directory. For a build under a sub-path, set `PAGES_BASE`, e.g.
`PAGES_BASE=/OpenBallistics/ npm run build`.

## Other scripts

| Command | Effect |
|---|---|
| `npm run index` | Rebuild the search indexes from `data/` |
| `npm run fieldsets` | Rebuild the field sets |
| `npm run prepare-data` | `index` and `fieldsets` |
| `npm run sample-bullets` | Regenerate the sample bullet records in `data/bullets/` |

## Contribute

- Data: [CONTRIBUTING.md](CONTRIBUTING.md#contributing-data).
- Code and pull requests: [CONTRIBUTING.md](CONTRIBUTING.md#workflow).
- Commit convention: [Conventional Commits](https://www.conventionalcommits.org/en/v1.0.0/),
  details in [CONTRIBUTING.md](CONTRIBUTING.md#commit-convention).
- Bug and data reports: open an issue from a template.

## Continuous integration and releases

| Workflow | Trigger | Effect |
|---|---|---|
| `ci.yml` | pull request | `npm ci`, `npm test`, `npm run build` |
| `pr-title.yml` | pull request | checks the title against the commit convention |
| `pages.yml` | push to `main` | tests, builds and deploys `site/dist` to GitHub Pages |
| `release.yml` | push to `main` | release-please release PR, tag, GitHub release |

Dependabot (`.github/dependabot.yml`) opens weekly updates for npm packages in `site/` and for GitHub
Actions. Versioning and the release process are in [CONTRIBUTING.md](CONTRIBUTING.md#versioning-and-releases).
Changes are listed in [CHANGELOG.md](CHANGELOG.md).

## License

MIT, see [LICENSE](LICENSE). Third-party software and its licences: [THIRD-PARTY.md](THIRD-PARTY.md).
