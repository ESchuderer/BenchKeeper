import { readFileSync, readdirSync } from 'node:fs';
import { join } from 'node:path';
import { describe, expect, it } from 'vitest';
import { FIELD_UNITS, formatValue, type Record_ } from '@lib/core';
import { CARTRIDGES } from '../../../lib/testing/fixtures';
import {
  compareProfiles,
  dimensionsOf,
  formatDifference,
  formatLength,
  outerProfile,
  comparedDimensions,
  tableUnit
} from './compare';

const real = (family: string, key: string) =>
  JSON.parse(readFileSync(join(CARTRIDGES, family, `${key}.json`), 'utf8')) as Record_;
const synthetic = (name: string, cartridge: Record<string, unknown>, family = 'rimless') =>
  ({ key: name, name, family, cartridge, chamber: {} }) as unknown as Record_;

describe('dimensionsOf', () => {
  const record = synthetic('x', {
    lengths: { L1: 39.62, L1Tol: -0.2, L3: null },
    caseHead: { R: 1.37, eMin: 1.4, delta: 36, beta: { degrees: 35 } },
    powderChamber: { P1: 11.96, P2: '11.53' },
    pressures: { Pmax: 4150, M: 25 },
    projectile: { L3PlusG: 58.16 },
    misc: { deltaL: 0.1 }
  });
  it('keeps millimetre numbers, written as the detail page writes them, in the sheet order', () => {
    expect([...dimensionsOf(record)]).toEqual([
      ['L1', 39.62], ['R', 1.37], ['e min', 1.4], ['P1', 11.96], ['L3 + G', 58.16], ['delta L', 0.1]
    ]);
  });
  it('leaves out tolerances, other units, angles, text and absent values', () => {
    const symbols = [...dimensionsOf(record).keys()];
    for (const left of ['L1Tol', 'delta', 'beta', 'P2', 'Pmax', 'M', 'L3']) expect(symbols).not.toContain(left);
    expect(Object.keys(FIELD_UNITS)).toEqual(expect.arrayContaining(['Pmax', 'delta', 'beta']));
  });
  it('reads only the cartridge part and skips repeating groups', () => {
    const shot = { ...synthetic('s', { lengths: [{ marking: '12/70', l: 70 }], dimensions: { d: 18.2 } }), chamber: { lengths: { L1: 9 } } };
    expect([...dimensionsOf(shot as Record_)]).toEqual([['d', 18.2]]);
  });
});

describe('comparedDimensions', () => {
  it('lists every symbol either publishes, null where one does not, in the sheet order', () => {
    const a = synthetic('a', { lengths: { L1: 10, L3: 30 }, caseHead: { R: 1 } });
    const b = synthetic('b', { lengths: { L3: 33.5, L6: 70 }, caseHead: { R: 1.5, E: 3 } });
    expect(comparedDimensions(a, b)).toEqual([
      { symbol: 'L1', a: 10, b: null },
      { symbol: 'L3', a: 30, b: 33.5 },
      { symbol: 'L6', a: null, b: 70 },
      { symbol: 'R', a: 1, b: 1.5 },
      { symbol: 'E', a: null, b: 3 }
    ]);
  });
  it('puts symbols only the second publishes at the start when nothing before them is shared', () => {
    const rows = comparedDimensions(synthetic('a', { lengths: { L3: 1 } }), synthetic('b', { lengths: { L1: 2, L3: 3 } }));
    expect(rows.map((row) => row.symbol)).toEqual(['L1', 'L3']);
  });
  it('is empty when neither publishes a dimension', () => {
    expect(comparedDimensions(synthetic('a', {}), synthetic('b', {}))).toEqual([]);
  });
  it('works on published records', () => {
    const a = real('rimless', '308_win');
    const b = real('belted', '300_win_mag');
    const rows = comparedDimensions(a, b);
    const symbols = rows.map((row) => row.symbol);
    expect(symbols).toContain('L3');
    expect(symbols).not.toContain('Pmax');
    expect(new Set(symbols).size).toBe(symbols.length);
    expect(new Set(symbols)).toEqual(new Set([...dimensionsOf(a).keys(), ...dimensionsOf(b).keys()]));
    for (const row of rows) {
      expect(row.a).toBe(dimensionsOf(a).get(row.symbol) ?? null);
      expect(row.b).toBe(dimensionsOf(b).get(row.symbol) ?? null);
    }
    expect(rows.find((row) => row.symbol === 'delta L')).toMatchObject({ b: null });
    expect(rows.find((row) => row.symbol === 'delta L')!.a).not.toBeNull();
    expect(rows.find((row) => row.symbol === 'R3')).toMatchObject({ a: null });
    expect(rows.find((row) => row.symbol === 'R3')!.b).not.toBeNull();
  });
});

describe('units', () => {
  it('writes metric lengths with formatValue and imperial lengths in inches', () => {
    expect(formatLength(51.18, 'metric')).toBe(formatValue(51.18));
    expect(formatLength(25.4, 'imperial')).toBe('1');
    expect(formatLength(12.7, 'imperial')).toBe('0.5');
    expect(tableUnit('metric')).toBe('mm');
    expect(tableUnit('imperial')).toBe('in');
  });
  it('writes nothing for a dimension a cartridge does not publish', () => {
    expect(formatLength(null, 'metric')).toBe('');
    expect(formatLength(null, 'imperial')).toBe('');
    expect(formatDifference(null, 5, 'metric')).toBe('');
    expect(formatDifference(5, null, 'imperial')).toBe('');
  });
  it('takes B minus A and converts the difference', () => {
    expect(formatDifference(51.18, 66.55, 'metric')).toBe('15.37');
    expect(formatDifference(66.55, 51.18, 'metric')).toBe('-15.37');
    expect(formatDifference(1.37, 1.37, 'metric')).toBe('0');
    expect(formatDifference(25.4, 76.2, 'imperial')).toBe('2');
    expect(formatDifference(25.4, 0, 'imperial')).toBe('-1');
  });
});

describe('profile comparison', () => {
  const a = real('rimless', '308_win');
  const b = real('belted', '300_win_mag');
  const numbers = (path: string) => (path.match(/-?\d+(?:\.\d+)?/g) ?? []).map(Number);
  const points = (path: string) => {
    const values = numbers(path);
    return Array.from({ length: values.length / 2 }, (_, i) => [values[2 * i]!, values[2 * i + 1]!] as const);
  };

  it('draws both cases in one frame, from the head face, at one scale about one axis', () => {
    const drawing = compareProfiles(a, b)!;
    expect(drawing).not.toBeNull();
    for (const [record, path] of [[a, drawing.a], [b, drawing.b]] as const) {
      const xs = points(path).map(([x]) => x);
      const ys = points(path).map(([, y]) => y);
      const profile = outerProfile(record)!;
      const rMax = Math.max(...profile.map(([r]) => r));
      const zMax = Math.max(...profile.map(([, z]) => z));
      expect(Math.min(...xs)).toBeCloseTo(drawing.headFace.x, 4);
      expect((Math.max(...xs) - Math.min(...xs)) / drawing.scale).toBeCloseTo(zMax, 3);
      expect((Math.max(...ys) - Math.min(...ys)) / drawing.scale).toBeCloseTo(2 * rMax, 3);
      expect((Math.max(...ys) + Math.min(...ys)) / 2).toBeCloseTo(drawing.axis.y, 3);
    }
    expect(drawing.axis.y).toBeCloseTo(drawing.height / 2, 6);
  });

  it('is symmetric about the axis and closed', () => {
    const drawing = compareProfiles(a, b)!;
    expect(drawing.a.endsWith('Z')).toBe(true);
    const ys = points(drawing.a).map(([, y]) => y);
    expect(Math.min(...ys) + Math.max(...ys)).toBeCloseTo(2 * drawing.axis.y, 3);
  });

  it('cannot draw a shot cartridge or a record that publishes too little', () => {
    // Any shotshell record will do; the first by name keeps the test deterministic.
    const [file] = readdirSync(join(CARTRIDGES, 'shotshell')).filter((name) => name.endsWith('.json')).sort();
    const shot = real('shotshell', file!.replace(/\.json$/, ''));
    expect(outerProfile(shot)).toBeNull();
    expect(compareProfiles(a, shot)).toBeNull();
    expect(compareProfiles(synthetic('empty', {}), a)).toBeNull();
  });
});
