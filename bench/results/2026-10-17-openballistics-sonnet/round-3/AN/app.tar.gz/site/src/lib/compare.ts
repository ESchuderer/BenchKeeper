/**
 * What the comparison view shows: the dimensions either of two cartridges publishes, and their
 * case profiles on one common axis.
 *
 * Framework-free so the rows and the geometry can be tested without the page. The sheet's own
 * order, notation and units come from `@lib/core`, the outline from `@lib/shapes2d`, the
 * viewport and paths from `@lib/geom`; nothing is recomputed here.
 */

import {
  FIELD_LABELS,
  FIELD_UNITS,
  GROUP_ORDER,
  formatValue,
  orderedFields,
  type Record_
} from '@lib/core';
import { fullSectionPath, viewportFor } from '@lib/geom/svg';
import type { Profile } from '@lib/geom/profile';
import { adaptMetallic, caseOuterProfile, type CartridgeRecord } from '@lib/shapes2d/case';
import { defaultUnit, displayNumber, type UnitSystem } from './units';

const has = (table: object, field: string): boolean => Object.prototype.hasOwnProperty.call(table, field);

export interface DimensionRow {
  /** The symbol as the detail page writes it: `e min`, `L3`. */
  symbol: string;
  /** Millimetres, as published; `null` where that cartridge does not publish the dimension. */
  a: number | null;
  b: number | null;
}

/**
 * The dimensions a record publishes, by symbol, in the sheet's order.
 *
 * A dimension is a number in the `cartridge` part whose unit is millimetres, which is a field
 * with no entry in `FIELD_UNITS`. Tolerances are not dimensions. A symbol that appears in two
 * groups keeps its first value.
 */
export function dimensionsOf(record: Record_): Map<string, number> {
  const found = new Map<string, number>();
  const groups = record.cartridge ?? {};
  const known = GROUP_ORDER.cartridge.filter((name) => name in groups);
  const rest = Object.keys(groups).filter((name) => !known.includes(name)).sort();
  for (const name of [...known, ...rest]) {
    const group = groups[name];
    if (!group || Array.isArray(group)) continue;
    for (const field of orderedFields('cartridge', name, group)) {
      const value = group[field];
      if (typeof value !== 'number' || !Number.isFinite(value)) continue;
      if (field.endsWith('Tol') || has(FIELD_UNITS, field)) continue;
      const symbol = has(FIELD_LABELS, field) ? FIELD_LABELS[field]! : field;
      if (!found.has(symbol)) found.set(symbol, value);
    }
  }
  return found;
}

/**
 * One row per symbol either record publishes. The symbols of the first keep its order. A symbol
 * only the second publishes follows the symbol before it in the second's order, so the rows stay
 * in the sheet's order.
 */
export function comparedDimensions(a: Record_, b: Record_): DimensionRow[] {
  const first = dimensionsOf(a);
  const second = dimensionsOf(b);
  const symbols = [...first.keys()];
  let last = -1;
  for (const symbol of second.keys()) {
    const at = symbols.indexOf(symbol);
    if (at >= 0) {
      last = Math.max(last, at);
    } else {
      last += 1;
      symbols.splice(last, 0, symbol);
    }
  }
  return symbols.map((symbol) => ({ symbol, a: first.get(symbol) ?? null, b: second.get(symbol) ?? null }));
}

/** A length published in millimetres, as the reader's unit system writes it. Empty if unpublished. */
export function formatLength(millimetres: number | null, system: UnitSystem): string {
  if (millimetres === null) return '';
  return system === 'metric'
    ? (formatValue(millimetres) as string)
    : displayNumber(millimetres, defaultUnit('length', system));
}

/**
 * B minus A, taken in millimetres and then converted and written like a length. The difference
 * of two published figures is cut to twelve significant digits, as `displayNumber` does, so
 * that binary floating point does not print `15.369999999999997` for 15.37. Empty unless both
 * cartridges publish the dimension.
 */
export function formatDifference(a: number | null, b: number | null, system: UnitSystem): string {
  if (a === null || b === null) return '';
  const difference = b - a;
  return system === 'metric'
    ? (formatValue(Number(difference.toPrecision(12))) as string)
    : displayNumber(difference, defaultUnit('length', system));
}

/** The unit the table is written in. */
export const tableUnit = (system: UnitSystem): string => defaultUnit('length', system);

/** The outer half-profile of a metallic case, or `null` where it cannot be drawn. */
export function outerProfile(record: Record_): Profile | null {
  if (record.family === 'shotshell') return null;
  try {
    return caseOuterProfile(adaptMetallic(record as unknown as CartridgeRecord));
  } catch {
    // A record that publishes too little to draw is a missing picture, not a broken page.
    return null;
  }
}

/** Both outlines in one coordinate system, as SVG path data. */
export interface ProfileComparison {
  width: number;
  height: number;
  /** User units per millimetre, the same for both outlines. */
  scale: number;
  a: string;
  b: string;
  /** The head faces: one vertical line, since both cases start at z = 0. */
  headFace: { x: number; y1: number; y2: number };
  /** The common axis of revolution. */
  axis: { y: number; x1: number; x2: number };
}

const UNITS_PER_MM = 4;
const MARGIN_MM = 2;

/**
 * The silhouettes of both cases, mirrored about one axis, at one scale and with the head faces
 * at the same point. `null` when either case cannot be drawn.
 */
export function compareProfiles(a: Record_, b: Record_): ProfileComparison | null {
  const first = outerProfile(a);
  const second = outerProfile(b);
  if (!first || !second) return null;
  const view = viewportFor([first, second], { scale: UNITS_PER_MM, marginMm: MARGIN_MM, frame: 'landscape' });
  const [headX, axisY] = view.xy(0, 0);
  const [farX] = view.xy(0, view.zMax);
  const rMax = view.rMax;
  return {
    width: view.width,
    height: view.height,
    scale: view.scale,
    a: fullSectionPath(first, view),
    b: fullSectionPath(second, view),
    headFace: { x: headX, y1: view.xy(-rMax, 0)[1], y2: view.xy(rMax, 0)[1] },
    axis: { y: axisY, x1: headX, x2: farX }
  };
}
