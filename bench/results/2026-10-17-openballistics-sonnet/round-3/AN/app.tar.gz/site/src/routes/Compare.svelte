<script lang="ts">
  import PageHeader from '../components/PageHeader.svelte';
  import { compareProfiles, formatDifference, formatLength, comparedDimensions, tableUnit } from '../lib/compare';
  import { load } from '../lib/data';
  import { t } from '../lib/i18n.svelte';
  import { href } from '../lib/router';
  import { unitSystem } from '../lib/units.svelte';

  let { a, b }: { a: string; b: string } = $props();

  // Held by promise, so a unit or language change re-renders the table without a second fetch.
  const records = $derived(Promise.all([load(a), load(b)]));
</script>

<div data-ui="Compare" class="contents">
  {#await records}
    <p class="status" role="status">{t('site.loading')}</p>
  {:then [first, second]}
    {@const system = unitSystem()}
    {@const rows = comparedDimensions(first, second)}
    {@const profiles = compareProfiles(first, second)}
    <PageHeader
      eyebrow={t('compare.title')}
      title={t('compare.heading', { a: first.name, b: second.name })}
      description={t('compare.lede')}
      backHref={href.cartridge(a)}
      backLabel={t('compare.view', { name: first.name })}
    />

    <section class="profiles">
      {#if profiles}
        <svg
          role="img"
          aria-label={t('compare.profiles', { a: first.name, b: second.name })}
          viewBox={`0 0 ${profiles.width} ${profiles.height}`}
          preserveAspectRatio="xMinYMid meet"
        >
          <line class="axis" x1={profiles.axis.x1} y1={profiles.axis.y} x2={profiles.axis.x2} y2={profiles.axis.y} />
          <line class="face" x1={profiles.headFace.x} y1={profiles.headFace.y1} x2={profiles.headFace.x} y2={profiles.headFace.y2} />
          <path class="outline a" d={profiles.a} />
          <path class="outline b" d={profiles.b} />
        </svg>
        <ul class="legend">
          <li><span class="swatch a" aria-hidden="true"></span>{first.name}</li>
          <li><span class="swatch b" aria-hidden="true"></span>{second.name}</li>
        </ul>
      {:else}
        <p class="status">{t('compare.noDrawing')}</p>
      {/if}
    </section>

    <section class="table">
      {#if rows.length}
        <div class="scroll">
          <table>
            <caption>{t('compare.dimensions', { unit: tableUnit(system) })}</caption>
            <thead>
              <tr>
                <th scope="col">{t('compare.symbol')}</th>
                <th scope="col" class="num value">{first.name}</th>
                <th scope="col" class="num value">{second.name}</th>
                <th scope="col" class="num value">{t('compare.difference')}</th>
              </tr>
            </thead>
            <tbody>
              {#each rows as row (row.symbol)}
                <tr>
                  <td class="num">{row.symbol}</td>
                  <td class="num value">{formatLength(row.a, system)}</td>
                  <td class="num value">{formatLength(row.b, system)}</td>
                  <td class="num value">{formatDifference(row.a, row.b, system)}</td>
                </tr>
              {/each}
            </tbody>
          </table>
        </div>
        <p class="note">{t('compare.differenceNote')}</p>
      {:else}
        <p class="status">{t('compare.noShared')}</p>
      {/if}
    </section>
  {:catch error}
    <p class="status">{error.message} <a href={href.list()}>{t('record.back')}</a></p>
  {/await}
</div>

<style>
  @layer legacy {
    .status, .note { color: var(--ink-2); font-size: var(--step-0); }
    .profiles { margin-bottom: 2rem; }
    svg { display: block; width: 100%; max-height: 24rem; background: var(--surface); border: 1px solid var(--rule); border-radius: var(--radius); }
    .outline { fill-opacity: .1; stroke-width: 1.5; vector-effect: non-scaling-stroke; stroke-linejoin: round; }
    .outline.a { stroke: var(--dim-ink); fill: var(--dim-ink); }
    .swatch.a { background: var(--dim-ink); }
    .outline.b { stroke: var(--warn); fill: var(--warn); stroke-dasharray: 6 3; }
    .swatch.b { background: var(--warn); }
    .axis, .face { stroke: var(--ink-3); stroke-width: 1; stroke-dasharray: 2 3; vector-effect: non-scaling-stroke; }
    .legend { display: flex; flex-wrap: wrap; gap: .5rem 1.5rem; list-style: none; padding: 0; margin: .75rem 0 0; font-size: var(--step-0); }
    .swatch { display: inline-block; width: 1.5rem; height: .25rem; margin-right: .5rem; vertical-align: middle; }
    .scroll { overflow-x: auto; }
    table { border-collapse: collapse; font-size: var(--step-0); width: 100%; }
    caption { text-align: left; font-weight: 600; padding-bottom: .5rem; }
    th, td { text-align: left; padding: .25rem .75rem .25rem 0; white-space: nowrap; }
    thead th { color: var(--ink-2); font-weight: 500; border-bottom: 1px solid var(--rule); }
    .value { text-align: right; }
    td { font-weight: 500; }
  }
</style>
