<!-- The title becomes the commit on main. Use Conventional Commits, e.g. `data(rimless): correct L3 of 308 Win.` See CONTRIBUTING.md. -->

## What and why

## Source (for a data change)

<!-- The C.I.P. sheet and its revision date, a manufacturer's drawing, or the measurement. -->

## Checked

- [ ] `npm test` and `npm run build` pass in `site/`
- [ ] User-visible change added to `CHANGELOG.md` under `[Unreleased]`
