# Changelog

All notable changes to this project are recorded in this file.

The format is based on [Keep a Changelog 1.1.0](https://keepachangelog.com/en/1.1.0/), and the
project adheres to [Semantic Versioning 2.0.0](https://semver.org/). Versions are headed
`## [X.Y.Z] - YYYY-MM-DD`; the groups are Added, Changed, Deprecated, Removed, Fixed and Security.
How the file is maintained and how a release is made: [docs/releasing.md](docs/releasing.md).

## [Unreleased]

### Added

- The database as it stands: cartridge and chamber records from the C.I.P. tables, sample bullet
  records, target faces, and the libraries and the website that draw and browse them.
- A view that compares two cartridges at `#/compare/<a>/<b>`: their outer profiles overlaid at one
  scale, and a table of the dimensions either publishes with the difference (blank where only one
  does), in metric or imperial units. It is opened from the "Compare with" control on a cartridge's page, in English and German.
- Continuous integration, deployment of the site to GitHub Pages, tag-triggered releases and
  Dependabot updates, with contributor documentation and a commit convention.

[Unreleased]: https://github.com/PiMetry/OpenBallistics/commits/main
