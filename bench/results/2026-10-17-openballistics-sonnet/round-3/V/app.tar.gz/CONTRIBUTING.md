# Contributing

Thank you for helping. This page covers how to set up, what a good data change looks like, the
commit convention and what a pull request needs. How to install, develop, test and build is in the
[README](README.md).

## Before you start

- Look for an existing issue. For a wrong value in a cartridge, a bullet or the site, use one of
  the [issue forms](.github/ISSUE_TEMPLATE); the site fills them in when you follow a "report"
  link from a page.
- For a change larger than a correction, open an issue and say what you intend, so the work is not
  wasted on something that cannot be merged.
- Be kind. Assume the other person is trying to help.

## Changing the data

Everything in `data/` is a JSON record. Do not edit anything generated: the search index and the
other `*.generated.json` files are rebuilt from the records by `npm run prepare-data` and are not
in git.

**Cartridges** are in `data/cartridges/<family>/<key>.json`, where the family is one of belted,
pistol, rimfire, rimless, rimmed or shotshell and the key is the file name without `.json`. A
record carries the cartridge and chamber dimensions, in the units of the sheet, and the sheet it comes from
(`tab`, `published`, `revised`). A value is correct when it agrees with the C.I.P. sheet.

- **Cite your source.** Name the sheet and its revision date, or the manufacturer's drawing, or
  describe the measurement, in the pull request. A change that cannot be checked against something
  is not merged.
- Change the value and nothing else; keep the formatting of the file as it is, so the diff shows
  the one number that changed.
- Do not rename a key: it is the file name and the address of the record on the site (`#/c/<key>`, and in `#/compare/<a>/<b>`).

**Bullets** are in `data/bullets/`. Today that directory holds 75 *synthetic* samples, marked
`sample: true`, which `npm run sample-bullets` regenerates; do not edit them by hand. Real bullet
records are not accepted yet without discussion, because `site/src/lib/sample-bullets.test.ts`
asserts that the directory holds exactly those 75 samples. Open an issue and agree the change to
that test with the maintainers first.

**Targets** are in `data/targets/`, one file per face, with the rings and the rule it comes from in
`source` and `ruleSources`. `site/src/lib/target-catalogue.test.ts` asserts the number of faces, so
adding one means updating that test in the same pull request.

Then:

```sh
cd site
npm test
npm run build
npm run dev
```

and look at the record in the browser. In the pull request, say what you changed, where the right
value comes from, and which pages you looked at.

## Changing code

- The libraries in `lib/` stay framework-free and free of import cycles; a test enforces this, see
  `site/src/lib/boundaries.test.ts`.
- Add or update a test with the change. A bug fix starts with a test that fails.
- Follow the conventions in [site/UI.md](site/UI.md) for the site's components and styles.
- Keep a pull request to one purpose; it is easier to review and to revert.

## Commit convention

Commits and pull request titles follow
[Conventional Commits 1.0.0](https://www.conventionalcommits.org/en/v1.0.0/):

```
<type>(<scope>)<!>: <description>

<body>

<footer>
```

- **type** is one of:

  | Type       | Use for |
  | ---------- | ------- |
  | `feat`     | A new capability of the site or the libraries. |
  | `fix`      | A bug fix. |
  | `data`     | A change to the records in `data/`: a correction, an addition, a removal. |
  | `docs`     | Documentation only. |
  | `style`    | Formatting that does not change behaviour. |
  | `refactor` | A change that neither fixes a bug nor adds a capability. |
  | `perf`     | A performance improvement. |
  | `test`     | Adding or correcting tests. |
  | `build`    | The build, the scripts and the dependencies. |
  | `ci`       | The workflows and other repository automation. |
  | `chore`    | Anything else that does not touch the shipped result. |
  | `revert`   | Undoing an earlier commit; name it in the body. |

- **scope** is optional, lower case: a data family or area such as `rimless`, `bullets`, `targets`,
  or a code area such as `site`, `render2d`, `deps`.
- **description** is in the imperative, begins with a lower-case letter and has no final full stop.
  Keep the first line under about 72 characters.
- A breaking change is marked with `!` before the colon and a `BREAKING CHANGE:` footer saying what
  breaks and what to do about it. What counts as breaking is in
  [docs/releasing.md](docs/releasing.md).

Examples:

```
data(rimless): correct L3 of 308 Win. to the 2008 sheet
fix(targets): score a shot on the ring boundary as the higher ring
feat(site): add a unit selector to the bullet page
build(deps): bump vite to 5.4.21
ci: cache npm downloads in the pages workflow
feat(data)!: rename the pressure fields to match the sheet
```

**Pull requests are squash-merged and the title becomes the commit on `main`**, so the title must
follow the convention; the `pr-title` check fails when it does not. You may commit in any style on
your branch, but tidy commits that follow the convention make review easier. The changelog is
written by hand at release time from these titles, see
[docs/releasing.md](docs/releasing.md).

## Pull requests

Before you open one:

- `npm test` and `npm run build` pass in `site/`; the `check` job runs the same two commands.
- The title follows the convention.
- Anything a user would notice is described in the pull request, and for data, its source.

Pull requests from forks run CI with a read-only token and no secrets. A maintainer reviews and
merges; dependency updates arrive from Dependabot and are reviewed like any other change.

## Licence

By contributing you agree that your work is released under the [MIT licence](LICENSE).
