# OpenBallistics

An open database of cartridges, bullets and targets, kept as plain JSON records, with the
libraries that draw and measure them and a website that browses them. The cartridge and chamber
dimensions are transcribed from the C.I.P. tables of dimensions of cartridges and chambers.

The project is independent and is not affiliated with the C.I.P.

## What is in the repository

| Path        | What it holds |
| ----------- | ------------- |
| `data/`     | The records: `cartridges/` (one folder per family), `bullets/` and `targets/`. |
| `lib/`      | Shared TypeScript libraries: geometry, drawing, targets and user data. They are framework-free. |
| `site/`     | The Svelte website. It is the only part with a `package.json`. |
| `fixtures/` | Reference files the tests compare against. They are test data and are not shipped. |
| `docs/`     | Notes for maintainers; see [docs/releasing.md](docs/releasing.md). |

## Install

You need Node.js 22 (the version in [`.nvmrc`](.nvmrc)) and npm. Every npm command below is run
from the `site/` directory:

```sh
cd site
npm ci
```

## Develop

```sh
npm run dev
```

This builds the search index from `data/` and starts the Vite dev server, which serves the records
straight from `data/`, so an edited record shows up on reload. The index is rebuilt when the server
starts, not while it runs: restart it, or run `npm run prepare-data`, after changing the set of
records or a value the list searches and sorts on.

The other scripts in `site/package.json`:

| Command                  | What it does |
| ------------------------ | ------------ |
| `npm run index`          | Builds the search indexes and the flag set from `data/`. |
| `npm run fieldsets`      | Works out which fields each cartridge family has, for the editors. |
| `npm run prepare-data`   | Runs `index` and `fieldsets`. `dev`, `test` and `build` run it first. |
| `npm run sample-bullets` | Regenerates the sample records in `data/bullets/`. See [data/bullets/README.md](data/bullets/README.md). |

The generated files (`site/src/lib/*.generated.json` and `site/public/flags/`) are ignored by git.

## Test

```sh
npm test
```

This runs Vitest over the site's tests and the tests of every library in `lib/`.

## Build

```sh
npm run build
```

This prepares the data, type-checks the site and the libraries with `svelte-check`, and writes the
site to `site/dist/`. To look at the result:

```sh
npm run preview
```

The build is for the root of a domain by default. To build for a sub-path, as GitHub Pages does for
a project page, set `PAGES_BASE` with a leading and a trailing slash, for example
`PAGES_BASE=/OpenBallistics/ npm run build`.

## Continuous integration and deployment

- Every pull request runs `npm ci`, `npm test` and `npm run build` ([`ci.yml`](.github/workflows/ci.yml)),
  and its title is checked against the commit convention ([`pr-title.yml`](.github/workflows/pr-title.yml)).
  Run the same three commands before you open one.
- Every push to `main` deploys the site to GitHub Pages ([`pages.yml`](.github/workflows/pages.yml)).
- Pushing a version tag makes a release ([`release.yml`](.github/workflows/release.yml)).
- Dependabot opens weekly pull requests for npm packages and for the actions the workflows use.

## Contribute

Contributions are welcome: corrections to the data, new records, fixes and features. The short
version:

1. Open an issue first for anything larger than a correction. The forms in
   [the issue templates](.github/ISSUE_TEMPLATE) cover a wrong cartridge value, a bullet problem and
   site feedback.
2. Branch from `main`, make the change, and run `npm test` and `npm run build`.
3. Open a pull request whose title follows [Conventional Commits](https://www.conventionalcommits.org/en/v1.0.0/),
   for example `data(rimless): correct L3 of 308 Win.` or `fix: keep the unit when saving a gun`.

[CONTRIBUTING.md](CONTRIBUTING.md) has the detail: how to change a record and what to cite, the
commit convention, and what a pull request needs.

## Versions and releases

The project follows [Semantic Versioning](https://semver.org/). The version is the `version` field
of `site/package.json`, and a release is a `vMAJOR.MINOR.PATCH` tag on `main`. Changes are listed in
[CHANGELOG.md](CHANGELOG.md), which follows [Keep a Changelog](https://keepachangelog.com/en/1.1.0/).
[docs/releasing.md](docs/releasing.md) describes how a release is made.

## Licence

The project is released under the [MIT licence](LICENSE), Copyright (c) 2026 PiMetry.

The built site includes work by others, under their own licences: country flags, the Svelte
runtime and the IBM Plex typefaces. Their notices are in [THIRD-PARTY.md](THIRD-PARTY.md), which is
also copied into the built site. By contributing you agree that your contribution is released
under the same licence.
