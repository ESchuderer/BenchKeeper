# Releasing

How versions are numbered, where the version is kept, how a release is made, and the one-time
settings the repository needs.

## Versioning

The project uses [Semantic Versioning 2.0.0](https://semver.org/), `MAJOR.MINOR.PATCH`, with a
`-rc.N` style suffix for a pre-release. One version covers the repository as a whole: the data, the
libraries and the site are released together. Until `1.0.0`, a minor version may contain a breaking
change; say so in the changelog.

What the numbers mean here:

| Bump      | When |
| --------- | ---- |
| **MAJOR** | A breaking change: a record's fields or keys are renamed or removed, a record is removed, a library's exported interface changes incompatibly, or the format of a user's exported backup stops being readable. |
| **MINOR** | A backward-compatible addition: new records, new fields, a new page or capability. |
| **PATCH** | A correction: a wrong value in a record, a bug fix, a fix to the site or the tooling that changes nothing about what is available. |

## Where the version is kept

In one place: the `version` field of [`site/package.json`](../site/package.json). The same number
appears twice in `site/package-lock.json`, which `npm version` keeps in step. The release tag is that
number with a `v` in front, so version `0.2.0` is tagged `v0.2.0`. The release workflow refuses a tag
that does not match the file.

## The changelog

[`CHANGELOG.md`](../CHANGELOG.md) follows [Keep a Changelog 1.1.0](https://keepachangelog.com/en/1.1.0/):

- Newest first. `## [Unreleased]` is at the top and collects changes as they merge.
- A released version has the heading `## [X.Y.Z] - YYYY-MM-DD` (an ISO date). The release workflow
  looks for exactly this heading and uses the text under it as the release notes.
- Under each version, only the groups that apply, in this order: `### Added`, `### Changed`,
  `### Deprecated`, `### Removed`, `### Fixed`, `### Security`. Data changes go under the same
  groups: a new record is *Added*, a corrected value is *Fixed*.
- One line per change, for a person reading it, not a copy of a commit title. Mark a breaking change
  with `**Breaking:**` at the start of its line.
- The link references at the bottom compare tags: `[Unreleased]` against the latest tag and each
  version against the one before it.

The changelog is written by hand. Add a line to `[Unreleased]` in the pull request that makes a
user-visible change; a maintainer tidies it at release time, using the squash-merged commit titles
(`git log --oneline vPREVIOUS..main`) as the checklist. `docs`, `style`, `test`, `ci` and `chore`
commits normally do not need a line.

## Making a release

Releases are cut from `main` by a maintainer, by pushing a tag. Nothing is published until the tag
is pushed.

1. Decide the version from the commits since the last tag: any `!` or `BREAKING CHANGE:` means a
   major bump, any `feat` or added `data` a minor one, otherwise a patch.
2. On a branch from an up-to-date `main`, set the version without tagging. (For the first release,
   `0.1.0`, the file already says so: skip this step.)

   ```sh
   cd site
   npm version 0.2.0 --no-git-tag-version
   ```

3. In `CHANGELOG.md`, rename `## [Unreleased]` to `## [0.2.0] - YYYY-MM-DD`, add a fresh empty
   `## [Unreleased]` above it, and update the link references at the bottom. The first release has
   no earlier tag to compare against, so its reference is
   `[0.1.0]: https://github.com/PiMetry/OpenBallistics/releases/tag/v0.1.0`.
4. Commit as `chore(release): v0.2.0`, open a pull request, and merge it once CI passes.
5. Tag the merge commit on `main` and push the tag:

   ```sh
   git switch main
   git pull
   git tag -a v0.2.0 -m "v0.2.0"
   git push origin v0.2.0
   ```

The [release workflow](../.github/workflows/release.yml) then:

1. checks that the tag matches `site/package.json`, is on `main`, and has a section in
   `CHANGELOG.md`;
2. runs `npm ci`, `npm test` and `npm run build`;
3. creates the GitHub release named after the tag, with that changelog section as its notes, marked
   as a pre-release when the version has a suffix such as `-rc.1`;
4. attaches `openballistics-data-vX.Y.Z.tar.gz` (the `data/` directory) and
   `openballistics-site-vX.Y.Z.tar.gz` (the built site, for the root of a domain).

If a check fails, nothing is released. Fix the cause, delete the tag
(`git push --delete origin v0.2.0` and `git tag -d v0.2.0`), and tag again.

The website is separate from releases: every merge to `main` deploys it to GitHub Pages
([`pages.yml`](../.github/workflows/pages.yml)), so the live site follows `main`, not the latest tag.

## One-time repository settings

These cannot be set from a file in the repository; a maintainer sets them once on GitHub.

- **Pages.** Settings, Pages, Build and deployment, Source: **GitHub Actions**. Without it the
  deploy job fails. The site is then served at `https://pimetry.github.io/OpenBallistics/`; the
  workflow takes the base path from Pages, so a custom domain needs no change to the code.
- **Merging.** Settings, General, Pull Requests: allow squash merging only, with the default
  commit message set to **Pull request title** (and description), so the checked title is the
  commit on `main`. Allow auto-delete of head branches.
- **Branch protection for `main`.** Require a pull request, and require the status checks `check`
  and `pr-title`.
- **Tags.** Protect `v*` tags (Settings, Rules) so only maintainers can create them; a pushed tag
  publishes a release.
- **Actions permissions.** Settings, Actions, General: for pull requests from forks, require
  approval for first-time contributors.
- **Labels.** The issue forms apply the `data` and `bullet` labels, and the triage labels are
  listed in [docs/agents/triage-labels.md](agents/triage-labels.md). Create them so the forms and
  triage work.
