import { readFileSync } from 'node:fs';
import { resolve } from 'node:path';
import { describe, expect, it } from 'vitest';
import { adaptMetallic, caseOuterProfile, type CartridgeRecord } from '@lib/shapes2d';
import type { Record_ } from '@lib/core';
import { allDimensions, difference, overlayOf, showLength } from './compare';

const DATA = resolve(__dirname, '../../../data/cartridges');
const record = (family: string, key: string): Record_ =>
  JSON.parse(readFileSync(resolve(DATA, family, `${key}.json`), 'utf8'));

/** A record with only the cartridge groups given: enough for the table, which reads nothing else. */
const withGroups = (cartridge: Record_['cartridge']): Record_ =>
  ({ key: 'x', name: 'X', family: 'rimless', cartridge, chamber: {} }) as Record_;

describe('difference', () => {
  it('is B minus A without floating-point noise', () => {
    expect(12.07 - 11.9).not.toBe(0.17);
    expect(difference(11.9, 12.07)).toBe(0.17);
    expect(difference(0.3, 0.1)).toBe(-0.2);
    expect(difference(1.37, 1.27)).toBe(-0.1);
    expect(difference(51.18, 51.18)).toBe(0);
    expect(Object.is(difference(1.5, 1.5), 0)).toBe(true);
    expect(difference(2, 10)).toBe(8);
  });
});

describe('allDimensions', () => {
  it('lists the millimetre figures either publishes, as the detail page labels them and in its order', () => {
    const a = record('rimless', '308_win');
    const b = record('belted', '300_win_mag');
    const rows = allDimensions(a, b);
    const symbols = rows.map((row) => row.symbol);
    // The case head, in the sheet's order, with `e min` as the page writes it.
    expect(symbols).toContain('e min');
    expect(symbols.indexOf('R')).toBeLessThan(symbols.indexOf('R1'));
    expect(symbols.indexOf('L1')).toBeLessThan(symbols.indexOf('R'));
    expect(rows.find((row) => row.symbol === 'e min')).toEqual({ symbol: 'e min', a: 1.4, b: 0.94, difference: -0.46 });
    expect(rows.find((row) => row.symbol === 'E1')).toEqual({ symbol: 'E1', a: 10.39, b: 12.07, difference: 1.68 });
    // What only one publishes is listed too, the other's cell and the difference left empty:
    // delta L is the 308 Win.'s alone, R3 (the belt) the 300 Win. Mag.'s alone.
    expect(rows.find((row) => row.symbol === 'delta L')).toEqual({ symbol: 'delta L', a: 0.1, b: null, difference: null });
    expect(rows.find((row) => row.symbol === 'R3')).toEqual({ symbol: 'R3', a: null, b: 13.51, difference: null });
    // Not dimensions: tolerances, pressures, energies, masses and angles.
    for (const other of ['ETol', 'Pmax', 'PK', 'PE', 'EE', 'M', 'alpha', 'δ', 'β', 'delta', 'beta']) {
      expect(symbols).not.toContain(other);
    }
    expect(new Set(symbols).size).toBe(symbols.length);
  });

  it('reads the cartridge part only, numbers only, and skips lists', () => {
    const a = withGroups({
      lengths: { L1: 10, L1Tol: 0.1, L2: null, L3: '12' as never },
      caseHead: { eMin: 1.1, delta: 36, beta: { degrees: 35 } as never, f: 0 },
      pressures: { Pmax: 4200 },
      hulls: [{ l: 70 }] as never
    });
    const b = withGroups({
      lengths: { L1: 12.5, L1Tol: 0.2, L2: 3, L3: 12 },
      caseHead: { eMin: 1.4, delta: 35, beta: 35, f: 0.1 },
      pressures: { Pmax: 3000 },
      hulls: [{ l: 76 }] as never
    });
    a.chamber = { lengths: { L0: 1 } };
    b.chamber = { lengths: { L0: 2 } };
    expect(allDimensions(a, b)).toEqual([
      { symbol: 'L1', a: 10, b: 12.5, difference: 2.5 },
      // A blank or a string is not a figure: only B publishes L2 and L3.
      { symbol: 'L2', a: null, b: 3, difference: null },
      { symbol: 'L3', a: null, b: 12, difference: null },
      { symbol: 'e min', a: 1.1, b: 1.4, difference: 0.3 },
      // Zero is a figure: a feature published as 0 is not one the sheet is silent about.
      { symbol: 'f', a: 0, b: 0.1, difference: 0.1 }
    ]);
  });

  it("keeps both records' orders, with a gap where only one publishes", () => {
    const a = withGroups({ lengths: { L1: 1, L3: 3 }, caseHead: { eMin: 1 } });
    const b = withGroups({ lengths: { L1: 1, L2: 5, L3: 4 }, caseHead: { eMin: 1, f: 2 } });
    expect(allDimensions(a, b).map((row) => [row.symbol, row.a, row.b, row.difference])).toEqual([
      ['L1', 1, 1, 0],
      ['L2', null, 5, null],
      ['L3', 3, 4, 1],
      ['e min', 1, 1, 0],
      ['f', null, 2, null]
    ]);
  });

  it('lists the dimensions of cartridges that share none, each with an empty cell', () => {
    expect(allDimensions(withGroups({ lengths: { L1: 1 } }), withGroups({ collar: { H1: 2 } }))).toEqual([
      { symbol: 'L1', a: 1, b: null, difference: null },
      { symbol: 'H1', a: null, b: 2, difference: null }
    ]);
  });

  it('has no rows when neither publishes a dimension', () => {
    expect(allDimensions(withGroups({}), withGroups({ pressures: { Pmax: 1 } }))).toEqual([]);
  });
});

describe('showLength', () => {
  it('writes metric figures as the detail page does and imperial ones in inches, unrounded', () => {
    expect(showLength(12.07, 'metric')).toBe('12.07');
    expect(showLength(-0.46, 'metric')).toBe('-0.46');
    expect(showLength(0, 'metric')).toBe('0');
    expect(showLength(25.4, 'imperial')).toBe('1');
    expect(showLength(12.07, 'imperial')).toBe(String(Number((12.07 / 25.4).toPrecision(12))));
    expect(showLength(-0.46, 'imperial')).toBe(String(Number((-0.46 / 25.4).toPrecision(12))));
  });
});

describe('overlayOf', () => {
  const a = record('rimless', '308_win');
  const b = record('belted', '300_win_mag');

  /** Every `x,y` of a path in the viewBox's units. */
  const points = (d: string) => [...d.matchAll(/[ML]([-\d.e]+),([-\d.e]+)/g)].map((m) => [Number(m[1]), Number(m[2])] as const);

  it('draws both outlines in one viewBox in millimetres, about one axis', () => {
    const result = overlayOf(a, b);
    if (!('overlay' in result)) throw new Error('expected an overlay');
    const { overlay } = result;
    const profile = (r: Record_) => caseOuterProfile(adaptMetallic(r as unknown as CartridgeRecord));
    const first = profile(a), second = profile(b);
    const ys = [points(overlay.a), points(overlay.b)].map((p) => p.map(([, y]) => y));
    const xs = [points(overlay.a), points(overlay.b)].map((p) => p.map(([x]) => x));
    const rMax = (p: typeof first) => Math.max(...p.map(([r]) => r));
    const zMax = (p: typeof first) => Math.max(...p.map(([, z]) => z));
    const [axisX1, axisY, axisX2] = [overlay.axis[0], overlay.axis[1], overlay.axis[2]];

    // One scale, 1 unit to 1 mm: a section is twice the radius across and the length long.
    expect(Math.max(...ys[0]!) - Math.min(...ys[0]!)).toBeCloseTo(2 * rMax(first), 5);
    expect(Math.max(...ys[1]!) - Math.min(...ys[1]!)).toBeCloseTo(2 * rMax(second), 5);
    expect(Math.max(...xs[0]!) - Math.min(...xs[0]!)).toBeCloseTo(zMax(first), 5);
    expect(Math.max(...xs[1]!) - Math.min(...xs[1]!)).toBeCloseTo(zMax(second), 5);
    // One axis: each section is centred on it.
    for (const column of ys) expect((Math.max(...column) + Math.min(...column)) / 2).toBeCloseTo(axisY, 5);
    // The head faces are at the same x, and it is where the axis and the guide start.
    expect(Math.min(...xs[0]!)).toBeCloseTo(Math.min(...xs[1]!), 6);
    expect(Math.min(...xs[0]!)).toBeCloseTo(axisX1, 6);
    expect(overlay.head[0]).toBeCloseTo(axisX1, 6);
    expect(axisX2).toBeCloseTo(axisX1 + Math.max(zMax(first), zMax(second)), 5);
    // Both fit in the box.
    expect(overlay.width).toBeGreaterThan(Math.max(...xs.flat()));
    expect(overlay.height).toBeGreaterThan(Math.max(...ys.flat()));
    // Two different cartridges: the overlay is not one outline drawn twice.
    expect(overlay.a).not.toBe(overlay.b);
  });

  it('does not draw shot cartridges, nor a record too thin to draw', () => {
    expect(overlayOf(a, record('shotshell', '12'))).toEqual({ unavailable: 'shot' });
    expect(overlayOf(record('shotshell', '12'), a)).toEqual({ unavailable: 'shot' });
    const thin = record('rimmed', '7_x_67_r_luyven');
    expect(overlayOf(thin, a)).toEqual({ unavailable: 'a' });
    expect(overlayOf(a, thin)).toEqual({ unavailable: 'b' });
  });
});
