/**
 * Putting two cartridges side by side: the dimensions both publish, and their outer profiles
 * overlaid on one axis.
 *
 * Framework-free, so the page stays a layout of what is worked out here. The figures are the
 * detail page's own - same groups, same order, same symbols - and the outline is the one the
 * renderer draws, `caseOuterProfile`, not a second reading of the record.
 */

import {
  FIELD_LABELS,
  FIELD_UNITS,
  GROUP_ORDER,
  formatValue,
  orderedFields,
  type Group,
  type Record_
} from '@lib/core';
import { fmt, fullSectionPath, viewportFor } from '@lib/geom';
import { adaptMetallic, caseOuterProfile, type CartridgeRecord } from '@lib/shapes2d';
import { displayNumber, type UnitSystem } from './units';

export interface DimensionRow {
  /** The symbol as the detail page writes it: `e min`, `L3 + G`. */
  symbol: string;
  /** In millimetres; `null` where the record does not publish the dimension. */
  a: number | null;
  b: number | null;
  /** B minus A, in millimetres; `null` unless both publish it. */
  difference: number | null;
}

/** Decimal places a number is written with, so a difference can be kept as exact as its inputs. */
function decimals(value: number): number {
  const [mantissa = '', exponent = '0'] = String(value).split('e');
  return Math.max(0, (mantissa.split('.')[1] ?? '').length - Number(exponent));
}

/**
 * `b - a` without the binary noise: `12.07 - 11.9` is `0.17000000000000171` in floating point,
 * and the sheets publish both figures to two places. The result is as precise as the finer of the
 * two, which is the precision of the true difference; nothing is rounded away.
 */
export function difference(a: number, b: number): number {
  const places = Math.min(100, Math.max(decimals(a), decimals(b)));
  return Number((b - a).toFixed(places));
}

/**
 * Every dimension a record publishes in millimetres, by symbol, in the order the detail page lists
 * them. Lists (a shot cartridge's hull lengths), tolerances and figures in another unit are not
 * dimensions here, and only numbers are: a blank means the sheet does not dimension the feature.
 */
function dimensionsOf(record: Record_): Map<string, number> {
  const found = new Map<string, number>();
  const groups = record.cartridge;
  const known = GROUP_ORDER.cartridge.filter((name) => name in groups);
  const placed = new Set(known);
  const rest = Object.keys(groups).filter((name) => !placed.has(name)).sort();
  for (const name of [...known, ...rest]) {
    const group = groups[name];
    if (!group || Array.isArray(group)) continue;
    for (const field of orderedFields('cartridge', name, group)) {
      const value = (group as Group)[field];
      if (typeof value !== 'number' || field.endsWith('Tol') || field in FIELD_UNITS) continue;
      const symbol = FIELD_LABELS[field] ?? field;
      if (!found.has(symbol)) found.set(symbol, value);
    }
  }
  return found;
}

/**
 * One row per dimension symbol either record publishes, in the detail page's order: where the two
 * orders disagree, A's holds, and a symbol only B publishes follows the one before it in B's list
 * (it comes first if none precedes it, and last if the two share no symbol at all). Where a record
 * does not publish a symbol its figure is `null`, and so is the difference.
 */
export function allDimensions(a: Record_, b: Record_): DimensionRow[] {
  const first = dimensionsOf(a);
  const second = dimensionsOf(b);
  const symbols = [...first.keys()];
  const shared = symbols.some((symbol) => second.has(symbol));
  let previous = shared ? -1 : symbols.length - 1;
  for (const symbol of second.keys()) {
    const at = symbols.indexOf(symbol);
    if (at >= 0) previous = at;
    else symbols.splice(++previous, 0, symbol);
  }
  return symbols.map((symbol) => {
    const x = first.get(symbol) ?? null;
    const y = second.get(symbol) ?? null;
    return { symbol, a: x, b: y, difference: x === null || y === null ? null : difference(x, y) };
  });
}

/** A figure as the reader's unit system writes it: the sheet's text in metric, inches otherwise. */
export function showLength(value: number, system: UnitSystem): string {
  return system === 'metric' ? (formatValue(value) as string) : displayNumber(value, 'in');
}

export interface Overlay {
  /** Both in the viewBox's units, which are millimetres. */
  width: number;
  height: number;
  a: string;
  b: string;
  /** The common axis and the common head face, as `[x1, y1, x2, y2]`. */
  axis: [number, number, number, number];
  head: [number, number, number, number];
}

export type OverlayResult = { overlay: Overlay } | { unavailable: 'shot' | 'a' | 'b' };

/** Whether the outline of a record can be drawn: a shot cartridge is another kind of drawing. */
function profileOf(record: Record_) {
  if (record.family === 'shotshell') return null;
  try {
    return caseOuterProfile(adaptMetallic(record as unknown as CartridgeRecord));
  } catch {
    // Six records publish too little to draw; the table still compares what they do publish.
    return null;
  }
}

/**
 * The two outlines in one viewport: one scale, one axis, and the head faces (z = 0) at the same
 * x. The viewBox is in millimetres, so a length on the page is a length of the cartridge.
 */
export function overlayOf(a: Record_, b: Record_): OverlayResult {
  if (a.family === 'shotshell' || b.family === 'shotshell') return { unavailable: 'shot' };
  const first = profileOf(a);
  if (!first) return { unavailable: 'a' };
  const second = profileOf(b);
  if (!second) return { unavailable: 'b' };
  const view = viewportFor([first, second], { scale: 1, marginMm: 2, frame: 'landscape' });
  const [headX, centreY] = view.xy(0, 0);
  const [, topY] = view.xy(view.rMax, 0);
  const [endX] = view.xy(0, view.zMax);
  return {
    overlay: {
      width: Number(fmt(view.width)),
      height: Number(fmt(view.height)),
      a: fullSectionPath(first, view),
      b: fullSectionPath(second, view),
      axis: [headX, centreY, endX, centreY],
      head: [headX, topY, headX, centreY + view.rMax]
    }
  };
}
