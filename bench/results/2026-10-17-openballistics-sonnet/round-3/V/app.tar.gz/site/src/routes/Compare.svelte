<script lang="ts">
  import PageHeader from '../components/PageHeader.svelte';
  import ScaleRuler from '../components/ScaleRuler.svelte';
  import { allDimensions, overlayOf, showLength } from '../lib/compare';
  import { byKey, load } from '../lib/data';
  import { t } from '../lib/i18n.svelte';
  import { href } from '../lib/router';
  import { unitSystem } from '../lib/units.svelte';

  interface Props {
    /** The keys of the two cartridges, as `#/c/<key>` writes them. */
    a: string;
    b: string;
  }
  let { a, b }: Props = $props();

  const records = $derived(Promise.all([load(a), load(b)]));
  const system = $derived(unitSystem());
  /** The names the page can use before the records arrive; the key stands in for an unknown one. */
  const nameA = $derived(byKey(a)?.name ?? a);
  const nameB = $derived(byKey(b)?.name ?? b);
</script>

<div data-ui="Compare" class="contents">
  <PageHeader
    title={t('compare.heading', { a: nameA, b: nameB })}
    description={t('compare.lede')}
    backHref={href.cartridge(a)}
    backLabel={t('compare.back', { name: nameA })}
  />

  {#await records}
    <p class="status" role="status">{t('compare.loading', { a: nameA, b: nameB })}</p>
  {:then [first, second]}
    {@const drawn = overlayOf(first, second)}
    {@const rows = allDimensions(first, second)}

    <section class="profiles">
      {#if 'overlay' in drawn}
        {@const overlay = drawn.overlay}
        <figure>
          <!--
            One viewBox in millimetres for both outlines, so a length on the page is a length of
            the cartridge. Only the two outlines are paths; the axis and the head face are lines.
          -->
          <svg
            viewBox={`0 0 ${overlay.width} ${overlay.height}`}
            style:max-width={`${overlay.width * 8}px`}
            role="img"
            aria-label={t('compare.profiles', { a: first.name, b: second.name })}
          >
            <line class="guide" x1={overlay.axis[0]} y1={overlay.axis[1]} x2={overlay.axis[2]} y2={overlay.axis[3]} />
            <line class="guide" x1={overlay.head[0]} y1={overlay.head[1]} x2={overlay.head[2]} y2={overlay.head[3]} />
            <path class="outline first" d={overlay.a} />
            <path class="outline second" d={overlay.b} />
          </svg>
          <ScaleRuler widthMm={overlay.width} />
          <figcaption>
            <span class="key"><span class="swatch first" aria-hidden="true"></span>{first.name}</span>
            <span class="key"><span class="swatch second" aria-hidden="true"></span>{second.name}</span>
          </figcaption>
        </figure>
      {:else if drawn.unavailable === 'shot'}
        <p class="note">{t('compare.shot')}</p>
      {:else}
        <p class="note">{t('compare.undrawn', { name: drawn.unavailable === 'a' ? first.name : second.name })}</p>
      {/if}
    </section>

    {#if rows.length}
      <div class="scroll">
        <table>
          <caption>{system === 'metric' ? t('compare.dimensionsMm') : t('compare.dimensionsIn')}</caption>
          <thead>
            <tr>
              <th scope="col">{t('compare.symbol')}</th>
              <th scope="col" class="num">{first.name}</th>
              <th scope="col" class="num">{second.name}</th>
              <th scope="col" class="num">{t('compare.difference')}</th>
            </tr>
          </thead>
          <tbody>
            {#each rows as row (row.symbol)}
              <tr>
                <td class="num">{row.symbol}</td>
                <td class="num">{row.a === null ? '' : showLength(row.a, system)}</td>
                <td class="num">{row.b === null ? '' : showLength(row.b, system)}</td>
                <td class="num">{row.difference === null ? '' : showLength(row.difference, system)}</td>
              </tr>
            {/each}
          </tbody>
        </table>
      </div>
      <p class="note">{t('compare.differenceNote', { a: first.name, b: second.name })}</p>
    {:else}
      <p class="note">{t('compare.none')}</p>
    {/if}
  {:catch error}
    <p class="status error">{error.message} <a href={href.list()}>{t('record.back')}</a></p>
  {/await}
</div>

<style>
  @layer legacy {
    .profiles { margin-bottom: 2rem; }
    figure {
      margin: 0;
      padding: var(--panel-padding, 1rem);
      background: var(--surface);
      border: 1px solid var(--rule);
      border-radius: var(--radius);
    }
    figure > svg { display: block; width: 100%; height: auto; margin-inline: auto; }
    /* Hairlines that stay one pixel wide whatever the scale; the second outline is dashed so the
       two differ by more than their colour. */
    .outline { fill-opacity: 0.12; stroke-width: 1.5; vector-effect: non-scaling-stroke; stroke-linejoin: round; }
    .outline.first { fill: var(--link); stroke: var(--link); }
    .outline.second { fill: var(--alert); stroke: var(--alert); stroke-dasharray: 6 3; }
    .guide { stroke: var(--ink-3); stroke-width: 1; stroke-dasharray: 2 3; vector-effect: non-scaling-stroke; }
    figcaption { display: flex; flex-wrap: wrap; gap: 0.5rem 1.5rem; margin-top: 0.75rem; font-size: var(--step-0); }
    .key { display: inline-flex; align-items: center; gap: 0.5rem; }
    .swatch { width: 1.5rem; border-top: 2px solid var(--link); }
    .swatch.second { border-top: 2px dashed var(--alert); }
    .scroll { overflow-x: auto; }
    table { border-collapse: collapse; font-size: var(--step-0); width: 100%; }
    caption { caption-side: top; text-align: left; font-weight: 600; padding-bottom: 0.5rem; }
    th, td { text-align: right; padding: 0.3rem 0.75rem 0.3rem 0; white-space: nowrap; }
    th { color: var(--ink-2); font-weight: 500; border-bottom: 1px solid var(--rule); }
    td { font-weight: 500; }
    th:first-child, td:first-child { text-align: left; }
    .note { margin: 0.75rem 0 0; color: var(--ink-2); font-size: var(--step-0); }
    .status { color: var(--ink-2); }
    .status.error { color: var(--alert); }
  }
</style>
