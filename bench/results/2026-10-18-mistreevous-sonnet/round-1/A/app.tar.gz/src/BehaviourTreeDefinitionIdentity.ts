import {
    AnyNodeDefinition,
    BranchNodeDefinition,
    NodeArgument,
    NodeAttributeDefinition,
    NodeGuardDefinition,
    RootNodeDefinition
} from "./BehaviourTreeDefinition";
import { MAIN_ROOT_NODE_KEY, RootNodeDefinitionMap, createRootNodeDefinitionMap } from "./BehaviourTreeBuilder";
import { isInteger } from "./BehaviourTreeDefinitionUtilities";

/**
 * A value that can be serialised to JSON, with a consistent order for the properties of an object.
 */
type CanonicalValue = null | boolean | number | string | CanonicalValue[] | { [key: string]: CanonicalValue };

/**
 * Creates an identifier for a tree definition, which is the same for every definition that builds the same tree.
 * This is the case for an MDSL definition and the equivalent JSON definition, however they were written. Only what the tree is
 * built from is taken into account, which includes the globally registered subtrees that are referenced but not any root nodes that are not.
 * This follows how BehaviourTreeBuilder reads a definition, including its defaults, and must be kept in step with it.
 * @param definition The root node definitions, which have been validated and used to build the tree.
 * @returns The identifier of the definition.
 */
export function createDefinitionId(definition: RootNodeDefinition[]): string {
    const rootNodeDefinitionMap = createRootNodeDefinitionMap(definition);

    return hash(JSON.stringify(canonicaliseNode(rootNodeDefinitionMap[MAIN_ROOT_NODE_KEY], rootNodeDefinitionMap)));
}

/**
 * Gets a definition of a node in a consistent form, which has the same defaults that the tree builder applies and in which
 * branch nodes are replaced by the nodes that they refer to.
 * @param definition The node definition.
 * @param rootNodeDefinitionMap The mapping of root node identifers to root node definitions, including globally registered subtree root node definitions.
 * @returns The node definition in a consistent form.
 */
function canonicaliseNode(definition: AnyNodeDefinition, rootNodeDefinitionMap: RootNodeDefinitionMap): CanonicalValue {
    // A branch node is built as the child of the root node that it refers to, and nothing else about it is used.
    if (definition.type === "branch") {
        return canonicaliseNode(rootNodeDefinitionMap[definition.ref].child, rootNodeDefinitionMap);
    }

    const canonicalChild = (child: AnyNodeDefinition) => canonicaliseNode(child, rootNodeDefinitionMap);

    return {
        type: definition.type,
        while: canonicaliseAttribute(definition.while, true),
        until: canonicaliseAttribute(definition.until, true),
        entry: canonicaliseAttribute(definition.entry),
        step: canonicaliseAttribute(definition.step),
        exit: canonicaliseAttribute(definition.exit),
        ...canonicaliseNodeProperties(definition, canonicalChild)
    };
}

/**
 * Gets the properties of a node definition that are specific to the type of node, in a consistent form.
 * @param definition The node definition.
 * @param canonicalChild A function to get a child node definition in a consistent form.
 * @returns The properties of the node definition that are specific to the type of node.
 */
function canonicaliseNodeProperties(
    definition: Exclude<AnyNodeDefinition, BranchNodeDefinition>,
    canonicalChild: (child: AnyNodeDefinition) => CanonicalValue
): { [key: string]: CanonicalValue } {
    switch (definition.type) {
        case "root":
        case "flip":
        case "succeed":
        case "fail":
            return { child: canonicalChild(definition.child) };

        case "repeat":
            return { iterations: canonicaliseCount(definition.iterations), child: canonicalChild(definition.child) };

        case "retry":
            return { attempts: canonicaliseCount(definition.attempts), child: canonicalChild(definition.child) };

        case "sequence":
        case "selector":
        case "parallel":
        case "race":
        case "all":
            return { children: definition.children.map(canonicalChild) };

        case "lotto":
            return { weights: definition.weights ?? null, children: definition.children.map(canonicalChild) };

        case "action":
        case "condition":
            return { call: definition.call, args: canonicaliseArguments(definition.args) };

        case "wait":
            return { duration: canonicaliseCount(definition.duration) };
    }
}

/**
 * Gets a node attribute definition in a consistent form.
 * @param definition The attribute definition, if there is one.
 * @param isGuard Whether the attribute is a guard.
 * @returns The attribute definition in a consistent form, or null if there isn't one.
 */
function canonicaliseAttribute(
    definition: NodeAttributeDefinition | NodeGuardDefinition | undefined,
    isGuard = false
): CanonicalValue {
    if (!definition) {
        return null;
    }

    return {
        call: definition.call,
        args: canonicaliseArguments(definition.args),
        ...(isGuard ? { succeedOnAbort: !!(definition as NodeGuardDefinition).succeedOnAbort } : {})
    };
}

/**
 * Gets the arguments of an action, condition or attribute in a consistent form, in which the values that JSON would give the same
 * form as null, which are undefined, NaN and the infinities, are different from each other and from null.
 * @param args The arguments, if there are any.
 * @returns The arguments in a consistent form.
 */
function canonicaliseArguments(args: NodeArgument[] | undefined): CanonicalValue[] {
    return (args ?? []).map((arg): CanonicalValue => {
        if (typeof arg === "undefined") {
            return { "#undefined": true };
        }

        return typeof arg === "number" && !Number.isFinite(arg) ? { "#number": String(arg) } : arg;
    });
}

/**
 * Gets a number that is either a single count or a range of counts in a consistent form, in the way that the tree builder reads it.
 * @param value The count or range of counts, if there is one.
 * @returns The single count, the lower and upper counts, or null if there isn't one.
 */
function canonicaliseCount(value: number | [number, number] | undefined): CanonicalValue {
    if (Array.isArray(value)) {
        return [value[0], value[1]];
    }

    return isInteger(value) ? (value as number) : null;
}

/**
 * Gets a hash of a string, which is not secure and is only meant to tell values apart.
 * This is two passes of cyrb53 with different seeds, giving 106 bits, so that it is not likely that the definitions of any of the
 * trees that an application has would have the same hash.
 * @param value The string to hash.
 * @returns The hash as a string of hexadecimal digits.
 */
function hash(value: string): string {
    return [0, 1].map((seed) => hashWithSeed(value, seed).toString(16).padStart(14, "0")).join("");
}

/**
 * Gets the cyrb53 hash of a string.
 * @param value The string to hash.
 * @param seed The seed.
 * @returns The 53 bit hash as a number.
 */
function hashWithSeed(value: string, seed: number): number {
    let h1 = 0xdeadbeef ^ seed;
    let h2 = 0x41c6ce57 ^ seed;

    for (let index = 0; index < value.length; index++) {
        const code = value.charCodeAt(index);

        h1 = Math.imul(h1 ^ code, 2654435761);
        h2 = Math.imul(h2 ^ code, 1597334677);
    }

    h1 = Math.imul(h1 ^ (h1 >>> 16), 2246822507) ^ Math.imul(h2 ^ (h2 >>> 13), 3266489909);
    h2 = Math.imul(h2 ^ (h2 >>> 16), 2246822507) ^ Math.imul(h1 ^ (h1 >>> 13), 3266489909);

    return 4294967296 * (2097151 & h2) + (h1 >>> 0);
}
