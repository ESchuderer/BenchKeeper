import State, { AnyState } from "./State";

/**
 * The current version of the snapshot format.
 */
export const SNAPSHOT_VERSION = 1;

/**
 * The execution state that is common to the snapshot of every node.
 */
interface BaseNodeSnapshot<Type extends string> {
    /**
     * The node type.
     */
    type: Type;
    /**
     * The node state.
     */
    state: AnyState;
}

/**
 * The execution state of a node that has child nodes, which is either a composite or a decorator node.
 */
interface ParentNodeSnapshot<Type extends string> extends BaseNodeSnapshot<Type> {
    /**
     * The snapshots of the child nodes, in the order in which they are defined.
     */
    children: NodeSnapshot[];
}

/**
 * The execution state of a repeat node.
 */
export interface RepeatNodeSnapshot extends ParentNodeSnapshot<"repeat"> {
    /**
     * The number of iterations to make, or null if there is no limit or one has not been chosen yet.
     */
    targetIterationCount: number | null;
    /**
     * The number of iterations that have been completed.
     */
    currentIterationCount: number;
}

/**
 * The execution state of a retry node.
 */
export interface RetryNodeSnapshot extends ParentNodeSnapshot<"retry"> {
    /**
     * The number of attempts to make, or null if there is no limit or one has not been chosen yet.
     */
    targetAttemptCount: number | null;
    /**
     * The number of attempts that have been made.
     */
    currentAttemptCount: number;
}

/**
 * The execution state of a lotto node.
 */
export interface LottoNodeSnapshot extends ParentNodeSnapshot<"lotto"> {
    /**
     * The index of the child node that was drawn as the winner, or null if the node has not drawn a child yet.
     */
    selectedChild: number | null;
}

/**
 * The execution state of a wait node.
 */
export interface WaitNodeSnapshot extends BaseNodeSnapshot<"wait"> {
    /**
     * The total duration in milliseconds that the node is waiting for, or null if it is waiting indefinitely.
     * This is only meaningful if the node is running, otherwise it is null.
     */
    totalDuration: number | null;
    /**
     * The duration in milliseconds that the node has been waiting for.
     * This is only meaningful if the node is running, otherwise it is zero.
     */
    waitedDuration: number;
}

/**
 * The result of an action function promise that has settled but has not yet been handled by the tree.
 */
export type PromiseResultSnapshot = {
    /**
     * Whether the promise was resolved rather than rejected.
     */
    isResolved: boolean;
    /**
     * The resolved value or rejection reason, as a string.
     */
    value: string;
};

/**
 * The execution state of an action node.
 * A promise that an action function returned cannot be stored in a snapshot, so if it had not settled by the time the
 * snapshot was taken the action is snapshotted as not yet started, with a state of READY, and its function will be called again.
 */
export interface ActionNodeSnapshot extends BaseNodeSnapshot<"action"> {
    /**
     * The result of the promise that the action function returned, or null if there isn't one or it has not settled.
     * This is only meaningful if the node is running, otherwise it is null.
     */
    promiseResult: PromiseResultSnapshot | null;
}

/**
 * The execution state of a single node in a behaviour tree.
 * This contains only plain data and can be serialised to JSON.
 */
export type NodeSnapshot =
    | ParentNodeSnapshot<"root" | "sequence" | "selector" | "parallel" | "race" | "all" | "flip" | "succeed" | "fail">
    | RepeatNodeSnapshot
    | RetryNodeSnapshot
    | LottoNodeSnapshot
    | WaitNodeSnapshot
    | ActionNodeSnapshot
    | BaseNodeSnapshot<"condition">;

/**
 * The execution state of a behaviour tree, as returned by the 'snapshot' function of a behaviour tree instance.
 * This contains only plain data and can be serialised to JSON and deserialised without change.
 */
export type BehaviourTreeSnapshot = {
    /**
     * The version of the snapshot format.
     */
    version: typeof SNAPSHOT_VERSION;
    /**
     * Identifies the definition of the tree that the snapshot was taken from, which is the same for an MDSL definition and the equivalent JSON definition.
     * A snapshot can only be restored to a tree that has the same definition.
     */
    definition: string;
    /**
     * The execution state of the root node, which contains the state of every nested node.
     */
    root: NodeSnapshot;
};

/**
 * An object with unknown properties, such as one that was deserialised from JSON.
 */
export type SnapshotRecord = { [key: string]: unknown };

/**
 * Gets whether a value is a non-null, non-array object.
 * @param value The value.
 * @returns Whether the value is a non-null, non-array object.
 */
export function isRecord(value: unknown): value is SnapshotRecord {
    return typeof value === "object" && value !== null && !Array.isArray(value);
}

/**
 * Gets whether a value is a valid node state.
 * @param value The value.
 * @returns Whether the value is a valid node state.
 */
export function isNodeState(value: unknown): value is AnyState {
    return Object.values(State).includes(value as State);
}

/**
 * Validates that a property of a node snapshot is a non-negative integer, or optionally null.
 * @param snapshot The node snapshot.
 * @param property The name of the property to validate.
 * @param path The path of the node in the tree, for use in error messages.
 * @param isNullAllowed Whether the property is allowed to be null.
 * @throws An error if the property is not valid.
 */
export function validateNonNegativeInteger(
    snapshot: SnapshotRecord,
    property: string,
    path: string,
    isNullAllowed = false
): void {
    const value = snapshot[property];

    if ((isNullAllowed && value === null) || (Number.isInteger(value) && (value as number) >= 0)) {
        return;
    }

    throw new Error(
        `expected '${property}' to be a non-negative integer${
            isNullAllowed ? " or null" : ""
        } at '${path}' but got '${value}'`
    );
}

/**
 * Validates that the target count of a running node agrees with how the node is defined, as a running node always has the
 * target that was derived from its definition when it started running. This stops a snapshot that has been taken from a
 * different definition, or changed, from making a node loop or wait for a different number of times than it would.
 * @param snapshot The node snapshot.
 * @param property The name of the target count property to validate.
 * @param path The path of the node in the tree, for use in error messages.
 * @param explicit The explicit count that the node is defined with, or null if it doesn't have one.
 * @param isRandom Whether the node is defined with a minimum and maximum count to randomly choose between.
 * @throws An error if the property does not agree with the definition.
 */
export function validateTargetCountForDefinition(
    snapshot: SnapshotRecord,
    property: string,
    path: string,
    explicit: number | null,
    isRandom: boolean
): void {
    const value = snapshot[property];

    if (explicit !== null) {
        if (value !== explicit) {
            throw new Error(`expected '${property}' to be ${explicit} at '${path}' as the node is defined with it`);
        }
    } else if (isRandom) {
        if (value === null) {
            throw new Error(`expected '${property}' to be a number at '${path}' as the node is defined with a range`);
        }
    } else if (value !== null) {
        throw new Error(`expected '${property}' to be null at '${path}' as the node is defined with no limit`);
    }
}

/**
 * Validates that a property of a node snapshot is a non-negative finite number.
 * @param snapshot The node snapshot.
 * @param property The name of the property to validate.
 * @param path The path of the node in the tree, for use in error messages.
 * @throws An error if the property is not valid.
 */
export function validateNonNegativeNumber(snapshot: SnapshotRecord, property: string, path: string): void {
    const value = snapshot[property];

    if (typeof value !== "number" || !Number.isFinite(value) || value < 0) {
        throw new Error(`expected '${property}' to be a non-negative finite number at '${path}' but got '${value}'`);
    }
}
