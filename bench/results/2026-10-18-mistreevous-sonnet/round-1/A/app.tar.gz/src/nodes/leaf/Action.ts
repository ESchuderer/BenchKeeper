import { BehaviourTreeOptions } from "../../BehaviourTreeOptions";
import { NodeDetails } from "../Node";
import State, { AnyState, CompleteState } from "../../State";
import { Agent } from "../../Agent";
import Leaf from "./Leaf";
import Lookup from "../../Lookup";
import Attribute from "../../attributes/Attribute";
import { ActionNodeSnapshot, SnapshotRecord, isRecord } from "../../BehaviourTreeSnapshot";

/**
 * The type representing a resolved/rejected update promise.
 */
type UpdatePromiseResult = {
    /**
     * Whether the promise was resolved rather than rejected.
     */
    isResolved: boolean;

    /**
     * The promise resolved value or rejection reason.
     */
    value: any;
};

/**
 * An Action leaf node.
 * This represents an immediate or ongoing state of behaviour.
 */
export default class Action extends Leaf {
    /**
     * @param attributes The node attributes.
     * @param options The behaviour tree options.
     * @param actionName The action name.
     * @param actionArguments The array of action arguments.
     */
    constructor(
        attributes: Attribute[],
        options: BehaviourTreeOptions,
        private actionName: string,
        public actionArguments: any[]
    ) {
        super("action", attributes, options);
    }

    /**
     * Whether there is a pending update promise.
     */
    private isUsingUpdatePromise = false;

    /**
     * The finished state result of an update promise.
     */
    private updatePromiseResult: UpdatePromiseResult | null = null;

    /**
     * Identifies the current update promise, so that a promise that is no longer wanted can be told apart from it.
     */
    private updatePromiseId = 0;

    /**
     * Called when the node is being updated.
     * @param agent The agent.
     */
    protected onUpdate(agent: Agent): void {
        // If the result of this action depends on an update promise then there is nothing to do until it settles.
        if (this.isUsingUpdatePromise) {
            // Are we still waiting for our update promise to settle?
            if (!this.updatePromiseResult) {
                return;
            }

            const { isResolved, value } = this.updatePromiseResult;

            // Our update promise settled, was it resolved or rejected?
            if (isResolved) {
                // Our promise resolved so check to make sure the result is a valid finished state.
                if (value !== State.SUCCEEDED && value !== State.FAILED) {
                    throw new Error(
                        "action node promise resolved with an invalid value, expected a State.SUCCEEDED or State.FAILED value to be returned"
                    );
                }

                // Set the state of this node to match the state returned by the promise.
                this.setState(value);

                return;
            } else {
                // The promise was rejected, which isn't great.
                throw new Error(`action function '${this.actionName}' promise rejected with '${value}'`);
            }
        }

        // Attempt to get the invoker for the action function.
        const actionFuncInvoker = Lookup.getFuncInvoker(agent, this.actionName);

        // The action function should be defined.
        if (actionFuncInvoker === null) {
            throw new Error(
                `cannot update action node as the action '${this.actionName}' function is not defined on the agent and has not been registered`
            );
        }

        let actionFunctionResult;

        try {
            // Call the action function, the result of which may be:
            // - The finished state of this action node.
            // - A promise to return a finished node state.
            // - Undefined if the node should remain in the running state.
            actionFunctionResult = actionFuncInvoker(this.actionArguments) as CompleteState | Promise<CompleteState>;
        } catch (error) {
            // An uncaught error was thrown.
            if (error instanceof Error) {
                throw new Error(`action function '${this.actionName}' threw: ${error.stack}`);
            } else {
                throw new Error(`action function '${this.actionName}' threw: ${error}`);
            }
        }

        if (actionFunctionResult instanceof Promise) {
            // Each update promise gets its own identifier.
            const updatePromiseId = ++this.updatePromiseId;

            actionFunctionResult.then(
                (result) => {
                    // If the identifier has changed then the promise was cleared as it was resolving, probably via an abort, reset or restore.
                    if (updatePromiseId !== this.updatePromiseId) {
                        return;
                    }

                    // Set the resolved update promise result so that it can be handled on the next update of this node.
                    this.updatePromiseResult = {
                        isResolved: true,
                        value: result
                    };
                },
                (reason) => {
                    // If the identifier has changed then the promise was cleared as it was rejecting, probably via an abort, reset or restore.
                    if (updatePromiseId !== this.updatePromiseId) {
                        return;
                    }

                    // Set the rejected update promise result so that it can be handled on the next update of this node.
                    this.updatePromiseResult = {
                        isResolved: false,
                        value: reason
                    };
                }
            );

            // This node will be in the 'RUNNING' state until the update promise resolves.
            this.setState(State.RUNNING);

            // We are now waiting for the promise returned by the use to resolve before we know what state this node is in.
            this.isUsingUpdatePromise = true;
        } else {
            // Validate the returned value.
            this.validateUpdateResult(actionFunctionResult);

            // Set the state of this node, this may be undefined, which just means that the node is still in the 'RUNNING' state.
            this.setState(actionFunctionResult || State.RUNNING);
        }
    }

    /**
     * Gets the name of the node.
     */
    getName = () => this.actionName;

    /**
     * Reset the state of the node.
     */
    reset = () => {
        // Reset the state of this node.
        this.setState(State.READY);

        // There is no longer an update promise that we care about.
        this.clearUpdatePromise();
    };

    /**
     * Clears any update promise, so that the result of one that is still pending is ignored.
     */
    private clearUpdatePromise = () => {
        this.isUsingUpdatePromise = false;
        this.updatePromiseResult = null;
        this.updatePromiseId++;
    };

    /**
     * Gets the state of this node to include in a snapshot.
     */
    protected getSnapshotState(): AnyState {
        // A promise that has not settled cannot be stored, so an action that is waiting on one is snapshotted as not yet started and its function will be called again.
        if (this.is(State.RUNNING) && this.isUsingUpdatePromise && !this.updatePromiseResult) {
            return State.READY;
        }

        return this.getState();
    }

    /**
     * Gets the execution state specific to this type of node, to include in a snapshot.
     */
    protected getSnapshotData() {
        // A promise that has not settled cannot be stored, and a result is only used while the node is running.
        if (!this.is(State.RUNNING) || !this.updatePromiseResult) {
            return { promiseResult: null };
        }

        const { isResolved, value } = this.updatePromiseResult;

        return { promiseResult: { isResolved, value: stringifyPromiseValue(value) } };
    }

    /**
     * Validates the execution state specific to this type of node in a snapshot.
     * @param snapshot The snapshot of this node.
     * @param path The path of this node in the tree, for use in error messages.
     */
    protected validateSnapshotData(snapshot: SnapshotRecord, path: string): void {
        const { promiseResult, state } = snapshot;

        if (
            promiseResult !== null &&
            !(
                isRecord(promiseResult) &&
                typeof promiseResult.isResolved === "boolean" &&
                typeof promiseResult.value === "string"
            )
        ) {
            throw new Error(
                `expected 'promiseResult' to be null or an object with an 'isResolved' boolean and a 'value' string at '${path}'`
            );
        }

        // A promise result would be used instead of calling the action function the first time that the node is updated.
        if (promiseResult !== null && state !== State.RUNNING) {
            throw new Error(`expected 'promiseResult' to be null at '${path}' as the node is not running`);
        }
    }

    /**
     * Restores the execution state specific to this type of node from a snapshot that has been validated.
     * @param snapshot The snapshot of this node.
     */
    protected restoreSnapshotData(snapshot: ActionNodeSnapshot): void {
        // Forget any update promise that the node was waiting on, as we have no further interest in it.
        this.clearUpdatePromise();

        if (snapshot.promiseResult) {
            this.isUsingUpdatePromise = true;
            this.updatePromiseResult = { ...snapshot.promiseResult };
        }
    }

    /**
     * Gets the details of this node instance.
     * @returns The details of this node instance.
     */
    public getDetails(): NodeDetails {
        return {
            ...super.getDetails(),
            args: this.actionArguments
        };
    }

    /**
     * Called when the state of this node changes.
     * @param previousState The previous node state.
     */
    protected onStateChanged(previousState: State): void {
        this.options.onNodeStateChange?.({
            id: this.uid,
            type: this.getType(),
            args: this.actionArguments,
            while: this.attributes.while?.getDetails(),
            until: this.attributes.until?.getDetails(),
            entry: this.attributes.entry?.getDetails(),
            step: this.attributes.step?.getDetails(),
            exit: this.attributes.exit?.getDetails(),
            previousState,
            state: this.getState()
        });
    }

    /**
     * Validate the result of an update function call.
     * @param result The result of an update function call.
     */
    private validateUpdateResult = (result: CompleteState | State.RUNNING) => {
        switch (result) {
            case State.SUCCEEDED:
            case State.FAILED:
            case State.RUNNING:
            case undefined:
                return;
            default:
                throw new Error(
                    `expected action function '${this.actionName}' to return an optional State.SUCCEEDED or State.FAILED value but returned '${result}'`
                );
        }
    };
}

/**
 * Gets the string form of the value that an update promise resolved with or was rejected for.
 * @param value The value.
 * @returns The string form of the value.
 */
function stringifyPromiseValue(value: unknown): string {
    try {
        return String(value);
    } catch {
        return "unknown";
    }
}
