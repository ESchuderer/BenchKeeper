import Leaf from "./Leaf";
import State from "../../State";
import Attribute from "../../attributes/Attribute";
import { Agent } from "../../Agent";
import { BehaviourTreeOptions } from "../../BehaviourTreeOptions";
import {
    SnapshotRecord,
    WaitNodeSnapshot,
    validateNonNegativeInteger,
    validateNonNegativeNumber,
    validateTargetCountForDefinition
} from "../../BehaviourTreeSnapshot";

/**
 * A WAIT node.
 * The state of this node will change to SUCCEEDED after a duration of time
 */
export default class Wait extends Leaf {
    /**
     * @param attributes The node attributes.
     * @param options The behaviour tree options.
     * @param duration The duration that this node will wait to succeed in milliseconds.
     * @param durationMin The minimum possible duration in milliseconds that this node will wait to succeed.
     * @param durationMax The maximum possible duration in milliseconds that this node will wait to succeed.
     */
    constructor(
        attributes: Attribute[],
        options: BehaviourTreeOptions,
        private duration: number | null,
        private durationMin: number | null,
        private durationMax: number | null
    ) {
        super("wait", attributes, options);
    }

    /**
     * The time in milliseconds at which this node was first updated.
     */
    private initialUpdateTime: number = 0;

    /**
     * The total duration in milliseconds that this node will be waiting for.
     */
    private totalDuration: number | null = null;

    /**
     * The duration in milliseconds that this node has been waiting for.
     */
    private waitedDuration: number = 0;

    /**
     * Called when the node is being updated.
     * @param agent The agent.
     */
    protected onUpdate(agent: Agent): void {
        // If this node is in the READY state then we need to set the initial update time.
        if (this.is(State.READY)) {
            // Set the initial update time.
            this.initialUpdateTime = new Date().getTime();

            // Set the initial waited duration.
            this.waitedDuration = 0;

            // Are we dealing with an explicit duration or will we be randomly picking a duration between the min and max duration.
            if (this.duration !== null) {
                this.totalDuration = this.duration;
            } else if (this.durationMin !== null && this.durationMax !== null) {
                // We will be picking a random duration between a min and max duration, if the optional 'random' behaviour tree
                // function option is defined then we will be using that, otherwise we will fall back to using Math.random.
                const random = typeof this.options.random === "function" ? this.options.random : Math.random;

                // Pick a random duration between a min and max duration.
                this.totalDuration = Math.floor(
                    random() * (this.durationMax - this.durationMin + 1) + this.durationMin
                );
            } else {
                this.totalDuration = null;
            }

            // The node is now running until we finish waiting.
            this.setState(State.RUNNING);
        }

        // If we have no total duration then this wait node will wait indefinitely until it is aborted.
        if (this.totalDuration === null) {
            return;
        }

        // If we have a 'getDeltaTime' function defined as part of our options then we will use it to figure out how long we have waited for.
        if (typeof this.options.getDeltaTime === "function") {
            // Get the delta time.
            const deltaTime = this.options.getDeltaTime();

            // Our delta time must be a valid number and cannot be NaN.
            if (typeof deltaTime !== "number" || isNaN(deltaTime)) {
                throw new Error("The delta time must be a valid number and not NaN.");
            }

            // Update the amount of time that this node has been waiting for based on the delta time.
            this.waitedDuration += deltaTime * 1000;
        } else {
            // We are not using a delta time, so we will just work out hom much time has passed since the first update.
            this.waitedDuration = new Date().getTime() - this.initialUpdateTime;
        }

        // Have we waited long enough?
        if (this.waitedDuration >= this.totalDuration) {
            // We have finished waiting!
            this.setState(State.SUCCEEDED);
        }
    }

    /**
     * Gets the execution state specific to this type of node, to include in a snapshot.
     * Absolute times are not included as they mean nothing to the process that the snapshot is restored in.
     */
    protected getSnapshotData() {
        // The duration that a node has been waiting for is only used while it is running.
        if (!this.is(State.RUNNING)) {
            return { totalDuration: null, waitedDuration: 0 };
        }

        // Without a 'getDeltaTime' function the duration is only updated when the node is updated, but it continues to pass.
        const waitedDuration =
            typeof this.options.getDeltaTime === "function"
                ? this.waitedDuration
                : new Date().getTime() - this.initialUpdateTime;

        // A duration cannot be negative, which could otherwise happen if the clock was set back.
        return { totalDuration: this.totalDuration, waitedDuration: Math.max(0, waitedDuration) };
    }

    /**
     * Validates the execution state specific to this type of node in a snapshot.
     * @param snapshot The snapshot of this node.
     * @param path The path of this node in the tree, for use in error messages.
     */
    protected validateSnapshotData(snapshot: SnapshotRecord, path: string): void {
        validateNonNegativeInteger(snapshot, "totalDuration", path, true);
        validateNonNegativeNumber(snapshot, "waitedDuration", path);

        // A total duration is always chosen as soon as the node starts running.
        if (snapshot.state === State.RUNNING) {
            validateTargetCountForDefinition(
                snapshot,
                "totalDuration",
                path,
                this.duration,
                this.durationMin !== null && this.durationMax !== null
            );
        }
    }

    /**
     * Restores the execution state specific to this type of node from a snapshot that has been validated.
     * @param snapshot The snapshot of this node.
     */
    protected restoreSnapshotData(snapshot: WaitNodeSnapshot): void {
        this.totalDuration = snapshot.totalDuration;
        this.waitedDuration = snapshot.waitedDuration;

        // The time that has passed since the snapshot was taken should not count, so start the wait as if it was
        // started the waited duration ago. This also covers the case where a clock is used rather than a delta time.
        this.initialUpdateTime = new Date().getTime() - snapshot.waitedDuration;
    }

    /**
     * Gets the name of the node.
     */
    getName = () => {
        if (this.duration !== null) {
            return `WAIT ${this.duration}ms`;
        } else if (this.durationMin !== null && this.durationMax !== null) {
            return `WAIT ${this.durationMin}ms-${this.durationMax}ms`;
        } else {
            return "WAIT";
        }
    };
}
