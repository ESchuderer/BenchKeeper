import { assert } from "chai";
import sinon from "sinon";

import { BehaviourTree, BehaviourTreeSnapshot, State, convertMDSLToJSON } from "../src/index";
import { RootNodeDefinition } from "../src/BehaviourTreeDefinition";

import {
    assertSnapshotRestoresAtEveryStep,
    deepFreeze,
    getDetailsWithoutIds,
    roundTripSnapshot
} from "./SnapshotTestUtilities";

const RUNNING_UNTIL = (tick: number) => (currentTick: number) => currentTick < tick ? State.RUNNING : State.SUCCEEDED;
const FAILING_UNTIL = (tick: number) => (currentTick: number) => currentTick < tick ? State.RUNNING : State.FAILED;

describe("A BehaviourTree instance", () => {
    describe("has a 'snapshot' function that", () => {
        it("returns the execution state of the tree as a plain object that is unchanged by JSON serialisation", () => {
            const tree = new BehaviourTree(
                "root { sequence { action [Work] condition [IsReady] } }",
                { Work: () => State.RUNNING, IsReady: () => true },
                {}
            );

            [() => undefined, () => tree.step()].forEach((action) => {
                action();

                const snapshot = tree.snapshot();

                assert.isObject(snapshot);
                assert.deepEqual(JSON.parse(JSON.stringify(snapshot)), snapshot);
            });
        });

        it("returns a snapshot that mirrors the structure of the tree and the state of each node", () => {
            const tree = new BehaviourTree(
                "root { sequence { condition [IsReady] flip { condition [IsReady] } condition [IsReady] } }",
                { IsReady: () => true },
                {}
            );

            assert.deepEqual(tree.snapshot(), {
                version: 1,
                definition: tree.snapshot().definition,
                root: {
                    type: "root",
                    state: State.READY,
                    children: [
                        {
                            type: "sequence",
                            state: State.READY,
                            children: [
                                { type: "condition", state: State.READY },
                                {
                                    type: "flip",
                                    state: State.READY,
                                    children: [{ type: "condition", state: State.READY }]
                                },
                                { type: "condition", state: State.READY }
                            ]
                        }
                    ]
                }
            });

            tree.step();

            assert.deepEqual(tree.snapshot(), {
                version: 1,
                definition: tree.snapshot().definition,
                root: {
                    type: "root",
                    state: State.FAILED,
                    children: [
                        {
                            type: "sequence",
                            state: State.FAILED,
                            children: [
                                { type: "condition", state: State.SUCCEEDED },
                                {
                                    type: "flip",
                                    state: State.FAILED,
                                    children: [{ type: "condition", state: State.SUCCEEDED }]
                                },
                                { type: "condition", state: State.READY }
                            ]
                        }
                    ]
                }
            });
        });

        it("returns the same snapshot for a tree that has been reset as for one that has not been stepped", () => {
            const definition = `root {
                sequence {
                    repeat [1, 3] { retry [1, 3] { lotto { action [Work] action [Work] } } }
                    wait [100, 200]
                    action [Work]
                }
            }`;
            const agent = { Work: () => State.SUCCEEDED };
            const tree = new BehaviourTree(definition, agent, {});
            const freshSnapshot = tree.snapshot();

            for (let step = 0; step < 4; step++) {
                tree.step();
            }
            assert.notDeepEqual(tree.snapshot(), freshSnapshot);

            tree.reset();

            assert.deepEqual(tree.snapshot(), freshSnapshot);
        });

        it("does not affect the tree or its subsequent behaviour", () => {
            const calls: string[] = [];
            const agent = {
                Work: () => {
                    calls.push("Work");
                    return State.RUNNING;
                }
            };
            const tree = new BehaviourTree("root { action [Work] }", agent, {});

            tree.step();
            const detailsBefore = getDetailsWithoutIds(tree);
            const snapshotBefore = tree.snapshot();

            tree.snapshot();

            assert.deepEqual(getDetailsWithoutIds(tree), detailsBefore);
            assert.deepEqual(tree.snapshot(), snapshotBefore);
            assert.deepEqual(calls, ["Work"]);

            tree.step();

            assert.deepEqual(calls, ["Work", "Work"]);
        });

        it("returns a new object each time that does not share state with the tree or earlier snapshots", () => {
            const tree = new BehaviourTree("root { action [Work] }", { Work: () => State.RUNNING }, {});

            const first = tree.snapshot();
            first.root.state = State.FAILED;
            (first.root as any).children.push("garbage");

            assert.deepEqual(tree.snapshot(), new BehaviourTree("root { action [Work] }", {}, {}).snapshot());
        });
    });

    describe("has a 'restore' function that", () => {
        const definition = "root { sequence { action [Done] action [Work] } }";
        const agent = { Done: () => State.SUCCEEDED, Work: () => State.RUNNING };

        it("sets a tree built from the same definition to the state of the tree the snapshot was taken from", () => {
            const original = new BehaviourTree(definition, agent, {});
            original.step();

            const restored = new BehaviourTree(definition, agent, {});
            restored.restore(roundTripSnapshot(original.snapshot()));

            assert.equal(restored.getState(), State.RUNNING);
            assert.isTrue(restored.isRunning());
            assert.deepEqual(getDetailsWithoutIds(restored), getDetailsWithoutIds(original));
        });

        it("can restore a tree that has already been stepped, discarding its existing state", () => {
            const original = new BehaviourTree(definition, agent, {});
            const target = new BehaviourTree(definition, agent, {});
            target.step();

            const initialSnapshot = original.snapshot();
            target.restore(initialSnapshot);

            assert.equal(target.getState(), State.READY);
            assert.deepEqual(getDetailsWithoutIds(target), getDetailsWithoutIds(original));
        });

        it("does not modify or hold on to the snapshot that it is given", () => {
            const original = new BehaviourTree(definition, agent, {});
            original.step();
            const snapshot = original.snapshot();
            const expected = JSON.parse(JSON.stringify(snapshot));

            const restored = new BehaviourTree(definition, agent, {});
            restored.restore(deepFreeze(snapshot));
            restored.step();

            assert.deepEqual(snapshot, expected);

            const mutable = JSON.parse(JSON.stringify(expected));
            const other = new BehaviourTree(definition, agent, {});
            other.restore(mutable);
            mutable.root.state = State.FAILED;
            mutable.root.children[0].children[1].state = State.FAILED;

            assert.deepEqual(other.snapshot(), expected);
        });

        it("does not notify the 'onNodeStateChange' option, as restoring is not a state change", () => {
            const original = new BehaviourTree(definition, agent, {});
            original.step();

            const changes: { type: string; previousState: State; state: State }[] = [];
            const restored = new BehaviourTree(definition, agent, {
                onNodeStateChange: ({ type, previousState, state }) => changes.push({ type, previousState, state })
            });

            restored.restore(original.snapshot());

            assert.deepEqual(changes, []);
            assert.deepEqual(getDetailsWithoutIds(restored), getDetailsWithoutIds(original));
        });

        it("does not notify the 'onNodeStateChange' option when restoring a tree that has already been stepped", () => {
            const original = new BehaviourTree(definition, agent, {});
            original.step();

            const changes: string[] = [];
            const target = new BehaviourTree(definition, agent, {
                onNodeStateChange: ({ type, state }) => changes.push(`${type}:${state}`)
            });
            target.step();
            assert.isNotEmpty(changes);
            changes.length = 0;

            target.restore(new BehaviourTree(definition, agent, {}).snapshot());
            target.restore(original.snapshot());

            assert.deepEqual(changes, []);
        });

        it("is followed by a step that notifies the 'onNodeStateChange' option of changes as usual", () => {
            const changes: { type: string; previousState: State; state: State }[] = [];
            let finish = false;
            const finishingAgent = { Done: () => State.SUCCEEDED, Work: () => (finish ? State.SUCCEEDED : undefined) };
            const options = {
                onNodeStateChange: ({ type, previousState, state }: any) => changes.push({ type, previousState, state })
            };

            const original = new BehaviourTree(definition, finishingAgent, {});
            original.step();

            const restored = new BehaviourTree(definition, finishingAgent, options);
            restored.restore(original.snapshot());

            assert.deepEqual(changes, []);

            finish = true;
            restored.step();

            assert.deepEqual(changes, [
                { type: "action", previousState: State.RUNNING, state: State.SUCCEEDED },
                { type: "sequence", previousState: State.RUNNING, state: State.SUCCEEDED },
                { type: "root", previousState: State.RUNNING, state: State.SUCCEEDED }
            ]);
        });

        describe("will error and leave the tree unchanged if the snapshot", () => {
            const createSnapshot = (): any => {
                const tree = new BehaviourTree(definition, agent, {});
                tree.step();
                return tree.snapshot();
            };

            const invalidSnapshots: [string, string, (snapshot: any) => any][] = [
                ["is undefined", "expected snapshot to be an object", () => undefined],
                ["is null", "expected snapshot to be an object", () => null],
                ["is a string", "expected snapshot to be an object", () => JSON.stringify(createSnapshot())],
                ["is an array", "expected snapshot to be an object", () => []],
                [
                    "has an unsupported version",
                    "unsupported snapshot version '2'",
                    (snapshot) => ({ ...snapshot, version: 2 })
                ],
                [
                    "has no version",
                    "unsupported snapshot version 'undefined'",
                    ({ definition, root }) => ({ definition, root })
                ],
                [
                    "has no root node snapshot",
                    "expected node snapshot to be an object at 'root'",
                    ({ version, definition }) => ({ version, definition })
                ],
                [
                    "has a root node snapshot of the wrong type",
                    "expected node snapshot of type 'root' but got 'sequence' at 'root'",
                    (snapshot) => ({ ...snapshot, root: snapshot.root.children[0] })
                ],
                [
                    "has a node snapshot of the wrong type",
                    "expected node snapshot of type 'action' but got 'condition' at 'root > sequence > action'",
                    (snapshot) => {
                        snapshot.root.children[0].children[0].type = "condition";
                        return snapshot;
                    }
                ],
                [
                    "has a node snapshot with an invalid state",
                    "invalid node state 'ENDED' at 'root > sequence > action'",
                    (snapshot) => {
                        snapshot.root.children[0].children[1].state = "ENDED";
                        return snapshot;
                    }
                ],
                [
                    "has a node snapshot with no state",
                    "invalid node state 'undefined' at 'root'",
                    (snapshot) => {
                        delete snapshot.root.state;
                        return snapshot;
                    }
                ],
                [
                    "has a node snapshot with too few children",
                    "expected 2 child node snapshots but got 1 at 'root > sequence'",
                    (snapshot) => {
                        snapshot.root.children[0].children.pop();
                        return snapshot;
                    }
                ],
                [
                    "has a node snapshot with too many children",
                    "expected 1 child node snapshots but got 2 at 'root'",
                    (snapshot) => {
                        snapshot.root.children.push(snapshot.root.children[0]);
                        return snapshot;
                    }
                ],
                [
                    "has a node snapshot with children that are not an array",
                    "expected an array of 2 child node snapshots at 'root > sequence'",
                    (snapshot) => {
                        snapshot.root.children[0].children = {};
                        return snapshot;
                    }
                ]
            ];

            invalidSnapshots.forEach(([description, message, createInvalidSnapshot]) => {
                it(`${description}`, () => {
                    const tree = new BehaviourTree(definition, agent, {});
                    tree.step();
                    const snapshotBefore = tree.snapshot();
                    const detailsBefore = getDetailsWithoutIds(tree);

                    assert.throws(() => tree.restore(createInvalidSnapshot(createSnapshot())), Error, message);

                    assert.deepEqual(tree.snapshot(), snapshotBefore);
                    assert.deepEqual(getDetailsWithoutIds(tree), detailsBefore);
                });
            });

            it("has an invalid node after valid ones, so that the state of earlier nodes is not changed", () => {
                const tree = new BehaviourTree(definition, agent, {});
                const snapshotBefore = tree.snapshot();
                const snapshot = createSnapshot();
                snapshot.root.children[0].children[1].type = "wait";

                assert.throws(() => tree.restore(snapshot), Error, "invalid snapshot");

                assert.deepEqual(tree.snapshot(), snapshotBefore);
            });
        });

        describe("checks the definition that the snapshot was taken from, and", () => {
            const mdsl = `root {
    sequence while(IsAlive, 1, "two", true, null, $target) entry(Prepare) exit(Finish, 3) {
        action [Work, 1, "a", false, null, $target]
        repeat [2, 4] {
            lotto [1, 3] {
                wait [100, 200]
                condition [IsReady]
            }
        }
        retry [3] until(IsDone) {
            branch [Sub]
        }
    }
}

root [Sub] {
    flip { action [Other] }
}`;

            const agent = {
                IsAlive: () => true,
                IsReady: () => true,
                IsDone: () => false,
                Prepare: () => undefined,
                Finish: () => undefined,
                Work: () => State.RUNNING,
                Other: () => State.SUCCEEDED,
                target: "target"
            };

            const createSnapshot = (definition: any, steps = 1) => {
                const tree = new BehaviourTree(definition, agent, {});
                for (let step = 0; step < steps; step++) {
                    tree.step();
                }
                return tree.snapshot();
            };

            const assertRejected = (treeDefinition: any, snapshotDefinition: any) => {
                const tree = new BehaviourTree(treeDefinition, agent, {});
                tree.step();
                const snapshotBefore = tree.snapshot();
                const detailsBefore = getDetailsWithoutIds(tree);

                assert.throws(
                    () => tree.restore(createSnapshot(snapshotDefinition)),
                    Error,
                    "invalid snapshot: snapshot does not match the tree's definition"
                );

                assert.deepEqual(tree.snapshot(), snapshotBefore);
                assert.deepEqual(getDetailsWithoutIds(tree), detailsBefore);
            };

            const assertRestored = (treeDefinition: any, snapshotDefinition: any) => {
                const original = new BehaviourTree(snapshotDefinition, agent, {});
                original.step();
                const restored = new BehaviourTree(treeDefinition, agent, {});

                restored.restore(roundTripSnapshot(original.snapshot()));

                assert.deepEqual(getDetailsWithoutIds(restored), getDetailsWithoutIds(original));
            };

            // The progress of wait nodes follows the clock, which must not move while trees are compared.
            let clock: sinon.SinonFakeTimers;
            beforeEach(() => (clock = sinon.useFakeTimers()));
            afterEach(() => {
                clock.restore();
                BehaviourTree.unregisterAll();
            });

            it("is recorded in the snapshot as a string", () => {
                const { definition } = createSnapshot(mdsl);

                assert.isString(definition);
                assert.isNotEmpty(definition);
                assert.strictEqual(createSnapshot(mdsl, 3).definition, definition);
                assert.strictEqual(createSnapshot(mdsl, 0).definition, definition);
            });

            it("accepts a snapshot from a tree built from the same definition", () => {
                assertRestored(mdsl, mdsl);
            });

            it("accepts a snapshot of an MDSL definition in a tree built from the equivalent JSON definition", () => {
                const json = convertMDSLToJSON(mdsl);

                assertRestored(json, mdsl);
                assertRestored(mdsl, json);
                assert.strictEqual(createSnapshot(json).definition, createSnapshot(mdsl).definition);
            });

            it("accepts a snapshot from an equivalent JSON definition that is written differently", () => {
                const written = [
                    {
                        id: "Sub",
                        type: "root",
                        child: { child: { call: "Other", type: "action" }, type: "flip" }
                    },
                    {
                        type: "root",
                        child: {
                            exit: { args: [3], call: "Finish" },
                            entry: { call: "Prepare", args: [] },
                            while: { call: "IsAlive", args: [1, "two", true, null, { $: "target" }] },
                            type: "sequence",
                            children: [
                                { type: "action", call: "Work", args: [1, "a", false, null, { $: "target" }] },
                                {
                                    type: "repeat",
                                    iterations: [2, 4],
                                    child: {
                                        type: "lotto",
                                        weights: [1, 3],
                                        children: [
                                            { type: "wait", duration: [100, 200] },
                                            { type: "condition", call: "IsReady" }
                                        ]
                                    }
                                },
                                {
                                    type: "retry",
                                    attempts: 3,
                                    until: { call: "IsDone" },
                                    child: { type: "branch", ref: "Sub" }
                                }
                            ]
                        }
                    }
                ];

                assertRestored(written, mdsl);
                assertRestored(mdsl, written);
            });

            it("accepts a snapshot from a tree with the same definition and different subtrees that are never used", () => {
                assertRestored(
                    `${mdsl}\nroot [Unused] { action [Nothing] }`,
                    `${mdsl}\nroot [Different] { sequence { action [Unrelated] } }`
                );
            });

            it("accepts a snapshot from a tree with the same registered subtrees", () => {
                BehaviourTree.register("Shared", "root { action [Work] }");

                const definition = "root { sequence { branch [Shared] action [Other] } }";

                assertRestored(definition, definition);
            });

            const differentDefinitions: [string, string, string][] = [
                ["calls a different action", "root { action [Work] }", "root { action [Other] }"],
                ["calls an action with different arguments", "root { action [Work, 1] }", "root { action [Work, 2] }"],
                [
                    "calls an action with a different argument type",
                    "root { action [Work, 1] }",
                    'root { action [Work, "1"] }'
                ],
                [
                    "calls an action with an agent property argument",
                    "root { action [Work, $a] }",
                    'root { action [Work, "a"] }'
                ],
                [
                    "has a different node type",
                    "root { sequence { action [Work] } }",
                    "root { selector { action [Work] } }"
                ],
                [
                    "has a different node type of the same shape",
                    "root { sequence { action [Work] } }",
                    "root { parallel { action [Work] } }"
                ],
                [
                    "has a different shape",
                    "root { sequence { action [Work] action [Other] } }",
                    "root { sequence { action [Other] action [Work] } }"
                ],
                [
                    "has a different condition",
                    "root { sequence { condition [IsReady] action [Work] } }",
                    "root { sequence { condition [IsAlive] action [Work] } }"
                ],
                ["has a different wait duration", "root { wait [100] }", "root { wait [200] }"],
                ["has a different wait duration range", "root { wait [100, 200] }", "root { wait [100, 300] }"],
                ["has a fixed rather than random wait duration", "root { wait [100] }", "root { wait [100, 100] }"],
                ["has a wait with no duration", "root { wait }", "root { wait [100] }"],
                [
                    "has a different number of repeat iterations",
                    "root { repeat [2] { action [Work] } }",
                    "root { repeat [3] { action [Work] } }"
                ],
                [
                    "has a repeat with no limit",
                    "root { repeat { action [Work] } }",
                    "root { repeat [2] { action [Work] } }"
                ],
                [
                    "has a different number of retry attempts",
                    "root { retry [2, 3] { action [Work] } }",
                    "root { retry [2, 4] { action [Work] } }"
                ],
                [
                    "has different lotto weights",
                    "root { lotto [1, 2] { action [Work] action [Other] } }",
                    "root { lotto [2, 1] { action [Work] action [Other] } }"
                ],
                [
                    "has a lotto without weights",
                    "root { lotto { action [Work] action [Other] } }",
                    "root { lotto [1, 1] { action [Work] action [Other] } }"
                ],
                [
                    "has a different guard",
                    "root { action [Work] while(IsAlive) }",
                    "root { action [Work] until(IsAlive) }"
                ],
                [
                    "has a different callback",
                    "root { action [Work] entry(Prepare) }",
                    "root { action [Work] exit(Prepare) }"
                ],
                [
                    "has a different callback function",
                    "root { action [Work] entry(Prepare) }",
                    "root { action [Work] entry(Finish) }"
                ],
                [
                    "has a callback that the other doesn't",
                    "root { action [Work] step(Prepare) }",
                    "root { action [Work] }"
                ],
                [
                    "has a different subtree",
                    "root { branch [Sub] } root [Sub] { action [Work] }",
                    "root { branch [Sub] } root [Sub] { action [Other] }"
                ],
                [
                    "has a branch to a different subtree",
                    "root { branch [A] } root [A] { action [Work] } root [B] { action [Other] }",
                    "root { branch [B] } root [A] { action [Work] } root [B] { action [Other] }"
                ]
            ];

            differentDefinitions.forEach(([description, treeDefinition, snapshotDefinition]) => {
                it(`rejects a snapshot from a tree that ${description}`, () => {
                    assertRejected(treeDefinition, snapshotDefinition);
                    assertRejected(snapshotDefinition, treeDefinition);
                });
            });

            it("rejects a snapshot from a tree with a guard that has a different resolved state", () => {
                assertRejected(
                    { type: "root", child: { type: "action", call: "Work", while: { call: "IsAlive" } } },
                    {
                        type: "root",
                        child: { type: "action", call: "Work", while: { call: "IsAlive", succeedOnAbort: true } }
                    }
                );
            });

            it("rejects a snapshot from a tree with the same shape in a different JSON definition", () => {
                assertRejected(
                    { type: "root", child: { type: "action", call: "Work" } },
                    { type: "root", child: { type: "action", call: "Other" } }
                );
            });

            it("rejects a snapshot from a tree with arguments that only differ by values that JSON cannot represent", () => {
                const values = [null, NaN, Infinity, -Infinity, undefined, "NaN"];

                values.forEach((snapshotValue, snapshotIndex) =>
                    values.forEach((treeValue, treeIndex) => {
                        const createDefinition = (value: any) => ({
                            type: "root",
                            child: { type: "action", call: "Work", args: [value] }
                        });

                        if (snapshotIndex === treeIndex) {
                            assertRestored(createDefinition(treeValue), createDefinition(snapshotValue));
                        } else {
                            assertRejected(createDefinition(treeValue), createDefinition(snapshotValue));
                        }
                    })
                );
            });

            it("rejects a snapshot from a tree with a different registered subtree", () => {
                const definition = "root { branch [Shared] }";

                BehaviourTree.register("Shared", "root { action [Work] }");
                const snapshot = createSnapshot(definition);

                BehaviourTree.register("Shared", "root { action [Other] }");
                const tree = new BehaviourTree(definition, agent, {});
                const snapshotBefore = tree.snapshot();

                assert.throws(() => tree.restore(snapshot), Error, "snapshot does not match the tree's definition");
                assert.deepEqual(tree.snapshot(), snapshotBefore);
            });

            it("rejects a snapshot from a tree that is a different definition, before checking the nodes", () => {
                const tree = new BehaviourTree("root { sequence { action [Work] action [Other] } }", agent, {});

                assert.throws(
                    () => tree.restore(createSnapshot("root { wait [100] }")),
                    Error,
                    "snapshot does not match the tree's definition"
                );
            });

            it("rejects a snapshot that has been given a definition from another tree", () => {
                const tree = new BehaviourTree("root { action [Work] }", agent, {});
                const snapshot = {
                    ...createSnapshot("root { action [Work] }"),
                    definition: createSnapshot(mdsl).definition
                };

                assert.throws(() => tree.restore(snapshot), Error, "snapshot does not match the tree's definition");
            });

            it("does not notify or change a running tree when it rejects a snapshot", () => {
                const changes: string[] = [];
                const tree = new BehaviourTree("root { sequence { action [Work] action [Other] } }", agent, {
                    onNodeStateChange: ({ type, state }) => changes.push(`${type}:${state}`)
                });
                tree.step();
                const changesBefore = [...changes];
                const snapshotBefore = tree.snapshot();

                assert.throws(
                    () => tree.restore(createSnapshot("root { sequence { action [Other] action [Work] } }")),
                    Error,
                    "snapshot does not match the tree's definition"
                );

                assert.deepEqual(changes, changesBefore);
                assert.deepEqual(tree.snapshot(), snapshotBefore);

                tree.step();

                assert.equal(tree.getState(), State.RUNNING);
            });

            const notSnapshots: [string, any][] = [
                ["undefined", undefined],
                ["null", null],
                ["a string", "snapshot"],
                ["a JSON string of a snapshot", JSON.stringify(createSnapshot("root { action [Work] }"))],
                ["a number", 1],
                ["a boolean", true],
                ["an array", []],
                ["an array of a snapshot", [createSnapshot("root { action [Work] }")]],
                ["a function", () => undefined],
                ["an empty object", {}],
                ["an object without the fields of a snapshot", { some: "object" }],
                ["an object with only a version", { version: 1 }],
                ["an object with only a root", { root: createSnapshot("root { action [Work] }").root }],
                [
                    "an object with a root and a version but no definition",
                    (() => {
                        const { version, root } = createSnapshot("root { action [Work] }");
                        return { version, root };
                    })()
                ],
                [
                    "an object with a definition that is not a string",
                    { ...createSnapshot("root { action [Work] }"), definition: 1 }
                ],
                ["an object with a null definition", { ...createSnapshot("root { action [Work] }"), definition: null }]
            ];

            notSnapshots.forEach(([description, value]) => {
                it(`rejects ${description} that is not a snapshot`, () => {
                    const tree = new BehaviourTree("root { action [Work] }", agent, {});
                    tree.step();
                    const snapshotBefore = tree.snapshot();
                    const detailsBefore = getDetailsWithoutIds(tree);

                    assert.throws(() => tree.restore(value), Error, "invalid snapshot");

                    assert.deepEqual(tree.snapshot(), snapshotBefore);
                    assert.deepEqual(getDetailsWithoutIds(tree), detailsBefore);
                });
            });
        });

        describe("restores a tree that had finished", () => {
            [State.SUCCEEDED, State.FAILED].forEach((result) => {
                it(`with a state of ${result} and starts a new run on the next step`, () => {
                    const calls: string[] = [];
                    const finishedAgent = {
                        Work: () => {
                            calls.push("Work");
                            return result;
                        }
                    };
                    const original = new BehaviourTree("root { sequence { action [Work] } }", finishedAgent, {});
                    original.step();

                    const restored = new BehaviourTree("root { sequence { action [Work] } }", finishedAgent, {});
                    restored.restore(roundTripSnapshot(original.snapshot()));

                    assert.equal(restored.getState(), result);
                    assert.isFalse(restored.isRunning());
                    assert.deepEqual(getDetailsWithoutIds(restored), getDetailsWithoutIds(original));
                    assert.deepEqual(calls, ["Work"]);

                    restored.step();

                    assert.deepEqual(calls, ["Work", "Work"]);
                    assert.equal(restored.getState(), result);
                });
            });
        });
    });

    describe("gives a snapshot that is independent of the tree, for a tree with", () => {
        const tickClock = (clock: sinon.SinonFakeTimers) => {
            clock.tick(100);
            return Promise.resolve().then(() => Promise.resolve());
        };

        const scenarios: [string, string, { [name: string]: () => any }][] = [
            [
                "repeat, wait and lotto nodes",
                "root { repeat [3] { sequence { wait [100, 300] lotto [1, 2] { action [Work] action [Finish] } } } }",
                { Work: () => State.RUNNING, Finish: () => State.SUCCEEDED }
            ],
            [
                "a retry node",
                "root { retry [3] { sequence { action [Work] action [Fail] } } }",
                { Work: () => State.SUCCEEDED, Fail: () => State.FAILED }
            ],
            [
                "parallel children that wait",
                "root { parallel { wait [250] action [Work] } }",
                { Work: () => State.RUNNING }
            ],
            [
                "an action with a promise that settles",
                "root { sequence { action [Settle] wait [300] action [Finish] } }",
                { Settle: () => Promise.resolve(State.SUCCEEDED), Finish: () => State.SUCCEEDED }
            ],
            [
                "an action with a promise that never settles",
                "root { sequence { action [Pending] action [Finish] } }",
                { Pending: () => new Promise(() => undefined), Finish: () => State.SUCCEEDED }
            ],
            [
                "an action with a promise that is rejected",
                "root { sequence { action [Reject] action [Finish] } }",
                { Reject: () => Promise.reject(new Error("some-error")), Finish: () => State.SUCCEEDED }
            ]
        ];

        scenarios.forEach(([description, definition, functions]) => {
            describe(description, () => {
                let clock: sinon.SinonFakeTimers;

                beforeEach(() => (clock = sinon.useFakeTimers()));
                afterEach(() => clock.restore());

                const createTree = () => new BehaviourTree(definition, { ...functions }, { random: () => 0.7 });

                const stepIgnoringErrors = async (tree: BehaviourTree) => {
                    try {
                        tree.step();
                    } catch (error) {
                        // A rejected promise is expected to throw when the tree is stepped.
                    }

                    await tickClock(clock);
                };

                for (let stepsBeforeSnapshot = 0; stepsBeforeSnapshot <= 6; stepsBeforeSnapshot++) {
                    it(`is not changed by stepping the tree or a tree it is restored to, when taken after ${stepsBeforeSnapshot} steps`, async () => {
                        const tree = createTree();

                        for (let step = 0; step < stepsBeforeSnapshot; step++) {
                            await stepIgnoringErrors(tree);
                        }

                        const snapshot = tree.snapshot();
                        const expected = JSON.parse(JSON.stringify(snapshot));

                        for (let step = 0; step < 6; step++) {
                            await stepIgnoringErrors(tree);

                            assert.deepEqual(snapshot, expected, `snapshot after stepping the tree ${step + 1} times`);
                        }

                        const restored = createTree();
                        restored.restore(snapshot);

                        for (let step = 0; step < 6; step++) {
                            await stepIgnoringErrors(restored);

                            assert.deepEqual(
                                snapshot,
                                expected,
                                `snapshot after stepping the restored tree ${step + 1} times`
                            );
                        }
                    });

                    it(`is equal to a snapshot taken straight after it is restored, when taken after ${stepsBeforeSnapshot} steps`, async () => {
                        const tree = createTree();

                        for (let step = 0; step < stepsBeforeSnapshot; step++) {
                            await stepIgnoringErrors(tree);
                        }

                        const snapshot = tree.snapshot();

                        // Restore into trees that are fresh and that have already been stepped.
                        const stepped = createTree();
                        await stepIgnoringErrors(stepped);

                        [createTree(), stepped].forEach((restored) => {
                            restored.restore(snapshot);

                            assert.deepEqual(
                                JSON.parse(JSON.stringify(restored.snapshot())),
                                JSON.parse(JSON.stringify(snapshot))
                            );
                        });
                    });
                }
            });
        });
    });

    describe("behaves exactly as the tree that a snapshot was taken from when restored, for a tree with", () => {
        it("a sequence node", () => {
            assertSnapshotRestoresAtEveryStep({
                definition: "root { sequence { action [A] action [B] action [C] } }",
                functions: { A: RUNNING_UNTIL(1), B: RUNNING_UNTIL(3), C: RUNNING_UNTIL(5) },
                steps: 7
            });
        });

        it("a sequence node with a failing child", () => {
            assertSnapshotRestoresAtEveryStep({
                definition: "root { sequence { action [A] action [B] action [C] } }",
                functions: { A: RUNNING_UNTIL(2), B: FAILING_UNTIL(4), C: RUNNING_UNTIL(5) },
                steps: 6
            });
        });

        it("a selector node", () => {
            assertSnapshotRestoresAtEveryStep({
                definition: "root { selector { action [A] action [B] action [C] } }",
                functions: { A: FAILING_UNTIL(1), B: FAILING_UNTIL(3), C: RUNNING_UNTIL(5) },
                steps: 7
            });
        });

        it("a parallel node", () => {
            assertSnapshotRestoresAtEveryStep({
                definition: "root { parallel { action [A] action [B] action [C] } }",
                functions: { A: RUNNING_UNTIL(2), B: RUNNING_UNTIL(4), C: RUNNING_UNTIL(3) },
                steps: 6
            });
            assertSnapshotRestoresAtEveryStep({
                definition: "root { parallel { action [A] action [B] action [C] } }",
                functions: { A: RUNNING_UNTIL(2), B: FAILING_UNTIL(4), C: RUNNING_UNTIL(6) },
                steps: 6
            });
        });

        it("a race node", () => {
            assertSnapshotRestoresAtEveryStep({
                definition: "root { race { action [A] action [B] action [C] } }",
                functions: { A: FAILING_UNTIL(2), B: RUNNING_UNTIL(4), C: RUNNING_UNTIL(6) },
                steps: 6
            });
            assertSnapshotRestoresAtEveryStep({
                definition: "root { race { action [A] action [B] } }",
                functions: { A: FAILING_UNTIL(2), B: FAILING_UNTIL(4) },
                steps: 6
            });
        });

        it("an all node", () => {
            assertSnapshotRestoresAtEveryStep({
                definition: "root { all { action [A] action [B] action [C] } }",
                functions: { A: FAILING_UNTIL(2), B: RUNNING_UNTIL(4), C: FAILING_UNTIL(3) },
                steps: 6
            });
        });

        it("flip, succeed and fail nodes", () => {
            assertSnapshotRestoresAtEveryStep({
                definition: `root {
                    sequence {
                        flip { action [A] }
                        succeed { action [B] }
                        selector {
                            fail { action [C] }
                            action [D]
                        }
                    }
                }`,
                functions: { A: FAILING_UNTIL(2), B: FAILING_UNTIL(3), C: RUNNING_UNTIL(4), D: RUNNING_UNTIL(6) },
                steps: 8
            });
        });

        it("condition nodes", () => {
            assertSnapshotRestoresAtEveryStep({
                definition: "root { sequence { condition [IsReady] action [A] condition [IsDone] } }",
                functions: { IsReady: () => true, A: RUNNING_UNTIL(3), IsDone: (tick) => tick > 4 },
                steps: 6
            });
        });

        it("branch nodes and nested trees", () => {
            assertSnapshotRestoresAtEveryStep({
                definition: `
                    root { sequence { branch [Work] branch [Work] } }
                    root [Work] { selector { action [A] sequence { action [B] action [C] } } }
                `,
                functions: { A: FAILING_UNTIL(1), B: RUNNING_UNTIL(2), C: RUNNING_UNTIL(4) },
                steps: 8
            });
        });

        it("entry, step and exit callbacks, calling them as the original tree would", () => {
            assertSnapshotRestoresAtEveryStep({
                definition: `root {
                    sequence entry(OnEntry, "sequence") exit(OnExit, "sequence") step(OnStep, "sequence") {
                        action [A] entry(OnEntry, "A") exit(OnExit, "A") step(OnStep, "A")
                        action [B] entry(OnEntry, "B") exit(OnExit, "B") step(OnStep, "B")
                    }
                }`,
                functions: {
                    A: RUNNING_UNTIL(2),
                    B: RUNNING_UNTIL(4),
                    OnEntry: () => undefined,
                    OnExit: () => undefined,
                    OnStep: () => undefined
                },
                steps: 6
            });
        });

        it("while and until guards, aborting nodes as the original tree would", () => {
            assertSnapshotRestoresAtEveryStep({
                definition: `root {
                    selector {
                        sequence while(IsAllowed) {
                            action [A] exit(OnExit, "A")
                            action [B]
                        }
                        sequence until(IsDone) {
                            action [C] exit(OnExit, "C")
                            action [D]
                        }
                    }
                }`,
                functions: {
                    IsAllowed: (tick) => tick < 3,
                    IsDone: (tick) => tick >= 5,
                    OnExit: () => undefined,
                    A: RUNNING_UNTIL(5),
                    B: RUNNING_UNTIL(5),
                    C: RUNNING_UNTIL(5),
                    D: RUNNING_UNTIL(5)
                },
                steps: 7
            });
        });

        it("a tree that runs to completion and is then stepped again to start a new run", () => {
            assertSnapshotRestoresAtEveryStep({
                definition: "root { sequence { action [A] action [B] } }",
                functions: {
                    A: (tick) => (tick % 3 === 0 ? State.SUCCEEDED : State.RUNNING),
                    B: () => State.SUCCEEDED
                },
                steps: 9
            });
        });
    });
});
