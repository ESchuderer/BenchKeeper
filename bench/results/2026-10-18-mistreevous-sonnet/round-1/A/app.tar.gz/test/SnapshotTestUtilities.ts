import { assert } from "chai";
import sinon from "sinon";

import { BehaviourTree, BehaviourTreeSnapshot, NodeDetails } from "../src/index";
import { RootNodeDefinition } from "../src/BehaviourTreeDefinition";

/**
 * The milliseconds that the fake clock moves forward by on every step of a scenario.
 */
const TICK_DURATION_MS = 100;

/**
 * A scripted agent function, called with the current tick of the scenario.
 */
type ScriptedFunction = (tick: number) => any;

/**
 * A scripted scenario that is run to completion once for each point at which a snapshot could be taken.
 */
export type SnapshotScenario = {
    /**
     * The tree definition.
     */
    definition: string | RootNodeDefinition | RootNodeDefinition[];
    /**
     * The agent functions, each returning a result based on the current tick. The first tick is 1.
     */
    functions: { [name: string]: ScriptedFunction };
    /**
     * The number of times the tree is stepped.
     */
    steps: number;
    /**
     * The values returned in turn by the 'random' option, which wrap around when exhausted.
     */
    random?: number[];
    /**
     * Whether the tree should use a 'getDeltaTime' option rather than the clock to track the duration of wait nodes.
     */
    useDeltaTime?: boolean;
};

/**
 * Get the details of a tree without the node identifiers, which are different for every tree instance.
 * @param tree The behaviour tree.
 * @returns The details of every node of the tree without identifiers.
 */
export function getDetailsWithoutIds(tree: BehaviourTree): any {
    const strip = ({ id, children, ...details }: NodeDetails): any => ({
        ...details,
        ...(children ? { children: children.map(strip) } : {})
    });

    return strip(tree.getTreeNodeDetails());
}

/**
 * Pass a snapshot through JSON serialisation, asserting that this did not change it.
 * @param snapshot The snapshot.
 * @returns The snapshot after being serialised and deserialised.
 */
export function roundTripSnapshot(snapshot: BehaviourTreeSnapshot): BehaviourTreeSnapshot {
    const roundTripped = JSON.parse(JSON.stringify(snapshot));

    assert.deepEqual(roundTripped, snapshot);

    return roundTripped;
}

/**
 * Recursively freeze an object.
 * @param value The object.
 * @returns The same object.
 */
export function deepFreeze<T>(value: T): T {
    if (typeof value === "object" && value !== null) {
        Object.values(value).forEach(deepFreeze);
        Object.freeze(value);
    }

    return value;
}

/**
 * Run a scenario once for each possible point at which a snapshot could be taken.
 * Each time the tree is stepped up to that point and a snapshot is taken, which is passed through JSON serialisation
 * and restored into a second tree built from the same definition. Both trees are then stepped in lockstep until the end
 * of the scenario, asserting that the node details, the agent functions called and any errors thrown are the same.
 * @param scenario The scenario.
 */
export function assertSnapshotRestoresAtEveryStep(scenario: SnapshotScenario): void {
    for (let snapshotStep = 0; snapshotStep <= scenario.steps; snapshotStep++) {
        const clock = sinon.useFakeTimers();

        try {
            runScenarioWithSnapshotAt(scenario, snapshotStep, () => clock.tick(TICK_DURATION_MS));
        } catch (error) {
            (error as Error).message = `[snapshot taken after ${snapshotStep} steps] ${(error as Error).message}`;
            throw error;
        } finally {
            clock.restore();
        }
    }
}

function runScenarioWithSnapshotAt(scenario: SnapshotScenario, snapshotStep: number, advanceClock: () => void) {
    let tick = 0;

    const createTree = (log: string[], randomOffset: number) => {
        const agent: { [name: string]: () => any } = {};

        Object.entries(scenario.functions).forEach(([name, func]) => {
            agent[name] = () => {
                log.push(name);
                return func(tick);
            };
        });

        let randomCalls = randomOffset;
        const random = () => {
            const values = scenario.random ?? [0.5];
            return values[randomCalls++ % values.length];
        };

        const tree = new BehaviourTree(scenario.definition, agent, {
            random,
            ...(scenario.useDeltaTime ? { getDeltaTime: () => TICK_DURATION_MS / 1000 } : {})
        });

        return { tree, getRandomCalls: () => randomCalls };
    };

    const stepTree = (tree: BehaviourTree): string | null => {
        try {
            tree.step();
            return null;
        } catch (error) {
            return (error as Error).message;
        }
    };

    const originalLog: string[] = [];
    const original = createTree(originalLog, 0);

    for (let step = 0; step < snapshotStep; step++) {
        tick++;
        advanceClock();
        assert.isNull(stepTree(original.tree));
    }

    const snapshot = roundTripSnapshot(original.tree.snapshot());

    const restoredLog: string[] = [];
    const restored = createTree(restoredLog, original.getRandomCalls());

    restored.tree.restore(deepFreeze(snapshot));

    assert.deepEqual(getDetailsWithoutIds(restored.tree), getDetailsWithoutIds(original.tree));
    assert.deepEqual(restored.tree.snapshot(), snapshot);

    const originalLogOffset = originalLog.length;

    for (let step = snapshotStep; step < scenario.steps; step++) {
        tick++;
        advanceClock();

        const originalError = stepTree(original.tree);
        const restoredError = stepTree(restored.tree);

        assert.equal(restoredError, originalError, `error thrown by step ${step + 1}`);
        assert.deepEqual(restoredLog, originalLog.slice(originalLogOffset), `agent calls up to step ${step + 1}`);
        assert.deepEqual(
            getDetailsWithoutIds(restored.tree),
            getDetailsWithoutIds(original.tree),
            `node details after step ${step + 1}`
        );
        assert.deepEqual(restored.tree.snapshot(), original.tree.snapshot(), `snapshot after step ${step + 1}`);
        assert.equal(restored.getRandomCalls(), original.getRandomCalls(), `random calls up to step ${step + 1}`);
    }
}

/**
 * Find the snapshot of the first node of the specified type in a tree snapshot, or error if there isn't one.
 * @param snapshot The tree snapshot.
 * @param type The node type.
 * @returns The snapshot of the first node of the specified type.
 */
export function findNodeSnapshot(snapshot: BehaviourTreeSnapshot, type: string): any {
    const find = (node: any): any =>
        node.type === type ? node : (node.children ?? []).map(find).find((child: any) => !!child);

    const found = find(snapshot.root);

    if (!found) {
        throw new Error(`cannot find node snapshot with type '${type}'`);
    }

    return found;
}
