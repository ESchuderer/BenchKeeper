import { assert } from "chai";

import { BehaviourTree, State } from "../../../src/index";
import { RootNodeDefinition } from "../../../src/BehaviourTreeDefinition";

import { findNode } from "../../TestUtilities";
import { assertSnapshotRestoresAtEveryStep, findNodeSnapshot, roundTripSnapshot } from "../../SnapshotTestUtilities";

describe("A Lotto node", () => {
    describe("on tree initialisation", () => {
        describe("will error if the node does not have at least one child", () => {
            it("(MDSL)", () => {
                const definition = "root { lotto {} }";
                assert.throws(
                    () => new BehaviourTree(definition, {}),
                    Error,
                    "invalid definition: a lotto node must have at least a single child"
                );
            });

            it("(JSON)", () => {
                const definition: RootNodeDefinition = {
                    type: "root",
                    child: {
                        type: "lotto",
                        children: []
                    }
                };
                assert.throws(
                    () => new BehaviourTree(definition, {}),
                    Error,
                    "invalid definition: expected non-empty 'children' array to be defined for lotto node at depth '1'"
                );
            });
        });

        describe("will error if any optional weights are defined and", () => {
            describe("are not positive integer values", () => {
                it("(MDSL)", () => {
                    let definition = "root { lotto [-1] { action [SomeAction] } }";
                    assert.throws(
                        () => new BehaviourTree(definition, {}),
                        Error,
                        "invalid definition: lotto node weight arguments must be positive integer values"
                    );

                    definition = "root { lotto [1.234] { action [SomeAction] } }";
                    assert.throws(
                        () => new BehaviourTree(definition, {}),
                        Error,
                        "invalid definition: lotto node weight arguments must be positive integer values"
                    );

                    definition = 'root { lotto ["some-string"] { action [SomeAction] } }';
                    assert.throws(
                        () => new BehaviourTree(definition, {}),
                        Error,
                        "invalid definition: lotto node weight arguments must be positive integer values"
                    );

                    definition = "root { lotto [false] { action [SomeAction] } }";
                    assert.throws(
                        () => new BehaviourTree(definition, {}),
                        Error,
                        "invalid definition: lotto node weight arguments must be positive integer values"
                    );
                });

                it("(JSON)", () => {
                    let definition: RootNodeDefinition = {
                        type: "root",
                        child: {
                            type: "lotto",
                            weights: [-1],
                            children: [
                                {
                                    type: "action",
                                    call: "SomeAction"
                                }
                            ]
                        }
                    };
                    assert.throws(
                        () => new BehaviourTree(definition, {}),
                        Error,
                        "invalid definition: expected an array of positive integer weight values with a length matching the number of child nodes for 'weights' property if defined for lotto node at depth '1'"
                    );

                    definition = {
                        type: "root",
                        child: {
                            type: "lotto",
                            weights: [1.234],
                            children: [
                                {
                                    type: "action",
                                    call: "SomeAction"
                                }
                            ]
                        }
                    };
                    assert.throws(
                        () => new BehaviourTree(definition, {}),
                        Error,
                        "invalid definition: expected an array of positive integer weight values with a length matching the number of child nodes for 'weights' property if defined for lotto node at depth '1'"
                    );

                    definition = {
                        type: "root",
                        child: {
                            type: "lotto",
                            weights: ["some-string"],
                            children: [
                                {
                                    type: "action",
                                    call: "SomeAction"
                                }
                            ]
                        }
                    } as any;
                    assert.throws(
                        () => new BehaviourTree(definition, {}),
                        Error,
                        "invalid definition: expected an array of positive integer weight values with a length matching the number of child nodes for 'weights' property if defined for lotto node at depth '1'"
                    );

                    definition = {
                        type: "root",
                        child: {
                            type: "lotto",
                            weights: [false],
                            children: [
                                {
                                    type: "action",
                                    call: "SomeAction"
                                }
                            ]
                        }
                    } as any;
                    assert.throws(
                        () => new BehaviourTree(definition, {}),
                        Error,
                        "invalid definition: expected an array of positive integer weight values with a length matching the number of child nodes for 'weights' property if defined for lotto node at depth '1'"
                    );
                });
            });

            describe("the number of weights does not match the number of child nodes", () => {
                it("(MDSL)", () => {
                    const definition = "root { lotto [1] { action [SomeAction] action [SomeOtherAction] } }";
                    assert.throws(
                        () => new BehaviourTree(definition, {}),
                        Error,
                        "invalid definition: expected a number of weight arguments matching the number of child nodes for lotto node"
                    );
                });

                it("(JSON)", () => {
                    const definition: RootNodeDefinition = {
                        type: "root",
                        child: {
                            type: "lotto",
                            weights: [1],
                            children: [
                                {
                                    type: "action",
                                    call: "SomeAction"
                                },
                                {
                                    type: "action",
                                    call: "SomeOtherAction"
                                }
                            ]
                        }
                    };
                    assert.throws(
                        () => new BehaviourTree(definition, {}),
                        Error,
                        "invalid definition: expected an array of positive integer weight values with a length matching the number of child nodes for 'weights' property if defined for lotto node at depth '1'"
                    );
                });
            });
        });
    });

    describe("when updated as part of a tree step will", () => {
        describe("when initially in the READY state will select a child node at random to be the single active child node", () => {
            it("(MDSL)", () => {
                const definition = "root { lotto { condition [IsTrue] } }";
                const agent = { IsTrue: () => true };
                const tree = new BehaviourTree(definition, agent);

                let lottoNode = findNode(tree, "lotto");
                let childNode = findNode(tree, "condition");
                assert.strictEqual(lottoNode.state, State.READY);
                assert.strictEqual(childNode.state, State.READY);

                tree.step();

                lottoNode = findNode(tree, "lotto");
                childNode = findNode(tree, "condition");
                assert.strictEqual(lottoNode.state, State.SUCCEEDED);
                assert.strictEqual(childNode.state, State.SUCCEEDED);
            });

            it("(JSON)", () => {
                const definition: RootNodeDefinition = {
                    type: "root",
                    child: {
                        type: "lotto",
                        children: [
                            {
                                type: "condition",
                                call: "IsTrue"
                            }
                        ]
                    }
                };
                const agent = { IsTrue: () => true };
                const tree = new BehaviourTree(definition, agent);

                let lottoNode = findNode(tree, "lotto");
                let childNode = findNode(tree, "condition");
                assert.strictEqual(lottoNode.state, State.READY);
                assert.strictEqual(childNode.state, State.READY);

                tree.step();

                lottoNode = findNode(tree, "lotto");
                childNode = findNode(tree, "condition");
                assert.strictEqual(lottoNode.state, State.SUCCEEDED);
                assert.strictEqual(childNode.state, State.SUCCEEDED);
            });
        });

        describe("will use the 'random' function to select the single active child if it was defined as a behaviour tree option", () => {
            it("(MDSL)", () => {
                const definition =
                    "root { lotto { condition [IsFalse] condition [IsFalse] condition [IsFalse] condition [IsTrue] condition [IsFalse] condition [IsFalse] } }";
                const agent = {
                    IsTrue: () => true,
                    IsFalse: () => false
                };
                const options = {
                    // Usually this would return a new pseudo-random number each time, but for the sake of this test we
                    // just want to make sure that the number we return actually has an impact on which child node of the
                    // lotto node is selected. A value of 0.6 should always result in the fourth child out of six being picked.
                    random: () => 0.6
                };
                const tree = new BehaviourTree(definition, agent, options);

                let lottoNode = findNode(tree, "lotto");
                assert.strictEqual(lottoNode.state, State.READY);

                tree.step();

                // Check that the lotto node has moved into the SUCCEEDED state. This would only
                // have happened if the fourth condition node was selected by the lotto node.
                lottoNode = findNode(tree, "lotto");
                assert.strictEqual(lottoNode.state, State.SUCCEEDED);
            });

            it("(JSON)", () => {
                const definition: RootNodeDefinition = {
                    type: "root",
                    child: {
                        type: "lotto",
                        children: [
                            {
                                type: "condition",
                                call: "IsFalse"
                            },
                            {
                                type: "condition",
                                call: "IsFalse"
                            },
                            {
                                type: "condition",
                                call: "IsFalse"
                            },
                            {
                                type: "condition",
                                call: "IsTrue"
                            },
                            {
                                type: "condition",
                                call: "IsFalse"
                            },
                            {
                                type: "condition",
                                call: "IsFalse"
                            }
                        ]
                    }
                };
                const agent = {
                    IsTrue: () => true,
                    IsFalse: () => false
                };
                const options = {
                    // Usually this would return a new pseudo-random number each time, but for the sake of this test we
                    // just want to make sure that the number we return actually has an impact on which child node of the
                    // lotto node is selected. A value of 0.6 should always result in the fourth child out of six being picked.
                    random: () => 0.6
                };
                const tree = new BehaviourTree(definition, agent, options);

                let lottoNode = findNode(tree, "lotto");
                assert.strictEqual(lottoNode.state, State.READY);

                tree.step();

                // Check that the lotto node has moved into the SUCCEEDED state. This would only
                // have happened if the fourth condition node was selected by the lotto node.
                lottoNode = findNode(tree, "lotto");
                assert.strictEqual(lottoNode.state, State.SUCCEEDED);
            });
        });

        it("can optionally have weights defined and will use them to influence the selection of the single active child", () => {
            // TODO Need to figure out how to spy on createLotto as there is no other way to test this.
        });

        describe("move to the SUCCESS state if the selected child node moves to the SUCCESS state", () => {
            it("(MDSL)", () => {
                const definition = "root { lotto { condition [IsTrue] } }";
                const agent = { IsTrue: () => true };
                const tree = new BehaviourTree(definition, agent);

                let lottoNode = findNode(tree, "lotto");
                let childNode = findNode(tree, "condition");
                assert.strictEqual(lottoNode.state, State.READY);
                assert.strictEqual(childNode.state, State.READY);

                tree.step();

                lottoNode = findNode(tree, "lotto");
                childNode = findNode(tree, "condition");
                assert.strictEqual(lottoNode.state, State.SUCCEEDED);
                assert.strictEqual(childNode.state, State.SUCCEEDED);
            });

            it("(JSON)", () => {
                const definition: RootNodeDefinition = {
                    type: "root",
                    child: {
                        type: "lotto",
                        children: [
                            {
                                type: "condition",
                                call: "IsTrue"
                            }
                        ]
                    }
                };
                const agent = { IsTrue: () => true };
                const tree = new BehaviourTree(definition, agent);

                let lottoNode = findNode(tree, "lotto");
                let childNode = findNode(tree, "condition");
                assert.strictEqual(lottoNode.state, State.READY);
                assert.strictEqual(childNode.state, State.READY);

                tree.step();

                lottoNode = findNode(tree, "lotto");
                childNode = findNode(tree, "condition");
                assert.strictEqual(lottoNode.state, State.SUCCEEDED);
                assert.strictEqual(childNode.state, State.SUCCEEDED);
            });
        });

        describe("move to the FAILED state if the selected child node moves to the FAILED state", () => {
            it("(MDSL)", () => {
                const definition = "root { lotto { condition [IsFalse] } }";
                const agent = { IsFalse: () => false };
                const tree = new BehaviourTree(definition, agent);

                let lottoNode = findNode(tree, "lotto");
                let childNode = findNode(tree, "condition");
                assert.strictEqual(lottoNode.state, State.READY);
                assert.strictEqual(childNode.state, State.READY);

                tree.step();

                lottoNode = findNode(tree, "lotto");
                childNode = findNode(tree, "condition");
                assert.strictEqual(lottoNode.state, State.FAILED);
                assert.strictEqual(childNode.state, State.FAILED);
            });

            it("(JSON)", () => {
                const definition: RootNodeDefinition = {
                    type: "root",
                    child: {
                        type: "lotto",
                        children: [
                            {
                                type: "condition",
                                call: "IsFalse"
                            }
                        ]
                    }
                };
                const agent = { IsFalse: () => false };
                const tree = new BehaviourTree(definition, agent);

                let lottoNode = findNode(tree, "lotto");
                let childNode = findNode(tree, "condition");
                assert.strictEqual(lottoNode.state, State.READY);
                assert.strictEqual(childNode.state, State.READY);

                tree.step();

                lottoNode = findNode(tree, "lotto");
                childNode = findNode(tree, "condition");
                assert.strictEqual(lottoNode.state, State.FAILED);
                assert.strictEqual(childNode.state, State.FAILED);
            });
        });

        describe("move to the RUNNING state if the selected child node is in the RUNNING state", () => {
            it("(MDSL)", () => {
                const definition = "root { lotto { action [someAction] } }";
                const agent = { someAction: () => State.RUNNING };
                const tree = new BehaviourTree(definition, agent);

                let lottoNode = findNode(tree, "lotto");
                let actionNode = findNode(tree, "action");
                assert.strictEqual(lottoNode.state, State.READY);
                assert.strictEqual(actionNode.state, State.READY);

                tree.step();

                lottoNode = findNode(tree, "lotto");
                actionNode = findNode(tree, "action");
                assert.strictEqual(lottoNode.state, State.RUNNING);
                assert.strictEqual(actionNode.state, State.RUNNING);
            });

            it("(JSON)", () => {
                const definition: RootNodeDefinition = {
                    type: "root",
                    child: {
                        type: "lotto",
                        children: [
                            {
                                type: "action",
                                call: "someAction"
                            }
                        ]
                    }
                };
                const agent = { someAction: () => State.RUNNING };
                const tree = new BehaviourTree(definition, agent);

                let lottoNode = findNode(tree, "lotto");
                let actionNode = findNode(tree, "action");
                assert.strictEqual(lottoNode.state, State.READY);
                assert.strictEqual(actionNode.state, State.READY);

                tree.step();

                lottoNode = findNode(tree, "lotto");
                actionNode = findNode(tree, "action");
                assert.strictEqual(lottoNode.state, State.RUNNING);
                assert.strictEqual(actionNode.state, State.RUNNING);
            });
        });
    });

    describe("when a snapshot of the tree is restored", () => {
        const definition = "root { lotto { action [A] action [B] action [C] } }";

        const createAgent = (calls: string[], results: { [name: string]: State | undefined }) => {
            const agent: { [name: string]: () => State | undefined } = {};

            ["A", "B", "C"].forEach((name) => {
                agent[name] = () => {
                    calls.push(name);
                    return results[name];
                };
            });

            return agent;
        };

        it("keeps the child that was selected rather than selecting another", () => {
            [0, 0.5, 0.99].forEach((randomValue) => {
                let randomCalls = 0;
                const options = {
                    random: () => {
                        randomCalls++;
                        return randomValue;
                    }
                };
                const calls: string[] = [];
                const agent = createAgent(calls, { A: undefined, B: undefined, C: undefined });

                const original = new BehaviourTree(definition, agent, options);
                original.step();
                assert.equal(randomCalls, 1);
                assert.lengthOf(calls, 1);

                const snapshot = roundTripSnapshot(original.snapshot());
                assert.strictEqual(
                    findNodeSnapshot(snapshot, "lotto").selectedChild,
                    ["A", "B", "C"].indexOf(calls[0])
                );

                const restoredCalls: string[] = [];
                const restored = new BehaviourTree(definition, createAgent(restoredCalls, {}), {
                    ...options,
                    random: () => {
                        throw new Error("a restored lotto node should not draw again");
                    }
                });
                restored.restore(snapshot);
                restored.step();
                restored.step();

                assert.deepEqual(restoredCalls, [calls[0], calls[0]]);
                assert.equal(restored.getState(), State.RUNNING);
            });
        });

        it("keeps the resolved state of the selected child and draws again when a new run starts", () => {
            const randomValues = [0, 0.99];
            let randomCalls = 0;
            const options = { random: () => randomValues[randomCalls++] };
            const calls: string[] = [];
            const results = { A: State.SUCCEEDED, B: State.SUCCEEDED, C: State.SUCCEEDED };

            const original = new BehaviourTree(definition, createAgent(calls, results), options);
            original.step();
            assert.equal(original.getState(), State.SUCCEEDED);
            const firstSelection = calls[0];

            const restoredCalls: string[] = [];
            const restored = new BehaviourTree(definition, createAgent(restoredCalls, results), options);
            restored.restore(roundTripSnapshot(original.snapshot()));

            assert.equal(restored.getState(), State.SUCCEEDED);
            assert.deepEqual(restoredCalls, []);
            assert.equal(randomCalls, 1);

            restored.step();

            assert.equal(randomCalls, 2);
            assert.lengthOf(restoredCalls, 1);
            assert.notEqual(restoredCalls[0], firstSelection);
        });

        it("behaves as the original tree would", () => {
            assertSnapshotRestoresAtEveryStep({
                definition,
                functions: {
                    A: (tick: number) => (tick < 3 ? State.RUNNING : State.SUCCEEDED),
                    B: (tick: number) => (tick < 4 ? State.RUNNING : State.FAILED),
                    C: (tick: number) => (tick < 2 ? State.RUNNING : State.SUCCEEDED)
                },
                random: [0, 0.5, 0.99],
                steps: 14
            });
        });

        it("behaves as the original tree would when it has weights and is nested within a node that repeats it", () => {
            assertSnapshotRestoresAtEveryStep({
                definition: `root {
                    repeat [4] {
                        sequence {
                            lotto [1, 3, 5] {
                                action [A]
                                sequence { action [B] action [C] }
                                action [C]
                            }
                            action [B]
                        }
                    }
                }`,
                functions: {
                    A: (tick: number) => (tick % 2 === 0 ? State.SUCCEEDED : State.RUNNING),
                    B: (tick: number) => (tick % 3 === 0 ? State.SUCCEEDED : State.RUNNING),
                    C: () => State.SUCCEEDED
                },
                random: [0.1, 0.9, 0.5, 0.3, 0.99, 0, 0.7],
                steps: 30
            });
        });

        describe("will error and leave the tree unchanged if the snapshot node has", () => {
            const invalidValues: [string, any][] = [
                ["a selected child that is not an integer", 0.5],
                ["a selected child that is negative", -1],
                ["a selected child that is not an index of a child", 3],
                ["a selected child that is a string", "0"],
                ["a selected child that is undefined", undefined]
            ];

            invalidValues.forEach(([description, value]) => {
                it(description, () => {
                    const tree = new BehaviourTree(definition, createAgent([], {}), {});
                    const snapshotBefore = tree.snapshot();
                    const snapshot = JSON.parse(JSON.stringify(snapshotBefore));
                    snapshot.root.children[0].selectedChild = value;

                    assert.throws(
                        () => tree.restore(snapshot),
                        Error,
                        "invalid snapshot: expected 'selectedChild' to be the index of a child or null at 'root > lotto'"
                    );

                    assert.deepEqual(tree.snapshot(), snapshotBefore);
                });
            });

            it("no selected child while it is in the RUNNING state", () => {
                const tree = new BehaviourTree(definition, createAgent([], {}), {});
                const snapshotBefore = tree.snapshot();
                const snapshot = JSON.parse(JSON.stringify(snapshotBefore));
                snapshot.root.children[0].state = State.RUNNING;

                assert.throws(
                    () => tree.restore(snapshot),
                    Error,
                    "invalid snapshot: expected 'selectedChild' to be the index of a child at 'root > lotto' as the node is running"
                );

                assert.deepEqual(tree.snapshot(), snapshotBefore);
            });
        });

        it("will restore a node that resolved without selecting a child, as when a guard failed before the first update", () => {
            const guardedDefinition = "root { lotto while(IsAllowed) { action [A] action [B] } }";
            const original = new BehaviourTree(
                guardedDefinition,
                { IsAllowed: () => false, A: () => State.RUNNING, B: () => State.RUNNING },
                {}
            );
            original.step();
            assert.equal(findNode(original, "lotto").state, State.FAILED);

            const snapshot = roundTripSnapshot(original.snapshot());
            assert.strictEqual(findNodeSnapshot(snapshot, "lotto").selectedChild, null);

            const restored = new BehaviourTree(
                guardedDefinition,
                { IsAllowed: () => false, A: () => State.RUNNING, B: () => State.RUNNING },
                {}
            );
            restored.restore(snapshot);

            assert.equal(findNode(restored, "lotto").state, State.FAILED);
        });
    });
});
