import { assert } from "chai";
import sinon, { SinonSandbox } from "sinon";

import { BehaviourTree, State } from "../../../src/index";
import { RootNodeDefinition } from "../../../src/BehaviourTreeDefinition";
import { Agent } from "../../../src/Agent";

import { findNode } from "../../TestUtilities";
import { assertSnapshotRestoresAtEveryStep, findNodeSnapshot, roundTripSnapshot } from "../../SnapshotTestUtilities";

describe("A Repeat node", () => {
    describe("on tree initialisation", () => {
        describe("will error if", () => {
            describe("the node does not have a single child", () => {
                it("(MDSL)", () => {
                    const definition = "root { repeat {} }";
                    assert.throws(
                        () => new BehaviourTree(definition, {}),
                        Error,
                        "invalid definition: a repeat node must have a single child node defined"
                    );
                });

                it("(JSON)", () => {
                    const definition = {
                        type: "root",
                        child: {
                            type: "repeat"
                        }
                    } as any;
                    assert.throws(
                        () => new BehaviourTree(definition, {}),
                        Error,
                        "invalid definition: expected property 'child' to be defined for repeat node at depth '1'"
                    );
                });
            });

            describe("the defined node arguments are not integers", () => {
                it("(MDSL)", () => {
                    const definition = "root { repeat ['not', 'integers'] { condition [someCondition] } }";
                    assert.throws(
                        () => new BehaviourTree(definition, {}),
                        Error,
                        "invalid definition: repeat node iteration counts must be integer values"
                    );
                });

                it("(JSON)", () => {
                    const definition = {
                        type: "root",
                        child: {
                            type: "repeat",
                            iterations: ["not", "integers"],
                            child: {
                                type: "condition",
                                call: "someCondition"
                            }
                        }
                    } as any;
                    assert.throws(
                        () => new BehaviourTree(definition, {}),
                        Error,
                        "invalid definition: expected array containing two integer values for 'iterations' property if defined for repeat node at depth '1'"
                    );
                });
            });

            describe("a negative iteration count node argument was defined", () => {
                it("(MDSL)", () => {
                    const definition = "root { repeat [-1] { condition [someCondition] } }";
                    assert.throws(
                        () => new BehaviourTree(definition, {}),
                        Error,
                        "invalid definition: a repeat node must have a positive number of iterations if defined"
                    );
                });

                it("(JSON)", () => {
                    const definition = {
                        type: "root",
                        child: {
                            type: "repeat",
                            iterations: -1,
                            child: {
                                type: "condition",
                                call: "someCondition"
                            }
                        }
                    } as any;
                    assert.throws(
                        () => new BehaviourTree(definition, {}),
                        Error,
                        "invalid definition: expected positive iterations count for 'iterations' property if defined for repeat node at depth '1'"
                    );
                });
            });

            describe("more than two node arguments are defined", () => {
                it("(MDSL)", () => {
                    const definition = "root { repeat [0, 10, 20] { condition [someCondition] } }";
                    assert.throws(
                        () => new BehaviourTree(definition, {}),
                        Error,
                        "invalid definition: invalid number of repeat node iteration count arguments defined"
                    );
                });

                it("(JSON)", () => {
                    const definition = {
                        type: "root",
                        child: {
                            type: "repeat",
                            iterations: [0, 10, 20],
                            child: {
                                type: "condition",
                                call: "someCondition"
                            }
                        }
                    } as any;
                    assert.throws(
                        () => new BehaviourTree(definition, {}),
                        Error,
                        "invalid definition: expected array containing two integer values for 'iterations' property if defined for repeat node at depth '1'"
                    );
                });
            });

            describe("a minimum iteration count node argument is defined that is greater than the maximum iteration count node argument", () => {
                it("(MDSL)", () => {
                    const definition = "root { repeat [10, 5] { condition [someCondition] } }";
                    assert.throws(
                        () => new BehaviourTree(definition, {}),
                        Error,
                        "invalid definition: a repeat node must not have a minimum iteration count that exceeds the maximum iteration count"
                    );
                });

                it("(JSON)", () => {
                    const definition = {
                        type: "root",
                        child: {
                            type: "repeat",
                            iterations: [10, 5],
                            child: {
                                type: "condition",
                                call: "someCondition"
                            }
                        }
                    } as any;
                    assert.throws(
                        () => new BehaviourTree(definition, {}),
                        Error,
                        "invalid definition: expected minimum iterations count that does not exceed the maximum iterations count for 'iterations' property if defined for repeat node at depth '1'"
                    );
                });
            });
        });
    });

    describe("when updated as part of a tree step", () => {
        let sandbox: SinonSandbox;

        beforeEach(() => {
            sandbox = sinon.createSandbox();
            sandbox.replace(globalThis.Math, "random", () => 0.5);
        });

        afterEach(() => sandbox.restore());

        describe("will move to the FAILED state if the child node moves to the FAILED state", () => {
            it("(MDSL)", () => {
                const definition = "root { repeat { condition [someCondition] } }";
                const agent = { someCondition: () => false };
                const tree = new BehaviourTree(definition, agent);

                let node = findNode(tree, "repeat", "REPEAT");
                assert.exists(node);
                assert.strictEqual(node.state, State.READY);

                tree.step();

                node = findNode(tree, "repeat", "REPEAT");
                assert.strictEqual(node.state, State.FAILED);
            });

            it("(JSON)", () => {
                const definition: RootNodeDefinition = {
                    type: "root",
                    child: {
                        type: "repeat",
                        child: {
                            type: "condition",
                            call: "someCondition"
                        }
                    }
                };
                const agent = { someCondition: () => false };
                const tree = new BehaviourTree(definition, agent);

                let node = findNode(tree, "repeat", "REPEAT");
                assert.exists(node);
                assert.strictEqual(node.state, State.READY);

                tree.step();

                node = findNode(tree, "repeat", "REPEAT");
                assert.strictEqual(node.state, State.FAILED);
            });
        });

        describe("will move to the RUNNING state if the child node moves to the SUCCEEDED state", () => {
            it("(MDSL)", () => {
                const definition = "root { repeat { condition [someCondition] } }";
                const agent = { someCondition: () => true };
                const tree = new BehaviourTree(definition, agent);

                let node = findNode(tree, "repeat", "REPEAT");
                assert.exists(node);
                assert.strictEqual(node.state, State.READY);

                tree.step();

                node = findNode(tree, "repeat", "REPEAT");
                assert.strictEqual(node.state, State.RUNNING);
            });

            it("(JSON)", () => {
                const definition: RootNodeDefinition = {
                    type: "root",
                    child: {
                        type: "repeat",
                        child: {
                            type: "condition",
                            call: "someCondition"
                        }
                    }
                };
                const agent = { someCondition: () => true };
                const tree = new BehaviourTree(definition, agent);

                let node = findNode(tree, "repeat", "REPEAT");
                assert.exists(node);
                assert.strictEqual(node.state, State.READY);

                tree.step();

                node = findNode(tree, "repeat", "REPEAT");
                assert.strictEqual(node.state, State.RUNNING);
            });
        });

        describe("and an iteration count node argument is defined will attempt to re-run the child node until the iteration count is reached", () => {
            it("(MDSL)", () => {
                const definition = "root { repeat [3] { condition [someCondition] } }";
                const agent = { someCondition: () => true };
                const tree = new BehaviourTree(definition, agent);

                let node = findNode(tree, "repeat", "REPEAT 3x");
                assert.exists(node);
                assert.strictEqual(node.state, State.READY);

                tree.step();

                node = findNode(tree, "repeat", "REPEAT 3x");
                assert.strictEqual(node.state, State.RUNNING);

                tree.step();

                node = findNode(tree, "repeat", "REPEAT 3x");
                assert.strictEqual(node.state, State.RUNNING);

                tree.step();

                node = findNode(tree, "repeat", "REPEAT 3x");
                assert.strictEqual(node.state, State.RUNNING);

                tree.step();

                node = findNode(tree, "repeat", "REPEAT 3x");
                assert.strictEqual(node.state, State.SUCCEEDED);
            });

            it("(JSON)", () => {
                const definition: RootNodeDefinition = {
                    type: "root",
                    child: {
                        type: "repeat",
                        iterations: 3,
                        child: {
                            type: "condition",
                            call: "someCondition"
                        }
                    }
                };
                const agent = { someCondition: () => true };
                const tree = new BehaviourTree(definition, agent);

                let node = findNode(tree, "repeat", "REPEAT 3x");
                assert.exists(node);
                assert.strictEqual(node.state, State.READY);

                tree.step();

                node = findNode(tree, "repeat", "REPEAT 3x");
                assert.strictEqual(node.state, State.RUNNING);

                tree.step();

                node = findNode(tree, "repeat", "REPEAT 3x");
                assert.strictEqual(node.state, State.RUNNING);

                tree.step();

                node = findNode(tree, "repeat", "REPEAT 3x");
                assert.strictEqual(node.state, State.RUNNING);

                tree.step();

                node = findNode(tree, "repeat", "REPEAT 3x");
                assert.strictEqual(node.state, State.SUCCEEDED);
            });
        });

        describe("and minumum and maximum iteration count node arguments are defined", () => {
            describe("and if the 'random' behaviour tree option is not defined will pick an iteration count from between the minimum and maximum bounds using Math.random", () => {
                it("(MDSL)", () => {
                    // We have spied on Math.random to always return 0.5 for the sake of this test, so our iteration count should always be 4.
                    const definition = "root { repeat [2, 6] { condition [someCondition] } }";
                    const agent = { someCondition: () => true };
                    const tree = new BehaviourTree(definition, agent);

                    let node = findNode(tree, "repeat", "REPEAT 2x-6x");
                    assert.exists(node);
                    assert.strictEqual(node.state, State.READY);

                    tree.step();

                    node = findNode(tree, "repeat", "REPEAT 2x-6x");
                    assert.strictEqual(node.state, State.RUNNING);

                    tree.step();

                    node = findNode(tree, "repeat", "REPEAT 2x-6x");
                    assert.strictEqual(node.state, State.RUNNING);

                    tree.step();

                    node = findNode(tree, "repeat", "REPEAT 2x-6x");
                    assert.strictEqual(node.state, State.RUNNING);

                    tree.step();

                    node = findNode(tree, "repeat", "REPEAT 2x-6x");
                    assert.strictEqual(node.state, State.RUNNING);

                    tree.step();

                    node = findNode(tree, "repeat", "REPEAT 2x-6x");
                    assert.strictEqual(node.state, State.SUCCEEDED);
                });

                it("(JSON)", () => {
                    // We have spied on Math.random to always return 0.5 for the sake of this test, so our iteration count should always be 4.
                    const definition: RootNodeDefinition = {
                        type: "root",
                        child: {
                            type: "repeat",
                            iterations: [2, 6],
                            child: {
                                type: "condition",
                                call: "someCondition"
                            }
                        }
                    };
                    const agent = { someCondition: () => true };
                    const tree = new BehaviourTree(definition, agent);

                    let node = findNode(tree, "repeat", "REPEAT 2x-6x");
                    assert.exists(node);
                    assert.strictEqual(node.state, State.READY);

                    tree.step();

                    node = findNode(tree, "repeat", "REPEAT 2x-6x");
                    assert.strictEqual(node.state, State.RUNNING);

                    tree.step();

                    node = findNode(tree, "repeat", "REPEAT 2x-6x");
                    assert.strictEqual(node.state, State.RUNNING);

                    tree.step();

                    node = findNode(tree, "repeat", "REPEAT 2x-6x");
                    assert.strictEqual(node.state, State.RUNNING);

                    tree.step();

                    node = findNode(tree, "repeat", "REPEAT 2x-6x");
                    assert.strictEqual(node.state, State.RUNNING);

                    tree.step();

                    node = findNode(tree, "repeat", "REPEAT 2x-6x");
                    assert.strictEqual(node.state, State.SUCCEEDED);
                });
            });

            describe("and if the 'random' behaviour tree option is defined will use it to pick an iteration count from between the minimum and maximum bounds", () => {
                it("(MDSL)", () => {
                    const definition = "root { repeat [2, 10] { condition [someCondition] } }";
                    const agent = { someCondition: () => true };
                    const options = {
                        // Usually this would return a new pseudo-random number each time, but for the sake of this test we
                        // just want to make sure that the number we return actually has an impact on the iteration count picked.
                        // A value of 0.2 should always result in an iteration count of 3.
                        random: () => 0.2
                    };
                    const tree = new BehaviourTree(definition, agent, options);

                    let node = findNode(tree, "repeat", "REPEAT 2x-10x");
                    assert.exists(node);
                    assert.strictEqual(node.state, State.READY);

                    tree.step();

                    node = findNode(tree, "repeat", "REPEAT 2x-10x");
                    assert.strictEqual(node.state, State.RUNNING);

                    tree.step();

                    node = findNode(tree, "repeat", "REPEAT 2x-10x");
                    assert.strictEqual(node.state, State.RUNNING);

                    tree.step();

                    node = findNode(tree, "repeat", "REPEAT 2x-10x");
                    assert.strictEqual(node.state, State.RUNNING);

                    tree.step();

                    node = findNode(tree, "repeat", "REPEAT 2x-10x");
                    assert.strictEqual(node.state, State.SUCCEEDED);
                });

                it("(JSON)", () => {
                    const definition: RootNodeDefinition = {
                        type: "root",
                        child: {
                            type: "repeat",
                            iterations: [2, 10],
                            child: {
                                type: "condition",
                                call: "someCondition"
                            }
                        }
                    };
                    const agent = { someCondition: () => true };
                    const options = {
                        // Usually this would return a new pseudo-random number each time, but for the sake of this test we
                        // just want to make sure that the number we return actually has an impact on the iteration count picked.
                        // A value of 0.2 should always result in an iteration count of 3.
                        random: () => 0.2
                    };
                    const tree = new BehaviourTree(definition, agent, options);

                    let node = findNode(tree, "repeat", "REPEAT 2x-10x");
                    assert.exists(node);
                    assert.strictEqual(node.state, State.READY);

                    tree.step();

                    node = findNode(tree, "repeat", "REPEAT 2x-10x");
                    assert.strictEqual(node.state, State.RUNNING);

                    tree.step();

                    node = findNode(tree, "repeat", "REPEAT 2x-10x");
                    assert.strictEqual(node.state, State.RUNNING);

                    tree.step();

                    node = findNode(tree, "repeat", "REPEAT 2x-10x");
                    assert.strictEqual(node.state, State.RUNNING);

                    tree.step();

                    node = findNode(tree, "repeat", "REPEAT 2x-10x");
                    assert.strictEqual(node.state, State.SUCCEEDED);
                });
            });
        });
    });

    describe("when a snapshot of the tree is restored", () => {
        const stepTree = (tree: BehaviourTree, steps: number) => {
            for (let step = 0; step < steps; step++) {
                tree.step();
            }
        };

        it("keeps the iteration count and the target iteration count", () => {
            const calls: string[] = [];
            const agent = {
                Work: () => {
                    calls.push("Work");
                    return State.SUCCEEDED;
                }
            };
            const definition = "root { repeat [3] { action [Work] } }";

            const original = new BehaviourTree(definition, agent, {});
            stepTree(original, 2);

            const snapshot = roundTripSnapshot(original.snapshot());
            assert.include(findNodeSnapshot(snapshot, "repeat"), { targetIterationCount: 3, currentIterationCount: 2 });

            calls.length = 0;
            const restored = new BehaviourTree(definition, agent, {});
            restored.restore(snapshot);

            // There is one iteration left to make before the extra step that resolves the node.
            restored.step();
            assert.equal(restored.getState(), State.RUNNING);
            restored.step();
            assert.equal(restored.getState(), State.SUCCEEDED);
            assert.deepEqual(calls, ["Work"]);
        });

        it("keeps a randomly selected target iteration count rather than selecting another", () => {
            // The first value selects the maximum of 5 and the second the minimum of 1.
            const random = [0.99, 0];
            let randomCalls = 0;
            const options = { random: () => random[randomCalls++] };
            const calls: string[] = [];
            const agent = {
                Work: () => {
                    calls.push("Work");
                    return State.SUCCEEDED;
                }
            };
            const definition = "root { repeat [1, 5] { action [Work] } }";

            const original = new BehaviourTree(definition, agent, options);
            stepTree(original, 2);
            assert.equal(randomCalls, 1);

            const snapshot = roundTripSnapshot(original.snapshot());
            assert.include(findNodeSnapshot(snapshot, "repeat"), { targetIterationCount: 5, currentIterationCount: 2 });

            calls.length = 0;
            const restored = new BehaviourTree(definition, agent, options);
            restored.restore(snapshot);

            for (let step = 0; step < 3; step++) {
                restored.step();
                assert.equal(restored.getState(), State.RUNNING);
            }
            restored.step();
            assert.equal(restored.getState(), State.SUCCEEDED);
            assert.equal(calls.length, 3);
            assert.equal(randomCalls, 1);
        });

        it("selects a new random target iteration count when a tree that had finished starts a new run", () => {
            const random = [0.99, 0];
            let randomCalls = 0;
            const options = { random: () => random[randomCalls++] };
            const calls: string[] = [];
            const agent = {
                Work: () => {
                    calls.push("Work");
                    return State.SUCCEEDED;
                }
            };
            const definition = "root { repeat [1, 5] { action [Work] } }";

            const original = new BehaviourTree(definition, agent, options);
            stepTree(original, 6);
            assert.equal(original.getState(), State.SUCCEEDED);
            assert.equal(calls.length, 5);

            calls.length = 0;
            const restored = new BehaviourTree(definition, agent, options);
            restored.restore(roundTripSnapshot(original.snapshot()));
            assert.equal(restored.getState(), State.SUCCEEDED);

            stepTree(restored, 2);

            assert.equal(randomCalls, 2);
            assert.equal(calls.length, 1);
            assert.equal(restored.getState(), State.SUCCEEDED);
        });

        it("behaves as the original tree would for an explicit, random and unbounded number of iterations", () => {
            const functions = { Work: (tick: number) => (tick % 2 === 0 ? State.SUCCEEDED : State.RUNNING) };

            assertSnapshotRestoresAtEveryStep({
                definition: "root { repeat [3] { action [Work] } }",
                functions,
                steps: 10
            });
            assertSnapshotRestoresAtEveryStep({
                definition: "root { repeat [1, 4] { action [Work] } }",
                functions,
                random: [0.99, 0, 0.5],
                steps: 24
            });
            assertSnapshotRestoresAtEveryStep({
                definition: "root { repeat { action [Work] } }",
                functions: {
                    Work: (tick: number) =>
                        tick === 9 ? State.FAILED : tick % 2 === 0 ? State.SUCCEEDED : State.RUNNING
                },
                steps: 12
            });
        });

        it("behaves as the original tree would when nested within other nodes that reset it", () => {
            assertSnapshotRestoresAtEveryStep({
                definition: `root {
                    repeat [2] {
                        sequence {
                            repeat [1, 3] { action [Inner] }
                            action [Outer]
                        }
                    }
                }`,
                functions: {
                    Inner: (tick: number) => (tick % 2 === 0 ? State.SUCCEEDED : State.RUNNING),
                    Outer: (tick: number) => (tick % 3 === 0 ? State.SUCCEEDED : State.RUNNING)
                },
                random: [0.5, 0.99, 0, 0.2],
                steps: 40
            });
        });

        describe("will error and leave the tree unchanged if a running node has a target iteration count that does not agree with its definition", () => {
            const cases: [string, string, any, string][] = [
                ["an explicit count that is different", "root { repeat [3] { action [Work] } }", 4, "to be 3"],
                ["an explicit count that is null", "root { repeat [3] { action [Work] } }", null, "to be 3"],
                ["a range that is null", "root { repeat [1, 5] { action [Work] } }", null, "to be a number"],
                ["no limit that is a number", "root { repeat { action [Work] } }", 3, "to be null"]
            ];

            cases.forEach(([description, definition, value, expected]) => {
                it(`with ${description}`, () => {
                    const agent = { Work: () => State.RUNNING };
                    const original = new BehaviourTree(definition, agent, {});
                    original.step();
                    const snapshot = JSON.parse(JSON.stringify(original.snapshot()));
                    snapshot.root.children[0].targetIterationCount = value;

                    const tree = new BehaviourTree(definition, agent, {});
                    const snapshotBefore = tree.snapshot();

                    assert.throws(
                        () => tree.restore(snapshot),
                        Error,
                        "invalid snapshot: expected 'targetIterationCount' " + expected
                    );

                    assert.deepEqual(tree.snapshot(), snapshotBefore);
                });
            });

            it("but not if the node is not running, as when a guard failed before the node was first updated", () => {
                const definition = "root { repeat [3] while(IsAllowed) { action [Work] } }";
                const agent = { IsAllowed: () => false, Work: () => State.RUNNING };
                const original = new BehaviourTree(definition, agent, {});
                original.step();
                assert.equal(findNode(original, "repeat").state, State.FAILED);

                const snapshot = roundTripSnapshot(original.snapshot());
                assert.strictEqual(findNodeSnapshot(snapshot, "repeat").targetIterationCount, null);

                const restored = new BehaviourTree(definition, agent, {});
                restored.restore(snapshot);

                assert.equal(findNode(restored, "repeat").state, State.FAILED);
            });
        });

        describe("will error and leave the tree unchanged if the snapshot node has an invalid", () => {
            const invalidValues: [string, string, any][] = [
                ["target iteration count that is not an integer", "targetIterationCount", 1.5],
                ["target iteration count that is negative", "targetIterationCount", -1],
                ["target iteration count that is a string", "targetIterationCount", "3"],
                ["target iteration count that is undefined", "targetIterationCount", undefined],
                ["iteration count that is not an integer", "currentIterationCount", 0.5],
                ["iteration count that is negative", "currentIterationCount", -1],
                ["iteration count that is null", "currentIterationCount", null],
                ["iteration count that is undefined", "currentIterationCount", undefined]
            ];

            invalidValues.forEach(([description, property, value]) => {
                it(description, () => {
                    const tree = new BehaviourTree(
                        "root { repeat [3] { action [Work] } }",
                        { Work: () => State.RUNNING },
                        {}
                    );
                    const snapshotBefore = tree.snapshot();
                    const snapshot = JSON.parse(JSON.stringify(snapshotBefore));
                    snapshot.root.children[0][property] = value;

                    assert.throws(
                        () => tree.restore(snapshot),
                        Error,
                        "invalid snapshot: expected '" + property + "' to be a non-negative integer"
                    );

                    assert.deepEqual(tree.snapshot(), snapshotBefore);
                });
            });
        });
    });
});
