import { assert } from "chai";
import sinon from "sinon";

import { BehaviourTree, State } from "../../../src/index";
import { RootNodeDefinition } from "../../../src/BehaviourTreeDefinition";

import { findNode } from "../../TestUtilities";
import { assertSnapshotRestoresAtEveryStep, findNodeSnapshot, roundTripSnapshot } from "../../SnapshotTestUtilities";

describe("An Action node", () => {
    beforeEach(() => BehaviourTree.unregisterAll());

    describe("on tree initialisation", () => {
        describe("will error if no action function name is defined", () => {
            it("(MDSL)", () => {
                const definition = "root { action [] }";
                assert.throws(
                    () => new BehaviourTree(definition, {}),
                    Error,
                    "invalid definition: expected action name identifier argument"
                );
            });

            it("(JSON)", () => {
                const definition = {
                    type: "root",
                    child: {
                        type: "action"
                    }
                } as any;
                assert.throws(
                    () => new BehaviourTree(definition, {}),
                    Error,
                    "invalid definition: expected non-empty string for 'call' property of action node at depth '1'"
                );
            });
        });
    });

    describe("when updated as part of a tree step", () => {
        describe("will call the function defined by the first node argument", () => {
            describe("when the referenced function is", () => {
                describe("a registered function", () => {
                    it("(MDSL)", () => {
                        const registeredActionFunction = sinon.stub().returns(State.SUCCEEDED);
                        BehaviourTree.register("doAction", registeredActionFunction);

                        const definition = `root { action [doAction, "some-argument"] }`;
                        const agent = { mock: "agent" };
                        const tree = new BehaviourTree(definition, agent);

                        tree.step();

                        const node = findNode(tree, "action", "doAction");
                        assert.strictEqual(node.state, State.SUCCEEDED);
                        assert.isTrue(registeredActionFunction.calledWith(agent, "some-argument"));
                    });

                    it("(JSON)", () => {
                        const registeredActionFunction = sinon.stub().returns(State.SUCCEEDED);
                        BehaviourTree.register("doAction", registeredActionFunction);

                        const definition: RootNodeDefinition = {
                            type: "root",
                            child: {
                                type: "action",
                                call: "doAction",
                                args: ["some-argument"]
                            }
                        };
                        const agent = { mock: "agent" };
                        const tree = new BehaviourTree(definition, agent);

                        tree.step();

                        const node = findNode(tree, "action", "doAction");
                        assert.strictEqual(node.state, State.SUCCEEDED);
                        assert.isTrue(registeredActionFunction.calledWith(agent, "some-argument"));
                    });
                });

                describe("an agent function", () => {
                    it("(MDSL)", () => {
                        const definition = "root { action [doAction] }";
                        const agent = { doAction: () => State.SUCCEEDED };
                        const tree = new BehaviourTree(definition, agent);

                        tree.step();

                        const node = findNode(tree, "action", "doAction");
                        assert.strictEqual(node.state, State.SUCCEEDED);
                    });

                    it("(JSON)", () => {
                        const definition: RootNodeDefinition = {
                            type: "root",
                            child: {
                                type: "action",
                                call: "doAction"
                            }
                        };
                        const agent = { doAction: () => State.SUCCEEDED };
                        const tree = new BehaviourTree(definition, agent);

                        tree.step();

                        const node = findNode(tree, "action", "doAction");
                        assert.strictEqual(node.state, State.SUCCEEDED);
                    });
                });
            });

            describe("and will error if", () => {
                describe("there is no agent function or registered function that matches the action name", () => {
                    it("(MDSL)", () => {
                        const definition = "root { action [DoTheThing] }";
                        let tree: BehaviourTree;
                        assert.doesNotThrow(() => (tree = new BehaviourTree(definition, {})), Error);
                        assert.throws(
                            () => tree.step(),
                            Error,
                            "error stepping tree: cannot update action node as the action 'DoTheThing' function is not defined on the agent and has not been registered"
                        );
                    });

                    it("(JSON)", () => {
                        const definition: RootNodeDefinition = {
                            type: "root",
                            child: {
                                type: "action",
                                call: "DoTheThing"
                            }
                        };
                        let tree: BehaviourTree;
                        assert.doesNotThrow(() => (tree = new BehaviourTree(definition, {})), Error);
                        assert.throws(
                            () => tree.step(),
                            Error,
                            "error stepping tree: cannot update action node as the action 'DoTheThing' function is not defined on the agent and has not been registered"
                        );
                    });
                });

                describe("the action function", () => {
                    describe("throws an error object", () => {
                        it("(MDSL)", () => {
                            const definition = "root { action [doAction] }";
                            const agent = {
                                doAction: () => {
                                    throw new Error("some-error");
                                }
                            };
                            const tree = new BehaviourTree(definition, agent);

                            assert.throws(
                                () => tree.step(),
                                Error,
                                "error stepping tree: action function 'doAction' threw: Error: some-error"
                            );
                        });

                        it("(JSON)", () => {
                            const definition: RootNodeDefinition = {
                                type: "root",
                                child: {
                                    type: "action",
                                    call: "doAction"
                                }
                            };
                            const agent = {
                                doAction: () => {
                                    throw new Error("some-error");
                                }
                            };
                            const tree = new BehaviourTree(definition, agent);

                            assert.throws(
                                () => tree.step(),
                                Error,
                                "error stepping tree: action function 'doAction' threw: Error: some-error"
                            );
                        });
                    });

                    describe("throws something that isn't an error object", () => {
                        it("(MDSL)", () => {
                            const definition = "root { action [doAction] }";
                            const agent = {
                                doAction: () => {
                                    throw "some-error";
                                }
                            };
                            const tree = new BehaviourTree(definition, agent);

                            assert.throws(
                                () => tree.step(),
                                Error,
                                "error stepping tree: action function 'doAction' threw: some-error"
                            );
                        });

                        it("(JSON)", () => {
                            const definition: RootNodeDefinition = {
                                type: "root",
                                child: {
                                    type: "action",
                                    call: "doAction"
                                }
                            };
                            const agent = {
                                doAction: () => {
                                    throw "some-error";
                                }
                            };
                            const tree = new BehaviourTree(definition, agent);

                            assert.throws(
                                () => tree.step(),
                                Error,
                                "error stepping tree: action function 'doAction' threw: some-error"
                            );
                        });
                    });

                    describe("returns an unexpected value", () => {
                        it("(MDSL)", () => {
                            const definition = "root { action [doAction] }";
                            const agent = {
                                doAction: () => "invalid-result"
                            };
                            const tree = new BehaviourTree(definition, agent);

                            assert.throws(
                                () => tree.step(),
                                Error,
                                "error stepping tree: expected action function 'doAction' to return an optional State.SUCCEEDED or State.FAILED value but returned 'invalid-result'"
                            );
                        });

                        it("(JSON)", () => {
                            const definition: RootNodeDefinition = {
                                type: "root",
                                child: {
                                    type: "action",
                                    call: "doAction"
                                }
                            };
                            const agent = {
                                doAction: () => "invalid-result"
                            };
                            const tree = new BehaviourTree(definition, agent);

                            assert.throws(
                                () => tree.step(),
                                Error,
                                "error stepping tree: expected action function 'doAction' to return an optional State.SUCCEEDED or State.FAILED value but returned 'invalid-result'"
                            );
                        });
                    });

                    describe("returns a rejected promise", () => {
                        it("(MDSL)", (done) => {
                            const definition = "root { action [doAction] }";
                            const result: Promise<State.SUCCEEDED> = new Promise(() => {
                                throw new Error("some-error");
                            });
                            const agent = { doAction: () => result };
                            const tree = new BehaviourTree(definition, agent);

                            assert.strictEqual(findNode(tree, "action", "doAction").state, State.READY);

                            tree.step();

                            assert.strictEqual(findNode(tree, "action", "doAction").state, State.RUNNING);

                            setTimeout(() => {
                                assert.throws(
                                    () => tree.step(),
                                    Error,
                                    "error stepping tree: action function 'doAction' promise rejected with 'Error: some-error'"
                                );

                                done();
                            }, 0);
                        });

                        it("(JSON)", (done) => {
                            const definition: RootNodeDefinition = {
                                type: "root",
                                child: {
                                    type: "action",
                                    call: "doAction"
                                }
                            };
                            const result: Promise<State.SUCCEEDED> = new Promise(() => {
                                throw new Error("some-error");
                            });
                            const agent = { doAction: () => result };
                            const tree = new BehaviourTree(definition, agent);

                            assert.strictEqual(findNode(tree, "action", "doAction").state, State.READY);

                            tree.step();

                            assert.strictEqual(findNode(tree, "action", "doAction").state, State.RUNNING);

                            setTimeout(() => {
                                assert.throws(
                                    () => tree.step(),
                                    Error,
                                    "error stepping tree: action function 'doAction' promise rejected with 'Error: some-error'"
                                );

                                done();
                            }, 0);
                        });
                    });
                });
            });

            describe("and move to", () => {
                describe("the SUCCESS state if the function returns a value of State.SUCCEEDED", () => {
                    it("(MDSL)", () => {
                        const definition = "root { action [doAction] }";
                        const agent = { doAction: () => State.SUCCEEDED };
                        const tree = new BehaviourTree(definition, agent);

                        let node = findNode(tree, "action", "doAction");
                        assert.strictEqual(node.state, State.READY);

                        tree.step();

                        node = findNode(tree, "action", "doAction");
                        assert.strictEqual(node.state, State.SUCCEEDED);
                    });

                    it("(JSON)", () => {
                        const definition: RootNodeDefinition = {
                            type: "root",
                            child: {
                                type: "action",
                                call: "doAction"
                            }
                        };
                        const agent = { doAction: () => State.SUCCEEDED };
                        const tree = new BehaviourTree(definition, agent);

                        let node = findNode(tree, "action", "doAction");
                        assert.strictEqual(node.state, State.READY);

                        tree.step();

                        node = findNode(tree, "action", "doAction");
                        assert.strictEqual(node.state, State.SUCCEEDED);
                    });
                });

                describe("the FAILED state if the function returns a value of State.FAILED", () => {
                    it("(MDSL)", () => {
                        const definition = "root { action [doAction] }";
                        const agent = { doAction: () => State.FAILED };
                        const tree = new BehaviourTree(definition, agent);

                        let node = findNode(tree, "action", "doAction");
                        assert.strictEqual(node.state, State.READY);

                        tree.step();

                        node = findNode(tree, "action", "doAction");
                        assert.strictEqual(node.state, State.FAILED);
                    });

                    it("(JSON)", () => {
                        const definition: RootNodeDefinition = {
                            type: "root",
                            child: {
                                type: "action",
                                call: "doAction"
                            }
                        };
                        const agent = { doAction: () => State.FAILED };
                        const tree = new BehaviourTree(definition, agent);

                        let node = findNode(tree, "action", "doAction");
                        assert.strictEqual(node.state, State.READY);

                        tree.step();

                        node = findNode(tree, "action", "doAction");
                        assert.strictEqual(node.state, State.FAILED);
                    });
                });

                describe("the RUNNING state if", () => {
                    describe("the function returns undefined", () => {
                        it("(MDSL)", () => {
                            const definition = "root { action [doAction] }";
                            const agent = { doAction: () => State.RUNNING };
                            const tree = new BehaviourTree(definition, agent);

                            let node = findNode(tree, "action", "doAction");
                            assert.strictEqual(node.state, State.READY);

                            tree.step();

                            node = findNode(tree, "action", "doAction");
                            assert.strictEqual(node.state, State.RUNNING);
                        });

                        it("(JSON)", () => {
                            const definition: RootNodeDefinition = {
                                type: "root",
                                child: {
                                    type: "action",
                                    call: "doAction"
                                }
                            };
                            const agent = { doAction: () => State.RUNNING };
                            const tree = new BehaviourTree(definition, agent);

                            let node = findNode(tree, "action", "doAction");
                            assert.strictEqual(node.state, State.READY);

                            tree.step();

                            node = findNode(tree, "action", "doAction");
                            assert.strictEqual(node.state, State.RUNNING);
                        });
                    });

                    describe("the function returns a value of State.RUNNING", () => {
                        it("(MDSL)", () => {
                            const definition = "root { action [doAction] }";
                            const agent = { doAction: () => State.RUNNING };
                            const tree = new BehaviourTree(definition, agent);

                            let node = findNode(tree, "action", "doAction");
                            assert.strictEqual(node.state, State.READY);

                            tree.step();

                            node = findNode(tree, "action", "doAction");
                            assert.strictEqual(node.state, State.RUNNING);
                        });

                        it("(JSON)", () => {
                            const definition: RootNodeDefinition = {
                                type: "root",
                                child: {
                                    type: "action",
                                    call: "doAction"
                                }
                            };
                            const agent = { doAction: () => State.RUNNING };
                            const tree = new BehaviourTree(definition, agent);

                            let node = findNode(tree, "action", "doAction");
                            assert.strictEqual(node.state, State.READY);

                            tree.step();

                            node = findNode(tree, "action", "doAction");
                            assert.strictEqual(node.state, State.RUNNING);
                        });
                    });

                    describe("the function returns a promise to return a value of State.SUCCEEDED or State.FAILED", () => {
                        it("(MDSL)", (done) => {
                            const definition = "root { action [doAction] }";

                            const result: Promise<State.SUCCEEDED> = new Promise((resolve) => resolve(State.SUCCEEDED));
                            const agent = { doAction: () => result };
                            const tree = new BehaviourTree(definition, agent);

                            assert.strictEqual(findNode(tree, "action", "doAction").state, State.READY);

                            tree.step();

                            assert.strictEqual(findNode(tree, "action", "doAction").state, State.RUNNING);

                            setTimeout(() => {
                                tree.step();

                                assert.strictEqual(findNode(tree, "action", "doAction").state, State.SUCCEEDED);

                                done();
                            }, 0);
                        });

                        it("(JSON)", (done) => {
                            const definition: RootNodeDefinition = {
                                type: "root",
                                child: {
                                    type: "action",
                                    call: "doAction"
                                }
                            };

                            const result: Promise<State.SUCCEEDED> = new Promise((resolve) => resolve(State.SUCCEEDED));
                            const agent = { doAction: () => result };
                            const tree = new BehaviourTree(definition, agent);

                            assert.strictEqual(findNode(tree, "action", "doAction").state, State.READY);

                            tree.step();

                            assert.strictEqual(findNode(tree, "action", "doAction").state, State.RUNNING);

                            setTimeout(() => {
                                tree.step();

                                assert.strictEqual(findNode(tree, "action", "doAction").state, State.SUCCEEDED);

                                done();
                            }, 0);
                        });
                    });
                });
            });

            describe("and pass any node arguments that follow the action name identifier argument where", () => {
                describe("the argument is a", () => {
                    describe("string", () => {
                        it("(MDSL)", () => {
                            const definition = 'root { action [doAction, "hello world!"] }';
                            const agent = {
                                doAction: (arg: any) => assert.strictEqual(arg, "hello world!")
                            };
                            const tree = new BehaviourTree(definition, agent);

                            tree.step();
                        });

                        it("(JSON)", () => {
                            const definition: RootNodeDefinition = {
                                type: "root",
                                child: {
                                    type: "action",
                                    call: "doAction",
                                    args: ["hello world!"]
                                }
                            };
                            const agent = {
                                doAction: (arg: any) => assert.strictEqual(arg, "hello world!")
                            };
                            const tree = new BehaviourTree(definition, agent);

                            tree.step();
                        });
                    });

                    describe("string with escaped quotes", () => {
                        it("(MDSL)", () => {
                            const definition = 'root { action [doAction, "hello \\" world!"] }';
                            const agent = {
                                doAction: (arg: any) => assert.strictEqual(arg, 'hello " world!')
                            };
                            const tree = new BehaviourTree(definition, agent);

                            tree.step();
                        });

                        it("(JSON)", () => {
                            const definition: RootNodeDefinition = {
                                type: "root",
                                child: {
                                    type: "action",
                                    call: "doAction",
                                    args: ['hello " world!']
                                }
                            };
                            const agent = {
                                doAction: (arg: any) => assert.strictEqual(arg, 'hello " world!')
                            };
                            const tree = new BehaviourTree(definition, agent);

                            tree.step();
                        });
                    });

                    describe("number", () => {
                        it("(MDSL)", () => {
                            const definition = "root { action [doAction, 23.4567] }";
                            const agent = {
                                doAction: (arg: any) => assert.strictEqual(arg, 23.4567)
                            };
                            const tree = new BehaviourTree(definition, agent);

                            tree.step();
                        });

                        it("(JSON)", () => {
                            const definition: RootNodeDefinition = {
                                type: "root",
                                child: {
                                    type: "action",
                                    call: "doAction",
                                    args: [23.4567]
                                }
                            };
                            const agent = {
                                doAction: (arg: any) => assert.strictEqual(arg, 23.4567)
                            };
                            const tree = new BehaviourTree(definition, agent);

                            tree.step();
                        });
                    });

                    describe("boolean 'true' literal", () => {
                        it("(MDSL)", () => {
                            const definition = "root { action [doAction, true] }";
                            const agent = {
                                doAction: (arg: any) => assert.strictEqual(arg, true)
                            };
                            const tree = new BehaviourTree(definition, agent);

                            tree.step();
                        });

                        it("(JSON)", () => {
                            const definition: RootNodeDefinition = {
                                type: "root",
                                child: {
                                    type: "action",
                                    call: "doAction",
                                    args: [true]
                                }
                            };
                            const agent = {
                                doAction: (arg: any) => assert.strictEqual(arg, true)
                            };
                            const tree = new BehaviourTree(definition, agent);

                            tree.step();
                        });
                    });

                    describe("boolean 'false' literal", () => {
                        it("(MDSL)", () => {
                            const definition = "root { action [doAction, false] }";
                            const agent = {
                                doAction: (arg: any) => assert.strictEqual(arg, false)
                            };
                            const tree = new BehaviourTree(definition, agent);

                            tree.step();
                        });

                        it("(JSON)", () => {
                            const definition: RootNodeDefinition = {
                                type: "root",
                                child: {
                                    type: "action",
                                    call: "doAction",
                                    args: [false]
                                }
                            };
                            const agent = {
                                doAction: (arg: any) => assert.strictEqual(arg, false)
                            };
                            const tree = new BehaviourTree(definition, agent);

                            tree.step();
                        });
                    });

                    describe("null", () => {
                        it("(MDSL)", () => {
                            const definition = "root { action [doAction, null] }";
                            const agent = {
                                doAction: (arg: any) => assert.isNull(arg)
                            };
                            const tree = new BehaviourTree(definition, agent);

                            tree.step();
                        });

                        it("(JSON)", () => {
                            const definition: RootNodeDefinition = {
                                type: "root",
                                child: {
                                    type: "action",
                                    call: "doAction",
                                    args: [null]
                                }
                            };
                            const agent = {
                                doAction: (arg: any) => assert.isNull(arg)
                            };
                            const tree = new BehaviourTree(definition, agent);

                            tree.step();
                        });
                    });

                    describe("agent property reference", () => {
                        it("(MDSL)", () => {
                            const definition = "root { action [doAction, $someProperty] }";
                            const agent = {
                                doAction: (arg: any) => {
                                    assert.strictEqual(arg, "some-property-value");
                                },
                                someProperty: "some-property-value"
                            };
                            const tree = new BehaviourTree(definition, agent);

                            tree.step();
                        });

                        it("(JSON)", () => {
                            const definition: RootNodeDefinition = {
                                type: "root",
                                child: {
                                    type: "action",
                                    call: "doAction",
                                    args: [{ $: "someProperty" }]
                                }
                            };
                            const agent = {
                                doAction: (arg: any) => assert.strictEqual(arg, "some-property-value"),
                                someProperty: "some-property-value"
                            };
                            const tree = new BehaviourTree(definition, agent);

                            tree.step();
                        });
                    });
                });

                describe("there are multiple arguments", () => {
                    it("(MDSL)", () => {
                        const definition =
                            'root { action [doAction, 1.23, "hello world!", false, null, $someProperty] }';
                        const agent = {
                            doAction: (arg0: any, arg1: any, arg2: any, arg3: any, arg4: any) => {
                                assert.strictEqual(arg0, 1.23);
                                assert.strictEqual(arg1, "hello world!");
                                assert.strictEqual(arg2, false);
                                assert.strictEqual(arg3, null);
                                assert.strictEqual(arg4, "some-property-value");
                            },
                            someProperty: "some-property-value"
                        };
                        const tree = new BehaviourTree(definition, agent);

                        tree.step();
                    });

                    it("(JSON)", () => {
                        const definition: RootNodeDefinition = {
                            type: "root",
                            child: {
                                type: "action",
                                call: "doAction",
                                args: [1.23, "hello world!", false, null, { $: "someProperty" }]
                            }
                        };
                        const agent = {
                            doAction: (arg0: any, arg1: any, arg2: any, arg3: any, arg4: any) => {
                                assert.strictEqual(arg0, 1.23);
                                assert.strictEqual(arg1, "hello world!");
                                assert.strictEqual(arg2, false);
                                assert.strictEqual(arg3, null);
                                assert.strictEqual(arg4, "some-property-value");
                            },
                            someProperty: "some-property-value"
                        };
                        const tree = new BehaviourTree(definition, agent);

                        tree.step();
                    });
                });
            });
        });
    });

    describe("when a snapshot of the tree is restored", () => {
        const definition = "root { sequence { action [Work] action [Other] } }";

        // Wait for any promise callbacks to be called.
        const settle = () => new Promise((resolve) => setTimeout(resolve, 0));

        const createTrees = (work: () => any) => {
            const calls: string[] = [];
            const createAgent = () => ({
                Work: () => {
                    calls.push("Work");
                    return work();
                },
                Other: () => {
                    calls.push("Other");
                    return State.SUCCEEDED;
                }
            });

            return {
                calls,
                original: new BehaviourTree(definition, createAgent(), {}),
                createRestored: () => new BehaviourTree(definition, createAgent(), {})
            };
        };

        it("keeps no promise result for an action that is not waiting on a promise", () => {
            const { original } = createTrees(() => undefined);
            assert.deepEqual(findNodeSnapshot(original.snapshot(), "action"), {
                type: "action",
                state: State.READY,
                promiseResult: null
            });

            original.step();

            assert.deepEqual(findNodeSnapshot(original.snapshot(), "action"), {
                type: "action",
                state: State.RUNNING,
                promiseResult: null
            });
        });

        describe("for an action that was waiting on a promise that had not settled", () => {
            it("snapshots the action as not yet started, with no promise result", () => {
                const { original } = createTrees(() => new Promise(() => undefined));
                original.step();
                assert.strictEqual(findNode(original, "action", "Work").state, State.RUNNING);

                const snapshot = roundTripSnapshot(original.snapshot());

                assert.deepEqual(findNodeSnapshot(snapshot, "action"), {
                    type: "action",
                    state: State.READY,
                    promiseResult: null
                });
            });

            it("snapshots the action as not yet started while keeping the result of another action's promise that had settled", async () => {
                const calls: string[] = [];
                const createTree = () =>
                    new BehaviourTree(
                        "root { parallel { action [Pending] action [Settled] } }",
                        {
                            Pending: () => {
                                calls.push("Pending");
                                return new Promise(() => undefined);
                            },
                            Settled: () => {
                                calls.push("Settled");
                                return Promise.resolve(State.SUCCEEDED);
                            }
                        },
                        {}
                    );

                const original = createTree();
                original.step();
                await settle();

                const snapshot = roundTripSnapshot(original.snapshot());

                assert.deepEqual(
                    findNodeSnapshot(snapshot, "parallel").children.map(({ state, promiseResult }: any) => ({
                        state,
                        promiseResult
                    })),
                    [
                        { state: State.READY, promiseResult: null },
                        { state: State.RUNNING, promiseResult: { isResolved: true, value: State.SUCCEEDED } }
                    ]
                );

                const restored = createTree();
                restored.restore(snapshot);
                restored.step();

                assert.deepEqual(calls, ["Pending", "Settled", "Pending"]);
                assert.strictEqual(findNode(restored, "action", "Settled").state, State.SUCCEEDED);
            });

            it("does not change the tree that the snapshot was taken from, which still waits for its promise", async () => {
                let resolve: (state: State) => void = () => undefined;
                const { original, calls } = createTrees(() => new Promise((resolver) => (resolve = resolver)));
                original.step();

                original.snapshot();
                original.step();

                assert.deepEqual(calls, ["Work"]);
                assert.strictEqual(findNode(original, "action", "Work").state, State.RUNNING);

                resolve(State.SUCCEEDED);
                await settle();
                original.step();

                assert.deepEqual(calls, ["Work", "Other"]);
                assert.strictEqual(original.getState(), State.SUCCEEDED);
            });

            it("restores the action as not yet started and calls its function again on the next step", () => {
                const { original, createRestored, calls } = createTrees(() => new Promise(() => undefined));
                original.step();
                assert.deepEqual(calls, ["Work"]);

                const restored = createRestored();
                restored.restore(roundTripSnapshot(original.snapshot()));

                assert.strictEqual(findNode(restored, "action", "Work").state, State.READY);
                assert.strictEqual(restored.getState(), State.RUNNING);
                assert.deepEqual(calls, ["Work"]);

                restored.step();

                assert.deepEqual(calls, ["Work", "Work"]);
                assert.strictEqual(findNode(restored, "action", "Work").state, State.RUNNING);

                restored.step();

                assert.deepEqual(calls, ["Work", "Work"]);
            });

            it("carries on with the promise that the function returns after the restore", async () => {
                let promises = 0;
                const { original, createRestored, calls } = createTrees(() =>
                    promises++ === 0 ? new Promise(() => undefined) : Promise.resolve(State.SUCCEEDED)
                );
                original.step();

                const restored = createRestored();
                restored.restore(roundTripSnapshot(original.snapshot()));
                restored.step();
                await settle();
                restored.step();

                assert.deepEqual(calls, ["Work", "Work", "Other"]);
                assert.strictEqual(restored.getState(), State.SUCCEEDED);
            });

            it("starts the restored action as it would a node that had not started, calling its entry callback again", () => {
                const calls: string[] = [];
                const createTree = () =>
                    new BehaviourTree(
                        "root { action [Work] entry(OnEntry) }",
                        {
                            Work: () => new Promise(() => undefined),
                            OnEntry: () => calls.push("OnEntry")
                        },
                        {}
                    );

                const original = createTree();
                original.step();
                original.step();
                assert.deepEqual(calls, ["OnEntry"]);

                const restored = createTree();
                restored.restore(roundTripSnapshot(original.snapshot()));
                restored.step();

                assert.deepEqual(calls, ["OnEntry", "OnEntry"]);
            });

            it("restores a snapshot of the restored tree that is the same as the snapshot that it was restored from", () => {
                const { original, createRestored } = createTrees(() => new Promise(() => undefined));
                original.step();
                const snapshot = roundTripSnapshot(original.snapshot());

                const restored = createRestored();
                restored.restore(snapshot);

                assert.deepEqual(restored.snapshot(), snapshot);
            });
        });

        it("keeps the result of a promise that had resolved but not been handled by the tree", async () => {
            for (const result of [State.SUCCEEDED, State.FAILED]) {
                const { original, createRestored, calls } = createTrees(() => Promise.resolve(result));
                original.step();
                await settle();

                const snapshot = roundTripSnapshot(original.snapshot());
                assert.deepEqual(findNodeSnapshot(snapshot, "action").promiseResult, {
                    isResolved: true,
                    value: result
                });

                const restored = createRestored();
                restored.restore(snapshot);
                restored.step();

                assert.deepEqual(calls, ["Work"].concat(result === State.SUCCEEDED ? ["Other"] : []));
                assert.strictEqual(findNode(restored, "action", "Work").state, result);
            }
        });

        it("keeps the result of a promise that had been rejected but not been handled by the tree", async () => {
            const { original, createRestored, calls } = createTrees(() => Promise.reject(new Error("some-error")));
            original.step();
            await settle();

            const snapshot = roundTripSnapshot(original.snapshot());
            assert.deepEqual(findNodeSnapshot(snapshot, "action").promiseResult, {
                isResolved: false,
                value: "Error: some-error"
            });

            const restored = createRestored();
            restored.restore(snapshot);

            assert.throws(
                () => restored.step(),
                Error,
                "error stepping tree: action function 'Work' promise rejected with 'Error: some-error'"
            );
            assert.deepEqual(calls, ["Work"]);
        });

        it("keeps the result of a promise that had resolved with an invalid value", async () => {
            const { original, createRestored } = createTrees(() => Promise.resolve({ not: "a state" }));
            original.step();
            await settle();

            const snapshot = roundTripSnapshot(original.snapshot());

            const restored = createRestored();
            restored.restore(snapshot);

            assert.throws(
                () => restored.step(),
                Error,
                "action node promise resolved with an invalid value, expected a State.SUCCEEDED or State.FAILED value to be returned"
            );
        });

        it("will ignore a promise from before the restore that settles afterwards", async () => {
            let resolveFirst: (state: State) => void = () => undefined;
            let isFirstCall = true;
            const { original, calls } = createTrees(() => {
                if (isFirstCall) {
                    isFirstCall = false;
                    return new Promise((resolve) => (resolveFirst = resolve));
                }
                return new Promise(() => undefined);
            });
            const unstartedSnapshot = original.snapshot();

            original.step();
            original.restore(unstartedSnapshot);
            original.step();
            assert.deepEqual(calls, ["Work", "Work"]);

            resolveFirst(State.SUCCEEDED);
            await settle();
            original.step();

            assert.deepEqual(calls, ["Work", "Work"]);
            assert.strictEqual(findNode(original, "action", "Work").state, State.RUNNING);
        });

        it("will use the promise result in the snapshot rather than one from a promise that settles afterwards", async () => {
            let resolveFirst: (state: State) => void = () => undefined;
            const { original } = createTrees(() => new Promise((resolve) => (resolveFirst = resolve)));
            original.step();

            const failed = createTrees(() => Promise.resolve(State.FAILED));
            failed.original.step();
            await settle();

            original.restore(failed.original.snapshot());

            resolveFirst(State.SUCCEEDED);
            await settle();
            original.step();

            assert.strictEqual(findNode(original, "action", "Work").state, State.FAILED);
        });

        it("behaves as the original tree would for actions that return a state", () => {
            assertSnapshotRestoresAtEveryStep({
                definition: "root { sequence { action [A] action [B] action [A] } }",
                functions: {
                    A: (tick: number) => (tick % 3 === 0 ? State.SUCCEEDED : undefined),
                    B: (tick: number) => (tick % 2 === 0 ? State.SUCCEEDED : State.RUNNING)
                },
                steps: 12
            });
        });

        describe("will error and leave the tree unchanged if the snapshot node has", () => {
            const invalidPromiseResults: [string, any][] = [
                ["a promise result that is not an object", "resolved"],
                ["a promise result that is undefined", undefined],
                ["a promise result without an isResolved flag", { value: State.SUCCEEDED }],
                [
                    "a promise result with an isResolved flag that is not a boolean",
                    { isResolved: 1, value: State.SUCCEEDED }
                ],
                ["a promise result with a value that is not a string", { isResolved: true, value: 1 }],
                ["a promise result with no value", { isResolved: true }]
            ];

            invalidPromiseResults.forEach(([description, value]) => {
                it(description, () => {
                    const { original, createRestored } = createTrees(() => undefined);
                    original.step();
                    const tree = createRestored();
                    const snapshotBefore = tree.snapshot();
                    const snapshot = JSON.parse(JSON.stringify(original.snapshot()));
                    snapshot.root.children[0].children[0].promiseResult = value;

                    assert.throws(
                        () => tree.restore(snapshot),
                        Error,
                        "invalid snapshot: expected 'promiseResult' to be null or an object with an 'isResolved' boolean and a 'value' string at 'root > sequence > action'"
                    );

                    assert.deepEqual(tree.snapshot(), snapshotBefore);
                });
            });

            it("a promise result while it is not in the RUNNING state", () => {
                const { original, createRestored } = createTrees(() => undefined);
                original.step();
                const tree = createRestored();
                const snapshotBefore = tree.snapshot();
                const snapshot = JSON.parse(JSON.stringify(original.snapshot()));
                snapshot.root.children[0].children[1].promiseResult = { isResolved: true, value: State.SUCCEEDED };

                assert.throws(
                    () => tree.restore(snapshot),
                    Error,
                    "invalid snapshot: expected 'promiseResult' to be null at 'root > sequence > action' as the node is not running"
                );

                assert.deepEqual(tree.snapshot(), snapshotBefore);
            });
        });
    });
});
