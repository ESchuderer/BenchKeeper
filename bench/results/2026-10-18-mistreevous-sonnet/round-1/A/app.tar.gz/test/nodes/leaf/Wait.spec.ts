import { assert } from "chai";
import sinon, { SinonFakeTimers, SinonSandbox } from "sinon";

import { BehaviourTree, State } from "../../../src/index";
import { RootNodeDefinition } from "../../../src/BehaviourTreeDefinition";
import { Agent } from "../../../src/Agent";

import { findNode } from "../../TestUtilities";
import { assertSnapshotRestoresAtEveryStep, findNodeSnapshot, roundTripSnapshot } from "../../SnapshotTestUtilities";

describe("A Wait node", () => {
    describe("on tree initialisation", () => {
        describe("will error if", () => {
            describe("the defined node arguments are not integers", () => {
                it("(MDSL)", () => {
                    const definition = "root { wait ['not', 'integers'] }";
                    assert.throws(
                        () => new BehaviourTree(definition, {}),
                        Error,
                        "invalid definition: wait node durations must be integer values"
                    );
                });

                it("(JSON)", () => {
                    const definition = {
                        type: "root",
                        child: {
                            type: "wait",
                            duration: ["not", "integers"]
                        }
                    } as any;
                    assert.throws(
                        () => new BehaviourTree(definition, {}),
                        Error,
                        "invalid definition: expected array containing two integer values for 'duration' property if defined for wait node at depth '1'"
                    );
                });
            });

            describe("a negative duration node argument was defined", () => {
                it("(MDSL)", () => {
                    const definition = "root { wait [-1] }";
                    assert.throws(
                        () => new BehaviourTree(definition, {}),
                        Error,
                        "invalid definition: a wait node must have a positive duration"
                    );
                });

                it("(JSON)", () => {
                    const definition = {
                        type: "root",
                        child: {
                            type: "wait",
                            duration: -1
                        }
                    } as any;
                    assert.throws(
                        () => new BehaviourTree(definition, {}),
                        Error,
                        "invalid definition: expected positive duration value for 'duration' property if defined for wait node at depth '1'"
                    );
                });
            });

            describe("more than two node arguments are defined", () => {
                it("(MDSL)", () => {
                    const definition = "root { wait [0, 1000, 4000] }";
                    assert.throws(
                        () => new BehaviourTree(definition, {}),
                        Error,
                        "invalid definition: invalid number of wait node duration arguments defined"
                    );
                });

                it("(JSON)", () => {
                    const definition = {
                        type: "root",
                        child: {
                            type: "wait",
                            duration: [0, 1000, 4000]
                        }
                    } as any;
                    assert.throws(
                        () => new BehaviourTree(definition, {}),
                        Error,
                        "invalid definition: expected array containing two integer values for 'duration' property if defined for wait node at depth '1'"
                    );
                });
            });

            describe("a minimum duration bound node argument is defined that is greater than the maximum duration bound node argument", () => {
                it("(MDSL)", () => {
                    const definition = "root { wait [1000, 500] }";
                    assert.throws(
                        () => new BehaviourTree(definition, {}),
                        Error,
                        "invalid definition: a wait node must not have a minimum duration that exceeds the maximum duration"
                    );
                });

                it("(JSON)", () => {
                    const definition = {
                        type: "root",
                        child: {
                            type: "wait",
                            duration: [1000, 500]
                        }
                    } as any;
                    assert.throws(
                        () => new BehaviourTree(definition, {}),
                        Error,
                        "invalid definition: expected minimum duration value that does not exceed the maximum duration value for 'duration' property if defined for wait node at depth '1'"
                    );
                });
            });
        });
    });

    describe("when updated as part of a tree step", () => {
        let clock: SinonFakeTimers;
        let sandbox: SinonSandbox;

        beforeEach(() => {
            clock = sinon.useFakeTimers();
            sandbox = sinon.createSandbox();
            sandbox.replace(globalThis.Math, "random", () => 0.5);
        });

        afterEach(() => {
            clock.restore();
            sandbox.restore();
        });

        describe("and an explicit duration was defined will move to the SUCCEEDED state if the duration has expired", () => {
            it("(MDSL)", () => {
                const definition = "root { wait [100] }";
                const tree = new BehaviourTree(definition, {});

                let node = findNode(tree, "wait");
                assert.strictEqual(node.state, State.READY);

                tree.step();

                node = findNode(tree, "wait");
                assert.strictEqual(node.state, State.RUNNING);

                clock.tick(99);

                tree.step();

                node = findNode(tree, "wait");
                assert.strictEqual(node.state, State.RUNNING);

                clock.tick(1);

                tree.step();

                node = findNode(tree, "wait");
                assert.strictEqual(node.state, State.SUCCEEDED);
            });

            it("(JSON)", () => {
                const definition: RootNodeDefinition = {
                    type: "root",
                    child: {
                        type: "wait",
                        duration: 100
                    }
                };
                const tree = new BehaviourTree(definition, {});

                let node = findNode(tree, "wait");
                assert.strictEqual(node.state, State.READY);

                tree.step();

                node = findNode(tree, "wait");
                assert.strictEqual(node.state, State.RUNNING);

                clock.tick(99);

                tree.step();

                node = findNode(tree, "wait");
                assert.strictEqual(node.state, State.RUNNING);

                clock.tick(1);

                tree.step();

                node = findNode(tree, "wait");
                assert.strictEqual(node.state, State.SUCCEEDED);
            });
        });

        describe("and min and max durations were defined", () => {
            describe("will select a random duration between the min and max durations and move to the SUCCEEDED state if the duration has expired", () => {
                it("(MDSL)", () => {
                    const definition = "root { wait [5000, 10000] }";
                    const tree = new BehaviourTree(definition, {});

                    let node = findNode(tree, "wait");
                    assert.strictEqual(node.state, State.READY);

                    tree.step();

                    node = findNode(tree, "wait");
                    assert.strictEqual(node.state, State.RUNNING);

                    // We have spied on Math.random to always return 0.5 for the sake of this test, so our actual duration 'should' be 7500ms.
                    clock.tick(7499);

                    tree.step();

                    node = findNode(tree, "wait");
                    assert.strictEqual(node.state, State.RUNNING);

                    clock.tick(1);

                    tree.step();

                    node = findNode(tree, "wait");
                    assert.strictEqual(node.state, State.SUCCEEDED);
                });

                it("(JSON)", () => {
                    const definition: RootNodeDefinition = {
                        type: "root",
                        child: {
                            type: "wait",
                            duration: [5000, 10000]
                        }
                    };
                    const tree = new BehaviourTree(definition, {});

                    let node = findNode(tree, "wait");
                    assert.strictEqual(node.state, State.READY);

                    tree.step();

                    node = findNode(tree, "wait");
                    assert.strictEqual(node.state, State.RUNNING);

                    // We have spied on Math.random to always return 0.5 for the sake of this test, so our actual duration 'should' be 7500ms.
                    clock.tick(7499);

                    tree.step();

                    node = findNode(tree, "wait");
                    assert.strictEqual(node.state, State.RUNNING);

                    clock.tick(1);

                    tree.step();

                    node = findNode(tree, "wait");
                    assert.strictEqual(node.state, State.SUCCEEDED);
                });
            });

            describe("will use the 'random' function to select the duration between the min and max durations if it was defined as a behaviour tree option and move to the SUCCEEDED state if the duration has expired", () => {
                it("(MDSL)", () => {
                    const definition = "root { wait [5000, 10000] }";
                    const options = {
                        // Usually this would return a new pseudo-random number each time, but for the sake of this test we
                        // just want to make sure that the number we return actually has an impact on which duration is picked.
                        random: () => 0.2
                    };
                    const tree = new BehaviourTree(definition, {}, options);

                    let node = findNode(tree, "wait");
                    assert.strictEqual(node.state, State.READY);

                    tree.step();

                    node = findNode(tree, "wait");
                    assert.strictEqual(node.state, State.RUNNING);

                    // Our 'random' function option will always return 0.2 for the sake of this test, so our actual duration 'should' be 6000ms.
                    clock.tick(5999);

                    tree.step();

                    node = findNode(tree, "wait");
                    assert.strictEqual(node.state, State.RUNNING);

                    clock.tick(1);

                    tree.step();

                    node = findNode(tree, "wait");
                    assert.strictEqual(node.state, State.SUCCEEDED);
                });

                it("(JSON)", () => {
                    const definition: RootNodeDefinition = {
                        type: "root",
                        child: {
                            type: "wait",
                            duration: [5000, 10000]
                        }
                    };
                    const options = {
                        // Usually this would return a new pseudo-random number each time, but for the sake of this test we
                        // just want to make sure that the number we return actually has an impact on which duration is picked.
                        random: () => 0.2
                    };
                    const tree = new BehaviourTree(definition, {}, options);

                    let node = findNode(tree, "wait");
                    assert.strictEqual(node.state, State.READY);

                    tree.step();

                    node = findNode(tree, "wait");
                    assert.strictEqual(node.state, State.RUNNING);

                    // Our 'random' function option will always return 0.2 for the sake of this test, so our actual duration 'should' be 6000ms.
                    clock.tick(5999);

                    tree.step();

                    node = findNode(tree, "wait");
                    assert.strictEqual(node.state, State.RUNNING);

                    clock.tick(1);

                    tree.step();

                    node = findNode(tree, "wait");
                    assert.strictEqual(node.state, State.SUCCEEDED);
                });
            });
        });

        describe("and an explicit duration or min and max durations were not defined will stay in the RUNNING state until aborted", () => {
            it("(MDSL)", () => {
                const definition = "root { wait while(CanWait) }";
                let canWait = true;
                const agent = { CanWait: () => canWait };
                const tree = new BehaviourTree(definition, agent);

                let node = findNode(tree, "wait");
                assert.strictEqual(node.state, State.READY);

                tree.step();

                node = findNode(tree, "wait");
                assert.strictEqual(node.state, State.RUNNING);

                clock.tick(1000000);

                tree.step();

                node = findNode(tree, "wait");
                assert.strictEqual(node.state, State.RUNNING);

                canWait = false;

                tree.step();

                node = findNode(tree, "wait");
                assert.strictEqual(node.state, State.FAILED);
            });

            it("(JSON)", () => {
                const definition: RootNodeDefinition = {
                    type: "root",
                    child: {
                        type: "wait",
                        while: {
                            call: "CanWait"
                        }
                    }
                };
                let canWait = true;
                const agent = { CanWait: () => canWait };
                const tree = new BehaviourTree(definition, agent);

                let node = findNode(tree, "wait");
                assert.strictEqual(node.state, State.READY);

                tree.step();

                node = findNode(tree, "wait");
                assert.strictEqual(node.state, State.RUNNING);

                clock.tick(1000000);

                tree.step();

                node = findNode(tree, "wait");
                assert.strictEqual(node.state, State.RUNNING);

                canWait = false;

                tree.step();

                node = findNode(tree, "wait");
                assert.strictEqual(node.state, State.FAILED);
            });
        });

        describe("will use the 'getDeltaTime' function to update the elapsed duration if it was defined as a behaviour tree option", () => {
            it("(MDSL)", () => {
                const definition = "root { wait [1000] }";
                const tree = new BehaviourTree(definition, {}, { getDeltaTime: () => 0.5 });

                let node = findNode(tree, "wait");
                assert.strictEqual(node.state, State.READY);

                tree.step();

                node = findNode(tree, "wait");
                assert.strictEqual(node.state, State.RUNNING);

                tree.step();

                node = findNode(tree, "wait");
                assert.strictEqual(node.state, State.SUCCEEDED);
            });

            it("(JSON)", () => {
                const definition: RootNodeDefinition = {
                    type: "root",
                    child: {
                        type: "wait",
                        duration: 1000
                    }
                };
                const tree = new BehaviourTree(definition, {}, { getDeltaTime: () => 0.5 });

                let node = findNode(tree, "wait");
                assert.strictEqual(node.state, State.READY);

                tree.step();

                node = findNode(tree, "wait");
                assert.strictEqual(node.state, State.RUNNING);

                tree.step();

                node = findNode(tree, "wait");
                assert.strictEqual(node.state, State.SUCCEEDED);
            });
        });
    });

    describe("when a snapshot of the tree is restored", () => {
        let clock: SinonFakeTimers;

        beforeEach(() => {
            clock = sinon.useFakeTimers();
        });

        afterEach(() => {
            clock.restore();
        });

        const stepAndGetState = (tree: BehaviourTree) => {
            tree.step();
            return findNode(tree, "wait").state;
        };

        describe("will wait for only the remaining duration and not count the time between the snapshot and the restore", () => {
            it("when using the clock", () => {
                const definition = "root { wait [1000] }";

                const original = new BehaviourTree(definition, {}, {});
                assert.strictEqual(stepAndGetState(original), State.RUNNING);
                clock.tick(400);

                const snapshot = roundTripSnapshot(original.snapshot());
                assert.include(findNodeSnapshot(snapshot, "wait"), { totalDuration: 1000, waitedDuration: 400 });

                // A lot of time passes, as if the process was restarted.
                clock.tick(5 * 24 * 60 * 60 * 1000);

                const restored = new BehaviourTree(definition, {}, {});
                restored.restore(snapshot);

                assert.strictEqual(findNode(restored, "wait").state, State.RUNNING);
                assert.strictEqual(stepAndGetState(restored), State.RUNNING);
                clock.tick(599);
                assert.strictEqual(stepAndGetState(restored), State.RUNNING);
                clock.tick(1);
                assert.strictEqual(stepAndGetState(restored), State.SUCCEEDED);
                assert.strictEqual(restored.getState(), State.SUCCEEDED);
            });

            it("when using the 'getDeltaTime' option", () => {
                const definition = "root { wait [1000] }";
                const options = { getDeltaTime: () => 0.25 };

                const original = new BehaviourTree(definition, {}, options);
                assert.strictEqual(stepAndGetState(original), State.RUNNING);
                assert.strictEqual(stepAndGetState(original), State.RUNNING);

                const snapshot = roundTripSnapshot(original.snapshot());
                assert.include(findNodeSnapshot(snapshot, "wait"), { totalDuration: 1000, waitedDuration: 500 });

                // A lot of time passes, as if the process was restarted.
                clock.tick(5 * 24 * 60 * 60 * 1000);

                const restored = new BehaviourTree(definition, {}, options);
                restored.restore(snapshot);

                assert.strictEqual(stepAndGetState(restored), State.RUNNING);
                assert.strictEqual(stepAndGetState(restored), State.SUCCEEDED);
            });

            it("when the snapshot was taken using the clock and restored using the 'getDeltaTime' option", () => {
                const definition = "root { wait [1000] }";

                const original = new BehaviourTree(definition, {}, {});
                original.step();
                clock.tick(750);

                const snapshot = roundTripSnapshot(original.snapshot());
                clock.tick(60 * 60 * 1000);

                const restored = new BehaviourTree(definition, {}, { getDeltaTime: () => 0.1 });
                restored.restore(snapshot);

                for (let step = 0; step < 2; step++) {
                    assert.strictEqual(stepAndGetState(restored), State.RUNNING);
                }
                assert.strictEqual(stepAndGetState(restored), State.SUCCEEDED);
            });

            it("when the snapshot was taken using the 'getDeltaTime' option and restored using the clock", () => {
                const definition = "root { wait [1000] }";

                const original = new BehaviourTree(definition, {}, { getDeltaTime: () => 0.75 });
                original.step();

                const snapshot = roundTripSnapshot(original.snapshot());
                clock.tick(60 * 60 * 1000);

                const restored = new BehaviourTree(definition, {}, {});
                restored.restore(snapshot);

                assert.strictEqual(stepAndGetState(restored), State.RUNNING);
                clock.tick(249);
                assert.strictEqual(stepAndGetState(restored), State.RUNNING);
                clock.tick(1);
                assert.strictEqual(stepAndGetState(restored), State.SUCCEEDED);
            });

            it("when the snapshot is restored into the tree it was taken from", () => {
                const tree = new BehaviourTree("root { wait [1000] }", {}, {});
                tree.step();
                clock.tick(600);

                const snapshot = tree.snapshot();
                clock.tick(10000);
                tree.restore(snapshot);

                assert.strictEqual(stepAndGetState(tree), State.RUNNING);
                clock.tick(400);
                assert.strictEqual(stepAndGetState(tree), State.SUCCEEDED);
            });
        });

        it("will succeed on the next step if the duration had already passed when the snapshot was taken", () => {
            const original = new BehaviourTree("root { wait [1000] }", {}, {});
            original.step();
            clock.tick(1500);

            const restored = new BehaviourTree("root { wait [1000] }", {}, {});
            restored.restore(roundTripSnapshot(original.snapshot()));

            assert.strictEqual(findNode(restored, "wait").state, State.RUNNING);
            assert.strictEqual(stepAndGetState(restored), State.SUCCEEDED);
        });

        it("will keep a randomly selected duration rather than selecting another", () => {
            const definition = "root { wait [100, 1000] }";
            let randomCalls = 0;
            const options = {
                random: () => {
                    randomCalls++;
                    return 0.99;
                }
            };

            const original = new BehaviourTree(definition, {}, options);
            original.step();
            assert.strictEqual(randomCalls, 1);
            clock.tick(500);

            const snapshot = roundTripSnapshot(original.snapshot());
            assert.include(findNodeSnapshot(snapshot, "wait"), { totalDuration: 991, waitedDuration: 500 });

            const restored = new BehaviourTree(
                definition,
                {},
                {
                    random: () => {
                        throw new Error("a restored wait node should not select another duration");
                    }
                }
            );
            restored.restore(snapshot);

            assert.strictEqual(stepAndGetState(restored), State.RUNNING);
            clock.tick(490);
            assert.strictEqual(stepAndGetState(restored), State.RUNNING);
            clock.tick(1);
            assert.strictEqual(stepAndGetState(restored), State.SUCCEEDED);
        });

        it("will keep waiting indefinitely if there is no duration", () => {
            const original = new BehaviourTree("root { wait }", {}, {});
            original.step();

            const snapshot = roundTripSnapshot(original.snapshot());
            assert.include(findNodeSnapshot(snapshot, "wait"), { totalDuration: null });

            const restored = new BehaviourTree("root { wait }", {}, {});
            restored.restore(snapshot);
            clock.tick(Number.MAX_SAFE_INTEGER);

            assert.strictEqual(stepAndGetState(restored), State.RUNNING);
        });

        it("will wait for the whole duration of a node that had not started waiting", () => {
            const original = new BehaviourTree("root { sequence { wait [100] wait [1000] } }", {}, {});
            original.step();
            clock.tick(100);
            original.step();
            assert.deepEqual(
                [findNode(original, "wait", "WAIT 100ms").state, findNode(original, "wait", "WAIT 1000ms").state],
                [State.SUCCEEDED, State.RUNNING]
            );

            const snapshot = roundTripSnapshot(original.snapshot());
            clock.tick(100000);

            const restored = new BehaviourTree("root { sequence { wait [100] wait [1000] } }", {}, {});
            restored.restore(snapshot);
            restored.step();
            clock.tick(999);
            restored.step();
            assert.strictEqual(restored.getState(), State.RUNNING);
            clock.tick(1);
            restored.step();
            assert.strictEqual(restored.getState(), State.SUCCEEDED);
        });

        it("will start a new run with a full duration if the tree had finished", () => {
            const original = new BehaviourTree("root { wait [1000] }", {}, {});
            original.step();
            clock.tick(1000);
            original.step();
            assert.strictEqual(original.getState(), State.SUCCEEDED);

            clock.tick(50000);

            const restored = new BehaviourTree("root { wait [1000] }", {}, {});
            restored.restore(roundTripSnapshot(original.snapshot()));
            assert.strictEqual(restored.getState(), State.SUCCEEDED);

            assert.strictEqual(stepAndGetState(restored), State.RUNNING);
            clock.tick(999);
            assert.strictEqual(stepAndGetState(restored), State.RUNNING);
            clock.tick(1);
            assert.strictEqual(stepAndGetState(restored), State.SUCCEEDED);
        });

        it("will not snapshot a negative waited duration if the clock goes backwards", () => {
            clock.setSystemTime(10000);
            const original = new BehaviourTree("root { wait [1000] }", {}, {});
            original.step();
            clock.setSystemTime(2000);

            const snapshot = roundTripSnapshot(original.snapshot());
            assert.include(findNodeSnapshot(snapshot, "wait"), { waitedDuration: 0 });

            const restored = new BehaviourTree("root { wait [1000] }", {}, {});
            restored.restore(snapshot);
            clock.tick(999);
            assert.strictEqual(stepAndGetState(restored), State.RUNNING);
            clock.tick(1);
            assert.strictEqual(stepAndGetState(restored), State.SUCCEEDED);
        });

        describe("will error and leave the tree unchanged if a running node has a total duration that does not agree with its definition", () => {
            const cases: [string, string, any, string][] = [
                ["an explicit duration that is different", "root { wait [1000] }", 2000, "to be 1000"],
                ["an explicit duration that is null", "root { wait [1000] }", null, "to be 1000"],
                ["a range that is null", "root { wait [100, 500] }", null, "to be a number"],
                ["no duration that is a number", "root { wait }", 1000, "to be null"]
            ];

            cases.forEach(([description, definition, value, expected]) => {
                it(`with ${description}`, () => {
                    const original = new BehaviourTree(definition, {}, {});
                    original.step();
                    const snapshot = JSON.parse(JSON.stringify(original.snapshot()));
                    snapshot.root.children[0].totalDuration = value;

                    const tree = new BehaviourTree(definition, {}, {});
                    const snapshotBefore = tree.snapshot();

                    assert.throws(
                        () => tree.restore(snapshot),
                        Error,
                        "invalid snapshot: expected 'totalDuration' " + expected
                    );

                    assert.deepEqual(tree.snapshot(), snapshotBefore);
                });
            });
        });

        describe("will error and leave the tree unchanged if the snapshot node has", () => {
            const createSnapshot = () => {
                const tree = new BehaviourTree("root { wait [1000] }", {}, {});
                tree.step();
                return JSON.parse(JSON.stringify(tree.snapshot()));
            };

            const invalidValues: [string, string, any, string][] = [
                ["a total duration that is not an integer", "totalDuration", 0.5, "a non-negative integer or null"],
                ["a total duration that is negative", "totalDuration", -1, "a non-negative integer or null"],
                ["a total duration that is a string", "totalDuration", "1000", "a non-negative integer or null"],
                ["a total duration that is undefined", "totalDuration", undefined, "a non-negative integer or null"],
                ["a waited duration that is a string", "waitedDuration", "1", "a non-negative finite number"],
                ["a waited duration that is null", "waitedDuration", null, "a non-negative finite number"],
                ["a waited duration that is undefined", "waitedDuration", undefined, "a non-negative finite number"],
                ["a waited duration that is infinite", "waitedDuration", Infinity, "a non-negative finite number"],
                ["a waited duration that is not a number", "waitedDuration", NaN, "a non-negative finite number"],
                ["a waited duration that is negative", "waitedDuration", -1, "a non-negative finite number"]
            ];

            invalidValues.forEach(([description, property, value, expected]) => {
                it(description, () => {
                    const tree = new BehaviourTree("root { wait [1000] }", {}, {});
                    const snapshotBefore = tree.snapshot();
                    const snapshot = createSnapshot();
                    snapshot.root.children[0][property] = value;

                    assert.throws(
                        () => tree.restore(snapshot),
                        Error,
                        "invalid snapshot: expected '" + property + "' to be " + expected + " at 'root > wait'"
                    );

                    assert.deepEqual(tree.snapshot(), snapshotBefore);
                });
            });
        });
    });

    describe("behaves as the original tree would when a snapshot of the tree is restored at any point", () => {
        const functions = {
            A: (tick: number) => (tick % 4 === 0 ? State.SUCCEEDED : State.RUNNING),
            B: () => State.SUCCEEDED
        };

        [false, true].forEach((useDeltaTime) => {
            describe(useDeltaTime ? "using the 'getDeltaTime' option" : "using the clock", () => {
                it("with an explicit duration", () => {
                    assertSnapshotRestoresAtEveryStep({
                        definition: "root { sequence { wait [350] action [A] wait [200] } }",
                        functions,
                        steps: 14,
                        useDeltaTime
                    });
                });

                it("with a random duration", () => {
                    assertSnapshotRestoresAtEveryStep({
                        definition: "root { repeat [3] { sequence { wait [100, 500] action [B] } } }",
                        functions,
                        random: [0.99, 0, 0.5],
                        steps: 24,
                        useDeltaTime
                    });
                });

                it("with no duration, which waits until it is aborted", () => {
                    assertSnapshotRestoresAtEveryStep({
                        definition: "root { race { wait action [A] } }",
                        functions,
                        steps: 6,
                        useDeltaTime
                    });
                });

                it("with parallel waits that are aborted by another node", () => {
                    assertSnapshotRestoresAtEveryStep({
                        definition: "root { race { wait [1000] wait [250] sequence { wait [100] action [B] } } }",
                        functions,
                        steps: 6,
                        useDeltaTime
                    });
                    assertSnapshotRestoresAtEveryStep({
                        definition: "root { parallel { wait [550] wait [250] action [A] } }",
                        functions,
                        steps: 10,
                        useDeltaTime
                    });
                });
            });
        });
    });
});
