import {
    AnyNodeDefinition,
    BranchNodeDefinition,
    NodeAttributeDefinition,
    NodeGuardDefinition,
    RootNodeDefinition
} from "./BehaviourTreeDefinition";
import { createRootNodeDefinitionMap, MAIN_ROOT_NODE_KEY } from "./BehaviourTreeBuilder";
import { isCompositeNodeDefinition, isDecoratorNodeDefinition, isInteger } from "./BehaviourTreeDefinitionUtilities";

/**
 * Creates an identifier of a tree definition, which is the same for any two definitions that build the same tree.
 * An MDSL definition and its equivalent JSON definition have the same identifier, however the properties of the JSON are ordered and whether or not the
 * optional properties that have a default are written out. Subtrees are resolved, including those that are globally registered at the time of the call.
 * @param definition The root node definitions, which must have been validated and be able to be built into a tree.
 * @returns An identifier of the definition.
 */
export function createDefinitionFingerprint(definition: RootNodeDefinition[]): string {
    const rootNodeDefinitionMap = createRootNodeDefinitionMap(definition);

    const describeNode = (node: AnyNodeDefinition): unknown => {
        // A branch is built as the child of the root node of the subtree that it references, and takes nothing else from the branch or the subtree root.
        if (node.type === "branch") {
            return describeNode(rootNodeDefinitionMap[node.ref].child);
        }

        return {
            type: node.type,
            while: describeGuard(node.while),
            until: describeGuard(node.until),
            entry: describeAttribute(node.entry),
            step: describeAttribute(node.step),
            exit: describeAttribute(node.exit),
            ...describeNodeSpecifics(node),
            children: isCompositeNodeDefinition(node)
                ? node.children.map(describeNode)
                : isDecoratorNodeDefinition(node)
                ? [describeNode(node.child)]
                : null
        };
    };

    return hash(JSON.stringify(describeNode(rootNodeDefinitionMap[MAIN_ROOT_NODE_KEY])));
}

/**
 * Describes the properties that are specific to the type of a node, applying the defaults for any that are optional.
 */
function describeNodeSpecifics(node: Exclude<AnyNodeDefinition, BranchNodeDefinition>): object {
    switch (node.type) {
        case "action":
        case "condition":
            return { call: node.call, args: node.args ?? [] };
        case "wait":
            return { duration: describeCount(node.duration) };
        case "repeat":
            return { iterations: describeCount(node.iterations) };
        case "retry":
            return { attempts: describeCount(node.attempts) };
        case "lotto":
            return { weights: node.weights ?? null };
        default:
            return {};
    }
}

/**
 * Describes an attribute definition, applying the defaults for any optional properties.
 */
function describeAttribute(attribute: NodeAttributeDefinition | undefined) {
    return attribute ? { call: attribute.call, args: attribute.args ?? [] } : null;
}

/**
 * Describes a guard definition, applying the defaults for any optional properties.
 */
function describeGuard(guard: NodeGuardDefinition | undefined) {
    return guard ? { ...describeAttribute(guard), succeedOnAbort: !!guard.succeedOnAbort } : null;
}

/**
 * Describes an explicit count or duration, or a range, in the way that a node is built from it, which is null if it is not one of the two.
 */
function describeCount(value: number | [number, number] | undefined) {
    if (Array.isArray(value)) {
        return [value[0], value[1]];
    }

    return isInteger(value) ? value : null;
}

/**
 * Creates a 53 bit hash of a string (cyrb53), as a string.
 */
function hash(text: string): string {
    let h1 = 0xdeadbeef;
    let h2 = 0x41c6ce57;

    for (let index = 0; index < text.length; index++) {
        const code = text.charCodeAt(index);
        h1 = Math.imul(h1 ^ code, 2654435761);
        h2 = Math.imul(h2 ^ code, 1597334677);
    }

    h1 = Math.imul(h1 ^ (h1 >>> 16), 2246822507) ^ Math.imul(h2 ^ (h2 >>> 13), 3266489909);
    h2 = Math.imul(h2 ^ (h2 >>> 16), 2246822507) ^ Math.imul(h1 ^ (h1 >>> 13), 3266489909);

    return (4294967296 * (2097151 & h2) + (h1 >>> 0)).toString(16);
}
