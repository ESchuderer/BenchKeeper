import { AnyState } from "./State";

/**
 * The properties common to the snapshot of every node.
 */
type BaseNodeSnapshot<Type extends string> = {
    /**
     * The node type.
     */
    type: Type;
    /**
     * The state of the node.
     */
    state: AnyState;
};

/**
 * The snapshot of a node that has no state beyond its own state and that of its children.
 */
export type SimpleNodeSnapshot =
    | (BaseNodeSnapshot<
          "root" | "flip" | "succeed" | "fail" | "sequence" | "selector" | "parallel" | "race" | "all"
      > & {
          /**
           * The snapshots of the child nodes, in the order that they are defined.
           */
          children: NodeSnapshot[];
      })
    | BaseNodeSnapshot<"condition">;

/**
 * The snapshot of a repeat node.
 */
export type RepeatNodeSnapshot = BaseNodeSnapshot<"repeat"> & {
    /**
     * The snapshots of the child nodes, in the order that they are defined.
     */
    children: NodeSnapshot[];
    /**
     * The number of iterations completed so far.
     */
    currentIterationCount: number;
    /**
     * The number of iterations to complete, which is null if the node repeats indefinitely or has not yet started.
     * If the node was defined with minimum and maximum iterations then this is the count that was randomly picked.
     */
    targetIterationCount: number | null;
};

/**
 * The snapshot of a retry node.
 */
export type RetryNodeSnapshot = BaseNodeSnapshot<"retry"> & {
    /**
     * The snapshots of the child nodes, in the order that they are defined.
     */
    children: NodeSnapshot[];
    /**
     * The number of attempts made so far.
     */
    currentAttemptCount: number;
    /**
     * The number of attempts to make, which is null if the node retries indefinitely or has not yet started.
     * If the node was defined with minimum and maximum attempts then this is the count that was randomly picked.
     */
    targetAttemptCount: number | null;
};

/**
 * The snapshot of a lotto node.
 */
export type LottoNodeSnapshot = BaseNodeSnapshot<"lotto"> & {
    /**
     * The snapshots of the child nodes, in the order that they are defined.
     */
    children: NodeSnapshot[];
    /**
     * The index of the child that was randomly picked as the active one, which is null if no child has been picked.
     */
    selectedChildIndex: number | null;
};

/**
 * The snapshot of a wait node.
 */
export type WaitNodeSnapshot = BaseNodeSnapshot<"wait"> & {
    /**
     * The total duration in milliseconds that the node will wait for, which is null if it waits indefinitely or has not yet started.
     * If the node was defined with minimum and maximum durations then this is the duration that was randomly picked.
     */
    totalDuration: number | null;
    /**
     * The duration in milliseconds that the node has waited for as of when the snapshot was taken.
     */
    waitedDuration: number;
};

/**
 * The snapshot of an action node.
 */
export type ActionNodeSnapshot = BaseNodeSnapshot<"action"> & {
    /**
     * The result of the promise returned by the action function, if it has settled but has not yet been handled by an update of the node.
     * The value is the resolved state, or the resolved value or rejection reason as a string if it is not a valid state.
     * An action that is waiting for a promise that has not settled is saved as not yet started, with a state of READY and no promise result.
     */
    updatePromiseResult: { isResolved: boolean; value: string } | null;
};

/**
 * The snapshot of the execution state of a node in a behaviour tree.
 * Nodes are identified by their position in the tree, and a snapshot can only be restored to a tree built from the same definition.
 */
export type NodeSnapshot =
    | SimpleNodeSnapshot
    | RepeatNodeSnapshot
    | RetryNodeSnapshot
    | LottoNodeSnapshot
    | WaitNodeSnapshot
    | ActionNodeSnapshot;

/**
 * The execution state of a behaviour tree, as returned by `BehaviourTree.snapshot()`.
 * This is a plain object that can be passed through `JSON.stringify` and `JSON.parse` without any change.
 */
export type BehaviourTreeSnapshot = {
    /**
     * The version of the snapshot format.
     */
    version: 1;
    /**
     * An identifier of the definition of the tree that the snapshot was taken from, which is the same for an MDSL definition and its equivalent JSON definition.
     * A snapshot can only be restored to a tree with the same identifier.
     */
    definition: string;
    /**
     * The snapshot of the root node of the tree.
     */
    root: NodeSnapshot;
};

/**
 * The current version of the snapshot format.
 */
export const SNAPSHOT_VERSION = 1;
