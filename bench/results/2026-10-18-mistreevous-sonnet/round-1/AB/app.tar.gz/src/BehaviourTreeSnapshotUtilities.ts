import { AnyState, State } from "./State";

/**
 * Something that can validate the snapshot of a node.
 */
type SnapshotValidator = {
    validateSnapshot(snapshot: unknown, path: string): void;
};

/**
 * Creates the error to throw for a problem found at the specified path of a snapshot.
 * @param path The path of the node, e.g. 'root.children[0]'.
 * @param message The description of the problem.
 */
export function createSnapshotError(path: string, message: string): Error {
    return new Error(`${path}: ${message}`);
}

/**
 * Gets whether the specified value is a non-null object that is not an array.
 * @param value The value to check.
 */
export function isSnapshotObject(value: unknown): value is Record<string, unknown> {
    return typeof value === "object" && value !== null && !Array.isArray(value);
}

/**
 * Gets whether the specified value is a valid node state.
 * @param value The value to check.
 */
export function isSnapshotState(value: unknown): value is AnyState {
    return Object.values(State).includes(value as State);
}

/**
 * Validates the child node snapshots against the child nodes that they are to be restored to.
 * @param path The path of the parent node.
 * @param children The child nodes.
 * @param snapshots The value of the 'children' property of the parent node snapshot.
 */
export function validateChildSnapshots(path: string, children: SnapshotValidator[], snapshots: unknown): void {
    if (!Array.isArray(snapshots)) {
        throw createSnapshotError(path, `expected ${children.length} children but got none`);
    }

    if (snapshots.length !== children.length) {
        throw createSnapshotError(path, `expected ${children.length} children but got ${snapshots.length}`);
    }

    children.forEach((child, index) => child.validateSnapshot(snapshots[index], `${path}.children[${index}]`));
}

/**
 * Gets whether the specified value is a valid iteration or attempt count, which is a non-negative integer.
 * @param value The value to check.
 */
export function isSnapshotCount(value: unknown): value is number {
    return Number.isInteger(value) && (value as number) >= 0;
}

/**
 * Validates the current and target counts in the snapshot of a node that repeats or retries its child.
 * @param snapshot The node snapshot.
 * @param path The path of the node in the tree.
 * @param keys The names of the snapshot properties holding the current count and the target count.
 * @param bounds The explicit count, or minimum and maximum counts, defined for the node, or all null if there are none.
 * @param name The name of the node.
 */
export function validateCountSnapshot(
    snapshot: Record<string, unknown>,
    path: string,
    keys: { current: string; target: string },
    bounds: { count: number | null; min: number | null; max: number | null },
    name: string
): void {
    const current = snapshot[keys.current];
    const target = snapshot[keys.target];

    if (!isSnapshotCount(current)) {
        throw createSnapshotError(path, `invalid ${keys.current} '${current}'`);
    }

    if (target !== null && !isSnapshotCount(target)) {
        throw createSnapshotError(path, `invalid ${keys.target} '${target}'`);
    }

    // The target is only picked once a node starts running, so it is not meaningful for any other state.
    if (snapshot.state !== State.RUNNING) {
        return;
    }

    if (!isPickedValuePossible(target, bounds)) {
        throw createSnapshotError(path, `${keys.target} '${target}' is not valid for '${name}'`);
    }

    if (target !== null && current > target) {
        throw createSnapshotError(path, `${keys.current} '${current}' is above ${keys.target} '${target}'`);
    }
}

/**
 * Gets whether the specified value is a valid duration in milliseconds, which is a finite non-negative number.
 * @param value The value to check.
 */
export function isSnapshotDuration(value: unknown): value is number {
    return typeof value === "number" && Number.isFinite(value) && value >= 0;
}

/**
 * Gets whether a value that a node picks when it starts, like a target count or duration, is possible for how the node is defined.
 * @param value The value picked, or null if no value is picked.
 * @param bounds The explicit value, or minimum and maximum values, defined for the node, or all null if there are none.
 */
export function isPickedValuePossible(
    value: unknown,
    bounds: { count: number | null; min: number | null; max: number | null }
): boolean {
    if (bounds.count !== null) {
        return value === bounds.count;
    }

    if (bounds.min !== null && bounds.max !== null) {
        return typeof value === "number" && value >= bounds.min && value <= bounds.max;
    }

    return value === null;
}

/**
 * Gets whether the specified value is a finite number.
 * @param value The value to check.
 */
export function isSnapshotFiniteNumber(value: unknown): value is number {
    return typeof value === "number" && Number.isFinite(value);
}
