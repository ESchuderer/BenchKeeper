import { BehaviourTreeOptions } from "../../BehaviourTreeOptions";
import { NodeDetails } from "../Node";
import State, { AnyState, CompleteState } from "../../State";
import { ActionNodeSnapshot, NodeSnapshot } from "../../BehaviourTreeSnapshot";
import { createSnapshotError, isSnapshotObject } from "../../BehaviourTreeSnapshotUtilities";
import { Agent } from "../../Agent";
import Leaf from "./Leaf";
import Lookup from "../../Lookup";
import Attribute from "../../attributes/Attribute";

/**
 * The type representing a resolved/rejected update promise.
 */
type UpdatePromiseResult = {
    /**
     * Whether the promise was resolved rather than rejected.
     */
    isResolved: boolean;

    /**
     * The promise resolved value or rejection reason.
     */
    value: any;
};

/**
 * An Action leaf node.
 * This represents an immediate or ongoing state of behaviour.
 */
export default class Action extends Leaf {
    /**
     * @param attributes The node attributes.
     * @param options The behaviour tree options.
     * @param actionName The action name.
     * @param actionArguments The array of action arguments.
     */
    constructor(
        attributes: Attribute[],
        options: BehaviourTreeOptions,
        private actionName: string,
        public actionArguments: any[]
    ) {
        super("action", attributes, options);
    }

    /**
     * Whether there is a pending update promise.
     */
    private isUsingUpdatePromise = false;

    /**
     * The update promise that was returned by the action function, if one is still of interest to this node.
     */
    private updatePromise: Promise<CompleteState> | null = null;

    /**
     * The finished state result of an update promise.
     */
    private updatePromiseResult: UpdatePromiseResult | null = null;

    /**
     * Called when the node is being updated.
     * @param agent The agent.
     */
    protected onUpdate(agent: Agent): void {
        // If the result of this action depends on an update promise then there is nothing to do until it settles.
        if (this.isUsingUpdatePromise) {
            // Are we still waiting for our update promise to settle?
            if (!this.updatePromiseResult) {
                return;
            }

            const { isResolved, value } = this.updatePromiseResult;

            // Our update promise settled, was it resolved or rejected?
            if (isResolved) {
                // Our promise resolved so check to make sure the result is a valid finished state.
                if (value !== State.SUCCEEDED && value !== State.FAILED) {
                    throw new Error(
                        "action node promise resolved with an invalid value, expected a State.SUCCEEDED or State.FAILED value to be returned"
                    );
                }

                // Set the state of this node to match the state returned by the promise.
                this.setState(value);

                return;
            } else {
                // The promise was rejected, which isn't great.
                throw new Error(`action function '${this.actionName}' promise rejected with '${value}'`);
            }
        }

        // Attempt to get the invoker for the action function.
        const actionFuncInvoker = Lookup.getFuncInvoker(agent, this.actionName);

        // The action function should be defined.
        if (actionFuncInvoker === null) {
            throw new Error(
                `cannot update action node as the action '${this.actionName}' function is not defined on the agent and has not been registered`
            );
        }

        let actionFunctionResult;

        try {
            // Call the action function, the result of which may be:
            // - The finished state of this action node.
            // - A promise to return a finished node state.
            // - Undefined if the node should remain in the running state.
            actionFunctionResult = actionFuncInvoker(this.actionArguments) as CompleteState | Promise<CompleteState>;
        } catch (error) {
            // An uncaught error was thrown.
            if (error instanceof Error) {
                throw new Error(`action function '${this.actionName}' threw: ${error.stack}`);
            } else {
                throw new Error(`action function '${this.actionName}' threw: ${error}`);
            }
        }

        if (actionFunctionResult instanceof Promise) {
            const updatePromise = actionFunctionResult;

            updatePromise.then(
                (result) => {
                    // If this is no longer our update promise then it was cleared as it was resolving, probably via an abort, reset or restore.
                    if (this.updatePromise !== updatePromise) {
                        return;
                    }

                    // Set the resolved update promise result so that it can be handled on the next update of this node.
                    this.updatePromiseResult = {
                        isResolved: true,
                        value: result
                    };
                },
                (reason) => {
                    // If this is no longer our update promise then it was cleared as it was resolving, probably via an abort, reset or restore.
                    if (this.updatePromise !== updatePromise) {
                        return;
                    }

                    // Set the rejected update promise result so that it can be handled on the next update of this node.
                    this.updatePromiseResult = {
                        isResolved: false,
                        value: reason
                    };
                }
            );

            // This node will be in the 'RUNNING' state until the update promise resolves.
            this.setState(State.RUNNING);

            // We are now waiting for the promise returned by the use to resolve before we know what state this node is in.
            this.isUsingUpdatePromise = true;
            this.updatePromise = updatePromise;
        } else {
            // Validate the returned value.
            this.validateUpdateResult(actionFunctionResult);

            // Set the state of this node, this may be undefined, which just means that the node is still in the 'RUNNING' state.
            this.setState(actionFunctionResult || State.RUNNING);
        }
    }

    /**
     * Gets the name of the node.
     */
    getName = () => this.actionName;

    /**
     * Reset the state of the node.
     */
    reset = () => {
        // Reset the state of this node.
        this.setState(State.READY);

        // There is no longer an update promise that we care about.
        this.isUsingUpdatePromise = false;
        this.updatePromise = null;
        this.updatePromiseResult = null;
    };

    /**
     * Gets the details of this node instance.
     * @returns The details of this node instance.
     */
    public getDetails(): NodeDetails {
        return {
            ...super.getDetails(),
            args: this.actionArguments
        };
    }

    /**
     * Called when the state of this node changes.
     * @param previousState The previous node state.
     */
    protected onStateChanged(previousState: State): void {
        this.options.onNodeStateChange?.({
            id: this.uid,
            type: this.getType(),
            args: this.actionArguments,
            while: this.attributes.while?.getDetails(),
            until: this.attributes.until?.getDetails(),
            entry: this.attributes.entry?.getDetails(),
            step: this.attributes.step?.getDetails(),
            exit: this.attributes.exit?.getDetails(),
            previousState,
            state: this.getState()
        });
    }

    /**
     * Gets the state of this node to put in its snapshot.
     * @returns The state of this node to put in its snapshot.
     */
    protected getSnapshotState(): AnyState {
        // A promise cannot be saved, so an action that is waiting for one is saved as not yet started and will call its action function again once restored.
        return this.isWaitingForPendingPromise() ? State.READY : this.getState();
    }

    /**
     * Gets the node type specific properties of the snapshot of this node, in addition to the type and state.
     * @returns The node type specific properties of the snapshot of this node.
     */
    protected getSnapshotData(): object {
        // The result of an update promise is only of interest to an action that is still running, as it is waiting to be handled by the next update.
        // If the promise has not settled then there is no result to save, and the action is saved as not yet started.
        if (!this.is(State.RUNNING) || !this.isUsingUpdatePromise || !this.updatePromiseResult) {
            return { updatePromiseResult: null };
        }

        // The value is only used as a state, or in the message of an error if it is a rejection reason or is not a valid state.
        const { isResolved, value } = this.updatePromiseResult;

        let text: string;

        try {
            text = String(value);
        } catch {
            text = "[value that cannot be converted to a string]";
        }

        return { updatePromiseResult: { isResolved, value: text } };
    }

    /**
     * Validates the node type specific properties of the specified snapshot, throwing an error if they cannot be restored to this node.
     * @param snapshot The node snapshot with a valid type and state.
     * @param path The path of this node in the tree, for use in error messages.
     */
    protected validateSnapshotData(snapshot: Record<string, unknown>, path: string): void {
        const { updatePromiseResult } = snapshot;

        if (updatePromiseResult === null) {
            return;
        }

        if (
            !isSnapshotObject(updatePromiseResult) ||
            typeof updatePromiseResult.isResolved !== "boolean" ||
            typeof updatePromiseResult.value !== "string"
        ) {
            throw createSnapshotError(path, `invalid updatePromiseResult '${updatePromiseResult}'`);
        }

        if (snapshot.state !== State.RUNNING) {
            throw createSnapshotError(path, "updatePromiseResult is only valid for a running action");
        }
    }

    /**
     * Restores the node type specific properties of the specified snapshot to this node.
     * @param snapshot The validated node snapshot.
     */
    protected applySnapshotData(snapshot: NodeSnapshot): void {
        const { updatePromiseResult } = snapshot as ActionNodeSnapshot;

        // Any promise that is still pending will no longer be of any interest to this node.
        this.isUsingUpdatePromise = updatePromiseResult !== null;
        this.updatePromise = null;
        this.updatePromiseResult = updatePromiseResult && { ...updatePromiseResult };
    }

    /**
     * Gets whether this node is running and waiting for an update promise that has not yet settled.
     */
    private isWaitingForPendingPromise(): boolean {
        return this.is(State.RUNNING) && this.isUsingUpdatePromise && !this.updatePromiseResult;
    }

    /**
     * Validate the result of an update function call.
     * @param result The result of an update function call.
     */
    private validateUpdateResult = (result: CompleteState | State.RUNNING) => {
        switch (result) {
            case State.SUCCEEDED:
            case State.FAILED:
            case State.RUNNING:
            case undefined:
                return;
            default:
                throw new Error(
                    `expected action function '${this.actionName}' to return an optional State.SUCCEEDED or State.FAILED value but returned '${result}'`
                );
        }
    };
}
