import Leaf from "./Leaf";
import State from "../../State";
import { NodeSnapshot, WaitNodeSnapshot } from "../../BehaviourTreeSnapshot";
import {
    createSnapshotError,
    isPickedValuePossible,
    isSnapshotDuration,
    isSnapshotFiniteNumber
} from "../../BehaviourTreeSnapshotUtilities";
import Attribute from "../../attributes/Attribute";
import { Agent } from "../../Agent";
import { BehaviourTreeOptions } from "../../BehaviourTreeOptions";

/**
 * A WAIT node.
 * The state of this node will change to SUCCEEDED after a duration of time
 */
export default class Wait extends Leaf {
    /**
     * @param attributes The node attributes.
     * @param options The behaviour tree options.
     * @param duration The duration that this node will wait to succeed in milliseconds.
     * @param durationMin The minimum possible duration in milliseconds that this node will wait to succeed.
     * @param durationMax The maximum possible duration in milliseconds that this node will wait to succeed.
     */
    constructor(
        attributes: Attribute[],
        options: BehaviourTreeOptions,
        private duration: number | null,
        private durationMin: number | null,
        private durationMax: number | null
    ) {
        super("wait", attributes, options);
    }

    /**
     * The time in milliseconds at which this node was first updated.
     */
    private initialUpdateTime: number = 0;

    /**
     * The total duration in milliseconds that this node will be waiting for.
     */
    private totalDuration: number | null = null;

    /**
     * The duration in milliseconds that this node has been waiting for.
     */
    private waitedDuration: number = 0;

    /**
     * Whether this node was restored from a snapshot and has not been updated since, which means that `waitedDuration` is the duration waited as of the snapshot.
     */
    private isRestored: boolean = false;

    /**
     * Called when the node is being updated.
     * @param agent The agent.
     */
    protected onUpdate(agent: Agent): void {
        // The time that has passed since this node was restored is now counted in the usual way.
        this.isRestored = false;

        // If this node is in the READY state then we need to set the initial update time.
        if (this.is(State.READY)) {
            // Set the initial update time.
            this.initialUpdateTime = new Date().getTime();

            // Set the initial waited duration.
            this.waitedDuration = 0;

            // Are we dealing with an explicit duration or will we be randomly picking a duration between the min and max duration.
            if (this.duration !== null) {
                this.totalDuration = this.duration;
            } else if (this.durationMin !== null && this.durationMax !== null) {
                // We will be picking a random duration between a min and max duration, if the optional 'random' behaviour tree
                // function option is defined then we will be using that, otherwise we will fall back to using Math.random.
                const random = typeof this.options.random === "function" ? this.options.random : Math.random;

                // Pick a random duration between a min and max duration.
                this.totalDuration = Math.floor(
                    random() * (this.durationMax - this.durationMin + 1) + this.durationMin
                );
            } else {
                this.totalDuration = null;
            }

            // The node is now running until we finish waiting.
            this.setState(State.RUNNING);
        }

        // If we have no total duration then this wait node will wait indefinitely until it is aborted.
        if (this.totalDuration === null) {
            return;
        }

        // If we have a 'getDeltaTime' function defined as part of our options then we will use it to figure out how long we have waited for.
        if (typeof this.options.getDeltaTime === "function") {
            // Get the delta time.
            const deltaTime = this.options.getDeltaTime();

            // Our delta time must be a valid number and cannot be NaN.
            if (typeof deltaTime !== "number" || isNaN(deltaTime)) {
                throw new Error("The delta time must be a valid number and not NaN.");
            }

            // Update the amount of time that this node has been waiting for based on the delta time.
            this.waitedDuration += deltaTime * 1000;
        } else {
            // We are not using a delta time, so we will just work out hom much time has passed since the first update.
            this.waitedDuration = new Date().getTime() - this.initialUpdateTime;
        }

        // Have we waited long enough?
        if (this.waitedDuration >= this.totalDuration) {
            // We have finished waiting!
            this.setState(State.SUCCEEDED);
        }
    }

    /**
     * Gets the name of the node.
     */
    getName = () => {
        if (this.duration !== null) {
            return `WAIT ${this.duration}ms`;
        } else if (this.durationMin !== null && this.durationMax !== null) {
            return `WAIT ${this.durationMin}ms-${this.durationMax}ms`;
        } else {
            return "WAIT";
        }
    };

    /**
     * Gets the duration in milliseconds that this node has been waiting for.
     * @returns The duration in milliseconds that this node has been waiting for.
     */
    private getWaitedDuration(): number {
        // If the clock is being used then time will have passed since the last update that has not yet been counted.
        // That is not the case if this node was only just restored, as then the duration waited is that of the snapshot until the node is next updated.
        const waitedDuration =
            this.is(State.RUNNING) && !this.isRestored && typeof this.options.getDeltaTime !== "function"
                ? new Date().getTime() - this.initialUpdateTime
                : this.waitedDuration;

        // A snapshot cannot hold an infinite number, which a delta time can add up to, so use the closest number that it can.
        return Math.max(-Number.MAX_VALUE, Math.min(Number.MAX_VALUE, waitedDuration));
    }

    /**
     * Gets the node type specific properties of the snapshot of this node, in addition to the type and state.
     * @returns The node type specific properties of the snapshot of this node.
     */
    protected getSnapshotData(): object {
        // The durations of a node that is ready are left over from a previous run, and are set again when it is next updated.
        if (this.is(State.READY)) {
            return { totalDuration: null, waitedDuration: 0 };
        }

        return { totalDuration: this.totalDuration, waitedDuration: this.getWaitedDuration() };
    }

    /**
     * Validates the node type specific properties of the specified snapshot, throwing an error if they cannot be restored to this node.
     * @param snapshot The node snapshot with a valid type and state.
     * @param path The path of this node in the tree, for use in error messages.
     */
    protected validateSnapshotData(snapshot: Record<string, unknown>, path: string): void {
        const { totalDuration, waitedDuration } = snapshot;

        if (totalDuration !== null && !isSnapshotDuration(totalDuration)) {
            throw createSnapshotError(path, `invalid totalDuration '${totalDuration}'`);
        }

        if (!isSnapshotFiniteNumber(waitedDuration)) {
            throw createSnapshotError(path, `invalid waitedDuration '${waitedDuration}'`);
        }

        // The total duration is only picked once a node starts running, so it is not meaningful for any other state.
        if (snapshot.state !== State.RUNNING) {
            return;
        }

        const bounds = { count: this.duration, min: this.durationMin, max: this.durationMax };

        if (!isPickedValuePossible(totalDuration, bounds)) {
            throw createSnapshotError(path, `totalDuration '${totalDuration}' is not valid for '${this.getName()}'`);
        }
    }

    /**
     * Restores the node type specific properties of the specified snapshot to this node.
     * @param snapshot The validated node snapshot.
     */
    protected applySnapshotData(snapshot: NodeSnapshot): void {
        const { totalDuration, waitedDuration } = snapshot as WaitNodeSnapshot;

        this.totalDuration = totalDuration;
        this.waitedDuration = waitedDuration;
        this.isRestored = true;

        // The time that passed since the snapshot was taken does not count, so the wait is treated as having started the duration waited ago.
        this.initialUpdateTime = new Date().getTime() - waitedDuration;
    }
}
