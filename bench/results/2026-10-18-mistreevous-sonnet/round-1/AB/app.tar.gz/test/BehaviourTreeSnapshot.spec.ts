import { assert } from "chai";
import sinon from "sinon";

import { BehaviourTree, BehaviourTreeSnapshot, State, convertMDSLToJSON } from "../src/index";
import { Agent } from "../src/Agent";
import { RootNodeDefinition } from "../src/BehaviourTreeDefinition";

import { findNode, withoutIds } from "./TestUtilities";

/**
 * Creates an agent that logs every function call and which has actions/conditions that are controlled by the specified flags.
 * @param log The array to which every agent function call will be logged.
 * @param flags The flags controlling the results of the agent functions.
 */
function createAgent(log: string[], flags: { [key: string]: boolean } = {}): Agent {
    const action = (name: string) => () => {
        log.push(name);
        return flags[name] ? State.SUCCEEDED : undefined;
    };

    return {
        A: action("A"),
        B: action("B"),
        C: action("C"),
        Pass: () => {
            log.push("Pass");
            return true;
        },
        Fail: () => {
            log.push("Fail");
            return false;
        },
        Fails: () => {
            log.push("Fails");
            return State.FAILED;
        }
    };
}

/**
 * Takes a snapshot of the tree and passes it through JSON serialisation, as it would be if it were stored by an application.
 */
function roundTrip(tree: BehaviourTree): BehaviourTreeSnapshot {
    return JSON.parse(JSON.stringify(tree.snapshot()));
}

describe("A BehaviourTree", () => {
    describe("snapshot", () => {
        it("returns a plain object that is unchanged by a JSON round trip, whatever the state of the tree", () => {
            const flags: { [key: string]: boolean } = { A: true };
            const tree = new BehaviourTree(
                "root { sequence { action [A] parallel { action [B] condition [Pass] } action [C] } }",
                createAgent([], flags)
            );

            const snapshots = [tree.snapshot()];

            tree.step();
            snapshots.push(tree.snapshot());

            flags["B"] = true;
            flags["C"] = true;
            tree.step();
            snapshots.push(tree.snapshot());

            assert.strictEqual(tree.getState(), State.SUCCEEDED);

            for (const snapshot of snapshots) {
                assert.deepEqual(JSON.parse(JSON.stringify(snapshot)), snapshot);
            }
        });

        it("has a version, a definition and a root node snapshot that mirrors the shape of the tree", () => {
            const tree = new BehaviourTree(
                "root { sequence { condition [Pass] flip { condition [Fail] } condition [Pass] } }",
                createAgent([])
            );

            tree.step();

            const { definition, ...snapshot } = tree.snapshot();

            assert.isString(definition);
            assert.deepEqual(snapshot, {
                version: 1,
                root: {
                    type: "root",
                    state: State.SUCCEEDED,
                    children: [
                        {
                            type: "sequence",
                            state: State.SUCCEEDED,
                            children: [
                                { type: "condition", state: State.SUCCEEDED },
                                {
                                    type: "flip",
                                    state: State.SUCCEEDED,
                                    children: [{ type: "condition", state: State.FAILED }]
                                },
                                { type: "condition", state: State.SUCCEEDED }
                            ]
                        }
                    ]
                }
            });
        });

        it("is not affected by later steps of the tree", () => {
            const flags: { [key: string]: boolean } = { A: false };
            const tree = new BehaviourTree("root { sequence { action [A] action [B] } }", createAgent([], flags));

            tree.step();

            const snapshot = tree.snapshot();
            const serialised = JSON.stringify(snapshot);

            flags["A"] = true;
            tree.step();
            tree.reset();

            assert.strictEqual(JSON.stringify(snapshot), serialised);
        });

        it("is the same for a tree that has been reset as for a tree that has never been stepped", () => {
            const tree = new BehaviourTree(
                "root { sequence { repeat [1, 3] { action [A] } lotto { action [B] action [C] } wait [10, 20] } }",
                createAgent([]),
                { random: () => 0.5 }
            );
            const untouched = new BehaviourTree(
                "root { sequence { repeat [1, 3] { action [A] } lotto { action [B] action [C] } wait [10, 20] } }",
                createAgent([]),
                { random: () => 0.5 }
            );

            tree.step();
            tree.reset();

            assert.deepEqual(tree.snapshot(), untouched.snapshot());
        });

        it("does not call any agent function or option function", () => {
            const log: string[] = [];
            let optionCalls = 0;
            const tree = new BehaviourTree(
                "root { sequence { action [A] wait [100] } }",
                createAgent(log, { A: true }),
                {
                    getDeltaTime: () => (optionCalls++, 0.01),
                    random: () => (optionCalls++, 0.5)
                }
            );

            tree.step();
            log.length = 0;
            optionCalls = 0;

            tree.snapshot();

            assert.deepEqual(log, []);
            assert.strictEqual(optionCalls, 0);
        });
    });

    describe("restore", () => {
        describe("sets a tree built from the same definition to the state of the tree the snapshot was taken from", () => {
            const definitions: [string, string, { [key: string]: boolean }][] = [
                ["sequence", "root { sequence { condition [Pass] action [A] action [B] } }", { A: true }],
                ["selector", "root { selector { condition [Fail] action [A] action [B] } }", { A: false }],
                ["parallel", "root { parallel { action [A] action [B] action [C] } }", { A: true }],
                ["race", "root { race { action [A] action [B] action [C] } }", { B: false }],
                ["all", "root { all { action [A] action [B] action [C] } }", { A: true, B: true }],
                ["flip", "root { sequence { flip { condition [Fail] } flip { action [A] } } }", { A: false }],
                ["succeed", "root { sequence { succeed { condition [Fail] } succeed { action [A] } } }", {}],
                ["fail", "root { sequence { fail { condition [Pass] } fail { action [A] } } }", {}]
            ];

            for (const [name, definition, flags] of definitions) {
                it(`(${name})`, () => {
                    const original = new BehaviourTree(definition, createAgent([], flags));
                    const restored = new BehaviourTree(definition, createAgent([]));

                    original.step();
                    restored.restore(roundTrip(original));

                    assert.deepEqual(
                        withoutIds(restored.getTreeNodeDetails()),
                        withoutIds(original.getTreeNodeDetails())
                    );
                    assert.deepEqual(restored.snapshot(), original.snapshot());
                });
            }
        });

        describe("makes the tree call the same agent functions in the same order and get the same result as the tree the snapshot was taken from", () => {
            const definitions: [string, string][] = [
                ["sequence", "root { sequence { condition [Pass] action [A] action [B] action [C] } }"],
                ["selector", "root { selector { condition [Fail] action [A] action [B] action [C] } }"],
                ["parallel", "root { parallel { action [A] action [B] action [C] } }"],
                ["race", "root { race { action [A] action [B] action [C] } }"],
                ["all", "root { all { action [A] action [B] action [C] } }"],
                ["flip", "root { flip { action [A] } }"],
                [
                    "nested",
                    "root { sequence { action [A] parallel { sequence { action [B] action [C] } action [A] } } }"
                ]
            ];

            for (const [name, definition] of definitions) {
                it(`(${name})`, () => {
                    const originalLog: string[] = [];
                    const restoredLog: string[] = [];
                    const flags: { [key: string]: boolean } = { A: true };

                    const original = new BehaviourTree(definition, createAgent(originalLog, flags));
                    const restored = new BehaviourTree(definition, createAgent(restoredLog, flags));

                    original.step();
                    const snapshot = roundTrip(original);
                    originalLog.length = 0;

                    // Let the tree move on with more of its nodes completing on each step.
                    const steps: { [key: string]: boolean }[] = [{ A: true, B: true }, { C: true }, { A: false }, {}];

                    const run = (tree: BehaviourTree) => {
                        const states: State[] = [];
                        for (const step of steps) {
                            Object.assign(flags, step);
                            tree.step();
                            states.push(tree.getState());
                        }
                        return states;
                    };

                    const originalStates = run(original);
                    Object.assign(flags, { A: true, B: false, C: false });

                    restored.restore(snapshot);
                    const restoredStates = run(restored);

                    assert.deepEqual(restoredLog, originalLog);
                    assert.deepEqual(restoredStates, originalStates);
                });
            }
        });

        it("does not call any agent function", () => {
            const log: string[] = [];
            const tree = new BehaviourTree(
                "root { sequence { action [A] action [B] } }",
                createAgent(log, { A: true })
            );

            tree.step();
            const snapshot = tree.snapshot();
            log.length = 0;

            tree.restore(snapshot);

            assert.deepEqual(log, []);
        });

        it("replaces whatever state the tree was already in, including a running state", () => {
            const flags: { [key: string]: boolean } = { A: true };
            const definition = "root { sequence { action [A] action [B] action [C] } }";
            const original = new BehaviourTree(definition, createAgent([], flags));
            const target = new BehaviourTree(definition, createAgent([], flags));

            original.step();
            const snapshot = original.snapshot();

            // Take the target further than the original, and then to a finished state.
            target.step();
            Object.assign(flags, { B: true, C: true });
            target.step();
            assert.strictEqual(target.getState(), State.SUCCEEDED);

            target.restore(snapshot);
            assert.deepEqual(withoutIds(target.getTreeNodeDetails()), withoutIds(original.getTreeNodeDetails()));

            // The same tree can also be rewound to an earlier state.
            const fresh = new BehaviourTree(definition, createAgent([], flags));
            const freshSnapshot = fresh.snapshot();
            target.restore(freshSnapshot);
            assert.deepEqual(withoutIds(target.getTreeNodeDetails()), withoutIds(fresh.getTreeNodeDetails()));
        });

        it("restores a finished tree as finished, and the next step starts a new run", () => {
            for (const [state, definition] of [
                [State.SUCCEEDED, "root { sequence { action [A] action [B] } }"],
                [State.FAILED, "root { sequence { action [A] action [Fails] } }"]
            ] as [State, string][]) {
                const originalLog: string[] = [];
                const restoredLog: string[] = [];
                const original = new BehaviourTree(definition, createAgent(originalLog, { A: true, B: true }));
                const restored = new BehaviourTree(definition, createAgent(restoredLog, { A: true, B: true }));

                original.step();
                assert.strictEqual(original.getState(), state);

                restored.restore(roundTrip(original));
                assert.strictEqual(restored.getState(), state);
                assert.isFalse(restored.isRunning());
                assert.deepEqual(withoutIds(restored.getTreeNodeDetails()), withoutIds(original.getTreeNodeDetails()));

                // Nothing should have been called by the restore, the next step is a whole new run.
                assert.deepEqual(restoredLog, []);

                originalLog.length = 0;
                original.step();
                restored.step();

                assert.deepEqual(originalLog.slice(0, 1), ["A"]);
                assert.deepEqual(restoredLog, originalLog);
                assert.strictEqual(restored.getState(), original.getState());
            }
        });

        it("does not call the 'onNodeStateChange' option, and the next step reports changes as usual", () => {
            const definition = "root { sequence { action [A] action [B] } }";
            const flags: { [key: string]: boolean } = { A: true };
            const original = new BehaviourTree(definition, createAgent([], flags));
            const changes: [string, State, State][] = [];
            const restored = new BehaviourTree(definition, createAgent([], flags), {
                onNodeStateChange: ({ type, previousState, state }) => changes.push([type, previousState, state])
            });

            original.step();
            restored.restore(original.snapshot());

            assert.deepEqual(changes, []);

            flags["B"] = true;
            restored.step();

            assert.deepEqual(changes, [
                ["action", State.RUNNING, State.SUCCEEDED],
                ["sequence", State.RUNNING, State.SUCCEEDED],
                ["root", State.RUNNING, State.SUCCEEDED]
            ]);
        });

        it("does not hold on to the snapshot that was passed in", () => {
            const flags: { [key: string]: boolean } = { A: false };
            const definition = "root { sequence { action [A] action [B] } }";
            const original = new BehaviourTree(definition, createAgent([], flags));
            const restored = new BehaviourTree(definition, createAgent([], flags));

            original.step();
            const snapshot = original.snapshot();
            restored.restore(snapshot);

            const before = JSON.stringify(restored.snapshot());

            (snapshot.root as any).state = State.FAILED;
            (snapshot.root as any).children[0].children.length = 0;

            assert.strictEqual(JSON.stringify(restored.snapshot()), before);
        });

        describe("will error and leave the tree as it was if", () => {
            const definition = "root { sequence { action [A] parallel { action [B] condition [Pass] } } }";
            const create = () => {
                const tree = new BehaviourTree(definition, createAgent([], { B: false }));
                tree.step();
                return tree;
            };
            const valid = (): any => JSON.parse(JSON.stringify(create().snapshot()));

            const invalid: [string, any, string][] = [
                ["the snapshot is not an object", "snapshot", "invalid snapshot: expected an object"],
                ["the snapshot is null", null, "invalid snapshot: expected an object"],
                [
                    "the version is not supported",
                    { ...valid(), version: 2 },
                    "invalid snapshot: unsupported version '2'"
                ],
                [
                    "the root node is missing",
                    (({ root, ...rest }) => rest)(valid()),
                    "invalid snapshot: root: expected an object"
                ],
                [
                    "a node type does not match the tree",
                    (() => {
                        const snapshot = valid();
                        snapshot.root.children[0].children[1].type = "selector";
                        return snapshot;
                    })(),
                    "invalid snapshot: root.children[0].children[1]: expected a 'parallel' node but got 'selector'"
                ],
                [
                    "the number of children does not match the tree",
                    (() => {
                        const snapshot = valid();
                        snapshot.root.children[0].children[1].children.pop();
                        return snapshot;
                    })(),
                    "invalid snapshot: root.children[0].children[1]: expected 2 children but got 1"
                ],
                [
                    "a node has no children array when it should",
                    (() => {
                        const snapshot = valid();
                        delete snapshot.root.children;
                        return snapshot;
                    })(),
                    "invalid snapshot: root: expected 1 children but got none"
                ],
                [
                    "a node state is not valid",
                    (() => {
                        const snapshot = valid();
                        snapshot.root.children[0].state = "mistreevous.nonsense";
                        return snapshot;
                    })(),
                    "invalid snapshot: root.children[0]: invalid state 'mistreevous.nonsense'"
                ]
            ];

            for (const [name, snapshot, message] of invalid) {
                it(name, () => {
                    const tree = create();
                    const before = JSON.stringify(tree.snapshot());

                    assert.throws(() => tree.restore(snapshot), Error, message);
                    assert.strictEqual(JSON.stringify(tree.snapshot()), before);
                });
            }
        });
    });
});

/**
 * A seedable pseudo-random number generator whose position can be copied.
 */
class Random {
    calls = 0;
    state: number;

    constructor(state: number) {
        this.state = state;
    }

    next = (): number => {
        this.calls++;
        this.state = (this.state + 0x6d2b79f5) | 0;
        let t = Math.imul(this.state ^ (this.state >>> 15), 1 | this.state);
        t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
        return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
}

/**
 * The outcome of one run of a tree over some steps.
 */
type Run = {
    /**
     * Every agent function call, with the step it was made in.
     */
    log: string[];
    /**
     * The tree node details (without node ids) after each step.
     */
    details: unknown[];
    /**
     * The number of calls made to the 'random' option.
     */
    randomCalls: number;
    /**
     * The serialised snapshot of the tree at the end of the run.
     */
    snapshot: string;
};

type FutureScenario = {
    definition: string;
    /**
     * The result of the specified action name on the specified step, with undefined meaning that it is still running.
     */
    outcome?: (name: number, step: number) => State | undefined;
    /**
     * The number of steps to take before taking the snapshot.
     */
    warmupSteps: number;
    /**
     * The number of steps to take after taking the snapshot.
     */
    steps: number;
    seed?: number;
    /**
     * How the elapsed time of 'wait' nodes is measured. With 'date' the clock is faked and moves forward by 100ms on every step,
     * and a long time passes between the snapshot being taken and restored. With 'delta' the 'getDeltaTime' option returns 0.1.
     */
    timing?: "date" | "delta";
    /**
     * The fake clock to use with 'date' timing if the test has already installed one.
     */
    clock?: sinon.SinonFakeTimers;
};

/**
 * Runs a tree for some steps, takes a snapshot, then runs the tree for more steps. The snapshot is then restored to a
 * new tree which runs the same remaining steps, with any randomness continuing from the same point.
 * @returns The runs of the original tree and the restored tree after the snapshot was taken.
 */
function runAndRestore(scenario: FutureScenario): { original: Run; restored: Run; snapshot: BehaviourTreeSnapshot } {
    const outcome = scenario.outcome ?? (() => State.SUCCEEDED);
    const seed = scenario.seed ?? 1;
    const clock = scenario.timing === "date" ? scenario.clock ?? sinon.useFakeTimers() : undefined;
    let step = 0;

    const createRun = (random: Random) => {
        const log: string[] = [];
        const call = (name: string, args: any[]) =>
            log.push(`${step}:${name}(${args.map((arg) => JSON.stringify(arg)).join(",")})`);
        const agent: Agent = {
            Work: (name: number) => {
                call("Work", [name]);
                return outcome(name, step);
            },
            Check: (name: number) => {
                call("Check", [name]);
                return outcome(name, step) === State.SUCCEEDED;
            },
            Notify: (name: number, ...rest: any[]) => call("Notify", [name, ...rest])
        };
        const tree = new BehaviourTree(scenario.definition, agent, {
            random: random.next,
            getDeltaTime: scenario.timing === "delta" ? () => 0.1 : undefined
        });
        return { tree, log, random };
    };

    const runSteps = ({ tree, log, random }: ReturnType<typeof createRun>, count: number): Run => {
        const details: unknown[] = [];
        const randomCallsBefore = random.calls;
        log.length = 0;

        for (let index = 0; index < count; index++) {
            step++;
            clock?.tick(100);
            tree.step();
            details.push(withoutIds(tree.getTreeNodeDetails()));
        }

        return {
            log: [...log],
            details,
            randomCalls: random.calls - randomCallsBefore,
            snapshot: JSON.stringify(tree.snapshot())
        };
    };

    try {
        const originalRun = createRun(new Random(seed));
        runSteps(originalRun, scenario.warmupSteps);

        const snapshot = JSON.parse(JSON.stringify(originalRun.tree.snapshot())) as BehaviourTreeSnapshot;
        const snapshotStep = step;
        const randomState = originalRun.random.state;

        const original = runSteps(originalRun, scenario.steps);

        // The restored tree has its own agent and random number generator, starting at the same point as the original had at the snapshot.
        step = snapshotStep;
        clock?.setSystemTime(clock.now + 10_000_000);
        const restoredRun = createRun(new Random(randomState));
        restoredRun.tree.restore(snapshot);
        const restored = runSteps(restoredRun, scenario.steps);

        return { original, restored, snapshot };
    } finally {
        if (clock !== scenario.clock) {
            clock?.restore();
        }
    }
}

describe("A BehaviourTree restored from a snapshot", () => {
    const assertSameFuture = (scenario: FutureScenario) => {
        const { original, restored } = runAndRestore(scenario);

        assert.isAbove(original.log.length, 0, "the scenario should call agent functions after the snapshot");
        assert.deepEqual(restored.log, original.log);
        assert.deepEqual(restored.details, original.details);
        assert.strictEqual(restored.randomCalls, original.randomCalls);
    };

    describe("with a repeat node", () => {
        it("has a snapshot that records the current and target iteration counts", () => {
            const tree = new BehaviourTree("root { repeat [3] { action [Work, 1] } }", { Work: () => State.SUCCEEDED });
            const repeat = () => (tree.snapshot().root as any).children[0];

            assert.deepEqual(repeat(), {
                type: "repeat",
                state: State.READY,
                children: [{ type: "action", state: State.READY, updatePromiseResult: null }],
                currentIterationCount: 0,
                targetIterationCount: null
            });

            tree.step();
            tree.step();

            assert.include(repeat(), { state: State.RUNNING, currentIterationCount: 2, targetIterationCount: 3 });
        });

        it("keeps its iteration count", () => {
            for (let warmupSteps = 0; warmupSteps <= 4; warmupSteps++) {
                assertSameFuture({
                    definition: "root { repeat [3] { action [Work, 1] } }",
                    warmupSteps,
                    steps: 6
                });
            }
        });

        it("keeps the progress of its child within the current iteration", () => {
            for (let warmupSteps = 0; warmupSteps <= 8; warmupSteps++) {
                assertSameFuture({
                    definition: "root { repeat [2] { sequence { action [Work, 1] action [Work, 2] } } }",
                    outcome: (name, step) => (step % 2 === (name === 1 ? 0 : 1) ? State.SUCCEEDED : undefined),
                    warmupSteps,
                    steps: 10
                });
            }
        });

        it("keeps an infinite repeat running", () => {
            assertSameFuture({
                definition: "root { repeat { action [Work, 1] } }",
                warmupSteps: 3,
                steps: 4
            });
        });

        it("keeps the iteration count that was randomly picked and does not pick another until a new run starts", () => {
            const definition = "root { repeat [2, 6] { action [Work, 1] } }";

            for (let seed = 1; seed <= 5; seed++) {
                for (let warmupSteps = 0; warmupSteps <= 5; warmupSteps++) {
                    assertSameFuture({ definition, warmupSteps, steps: 25, seed });
                }
            }
        });

        it("uses the iteration count picked before the snapshot rather than the one its own 'random' would pick", () => {
            const definition = "root { repeat [2, 5] { action [Work, 1] } }";
            const calls: number[] = [];
            const agent = { Work: () => (calls.push(calls.length), State.SUCCEEDED) };

            // Picks the minimum iteration count of 2.
            const original = new BehaviourTree(definition, agent, { random: () => 0 });
            original.step();

            // Would pick the maximum iteration count of 5.
            const restoredCalls: number[] = [];
            const restored = new BehaviourTree(
                definition,
                { Work: () => (restoredCalls.push(restoredCalls.length), State.SUCCEEDED) },
                { random: () => 0.99 }
            );
            restored.restore(original.snapshot());

            restored.step(); // The second iteration.
            assert.strictEqual(restored.getState(), State.RUNNING);
            restored.step(); // The repeat has no more iterations.
            assert.strictEqual(restored.getState(), State.SUCCEEDED);
            assert.strictEqual(restoredCalls.length, 1);

            // A new run makes a new random choice.
            for (let count = 1; count <= 5; count++) {
                restored.step();
                assert.strictEqual(restored.getState(), State.RUNNING);
            }
            restored.step();
            assert.strictEqual(restored.getState(), State.SUCCEEDED);
        });

        it("ends as it would have if it had already completed its iterations and fails if its child fails", () => {
            assertSameFuture({
                definition: "root { repeat [5] { action [Work, 1] } }",
                outcome: (name, step) => (step < 3 ? State.SUCCEEDED : State.FAILED),
                warmupSteps: 3,
                steps: 4
            });
        });
    });

    describe("with a retry node", () => {
        it("has a snapshot that records the current and target attempt counts", () => {
            const tree = new BehaviourTree("root { retry [3] { action [Work, 1] } }", { Work: () => State.FAILED });
            const retry = () => (tree.snapshot().root as any).children[0];

            assert.deepEqual(retry(), {
                type: "retry",
                state: State.READY,
                children: [{ type: "action", state: State.READY, updatePromiseResult: null }],
                currentAttemptCount: 0,
                targetAttemptCount: null
            });

            tree.step();
            tree.step();

            assert.include(retry(), { state: State.RUNNING, currentAttemptCount: 2, targetAttemptCount: 3 });
        });

        it("keeps its attempt count", () => {
            for (let warmupSteps = 0; warmupSteps <= 4; warmupSteps++) {
                assertSameFuture({
                    definition: "root { retry [3] { action [Work, 1] } }",
                    outcome: () => State.FAILED,
                    warmupSteps,
                    steps: 6
                });
            }
        });

        it("keeps the progress of its child within the current attempt", () => {
            for (let warmupSteps = 0; warmupSteps <= 8; warmupSteps++) {
                assertSameFuture({
                    definition: "root { retry [2] { sequence { action [Work, 1] action [Work, 2] } } }",
                    outcome: (name, step) => (name === 1 ? State.SUCCEEDED : step % 2 ? undefined : State.FAILED),
                    warmupSteps,
                    steps: 10
                });
            }
        });

        it("keeps the attempt count that was randomly picked and does not pick another until a new run starts", () => {
            const definition = "root { retry [2, 6] { action [Work, 1] } }";

            for (let seed = 1; seed <= 5; seed++) {
                for (let warmupSteps = 0; warmupSteps <= 5; warmupSteps++) {
                    assertSameFuture({ definition, outcome: () => State.FAILED, warmupSteps, steps: 25, seed });
                }
            }
        });

        it("uses the attempt count picked before the snapshot rather than the one its own 'random' would pick", () => {
            const definition = "root { retry [2, 5] { action [Work, 1] } }";
            const agent = { Work: () => State.FAILED };

            const original = new BehaviourTree(definition, agent, { random: () => 0 });
            original.step();

            const restored = new BehaviourTree(definition, agent, { random: () => 0.99 });
            restored.restore(original.snapshot());

            restored.step(); // The second attempt.
            assert.strictEqual(restored.getState(), State.RUNNING);
            restored.step(); // The retry has no more attempts.
            assert.strictEqual(restored.getState(), State.FAILED);
        });
    });

    describe("with a lotto node", () => {
        it("has a snapshot that records the selected child", () => {
            const tree = new BehaviourTree(
                "root { lotto [1, 1, 1] { action [Work, 1] action [Work, 2] action [Work, 3] } }",
                {
                    Work: () => undefined
                },
                { random: () => 0.9 }
            );
            const lotto = () => (tree.snapshot().root as any).children[0];

            assert.include(lotto(), { type: "lotto", state: State.READY, selectedChildIndex: null });

            tree.step();

            assert.include(lotto(), { state: State.RUNNING, selectedChildIndex: 2 });
        });

        it("keeps its selected child and does not pick another until a new run starts", () => {
            const definition =
                "root { lotto [3, 1, 2, 1] { action [Work, 1] action [Work, 2] action [Work, 3] action [Work, 4] } }";

            for (let seed = 1; seed <= 8; seed++) {
                for (let warmupSteps = 1; warmupSteps <= 4; warmupSteps++) {
                    assertSameFuture({
                        definition,
                        outcome: (name, step) => (step % 3 === 0 ? State.SUCCEEDED : undefined),
                        warmupSteps,
                        steps: 20,
                        seed
                    });
                }
            }
        });

        it("uses the child selected before the snapshot rather than the one its own 'random' would pick", () => {
            const definition = "root { lotto { action [Work, 1] action [Work, 2] } }";
            const calls: number[] = [];
            const agent = { Work: (name: number) => (calls.push(name), undefined) };

            const original = new BehaviourTree(definition, agent, { random: () => 0.9 });
            original.step();
            assert.deepEqual(calls, [2]);

            calls.length = 0;
            const restored = new BehaviourTree(definition, agent, { random: () => 0 });
            restored.restore(original.snapshot());
            restored.step();
            restored.step();

            assert.deepEqual(calls, [2, 2]);
        });

        it("keeps a selected child that is nested within other nodes", () => {
            for (let warmupSteps = 1; warmupSteps <= 6; warmupSteps++) {
                assertSameFuture({
                    definition:
                        "root { sequence { lotto { sequence { action [Work, 1] action [Work, 2] } sequence { action [Work, 3] action [Work, 4] } } action [Work, 5] } }",
                    outcome: (name, step) => (step % 2 ? undefined : State.SUCCEEDED),
                    warmupSteps,
                    steps: 12,
                    seed: 4
                });
            }
        });
    });

    describe("will error and leave the tree as it was if the snapshot", () => {
        const create = (definition: string) =>
            new BehaviourTree(definition, { Work: () => undefined }, { random: () => 0 });
        const cases: [string, string, (snapshot: any) => void, string][] = [
            [
                "has a repeat node with an iteration count that is not an integer",
                "root { repeat [3] { action [Work, 1] } }",
                (snapshot) => (snapshot.root.children[0].currentIterationCount = 1.5),
                "invalid snapshot: root.children[0]: invalid currentIterationCount '1.5'"
            ],
            [
                "has a repeat node with a negative iteration count",
                "root { repeat [3] { action [Work, 1] } }",
                (snapshot) => (snapshot.root.children[0].currentIterationCount = -1),
                "invalid snapshot: root.children[0]: invalid currentIterationCount '-1'"
            ],
            [
                "has a running repeat node with an iteration count above its target",
                "root { repeat [3] { action [Work, 1] } }",
                (snapshot) => (snapshot.root.children[0].currentIterationCount = 4),
                "invalid snapshot: root.children[0]: currentIterationCount '4' is above targetIterationCount '3'"
            ],
            [
                "has a running repeat node with a target that does not match its definition",
                "root { repeat [3] { action [Work, 1] } }",
                (snapshot) => (snapshot.root.children[0].targetIterationCount = 5),
                "invalid snapshot: root.children[0]: targetIterationCount '5' is not valid for 'REPEAT 3x'"
            ],
            [
                "has a running repeat node with a target outside the range of its definition",
                "root { repeat [2, 4] { action [Work, 1] } }",
                (snapshot) => (snapshot.root.children[0].targetIterationCount = 5),
                "invalid snapshot: root.children[0]: targetIterationCount '5' is not valid for 'REPEAT 2x-4x'"
            ],
            [
                "has a running infinite repeat node with a target",
                "root { repeat { action [Work, 1] } }",
                (snapshot) => (snapshot.root.children[0].targetIterationCount = 2),
                "invalid snapshot: root.children[0]: targetIterationCount '2' is not valid for 'REPEAT'"
            ],
            [
                "has a running retry node with a target that does not match its definition",
                "root { retry [3] { action [Work, 1] } }",
                (snapshot) => (snapshot.root.children[0].targetAttemptCount = null),
                "invalid snapshot: root.children[0]: targetAttemptCount 'null' is not valid for 'RETRY 3x'"
            ],
            [
                "has a retry node with an attempt count that is not a number",
                "root { retry [3] { action [Work, 1] } }",
                (snapshot) => (snapshot.root.children[0].currentAttemptCount = "1"),
                "invalid snapshot: root.children[0]: invalid currentAttemptCount '1'"
            ],
            [
                "has a running lotto node without a selected child",
                "root { lotto { action [Work, 1] action [Work, 2] } }",
                (snapshot) => (snapshot.root.children[0].selectedChildIndex = null),
                "invalid snapshot: root.children[0]: a running lotto node must have a selectedChildIndex"
            ],
            [
                "has a lotto node with a selected child that does not exist",
                "root { lotto { action [Work, 1] action [Work, 2] } }",
                (snapshot) => (snapshot.root.children[0].selectedChildIndex = 2),
                "invalid snapshot: root.children[0]: invalid selectedChildIndex '2'"
            ]
        ];

        for (const [name, definition, corrupt, message] of cases) {
            it(name, () => {
                const tree = create(definition);
                tree.step();
                const snapshot = JSON.parse(JSON.stringify(tree.snapshot()));
                corrupt(snapshot);

                const target = create(definition);
                target.step();
                target.step();
                const before = JSON.stringify(target.snapshot());

                assert.throws(() => target.restore(snapshot), Error, message);
                assert.strictEqual(JSON.stringify(target.snapshot()), before);
            });
        }
    });
});

describe("A BehaviourTree with a wait node restored from a snapshot", () => {
    let clock: sinon.SinonFakeTimers;

    beforeEach(() => {
        clock = sinon.useFakeTimers();
    });

    afterEach(() => {
        clock.restore();
    });

    const waitSnapshot = (tree: BehaviourTree) => (tree.snapshot().root as any).children[0];

    it("has a snapshot that records the total and waited durations", () => {
        const tree = new BehaviourTree("root { wait [1000] }", {});

        assert.deepEqual(waitSnapshot(tree), {
            type: "wait",
            state: State.READY,
            totalDuration: null,
            waitedDuration: 0
        });

        tree.step();
        clock.tick(300);

        // The duration waited is as of the snapshot being taken, not the last step.
        assert.deepEqual(waitSnapshot(tree), {
            type: "wait",
            state: State.RUNNING,
            totalDuration: 1000,
            waitedDuration: 300
        });
    });

    describe("using the clock", () => {
        it("only waits for the remaining time, however long it was between taking the snapshot and restoring it", () => {
            const original = new BehaviourTree("root { wait [1000] }", {});

            original.step();
            clock.tick(400);
            original.step();

            const snapshot = JSON.parse(JSON.stringify(original.snapshot()));

            // The process is down for a long time.
            clock.tick(5 * 24 * 60 * 60 * 1000);

            const restored = new BehaviourTree("root { wait [1000] }", {});
            restored.restore(snapshot);

            restored.step();
            assert.strictEqual(restored.getState(), State.RUNNING);

            clock.tick(500);
            restored.step();
            assert.strictEqual(restored.getState(), State.RUNNING);

            clock.tick(99);
            restored.step();
            assert.strictEqual(restored.getState(), State.RUNNING);

            clock.tick(1);
            restored.step();
            assert.strictEqual(restored.getState(), State.SUCCEEDED);
        });

        it("counts the time that passed between the last step and taking the snapshot", () => {
            const original = new BehaviourTree("root { wait [1000] }", {});

            original.step();
            clock.tick(600);

            const snapshot = original.snapshot();

            clock.tick(1000000);

            const restored = new BehaviourTree("root { wait [1000] }", {});
            restored.restore(snapshot);

            clock.tick(399);
            restored.step();
            assert.strictEqual(restored.getState(), State.RUNNING);

            clock.tick(1);
            restored.step();
            assert.strictEqual(restored.getState(), State.SUCCEEDED);
        });

        it("can be restored to the tree that the snapshot was taken from", () => {
            const tree = new BehaviourTree("root { wait [1000] }", {});

            tree.step();
            clock.tick(200);
            const snapshot = tree.snapshot();

            clock.tick(700);
            tree.restore(snapshot);

            clock.tick(700);
            tree.step();
            assert.strictEqual(tree.getState(), State.RUNNING);

            clock.tick(100);
            tree.step();
            assert.strictEqual(tree.getState(), State.SUCCEEDED);
        });

        it("starts waiting again from the snapshot if the tree was already part way through a wait", () => {
            const target = new BehaviourTree("root { wait [1000] }", {});
            target.step();
            clock.tick(900);

            const fresh = new BehaviourTree("root { wait [1000] }", {});
            fresh.step();

            target.restore(fresh.snapshot());
            clock.tick(500);
            target.step();

            assert.strictEqual(target.getState(), State.RUNNING);
        });

        it("makes the same agent calls as the original after waits within a sequence", () => {
            for (let warmupSteps = 0; warmupSteps <= 12; warmupSteps++) {
                const { original, restored } = runAndRestore({
                    definition:
                        "root { sequence { action [Work, 1] wait [250] action [Work, 2] wait [150, 450] action [Work, 3] } }",
                    timing: "date",
                    clock,
                    warmupSteps,
                    steps: 15,
                    seed: warmupSteps + 1
                });

                assert.isAbove(original.log.length, 0);
                assert.deepEqual(restored.log, original.log);
                assert.deepEqual(restored.details, original.details);
                assert.strictEqual(restored.randomCalls, original.randomCalls);
            }
        });
    });

    describe("using the 'getDeltaTime' option", () => {
        it("only waits for the remaining time", () => {
            const original = new BehaviourTree("root { wait [1000] }", {}, { getDeltaTime: () => 0.25 });

            original.step();
            original.step();

            const snapshot = JSON.parse(JSON.stringify(original.snapshot()));

            // No time passes in this case as there is no delta time reported, but the clock does move.
            clock.tick(1000000);

            let deltaTimeCalls = 0;
            const restored = new BehaviourTree(
                "root { wait [1000] }",
                {},
                { getDeltaTime: () => (deltaTimeCalls++, 0.25) }
            );
            restored.restore(snapshot);
            assert.strictEqual(deltaTimeCalls, 0);

            restored.step();
            assert.strictEqual(restored.getState(), State.RUNNING);

            restored.step();
            assert.strictEqual(restored.getState(), State.SUCCEEDED);
            assert.strictEqual(deltaTimeCalls, 2);
        });

        it("makes the same agent calls as the original after waits within a sequence", () => {
            for (let warmupSteps = 0; warmupSteps <= 12; warmupSteps++) {
                const { original, restored } = runAndRestore({
                    definition:
                        "root { sequence { action [Work, 1] wait [250] action [Work, 2] wait [150, 450] action [Work, 3] } }",
                    timing: "delta",
                    clock,
                    warmupSteps,
                    steps: 15,
                    seed: warmupSteps + 1
                });

                assert.isAbove(original.log.length, 0);
                assert.deepEqual(restored.log, original.log);
                assert.deepEqual(restored.details, original.details);
                assert.strictEqual(restored.randomCalls, original.randomCalls);
            }
        });
    });

    it("can be restored to a tree that measures time differently to the one that the snapshot was taken from", () => {
        const original = new BehaviourTree("root { wait [1000] }", {});
        original.step();
        clock.tick(750);

        const deltaTimeTree = new BehaviourTree("root { wait [1000] }", {}, { getDeltaTime: () => 0.1 });
        deltaTimeTree.restore(original.snapshot());
        deltaTimeTree.step();
        deltaTimeTree.step();
        assert.strictEqual(deltaTimeTree.getState(), State.RUNNING);
        deltaTimeTree.step();
        assert.strictEqual(deltaTimeTree.getState(), State.SUCCEEDED);

        const deltaTimeOriginal = new BehaviourTree("root { wait [1000] }", {}, { getDeltaTime: () => 0.4 });
        deltaTimeOriginal.step();
        deltaTimeOriginal.step();

        const clockTree = new BehaviourTree("root { wait [1000] }", {});
        clockTree.restore(deltaTimeOriginal.snapshot());
        clockTree.step();
        assert.strictEqual(clockTree.getState(), State.RUNNING);
        clock.tick(200);
        clockTree.step();
        assert.strictEqual(clockTree.getState(), State.SUCCEEDED);
    });

    it("keeps the duration that was randomly picked and does not pick another until a new run starts", () => {
        for (const timing of ["date", "delta"] as const) {
            for (let seed = 1; seed <= 5; seed++) {
                for (let warmupSteps = 0; warmupSteps <= 4; warmupSteps++) {
                    const { original, restored } = runAndRestore({
                        definition: "root { sequence { wait [100, 900] action [Work, 1] } }",
                        outcome: (name, step) => (step % 4 === 0 ? State.SUCCEEDED : undefined),
                        timing,
                        clock,
                        warmupSteps,
                        steps: 30,
                        seed
                    });

                    assert.isAbove(original.randomCalls, 0, "a new run should pick a new duration");
                    assert.deepEqual(restored.log, original.log);
                    assert.deepEqual(restored.details, original.details);
                    assert.strictEqual(restored.randomCalls, original.randomCalls);
                }
            }
        }
    });

    it("uses the duration picked before the snapshot rather than the one its own 'random' would pick", () => {
        const definition = "root { wait [100, 900] }";

        // Picks the minimum duration of 100ms.
        const original = new BehaviourTree(definition, {}, { random: () => 0 });
        original.step();

        // Would pick the maximum duration of 900ms.
        const restored = new BehaviourTree(definition, {}, { random: () => 0.999 });
        restored.restore(original.snapshot());

        clock.tick(100);
        restored.step();

        assert.strictEqual(restored.getState(), State.SUCCEEDED);
    });

    it("keeps waiting indefinitely if no duration was defined", () => {
        const original = new BehaviourTree("root { wait }", {});
        original.step();
        clock.tick(1000);

        const snapshot = original.snapshot();
        assert.deepEqual(waitSnapshot(original), {
            type: "wait",
            state: State.RUNNING,
            totalDuration: null,
            waitedDuration: 1000
        });

        const restored = new BehaviourTree("root { wait }", {});
        restored.restore(snapshot);
        clock.tick(10000000);
        restored.step();

        assert.strictEqual(restored.getState(), State.RUNNING);
    });

    it("restores a finished wait as finished, and the next step starts a new wait", () => {
        const original = new BehaviourTree("root { wait [100, 300] }", {}, { random: () => 0 });
        original.step();
        clock.tick(100);
        original.step();
        assert.strictEqual(original.getState(), State.SUCCEEDED);

        let randomCalls = 0;
        const restored = new BehaviourTree("root { wait [100, 300] }", {}, { random: () => (randomCalls++, 0.999) });
        restored.restore(original.snapshot());
        assert.strictEqual(restored.getState(), State.SUCCEEDED);
        assert.strictEqual(randomCalls, 0);

        // A new run picks a new duration, which is the maximum of 300ms.
        restored.step();
        assert.strictEqual(randomCalls, 1);
        assert.strictEqual(restored.getState(), State.RUNNING);

        clock.tick(299);
        restored.step();
        assert.strictEqual(restored.getState(), State.RUNNING);

        clock.tick(1);
        restored.step();
        assert.strictEqual(restored.getState(), State.SUCCEEDED);
    });

    describe("will error and leave the tree as it was if the snapshot", () => {
        const create = (definition: string) => {
            const tree = new BehaviourTree(definition, {}, { random: () => 0 });
            tree.step();
            return tree;
        };
        const cases: [string, string, (snapshot: any) => void, string][] = [
            [
                "has a total duration that is not a number",
                "root { wait [1000] }",
                (snapshot) => (snapshot.root.children[0].totalDuration = "1000"),
                "invalid snapshot: root.children[0]: invalid totalDuration '1000'"
            ],
            [
                "has a negative total duration",
                "root { wait [1000] }",
                (snapshot) => (snapshot.root.children[0].totalDuration = -1),
                "invalid snapshot: root.children[0]: invalid totalDuration '-1'"
            ],
            [
                "has a waited duration that is not a number",
                "root { wait [1000] }",
                (snapshot) => (snapshot.root.children[0].waitedDuration = null),
                "invalid snapshot: root.children[0]: invalid waitedDuration 'null'"
            ],
            [
                "has a running wait node with a total duration that does not match its definition",
                "root { wait [1000] }",
                (snapshot) => (snapshot.root.children[0].totalDuration = 2000),
                "invalid snapshot: root.children[0]: totalDuration '2000' is not valid for 'WAIT 1000ms'"
            ],
            [
                "has a running wait node with a total duration outside the range of its definition",
                "root { wait [100, 200] }",
                (snapshot) => (snapshot.root.children[0].totalDuration = 201),
                "invalid snapshot: root.children[0]: totalDuration '201' is not valid for 'WAIT 100ms-200ms'"
            ],
            [
                "has a running wait node with a total duration when none was defined",
                "root { wait }",
                (snapshot) => (snapshot.root.children[0].totalDuration = 100),
                "invalid snapshot: root.children[0]: totalDuration '100' is not valid for 'WAIT'"
            ]
        ];

        for (const [name, definition, corrupt, message] of cases) {
            it(name, () => {
                const snapshot = JSON.parse(JSON.stringify(create(definition).snapshot()));
                corrupt(snapshot);

                const target = create(definition);
                const before = JSON.stringify(target.snapshot());

                assert.throws(() => target.restore(snapshot), Error, message);
                assert.strictEqual(JSON.stringify(target.snapshot()), before);
            });
        }
    });
});

describe("A BehaviourTree with a promise-based action node", () => {
    const definition = "root { sequence { action [Work] action [After] } }";

    /**
     * Creates a tree with an action function that returns a promise that can be settled by the test.
     */
    const create = () => {
        const calls: string[] = [];
        let settle: { resolve(value: unknown): void; reject(reason: unknown): void } = {
            resolve: () => {},
            reject: () => {}
        };
        const agent = {
            Work: () => {
                calls.push("Work");
                return new Promise((resolve, reject) => (settle = { resolve, reject }));
            },
            After: () => {
                calls.push("After");
                return State.SUCCEEDED;
            }
        };

        return { tree: new BehaviourTree(definition, agent), calls, settle: () => settle };
    };

    const actionSnapshot = (tree: BehaviourTree) => (tree.snapshot().root as any).children[0].children[0];

    it("has a snapshot of an action node that records no promise result unless it settled and is waiting to be used", () => {
        const { tree, settle } = create();

        assert.deepEqual(actionSnapshot(tree), { type: "action", state: State.READY, updatePromiseResult: null });

        tree.step();
        settle().resolve(State.SUCCEEDED);

        // We can't tell the promise has settled until we get a chance to handle it.
        return Promise.resolve().then(() => {
            assert.deepEqual(actionSnapshot(tree), {
                type: "action",
                state: State.RUNNING,
                updatePromiseResult: { isResolved: true, value: State.SUCCEEDED }
            });

            tree.step();

            assert.deepEqual(actionSnapshot(tree), {
                type: "action",
                state: State.SUCCEEDED,
                updatePromiseResult: null
            });
        });
    });

    it("can be snapshotted again once the promise is no longer pending", () => {
        const { tree } = create();

        tree.step();
        tree.reset();

        assert.doesNotThrow(() => tree.snapshot());
    });

    it("keeps a resolved promise result and does not call the action function again", async () => {
        const original = create();
        original.tree.step();
        original.settle().resolve(State.SUCCEEDED);
        await Promise.resolve();

        const restored = create();
        restored.tree.restore(JSON.parse(JSON.stringify(original.tree.snapshot())));
        restored.tree.step();

        assert.deepEqual(restored.calls, ["After"]);
        assert.strictEqual(restored.tree.getState(), State.SUCCEEDED);
    });

    it("keeps a resolved promise result of a failure", async () => {
        const original = create();
        original.tree.step();
        original.settle().resolve(State.FAILED);
        await Promise.resolve();

        const restored = create();
        restored.tree.restore(JSON.parse(JSON.stringify(original.tree.snapshot())));
        restored.tree.step();

        assert.deepEqual(restored.calls, []);
        assert.strictEqual(restored.tree.getState(), State.FAILED);
    });

    it("keeps a rejected promise result, which will error on the next step", async () => {
        const original = create();
        original.tree.step();
        original.settle().reject(new Error("boom"));
        await Promise.resolve();

        const restored = create();
        restored.tree.restore(JSON.parse(JSON.stringify(original.tree.snapshot())));

        assert.throws(
            () => restored.tree.step(),
            Error,
            "error stepping tree: action function 'Work' promise rejected with 'Error: boom'"
        );
        assert.deepEqual(restored.calls, []);
    });

    it("keeps a resolved promise result that is not a valid state, which will error on the next step", async () => {
        const original = create();
        original.tree.step();
        original.settle().resolve("nonsense");
        await Promise.resolve();

        const restored = create();
        restored.tree.restore(JSON.parse(JSON.stringify(original.tree.snapshot())));

        assert.throws(
            () => restored.tree.step(),
            Error,
            "action node promise resolved with an invalid value, expected a State.SUCCEEDED or State.FAILED value to be returned"
        );
    });

    it("ignores any promise that was pending in the tree being restored to", async () => {
        const original = create();
        original.tree.step();
        original.tree.reset();
        const snapshot = original.tree.snapshot();

        const target = create();
        target.tree.step();
        target.tree.restore(snapshot);
        target.settle().resolve(State.SUCCEEDED);
        await Promise.resolve();

        // The restored action was never started, so it starts when stepped.
        target.tree.step();
        assert.deepEqual(target.calls, ["Work", "Work"]);
        assert.strictEqual(target.tree.getState(), State.RUNNING);
    });

    describe("will error and leave the tree as it was if the snapshot", () => {
        const cases: [string, (snapshot: any) => void, string][] = [
            [
                "has a promise result that is not an object",
                (snapshot) => (snapshot.root.children[0].children[0].updatePromiseResult = "result"),
                "invalid snapshot: root.children[0].children[0]: invalid updatePromiseResult 'result'"
            ],
            [
                "has a promise result without a boolean 'isResolved'",
                (snapshot) =>
                    (snapshot.root.children[0].children[0].updatePromiseResult = { isResolved: 1, value: "" }),
                "invalid snapshot: root.children[0].children[0]: invalid updatePromiseResult"
            ],
            [
                "has a promise result without a string 'value'",
                (snapshot) =>
                    (snapshot.root.children[0].children[0].updatePromiseResult = { isResolved: true, value: 1 }),
                "invalid snapshot: root.children[0].children[0]: invalid updatePromiseResult"
            ],
            [
                "has a promise result for an action that is not running",
                (snapshot) => {
                    snapshot.root.children[0].children[0].state = State.READY;
                    snapshot.root.children[0].children[0].updatePromiseResult = {
                        isResolved: true,
                        value: State.SUCCEEDED
                    };
                },
                "invalid snapshot: root.children[0].children[0]: updatePromiseResult is only valid for a running action"
            ],
            [
                "has no promise result property",
                (snapshot) => delete snapshot.root.children[0].children[0].updatePromiseResult,
                "invalid snapshot: root.children[0].children[0]: invalid updatePromiseResult 'undefined'"
            ]
        ];

        for (const [name, corrupt, message] of cases) {
            it(name, async () => {
                const original = create();
                original.tree.step();
                original.settle().resolve(State.SUCCEEDED);
                await Promise.resolve();
                const snapshot = JSON.parse(JSON.stringify(original.tree.snapshot()));
                corrupt(snapshot);

                const target = create();
                const before = JSON.stringify(target.tree.snapshot());

                assert.throws(() => target.tree.restore(snapshot), Error, message);
                assert.strictEqual(JSON.stringify(target.tree.snapshot()), before);
            });
        }
    });
});

describe("A BehaviourTree using every node type restored from a snapshot taken at any step", () => {
    const definition = `
        root {
            repeat [1, 2] entry(Notify, 100) exit(Notify, 101) {
                sequence step(Notify, 102) {
                    lotto [1, 2, 1] {
                        action [Work, 1] while(Check, 91)
                        sequence { action [Work, 2] wait [150, 400] }
                        action [Work, 3] entry(Notify, 103)
                    }
                    parallel {
                        action [Work, 4]
                        sequence { wait [200] action [Work, 5] }
                    }
                    selector {
                        condition [Check, 6]
                        retry [1, 3] { action [Work, 7] }
                    }
                    race {
                        action [Work, 8] until(Check, 92) exit(Notify, 105)
                        sequence exit(Notify, 106) { wait [300] action [Work, 9] }
                    }
                    all {
                        action [Work, 10]
                        flip { action [Work, 11] }
                    }
                    succeed { fail { action [Work, 12] exit(Notify, 104) } }
                    branch [Subtree]
                }
            }
        }
        root [Subtree] {
            repeat [2] { sequence { action [Work, 13] wait [100, 250] } }
        }
    `;

    // Each variant gives actions and conditions a different mix of succeeding, failing and running over time.
    const variants: ((name: number, step: number) => State | undefined)[] = [
        (name, step) => ((name + step) % 2 === 0 ? State.SUCCEEDED : undefined),
        (name, step) =>
            (name * 7 + step * 3) % 11 === 0 ? State.FAILED : (name + step) % 2 ? undefined : State.SUCCEEDED,
        (name, step) => [State.FAILED, undefined, undefined, State.SUCCEEDED, State.SUCCEEDED][(name * 3 + step) % 5],
        () => State.SUCCEEDED
    ];

    for (const timing of ["date", "delta"] as const) {
        it(`behaves as the original does, whichever step the snapshot is taken at (${timing})`, function () {
            this.timeout(30000);

            const workCalled = new Set<string>();
            const notifyCalled = new Set<string>();
            let runCount = 0;

            variants.forEach((outcome, variant) => {
                for (let seed = 1; seed <= 2; seed++) {
                    for (let warmupSteps = 0; warmupSteps <= 40; warmupSteps++) {
                        const { original, restored } = runAndRestore({
                            definition,
                            outcome,
                            timing,
                            warmupSteps,
                            steps: 40,
                            seed: seed * 17 + variant
                        });

                        const description = `variant ${variant}, seed ${seed}, snapshot after ${warmupSteps} steps`;
                        assert.deepEqual(restored.log, original.log, description);
                        assert.deepEqual(restored.details, original.details, description);
                        assert.strictEqual(restored.randomCalls, original.randomCalls, description);
                        assert.strictEqual(restored.snapshot, original.snapshot, description);

                        original.log.forEach((entry) => {
                            const call = entry.slice(entry.indexOf(":") + 1);
                            (call.startsWith("Notify") ? notifyCalled : workCalled).add(call);
                        });
                        runCount++;
                    }
                }
            });

            // Make sure that all of the tree is being exercised, otherwise the comparison proves little.
            assert.strictEqual(runCount, 4 * 2 * 41);
            for (let id = 1; id <= 13; id++) {
                const call = id === 6 ? "Check(6)" : `Work(${id})`;
                assert.isTrue(workCalled.has(call), `${call} was never called`);
            }
            for (const id of [100, 101, 102, 103, 104, 105, 106]) {
                const wasCalled = [...notifyCalled].some((call) => new RegExp("[(,]" + id + "\\)$").test(call));
                assert.isTrue(wasCalled, "Notify with " + id + " was never called");
            }
            assert.isTrue(
                [...notifyCalled].some((call) => call.includes('"aborted":true')),
                "no node was aborted"
            );
        });
    }
});

describe("Restoring a snapshot to a BehaviourTree", () => {
    it("restores the whole tree even if an 'onNodeStateChange' handler would throw", () => {
        const definition = "root { sequence { action [Work, 1] action [Work, 2] } }";
        const original = new BehaviourTree(definition, { Work: () => State.SUCCEEDED });
        original.step();

        const target = new BehaviourTree(
            definition,
            { Work: () => undefined },
            {
                onNodeStateChange: () => {
                    throw new Error("handler failed");
                }
            }
        );

        target.restore(original.snapshot());

        assert.deepEqual(withoutIds(target.getTreeNodeDetails()), withoutIds(original.getTreeNodeDetails()));
    });

    it("keeps an accumulated wait duration that is negative or too large to be saved", () => {
        for (const firstDeltaTime of [-0.5, -3, 0.25, Infinity, -Infinity]) {
            let deltaTime = firstDeltaTime;
            const original = new BehaviourTree("root { wait [1000] }", {}, { getDeltaTime: () => deltaTime });
            original.step();

            const snapshot = JSON.parse(JSON.stringify(original.snapshot()));
            const restored = new BehaviourTree("root { wait [1000] }", {}, { getDeltaTime: () => 0.25 });
            restored.restore(snapshot);

            // Whatever the original does with steps of 0.25 seconds, the restored tree must do the same.
            deltaTime = 0.25;
            for (let step = 0; step < 20; step++) {
                original.step();
                restored.step();
                assert.strictEqual(restored.getState(), original.getState(), `delta ${firstDeltaTime}, step ${step}`);
            }
        }
    });
});

describe("A BehaviourTree with a promise-based action node that is restored while its own promise is in flight", () => {
    it("is not affected when the promise that was in flight settles", async () => {
        const definition = "root { action [Work] }";
        const calls: string[] = [];
        let resolveInFlight: (value: State) => void = () => {};
        const create = (result: () => unknown) =>
            new BehaviourTree(definition, { Work: () => (calls.push("Work"), result()) });

        // A snapshot of an action with a settled promise result of 'succeeded'.
        const source = create(() => Promise.resolve(State.SUCCEEDED));
        source.step();
        await Promise.resolve();
        const snapshot = source.snapshot();
        calls.length = 0;

        const target = create(() => new Promise<State>((resolve) => (resolveInFlight = resolve)));
        target.step();
        target.restore(snapshot);

        // The promise that was in flight settles with a different result, after the restore but before the next step.
        resolveInFlight(State.FAILED);
        await Promise.resolve();

        target.step();
        assert.strictEqual(target.getState(), State.SUCCEEDED);
        assert.deepEqual(calls, ["Work"]);
    });

    it("is not affected when the promise that was in flight settles after the action was started again", async () => {
        const resolvers: ((value: State) => void)[] = [];
        const tree = new BehaviourTree("root { action [Work] }", {
            Work: () => new Promise<State>((resolve) => resolvers.push(resolve))
        });

        tree.step();
        tree.reset();
        tree.step();
        assert.strictEqual(resolvers.length, 2);

        // The first promise is no longer of interest, only the second one is.
        resolvers[0](State.FAILED);
        await Promise.resolve();
        tree.step();
        assert.strictEqual(tree.getState(), State.RUNNING);

        resolvers[1](State.SUCCEEDED);
        await Promise.resolve();
        tree.step();
        assert.strictEqual(tree.getState(), State.SUCCEEDED);
    });
});

describe("Taking a snapshot of a BehaviourTree with an action whose promise was rejected with a value that cannot be converted to a string", () => {
    it("does not error, and the restored tree errors on the next step as the original would", async () => {
        const definition = "root { action [Work] }";
        const create = () => new BehaviourTree(definition, { Work: () => Promise.reject(Object.create(null)) });
        const original = create();
        original.step();
        await new Promise((resolve) => setTimeout(resolve, 0));

        let snapshot: BehaviourTreeSnapshot | undefined;
        assert.doesNotThrow(() => (snapshot = JSON.parse(JSON.stringify(original.snapshot()))));

        const restored = create();
        restored.restore(snapshot!);

        assert.throws(() => original.step(), Error, "error stepping tree");
        assert.throws(() => restored.step(), Error, "error stepping tree");
    });
});

describe("A BehaviourTree snapshot", () => {
    const mdsl = `
        root {
            sequence {
                action [Work, 1, "two", true, null, $three]
                lotto [1, 2] {
                    wait [10, 20]
                    repeat [2] { condition [Pass] while(Pass, 1) entry(Enter) }
                }
                retry { action [Work] until(Fail) exit(Leave) }
            }
        }`;

    // The same definition as the MDSL above, written the way that it would be by hand, without any of the optional properties that are not needed.
    const json = {
        type: "root",
        child: {
            type: "sequence",
            children: [
                { type: "action", call: "Work", args: [1, "two", true, null, { $: "three" }] },
                {
                    type: "lotto",
                    weights: [1, 2],
                    children: [
                        { type: "wait", duration: [10, 20] },
                        {
                            type: "repeat",
                            iterations: 2,
                            child: {
                                type: "condition",
                                call: "Pass",
                                while: { call: "Pass", args: [1] },
                                entry: { call: "Enter" }
                            }
                        }
                    ]
                },
                {
                    type: "retry",
                    child: { type: "action", call: "Work", until: { call: "Fail" }, exit: { call: "Leave" } }
                }
            ]
        }
    };

    const agent = (): Agent => ({
        Work: () => State.SUCCEEDED,
        Pass: () => true,
        Fail: () => false,
        Enter: () => {},
        Leave: () => {}
    });

    const definitionOf = (tree: BehaviourTree): unknown => (tree.snapshot() as any).definition;

    afterEach(() => BehaviourTree.unregisterAll());

    it("records which definition it belongs to, as a string that survives a JSON round trip", () => {
        const tree = new BehaviourTree(mdsl, agent());

        assert.isString(definitionOf(tree));
        assert.isNotEmpty(definitionOf(tree));
        assert.strictEqual(roundTrip(tree).definition, definitionOf(tree));
    });

    it("records the same definition whatever the state of the tree", () => {
        const tree = new BehaviourTree(mdsl, agent());
        const before = definitionOf(tree);

        tree.step();
        tree.step();
        tree.reset();

        assert.strictEqual(definitionOf(tree), before);
    });

    it("records the same definition for trees built from the same definition", () => {
        assert.strictEqual(
            definitionOf(new BehaviourTree(mdsl, agent())),
            definitionOf(new BehaviourTree(mdsl, agent()))
        );
    });

    it("records the same definition for an MDSL definition and its equivalent JSON definition", () => {
        const fromMDSL = new BehaviourTree(mdsl, agent());

        assert.strictEqual(definitionOf(new BehaviourTree(json as any, agent())), definitionOf(fromMDSL));
        assert.strictEqual(definitionOf(new BehaviourTree([json] as any, agent())), definitionOf(fromMDSL));
        assert.strictEqual(definitionOf(new BehaviourTree(convertMDSLToJSON(mdsl), agent())), definitionOf(fromMDSL));
    });

    it("records the same definition whatever the order of the properties of the JSON definition", () => {
        const reordered = { child: { children: [{ call: "A", type: "action" }], type: "sequence" }, type: "root" };

        assert.strictEqual(
            definitionOf(new BehaviourTree(reordered as any, agent())),
            definitionOf(new BehaviourTree("root { sequence { action [A] } }", agent()))
        );
    });

    it("records the same definition for subtrees defined in the definition as for the same tree without them", () => {
        assert.strictEqual(
            definitionOf(new BehaviourTree("root { sequence { branch [Sub] } } root [Sub] { action [A] }", agent())),
            definitionOf(new BehaviourTree("root { sequence { action [A] } }", agent()))
        );
    });

    describe("records a different definition when", () => {
        const base = "root { sequence { action [A, 1] wait [10] condition [Pass] } }";

        const changed: [string, string][] = [
            ["an action is called something else", "root { sequence { action [B, 1] wait [10] condition [Pass] } }"],
            ["an argument is different", "root { sequence { action [A, 2] wait [10] condition [Pass] } }"],
            ["an argument is a different type", 'root { sequence { action [A, "1"] wait [10] condition [Pass] } }'],
            ["an argument is an agent property", "root { sequence { action [A, $x] wait [10] condition [Pass] } }"],
            ["a duration is different", "root { sequence { action [A, 1] wait [11] condition [Pass] } }"],
            ["a node is added", "root { sequence { action [A, 1] wait [10] condition [Pass] condition [Pass] } }"],
            ["the order of nodes is different", "root { sequence { wait [10] action [A, 1] condition [Pass] } }"],
            ["a node type is different", "root { selector { action [A, 1] wait [10] condition [Pass] } }"],
            ["a condition is called something else", "root { sequence { action [A, 1] wait [10] condition [Fail] } }"],
            ["a guard is added", "root { sequence { action [A, 1] wait [10] condition [Pass] while(Pass) } }"],
            [
                "a different kind of guard is added",
                "root { sequence { action [A, 1] wait [10] condition [Pass] until(Pass) } }"
            ],
            ["a callback is added", "root { sequence { action [A, 1] wait [10] condition [Pass] entry(Enter) } }"],
            [
                "the node is wrapped in a decorator",
                "root { flip { sequence { action [A, 1] wait [10] condition [Pass] } } }"
            ]
        ];

        for (const [name, other] of changed) {
            it(name, () => {
                assert.notStrictEqual(
                    definitionOf(new BehaviourTree(other, agent())),
                    definitionOf(new BehaviourTree(base, agent()))
                );
            });
        }

        it("the only difference is that a guard succeeds on abort", () => {
            assert.notStrictEqual(
                definitionOf(
                    new BehaviourTree(
                        {
                            type: "root",
                            child: { type: "action", call: "A", while: { call: "Pass", succeedOnAbort: true } }
                        } as any,
                        agent()
                    )
                ),
                definitionOf(
                    new BehaviourTree(
                        { type: "root", child: { type: "action", call: "A", while: { call: "Pass" } } } as any,
                        agent()
                    )
                )
            );
        });

        it("a repeat, retry or lotto is defined differently", () => {
            const definitions = [
                "root { repeat { action [A] } }",
                "root { repeat [2] { action [A] } }",
                "root { repeat [2, 3] { action [A] } }",
                "root { retry [2] { action [A] } }",
                "root { lotto { action [A] action [B] } }",
                "root { lotto [1, 2] { action [A] action [B] } }",
                "root { lotto [2, 1] { action [A] action [B] } }"
            ];
            const recorded = definitions.map((definition) => definitionOf(new BehaviourTree(definition, agent())));

            assert.strictEqual(new Set(recorded).size, definitions.length);
        });

        it("a globally registered subtree is different", () => {
            BehaviourTree.register("Sub", "root { action [A] }");
            const first = definitionOf(new BehaviourTree("root { sequence { branch [Sub] } }", agent()));

            BehaviourTree.register("Sub", "root { action [B] }");
            const second = definitionOf(new BehaviourTree("root { sequence { branch [Sub] } }", agent()));

            assert.notStrictEqual(first, second);
        });
    });

    it("records the definition that the tree was built with if a globally registered subtree is changed afterwards", () => {
        BehaviourTree.register("Sub", "root { action [A] }");
        const tree = new BehaviourTree("root { sequence { branch [Sub] } }", agent());
        const before = definitionOf(tree);

        BehaviourTree.register("Sub", "root { action [B] }");

        assert.strictEqual(definitionOf(tree), before);
    });
});

describe("Restoring a snapshot of a BehaviourTree", () => {
    const agent = (log: string[] = []): Agent => ({
        A: () => (log.push("A"), undefined),
        B: () => (log.push("B"), undefined),
        Pass: () => true
    });

    afterEach(() => BehaviourTree.unregisterAll());

    // A tree that has been stepped into a state that is easy to tell apart from that of one that has not.
    const create = (definition: string | RootNodeDefinition | RootNodeDefinition[], options = {}) => {
        const tree = new BehaviourTree(definition, agent(), options);
        tree.step();
        return tree;
    };

    const definition = "root { sequence { condition [Pass] action [A] wait [100] } }";

    it("is possible for a tree built from the equivalent JSON definition", () => {
        const source = create(definition);
        const target = new BehaviourTree(convertMDSLToJSON(definition), agent());

        target.restore(roundTrip(source));

        assert.deepEqual(withoutIds(target.getTreeNodeDetails()), withoutIds(source.getTreeNodeDetails()));
    });

    it("is possible for a tree built from the equivalent MDSL definition", () => {
        const source = create(convertMDSLToJSON(definition));
        const target = new BehaviourTree(definition, agent());

        target.restore(roundTrip(source));

        assert.deepEqual(withoutIds(target.getTreeNodeDetails()), withoutIds(source.getTreeNodeDetails()));
    });

    it("is possible for a tree with globally registered subtrees that are the same", () => {
        BehaviourTree.register("Sub", "root { action [A] }");
        const source = create("root { sequence { condition [Pass] branch [Sub] } }");
        const target = new BehaviourTree("root { sequence { condition [Pass] branch [Sub] } }", agent());

        target.restore(roundTrip(source));
        BehaviourTree.unregisterAll();

        assert.deepEqual(withoutIds(target.getTreeNodeDetails()), withoutIds(source.getTreeNodeDetails()));
    });

    describe("will error and leave the tree exactly as it was if the snapshot is of another definition that", () => {
        const others: [string, string][] = [
            [
                "has the same shape but a different action",
                "root { sequence { condition [Pass] action [B] wait [100] } }"
            ],
            [
                "has the same shape but a different duration",
                "root { sequence { condition [Pass] action [A] wait [200] } }"
            ],
            [
                "has the same shape but a different node type",
                "root { selector { condition [Pass] action [A] wait [100] } }"
            ],
            [
                "has the same shape but a different argument",
                "root { sequence { condition [Pass] action [A, 1] wait [100] } }"
            ],
            ["has a different shape", "root { sequence { condition [Pass] action [A] } }"],
            ["has an extra node", "root { sequence { condition [Pass] action [A] wait [100] action [B] } }"],
            ["is a single action", "root { action [A] }"]
        ];

        for (const [name, other] of others) {
            it(name, () => {
                const states: string[] = [];
                const tree = new BehaviourTree(definition, agent(), {
                    onNodeStateChange: ({ state }) => states.push(state)
                });
                tree.step();
                states.length = 0;
                const before = JSON.stringify(tree.snapshot());
                const details = JSON.stringify(withoutIds(tree.getTreeNodeDetails()));

                assert.throws(
                    () => tree.restore(roundTrip(create(other))),
                    Error,
                    "the snapshot does not match the tree's definition"
                );

                assert.strictEqual(JSON.stringify(tree.snapshot()), before);
                assert.strictEqual(JSON.stringify(withoutIds(tree.getTreeNodeDetails())), details);
                assert.deepEqual(states, []);
            });
        }

        it("only differs in a globally registered subtree", () => {
            BehaviourTree.register("Sub", "root { action [A] }");
            const source = create("root { sequence { branch [Sub] } }");
            BehaviourTree.register("Sub", "root { action [B] }");
            const target = create("root { sequence { branch [Sub] } }");
            const before = JSON.stringify(target.snapshot());

            assert.throws(
                () => target.restore(roundTrip(source)),
                Error,
                "the snapshot does not match the tree's definition"
            );
            assert.strictEqual(JSON.stringify(target.snapshot()), before);
        });

        it("is rejected before the node snapshots are looked at, even if they are not valid", () => {
            const target = create(definition);
            const snapshot: any = roundTrip(create("root { action [A] }"));
            snapshot.root = "nonsense";

            assert.throws(() => target.restore(snapshot), Error, "the snapshot does not match the tree's definition");
        });
    });

    describe("will error and leave the tree exactly as it was if what is restored is not a snapshot because it is", () => {
        const valid = (): any => roundTrip(create(definition));

        const notSnapshots: [string, unknown][] = [
            ["null", null],
            ["undefined", undefined],
            ["a string", "snapshot"],
            ["a string of a snapshot", JSON.stringify(valid())],
            ["a number", 1],
            ["a boolean", true],
            ["an array", []],
            ["an array of a snapshot", [valid()]],
            ["a function", () => valid()],
            ["an empty object", {}],
            ["an object without the fields of a snapshot", { name: "snapshot", state: State.READY }],
            ["a node snapshot rather than a tree snapshot", valid().root],
            ["a snapshot without a version", (({ version, ...rest }) => rest)(valid())],
            ["a snapshot without a definition", (({ definition, ...rest }) => rest)(valid())],
            ["a snapshot without a root", (({ root, ...rest }) => rest)(valid())],
            ["a snapshot with a definition that is not a string", { ...valid(), definition: 1 }],
            ["a snapshot with a null definition", { ...valid(), definition: null }],
            ["a snapshot with an empty definition", { ...valid(), definition: "" }],
            ["a snapshot with an object as a definition", { ...valid(), definition: { json: true } }]
        ];

        for (const [name, value] of notSnapshots) {
            it(name, () => {
                const tree = create(definition);
                const before = JSON.stringify(tree.snapshot());

                assert.throws(() => tree.restore(value as any), Error);
                assert.strictEqual(JSON.stringify(tree.snapshot()), before);
            });
        }

        it("rejects each with an error that is not a type error", () => {
            const tree = create(definition);

            for (const [, value] of notSnapshots) {
                try {
                    tree.restore(value as any);
                    assert.fail("expected an error");
                } catch (exception) {
                    assert.strictEqual((exception as Error).constructor, Error);
                    assert.match((exception as Error).message, /^invalid snapshot: /);
                }
            }
        });
    });
});

describe("A BehaviourTree with a promise-based action node that is waiting for its promise to settle", () => {
    const definition = "root { sequence { condition [Pass] action [Work] action [After] } }";

    const create = (options = {}) => {
        const calls: string[] = [];
        const settle: { resolve(value: unknown): void }[] = [];
        const agent = {
            Pass: () => true,
            Work: () => {
                calls.push("Work");
                return new Promise((resolve) => settle.push({ resolve }));
            },
            After: () => {
                calls.push("After");
                return State.SUCCEEDED;
            }
        };

        return { tree: new BehaviourTree(definition, agent, options), calls, settle };
    };

    const actionSnapshot = (tree: BehaviourTree) => (tree.snapshot().root as any).children[0].children[1];

    it("can be snapshotted, with the action as not yet started", () => {
        const { tree } = create();
        tree.step();

        assert.strictEqual(tree.getState(), State.RUNNING);
        assert.deepEqual(actionSnapshot(tree), { type: "action", state: State.READY, updatePromiseResult: null });
    });

    it("has a snapshot that is unchanged by a JSON round trip", () => {
        const { tree } = create();
        tree.step();

        assert.deepEqual(roundTrip(tree), tree.snapshot());
    });

    it("keeps the state of every other node in the snapshot", () => {
        const { tree } = create();
        tree.step();

        const snapshot: any = tree.snapshot();

        assert.strictEqual(snapshot.root.state, State.RUNNING);
        assert.strictEqual(snapshot.root.children[0].state, State.RUNNING);
        assert.strictEqual(snapshot.root.children[0].children[0].state, State.SUCCEEDED);
        assert.strictEqual(snapshot.root.children[0].children[2].state, State.READY);
    });

    it("is not affected by taking the snapshot, and still uses its promise", async () => {
        const { tree, calls, settle } = create();
        tree.step();
        tree.snapshot();
        tree.snapshot();

        tree.step();
        assert.deepEqual(calls, ["Work"]);

        settle[0].resolve(State.SUCCEEDED);
        await Promise.resolve();
        tree.step();

        assert.deepEqual(calls, ["Work", "After"]);
        assert.strictEqual(tree.getState(), State.SUCCEEDED);
    });

    it("is restored as not yet started, so the action function is called again on the next step", () => {
        const source = create();
        source.tree.step();
        const snapshot = roundTrip(source.tree);

        const target = create();
        target.tree.restore(snapshot);

        assert.deepEqual(target.calls, []);
        assert.strictEqual(target.tree.getState(), State.RUNNING);
        assert.strictEqual(findNode(target.tree, "action", "Work").state, State.READY);

        target.tree.step();

        assert.deepEqual(target.calls, ["Work"]);
        assert.strictEqual(findNode(target.tree, "action", "Work").state, State.RUNNING);
    });

    it("is restored so that the new promise decides the outcome and the nodes that were done are not run again", async () => {
        const source = create();
        source.tree.step();
        const snapshot = roundTrip(source.tree);

        const target = create();
        target.tree.restore(snapshot);
        target.tree.step();

        // The promise of the original tree settling is of no interest to the restored tree.
        source.settle[0].resolve(State.FAILED);
        await Promise.resolve();
        target.tree.step();
        assert.strictEqual(target.tree.getState(), State.RUNNING);

        target.settle[0].resolve(State.SUCCEEDED);
        await Promise.resolve();
        target.tree.step();

        assert.deepEqual(target.calls, ["Work", "After"]);
        assert.strictEqual(target.tree.getState(), State.SUCCEEDED);
    });

    it("can be snapshotted when a promise is pending within each kind of composite node", () => {
        for (const composite of ["sequence", "selector", "parallel", "race", "all", "lotto"]) {
            const tree = new BehaviourTree(`root { ${composite} { action [Work] action [Work] } }`, {
                Work: () => new Promise(() => {})
            });
            tree.step();

            const snapshot = roundTrip(tree);
            const restored = new BehaviourTree(`root { ${composite} { action [Work] action [Work] } }`, {
                Work: () => new Promise(() => {})
            });

            assert.doesNotThrow(() => restored.restore(snapshot), composite);
            assert.doesNotThrow(() => restored.step(), composite);
        }
    });

    it("can be snapshotted when a promise is pending within a decorator", () => {
        const tree = new BehaviourTree("root { repeat [3] { retry [2] { action [Work] } } }", {
            Work: () => new Promise(() => {})
        });
        tree.step();

        assert.doesNotThrow(() => tree.snapshot());
    });

    it("is still snapshotted with the result of a promise that settled but has not yet been handled", async () => {
        const { tree, settle } = create();
        tree.step();
        settle[0].resolve(State.SUCCEEDED);
        await Promise.resolve();

        assert.deepEqual(actionSnapshot(tree), {
            type: "action",
            state: State.RUNNING,
            updatePromiseResult: { isResolved: true, value: State.SUCCEEDED }
        });
    });

    it("calls the entry callback again, along with the action function, on the first step after it is restored", () => {
        const calls: string[] = [];
        const make = () =>
            new BehaviourTree("root { action [Work] entry(Enter) }", {
                Work: () => (calls.push("Work"), new Promise(() => {})),
                Enter: () => calls.push("Enter")
            });

        const source = make();
        source.step();
        const restored = make();
        restored.restore(source.snapshot());
        calls.length = 0;

        restored.step();

        assert.deepEqual(calls, ["Enter", "Work"]);
    });

    it("does not call the entry callback or any agent function when it is snapshotted or restored", () => {
        const calls: string[] = [];
        const make = () =>
            new BehaviourTree("root { action [Work] entry(Enter) }", {
                Work: () => (calls.push("Work"), new Promise(() => {})),
                Enter: () => calls.push("Enter")
            });

        const source = make();
        source.step();
        calls.length = 0;

        const snapshot = source.snapshot();
        make().restore(snapshot);

        assert.deepEqual(calls, []);
    });
});

describe("A BehaviourTree snapshot", () => {
    const definition = `
        root {
            sequence {
                lotto [1, 2] {
                    action [A]
                    sequence { action [B] wait [100, 400] }
                }
                parallel {
                    wait [500]
                    repeat [2, 3] { action [C] }
                    retry [2] { action [Fails] }
                }
                wait
            }
        }
    `;

    let clock: sinon.SinonFakeTimers;

    beforeEach(() => {
        clock = sinon.useFakeTimers();
    });

    afterEach(() => {
        clock.restore();
    });

    const create = (flags: { [key: string]: boolean }, options: { getDeltaTime?: () => number } = {}) => {
        let next = 0;
        return new BehaviourTree(definition, createAgent([], flags), {
            random: () => [0.9, 0.3, 0.6, 0.1][next++ % 4],
            ...options
        });
    };

    const timings: [string, { getDeltaTime?: () => number }][] = [
        ["the clock", {}],
        ["the 'getDeltaTime' option", { getDeltaTime: () => 0.1 }]
    ];

    for (const [timing, options] of timings) {
        describe(`of a tree using ${timing}`, () => {
            it("is not changed by stepping the tree it was taken from", () => {
                const flags: { [key: string]: boolean } = {};
                const tree = create(flags, options);

                for (let warmup = 0; warmup < 12; warmup++) {
                    const snapshot = tree.snapshot();
                    const serialised = JSON.stringify(snapshot);

                    flags["A"] = flags["B"] = flags["C"] = warmup % 3 !== 0;

                    for (let index = 0; index < 4; index++) {
                        clock.tick(100);
                        tree.step();
                    }

                    assert.strictEqual(JSON.stringify(snapshot), serialised, `after ${warmup} snapshots`);

                    tree.step();
                }
            });

            it("is not changed by stepping a tree that it was restored to", () => {
                const flags: { [key: string]: boolean } = {};
                const original = create(flags, options);

                for (let warmup = 0; warmup < 12; warmup++) {
                    // Neither a snapshot that was passed through JSON nor one that was not may be changed.
                    for (const snapshot of [original.snapshot(), roundTrip(original)]) {
                        const serialised = JSON.stringify(snapshot);
                        const restored = create(flags, options);

                        restored.restore(snapshot);
                        flags["A"] = flags["B"] = flags["C"] = warmup % 3 !== 0;

                        for (let index = 0; index < 4; index++) {
                            clock.tick(100);
                            restored.step();
                        }

                        assert.strictEqual(JSON.stringify(snapshot), serialised, `after ${warmup} steps`);
                    }

                    clock.tick(100);
                    original.step();
                }
            });

            it("is equal to a snapshot of a tree that it was restored to, taken before any step", () => {
                const flags: { [key: string]: boolean } = { A: true, B: true, C: true };
                const original = create(flags, options);

                for (let warmup = 0; warmup < 12; warmup++) {
                    const snapshot = original.snapshot();
                    const restored = create(flags, options);

                    restored.restore(snapshot);

                    // Time passes after the tree is restored and before it is stepped.
                    clock.tick(75);

                    assert.deepEqual(
                        roundTrip(restored),
                        JSON.parse(JSON.stringify(snapshot)),
                        `after ${warmup} steps`
                    );

                    clock.tick(25);
                    original.step();
                }
            });
        });
    }
});
