import { assert } from "chai";
import sinon from "sinon";

import { BehaviourTree, State } from "../../../src/index";
import { RootNodeDefinition } from "../../../src/BehaviourTreeDefinition";
import { findNode } from "../../TestUtilities";

describe("An Until guard node attribute", () => {
    describe("on tree initialisation", () => {
        describe("will error if no function name is defined", () => {
            it("(MDSL)", () => {
                const definition = "root { action [noop] until() }";
                assert.throws(
                    () => new BehaviourTree(definition, {}),
                    Error,
                    "invalid definition: expected agent function or registered function name identifier argument for attribute"
                );
            });

            it("(JSON)", () => {
                const definition: RootNodeDefinition = {
                    type: "root",
                    child: {
                        type: "action",
                        call: "noop",
                        until: {} as any
                    }
                };
                assert.throws(
                    () => new BehaviourTree(definition, {}),
                    Error,
                    "invalid definition: expected 'call' property for attribute 'until' to be a non-empty string for 'action' node at depth '1'"
                );
            });
        });
    });

    describe("when the node is updated as part of a tree step will call the guard function and", () => {
        describe("abort the running node and any child nodes and if the function returns a value of true will move them to the", () => {
            describe("FAILED state if", () => {
                describe("the resolved state to move to is not defined", () => {
                    it("(MDSL)", () => {
                        const definition = `root { sequence until(someCondition, "condition-argument") { action [someAction] exit(onActionExit) } }`;
                        const agent = {
                            someAction: () => State.RUNNING,
                            someCondition: sinon.stub().returns(false),
                            onActionExit: sinon.stub()
                        };
                        const tree = new BehaviourTree(definition, agent);

                        tree.step();

                        assert.isTrue(tree.isRunning());
                        assert.isTrue(agent.someCondition.calledWith("condition-argument"));
                        assert.strictEqual(findNode(tree, "root").state, State.RUNNING);
                        assert.strictEqual(findNode(tree, "sequence").state, State.RUNNING);
                        assert.strictEqual(findNode(tree, "action").state, State.RUNNING);

                        agent.someCondition.returns(true);

                        tree.step();

                        assert.isFalse(tree.isRunning());
                        assert.isTrue(agent.someCondition.calledWith("condition-argument"));
                        assert.isTrue(agent.onActionExit.calledWith(sinon.match({ succeeded: false, aborted: true })));
                        assert.strictEqual(findNode(tree, "root").state, State.FAILED);
                        assert.strictEqual(findNode(tree, "sequence").state, State.FAILED);
                        assert.strictEqual(findNode(tree, "action").state, State.READY);

                        tree.reset();

                        assert.isFalse(tree.isRunning());
                        assert.strictEqual(findNode(tree, "root").state, State.READY);
                        assert.strictEqual(findNode(tree, "sequence").state, State.READY);
                        assert.strictEqual(findNode(tree, "action").state, State.READY);

                        tree.step();

                        assert.isFalse(tree.isRunning());
                        assert.strictEqual(findNode(tree, "root").state, State.FAILED);
                        assert.strictEqual(findNode(tree, "sequence").state, State.FAILED);
                        assert.strictEqual(findNode(tree, "action").state, State.READY);
                    });

                    it("(JSON)", () => {
                        const definition: RootNodeDefinition = {
                            type: "root",
                            child: {
                                type: "sequence",
                                until: {
                                    call: "someCondition",
                                    args: ["condition-argument"]
                                },
                                children: [
                                    {
                                        type: "action",
                                        exit: {
                                            call: "onActionExit"
                                        },
                                        call: "someAction"
                                    }
                                ]
                            }
                        };
                        const agent = {
                            someAction: () => State.RUNNING,
                            someCondition: sinon.stub().returns(false),
                            onActionExit: sinon.stub()
                        };
                        const tree = new BehaviourTree(definition, agent);

                        tree.step();

                        assert.isTrue(tree.isRunning());
                        assert.isTrue(agent.someCondition.calledWith("condition-argument"));
                        assert.strictEqual(findNode(tree, "root").state, State.RUNNING);
                        assert.strictEqual(findNode(tree, "sequence").state, State.RUNNING);
                        assert.strictEqual(findNode(tree, "action").state, State.RUNNING);

                        agent.someCondition.returns(true);

                        tree.step();

                        assert.isFalse(tree.isRunning());
                        assert.isTrue(agent.someCondition.calledWith("condition-argument"));
                        assert.isTrue(agent.onActionExit.calledWith(sinon.match({ succeeded: false, aborted: true })));
                        assert.strictEqual(findNode(tree, "root").state, State.FAILED);
                        assert.strictEqual(findNode(tree, "sequence").state, State.FAILED);
                        assert.strictEqual(findNode(tree, "action").state, State.READY);

                        tree.reset();

                        assert.isFalse(tree.isRunning());
                        assert.strictEqual(findNode(tree, "root").state, State.READY);
                        assert.strictEqual(findNode(tree, "sequence").state, State.READY);
                        assert.strictEqual(findNode(tree, "action").state, State.READY);

                        tree.step();

                        assert.isFalse(tree.isRunning());
                        assert.strictEqual(findNode(tree, "root").state, State.FAILED);
                        assert.strictEqual(findNode(tree, "sequence").state, State.FAILED);
                        assert.strictEqual(findNode(tree, "action").state, State.READY);
                    });
                });

                describe("the guard is configured to move the aborted node to the FAILED state", () => {
                    it("(MDSL)", () => {
                        const definition = `root { sequence until(someCondition, "condition-argument") then fail { action [someAction] exit(onActionExit) } }`;
                        const agent = {
                            someAction: () => State.RUNNING,
                            someCondition: sinon.stub().returns(false),
                            onActionExit: sinon.stub()
                        };
                        const tree = new BehaviourTree(definition, agent);

                        tree.step();

                        assert.isTrue(tree.isRunning());
                        assert.isTrue(agent.someCondition.calledWith("condition-argument"));
                        assert.strictEqual(findNode(tree, "root").state, State.RUNNING);
                        assert.strictEqual(findNode(tree, "sequence").state, State.RUNNING);
                        assert.strictEqual(findNode(tree, "action").state, State.RUNNING);

                        agent.someCondition.returns(true);

                        tree.step();

                        assert.isFalse(tree.isRunning());
                        assert.isTrue(agent.someCondition.calledWith("condition-argument"));
                        assert.isTrue(agent.onActionExit.calledWith(sinon.match({ succeeded: false, aborted: true })));
                        assert.strictEqual(findNode(tree, "root").state, State.FAILED);
                        assert.strictEqual(findNode(tree, "sequence").state, State.FAILED);
                        assert.strictEqual(findNode(tree, "action").state, State.READY);

                        tree.reset();

                        assert.isFalse(tree.isRunning());
                        assert.strictEqual(findNode(tree, "root").state, State.READY);
                        assert.strictEqual(findNode(tree, "sequence").state, State.READY);
                        assert.strictEqual(findNode(tree, "action").state, State.READY);

                        tree.step();

                        assert.isFalse(tree.isRunning());
                        assert.strictEqual(findNode(tree, "root").state, State.FAILED);
                        assert.strictEqual(findNode(tree, "sequence").state, State.FAILED);
                        assert.strictEqual(findNode(tree, "action").state, State.READY);
                    });

                    it("(JSON)", () => {
                        const definition: RootNodeDefinition = {
                            type: "root",
                            child: {
                                type: "sequence",
                                until: {
                                    call: "someCondition",
                                    args: ["condition-argument"],
                                    succeedOnAbort: false
                                },
                                children: [
                                    {
                                        type: "action",
                                        exit: {
                                            call: "onActionExit"
                                        },
                                        call: "someAction"
                                    }
                                ]
                            }
                        };
                        const agent = {
                            someAction: () => State.RUNNING,
                            someCondition: sinon.stub().returns(false),
                            onActionExit: sinon.stub()
                        };
                        const tree = new BehaviourTree(definition, agent);

                        tree.step();

                        assert.isTrue(tree.isRunning());
                        assert.isTrue(agent.someCondition.calledWith("condition-argument"));
                        assert.strictEqual(findNode(tree, "root").state, State.RUNNING);
                        assert.strictEqual(findNode(tree, "sequence").state, State.RUNNING);
                        assert.strictEqual(findNode(tree, "action").state, State.RUNNING);

                        agent.someCondition.returns(true);

                        tree.step();

                        assert.isFalse(tree.isRunning());
                        assert.isTrue(agent.someCondition.calledWith("condition-argument"));
                        assert.isTrue(agent.onActionExit.calledWith(sinon.match({ succeeded: false, aborted: true })));
                        assert.strictEqual(findNode(tree, "root").state, State.FAILED);
                        assert.strictEqual(findNode(tree, "sequence").state, State.FAILED);
                        assert.strictEqual(findNode(tree, "action").state, State.READY);

                        tree.reset();

                        assert.isFalse(tree.isRunning());
                        assert.strictEqual(findNode(tree, "root").state, State.READY);
                        assert.strictEqual(findNode(tree, "sequence").state, State.READY);
                        assert.strictEqual(findNode(tree, "action").state, State.READY);

                        tree.step();

                        assert.isFalse(tree.isRunning());
                        assert.strictEqual(findNode(tree, "root").state, State.FAILED);
                        assert.strictEqual(findNode(tree, "sequence").state, State.FAILED);
                        assert.strictEqual(findNode(tree, "action").state, State.READY);
                    });
                });
            });

            describe("SUCCEEDED state if the guard is configured to move the aborted node to the SUCCEEDED state", () => {
                it("(MDSL)", () => {
                    const definition = `root { sequence until(someCondition, "condition-argument") then succeed { action [someAction] exit(onActionExit) } }`;
                    const agent = {
                        someAction: () => State.RUNNING,
                        someCondition: sinon.stub().returns(false),
                        onActionExit: sinon.stub()
                    };
                    const tree = new BehaviourTree(definition, agent);

                    tree.step();

                    assert.isTrue(tree.isRunning());
                    assert.isTrue(agent.someCondition.calledWith("condition-argument"));
                    assert.strictEqual(findNode(tree, "root").state, State.RUNNING);
                    assert.strictEqual(findNode(tree, "sequence").state, State.RUNNING);
                    assert.strictEqual(findNode(tree, "action").state, State.RUNNING);

                    agent.someCondition.returns(true);

                    tree.step();

                    assert.isFalse(tree.isRunning());
                    assert.isTrue(agent.someCondition.calledWith("condition-argument"));
                    assert.isTrue(agent.onActionExit.calledWith(sinon.match({ succeeded: false, aborted: true })));
                    assert.strictEqual(findNode(tree, "root").state, State.SUCCEEDED);
                    assert.strictEqual(findNode(tree, "sequence").state, State.SUCCEEDED);
                    assert.strictEqual(findNode(tree, "action").state, State.READY);

                    tree.reset();

                    assert.isFalse(tree.isRunning());
                    assert.strictEqual(findNode(tree, "root").state, State.READY);
                    assert.strictEqual(findNode(tree, "sequence").state, State.READY);
                    assert.strictEqual(findNode(tree, "action").state, State.READY);

                    tree.step();

                    assert.isFalse(tree.isRunning());
                    assert.strictEqual(findNode(tree, "root").state, State.SUCCEEDED);
                    assert.strictEqual(findNode(tree, "sequence").state, State.SUCCEEDED);
                    assert.strictEqual(findNode(tree, "action").state, State.READY);
                });

                it("(JSON)", () => {
                    const definition: RootNodeDefinition = {
                        type: "root",
                        child: {
                            type: "sequence",
                            until: {
                                call: "someCondition",
                                args: ["condition-argument"],
                                succeedOnAbort: true
                            },
                            children: [
                                {
                                    type: "action",
                                    exit: {
                                        call: "onActionExit"
                                    },
                                    call: "someAction"
                                }
                            ]
                        }
                    };
                    const agent = {
                        someAction: () => State.RUNNING,
                        someCondition: sinon.stub().returns(false),
                        onActionExit: sinon.stub()
                    };
                    const tree = new BehaviourTree(definition, agent);

                    tree.step();

                    assert.isTrue(tree.isRunning());
                    assert.isTrue(agent.someCondition.calledWith("condition-argument"));
                    assert.strictEqual(findNode(tree, "root").state, State.RUNNING);
                    assert.strictEqual(findNode(tree, "sequence").state, State.RUNNING);
                    assert.strictEqual(findNode(tree, "action").state, State.RUNNING);

                    agent.someCondition.returns(true);

                    tree.step();

                    assert.isFalse(tree.isRunning());
                    assert.isTrue(agent.someCondition.calledWith("condition-argument"));
                    assert.isTrue(agent.onActionExit.calledWith(sinon.match({ succeeded: false, aborted: true })));
                    assert.strictEqual(findNode(tree, "root").state, State.SUCCEEDED);
                    assert.strictEqual(findNode(tree, "sequence").state, State.SUCCEEDED);
                    assert.strictEqual(findNode(tree, "action").state, State.READY);

                    tree.reset();

                    assert.isFalse(tree.isRunning());
                    assert.strictEqual(findNode(tree, "root").state, State.READY);
                    assert.strictEqual(findNode(tree, "sequence").state, State.READY);
                    assert.strictEqual(findNode(tree, "action").state, State.READY);

                    tree.step();

                    assert.isFalse(tree.isRunning());
                    assert.strictEqual(findNode(tree, "root").state, State.SUCCEEDED);
                    assert.strictEqual(findNode(tree, "sequence").state, State.SUCCEEDED);
                    assert.strictEqual(findNode(tree, "action").state, State.READY);
                });
            });
        });

        describe("does nothing if the function returns a value of false", () => {
            it("(MDSL)", () => {
                const definition = `root { sequence until(someCondition, "condition-argument") { action [someAction] } }`;
                const agent = {
                    someAction: () => State.RUNNING,
                    someCondition: sinon.stub().returns(false)
                };
                const tree = new BehaviourTree(definition, agent);

                tree.step();

                assert.isTrue(tree.isRunning());
                assert.isTrue(agent.someCondition.calledWith("condition-argument"));
                assert.strictEqual(findNode(tree, "root").state, State.RUNNING);
                assert.strictEqual(findNode(tree, "sequence").state, State.RUNNING);
                assert.strictEqual(findNode(tree, "action").state, State.RUNNING);

                agent.someAction = () => State.SUCCEEDED;

                tree.step();

                assert.isFalse(tree.isRunning());
                assert.isTrue(agent.someCondition.calledWith("condition-argument"));
                assert.strictEqual(findNode(tree, "root").state, State.SUCCEEDED);
                assert.strictEqual(findNode(tree, "sequence").state, State.SUCCEEDED);
                assert.strictEqual(findNode(tree, "action").state, State.SUCCEEDED);
            });

            it("(JSON)", () => {
                const definition: RootNodeDefinition = {
                    type: "root",
                    child: {
                        type: "sequence",
                        until: {
                            call: "someCondition",
                            args: ["condition-argument"]
                        },
                        children: [
                            {
                                type: "action",
                                call: "someAction"
                            }
                        ]
                    }
                };
                const agent = {
                    someAction: () => State.RUNNING,
                    someCondition: sinon.stub().returns(false)
                };
                const tree = new BehaviourTree(definition, agent);

                tree.step();

                assert.isTrue(tree.isRunning());
                assert.isTrue(agent.someCondition.calledWith("condition-argument"));
                assert.strictEqual(findNode(tree, "root").state, State.RUNNING);
                assert.strictEqual(findNode(tree, "sequence").state, State.RUNNING);
                assert.strictEqual(findNode(tree, "action").state, State.RUNNING);

                agent.someAction = () => State.SUCCEEDED;

                tree.step();

                assert.isFalse(tree.isRunning());
                assert.isTrue(agent.someCondition.calledWith("condition-argument"));
                assert.strictEqual(findNode(tree, "root").state, State.SUCCEEDED);
                assert.strictEqual(findNode(tree, "sequence").state, State.SUCCEEDED);
                assert.strictEqual(findNode(tree, "action").state, State.SUCCEEDED);
            });
        });

        describe("throws an error if the guard condition function ", () => {
            describe("does not return a boolean value", () => {
                it("(MDSL)", () => {
                    const definition = `root { sequence until(someCondition, "condition-argument") { action [someAction] } }`;
                    const agent = {
                        someAction: () => State.RUNNING,
                        someCondition: () => "invalid-response"
                    };
                    const tree = new BehaviourTree(definition, agent);

                    assert.throws(
                        () => tree.step(),
                        Error,
                        "expected guard condition function 'someCondition' to return a boolean but returned 'invalid-response'"
                    );
                });

                it("(JSON)", () => {
                    const definition: RootNodeDefinition = {
                        type: "root",
                        child: {
                            type: "sequence",
                            until: {
                                call: "someCondition",
                                args: ["condition-argument"]
                            },
                            children: [
                                {
                                    type: "action",
                                    call: "someAction"
                                }
                            ]
                        }
                    };
                    const agent = {
                        someAction: () => State.RUNNING,
                        someCondition: () => "invalid-response"
                    };
                    const tree = new BehaviourTree(definition, agent);

                    assert.throws(
                        () => tree.step(),
                        Error,
                        "expected guard condition function 'someCondition' to return a boolean but returned 'invalid-response'"
                    );
                });
            });

            describe("throws an exception", () => {
                it("(MDSL)", () => {
                    const definition = `root { sequence until(someCondition, "condition-argument") { action [someAction] } }`;
                    const agent = {
                        someAction: () => State.RUNNING,
                        someCondition: () => {
                            throw new Error("some-error");
                        }
                    };
                    const tree = new BehaviourTree(definition, agent);

                    assert.throws(
                        () => tree.step(),
                        Error,
                        "error stepping tree: guard condition function 'someCondition' threw: Error: some-error"
                    );
                });

                it("(JSON)", () => {
                    const definition: RootNodeDefinition = {
                        type: "root",
                        child: {
                            type: "sequence",
                            until: {
                                call: "someCondition",
                                args: ["condition-argument"]
                            },
                            children: [
                                {
                                    type: "action",
                                    call: "someAction"
                                }
                            ]
                        }
                    };
                    const agent = {
                        someAction: () => State.RUNNING,
                        someCondition: () => {
                            throw new Error("some-error");
                        }
                    };
                    const tree = new BehaviourTree(definition, agent);

                    assert.throws(
                        () => tree.step(),
                        Error,
                        "error stepping tree: guard condition function 'someCondition' threw: Error: some-error"
                    );
                });
            });
        });
    });
});
