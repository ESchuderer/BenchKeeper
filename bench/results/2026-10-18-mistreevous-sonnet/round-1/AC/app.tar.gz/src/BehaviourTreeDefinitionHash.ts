import {
    AnyNodeDefinition,
    NodeAttributeDefinition,
    NodeGuardDefinition,
    RootNodeDefinition
} from "./BehaviourTreeDefinition";
import { MAIN_ROOT_NODE_KEY, RootNodeDefinitionMap, createRootNodeDefinitionMap } from "./BehaviourTreeBuilder";

/**
 * Creates a string that identifies a tree definition, which is the same for any definition that builds the same tree.
 * An MDSL definition and the equivalent JSON definition have the same hash. Registered subtrees that the definition
 * refers to are part of the definition, so the hash is only valid for the registered subtrees at the time it is created.
 * @param definition The root node definitions, which must have been validated.
 * @returns A string that identifies the tree definition.
 */
export function createDefinitionHash(definition: RootNodeDefinition[]): string {
    const rootNodeDefinitionMap = createRootNodeDefinitionMap(definition);

    return hashString(stringify(normalise(rootNodeDefinitionMap[MAIN_ROOT_NODE_KEY], rootNodeDefinitionMap)));
}

/**
 * Creates the normal form of a node definition, in which every branch is replaced by the root node child that it refers
 * to and the optional properties that the conversion from MDSL always writes are written for JSON definitions as well.
 * This has to be kept in line with how the builder uses a definition, as it decides what counts as the same definition.
 * @param definition The node definition.
 * @param rootNodeDefinitionMap The mapping of root node identifers to root node definitions, including globally registered subtree root node definitions.
 * @returns The normal form of the node definition.
 */
function normalise(definition: AnyNodeDefinition, rootNodeDefinitionMap: RootNodeDefinitionMap): unknown {
    // A branch is built as the child of the root node it refers to, and its own attributes are not used.
    if (definition.type === "branch") {
        return normalise(rootNodeDefinitionMap[definition.ref].child, rootNodeDefinitionMap);
    }

    const normalised: Record<string, unknown> = { ...definition };

    // The identifier of a root node does not change the tree that it builds.
    delete normalised.id;

    if ("child" in definition) {
        normalised.child = normalise(definition.child, rootNodeDefinitionMap);
    }

    if ("children" in definition) {
        normalised.children = definition.children.map((child) => normalise(child, rootNodeDefinitionMap));
    }

    if (definition.type === "action" || definition.type === "condition") {
        normalised.args = definition.args ?? [];
    }

    for (const key of ["while", "until"] as const) {
        const guard: NodeGuardDefinition | undefined = definition[key];

        if (guard) {
            normalised[key] = { call: guard.call, args: guard.args ?? [], succeedOnAbort: !!guard.succeedOnAbort };
        }
    }

    for (const key of ["entry", "step", "exit"] as const) {
        const callback: NodeAttributeDefinition | undefined = definition[key];

        if (callback) {
            normalised[key] = { call: callback.call, args: callback.args ?? [] };
        }
    }

    return normalised;
}

/**
 * Converts a value to JSON with the properties of every object in a fixed order, so that equal values give equal strings.
 * @param value The value to convert.
 * @returns The JSON string.
 */
function stringify(value: unknown): string {
    return JSON.stringify(value, (_key, nested) =>
        typeof nested === "object" && nested !== null && !Array.isArray(nested)
            ? Object.fromEntries(Object.entries(nested).sort(([a], [b]) => (a < b ? -1 : a > b ? 1 : 0)))
            : nested
    );
}

/**
 * Creates a 53 bit hash of a string, using the cyrb53 algorithm, as a hex string.
 * @param value The string to hash.
 * @returns The hash of the string.
 */
function hashString(value: string): string {
    let h1 = 0xdeadbeef;
    let h2 = 0x41c6ce57;

    for (let index = 0; index < value.length; index++) {
        const code = value.charCodeAt(index);

        h1 = Math.imul(h1 ^ code, 2654435761);
        h2 = Math.imul(h2 ^ code, 1597334677);
    }

    h1 = Math.imul(h1 ^ (h1 >>> 16), 2246822507) ^ Math.imul(h2 ^ (h2 >>> 13), 3266489909);
    h2 = Math.imul(h2 ^ (h2 >>> 16), 2246822507) ^ Math.imul(h1 ^ (h1 >>> 13), 3266489909);

    return (4294967296 * (2097151 & h2) + (h1 >>> 0)).toString(16);
}
