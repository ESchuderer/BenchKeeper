import State, { AnyState } from "./State";

/**
 * The current version of the snapshot format.
 */
export const SNAPSHOT_VERSION = 1;

/**
 * The snapshot of a node that has child nodes.
 */
type ParentNodeSnapshot = {
    /**
     * The snapshots of the child nodes, in the order that the children are defined.
     */
    children: NodeSnapshot[];
};

/**
 * The snapshot of a root, flip, succeed or fail node.
 */
export type DecoratorNodeSnapshot = {
    type: "root" | "flip" | "succeed" | "fail";
    state: AnyState;
} & ParentNodeSnapshot;

/**
 * The snapshot of a sequence, selector, parallel, race or all node.
 */
export type CompositeNodeSnapshot = {
    type: "sequence" | "selector" | "parallel" | "race" | "all";
    state: AnyState;
} & ParentNodeSnapshot;

/**
 * The snapshot of a lotto node.
 */
export type LottoNodeSnapshot = {
    type: "lotto";
    state: AnyState;
    /**
     * The index of the child that was picked at random, or null if no child has been picked.
     */
    selectedChildIndex: number | null;
} & ParentNodeSnapshot;

/**
 * The snapshot of a repeat node.
 */
export type RepeatNodeSnapshot = {
    type: "repeat";
    state: AnyState;
    /**
     * The number of iterations completed so far.
     */
    currentIterationCount: number;
    /**
     * The number of iterations to complete, or null if there is no limit. If this is a random number of iterations
     * between a minimum and a maximum, then this is the number that was picked.
     */
    targetIterationCount: number | null;
} & ParentNodeSnapshot;

/**
 * The snapshot of a retry node.
 */
export type RetryNodeSnapshot = {
    type: "retry";
    state: AnyState;
    /**
     * The number of attempts made so far.
     */
    currentAttemptCount: number;
    /**
     * The number of attempts to make, or null if there is no limit. If this is a random number of attempts between a
     * minimum and a maximum, then this is the number that was picked.
     */
    targetAttemptCount: number | null;
} & ParentNodeSnapshot;

/**
 * The snapshot of a wait node.
 */
export type WaitNodeSnapshot = {
    type: "wait";
    state: AnyState;
    /**
     * The duration to wait for in milliseconds, or null if the node waits indefinitely. If this is a random duration
     * between a minimum and a maximum, then this is the duration that was picked.
     */
    totalDuration: number | null;
    /**
     * The duration in milliseconds that the node has waited for as of when the snapshot was taken.
     */
    waitedDuration: number;
};

/**
 * The snapshot of an action node.
 */
export type ActionNodeSnapshot = {
    type: "action";
    state: AnyState;
    /**
     * The settled result of the promise returned by the action function, if there was one and it has not yet been
     * used to update the node. A promise that has not yet settled cannot be captured in a snapshot, so the snapshot of
     * an action that is waiting on one is of an action that has not started, with a state of READY.
     */
    promiseResult: {
        /**
         * Whether the promise was resolved, as opposed to rejected.
         */
        isResolved: boolean;
        /**
         * The value that the promise was resolved with, or the reason it was rejected with, as a string.
         */
        value: string;
    } | null;
};

/**
 * The snapshot of a condition node.
 */
export type ConditionNodeSnapshot = {
    type: "condition";
    state: AnyState;
};

/**
 * The snapshot of the execution state of a node.
 */
export type NodeSnapshot =
    | DecoratorNodeSnapshot
    | CompositeNodeSnapshot
    | LottoNodeSnapshot
    | RepeatNodeSnapshot
    | RetryNodeSnapshot
    | WaitNodeSnapshot
    | ActionNodeSnapshot
    | ConditionNodeSnapshot;

/**
 * The snapshot of the execution state of a behaviour tree.
 * This is a plain object that is unchanged by JSON serialisation, and can be used to restore the state of a tree built
 * from the same definition.
 */
export type BehaviourTreeSnapshot = {
    /**
     * The version of the snapshot format.
     */
    version: typeof SNAPSHOT_VERSION;
    /**
     * A hash of the definition of the tree that the snapshot was taken from. A snapshot can only be restored to a tree
     * built from the same definition, where an MDSL definition and the equivalent JSON definition are the same.
     */
    definitionHash: string;
    /**
     * The snapshot of the root node, which contains the snapshots of every other node in the tree.
     */
    root: NodeSnapshot;
};

/**
 * Gets whether the specified value is a valid node state.
 */
export function isNodeState(value: unknown): value is AnyState {
    return (Object.values(State) as unknown[]).includes(value);
}

/**
 * Gets whether the specified value is a non-negative integer.
 */
export function isNonNegativeInteger(value: unknown): value is number {
    return typeof value === "number" && Number.isInteger(value) && value >= 0;
}

/**
 * Gets whether the specified value is a number that is not NaN or infinite.
 */
export function isFiniteNumber(value: unknown): value is number {
    return typeof value === "number" && Number.isFinite(value);
}
