import { BehaviourTreeOptions } from "../../BehaviourTreeOptions";
import { NodeDetails } from "../Node";
import State, { CompleteState } from "../../State";
import { Agent } from "../../Agent";
import Leaf from "./Leaf";
import Lookup from "../../Lookup";
import Attribute from "../../attributes/Attribute";
import { NodeSnapshot } from "../../BehaviourTreeSnapshot";

/**
 * The type representing a resolved/rejected update promise.
 */
type UpdatePromiseResult = {
    /**
     * Whether the promise was resolved rather than rejected.
     */
    isResolved: boolean;

    /**
     * The promise resolved value or rejection reason.
     */
    value: any;
};

/**
 * An Action leaf node.
 * This represents an immediate or ongoing state of behaviour.
 */
export default class Action extends Leaf {
    /**
     * @param attributes The node attributes.
     * @param options The behaviour tree options.
     * @param actionName The action name.
     * @param actionArguments The array of action arguments.
     */
    constructor(
        attributes: Attribute[],
        options: BehaviourTreeOptions,
        private actionName: string,
        public actionArguments: any[]
    ) {
        super("action", attributes, options);
    }

    /**
     * Whether there is a pending update promise.
     */
    private isUsingUpdatePromise = false;

    /**
     * The finished state result of an update promise.
     */
    private updatePromiseResult: UpdatePromiseResult | null = null;

    /**
     * The update promise that we are waiting on. Any other promise is stale, perhaps from before this node was reset or restored.
     */
    private updatePromise: Promise<CompleteState> | null = null;

    /**
     * Called when the node is being updated.
     * @param agent The agent.
     */
    protected onUpdate(agent: Agent): void {
        // If the result of this action depends on an update promise then there is nothing to do until it settles.
        if (this.isUsingUpdatePromise) {
            // Are we still waiting for our update promise to settle?
            if (!this.updatePromiseResult) {
                return;
            }

            const { isResolved, value } = this.updatePromiseResult;

            // Our update promise settled, was it resolved or rejected?
            if (isResolved) {
                // Our promise resolved so check to make sure the result is a valid finished state.
                if (value !== State.SUCCEEDED && value !== State.FAILED) {
                    throw new Error(
                        "action node promise resolved with an invalid value, expected a State.SUCCEEDED or State.FAILED value to be returned"
                    );
                }

                // Set the state of this node to match the state returned by the promise.
                this.setState(value);

                return;
            } else {
                // The promise was rejected, which isn't great.
                throw new Error(`action function '${this.actionName}' promise rejected with '${value}'`);
            }
        }

        // Attempt to get the invoker for the action function.
        const actionFuncInvoker = Lookup.getFuncInvoker(agent, this.actionName);

        // The action function should be defined.
        if (actionFuncInvoker === null) {
            throw new Error(
                `cannot update action node as the action '${this.actionName}' function is not defined on the agent and has not been registered`
            );
        }

        let actionFunctionResult;

        try {
            // Call the action function, the result of which may be:
            // - The finished state of this action node.
            // - A promise to return a finished node state.
            // - Undefined if the node should remain in the running state.
            actionFunctionResult = actionFuncInvoker(this.actionArguments) as CompleteState | Promise<CompleteState>;
        } catch (error) {
            // An uncaught error was thrown.
            if (error instanceof Error) {
                throw new Error(`action function '${this.actionName}' threw: ${error.stack}`);
            } else {
                throw new Error(`action function '${this.actionName}' threw: ${error}`);
            }
        }

        if (actionFunctionResult instanceof Promise) {
            actionFunctionResult.then(
                (result) => {
                    // If 'isUpdatePromisePending' is not set then the promise was cleared as it was resolving, probably via an abort of reset.
                    // The promise could also have been replaced if this node was restored from a snapshot while we were waiting.
                    if (!this.isUsingUpdatePromise || this.updatePromise !== actionFunctionResult) {
                        return;
                    }

                    // Set the resolved update promise result so that it can be handled on the next update of this node.
                    this.updatePromiseResult = {
                        isResolved: true,
                        value: result
                    };
                },
                (reason) => {
                    // If 'isUpdatePromisePending' is not set then the promise was cleared as it was resolving, probably via an abort or reset.
                    // The promise could also have been replaced if this node was restored from a snapshot while we were waiting.
                    if (!this.isUsingUpdatePromise || this.updatePromise !== actionFunctionResult) {
                        return;
                    }

                    // Set the rejected update promise result so that it can be handled on the next update of this node.
                    this.updatePromiseResult = {
                        isResolved: false,
                        value: reason
                    };
                }
            );

            // This node will be in the 'RUNNING' state until the update promise resolves.
            this.setState(State.RUNNING);

            // We are now waiting for the promise returned by the use to resolve before we know what state this node is in.
            this.isUsingUpdatePromise = true;
            this.updatePromise = actionFunctionResult;
        } else {
            // Validate the returned value.
            this.validateUpdateResult(actionFunctionResult);

            // Set the state of this node, this may be undefined, which just means that the node is still in the 'RUNNING' state.
            this.setState(actionFunctionResult || State.RUNNING);
        }
    }

    /**
     * Gets the name of the node.
     */
    getName = () => this.actionName;

    /**
     * Reset the state of the node.
     */
    reset = () => {
        // Reset the state of this node.
        this.setState(State.READY);

        // There is no longer an update promise that we care about.
        this.isUsingUpdatePromise = false;
        this.updatePromiseResult = null;
        this.updatePromise = null;
    };

    /**
     * Gets a snapshot of the execution state of this node.
     * @returns A snapshot of the execution state of this node.
     */
    public getSnapshot(): NodeSnapshot {
        let promiseResult = null;

        // The update promise only matters while this node is running, after that the node is resolved and it will be reset.
        if (this.is(State.RUNNING) && this.isUsingUpdatePromise) {
            // A promise that has not settled can't be captured, so this node is saved as not yet started and a restored node will call the action function again.
            if (!this.updatePromiseResult) {
                return { ...super.getSnapshot(), state: State.READY, promiseResult } as NodeSnapshot;
            }

            // The reason for a rejection is only ever used as part of an error message, so we only need to keep it as a string.
            promiseResult = {
                isResolved: this.updatePromiseResult.isResolved,
                value: String(this.updatePromiseResult.value)
            };
        }

        return { ...super.getSnapshot(), promiseResult } as NodeSnapshot;
    }

    /**
     * Validates a snapshot against this node.
     * @param snapshot The snapshot to validate.
     */
    public validateSnapshot(snapshot: unknown): void {
        super.validateSnapshot(snapshot);

        const { promiseResult } = snapshot as { promiseResult?: unknown };

        if (promiseResult === null) {
            return;
        }

        const { isResolved, value } = (promiseResult ?? {}) as Record<string, unknown>;

        if (typeof promiseResult !== "object" || typeof isResolved !== "boolean" || typeof value !== "string") {
            throw new Error("invalid snapshot: invalid promiseResult for 'action' node");
        }
    }

    /**
     * Restores the execution state of this node from a snapshot that has already been validated.
     * @param snapshot The snapshot to restore from.
     */
    public restoreSnapshot(snapshot: NodeSnapshot): void {
        const { promiseResult } = snapshot as { promiseResult: UpdatePromiseResult | null };

        // We can't restore a promise, only the result of one that already settled, so forget about any promise we are waiting on.
        this.updatePromise = null;
        this.isUsingUpdatePromise = promiseResult !== null;
        this.updatePromiseResult = promiseResult && {
            isResolved: promiseResult.isResolved,
            value: promiseResult.value
        };

        super.restoreSnapshot(snapshot);
    }

    /**
     * Gets the details of this node instance.
     * @returns The details of this node instance.
     */
    public getDetails(): NodeDetails {
        return {
            ...super.getDetails(),
            args: this.actionArguments
        };
    }

    /**
     * Called when the state of this node changes.
     * @param previousState The previous node state.
     */
    protected onStateChanged(previousState: State): void {
        this.options.onNodeStateChange?.({
            id: this.uid,
            type: this.getType(),
            args: this.actionArguments,
            while: this.attributes.while?.getDetails(),
            until: this.attributes.until?.getDetails(),
            entry: this.attributes.entry?.getDetails(),
            step: this.attributes.step?.getDetails(),
            exit: this.attributes.exit?.getDetails(),
            previousState,
            state: this.getState()
        });
    }

    /**
     * Validate the result of an update function call.
     * @param result The result of an update function call.
     */
    private validateUpdateResult = (result: CompleteState | State.RUNNING) => {
        switch (result) {
            case State.SUCCEEDED:
            case State.FAILED:
            case State.RUNNING:
            case undefined:
                return;
            default:
                throw new Error(
                    `expected action function '${this.actionName}' to return an optional State.SUCCEEDED or State.FAILED value but returned '${result}'`
                );
        }
    };
}
