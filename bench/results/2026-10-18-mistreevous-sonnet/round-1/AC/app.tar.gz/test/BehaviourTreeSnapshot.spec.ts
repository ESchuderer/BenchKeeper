import { assert } from "chai";
import sinon, { SinonFakeTimers } from "sinon";

import {
    BehaviourTree,
    BehaviourTreeOptions,
    BehaviourTreeSnapshot,
    convertMDSLToJSON,
    NodeDetails,
    State
} from "../src/index";
import { assertRestoredTreeBehavesLikeOriginal, Scenario } from "./SnapshotEquivalence";

describe("A BehaviourTree", () => {
    let clock: SinonFakeTimers;

    beforeEach(() => {
        clock = sinon.useFakeTimers();
    });

    afterEach(() => {
        clock.restore();
    });

    const getStates = (details: NodeDetails): any => ({
        type: details.type,
        state: details.state,
        children: details.children?.map(getStates)
    });

    describe("snapshot() will return", () => {
        it("an object describing the state of every node, starting from the root", () => {
            const tree = new BehaviourTree(
                "root { sequence { condition [isNot, 2] selector { condition [isNot, 5] flip { condition [isNot, 3] } } } }",
                { isNot: () => true }
            );

            assert.deepEqual(tree.snapshot(), {
                version: 1,
                definitionHash: (tree.snapshot() as any).definitionHash,
                root: {
                    type: "root",
                    state: State.READY,
                    children: [
                        {
                            type: "sequence",
                            state: State.READY,
                            children: [
                                { type: "condition", state: State.READY },
                                {
                                    type: "selector",
                                    state: State.READY,
                                    children: [
                                        { type: "condition", state: State.READY },
                                        {
                                            type: "flip",
                                            state: State.READY,
                                            children: [{ type: "condition", state: State.READY }]
                                        }
                                    ]
                                }
                            ]
                        }
                    ]
                }
            });
        });

        it("the current state of each node after the tree has been stepped", () => {
            const tree = new BehaviourTree("root { sequence { condition [isNot, 5] action [work, 2] action [ok] } }", {
                isNot: () => true,
                work: () => State.RUNNING,
                ok: () => State.SUCCEEDED
            });

            tree.step();

            const { root } = tree.snapshot();

            assert.equal(root.state, State.RUNNING);

            const sequence = (root as any).children[0];

            assert.deepEqual(
                sequence.children.map((child: any) => child.state),
                [State.SUCCEEDED, State.RUNNING, State.READY]
            );
        });

        it("a plain object that is unchanged by JSON serialisation", () => {
            const tree = new BehaviourTree(
                "root { sequence { wait [100, 200] repeat [2, 4] { action [work, 3] } retry [2, 3] { action [ok] } lotto { action [ok] action [ko] } } }",
                { work: () => State.RUNNING, ok: () => State.SUCCEEDED, ko: () => State.FAILED }
            );

            for (let step = 0; step < 4; step++) {
                const snapshot = tree.snapshot();

                assert.deepEqual(JSON.parse(JSON.stringify(snapshot)), snapshot);

                tree.step();
                clock.tick(150);
            }
        });

        it("a new object each time that is not changed by later steps of the tree", () => {
            const tree = new BehaviourTree("root { action [work, 2] }", { work: () => State.RUNNING });

            const snapshot = tree.snapshot();

            tree.step();

            assert.notStrictEqual(tree.snapshot(), snapshot);
            assert.equal(snapshot.root.state, State.READY);
        });
    });

    describe("a snapshot is independent of the trees it was taken from and restored to, so", () => {
        const definition = `root {
            sequence {
                repeat [2] { action [work, 2] }
                lotto { action [ok] action [ok] }
                parallel { wait [300] action [promise] }
                retry [2] { action [fail] }
            }
        }`;
        const flushPromises = () => new Promise<void>((resolve) => process.nextTick(resolve));
        const roundTrip = (value: unknown) => JSON.parse(JSON.stringify(value));

        /**
         * Creates a tree and a function that steps it and lets some time pass and promises settle. The tree is given an action
         * with a promise that settles or one that never does.
         */
        const createTree = (settlePromises: boolean) => {
            let workCalls = 0;

            const tree = new BehaviourTree(
                definition,
                {
                    work: (n: number) => (++workCalls % n === 0 ? State.SUCCEEDED : State.RUNNING),
                    ok: () => State.SUCCEEDED,
                    fail: () => State.FAILED,
                    promise: () => (settlePromises ? Promise.resolve(State.SUCCEEDED) : new Promise<State>(() => {}))
                },
                { random: () => 0.5 }
            );

            const step = async () => {
                tree.step();
                clock.tick(100);

                await flushPromises();
            };

            return { tree, step };
        };

        // A snapshot is taken at every step of a run of the tree. With promises that settle, that includes snapshots of an action
        // with a settled promise result and without. With promises that are pending, it includes snapshots of an action that has
        // a pending promise, which is saved as not yet started.
        for (const settlePromises of [true, false]) {
            describe(settlePromises ? "with promises that settle" : "with promises that are pending", () => {
                const STEPS = 14;

                it("stepping the tree it was taken from does not change it", async () => {
                    const { tree, step } = createTree(settlePromises);

                    for (let stepNumber = 0; stepNumber < STEPS; stepNumber++) {
                        await step();

                        const snapshot = tree.snapshot();
                        const serialised = JSON.stringify(snapshot);

                        for (let count = 1; count <= 3; count++) {
                            await step();

                            assert.equal(JSON.stringify(snapshot), serialised, `step ${stepNumber}, ${count} later`);
                        }
                    }
                });

                it("restoring it, and then stepping the tree it was restored to, does not change it", async () => {
                    const { tree, step } = createTree(settlePromises);

                    // This tree is stepped first so that it has some state of its own for restoring to replace.
                    const other = createTree(settlePromises);
                    await other.step();
                    await other.step();

                    for (let stepNumber = 0; stepNumber < STEPS; stepNumber++) {
                        await step();

                        const snapshot = tree.snapshot();
                        const serialised = JSON.stringify(snapshot);

                        other.tree.restore(snapshot);
                        assert.equal(JSON.stringify(snapshot), serialised, `restored at step ${stepNumber}`);

                        for (let count = 1; count <= 3; count++) {
                            await other.step();

                            assert.equal(JSON.stringify(snapshot), serialised, `step ${stepNumber}, ${count} later`);
                        }
                    }
                });

                it("a snapshot taken straight after restoring it is equal to it", async () => {
                    const { tree, step } = createTree(settlePromises);
                    const other = createTree(settlePromises);

                    for (let stepNumber = 0; stepNumber < STEPS; stepNumber++) {
                        await step();
                        await other.step();

                        const snapshot = roundTrip(tree.snapshot());

                        other.tree.restore(snapshot);

                        assert.deepEqual(roundTrip(other.tree.snapshot()), snapshot, `restored at step ${stepNumber}`);
                    }
                });
            });
        }
    });

    describe("restore() will", () => {
        it("give a tree built from the same definition the node states of the snapshot", () => {
            const definition =
                "root { sequence { condition [isNot, 5] parallel { action [work, 2] action [ok] } action [ok] } }";
            const createAgent = () => ({ isNot: () => true, work: () => State.RUNNING, ok: () => State.SUCCEEDED });

            const original = new BehaviourTree(definition, createAgent());
            original.step();

            const restored = new BehaviourTree(definition, createAgent());
            restored.restore(JSON.parse(JSON.stringify(original.snapshot())));

            assert.deepEqual(getStates(restored.getTreeNodeDetails()), getStates(original.getTreeNodeDetails()));
            assert.equal(restored.getState(), State.RUNNING);
            assert.isTrue(restored.isRunning());
        });

        it("replace the existing state of the tree it is called on", () => {
            const definition = "root { sequence { action [ok] action [work, 2] } }";
            const agent = { ok: () => State.SUCCEEDED, work: () => State.RUNNING };

            const tree = new BehaviourTree(definition, agent);
            const initialSnapshot = tree.snapshot();

            tree.step();
            assert.equal(tree.getState(), State.RUNNING);

            tree.restore(initialSnapshot);

            assert.deepEqual(tree.snapshot(), initialSnapshot);
            assert.equal(tree.getState(), State.READY);
        });

        it("not call any agent functions", () => {
            const calls: string[] = [];
            const agent = {
                ok: () => (calls.push("ok"), State.SUCCEEDED),
                work: () => (calls.push("work"), State.RUNNING),
                entry: () => void calls.push("entry"),
                exit: () => void calls.push("exit")
            };
            const definition = "root { sequence { action [ok] entry(entry) exit(exit) action [work] } }";

            const original = new BehaviourTree(definition, agent);
            original.step();
            calls.length = 0;

            new BehaviourTree(definition, agent).restore(original.snapshot());

            assert.deepEqual(calls, []);
        });

        it("restore a finished tree as finished, with the next step starting a new run", () => {
            const calls: string[] = [];
            const agent = { ok: () => (calls.push("ok"), State.SUCCEEDED), ko: () => (calls.push("ko"), State.FAILED) };
            const definition = "root { sequence { action [ok] action [ko] } }";

            const original = new BehaviourTree(definition, agent);
            original.step();

            assert.equal(original.getState(), State.FAILED);

            const restored = new BehaviourTree(definition, agent);
            restored.restore(JSON.parse(JSON.stringify(original.snapshot())));

            assert.equal(restored.getState(), State.FAILED);
            assert.isFalse(restored.isRunning());
            assert.deepEqual(getStates(restored.getTreeNodeDetails()), getStates(original.getTreeNodeDetails()));

            calls.length = 0;
            restored.step();

            assert.deepEqual(calls, ["ok", "ko"]);
            assert.equal(restored.getState(), State.FAILED);
        });

        it("not call the 'onNodeStateChange' option, but report the changes made by the next step as usual", () => {
            const definition = "root { sequence { action [ok] action [work] } }";
            const agent = { ok: () => State.SUCCEEDED, work: () => State.RUNNING, done: () => State.SUCCEEDED };

            const original = new BehaviourTree(definition, agent);
            original.step();

            const changes: any[] = [];
            const restored = new BehaviourTree(definition, agent, {
                onNodeStateChange: ({ type, previousState, state }) => changes.push({ type, previousState, state })
            });

            restored.restore(original.snapshot());

            assert.deepEqual(changes, []);
            assert.equal(restored.getState(), State.RUNNING);

            // Restoring over a tree that is in a different state is not a state change either.
            restored.restore(new BehaviourTree(definition, agent).snapshot());

            assert.deepEqual(changes, []);
            assert.equal(restored.getState(), State.READY);

            restored.restore(original.snapshot());
            restored.step();

            // The 'ok' action is already SUCCEEDED and the rest of the tree is already RUNNING, so nothing changes.
            assert.deepEqual(changes, []);

            const finished = new BehaviourTree(
                definition,
                { ...agent, work: () => State.SUCCEEDED },
                {
                    onNodeStateChange: ({ type, previousState, state }) => changes.push({ type, previousState, state })
                }
            );

            finished.restore(original.snapshot());
            finished.step();

            // Changes are reported from the restored states.
            assert.sameDeepMembers(changes, [
                { type: "action", previousState: State.RUNNING, state: State.SUCCEEDED },
                { type: "sequence", previousState: State.RUNNING, state: State.SUCCEEDED },
                { type: "root", previousState: State.RUNNING, state: State.SUCCEEDED }
            ]);
        });

        describe("throw an error and leave the tree unchanged if the snapshot", () => {
            const definition = "root { sequence { action [ok] selector { condition [isNot, 5] action [work] } } }";
            const agent = { ok: () => State.SUCCEEDED, isNot: () => true, work: () => State.RUNNING };

            let tree: BehaviourTree;
            let valid: BehaviourTreeSnapshot;

            beforeEach(() => {
                const source = new BehaviourTree(definition, agent);
                source.step();
                valid = JSON.parse(JSON.stringify(source.snapshot()));

                tree = new BehaviourTree(definition, agent);
            });

            const assertRejected = (snapshot: any, message: string) => {
                const before = tree.snapshot();

                assert.throws(() => tree.restore(snapshot), Error, message);
                assert.deepEqual(tree.snapshot(), before);
            };

            it("is not an object", () => {
                assertRejected(null, "invalid snapshot: expected an object");
                assertRejected("snapshot", "invalid snapshot: expected an object");
            });

            it("has an unsupported version", () => {
                assertRejected({ ...valid, version: 2 }, "invalid snapshot: unsupported version '2'");
                assertRejected({ root: valid.root }, "invalid snapshot: unsupported version 'undefined'");
            });

            it("has no root node", () => {
                assertRejected(
                    { version: 1, definitionHash: valid.definitionHash },
                    "invalid snapshot: expected a root node snapshot"
                );
            });

            it("has a node of a different type to the node it is for", () => {
                const snapshot = JSON.parse(JSON.stringify(valid));
                snapshot.root.children[0].children[1].type = "sequence";

                assertRejected(snapshot, "invalid snapshot: expected a 'selector' node snapshot but found 'sequence'");
            });

            it("has a different number of children to the node it is for", () => {
                const snapshot = JSON.parse(JSON.stringify(valid));
                snapshot.root.children[0].children.pop();

                assertRejected(snapshot, "invalid snapshot: expected 2 children for 'sequence' node but found 1");
            });

            it("has a node without children when the node it is for has some", () => {
                const snapshot = JSON.parse(JSON.stringify(valid));
                delete snapshot.root.children[0].children;

                assertRejected(snapshot, "invalid snapshot: expected 2 children for 'sequence' node but found 0");
            });

            it("has a node with an invalid state, even deep in the tree", () => {
                const snapshot = JSON.parse(JSON.stringify(valid));
                snapshot.root.children[0].children[1].children[1].state = "running";

                assertRejected(snapshot, "invalid snapshot: invalid state 'running' for 'action' node");
            });
        });
    });

    describe("the definition a snapshot belongs to", () => {
        const agent = {
            ok: () => State.SUCCEEDED,
            ko: () => State.FAILED,
            work: () => State.RUNNING,
            isNot: () => true,
            yes: () => true
        };

        afterEach(() => {
            BehaviourTree.unregisterAll();
        });

        const getDefinitionHash = (definition: any, options?: BehaviourTreeOptions): unknown =>
            (new BehaviourTree(definition, agent, options).snapshot() as any).definitionHash;

        const assertRejected = (tree: BehaviourTree, snapshot: unknown) => {
            const before = tree.snapshot();
            const detailsBefore = JSON.stringify(tree.getTreeNodeDetails());

            assert.throws(() => tree.restore(snapshot as BehaviourTreeSnapshot), Error, "does not match");
            assert.deepEqual(tree.snapshot(), before);
            assert.equal(JSON.stringify(tree.getTreeNodeDetails()), detailsBefore);
        };

        it("is recorded in a snapshot as a string that is the same for any tree built from the same definition", () => {
            const definition = "root { sequence { action [ok] wait [10] } }";

            const hash = getDefinitionHash(definition);

            assert.isString(hash);
            assert.isNotEmpty(hash as string);
            assert.equal(getDefinitionHash(definition), hash);
        });

        it("is not changed by the state of the tree", () => {
            const tree = new BehaviourTree("root { sequence { action [ok] action [work] } }", agent);
            const hash = (tree.snapshot() as any).definitionHash;

            tree.step();

            assert.equal((tree.snapshot() as any).definitionHash, hash);
        });

        it("is the same for an MDSL definition and the equivalent JSON definition", () => {
            const mdsl = `root {
                sequence entry(ok, "a") exit(ok) {
                    action [work, 2, true, null, "x"] while(isNot, 3) until(isNot) then succeed step(ok)
                    condition [isNot, $prop]
                    wait [10, 20]
                    repeat [2] { lotto [1, 3] { action [ok] action [ko] } }
                }
            }`;

            // JSON written by hand, which leaves out the empty argument lists and false 'succeedOnAbort' flags that the conversion from MDSL writes.
            const json = {
                type: "root",
                child: {
                    type: "sequence",
                    exit: { call: "ok" },
                    entry: { call: "ok", args: ["a"] },
                    children: [
                        {
                            type: "action",
                            call: "work",
                            args: [2, true, null, "x"],
                            while: { call: "isNot", args: [3] },
                            until: { call: "isNot", succeedOnAbort: true },
                            step: { call: "ok" }
                        },
                        { type: "condition", call: "isNot", args: [{ $: "prop" }] },
                        { type: "wait", duration: [10, 20] },
                        {
                            type: "repeat",
                            iterations: 2,
                            child: {
                                type: "lotto",
                                weights: [1, 3],
                                children: [
                                    { type: "action", call: "ok" },
                                    { type: "action", call: "ko" }
                                ]
                            }
                        }
                    ]
                }
            };

            const hash = getDefinitionHash(mdsl);

            assert.equal(getDefinitionHash(json), hash);
            assert.equal(getDefinitionHash(convertMDSLToJSON(mdsl)), hash);
            assert.equal(getDefinitionHash(JSON.parse(JSON.stringify(json))), hash);
        });

        it("is the same however the MDSL is formatted and whatever order the JSON properties and root nodes are in", () => {
            const hash = getDefinitionHash(
                "root { sequence { branch [Sub] action [ok] } } root [Sub] { action [work] }"
            );

            assert.equal(
                getDefinitionHash(`
                    /* the sub tree comes first */
                    root [Sub] { action [work] }
                    root { sequence { branch [Sub]   action [ok] } }
                `),
                hash
            );
            assert.equal(
                getDefinitionHash([
                    { id: "Sub", child: { args: [], call: "work", type: "action" }, type: "root" },
                    {
                        child: {
                            children: [
                                { ref: "Sub", type: "branch" },
                                { call: "ok", type: "action" }
                            ],
                            type: "sequence"
                        },
                        type: "root"
                    }
                ]),
                hash
            );
        });

        it("is not changed by the tree options or the agent", () => {
            const definition = "root { action [ok] }";

            assert.equal(
                getDefinitionHash(definition, { random: () => 0.5, getDeltaTime: () => 1 }),
                getDefinitionHash(definition)
            );
        });

        describe("will not match the definition of a snapshot of a tree that has a different", () => {
            const cases: [string, string, string][] = [
                [
                    "action function",
                    "root { sequence { action [ok] action [work] } }",
                    "root { sequence { action [ko] action [work] } }"
                ],
                ["action argument", "root { action [work, 1] }", "root { action [work, 2] }"],
                ["number of arguments", "root { action [work, 1] }", "root { action [work, 1, 1] }"],
                ["argument type", 'root { action [work, "1"] }', "root { action [work, 1] }"],
                ["agent property argument", "root { action [work, $a] }", "root { action [work, $b] }"],
                ["condition function", "root { condition [isNot, 1] }", "root { condition [yes, 1] }"],
                [
                    "node type",
                    "root { sequence { action [ok] action [ko] } }",
                    "root { selector { action [ok] action [ko] } }"
                ],
                [
                    "child order",
                    "root { sequence { action [ok] action [ko] } }",
                    "root { sequence { action [ko] action [ok] } }"
                ],
                [
                    "nesting",
                    "root { sequence { action [ok] action [ko] } }",
                    "root { sequence { action [ok] sequence { action [ko] } } }"
                ],
                ["wait duration", "root { wait [10] }", "root { wait [11] }"],
                ["wait duration range", "root { wait [10, 20] }", "root { wait [10, 21] }"],
                ["repeat count", "root { repeat [2] { action [ok] } }", "root { repeat [3] { action [ok] } }"],
                ["retry attempts", "root { retry [2, 4] { action [ok] } }", "root { retry [2, 5] { action [ok] } }"],
                [
                    "lotto weight",
                    "root { lotto [1, 2] { action [ok] action [ko] } }",
                    "root { lotto [1, 3] { action [ok] action [ko] } }"
                ],
                ["guard", "root { action [work] while(isNot) }", "root { action [work] until(isNot) }"],
                ["guard function", "root { action [work] while(isNot) }", "root { action [work] while(yes) }"],
                [
                    "guard result when aborted",
                    "root { action [work] while(isNot) }",
                    "root { action [work] while(isNot) then succeed }"
                ],
                ["callback", "root { action [work] entry(ok) }", "root { action [work] exit(ok) }"],
                ["callback argument", 'root { action [work] step(ok, "a") }', 'root { action [work] step(ok, "b") }'],
                ["root callback", "root entry(ok) { action [work] }", "root exit(ok) { action [work] }"],
                [
                    "subtree",
                    "root { branch [Sub] } root [Sub] { action [ok] }",
                    "root { branch [Sub] } root [Sub] { action [ko] }"
                ]
            ];

            for (const [difference, definition, otherDefinition] of cases) {
                it(difference, () => {
                    const source = new BehaviourTree(definition, agent);
                    source.step();

                    assert.notEqual(getDefinitionHash(definition), getDefinitionHash(otherDefinition));

                    const tree = new BehaviourTree(otherDefinition, agent);
                    tree.step();

                    assertRejected(tree, JSON.parse(JSON.stringify(source.snapshot())));
                });
            }

            it("registered subtree", () => {
                const definition = "root { sequence { action [ok] branch [Sub] } }";

                BehaviourTree.register("Sub", "root { action [work] }");
                const source = new BehaviourTree(definition, agent);
                source.step();

                BehaviourTree.register("Sub", "root { action [ko] }");
                const tree = new BehaviourTree(definition, agent);

                assertRejected(tree, source.snapshot());
            });
        });

        it("will match when a registered subtree is changed after the tree was built", () => {
            const definition = "root { sequence { action [ok] branch [Sub] } }";

            BehaviourTree.register("Sub", "root { action [work] }");
            const first = new BehaviourTree(definition, agent);
            const second = new BehaviourTree(definition, agent);
            const snapshot = first.snapshot();

            BehaviourTree.register("Sub", "root { action [ko] }");

            assert.doesNotThrow(() => second.restore(snapshot));
            assert.deepEqual(second.snapshot(), snapshot);
        });

        it("will cause restore() to throw an error that says the snapshot does not match the definition of the tree", () => {
            const source = new BehaviourTree("root { action [ok] }", agent);
            const tree = new BehaviourTree("root { action [ko] }", agent);

            assert.throws(
                () => tree.restore(source.snapshot()),
                Error,
                "the snapshot does not match the tree's definition"
            );
        });

        it("will be checked before the nodes of the snapshot are", () => {
            const source = new BehaviourTree("root { sequence { action [ok] action [ko] } }", agent);
            const tree = new BehaviourTree("root { action [ok] }", agent);

            assert.throws(() => tree.restore(source.snapshot()), Error, "does not match the tree's definition");
        });

        it("will leave the tree as it was when restore() rejects a snapshot, without calling the 'onNodeStateChange' option or any agent function", () => {
            const onNodeStateChange = sinon.spy();
            const work = sinon.stub().returns(State.RUNNING);

            const source = new BehaviourTree("root { sequence { action [work] action [ok] } }", agent);
            source.step();

            const tree = new BehaviourTree(
                "root { sequence { action [work] action [ko] } }",
                { ...agent, work },
                { onNodeStateChange }
            );
            tree.step();
            onNodeStateChange.resetHistory();
            work.resetHistory();

            assertRejected(tree, source.snapshot());
            assert.equal(onNodeStateChange.callCount, 0);
            assert.equal(work.callCount, 0);

            // The tree carries on as if restore() was never called.
            tree.step();
            assert.equal(work.callCount, 1);
            assert.equal(tree.getState(), State.RUNNING);
        });

        it("will let a tree be restored from a snapshot of an MDSL definition when it was built from the JSON definition", () => {
            const mdsl = "root { sequence { action [ok] action [work, 2] while(isNot, 3) } }";
            const source = new BehaviourTree(mdsl, agent);
            source.step();

            const tree = new BehaviourTree(convertMDSLToJSON(mdsl)[0], agent);
            tree.restore(JSON.parse(JSON.stringify(source.snapshot())));

            assert.deepEqual(getStates(tree.getTreeNodeDetails()), getStates(source.getTreeNodeDetails()));
        });
    });

    describe("restore() will throw an error and leave the tree unchanged if it is given", () => {
        const definition = "root { sequence { action [ok] action [work] } }";
        const agent = { ok: () => State.SUCCEEDED, work: () => State.RUNNING };

        for (const [description, value] of [
            ["null", null],
            ["undefined", undefined],
            ["a string", "snapshot"],
            ["a JSON string of a snapshot", JSON.stringify(new BehaviourTree(definition, agent).snapshot())],
            ["a number", 42],
            ["a boolean", true],
            ["a function", () => ({})],
            ["an array", []],
            ["an array of snapshots", [new BehaviourTree(definition, agent).snapshot()]],
            ["an empty object", {}],
            ["an object that is not a snapshot", { type: "root", state: State.READY, children: [] }],
            ["an object that has the fields of a snapshot but not all of them", { version: 1, root: {} }]
        ] as [string, unknown][]) {
            it(description, () => {
                const tree = new BehaviourTree(definition, agent);
                tree.step();
                const before = tree.snapshot();

                assert.throws(() => tree.restore(value as BehaviourTreeSnapshot), Error);
                assert.deepEqual(tree.snapshot(), before);
                assert.equal(tree.getState(), State.RUNNING);
            });
        }

        it("a snapshot without a definition", () => {
            const tree = new BehaviourTree(definition, agent);
            const snapshot = JSON.parse(JSON.stringify(tree.snapshot()));
            delete snapshot.definitionHash;

            assert.throws(() => tree.restore(snapshot), Error, "invalid snapshot");
        });

        for (const value of [null, 1, {}, [], true, ""]) {
            it(`a snapshot with a definition of ${JSON.stringify(value)}`, () => {
                const tree = new BehaviourTree(definition, agent);

                assert.throws(
                    () => tree.restore({ ...tree.snapshot(), definitionHash: value } as any),
                    Error,
                    "invalid snapshot"
                );
            });
        }
    });

    describe("a repeat node", () => {
        const agent = { ok: () => State.SUCCEEDED };
        const findNodeSnapshot = (tree: BehaviourTree, type: string): any => {
            const find = (node: any): any =>
                node.type === type ? node : (node.children ?? []).map(find).find((found: any) => !!found);

            return find(tree.snapshot().root);
        };

        it("has its iteration counts in a snapshot", () => {
            const tree = new BehaviourTree("root { repeat [3] { action [ok] } }", agent);

            assert.include(findNodeSnapshot(tree, "repeat"), { currentIterationCount: 0, targetIterationCount: null });

            tree.step();
            tree.step();

            assert.include(findNodeSnapshot(tree, "repeat"), { currentIterationCount: 2, targetIterationCount: 3 });
        });

        it("has the random number of iterations that was picked in a snapshot", () => {
            const tree = new BehaviourTree("root { repeat [2, 4] { action [ok] } }", agent, { random: () => 0.9 });

            tree.step();

            assert.include(findNodeSnapshot(tree, "repeat"), { currentIterationCount: 1, targetIterationCount: 4 });
        });

        it("has no target iteration count in a snapshot if it repeats indefinitely", () => {
            const tree = new BehaviourTree("root { repeat { action [ok] } }", agent);

            tree.step();

            assert.include(findNodeSnapshot(tree, "repeat"), { currentIterationCount: 1, targetIterationCount: null });
        });

        it("will continue from the restored iteration count towards the restored target without picking another random number", () => {
            const definition = "root { repeat [2, 4] { action [ok] } }";

            const original = new BehaviourTree(definition, agent, { random: () => 0.9 });
            original.step();
            original.step();

            const random = sinon.stub().returns(0);
            const ok = sinon.stub().returns(State.SUCCEEDED);
            const restored = new BehaviourTree(definition, { ok }, { random });
            restored.restore(JSON.parse(JSON.stringify(original.snapshot())));

            restored.step();
            restored.step();

            assert.equal(restored.getState(), State.RUNNING);

            restored.step();

            assert.equal(restored.getState(), State.SUCCEEDED);
            assert.equal(ok.callCount, 2);
            assert.equal(random.callCount, 0);
        });

        it("will pick a new random number of iterations on the next run after being restored as finished", () => {
            const definition = "root { repeat [2, 4] { action [ok] } }";

            const original = new BehaviourTree(definition, agent, { random: () => 0.9 });
            do {
                original.step();
            } while (original.isRunning());

            const random = sinon.stub().returns(0);
            const ok = sinon.stub().returns(State.SUCCEEDED);
            const restored = new BehaviourTree(definition, { ok }, { random });
            restored.restore(JSON.parse(JSON.stringify(original.snapshot())));

            assert.equal(restored.getState(), State.SUCCEEDED);
            assert.equal(random.callCount, 0);

            restored.step();
            restored.step();
            restored.step();

            assert.equal(restored.getState(), State.SUCCEEDED);
            assert.equal(random.callCount, 1);
            assert.equal(ok.callCount, 2);
        });

        it("will reject a snapshot with invalid iteration counts", () => {
            const tree = new BehaviourTree("root { repeat [3] { action [ok] } }", agent);

            for (const [field, value] of [
                ["currentIterationCount", -1],
                ["currentIterationCount", 1.5],
                ["currentIterationCount", "1"],
                ["currentIterationCount", undefined],
                ["targetIterationCount", -1],
                ["targetIterationCount", "3"],
                ["targetIterationCount", undefined]
            ]) {
                const snapshot = JSON.parse(JSON.stringify(tree.snapshot()));
                snapshot.root.children[0][field as string] = value;

                assert.throws(
                    () => tree.restore(snapshot),
                    Error,
                    `invalid snapshot: invalid ${field} '${value}' for 'repeat' node`
                );
            }
        });
    });

    describe("a retry node", () => {
        const agent = { ko: () => State.FAILED };
        const findNodeSnapshot = (tree: BehaviourTree): any => (tree.snapshot().root as any).children[0];

        it("has its attempt counts in a snapshot", () => {
            const tree = new BehaviourTree("root { retry [3] { action [ko] } }", agent);

            assert.include(findNodeSnapshot(tree), { currentAttemptCount: 0, targetAttemptCount: null });

            tree.step();
            tree.step();

            assert.include(findNodeSnapshot(tree), { currentAttemptCount: 2, targetAttemptCount: 3 });
        });

        it("has the random number of attempts that was picked in a snapshot", () => {
            const tree = new BehaviourTree("root { retry [2, 4] { action [ko] } }", agent, { random: () => 0.9 });

            tree.step();

            assert.include(findNodeSnapshot(tree), { currentAttemptCount: 1, targetAttemptCount: 4 });
        });

        it("has no target attempt count in a snapshot if it retries indefinitely", () => {
            const tree = new BehaviourTree("root { retry { action [ko] } }", agent);

            tree.step();

            assert.include(findNodeSnapshot(tree), { currentAttemptCount: 1, targetAttemptCount: null });
        });

        it("will continue from the restored attempt count towards the restored target without picking another random number", () => {
            const definition = "root { retry [2, 4] { action [ko] } }";

            const original = new BehaviourTree(definition, agent, { random: () => 0.9 });
            original.step();
            original.step();

            const random = sinon.stub().returns(0);
            const ko = sinon.stub().returns(State.FAILED);
            const restored = new BehaviourTree(definition, { ko }, { random });
            restored.restore(JSON.parse(JSON.stringify(original.snapshot())));

            restored.step();
            restored.step();

            assert.equal(restored.getState(), State.RUNNING);

            restored.step();

            assert.equal(restored.getState(), State.FAILED);
            assert.equal(ko.callCount, 2);
            assert.equal(random.callCount, 0);
        });

        it("will pick a new random number of attempts on the next run after being restored as finished", () => {
            const definition = "root { retry [2, 4] { action [ko] } }";

            const original = new BehaviourTree(definition, agent, { random: () => 0.9 });
            do {
                original.step();
            } while (original.isRunning());

            const random = sinon.stub().returns(0);
            const ko = sinon.stub().returns(State.FAILED);
            const restored = new BehaviourTree(definition, { ko }, { random });
            restored.restore(JSON.parse(JSON.stringify(original.snapshot())));

            assert.equal(restored.getState(), State.FAILED);
            assert.equal(random.callCount, 0);

            restored.step();
            restored.step();
            restored.step();

            assert.equal(restored.getState(), State.FAILED);
            assert.equal(random.callCount, 1);
            assert.equal(ko.callCount, 2);
        });

        it("will reject a snapshot with invalid attempt counts", () => {
            const tree = new BehaviourTree("root { retry [3] { action [ko] } }", agent);

            for (const [field, value] of [
                ["currentAttemptCount", -1],
                ["currentAttemptCount", 1.5],
                ["currentAttemptCount", undefined],
                ["targetAttemptCount", -1],
                ["targetAttemptCount", "3"],
                ["targetAttemptCount", undefined]
            ]) {
                const snapshot = JSON.parse(JSON.stringify(tree.snapshot()));
                snapshot.root.children[0][field as string] = value;

                assert.throws(
                    () => tree.restore(snapshot),
                    Error,
                    `invalid snapshot: invalid ${field} '${value}' for 'retry' node`
                );
            }
        });
    });

    describe("a lotto node", () => {
        const definition = "root { lotto { action [first] action [second] action [third] } }";
        const createAgent = () => ({
            first: sinon.stub().returns(State.RUNNING),
            second: sinon.stub().returns(State.RUNNING),
            third: sinon.stub().returns(State.RUNNING)
        });
        const getCalledAgentFunctions = (agent: ReturnType<typeof createAgent>) =>
            Object.entries(agent)
                .filter(([, stub]) => stub.called)
                .map(([name]) => name);

        it("has no selected child in a snapshot before the tree is stepped", () => {
            const tree = new BehaviourTree(definition, createAgent());

            assert.include((tree.snapshot().root as any).children[0], { type: "lotto", selectedChildIndex: null });
        });

        it("has the index of the child picked at random in a snapshot", () => {
            for (const [random, expectedIndex] of [
                [0, 0],
                [0.5, 1],
                [0.9, 2]
            ]) {
                const agent = createAgent();
                const tree = new BehaviourTree(definition, agent, { random: () => random });

                tree.step();

                assert.include((tree.snapshot().root as any).children[0], { selectedChildIndex: expectedIndex });
                assert.deepEqual(getCalledAgentFunctions(agent), [["first", "second", "third"][expectedIndex]]);
            }
        });

        it("will carry on with the restored selected child without picking another", () => {
            const original = new BehaviourTree(definition, createAgent(), { random: () => 0.9 });
            original.step();

            const random = sinon.stub().returns(0);
            const agent = createAgent();
            const restored = new BehaviourTree(definition, agent, { random });
            restored.restore(JSON.parse(JSON.stringify(original.snapshot())));

            restored.step();
            restored.step();

            assert.deepEqual(getCalledAgentFunctions(agent), ["third"]);
            assert.equal(agent.third.callCount, 2);
            assert.equal(random.callCount, 0);
        });

        it("will pick another child on the next run after being restored as finished", () => {
            const original = new BehaviourTree(
                definition,
                { ...createAgent(), third: () => State.SUCCEEDED },
                { random: () => 0.9 }
            );
            original.step();

            assert.equal(original.getState(), State.SUCCEEDED);

            const random = sinon.stub().returns(0);
            const agent = createAgent();
            const restored = new BehaviourTree(definition, agent, { random });
            restored.restore(JSON.parse(JSON.stringify(original.snapshot())));

            assert.equal(restored.getState(), State.SUCCEEDED);

            restored.step();

            assert.deepEqual(getCalledAgentFunctions(agent), ["first"]);
            assert.equal(random.callCount, 1);
        });

        it("will reject a snapshot with an invalid selected child index", () => {
            const tree = new BehaviourTree(definition, createAgent());

            for (const value of [-1, 3, 1.5, "1", undefined]) {
                const snapshot = JSON.parse(JSON.stringify(tree.snapshot()));
                snapshot.root.children[0].selectedChildIndex = value;

                assert.throws(
                    () => tree.restore(snapshot),
                    Error,
                    `invalid snapshot: invalid selectedChildIndex '${value}' for 'lotto' node`
                );
            }
        });
    });

    describe("a wait node", () => {
        const getWaitSnapshot = (tree: BehaviourTree): any => (tree.snapshot().root as any).children[0];

        const restoreCopy = (definition: string, tree: BehaviourTree, options: BehaviourTreeOptions = {}) => {
            const restored = new BehaviourTree(definition, {}, options);
            restored.restore(JSON.parse(JSON.stringify(tree.snapshot())));
            return restored;
        };

        describe("that is timed using the clock", () => {
            const definition = "root { wait [1000] }";

            it("has the duration it will wait for and how long it has waited in a snapshot", () => {
                const tree = new BehaviourTree(definition, {});

                assert.include(getWaitSnapshot(tree), { state: State.READY, totalDuration: null, waitedDuration: 0 });

                tree.step();

                assert.include(getWaitSnapshot(tree), { state: State.RUNNING, totalDuration: 1000, waitedDuration: 0 });
            });

            it("has the duration waited up to when the snapshot was taken, not up to the last step, in a snapshot", () => {
                const tree = new BehaviourTree(definition, {});

                tree.step();
                clock.tick(300);

                assert.include(getWaitSnapshot(tree), { waitedDuration: 300 });
            });

            it("will only wait for the remaining time once restored, however long the snapshot was held for", () => {
                const tree = new BehaviourTree(definition, {});

                tree.step();
                clock.tick(300);

                const snapshot = JSON.parse(JSON.stringify(tree.snapshot()));

                // The process goes away for a day.
                clock.tick(1000 * 60 * 60 * 24);

                const restored = new BehaviourTree(definition, {});
                restored.restore(snapshot);

                restored.step();
                assert.equal(restored.getState(), State.RUNNING);

                clock.tick(699);
                restored.step();
                assert.equal(restored.getState(), State.RUNNING);

                clock.tick(1);
                restored.step();
                assert.equal(restored.getState(), State.SUCCEEDED);
            });

            it("will succeed on the first step once restored if it had already waited long enough when the snapshot was taken", () => {
                const tree = new BehaviourTree(definition, {});

                tree.step();
                clock.tick(5000);

                const restored = restoreCopy(definition, tree);
                clock.tick(1000 * 60 * 60);

                restored.step();

                assert.equal(restored.getState(), State.SUCCEEDED);
            });

            it("will carry on being restored again and again with the time waited unchanged", () => {
                const tree = new BehaviourTree(definition, {});

                tree.step();
                clock.tick(300);

                const first = restoreCopy(definition, tree);
                clock.tick(1000);
                const second = restoreCopy(definition, first);
                clock.tick(1000);

                assert.deepEqual(second.snapshot(), tree.snapshot());
            });
        });

        describe("that is timed using the 'getDeltaTime' option", () => {
            const definition = "root { wait [1000] }";

            it("has the duration waited, which is not changed by the clock, in a snapshot", () => {
                const tree = new BehaviourTree(definition, {}, { getDeltaTime: () => 0.1 });

                tree.step();
                tree.step();
                tree.step();
                clock.tick(5000);

                assert.include(getWaitSnapshot(tree), {
                    state: State.RUNNING,
                    totalDuration: 1000,
                    waitedDuration: 300
                });
            });

            it("will only wait for the remaining time once restored, however long the snapshot was held for", () => {
                const tree = new BehaviourTree(definition, {}, { getDeltaTime: () => 0.1 });

                tree.step();
                tree.step();
                tree.step();

                const snapshot = JSON.parse(JSON.stringify(tree.snapshot()));

                clock.tick(1000 * 60 * 60 * 24);

                const restored = new BehaviourTree(definition, {}, { getDeltaTime: () => 0.1 });
                restored.restore(snapshot);

                // The wait has 700ms to go.
                for (let step = 0; step < 6; step++) {
                    restored.step();
                    assert.equal(restored.getState(), State.RUNNING);
                }

                restored.step();
                assert.equal(restored.getState(), State.SUCCEEDED);
            });
        });

        describe("with a random duration", () => {
            const definition = "root { wait [1000, 2000] }";

            it("has the random duration that was picked in a snapshot", () => {
                const tree = new BehaviourTree(definition, {}, { random: () => 0.5 });

                tree.step();

                assert.include(getWaitSnapshot(tree), { totalDuration: 1500 });
            });

            it("will wait for the restored duration without picking another random duration", () => {
                const tree = new BehaviourTree(definition, {}, { random: () => 0.5 });

                tree.step();
                clock.tick(1000);

                const random = sinon.stub().returns(0);
                const restored = restoreCopy(definition, tree, { random });

                restored.step();
                assert.equal(restored.getState(), State.RUNNING);

                clock.tick(499);
                restored.step();
                assert.equal(restored.getState(), State.RUNNING);

                clock.tick(1);
                restored.step();
                assert.equal(restored.getState(), State.SUCCEEDED);
                assert.equal(random.callCount, 0);
            });

            it("will pick another duration, and start waiting again, on the next run after being restored as finished", () => {
                const tree = new BehaviourTree(definition, {}, { random: () => 0.5 });

                tree.step();
                clock.tick(1500);
                tree.step();

                assert.equal(tree.getState(), State.SUCCEEDED);

                const random = sinon.stub().returns(0);
                const restored = restoreCopy(definition, tree, { random });
                clock.tick(1000 * 60 * 60);

                assert.equal(restored.getState(), State.SUCCEEDED);
                assert.equal(random.callCount, 0);

                restored.step();
                assert.equal(restored.getState(), State.RUNNING);
                assert.equal(random.callCount, 1);

                clock.tick(999);
                restored.step();
                assert.equal(restored.getState(), State.RUNNING);

                clock.tick(1);
                restored.step();
                assert.equal(restored.getState(), State.SUCCEEDED);
            });
        });

        describe("with no duration", () => {
            it("has no duration in a snapshot and will keep waiting once restored", () => {
                const definition = "root { wait }";
                const tree = new BehaviourTree(definition, {});

                tree.step();

                assert.include(getWaitSnapshot(tree), { state: State.RUNNING, totalDuration: null });

                const restored = restoreCopy(definition, tree);
                clock.tick(1000 * 60 * 60 * 24);
                restored.step();

                assert.equal(restored.getState(), State.RUNNING);
            });
        });

        it("will reject a snapshot with an invalid duration", () => {
            const tree = new BehaviourTree("root { wait [1000] }", {});

            for (const [field, value] of [
                ["totalDuration", "1000"],
                ["totalDuration", -1],
                ["totalDuration", undefined],
                ["waitedDuration", "10"],
                ["waitedDuration", null],
                ["waitedDuration", undefined]
            ]) {
                const snapshot = JSON.parse(JSON.stringify(tree.snapshot()));
                snapshot.root.children[0][field as string] = value;

                assert.throws(
                    () => tree.restore(snapshot),
                    Error,
                    `invalid snapshot: invalid ${field} '${value}' for 'wait' node`
                );
            }
        });
    });

    describe("an action node", () => {
        const flushPromises = () => new Promise<void>((resolve) => process.nextTick(resolve));
        const getActionSnapshot = (tree: BehaviourTree): any => (tree.snapshot().root as any).children[0];

        it("has no promise result in a snapshot if its function does not return a promise", () => {
            const tree = new BehaviourTree("root { action [work] }", { work: () => State.RUNNING });

            tree.step();

            assert.deepEqual(getActionSnapshot(tree), { type: "action", state: State.RUNNING, promiseResult: null });
        });

        it("will call its function again on the next step once restored if its function does not return a promise", () => {
            const definition = "root { action [work] }";
            const work = sinon.stub().returns(State.RUNNING);

            const original = new BehaviourTree(definition, { work });
            original.step();

            const restored = new BehaviourTree(definition, { work });
            restored.restore(JSON.parse(JSON.stringify(original.snapshot())));
            work.resetHistory();

            restored.step();

            assert.equal(work.callCount, 1);
        });

        describe("whose function returned a promise", () => {
            const definition = "root { action [work] }";

            describe("that has not settled", () => {
                const createAgent = () => {
                    const promises: Array<(state: State) => void> = [];
                    const work = sinon.spy(() => new Promise<State>((resolve) => promises.push(resolve)));

                    return { work, promises, agent: { work, ok: () => State.SUCCEEDED } };
                };

                it("will not cause a snapshot of the tree to be refused", () => {
                    const { agent } = createAgent();
                    const tree = new BehaviourTree(definition, agent);

                    tree.step();

                    assert.doesNotThrow(() => tree.snapshot());
                });

                it("will be an action that has not started in a snapshot, with no promise result", () => {
                    const { agent } = createAgent();
                    const tree = new BehaviourTree(definition, agent);

                    tree.step();

                    assert.deepEqual(getActionSnapshot(tree), {
                        type: "action",
                        state: State.READY,
                        promiseResult: null
                    });
                    assert.equal(tree.snapshot().root.state, State.RUNNING);
                    assert.deepEqual(JSON.parse(JSON.stringify(tree.snapshot())), tree.snapshot());
                });

                it("will not change the tree that the snapshot was taken from", async () => {
                    const { agent, work, promises } = createAgent();
                    const tree = new BehaviourTree(definition, agent);

                    tree.step();
                    tree.snapshot();

                    assert.equal(getStates(tree.getTreeNodeDetails()).children[0].state, State.RUNNING);

                    promises[0](State.SUCCEEDED);
                    await flushPromises();
                    tree.step();

                    assert.equal(tree.getState(), State.SUCCEEDED);
                    assert.equal(work.callCount, 1);
                });

                it("will have its function called again on the next step once restored, and then wait on the new promise", async () => {
                    const original = createAgent();
                    const restoredAgent = createAgent();

                    const tree = new BehaviourTree(definition, original.agent);
                    tree.step();

                    const restored = new BehaviourTree(definition, restoredAgent.agent);
                    restored.restore(JSON.parse(JSON.stringify(tree.snapshot())));

                    assert.equal(restoredAgent.work.callCount, 0);

                    restored.step();

                    assert.equal(restoredAgent.work.callCount, 1);
                    assert.equal(restored.getState(), State.RUNNING);

                    restored.step();

                    assert.equal(restoredAgent.work.callCount, 1);

                    restoredAgent.promises[0](State.FAILED);
                    await flushPromises();
                    restored.step();

                    assert.equal(restored.getState(), State.FAILED);
                    assert.equal(restoredAgent.work.callCount, 1);
                });

                it("will not be changed by the promise that was pending when the snapshot was taken settling after the tree is restored", async () => {
                    const { agent, work, promises } = createAgent();
                    const tree = new BehaviourTree(definition, agent);

                    tree.step();
                    tree.restore(tree.snapshot());
                    tree.step();

                    assert.equal(work.callCount, 2);

                    promises[0](State.SUCCEEDED);
                    await flushPromises();
                    tree.step();

                    assert.equal(tree.getState(), State.RUNNING);
                    assert.equal(work.callCount, 2);

                    promises[1](State.FAILED);
                    await flushPromises();
                    tree.step();

                    assert.equal(tree.getState(), State.FAILED);
                });

                it("will have the rest of the tree restored as it was, with the action starting again where it left off", () => {
                    const sequence = "root { sequence { action [ok] entry(ok) action [work] action [ok] } }";
                    const { agent, work } = createAgent();

                    const tree = new BehaviourTree(sequence, agent);
                    tree.step();

                    const restored = new BehaviourTree(sequence, createAgent().agent);
                    restored.restore(tree.snapshot());

                    assert.deepEqual(
                        getStates(restored.getTreeNodeDetails()).children[0].children.map((child: any) => child.state),
                        [State.SUCCEEDED, State.READY, State.READY]
                    );
                    assert.equal(restored.getState(), State.RUNNING);
                    assert.equal(work.callCount, 1);
                });

                it("will be restored as not yet started wherever the action is in the tree", () => {
                    const nested =
                        "root { parallel { action [ok] repeat [2] { sequence { action [ok] action [work] while(isNot) } } } }";
                    const nestedAgent = createAgent();

                    const tree = new BehaviourTree(nested, { ...nestedAgent.agent, isNot: () => true });
                    tree.step();

                    const restoredAgent = createAgent();
                    const restored = new BehaviourTree(nested, { ...restoredAgent.agent, isNot: () => true });
                    restored.restore(JSON.parse(JSON.stringify(tree.snapshot())));
                    restored.step();

                    assert.equal(restoredAgent.work.callCount, 1);
                    assert.equal(restored.getState(), State.RUNNING);
                });
            });

            it("will not cause a snapshot of the tree to be refused when it is not running", async () => {
                const tree = new BehaviourTree(definition, { work: () => Promise.resolve(State.SUCCEEDED) });

                tree.step();
                await flushPromises();
                tree.step();

                assert.equal(tree.getState(), State.SUCCEEDED);
                assert.deepEqual(getActionSnapshot(tree), {
                    type: "action",
                    state: State.SUCCEEDED,
                    promiseResult: null
                });

                tree.reset();

                assert.deepEqual(getActionSnapshot(tree), { type: "action", state: State.READY, promiseResult: null });
            });

            for (const result of [State.SUCCEEDED, State.FAILED]) {
                it(`will have the result in a snapshot, and move to the ${result} state on the next step once restored without calling its function again, if the promise resolved with ${result}`, async () => {
                    const work = sinon.stub().resolves(result);
                    const original = new BehaviourTree(definition, { work });

                    original.step();
                    await flushPromises();

                    assert.deepEqual(getActionSnapshot(original), {
                        type: "action",
                        state: State.RUNNING,
                        promiseResult: { isResolved: true, value: result }
                    });

                    const restoredWork = sinon.stub().returns(State.RUNNING);
                    const restored = new BehaviourTree(definition, { work: restoredWork });
                    restored.restore(JSON.parse(JSON.stringify(original.snapshot())));

                    restored.step();

                    assert.equal(restored.getState(), result);
                    assert.equal(restoredWork.callCount, 0);
                });
            }

            it("will have the reason in a snapshot, and throw on the next step once restored, if the promise was rejected", async () => {
                const original = new BehaviourTree(definition, { work: () => Promise.reject(new Error("boom")) });

                original.step();
                await flushPromises();

                assert.deepEqual(getActionSnapshot(original), {
                    type: "action",
                    state: State.RUNNING,
                    promiseResult: { isResolved: false, value: "Error: boom" }
                });

                const restored = new BehaviourTree(definition, { work: () => State.RUNNING });
                restored.restore(JSON.parse(JSON.stringify(original.snapshot())));

                assert.throws(
                    () => restored.step(),
                    Error,
                    "error stepping tree: action function 'work' promise rejected with 'Error: boom'"
                );
                assert.throws(
                    () => original.step(),
                    Error,
                    "error stepping tree: action function 'work' promise rejected with 'Error: boom'"
                );
            });

            it("will throw on the next step once restored if the promise resolved with an invalid value", async () => {
                const original = new BehaviourTree(definition, { work: () => Promise.resolve(undefined as any) });

                original.step();
                await flushPromises();

                const restored = new BehaviourTree(definition, { work: () => State.RUNNING });
                restored.restore(JSON.parse(JSON.stringify(original.snapshot())));

                const expected = "action node promise resolved with an invalid value";

                assert.throws(() => restored.step(), Error, expected);
                assert.throws(() => original.step(), Error, expected);
            });

            it("will not have a promise that was pending before the tree was restored change the restored tree", async () => {
                let resolveFirstPromise: (state: State) => void = () => {};
                let calls = 0;

                const tree = new BehaviourTree(definition, {
                    work: () =>
                        ++calls === 1
                            ? new Promise((resolve) => (resolveFirstPromise = resolve))
                            : new Promise(() => {})
                });
                const readySnapshot = tree.snapshot();

                tree.step();
                tree.restore(readySnapshot);
                tree.step();

                resolveFirstPromise(State.SUCCEEDED);
                await flushPromises();
                tree.step();

                assert.equal(tree.getState(), State.RUNNING);
                assert.equal(calls, 2);
            });
        });

        it("will reject a snapshot with an invalid promise result", () => {
            const tree = new BehaviourTree("root { action [work] }", { work: () => State.RUNNING });

            for (const value of [
                {},
                { isResolved: true },
                { value: "x" },
                { isResolved: "yes", value: "x" },
                { isResolved: true, value: 1 },
                "x",
                undefined
            ]) {
                const snapshot = JSON.parse(JSON.stringify(tree.snapshot()));
                snapshot.root.children[0].promiseResult = value;

                assert.throws(
                    () => tree.restore(snapshot),
                    Error,
                    "invalid snapshot: invalid promiseResult for 'action' node"
                );
            }
        });
    });

    describe("a tree restored from a snapshot will behave as the tree the snapshot was taken from, whenever it was taken, if", () => {
        const scenarios: Scenario[] = [
            {
                name: "sequence",
                definition:
                    "root { sequence { condition [isNot, 7] action [work, 3] action [choosy, 2] action [work, 2] } }",
                steps: 12
            },
            {
                name: "selector",
                definition: "root { selector { action [choosy, 4] action [flaky, 3] action [work, 2] } }",
                steps: 12
            },
            {
                name: "parallel",
                definition:
                    "root { parallel { action [work, 3] action [work, 4] sequence { action [ok] action [work, 2] } } }",
                steps: 12
            },
            {
                name: "failing parallel",
                definition: "root { parallel { action [work, 5] action [flaky, 3] action [work, 2] } }",
                steps: 10
            },
            {
                name: "race",
                definition: "root { race { action [work, 5] action [work, 3] action [flaky, 4] } }",
                steps: 10
            },
            {
                name: "all",
                definition: "root { all { action [work, 5] action [flaky, 3] action [work, 2] } }",
                steps: 10
            },
            {
                name: "flip, succeed and fail",
                definition:
                    "root { sequence { flip { action [work, 2] } succeed { action [flaky, 2] } fail { action [work, 2] } } }",
                steps: 12
            },
            {
                name: "repeat with a fixed number of iterations",
                definition: "root { repeat [3] { sequence { action [work, 2] action [ok] } } }",
                steps: 14
            },
            {
                name: "repeat with a random number of iterations",
                definition: "root { sequence { repeat [2, 5] { action [work, 3] } action [ok] } }",
                steps: 20
            },
            {
                name: "repeat until the child fails",
                definition: "root { repeat { sequence { action [work, 2] condition [isNot, 7] } } }",
                steps: 16
            },
            {
                name: "retry with a fixed number of attempts",
                definition: "root { retry [3] { sequence { action [work, 2] action [choosy, 5] } } }",
                steps: 16
            },
            {
                name: "retry with a random number of attempts",
                definition: "root { sequence { retry [2, 5] { action [flaky, 3] } action [ok] } }",
                steps: 20
            },
            {
                name: "retry until the child succeeds",
                definition: "root { retry { sequence { action [work, 2] action [choosy, 7] } } }",
                steps: 16
            },
            {
                name: "nested repeat and retry",
                definition:
                    "root { repeat [2, 3] { retry [2, 4] { sequence { action [work, 2] action [choosy, 3] } } } }",
                steps: 24
            },
            {
                name: "lotto",
                definition:
                    "root { lotto { action [work, 3] action [work, 4] sequence { action [ok] action [work, 2] } } }",
                steps: 12
            },
            {
                name: "weighted lotto that is repeated",
                definition:
                    "root { repeat [3] { lotto [1, 5, 2] { action [work, 2] action [choosy, 2] action [flaky, 3] } } }",
                steps: 20
            },
            {
                name: "wait",
                definition: "root { sequence { action [ok] wait [100] action [work, 2] } }",
                steps: 12
            },
            {
                name: "wait with a random duration",
                definition: "root { repeat [2] { sequence { wait [80, 240] action [choosy, 2] } } }",
                steps: 24
            },
            {
                name: "wait with no duration, aborted by a guard",
                definition: "root { parallel { wait while(isNot, 6) action [work, 8] } }",
                steps: 12
            },
            {
                name: "wait in a race",
                definition:
                    "root { race { wait [200] sequence { wait [100, 300] action [work, 2] } action [work, 9] } }",
                steps: 16
            },
            {
                name: "subtrees that are used more than once",
                definition:
                    "root { sequence { branch [Work] branch [Work] repeat [2] { branch [Work] } } } root [Work] { retry [2, 3] { sequence { wait [60, 120] action [choosy, 2] } } }",
                steps: 30
            },
            {
                name: "a guard on a node with counters",
                definition:
                    'root { sequence { repeat [4] while(isNot, 5) exit(log, "repeat") { action [work, 3] } action [ok] } }',
                steps: 16
            },
            {
                name: "guards and callbacks",
                definition:
                    'root { sequence entry(log, "seq") exit(log, "seq") { action [work, 4] while(isNot, 3) entry(log, "a") step(log, "a") exit(log, "a") action [work, 3] until(isNot, 9) exit(log, "b") } }',
                steps: 14
            }
        ];

        for (const scenario of scenarios) {
            it(`the tree is a ${scenario.name}`, () => {
                for (const useDeltaTime of [false, true]) {
                    for (const randomOffset of [0, 3]) {
                        assertRestoredTreeBehavesLikeOriginal(scenario, clock, useDeltaTime, randomOffset);
                    }
                }
            });
        }
    });
});
