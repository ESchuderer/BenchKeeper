import { assert } from "chai";
import { SinonFakeTimers } from "sinon";

import { BehaviourTree, NodeDetails, State } from "../src/index";

/**
 * The (fake) time that passes between each step of a tree.
 */
const STEP_INTERVAL_MS = 40;

/**
 * The (fake) time that passes between a snapshot being taken and being restored.
 */
const DOWNTIME_MS = 1000 * 60 * 60 * 24;

/**
 * The values returned, in order and cycling, by the 'random' option of the trees under test.
 */
const RANDOM_VALUES = [0.1, 0.9, 0.5, 0.3, 0.75, 0, 0.99, 0.42];

/**
 * A scenario in which a snapshot of a tree is restored at every point of its execution.
 */
export type Scenario = {
    /**
     * The scenario name.
     */
    name: string;
    /**
     * The MDSL tree definition.
     */
    definition: string;
    /**
     * The number of steps the original tree is stepped for before the tree runs out of steps to snapshot.
     */
    steps: number;
};

/**
 * Removes the node ids, which are random for each tree instance, from the node details.
 */
function stripIds({ id, children, ...details }: NodeDetails): any {
    return { ...details, children: children?.map(stripIds) };
}

/**
 * A behaviour tree and an agent that records everything the tree does to it.
 * The agent behaves as a pure function of the step number, so two runs are given identical stimuli.
 */
class Run {
    /**
     * Everything the tree did, in order: agent function calls, 'random' calls and the tree state after each step.
     */
    public readonly trace: string[] = [];

    public randomCalls: number;

    public readonly tree: BehaviourTree;

    constructor(definition: string, private stepNumber: number, randomOffset: number, useDeltaTime: boolean) {
        this.randomCalls = randomOffset;

        const call = (name: string, args: any[]) => this.trace.push(`${this.stepNumber}: ${name}(${args.join(",")})`);

        const agent = {
            ok: () => (call("ok", []), State.SUCCEEDED),
            ko: () => (call("ko", []), State.FAILED),
            // Succeeds on every nth step, running until then.
            work: (n: number) => (call("work", [n]), this.stepNumber % n === 0 ? State.SUCCEEDED : State.RUNNING),
            // Fails on every nth step, running until then.
            flaky: (n: number) => (call("flaky", [n]), this.stepNumber % n === 0 ? State.FAILED : State.RUNNING),
            // Succeeds on every nth step and fails immediately otherwise.
            choosy: (n: number) => (call("choosy", [n]), this.stepNumber % n === 0 ? State.SUCCEEDED : State.FAILED),
            // True unless the step number is a multiple of n.
            isNot: (n: number) => (call("isNot", [n]), this.stepNumber % n !== 0),
            log: (...args: any[]) =>
                void call(
                    "log",
                    args.map((arg) => JSON.stringify(arg))
                )
        };

        this.tree = new BehaviourTree(definition, agent, {
            random: () => {
                const value = RANDOM_VALUES[this.randomCalls++ % RANDOM_VALUES.length];
                this.trace.push(`random() => ${value}`);
                return value;
            },
            ...(useDeltaTime ? { getDeltaTime: () => STEP_INTERVAL_MS / 1000 } : {})
        });
    }

    /**
     * Steps the tree, recording the resulting state of the tree.
     */
    public step(clock: SinonFakeTimers) {
        this.tree.step();

        this.trace.push(
            `${this.stepNumber}: ${this.tree.getState()} ${JSON.stringify(stripIds(this.tree.getTreeNodeDetails()))}`
        );

        this.stepNumber++;

        clock.tick(STEP_INTERVAL_MS);
    }

    public getStepNumber() {
        return this.stepNumber;
    }
}

/**
 * Asserts that a tree restored from a snapshot of an original tree, taken at any point of the original tree's
 * execution, does exactly what the original would have done from that point: the same agent function calls in the same
 * order, the same 'random' calls, and the same node states after each step. This holds if time passes between the
 * snapshot being taken and restored, and when the snapshot has been through JSON.
 * @param scenario The scenario.
 * @param clock The fake clock used for Date.
 * @param useDeltaTime Whether the trees should use the 'getDeltaTime' option, or the clock, to measure wait durations.
 * @param randomOffset The index in the 'random' values to start from.
 * @param totalSteps The total number of steps, snapshot or not, that each tree is stepped for.
 */
export function assertRestoredTreeBehavesLikeOriginal(
    { name, definition, steps }: Scenario,
    clock: SinonFakeTimers,
    useDeltaTime: boolean,
    randomOffset: number,
    totalSteps: number = steps * 2
) {
    for (let splitAt = 0; splitAt <= steps; splitAt++) {
        const description = `'${name}' (${
            useDeltaTime ? "getDeltaTime" : "Date"
        }) snapshot taken after ${splitAt} steps`;

        clock.setSystemTime(0);

        const original = new Run(definition, 0, randomOffset, useDeltaTime);

        while (original.getStepNumber() < splitAt) {
            original.step(clock);
        }

        const snapshot = original.tree.snapshot();
        const detailsAtSnapshot = stripIds(original.tree.getTreeNodeDetails());
        const stateAtSnapshot = original.tree.getState();
        const traceLengthAtSnapshot = original.trace.length;
        const randomCallsAtSnapshot = original.randomCalls;

        // A snapshot has to survive JSON unchanged.
        assert.deepEqual(JSON.parse(JSON.stringify(snapshot)), snapshot, `${description}: snapshot not JSON-safe`);

        while (original.getStepNumber() < totalSteps) {
            original.step(clock);
        }

        // Pretend the process went away for a while.
        clock.tick(DOWNTIME_MS);

        const restored = new Run(definition, splitAt, randomCallsAtSnapshot, useDeltaTime);

        restored.tree.restore(JSON.parse(JSON.stringify(snapshot)));

        assert.deepEqual(
            stripIds(restored.tree.getTreeNodeDetails()),
            detailsAtSnapshot,
            `${description}: node details`
        );
        assert.equal(restored.tree.getState(), stateAtSnapshot, `${description}: tree state`);
        assert.deepEqual(restored.tree.snapshot(), snapshot, `${description}: snapshot of restored tree`);

        while (restored.getStepNumber() < totalSteps) {
            restored.step(clock);
        }

        assert.deepEqual(restored.trace, original.trace.slice(traceLengthAtSnapshot), description);
    }
}
