Status: ready-for-agent

# Snapshot / restore of tree execution state

`BehaviourTree.snapshot()` returns a JSON-safe object; `BehaviourTree.restore(snapshot)` puts a tree built from the
same definition into that state. Storage, events and scheduling stay in the application.

## Format

```
BehaviourTreeSnapshot = { version: 1, definition: string, root: NodeSnapshot }
NodeSnapshot = { type, state, children?, ...per-type fields }
```

- The snapshot mirrors the node tree (children by position), so it needs no node ids (ids are random per build).
- Only `null`, numbers, strings, booleans, arrays and objects. Never `undefined` (JSON would drop the key).
- `definition` is an id (hash) of the validated JSON definition with sorted keys, so an MDSL definition and its equivalent
  JSON definition match. `restore()` rejects a snapshot with a different id, or that is not a snapshot at all.
- `type` and the child count are also checked on restore.
- Registered subtrees are not part of the definition id; a different registered subtree is caught only by the node checks.

| Node | Extra state kept |
| ---- | ---------------- |
| all nodes | `state` |
| composites, decorators | `children` (this holds which children are done/running) |
| lotto | `selectedChild`: index of the picked child, or `null` |
| repeat | `targetCount` (null = infinite, or the random pick), `currentCount` |
| retry | `targetCount`, `currentCount` |
| wait | `totalDuration` (null = indefinite, or the random pick), `waitedDuration` |
| action | `settledPromise`: `null`, or the settled-but-unconsumed promise result |
| condition, flip, succeed, fail, root | nothing |

## Decisions

- **Wait timing.** Snapshot stores elapsed time, never a timestamp. With the clock, elapsed is `now - initialUpdateTime`
  at snapshot time, and restore sets `initialUpdateTime = now - elapsed`, so the time between snapshot and restore does
  not count. With `getDeltaTime`, elapsed is the accumulated `waitedDuration`, which only moves on `step()`.
- **Finished trees.** Nothing special: root state is SUCCEEDED/FAILED, the next `step()` resets and re-rolls random choices.
- **Atomic restore.** The whole snapshot is validated before any node is touched, so a bad snapshot throws and leaves
  the tree as it was.
- **State-change events.** Restoring goes through `setState`, so `onNodeStateChange` fires for nodes whose state changes,
  like `reset()` does.
- **Async actions.** A pending promise cannot be serialised. An action whose promise is still pending is captured as
  READY (not yet started) with no promise, so its function (and entry callback) is called again on the next step. A promise that has settled but was not
  yet consumed by a step is kept (resolved value if SUCCEEDED/FAILED, otherwise `null`; a rejection reason as a string).
- No snapshot of agent state, registered functions, or option callbacks: those belong to the application.
