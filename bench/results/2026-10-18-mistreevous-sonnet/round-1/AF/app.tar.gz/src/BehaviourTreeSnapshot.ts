import { AnyState } from "./State";

/**
 * The execution state of a single node in a behaviour tree, containing only values that survive JSON serialisation.
 * Child snapshots are in the same order as the node children, and only the properties relevant to the node type are defined.
 */
export type NodeSnapshot = {
    /**
     * The node type.
     */
    type: string;
    /**
     * The node state.
     */
    state: AnyState;
    /**
     * The snapshots of the child nodes, defined if this node is a composite or decorator node.
     */
    children?: NodeSnapshot[];
    /**
     * The target number of iterations (`repeat`) or attempts (`retry`), or null if there is no target.
     */
    targetCount?: number | null;
    /**
     * The number of iterations (`repeat`) or attempts (`retry`) made so far.
     */
    currentCount?: number;
    /**
     * The index of the child picked by a `lotto` node, or null if it has not picked one.
     */
    selectedChild?: number | null;
    /**
     * The duration in milliseconds that a `wait` node is waiting for, or null if it will wait indefinitely.
     */
    totalDuration?: number | null;
    /**
     * The duration in milliseconds that a `wait` node has waited for.
     */
    waitedDuration?: number;
    /**
     * The result of an `action` node promise that has settled but has not yet been handled by a step, or null if there is none.
     * The value is the state that a promise resolved with if it was SUCCEEDED or FAILED, otherwise null, or the rejection reason as a string.
     */
    settledPromise?: { isResolved: boolean; value: string | null } | null;
};

/**
 * The execution state of a behaviour tree, as returned by `BehaviourTree.snapshot()` and accepted by `BehaviourTree.restore()`.
 * It is a plain object that is unchanged by serialising it to JSON and parsing it again.
 */
export type BehaviourTreeSnapshot = {
    /**
     * The snapshot format version.
     */
    version: 1;
    /**
     * An id of the definition of the tree that the snapshot was taken from, which is the same whether the definition was MDSL or JSON.
     */
    definition: string;
    /**
     * The snapshot of the root node.
     */
    root: NodeSnapshot;
};
