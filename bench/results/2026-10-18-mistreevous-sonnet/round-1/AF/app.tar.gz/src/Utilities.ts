/**
 * Create a randomly generated node uid.
 * @returns A randomly generated node uid.
 */
export function createUid(): string {
    const S4 = function () {
        return (((1 + Math.random()) * 0x10000) | 0).toString(16).substring(1);
    };
    return S4() + S4() + "-" + S4() + "-" + S4() + "-" + S4() + "-" + S4() + S4() + S4();
}

/**
 * Gets whether the specified value is a finite number that is not negative.
 * @param value The value to check.
 * @returns Whether the specified value is a finite number that is not negative.
 */
export function isNonNegativeNumber(value: unknown): value is number {
    return typeof value === "number" && isFinite(value) && value >= 0;
}

/**
 * Gets a string that is the same for any two values that serialise to JSON with the same content, regardless of property order.
 * @param value The JSON serialisable value.
 * @returns A short string identifying the content of the value.
 */
export function getContentId(value: unknown): string {
    const json = JSON.stringify(value, (_, child) =>
        child && typeof child === "object" && !Array.isArray(child)
            ? Object.fromEntries(Object.entries(child).sort(([a], [b]) => (a < b ? -1 : a > b ? 1 : 0)))
            : child
    );

    // The cyrb53 hash, which is plenty to tell apart definitions without being a dependency or needing a platform crypto API.
    let h1 = 0xdeadbeef;
    let h2 = 0x41c6ce57;
    for (let i = 0; i < json.length; i++) {
        h1 = Math.imul(h1 ^ json.charCodeAt(i), 2654435761);
        h2 = Math.imul(h2 ^ json.charCodeAt(i), 1597334677);
    }
    h1 = Math.imul(h1 ^ (h1 >>> 16), 2246822507) ^ Math.imul(h2 ^ (h2 >>> 13), 3266489909);
    h2 = Math.imul(h2 ^ (h2 >>> 16), 2246822507) ^ Math.imul(h1 ^ (h1 >>> 13), 3266489909);

    return (4294967296 * (2097151 & h2) + (h1 >>> 0)).toString(36);
}
