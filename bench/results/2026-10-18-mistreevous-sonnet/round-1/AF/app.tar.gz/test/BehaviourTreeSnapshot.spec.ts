import { assert } from "chai";
import sinon, { SinonFakeTimers } from "sinon";

import { BehaviourTree, State, convertMDSLToJSON } from "../src/index";
import type { BehaviourTreeSnapshot, NodeDetails } from "../src/index";
import { Agent } from "../src/Agent";

type World = { step: number };

/**
 * A repeatable source of 'random' numbers whose position can be copied from one source to another.
 */
function createRandom() {
    const values = [0.7, 0.2, 0.9, 0.4, 0.1, 0.6];
    const random = { position: 0, next: () => values[random.position++ % values.length] };
    return random;
}

const withoutIds = (details: NodeDetails): any => {
    const { id, children, ...rest } = details;
    return children ? { ...rest, children: children.map(withoutIds) } : rest;
};

const roundTrip = (snapshot: BehaviourTreeSnapshot): BehaviourTreeSnapshot => JSON.parse(JSON.stringify(snapshot));

describe("A BehaviourTree instance", () => {
    let clock: SinonFakeTimers;

    beforeEach(() => {
        clock = sinon.useFakeTimers();
    });

    afterEach(() => {
        clock.restore();
    });

    /**
     * Steps a tree 'before' times, restores a snapshot of it into a second tree built from the same definition and then
     * steps both trees 'after' times, checking after every step that they call the same agent functions and have the same state.
     * Agent functions should only depend on the world step so that both agents behave identically.
     * @returns The calls made by the original tree after the snapshot was taken, and the calls made by the restored tree.
     */
    function assertRestoredTreeMatchesOriginal(
        definition: string,
        createAgent: (calls: string[], world: World) => Agent,
        { before, after, useDeltaTime = false }: { before: number; after: number; useDeltaTime?: boolean }
    ) {
        const tickMs = 100;
        const world: World = { step: 0 };
        const originalCalls: string[] = [];
        const restoredCalls: string[] = [];
        const originalRandom = createRandom();
        const restoredRandom = createRandom();

        const createTree = (calls: string[], random: ReturnType<typeof createRandom>) =>
            new BehaviourTree(definition, createAgent(calls, world), {
                random: random.next,
                ...(useDeltaTime ? { getDeltaTime: () => tickMs / 1000 } : {})
            });

        const advance = () => {
            world.step++;
            clock.tick(tickMs);
        };

        const original = createTree(originalCalls, originalRandom);

        for (let i = 0; i < before; i++) {
            advance();
            original.step();
        }

        const snapshot = roundTrip(original.snapshot());

        // Random choices made before the snapshot must not be made again, so the restored tree continues from the same random position.
        const restored = createTree(restoredCalls, restoredRandom);
        restoredRandom.position = originalRandom.position;
        restored.restore(snapshot);

        assert.deepEqual(withoutIds(restored.getTreeNodeDetails()), withoutIds(original.getTreeNodeDetails()));

        originalCalls.length = 0;

        const states: State[] = [];

        for (let i = 0; i < after; i++) {
            advance();
            original.step();
            restored.step();
            states.push(restored.getState());

            assert.deepEqual(restoredCalls, originalCalls, `calls differ after step ${i + 1}`);
            assert.deepEqual(
                withoutIds(restored.getTreeNodeDetails()),
                withoutIds(original.getTreeNodeDetails()),
                `node details differ after step ${i + 1}`
            );
        }

        return { calls: originalCalls, states, original, restored };
    }

    // Each action succeeds once the world reaches the step in its name suffix, or runs until then.
    const stepActions = (calls: string[], world: World): Agent => {
        const until =
            (name: string, step: number, result: State.SUCCEEDED | State.FAILED = State.SUCCEEDED) =>
            () => {
                calls.push(name);
                return world.step >= step ? result : State.RUNNING;
            };

        return {
            A: until("A", 0),
            B: until("B", 4),
            C: until("C", 0),
            FailA: until("FailA", 0, State.FAILED),
            Slow: until("Slow", 6),
            Immediate: until("Immediate", 0)
        };
    };

    describe("has a 'snapshot' function that", () => {
        const definition = `root {
            sequence {
                repeat [2, 4] { action [A] }
                retry [2, 4] { flip { action [A] } }
                lotto [1, 1, 1] { action [A] action [B] action [C] }
                wait [1000, 3000]
                succeed { condition [IsTrue] }
                fail { action [A] }
            }
        }`;

        const createTree = () =>
            new BehaviourTree(
                definition,
                { ...stepActions([], { step: 0 }), IsTrue: () => true },
                { random: createRandom().next }
            );

        it("returns a plain object that is unchanged by JSON serialisation at any point of a run", () => {
            const tree = createTree();

            for (let i = 0; i < 40; i++) {
                const snapshot = tree.snapshot();
                assert.deepEqual(roundTrip(snapshot), snapshot);
                assert.strictEqual(JSON.stringify(roundTrip(snapshot)), JSON.stringify(snapshot));

                clock.tick(500);
                tree.step();
            }
        });

        it("returns a snapshot that does not change when the tree is stepped afterwards", () => {
            const tree = createTree();
            const snapshot = tree.snapshot();
            const serialised = JSON.stringify(snapshot);

            tree.step();
            tree.step();

            assert.strictEqual(JSON.stringify(snapshot), serialised);
        });

        it("is independent of the trees it is taken from and restored into, at any point of a run", () => {
            const tree = createTree();
            const restored = createTree();

            for (let i = 0; i < 40; i++) {
                const snapshot = tree.snapshot();
                const serialised = JSON.stringify(snapshot);

                restored.restore(snapshot);
                assert.strictEqual(JSON.stringify(roundTrip(restored.snapshot())), serialised, `after restore ${i}`);

                clock.tick(500);
                tree.step();
                restored.step();

                assert.strictEqual(JSON.stringify(snapshot), serialised, `after stepping ${i}`);
            }
        });

        it("is independent of the tree when it holds the result of a settled promise", async () => {
            const definition = "root { action [Work] }";
            const tree = new BehaviourTree(definition, { Work: () => Promise.resolve(State.SUCCEEDED) });
            tree.step();
            await Promise.resolve();

            const snapshot = tree.snapshot();
            const serialised = JSON.stringify(snapshot);

            const restored = new BehaviourTree(definition, { Work: () => State.RUNNING });
            restored.restore(snapshot);
            assert.strictEqual(JSON.stringify(roundTrip(restored.snapshot())), serialised);

            tree.step();
            restored.step();
            assert.strictEqual(JSON.stringify(snapshot), serialised);
        });
    });

    describe("has a 'restore' function that", () => {
        describe("sets a tree built from the same definition to the state of the tree the snapshot was taken from", () => {
            it("(sequence)", () => {
                const { calls } = assertRestoredTreeMatchesOriginal(
                    "root { sequence { action [A] action [B] action [C] } }",
                    stepActions,
                    { before: 2, after: 2 }
                );

                // 'A' had already succeeded before the snapshot, so it is never called again.
                assert.deepEqual(calls, ["B", "B", "C"]);
            });

            it("(selector)", () => {
                const { calls } = assertRestoredTreeMatchesOriginal(
                    "root { selector { action [FailA] action [B] action [C] } }",
                    stepActions,
                    { before: 2, after: 2 }
                );

                assert.deepEqual(calls, ["B", "B"]);
            });

            it("(parallel)", () => {
                const { calls } = assertRestoredTreeMatchesOriginal(
                    "root { parallel { action [A] action [B] } }",
                    stepActions,
                    { before: 2, after: 2 }
                );

                assert.deepEqual(calls, ["B", "B"]);
            });

            it("(race)", () => {
                const { calls } = assertRestoredTreeMatchesOriginal(
                    "root { race { action [FailA] action [B] action [Slow] } }",
                    stepActions,
                    { before: 2, after: 2 }
                );

                assert.deepEqual(calls, ["B", "Slow", "B", "Slow"]);
            });

            it("(all)", () => {
                const { calls } = assertRestoredTreeMatchesOriginal(
                    "root { all { action [A] action [B] action [Slow] } }",
                    stepActions,
                    { before: 2, after: 4 }
                );

                assert.deepEqual(calls, ["B", "Slow", "B", "Slow", "Slow", "Slow"]);
            });

            it("(lotto), keeping the child that was picked", () => {
                const { calls } = assertRestoredTreeMatchesOriginal(
                    "root { lotto [1, 1, 1] { action [A] action [B] action [C] } }",
                    (calls, world) => ({
                        A: () => (calls.push("A"), world.step >= 4 ? State.SUCCEEDED : State.RUNNING),
                        B: () => (calls.push("B"), world.step >= 4 ? State.SUCCEEDED : State.RUNNING),
                        C: () => (calls.push("C"), world.step >= 4 ? State.SUCCEEDED : State.RUNNING)
                    }),
                    { before: 2, after: 2 }
                );

                // Only a single child is ever called, and it is the same one on both trees.
                assert.lengthOf(new Set(calls), 1);
            });

            it("(repeat), keeping the random iteration count and current iteration", () => {
                const { calls } = assertRestoredTreeMatchesOriginal(
                    "root { repeat [2, 4] { action [A] } }",
                    stepActions,
                    { before: 2, after: 3 }
                );

                // The first random value picks 4 iterations, 2 of which were made before the snapshot.
                assert.deepEqual(calls, ["A", "A"]);
            });

            it("(repeat) with an explicit iteration count", () => {
                const { calls } = assertRestoredTreeMatchesOriginal("root { repeat [3] { action [A] } }", stepActions, {
                    before: 1,
                    after: 3
                });

                assert.deepEqual(calls, ["A", "A"]);
            });

            it("(retry), keeping the random attempt count and current attempt", () => {
                const { calls } = assertRestoredTreeMatchesOriginal(
                    "root { retry [2, 4] { action [FailA] } }",
                    stepActions,
                    { before: 3, after: 2 }
                );

                assert.deepEqual(calls, ["FailA"]);
            });

            it("(wait) using the clock, keeping the random duration and the time already waited", () => {
                // The first random value picks a duration of 2400ms, and 1000ms have been waited before the snapshot.
                const { states } = assertRestoredTreeMatchesOriginal("root { wait [1000, 3000] }", stepActions, {
                    before: 10,
                    after: 15
                });

                assert.include(states, State.SUCCEEDED);
            });

            it("(wait) using the 'getDeltaTime' option, keeping the random duration and the time already waited", () => {
                const { states } = assertRestoredTreeMatchesOriginal("root { wait [1000, 3000] }", stepActions, {
                    before: 10,
                    after: 15,
                    useDeltaTime: true
                });

                assert.include(states, State.SUCCEEDED);
            });

            it("(root, flip, succeed, fail and condition)", () => {
                assertRestoredTreeMatchesOriginal(
                    `root {
                        sequence {
                            flip { condition [IsFalse] }
                            succeed { action [FailA] }
                            fail { action [B] }
                        }
                    }`,
                    (calls, world) => ({
                        ...stepActions(calls, world),
                        IsFalse: () => (calls.push("IsFalse"), false)
                    }),
                    { before: 3, after: 4 }
                );
            });

            it("(callbacks), without calling the entry callback again for a running node", () => {
                const { calls } = assertRestoredTreeMatchesOriginal(
                    "root { action [B] entry(OnEntry) step(OnStep) exit(OnExit) }",
                    (calls, world) => ({
                        ...stepActions(calls, world),
                        OnEntry: () => calls.push("OnEntry"),
                        OnStep: () => calls.push("OnStep"),
                        OnExit: () => calls.push("OnExit")
                    }),
                    { before: 2, after: 2 }
                );

                assert.deepEqual(calls, ["OnStep", "B", "OnStep", "B", "OnExit"]);
            });

            it("(guards), aborting a restored running node when its guard is no longer satisfied", () => {
                const { calls } = assertRestoredTreeMatchesOriginal(
                    "root { action [B] while(IsOk) exit(OnExit) }",
                    (calls, world) => ({
                        ...stepActions(calls, world),
                        IsOk: () => world.step < 3,
                        OnExit: () => calls.push("OnExit")
                    }),
                    { before: 2, after: 2 }
                );

                assert.deepEqual(calls, ["OnExit"]);
            });

            it("(nested composites and decorators)", () => {
                assertRestoredTreeMatchesOriginal(
                    `root {
                        sequence {
                            repeat [2] {
                                parallel {
                                    action [A]
                                    retry [3] { sequence { condition [IsFalse] action [C] } }
                                }
                            }
                            wait [400]
                            selector { action [FailA] action [Slow] }
                        }
                    }`,
                    (calls, world) => ({
                        ...stepActions(calls, world),
                        IsFalse: () => (calls.push("IsFalse"), world.step > 1)
                    }),
                    { before: 3, after: 10 }
                );
            });
        });

        describe("makes a restored `wait` node wait only for the remaining time", () => {
            it("when using the clock", () => {
                const tree = new BehaviourTree("root { wait [1000] }", {});

                tree.step();
                clock.tick(400);

                const snapshot = roundTrip(tree.snapshot());

                // An hour passes before the snapshot is restored.
                clock.tick(60 * 60 * 1000);

                const restored = new BehaviourTree("root { wait [1000] }", {});
                restored.restore(snapshot);

                clock.tick(599);
                restored.step();
                assert.strictEqual(restored.getState(), State.RUNNING);

                clock.tick(1);
                restored.step();
                assert.strictEqual(restored.getState(), State.SUCCEEDED);
            });

            it("when using the 'getDeltaTime' option", () => {
                let deltaTime = 0.4;
                const options = { getDeltaTime: () => deltaTime };

                const tree = new BehaviourTree("root { wait [1000] }", {}, options);
                tree.step();

                const snapshot = roundTrip(tree.snapshot());

                // Time passes before the snapshot is restored, but the tree is not stepped.
                clock.tick(60 * 60 * 1000);

                const restored = new BehaviourTree("root { wait [1000] }", {}, options);
                restored.restore(snapshot);

                deltaTime = 0.5;
                restored.step();
                assert.strictEqual(restored.getState(), State.RUNNING);

                deltaTime = 0.1;
                restored.step();
                assert.strictEqual(restored.getState(), State.SUCCEEDED);
            });

            it("when the clock was set back after the node started waiting", () => {
                const tree = new BehaviourTree("root { wait [1000] }", {});

                tree.step();
                clock.setSystemTime(-5000);

                const restored = new BehaviourTree("root { wait [1000] }", {});
                restored.restore(roundTrip(tree.snapshot()));

                clock.tick(1000);
                restored.step();
                assert.strictEqual(restored.getState(), State.SUCCEEDED);
            });

            it("when it is restored into the tree that the snapshot was taken from", () => {
                const tree = new BehaviourTree("root { wait [1000] }", {});

                tree.step();
                clock.tick(400);

                const snapshot = tree.snapshot();

                clock.tick(5000);
                tree.restore(snapshot);

                clock.tick(599);
                tree.step();
                assert.strictEqual(tree.getState(), State.RUNNING);

                clock.tick(1);
                tree.step();
                assert.strictEqual(tree.getState(), State.SUCCEEDED);
            });
        });

        describe("restores a snapshot of a tree that has not started or has finished", () => {
            it("as not started", () => {
                const definition = "root { sequence { action [A] action [B] } }";
                const agent = stepActions([], { step: 0 });

                const snapshot = roundTrip(new BehaviourTree(definition, agent).snapshot());

                const restored = new BehaviourTree(definition, agent);
                restored.step();
                assert.strictEqual(restored.getState(), State.RUNNING);

                restored.restore(snapshot);
                assert.strictEqual(restored.getState(), State.READY);
                assert.deepEqual(
                    withoutIds(restored.getTreeNodeDetails()),
                    withoutIds(new BehaviourTree(definition, agent).getTreeNodeDetails())
                );
            });

            it("as finished, and the next step starts a new run that makes its random choices again", () => {
                const { calls, original, restored } = assertRestoredTreeMatchesOriginal(
                    "root { repeat [2, 4] { action [A] } }",
                    stepActions,
                    { before: 5, after: 3 }
                );

                assert.strictEqual(original.getState(), State.SUCCEEDED);
                assert.strictEqual(restored.getState(), State.SUCCEEDED);

                // The first run picked 4 iterations, the second run picks 2.
                assert.deepEqual(calls, ["A", "A"]);
            });

            it("as finished and failed", () => {
                const definition = "root { retry [2] { action [FailA] } }";
                const calls: string[] = [];
                const agent = { FailA: () => (calls.push("FailA"), State.FAILED) };

                const tree = new BehaviourTree(definition, agent);
                tree.step();
                tree.step();
                tree.step();
                assert.strictEqual(tree.getState(), State.FAILED);

                const restored = new BehaviourTree(definition, agent);
                restored.restore(roundTrip(tree.snapshot()));
                assert.strictEqual(restored.getState(), State.FAILED);

                calls.length = 0;
                restored.step();
                assert.deepEqual(calls, ["FailA"]);
                assert.strictEqual(restored.getState(), State.RUNNING);
            });
        });

        describe("can be used to roll a tree back", () => {
            it("by restoring a snapshot taken earlier into the same tree", () => {
                const calls: string[] = [];
                const world = { step: 0 };
                const tree = new BehaviourTree(
                    "root { sequence { action [A] action [B] action [C] } }",
                    stepActions(calls, world)
                );

                tree.step();
                const snapshot = tree.snapshot();

                world.step = 4;
                tree.step();
                assert.strictEqual(tree.getState(), State.SUCCEEDED);

                tree.restore(snapshot);
                assert.strictEqual(tree.getState(), State.RUNNING);

                calls.length = 0;
                tree.step();
                assert.deepEqual(calls, ["B", "C"]);
            });

            it("and does not call the 'onNodeStateChange' option, but the next step reports changes as usual", () => {
                const changes: string[] = [];
                const definition = "root { sequence { action [A] action [B] } }";
                const world = { step: 0 };
                const agent = stepActions([], world);

                const running = new BehaviourTree(definition, agent);
                running.step();
                const snapshot = running.snapshot();

                const restored = new BehaviourTree(definition, agent, {
                    onNodeStateChange: ({ type, previousState, state }) =>
                        changes.push(`${type}:${previousState}>${state}`)
                });
                restored.restore(snapshot);

                assert.deepEqual(changes, []);

                world.step = 4;
                restored.step();

                assert.sameMembers(changes, [
                    `action:${State.RUNNING}>${State.SUCCEEDED}`,
                    `sequence:${State.RUNNING}>${State.SUCCEEDED}`,
                    `root:${State.RUNNING}>${State.SUCCEEDED}`
                ]);
            });
        });

        describe("handles async actions", () => {
            const definition = "root { action [Work] }";

            it("by calling the action function again for a restored action whose promise was still pending", () => {
                const first = { Work: sinon.stub().returns(new Promise(() => {})) };
                const tree = new BehaviourTree(definition, first);
                tree.step();

                const second = { Work: sinon.stub().returns(new Promise(() => {})) };
                const restored = new BehaviourTree(definition, second);
                restored.restore(roundTrip(tree.snapshot()));

                assert.strictEqual(restored.getTreeNodeDetails().children![0].state, State.READY);

                restored.step();
                sinon.assert.calledOnce(second.Work);
                assert.strictEqual(restored.getState(), State.RUNNING);
            });

            it("by restoring an action whose promise was still pending as not yet started, so its entry callback is called again", () => {
                const pendingDefinition = "root { action [Work] entry(OnEntry) }";
                const agent = (OnEntry: () => void) => ({ Work: () => new Promise<State>(() => {}), OnEntry });
                const tree = new BehaviourTree(
                    pendingDefinition,
                    agent(() => {})
                );
                tree.step();

                const onEntry = sinon.stub();
                const restored = new BehaviourTree(pendingDefinition, agent(onEntry));
                restored.restore(roundTrip(tree.snapshot()));
                restored.step();

                sinon.assert.calledOnce(onEntry);
            });

            it("by keeping a settled promise result that was not yet handled", async () => {
                const tree = new BehaviourTree(definition, { Work: () => Promise.resolve(State.SUCCEEDED) });
                tree.step();
                await Promise.resolve();

                const agent = { Work: sinon.stub() };
                const restored = new BehaviourTree(definition, agent);
                restored.restore(roundTrip(tree.snapshot()));
                restored.step();

                sinon.assert.notCalled(agent.Work);
                assert.strictEqual(restored.getState(), State.SUCCEEDED);
            });

            it("by keeping a rejected promise result that was not yet handled", async () => {
                const tree = new BehaviourTree(definition, { Work: () => Promise.reject(new Error("boom")) });
                tree.step();
                await Promise.resolve();

                const restored = new BehaviourTree(definition, { Work: sinon.stub() });
                restored.restore(roundTrip(tree.snapshot()));

                assert.throws(
                    () => restored.step(),
                    Error,
                    "action function 'Work' promise rejected with 'Error: boom'"
                );
            });

            it("by keeping a settled promise result that resolved to an invalid value", async () => {
                const tree = new BehaviourTree(definition, { Work: () => Promise.resolve("nope" as any) });
                tree.step();
                await Promise.resolve();

                const restored = new BehaviourTree(definition, { Work: sinon.stub() });
                restored.restore(roundTrip(tree.snapshot()));

                assert.throws(() => restored.step(), Error, "action node promise resolved with an invalid value");
            });
        });

        describe("accepts a snapshot of a tree that was built from an equivalent definition", () => {
            const mdsl = `root {
                sequence while(IsTrue) {
                    action [A, 1, "two", true, null] entry(OnEntry)
                    repeat [2, 4] { branch [Sub] }
                    wait [1000]
                }
            }
            root [Other] { action [B] }`;
            const agent = { A: () => State.SUCCEEDED, IsTrue: () => true, OnEntry: () => {} };

            const restoreInto = (snapshotDefinition: any, restoredDefinition: any) => {
                const tree = new BehaviourTree(snapshotDefinition, agent);
                tree.step();
                const restored = new BehaviourTree(restoredDefinition, agent);
                restored.restore(roundTrip(tree.snapshot()));
                assert.deepEqual(withoutIds(restored.getTreeNodeDetails()), withoutIds(tree.getTreeNodeDetails()));
            };

            before(() => BehaviourTree.register("Sub", "root { action [A] }"));
            after(() => BehaviourTree.unregisterAll());

            it("when one is MDSL and the other is the equivalent JSON", () => {
                const json = convertMDSLToJSON(mdsl);
                restoreInto(mdsl, json);
                restoreInto(json, mdsl);
            });

            it("when the JSON has a different property order, or is a single root node rather than an array", () => {
                const reverseKeys = (value: any): any =>
                    Array.isArray(value)
                        ? value.map(reverseKeys)
                        : value && typeof value === "object"
                        ? Object.fromEntries(
                              Object.entries(value)
                                  .reverse()
                                  .map(([key, child]) => [key, reverseKeys(child)])
                          )
                        : value;
                const json = convertMDSLToJSON("root { sequence { action [A] wait [1000] } }");

                restoreInto(json, reverseKeys(json));
                restoreInto(json[0], json);
                restoreInto(json, json[0]);
            });
        });

        describe("throws an error and leaves the tree unchanged when the snapshot", () => {
            const definition =
                "root { sequence { repeat [2] { action [A] } lotto [1, 1] { action [B] action [C] } wait [1000] } }";
            const agent = () => stepActions([], { step: 0 });

            const validSnapshot = () => {
                const tree = new BehaviourTree(definition, agent());
                tree.step();
                return roundTrip(tree.snapshot());
            };

            const assertRejectedValue = (value: unknown, message: string) => {
                const tree = new BehaviourTree(definition, agent());
                tree.step();
                const before = tree.snapshot();

                assert.throws(() => tree.restore(value as any), Error, `error restoring tree: ${message}`);
                assert.deepEqual(tree.snapshot(), before);
            };

            const assertRejected = (modify: (snapshot: any) => void, message: string) => {
                const snapshot = validSnapshot();
                modify(snapshot);
                assertRejectedValue(snapshot, message);
            };

            const sequenceOf = (snapshot: any) => snapshot.root.children[0];
            const repeatOf = (snapshot: any) => sequenceOf(snapshot).children[0];
            const lottoOf = (snapshot: any) => sequenceOf(snapshot).children[1];
            const waitOf = (snapshot: any) => sequenceOf(snapshot).children[2];

            it("is not an object", () => {
                assertRejectedValue(null, "snapshot must be an object");
                assertRejectedValue("snapshot", "snapshot must be an object");
            });

            it("is an array, a number or an object without the snapshot fields", () => {
                assertRejectedValue([], "snapshot must be an object");
                assertRejectedValue(5, "snapshot must be an object");
                assertRejectedValue({}, "unsupported snapshot version");
                assertRejectedValue({ version: 1 }, "invalid snapshot");
                assertRejectedValue({ version: 1, root: validSnapshot().root }, "invalid snapshot");
                assertRejectedValue({ version: 1, definition: "x", root: null }, "invalid snapshot");
            });

            it("was taken from a tree with a different definition", () => {
                const other = new BehaviourTree("root { sequence { action [A] wait [1000] } }", agent());
                other.step();

                // Differs only in an argument, so it would pass the node type and child count checks.
                const otherArgument = new BehaviourTree(
                    "root { sequence { repeat [3] { action [A] } lotto [1, 1] { action [B] action [C] } wait [1000] } }",
                    agent()
                );
                otherArgument.step();

                assertRejectedValue(roundTrip(other.snapshot()), "snapshot does not match the tree's definition");
                assertRejectedValue(
                    roundTrip(otherArgument.snapshot()),
                    "snapshot does not match the tree's definition"
                );
            });

            it("has an unsupported version", () => {
                assertRejected((snapshot) => (snapshot.version = 2), "unsupported snapshot version");
            });

            it("has a node of the wrong type", () => {
                assertRejected(
                    (snapshot) => (sequenceOf(snapshot).type = "selector"),
                    "expected a 'sequence' node snapshot but got 'selector'"
                );
            });

            it("has the wrong number of children for a node", () => {
                assertRejected(
                    (snapshot) => sequenceOf(snapshot).children.pop(),
                    "expected 3 child node snapshots but got 2"
                );
                assertRejected(
                    (snapshot) => delete sequenceOf(snapshot).children,
                    "expected 3 child node snapshots but got 0"
                );
            });

            it("has a node with an invalid state", () => {
                assertRejected((snapshot) => (waitOf(snapshot).state = "bad"), "invalid node state");
            });

            it("has invalid iteration counts for a repeat node", () => {
                assertRejected((snapshot) => (repeatOf(snapshot).currentCount = -1), "invalid repeat node snapshot");
                assertRejected((snapshot) => (repeatOf(snapshot).targetCount = "2"), "invalid repeat node snapshot");
            });

            it("has an invalid selected child for a lotto node", () => {
                assertRejected((snapshot) => (lottoOf(snapshot).selectedChild = 2), "invalid lotto node snapshot");
                assertRejected(
                    (snapshot) => (lottoOf(snapshot).selectedChild = undefined),
                    "invalid lotto node snapshot"
                );
            });

            it("has invalid durations for a wait node", () => {
                assertRejected((snapshot) => (waitOf(snapshot).waitedDuration = NaN), "invalid wait node snapshot");
                assertRejected(
                    (snapshot) => (waitOf(snapshot).totalDuration = undefined),
                    "invalid wait node snapshot"
                );
            });
        });
    });
});
