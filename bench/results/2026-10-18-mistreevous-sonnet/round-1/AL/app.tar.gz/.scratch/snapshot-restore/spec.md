# Snapshot and restore of tree execution state

Source: user feature request (long-running workflows, process restarts).

## API
- `BehaviourTree#snapshot(): BehaviourTreeSnapshot`, a plain JSON-safe object `{ version: 1, root: NodeSnapshot }`.
- `BehaviourTree#restore(snapshot)`, for a tree built from the same definition.
- Types `BehaviourTreeSnapshot` and `NodeSnapshot` exported from the package.

## Node state kept
- Every node: type and state (this covers which composite children are done or running).
- `lotto`: index of the selected child.
- `repeat`, `retry`: current count and target count.
- `wait`: total duration and waited duration.
- `action`: a settled promise result not yet consumed by a step.

## Decisions
- Wait timing: the snapshot stores waited time. Restore re-bases the clock start, so time between snapshot and restore does not count. `getDeltaTime` mode keeps the stored waited time.
- `snapshot()` saves an action whose promise is unsettled as `READY` (not yet started), so the restored tree calls its action function again on the next step, entry callback included. It does not throw.
- The snapshot holds `definition`, a hash of the normalised JSON definition (sorted keys and root nodes, default `args` and `succeedOnAbort` dropped), so an MDSL definition and its equivalent JSON definition match. `restore()` throws an `Error` saying that the snapshot does not match the tree's definition on a mismatch, and an `Error` for input that is not a snapshot.
- `restore()` validates the whole snapshot before it changes the tree, and throws on a mismatch.
- `restore()` calls no agent functions and makes no random draws. `restore()` does not call `onNodeStateChange`; the next `step()` reports changes as usual.
- A finished tree restores as finished. The next `step()` resets and redraws random choices.
