/**
 * Create a randomly generated node uid.
 * @returns A randomly generated node uid.
 */
export function createUid(): string {
    const S4 = function () {
        return (((1 + Math.random()) * 0x10000) | 0).toString(16).substring(1);
    };
    return S4() + S4() + "-" + S4() + "-" + S4() + "-" + S4() + "-" + S4() + S4() + S4();
}

/**
 * Gets whether a value is a non-negative integer.
 * @param value The value to check.
 * @returns Whether the value is a non-negative integer.
 */
export function isCount(value: unknown): value is number {
    return Number.isInteger(value) && (value as number) >= 0;
}

/**
 * Gets whether a value is a finite non-negative number.
 * @param value The value to check.
 * @returns Whether the value is a finite non-negative number.
 */
export function isDuration(value: unknown): value is number {
    return typeof value === "number" && Number.isFinite(value) && value >= 0;
}
