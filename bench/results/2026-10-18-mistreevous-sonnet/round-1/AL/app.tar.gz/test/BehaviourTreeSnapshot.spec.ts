import { assert } from "chai";
import sinon, { SinonFakeTimers } from "sinon";

import {
    BehaviourTree,
    BehaviourTreeOptions,
    BehaviourTreeSnapshot,
    NodeDetails,
    State,
    convertMDSLToJSON
} from "../src/index";
import { Agent } from "../src/Agent";

/**
 * The step index shared by the agents of a test, which drives their action results.
 */
type Env = { i: number };

/**
 * Create an agent that logs every function call it receives.
 */
const createAgent = (log: string[], env: Env): Agent => ({
    // Running until the step index reaches 'until', then succeeded.
    work: (until: number) => {
        log.push(`work ${until}@${env.i}`);
        return env.i >= until ? State.SUCCEEDED : State.RUNNING;
    },
    tick: () => {
        log.push(`tick@${env.i}`);
        return State.SUCCEEDED;
    },
    fails: () => {
        log.push(`fails@${env.i}`);
        return State.FAILED;
    },
    isTrue: () => {
        log.push(`isTrue@${env.i}`);
        return true;
    },
    isNotStopped: () => {
        log.push(`isNotStopped@${env.i}`);
        return env.i < 6;
    },
    onEntry: () => log.push(`entry@${env.i}`),
    onExit: () => log.push(`exit@${env.i}`)
});

const withoutIds = (details: NodeDetails): any => {
    const { id, ...rest } = details;
    return { ...rest, children: details.children?.map(withoutIds) };
};

const roundTrip = (snapshot: BehaviourTreeSnapshot): BehaviourTreeSnapshot => JSON.parse(JSON.stringify(snapshot));

type TwinConfig = {
    definition: string;
    /** Steps taken by the original tree before the snapshot. */
    pre: number;
    /** Maximum steps taken by both trees after the restore, ending early when the original finishes. */
    post: number;
    optionsOriginal?: BehaviourTreeOptions;
    /** Options of the restored tree, chosen so that any new random draw would differ from the original. */
    optionsRestored?: BehaviourTreeOptions;
};

/**
 * Step a tree, snapshot it, restore the snapshot into a second tree and check that both trees then
 * show the same node states and call the same agent functions in the same order.
 */
function assertRestoredTreeMatchesOriginal({ definition, pre, post, optionsOriginal, optionsRestored }: TwinConfig) {
    const env: Env = { i: 0 };
    const originalLog: string[] = [];
    const restoredLog: string[] = [];
    const original = new BehaviourTree(definition, createAgent(originalLog, env), optionsOriginal);
    const restored = new BehaviourTree(definition, createAgent(restoredLog, env), optionsRestored);

    for (; env.i < pre; env.i++) {
        original.step();
    }

    restored.restore(roundTrip(original.snapshot()));
    originalLog.length = 0;

    assert.deepEqual(withoutIds(restored.getTreeNodeDetails()), withoutIds(original.getTreeNodeDetails()));

    for (
        let n = 0;
        n < post && !(original.getState() === State.SUCCEEDED || original.getState() === State.FAILED);
        n++
    ) {
        original.step();
        restored.step();
        env.i++;

        assert.deepEqual(restoredLog, originalLog);
        assert.deepEqual(withoutIds(restored.getTreeNodeDetails()), withoutIds(original.getTreeNodeDetails()));
    }
}

describe("A BehaviourTree instance", () => {
    describe("has a 'snapshot' function that", () => {
        it("returns a plain object that is unchanged by a JSON round trip", () => {
            const definition = `root {
                sequence {
                    lotto { action [work, 9] action [work, 9] }
                    repeat [2, 3] { retry [2, 3] { action [work, 9] } }
                    wait [100, 200]
                    parallel { race { action [work, 9] } all { action [work, 9] } }
                    flip { selector { condition [isTrue] succeed { fail { action [work, 9] } } } }
                }
            }`;
            const tree = new BehaviourTree(definition, createAgent([], { i: 0 }));
            tree.step();

            const snapshot = tree.snapshot();

            assert.deepEqual(JSON.parse(JSON.stringify(snapshot)), snapshot);
        });

        it("returns a snapshot with a version and a root node snapshot that mirrors the tree", () => {
            const tree = new BehaviourTree(
                "root { sequence { action [work, 9] condition [isTrue] } }",
                createAgent([], { i: 0 })
            );
            tree.step();

            const { version, root } = tree.snapshot();

            assert.strictEqual(version, 1);
            assert.strictEqual(root.type, "root");
            assert.strictEqual(root.state, State.RUNNING);
            assert.deepEqual(
                root.children![0].children!.map(({ type, state }) => [type, state]),
                [
                    ["action", State.RUNNING],
                    ["condition", State.READY]
                ]
            );
        });

        it("does not change the tree", () => {
            const tree = new BehaviourTree(
                "root { sequence { action [work, 9] wait [100] } }",
                createAgent([], { i: 0 })
            );
            tree.step();
            const before = tree.getTreeNodeDetails();

            tree.snapshot();

            assert.deepEqual(tree.getTreeNodeDetails(), before);
        });

        it("records the definition of the tree, the same for an MDSL definition and its equivalent JSON definition", () => {
            const agent = createAgent([], { i: 0 });
            const mdsl = new BehaviourTree(
                "root { sequence while(isTrue) { action [work, 3] /* comment */ wait [10] } }",
                agent
            );
            const json = new BehaviourTree(
                [
                    {
                        type: "root",
                        child: {
                            children: [
                                { type: "action", call: "work", args: [3] },
                                { duration: 10, type: "wait" }
                            ],
                            type: "sequence",
                            while: { call: "isTrue" }
                        }
                    }
                ] as any,
                agent
            );
            const other = new BehaviourTree("root { sequence while(isTrue) { action [work, 4] wait [10] } }", agent);

            assert.isString(mdsl.snapshot().definition);
            assert.strictEqual(json.snapshot().definition, mdsl.snapshot().definition);
            assert.notStrictEqual(other.snapshot().definition, mdsl.snapshot().definition);
        });

        it("records the same definition whatever the order of the root nodes", () => {
            const agent = createAgent([], { i: 0 });
            const main = { type: "root", child: { type: "sequence", children: [{ type: "branch", ref: "a" }] } };
            const a = { type: "root", id: "a", child: { type: "action", call: "tick" } };
            const b = { type: "root", id: "b", child: { type: "action", call: "work", args: [1] } };

            const first = new BehaviourTree([main, a, b] as any, agent);
            const second = new BehaviourTree([b, main, a] as any, agent);

            assert.strictEqual(second.snapshot().definition, first.snapshot().definition);
        });

        describe("with an action whose promise has not settled", () => {
            const pendingAgent = () => ({
                slow: () => new Promise<State.SUCCEEDED>(() => {}),
                tick: () => State.SUCCEEDED
            });

            it("does not throw and saves the action as not yet started", () => {
                const tree = new BehaviourTree("root { sequence { action [tick] action [slow] } }", pendingAgent());
                tree.step();

                const { root } = tree.snapshot();

                assert.strictEqual(root.state, State.RUNNING);
                assert.deepEqual(
                    root.children![0].children!.map(({ state }) => state),
                    [State.SUCCEEDED, State.READY]
                );
                assert.deepEqual(JSON.parse(JSON.stringify(root)), root);
            });

            it("leaves the tree running its action", () => {
                const tree = new BehaviourTree("root { action [slow] }", pendingAgent());
                tree.step();

                tree.snapshot();

                assert.strictEqual(tree.getState(), State.RUNNING);
                assert.strictEqual(tree.getTreeNodeDetails().children![0].state, State.RUNNING);
            });
        });
    });

    describe("has a 'restore' function that makes a tree built from the same definition", () => {
        it("show the node states of the snapshotted tree", () => {
            assertRestoredTreeMatchesOriginal({
                definition: "root { sequence { action [tick] action [work, 5] action [work, 9] } }",
                pre: 3,
                post: 0
            });
        });

        describe("behave like the snapshotted tree, with the same node states and agent function calls, for a", () => {
            const cases: [string, string][] = [
                ["sequence", "root { sequence { action [tick] action [work, 3] action [work, 5] } }"],
                ["selector", "root { selector { action [fails] action [work, 3] action [work, 5] } }"],
                ["parallel", "root { parallel { action [work, 2] action [work, 4] action [tick] } }"],
                ["race", "root { race { action [work, 4] action [work, 2] } }"],
                ["all", "root { all { action [work, 2] action [fails] action [work, 4] } }"],
                [
                    "flip, succeed and fail",
                    "root { sequence { flip { action [work, 2] } fail { action [work, 3] } succeed { action [work, 4] } } }"
                ],
                [
                    "branch to a subtree",
                    "root { sequence { branch [Sub] action [work, 3] } } root [Sub] { repeat [2] { action [tick] } }"
                ],
                [
                    "nested composite",
                    "root { sequence { action [tick] parallel { action [work, 3] selector { action [fails] action [work, 4] } } action [work, 6] } }"
                ],
                ["repeat with a fixed count", "root { repeat [4] { sequence { action [tick] action [work, 0] } } }"],
                ["retry with a fixed count", "root { retry [4] { action [fails] } }"],
                ["node with a 'while' guard", "root { sequence { action [work, 9] while(isNotStopped) } }"],
                ["node with entry and exit callbacks", "root { action [work, 3] entry(onEntry) exit(onExit) }"]
            ];

            cases.forEach(([name, definition]) => {
                it(name, () => {
                    for (let pre = 0; pre <= 5; pre++) {
                        assertRestoredTreeMatchesOriginal({ definition, pre, post: 8 });
                    }
                });
            });
        });

        describe("keep random choices that were already made for a", () => {
            // The original tree draws 0.9 and the restored tree would draw 0, so a new draw shows as a difference.
            const optionsOriginal = { random: () => 0.9 };
            const optionsRestored = { random: () => 0 };

            const cases: [string, string, BehaviourTreeOptions?][] = [
                ["repeat with a minimum and maximum count", "root { repeat [2, 4] { action [tick] } }"],
                ["retry with a minimum and maximum count", "root { retry [2, 4] { action [fails] } }"],
                ["lotto", "root { lotto { action [work, 7] action [work, 8] action [work, 9] } }"],
                ["lotto with weights", "root { lotto [1, 1, 8] { action [tick] action [tick] action [work, 6] } }"],
                ["wait with a minimum and maximum duration", "root { wait [1000, 2000] }", { getDeltaTime: () => 0.5 }]
            ];

            cases.forEach(([name, definition, extraOptions]) => {
                it(name, () => {
                    for (let pre = 1; pre <= 3; pre++) {
                        assertRestoredTreeMatchesOriginal({
                            definition,
                            pre,
                            post: 10,
                            optionsOriginal: { ...optionsOriginal, ...extraOptions },
                            optionsRestored: { ...optionsRestored, ...extraOptions }
                        });
                    }
                });
            });
        });

        it("not call the random function", () => {
            const definition =
                "root { sequence { lotto { action [tick] action [tick] } repeat [1, 3] { action [tick] } } }";
            const tree = new BehaviourTree(definition, createAgent([], { i: 0 }));
            tree.step();
            const random = sinon.stub().returns(0);
            const restored = new BehaviourTree(definition, createAgent([], { i: 0 }), { random });

            restored.restore(tree.snapshot());

            assert.isFalse(random.called);
        });

        it("not call any agent function", () => {
            const log: string[] = [];
            const definition = "root { action [work, 9] entry(onEntry) exit(onExit) }";
            const tree = new BehaviourTree(definition, createAgent([], { i: 0 }));
            tree.step();
            const restored = new BehaviourTree(definition, createAgent(log, { i: 0 }));

            restored.restore(tree.snapshot());

            assert.deepEqual(log, []);
        });

        describe("wait only for the remaining time of a wait node", () => {
            let clock: SinonFakeTimers;

            beforeEach(() => {
                clock = sinon.useFakeTimers();
            });

            afterEach(() => {
                clock.restore();
            });

            it("when using the clock, ignoring time that passed before the restore", () => {
                const definition = "root { wait [1000] }";
                const tree = new BehaviourTree(definition, {});
                tree.step();
                clock.tick(300);
                const snapshot = roundTrip(tree.snapshot());

                clock.tick(60 * 60 * 1000);
                const restored = new BehaviourTree(definition, {});
                restored.restore(snapshot);

                restored.step();
                assert.strictEqual(restored.getState(), State.RUNNING);
                clock.tick(699);
                restored.step();
                assert.strictEqual(restored.getState(), State.RUNNING);
                clock.tick(1);
                restored.step();
                assert.strictEqual(restored.getState(), State.SUCCEEDED);
            });

            it("when using the clock, counting time that passed between the last step and the snapshot", () => {
                const definition = "root { wait [1000] }";
                const tree = new BehaviourTree(definition, {});
                tree.step();
                clock.tick(900);
                const snapshot = tree.snapshot();

                const restored = new BehaviourTree(definition, {});
                restored.restore(snapshot);
                clock.tick(99);
                restored.step();
                assert.strictEqual(restored.getState(), State.RUNNING);
                clock.tick(1);
                restored.step();
                assert.strictEqual(restored.getState(), State.SUCCEEDED);
            });

            it("when using the 'getDeltaTime' option", () => {
                const definition = "root { wait [1000] }";
                const options = { getDeltaTime: () => 0.25 };
                const tree = new BehaviourTree(definition, {}, options);
                tree.step();
                tree.step();
                const snapshot = roundTrip(tree.snapshot());

                clock.tick(60 * 60 * 1000);
                const restored = new BehaviourTree(definition, {}, options);
                restored.restore(snapshot);

                restored.step();
                assert.strictEqual(restored.getState(), State.RUNNING);
                restored.step();
                assert.strictEqual(restored.getState(), State.SUCCEEDED);
            });

            it("without ever succeeding when the wait has no duration", () => {
                const tree = new BehaviourTree("root { wait }", {});
                tree.step();
                clock.tick(1000);
                const restored = new BehaviourTree("root { wait }", {});
                restored.restore(tree.snapshot());

                clock.tick(1000);
                restored.step();

                assert.strictEqual(restored.getState(), State.RUNNING);
            });
        });

        describe("with an action that returns a promise", () => {
            it("keep the resolved result of a settled promise without calling the action again", async () => {
                const calls: string[] = [];
                const agent = {
                    slow: () => {
                        calls.push("slow");
                        return Promise.resolve(State.SUCCEEDED);
                    }
                };
                const tree = new BehaviourTree("root { action [slow] }", agent);
                tree.step();
                await Promise.resolve();

                const restored = new BehaviourTree("root { action [slow] }", agent);
                restored.restore(roundTrip(tree.snapshot()));
                calls.length = 0;
                restored.step();

                assert.strictEqual(restored.getState(), State.SUCCEEDED);
                assert.deepEqual(calls, []);
            });

            it("keep the rejection of a settled promise", async () => {
                const agent = { slow: () => Promise.reject(new Error("boom")) };
                const tree = new BehaviourTree("root { action [slow] }", agent);
                tree.step();
                await new Promise((resolve) => setTimeout(resolve, 0));

                const restored = new BehaviourTree("root { action [slow] }", agent);
                restored.restore(roundTrip(tree.snapshot()));

                assert.throws(
                    () => restored.step(),
                    Error,
                    "action function 'slow' promise rejected with 'Error: boom'"
                );
            });
        });

        describe("with an action whose promise had not settled", () => {
            const pendingAgent = (calls: string[]) => ({
                slow: () => {
                    calls.push("slow");
                    return new Promise<State.SUCCEEDED>(() => {});
                },
                tick: () => State.SUCCEEDED
            });

            [
                ["root", "root { action [slow] }"],
                ["sequence", "root { sequence { action [tick] action [slow] } }"],
                ["parallel", "root { parallel { action [tick] action [slow] } }"],
                ["race", "root { race { action [slow] action [slow] } }"],
                ["lotto", "root { lotto { action [slow] } }"],
                ["repeat", "root { repeat [2] { action [slow] } }"]
            ].forEach(([name, definition]) => {
                it(`call the action function again on the next step, under a ${name}`, () => {
                    const calls: string[] = [];
                    const tree = new BehaviourTree(definition, pendingAgent(calls));
                    tree.step();

                    const restored = new BehaviourTree(definition, pendingAgent(calls));
                    restored.restore(roundTrip(tree.snapshot()));
                    calls.length = 0;
                    restored.step();

                    assert.strictEqual(calls[0], "slow");
                    assert.strictEqual(restored.getState(), State.RUNNING);
                });
            });

            it("call the action function once, not again while the new promise is pending", () => {
                const calls: string[] = [];
                const tree = new BehaviourTree("root { action [slow] }", pendingAgent(calls));
                tree.step();
                const restored = new BehaviourTree("root { action [slow] }", pendingAgent(calls));
                restored.restore(tree.snapshot());
                calls.length = 0;

                restored.step();
                restored.step();

                assert.deepEqual(calls, ["slow"]);
            });

            it("ignore the result of a promise that was pending in the tree before the restore", async () => {
                let resolve!: (state: State.SUCCEEDED) => void;
                const calls: string[] = [];
                const agent = {
                    slow: () => {
                        calls.push("slow");
                        return new Promise<State.SUCCEEDED>((r) => (resolve = r));
                    }
                };
                const source = new BehaviourTree("root { action [slow] }", agent);
                source.step();
                const tree = new BehaviourTree("root { action [slow] }", agent);
                tree.step();
                const staleResolve = resolve;

                tree.restore(source.snapshot());
                staleResolve(State.SUCCEEDED);
                await Promise.resolve();
                calls.length = 0;
                tree.step();

                assert.deepEqual(calls, ["slow"]);
                assert.strictEqual(tree.getState(), State.RUNNING);
            });

            it("ignore the result of a promise that was pending before the restore and settles after the action was called again", async () => {
                const resolvers: ((state: State.SUCCEEDED) => void)[] = [];
                const agent = {
                    slow: () => new Promise<State.SUCCEEDED>((resolve) => resolvers.push(resolve))
                };
                const source = new BehaviourTree("root { action [slow] }", agent);
                source.step();
                const tree = new BehaviourTree("root { action [slow] }", agent);
                tree.step();

                tree.restore(source.snapshot());
                tree.step();
                resolvers[1](State.SUCCEEDED); // the promise of the tree before the restore
                await Promise.resolve();
                tree.step();

                assert.strictEqual(tree.getState(), State.RUNNING);
            });
        });

        describe("restore a snapshot of a finished tree as finished and", () => {
            it("start a new run, making new random choices, on the next step", () => {
                const definition = "root { repeat [1, 3] { action [tick] } }";
                const tree = new BehaviourTree(definition, createAgent([], { i: 0 }), { random: () => 0.9 });
                while (tree.getState() !== State.SUCCEEDED) {
                    tree.step();
                }

                const random = sinon.stub().returns(0);
                const log: string[] = [];
                const restored = new BehaviourTree(definition, createAgent(log, { i: 0 }), { random });
                restored.restore(roundTrip(tree.snapshot()));

                assert.strictEqual(restored.getState(), State.SUCCEEDED);
                assert.deepEqual(withoutIds(restored.getTreeNodeDetails()), withoutIds(tree.getTreeNodeDetails()));
                assert.isFalse(random.called);

                // A random draw of 0 gives one iteration, where the original run had three.
                restored.step();
                restored.step();
                assert.isTrue(random.calledOnce);
                assert.strictEqual(restored.getState(), State.SUCCEEDED);
                assert.deepEqual(log, ["tick@0"]);
            });
        });

        it("replace the state of a tree that has already run", () => {
            const definition = "root { sequence { action [tick] action [work, 99] } }";
            const fresh = new BehaviourTree(definition, createAgent([], { i: 0 }));
            const advanced = new BehaviourTree(definition, createAgent([], { i: 0 }));
            advanced.step();

            advanced.restore(fresh.snapshot());

            assert.deepEqual(withoutIds(advanced.getTreeNodeDetails()), withoutIds(fresh.getTreeNodeDetails()));
        });

        it("not call the 'onNodeStateChange' option, while the next step does for its changes", () => {
            const definition = "root { sequence { action [tick] action [work, 1] } }";
            const env: Env = { i: 0 };
            const tree = new BehaviourTree(definition, createAgent([], env));
            tree.step();
            const changes: [string, State, State][] = [];
            const restored = new BehaviourTree(definition, createAgent([], env), {
                onNodeStateChange: ({ type, previousState, state }) => changes.push([type, previousState, state])
            });

            restored.restore(tree.snapshot());

            assert.deepEqual(changes, []);

            env.i = 1;
            restored.step();

            assert.deepEqual(changes, [
                ["action", State.RUNNING, State.SUCCEEDED],
                ["sequence", State.RUNNING, State.SUCCEEDED],
                ["root", State.RUNNING, State.SUCCEEDED]
            ]);
        });

        describe("keep a snapshot independent of the trees, for a tree with", () => {
            const cases: [string, string][] = [
                [
                    "wait, lotto, repeat and retry nodes",
                    "root { sequence { wait [20, 40] lotto { action [work, 3] action [work, 5] } repeat [2, 4] { action [work, 4] } retry [3] { action [fails] } wait [50] } }"
                ],
                [
                    "a flip, a fail, a succeed and a parallel node",
                    "root { sequence { flip { action [work, 2] } fail { action [work, 3] } succeed { action [work, 4] } parallel { action [work, 6] action [tick] } } }"
                ]
            ];
            let clock: SinonFakeTimers;

            beforeEach(() => {
                clock = sinon.useFakeTimers();
            });

            afterEach(() => {
                clock.restore();
            });

            cases.forEach(([name, definition]) => {
                it(name, () => {
                    for (let pre = 0; pre <= 8; pre++) {
                        const env: Env = { i: 0 };
                        const tree = new BehaviourTree(definition, createAgent([], env), { random: () => 0.5 });
                        const restored = new BehaviourTree(definition, createAgent([], env), { random: () => 0.1 });

                        for (; env.i < pre; env.i++) {
                            tree.step();
                            clock.tick(7);
                        }

                        const snapshot = tree.snapshot();
                        const serialised = JSON.stringify(snapshot);

                        restored.restore(snapshot);
                        assert.deepEqual(
                            roundTrip(restored.snapshot()),
                            JSON.parse(serialised),
                            `restored, pre ${pre}`
                        );

                        for (let n = 0; n < 12; n++) {
                            tree.step();
                            restored.step();
                            env.i++;
                            clock.tick(7);
                            assert.strictEqual(JSON.stringify(snapshot), serialised, `pre ${pre}, step ${n}`);
                        }
                    }
                });
            });
        });

        it("keep a snapshot independent of the trees, for an action with a settled promise", async () => {
            const definition = "root { action [work] }";
            const agent = { work: () => Promise.resolve(State.SUCCEEDED) };
            const tree = new BehaviourTree(definition, agent);
            const restored = new BehaviourTree(definition, agent);
            tree.step();
            await Promise.resolve();

            const snapshot = tree.snapshot();
            const serialised = JSON.stringify(snapshot);

            restored.restore(snapshot);
            assert.deepEqual(roundTrip(restored.snapshot()), JSON.parse(serialised));

            tree.step();
            restored.step();
            assert.strictEqual(JSON.stringify(snapshot), serialised);
        });

        describe("throw, leaving the tree unchanged, when the snapshot", () => {
            const definition =
                "root { sequence { lotto { action [tick] action [tick] } repeat [3] { action [tick] } wait [10] action [work, 9] } }";
            let tree: BehaviourTree;
            let valid: any;

            beforeEach(() => {
                tree = new BehaviourTree(definition, createAgent([], { i: 0 }));
                const source = new BehaviourTree(definition, createAgent([], { i: 0 }));
                for (let i = 0; i < 4; i++) source.step();
                valid = roundTrip(source.snapshot());
            });

            const nodeAt = (snapshot: any, ...path: number[]) =>
                path.reduce((node, index) => node.children[index], snapshot.root);

            // Each case corrupts a valid snapshot taken while the lotto, repeat and wait nodes are past the ready state.
            const cases: [string, (snapshot: any) => any, string][] = [
                ["is not an object", () => null, "invalid snapshot"],
                ["has an unsupported version", (s) => ({ ...s, version: 2 }), "unsupported snapshot version"],
                [
                    "has a node of the wrong type",
                    (s) => ((nodeAt(s, 0).type = "selector"), s),
                    "snapshot node type 'selector' does not match tree node type 'sequence'"
                ],
                [
                    "has a node with the wrong number of children",
                    (s) => (nodeAt(s, 0).children.pop(), s),
                    "snapshot node 'sequence' has 3 children but the tree node has 4"
                ],
                [
                    "has a node with an invalid state",
                    (s) => ((nodeAt(s, 0, 3).state = "nope"), s),
                    "invalid snapshot node state"
                ],
                [
                    "has a lotto node with a selected child out of range",
                    (s) => ((nodeAt(s, 0, 0).selectedChild = 5), s),
                    "invalid snapshot lotto selected child"
                ],
                [
                    "has a lotto node past the ready state without a selected child",
                    (s) => ((nodeAt(s, 0, 0).selectedChild = null), s),
                    "invalid snapshot lotto selected child"
                ],
                [
                    "has a repeat node with a negative count",
                    (s) => ((nodeAt(s, 0, 1).currentCount = -1), s),
                    "invalid snapshot repeat counts"
                ],
                [
                    "has a repeat node with a target that is not an integer",
                    (s) => ((nodeAt(s, 0, 1).targetCount = 1.5), s),
                    "invalid snapshot repeat counts"
                ],
                [
                    "has a wait node with a duration that is not a number",
                    (s) => ((nodeAt(s, 0, 2).waitedDuration = "1"), s),
                    "invalid snapshot wait durations"
                ]
            ];

            cases.forEach(([name, corrupt, message]) => {
                it(name, () => {
                    const snapshot = corrupt(roundTrip(valid));
                    const before = withoutIds(tree.getTreeNodeDetails());

                    assert.throws(() => tree.restore(snapshot), Error, message);
                    assert.deepEqual(withoutIds(tree.getTreeNodeDetails()), before);
                });
            });

            [
                ["undefined", undefined],
                ["null", null],
                ["a string", "snapshot"],
                ["a number", 1],
                ["an array", []],
                ["an array holding a snapshot", [{ version: 1 }]],
                ["an empty object", {}],
                ["an object with only a version", { version: 1 }],
                ["an object with no root", { version: 1, definition: "abc" }],
                ["an object with no definition", { version: 1, root: { type: "root", state: State.READY } }]
            ].forEach(([name, input]) => {
                it(`is ${name} rather than a snapshot`, () => {
                    const before = withoutIds(tree.getTreeNodeDetails());

                    assert.throws(() => tree.restore(input as any), Error);
                    assert.deepEqual(withoutIds(tree.getTreeNodeDetails()), before);
                });
            });

            [
                ["has a different node structure", "root { sequence { action [tick] } }"],
                ["has a different action argument", definition.replace("work, 9", "work, 8")],
                ["has a different wait duration", definition.replace("wait [10]", "wait [11]")],
                ["has a different repeat count", definition.replace("repeat [3]", "repeat [4]")],
                ["has a different guard", definition.replace("action [work, 9]", "action [work, 9] while(isTrue)")],
                ["has a different action name", definition.replace("work, 9", "tick")]
            ].forEach(([name, otherDefinition]) => {
                it(`was taken from a tree that ${name}`, () => {
                    const source = new BehaviourTree(otherDefinition, createAgent([], { i: 0 }));
                    for (let i = 0; i < 4; i++) source.step();
                    const before = withoutIds(tree.getTreeNodeDetails());

                    assert.throws(
                        () => tree.restore(roundTrip(source.snapshot())),
                        Error,
                        "snapshot does not match the tree's definition"
                    );
                    assert.deepEqual(withoutIds(tree.getTreeNodeDetails()), before);
                });
            });

            it("holds the definition of another tree that has the same node structure", () => {
                const other = new BehaviourTree(
                    definition.replace("wait [10]", "wait [11]"),
                    createAgent([], { i: 0 })
                );
                const wrong = { ...valid, definition: other.snapshot().definition };

                assert.throws(() => tree.restore(wrong), Error, "snapshot does not match the tree's definition");
            });

            it("was taken from a tree built from the equivalent JSON definition is accepted", () => {
                const source = new BehaviourTree(convertMDSLToJSON(definition), createAgent([], { i: 0 }));
                for (let i = 0; i < 4; i++) source.step();

                assert.doesNotThrow(() => tree.restore(roundTrip(source.snapshot())));
            });

            it("is accepted when valid", () => {
                assert.doesNotThrow(() => tree.restore(valid));
            });
        });
    });
});
