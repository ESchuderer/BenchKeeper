# Tree snapshot and restore

Tier: full (new capability). Source: user feature request (long-running workflows, process restarts).

## Goal
`BehaviourTree.snapshot()` returns the execution state as a JSON-safe object. `restore(snapshot)` puts a tree built from the same definition into that state. The restored tree then behaves as the original would have.

## Format
`BehaviourTreeSnapshot = { version: 1, definition: string, root: NodeSnapshot }`. `definition` is a fingerprint (53 bit hash) of the definition as JSON, with keys sorted, root nodes sorted by id and the defaults `args: []` and `succeedOnAbort: false` removed, so an MDSL definition and its equivalent JSON definition have the same fingerprint.
`NodeSnapshot = { type, name, state, children?, ...per-type fields }`, mirroring the tree shape.

| Node | Extra fields |
|---|---|
| lotto | `selectedChild` (index or null) |
| repeat | `targetIterationCount` (number or null), `currentIterationCount` |
| retry | `targetAttemptCount` (number or null), `currentAttemptCount` |
| wait | `totalDuration` (number or null), `waitedDuration` (ms, includes time elapsed up to the snapshot in clock mode) |
| action | `promise`: null, or `{ isResolved, value }` for a settled update promise. A pending promise is saved as `state: READY`, `promise: null` |
| others | none (state derives from node states) |

## Decisions
- A stale promise that settles after a restore or reset is ignored (identity check in `Action`).
- Node ids are not part of the snapshot (random per build, not execution state).
- A restored wait sets its start time to `now - waitedDuration`, so time between snapshot and restore does not count. In `getDeltaTime` mode `snapshot()` does not call `getDeltaTime`.
- An action that awaits a still-pending promise is saved as not yet started (READY, no promise): a promise cannot be serialised. After a restore its `entry` callback and action function are called again on the next step.
- Settled promise: resolved value kept if a State, rejection reason kept as its string form (the error message uses the string form).
- `restore()` validates the whole snapshot (shape, version, definition fingerprint, node types and names, child counts, states, numbers) before changing the tree; an invalid snapshot throws and leaves the tree untouched.
- `restore()` sets node states directly and does not call `onNodeStateChange`: the transitions already happened before the snapshot, so an app that notifies on them would repeat side effects on every restart.
- Finished tree: root is SUCCEEDED/FAILED, so the next `step()` resets and draws new random values.

## Acceptance
Failing test first for each: JSON round trip, each node type, wait with Date and getDeltaTime, finished tree, validation errors, equivalence of restored vs original over further steps. README section and example, Version History row, version 4.4.0, `npm test` passes.
