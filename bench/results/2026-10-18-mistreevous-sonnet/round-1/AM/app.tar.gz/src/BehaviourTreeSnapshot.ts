import { AnyState } from "./State";

/**
 * The saved execution state of a single node, and of the nodes below it.
 * Only the fields that apply to the node type are present.
 */
export type NodeSnapshot = {
    /**
     * The node type.
     */
    type: string;
    /**
     * The node name, as shown in the node details.
     */
    name: string;
    /**
     * The node state.
     */
    state: AnyState;
    /**
     * The snapshots of the child nodes, present for composite and decorator nodes.
     */
    children?: NodeSnapshot[];
    /**
     * The index of the child picked by a lotto node, or null if none has been picked.
     */
    selectedChild?: number | null;
    /**
     * The number of iterations a repeat node will make, or null if it repeats indefinitely.
     */
    targetIterationCount?: number | null;
    /**
     * The number of iterations a repeat node has made.
     */
    currentIterationCount?: number;
    /**
     * The number of attempts a retry node will make, or null if it retries indefinitely.
     */
    targetAttemptCount?: number | null;
    /**
     * The number of attempts a retry node has made.
     */
    currentAttemptCount?: number;
    /**
     * The duration in milliseconds a wait node waits for, or null if it waits indefinitely.
     */
    totalDuration?: number | null;
    /**
     * The duration in milliseconds a wait node has waited for.
     */
    waitedDuration?: number;
    /**
     * The settled update promise of an action node, or null if there is none.
     * The value is the string form of the resolved value or rejection reason.
     */
    promise?: { isResolved: boolean; value: string } | null;
};

/**
 * The saved execution state of a behaviour tree, which survives JSON serialisation.
 */
export type BehaviourTreeSnapshot = {
    /**
     * The snapshot format version.
     */
    version: 1;
    /**
     * The fingerprint of the definition of the tree that the snapshot was taken from.
     */
    definition: string;
    /**
     * The snapshot of the root node.
     */
    root: NodeSnapshot;
};
