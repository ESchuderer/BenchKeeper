import { assert } from "chai";
import sinon, { SinonFakeTimers } from "sinon";

import { BehaviourTree, BehaviourTreeSnapshot, BehaviourTreeOptions, NodeDetails, State } from "../src/index";
import { Agent } from "../src/Agent";

type World = { t: number; log: string[]; random: Random };
type Random = (() => number) & { index: number };

const createRandom = (values: number[]): Random => {
    const random = (() => values[random.index++ % values.length]) as Random;
    random.index = 0;
    return random;
};

const stripIds = (details: NodeDetails): any => ({
    ...details,
    id: undefined,
    children: details.children?.map(stripIds)
});

const roundTrip = (snapshot: BehaviourTreeSnapshot): BehaviourTreeSnapshot => JSON.parse(JSON.stringify(snapshot));

/**
 * Steps a tree to 'snapshotAt' steps, takes a JSON round-tripped snapshot, restores it into a fresh tree (with a fresh agent
 * and world, and a gap in time before the restore) and then checks that both trees behave identically for the remaining steps.
 */
function assertRestoredTreeBehavesAsOriginal(config: {
    definition: string;
    agent: (world: World) => Agent;
    randomValues?: number[];
    restoredRandomValues?: number[];
    options?: (world: World) => BehaviourTreeOptions;
    steps: number;
    snapshotAt: number;
    gap?: number;
}) {
    const clock = sinon.useFakeTimers();

    try {
        const setUp = (randomValues: number[] = [0.5]) => {
            const world: World = { t: 0, log: [], random: createRandom(randomValues) };
            const options = { random: world.random, ...config.options?.(world) };
            return { world, tree: new BehaviourTree(config.definition, config.agent(world), options) };
        };

        const original = setUp(config.randomValues);
        const originalDetails: any[] = [];
        let snapshot: BehaviourTreeSnapshot | undefined;
        let randomIndex = 0;
        const step = (side: ReturnType<typeof setUp>, t: number, offset: number) => {
            side.world.t = t;
            clock.setSystemTime(t * 100 + offset);
            side.tree.step();
        };

        for (let t = 0; t < config.steps; t++) {
            if (t === config.snapshotAt) {
                snapshot = roundTrip(original.tree.snapshot());
                randomIndex = original.world.random.index;
            }
            step(original, t, 0);
            originalDetails.push(stripIds(original.tree.getTreeNodeDetails()));
        }

        const gap = config.gap ?? 1000000;
        const restored = setUp(config.restoredRandomValues ?? config.randomValues);
        restored.world.random.index = config.restoredRandomValues ? 0 : randomIndex;
        clock.setSystemTime(Math.max(config.snapshotAt - 1, 0) * 100 + gap);
        restored.tree.restore(snapshot!);

        assert.strictEqual(restored.world.random.index, config.restoredRandomValues ? 0 : randomIndex);
        assert.deepEqual(
            stripIds(restored.tree.getTreeNodeDetails()),
            config.snapshotAt === 0
                ? stripIds(new BehaviourTree(config.definition, config.agent(restored.world)).getTreeNodeDetails())
                : originalDetails[config.snapshotAt - 1]
        );

        for (let t = config.snapshotAt; t < config.steps; t++) {
            step(restored, t, gap);
            assert.deepEqual(stripIds(restored.tree.getTreeNodeDetails()), originalDetails[t], `details at step ${t}`);
        }

        const sinceSnapshot = original.world.log.filter((entry) => Number(entry.split(":")[0]) >= config.snapshotAt);
        assert.deepEqual(restored.world.log, sinceSnapshot);
        assert.isAbove(restored.world.log.length, 0);
    } finally {
        clock.restore();
    }
}

/** An agent whose functions are pure functions of the world time and which log each call. */
const agentWith = (functions: Record<string, (t: number) => any>) => (world: World) =>
    Object.fromEntries(
        Object.entries(functions).map(([name, fn]) => [
            name,
            (...args: any[]) => {
                world.log.push(`${world.t}:${name}${args.length ? `(${args.join(",")})` : ""}`);
                return fn(world.t);
            }
        ])
    ) as Agent;

describe("A BehaviourTree snapshot", () => {
    describe("can be taken as a plain object that survives JSON serialisation", () => {
        it("for a tree that has not been stepped", () => {
            const tree = new BehaviourTree("root { action [a] }", { a: () => State.RUNNING });
            const snapshot = tree.snapshot();
            assert.deepEqual(roundTrip(snapshot), snapshot);
        });

        it("for a tree containing every node type, mid-run", () => {
            const definition = `root {
                sequence {
                    parallel { action [a] wait [100000] }
                    race { action [a] action [a] }
                    all { action [a] condition [c] }
                    selector { condition [f] lotto [1,2] { action [a] action [a] } }
                    repeat [3] { retry [2] { flip { fail { succeed { action [done] } } } } }
                    repeat [2,4] { retry [2,4] { wait [10, 20] } }
                    action [b, 1, "x"]
                    wait
                }
            }`;
            const agent = {
                a: () => State.RUNNING,
                b: () => new Promise<State>(() => undefined),
                done: () => State.SUCCEEDED,
                c: () => true,
                f: () => false
            };
            const tree = new BehaviourTree(definition, { ...agent, b: () => State.SUCCEEDED }, { random: () => 0.7 });
            tree.step();
            tree.step();
            const snapshot = tree.snapshot();
            assert.deepEqual(roundTrip(snapshot), snapshot);
            assert.strictEqual(snapshot.root.type, "root");
        });

        it("which does not share references with the tree", () => {
            const tree = new BehaviourTree("root { repeat [3] { action [a] } }", { a: () => State.SUCCEEDED });
            tree.step();
            const first = tree.snapshot();
            tree.step();
            assert.notDeepEqual(tree.snapshot(), first);
        });
    });

    describe("can be restored", () => {
        it("into a tree built from the same definition, giving the same node states", () => {
            const definition = "root { sequence { action [a] action [b] } }";
            const agent = { a: () => State.SUCCEEDED, b: () => State.RUNNING };
            const original = new BehaviourTree(definition, agent);
            original.step();

            const restored = new BehaviourTree(definition, agent);
            restored.restore(roundTrip(original.snapshot()));

            assert.deepEqual(stripIds(restored.getTreeNodeDetails()), stripIds(original.getTreeNodeDetails()));
            assert.strictEqual(restored.getState(), State.RUNNING);
            assert.isTrue(restored.isRunning());
        });

        it("over a tree that is in a different state", () => {
            const definition = "root { sequence { action [a] action [b] } }";
            const agent = { a: () => State.SUCCEEDED, b: () => State.RUNNING };
            const original = new BehaviourTree(definition, agent);
            original.step();
            const snapshot = original.snapshot();

            const target = new BehaviourTree(definition, agent);
            target.step();
            target.step();
            target.restore(snapshot);
            assert.deepEqual(target.snapshot(), snapshot);
        });

        it("without calling any agent function or the onNodeStateChange callback", () => {
            const definition = "root { sequence { action [a] action [b] } }";
            const a = sinon.stub().returns(State.SUCCEEDED);
            const b = sinon.stub().returns(State.RUNNING);
            const original = new BehaviourTree(definition, { a, b });
            original.step();
            a.resetHistory();
            b.resetHistory();

            const onNodeStateChange = sinon.spy();
            const restored = new BehaviourTree(definition, { a, b }, { onNodeStateChange });
            restored.restore(original.snapshot());

            assert.isFalse(a.called);
            assert.isFalse(b.called);
            assert.isFalse(onNodeStateChange.called);
        });

        it("without calling onNodeStateChange for a tree that was in a different state, and then reports the next step", () => {
            const definition = "root { sequence { action [a] action [b] } }";
            let bResult = State.RUNNING;
            const agent = { a: () => State.SUCCEEDED, b: () => bResult };
            const original = new BehaviourTree(definition, agent);
            original.step();
            const snapshot = roundTrip(original.snapshot());

            const onNodeStateChange = sinon.spy();
            const restored = new BehaviourTree(definition, agent, { onNodeStateChange });
            restored.step();
            restored.step();
            onNodeStateChange.resetHistory();

            restored.restore(snapshot);
            assert.isFalse(onNodeStateChange.called);

            bResult = State.SUCCEEDED;
            restored.step();
            assert.deepEqual(
                onNodeStateChange.args.map(([{ type, previousState, state }]) => [type, previousState, state]),
                [
                    ["action", State.RUNNING, State.SUCCEEDED],
                    ["sequence", State.RUNNING, State.SUCCEEDED],
                    ["root", State.RUNNING, State.SUCCEEDED]
                ]
            );
        });
    });

    describe("is independent of the tree", () => {
        const definition = `root {
            sequence {
                repeat [3] { sequence { action [a] lotto { action [a] action [a] } } }
                retry [2] { wait [100] }
                action [p]
            }
        }`;
        const createTree = (clock: SinonFakeTimers) => {
            let calls = 0;
            const agent = {
                a: () => (++calls % 4 === 0 ? State.RUNNING : State.SUCCEEDED),
                p: () => Promise.resolve(State.SUCCEEDED)
            };
            clock.setSystemTime(0);
            return new BehaviourTree(definition, agent, { random: () => 0.7 });
        };
        const stepTo = async (tree: BehaviourTree, clock: SinonFakeTimers, count: number) => {
            for (let i = 0; i < count; i++) {
                clock.tick(10);
                tree.step();
                await Promise.resolve();
            }
        };
        let clock: SinonFakeTimers;

        beforeEach(() => (clock = sinon.useFakeTimers()));
        afterEach(() => clock.restore());

        for (let steps = 1; steps <= 12; steps++) {
            it(`so stepping the tree or a tree restored from it does not change the snapshot (${steps} steps)`, async () => {
                const tree = createTree(clock);
                await stepTo(tree, clock, steps);
                const snapshot = tree.snapshot();
                const saved = roundTrip(snapshot);

                await stepTo(tree, clock, 12);
                assert.deepEqual(roundTrip(snapshot), saved);

                const restored = createTree(clock);
                restored.restore(snapshot);
                await stepTo(restored, clock, 12);
                assert.deepEqual(roundTrip(snapshot), saved);
            });

            it(`so a snapshot taken right after a restore equals the restored snapshot (${steps} steps)`, async () => {
                const tree = createTree(clock);
                await stepTo(tree, clock, steps);
                const snapshot = tree.snapshot();

                const restored = createTree(clock);
                restored.restore(snapshot);
                assert.deepEqual(roundTrip(restored.snapshot()), roundTrip(snapshot));
            });
        }
    });

    describe("restores a tree that then behaves as the original would have", () => {
        const running = (from: number) => (t: number) => t >= from ? State.SUCCEEDED : State.RUNNING;

        afterEach(() => BehaviourTree.unregisterAll());

        it("for a sequence node", () => {
            assertRestoredTreeBehavesAsOriginal({
                definition: "root { sequence { action [a] action [b] action [c] } }",
                agent: agentWith({ a: running(1), b: running(3), c: running(5) }),
                steps: 8,
                snapshotAt: 3
            });
        });

        it("for a selector node", () => {
            assertRestoredTreeBehavesAsOriginal({
                definition: "root { selector { action [a] action [b] action [c] } }",
                agent: agentWith({
                    a: () => State.FAILED,
                    b: (t) => (t < 4 ? State.RUNNING : State.FAILED),
                    c: running(6)
                }),
                steps: 8,
                snapshotAt: 3
            });
        });

        it("for a parallel node", () => {
            assertRestoredTreeBehavesAsOriginal({
                definition: "root { parallel { action [a] action [b] } }",
                agent: agentWith({ a: running(2), b: running(5) }),
                steps: 8,
                snapshotAt: 3
            });
        });

        it("for a race node", () => {
            assertRestoredTreeBehavesAsOriginal({
                definition: "root { race { action [a] action [b] } }",
                agent: agentWith({ a: (t) => (t < 4 ? State.RUNNING : State.FAILED), b: running(5) }),
                steps: 8,
                snapshotAt: 3
            });
        });

        it("for an all node", () => {
            assertRestoredTreeBehavesAsOriginal({
                definition: "root { all { action [a] action [b] } }",
                agent: agentWith({ a: running(2), b: running(5) }),
                steps: 8,
                snapshotAt: 3
            });
        });

        it("for a flip, succeed and fail node", () => {
            assertRestoredTreeBehavesAsOriginal({
                definition: "root { sequence { flip { action [a] } succeed { action [b] } fail { action [c] } } }",
                agent: agentWith({ a: (t) => (t < 1 ? State.RUNNING : State.FAILED), b: running(3), c: running(5) }),
                steps: 8,
                snapshotAt: 2
            });
        });

        it("for guards, callbacks and a branch node", () => {
            BehaviourTree.register("sub", "root { action [b] until(u) }");
            assertRestoredTreeBehavesAsOriginal({
                definition: `root { sequence entry(onEntry) exit(onExit) {
                    action [a] while(g) step(onStep)
                    branch [sub]
                } }`,
                agent: agentWith({
                    a: running(2),
                    b: running(6),
                    g: () => true,
                    u: (t) => t >= 5,
                    onEntry: () => undefined,
                    onExit: () => undefined,
                    onStep: () => undefined
                }),
                steps: 8,
                snapshotAt: 4
            });
        });

        it("for a lotto node that was aborted by its own guard before picking a child", () => {
            assertRestoredTreeBehavesAsOriginal({
                definition: "root { selector { lotto while(g) { action [a] action [b] } action [c] } }",
                agent: agentWith({ a: running(4), b: running(4), c: running(4), g: () => false }),
                steps: 6,
                snapshotAt: 2
            });
        });

        it("for a wait node when the clock has moved backwards", () => {
            const clock = sinon.useFakeTimers(1000);
            try {
                const definition = "root { wait [500] }";
                const original = new BehaviourTree(definition, {});
                original.step();
                clock.setSystemTime(500);
                const restored = new BehaviourTree(definition, {});
                restored.restore(roundTrip(original.snapshot()));
                assert.strictEqual(restored.getState(), State.RUNNING);
            } finally {
                clock.restore();
            }
        });

        it("for a lotto node, keeping the child already picked", () => {
            assertRestoredTreeBehavesAsOriginal({
                definition: "root { lotto [1,1,1] { action [a] action [b] action [c] } }",
                agent: agentWith({ a: running(4), b: running(4), c: running(4) }),
                randomValues: [0.9],
                restoredRandomValues: [0.1],
                steps: 5,
                snapshotAt: 2
            });
        });

        it("for a repeat node, keeping the iteration count and the random target", () => {
            assertRestoredTreeBehavesAsOriginal({
                definition: "root { repeat [2,5] { action [a] } }",
                agent: agentWith({ a: () => State.SUCCEEDED }),
                randomValues: [0.99],
                restoredRandomValues: [0],
                steps: 8,
                snapshotAt: 3
            });
        });

        it("for a repeat node with a fixed and an infinite iteration count", () => {
            assertRestoredTreeBehavesAsOriginal({
                definition: "root { sequence { repeat [3] { action [a] } repeat { action [b] } } }",
                agent: agentWith({ a: () => State.SUCCEEDED, b: (t) => (t < 9 ? State.SUCCEEDED : State.FAILED) }),
                steps: 12,
                snapshotAt: 2
            });
        });

        it("for a retry node, keeping the attempt count and the random target", () => {
            assertRestoredTreeBehavesAsOriginal({
                definition: "root { retry [2,5] { action [a] } }",
                agent: agentWith({ a: () => State.FAILED }),
                randomValues: [0.99],
                restoredRandomValues: [0],
                steps: 8,
                snapshotAt: 3
            });
        });

        it("for a retry node with a fixed and an infinite attempt count", () => {
            assertRestoredTreeBehavesAsOriginal({
                definition: "root { selector { retry [3] { action [a] } retry { action [b] } } }",
                agent: agentWith({ a: () => State.FAILED, b: (t) => (t < 9 ? State.FAILED : State.SUCCEEDED) }),
                steps: 12,
                snapshotAt: 2
            });
        });

        it("for nested repeat and retry nodes", () => {
            assertRestoredTreeBehavesAsOriginal({
                definition: "root { repeat [3] { retry [3] { action [a] } } }",
                agent: agentWith({ a: (t) => (t % 3 === 2 ? State.SUCCEEDED : State.FAILED) }),
                steps: 12,
                snapshotAt: 5
            });
        });

        it("for an action node and arguments", () => {
            assertRestoredTreeBehavesAsOriginal({
                definition: 'root { sequence { action [a, 1, "x"] action [b] } }',
                agent: agentWith({ a: running(3), b: running(5) }),
                steps: 8,
                snapshotAt: 2
            });
        });

        describe("for a wait node", () => {
            it("waiting only for the remaining time when using the clock", () => {
                assertRestoredTreeBehavesAsOriginal({
                    definition: "root { sequence { wait [500] action [a] } }",
                    agent: agentWith({ a: () => State.SUCCEEDED }),
                    steps: 8,
                    snapshotAt: 3
                });
            });

            it("waiting only for the remaining time when using getDeltaTime", () => {
                assertRestoredTreeBehavesAsOriginal({
                    definition: "root { sequence { wait [500] action [a] } }",
                    agent: agentWith({ a: () => State.SUCCEEDED }),
                    options: () => ({ getDeltaTime: () => 0.1 }),
                    steps: 8,
                    snapshotAt: 3
                });
            });

            it("keeping the random duration already picked", () => {
                assertRestoredTreeBehavesAsOriginal({
                    definition: "root { sequence { wait [100, 900] action [a] } }",
                    agent: agentWith({ a: () => State.SUCCEEDED }),
                    randomValues: [0.5],
                    restoredRandomValues: [0],
                    steps: 6,
                    snapshotAt: 3
                });
            });

            it("that waits indefinitely", () => {
                assertRestoredTreeBehavesAsOriginal({
                    definition: "root { parallel { wait action [a] } }",
                    agent: agentWith({ a: () => State.RUNNING }),
                    steps: 5,
                    snapshotAt: 2
                });
            });
        });

        it("without calling getDeltaTime when the snapshot is taken", () => {
            const getDeltaTime = sinon.stub().returns(0.1);
            const tree = new BehaviourTree("root { wait [500] }", {}, { getDeltaTime });
            tree.step();
            getDeltaTime.resetHistory();
            tree.snapshot();
            assert.isFalse(getDeltaTime.called);
        });

        describe("taken at any step of a run", () => {
            for (let snapshotAt = 0; snapshotAt <= 9; snapshotAt++) {
                it(`(snapshot after ${snapshotAt} steps)`, () => {
                    assertRestoredTreeBehavesAsOriginal({
                        definition: `root { sequence {
                            repeat [2] { sequence { action [a] wait [150] } }
                            lotto { action [b] action [c] }
                            retry [2] { action [d] }
                        } }`,
                        agent: agentWith({
                            a: running(0),
                            b: running(5),
                            c: running(5),
                            d: (t) => (t < 8 ? State.FAILED : State.SUCCEEDED)
                        }),
                        randomValues: [0.3, 0.6, 0.9],
                        steps: 14,
                        snapshotAt
                    });
                });
            }
        });
    });

    describe("of a finished tree", () => {
        for (const finalState of [State.SUCCEEDED, State.FAILED]) {
            it(`restores as ${finalState} and the next step starts a new run with new random choices`, () => {
                const definition =
                    "root { sequence { lotto { action [a] action [b] } repeat [1,3] { action [done] } } }";
                const calls: string[] = [];
                const agent = () => ({
                    a: () => (calls.push("a"), State.SUCCEEDED),
                    b: () => (calls.push("b"), State.SUCCEEDED),
                    done: () => (calls.push("done"), finalState)
                });

                const original = new BehaviourTree(definition, agent(), { random: createRandom([0.1]) });
                original.step();
                original.step();
                assert.strictEqual(original.getState(), finalState);

                const restoredRandom = createRandom([0.9, 0.9]);
                const restored = new BehaviourTree(definition, agent(), { random: restoredRandom });
                restored.restore(roundTrip(original.snapshot()));
                assert.strictEqual(restored.getState(), finalState);
                assert.strictEqual(restoredRandom.index, 0);

                calls.length = 0;
                restored.step();
                assert.strictEqual(calls[0], "b");
                assert.isAbove(restoredRandom.index, 0);
            });
        }
    });

    describe("of an action node", () => {
        const definition = "root { action [a] }";

        it("with a settled update promise restores with the promise result", async () => {
            for (const result of [State.SUCCEEDED, State.FAILED]) {
                const a = sinon.stub().resolves(result);
                const original = new BehaviourTree(definition, { a });
                original.step();
                await Promise.resolve();

                const b = sinon.stub().resolves(result);
                const restored = new BehaviourTree(definition, { a: b });
                restored.restore(roundTrip(original.snapshot()));
                restored.step();

                assert.strictEqual(restored.getState(), result);
                assert.isFalse(b.called);
            }
        });

        it("with a rejected update promise restores to error with the same message", async () => {
            const original = new BehaviourTree(definition, { a: () => Promise.reject(new Error("nope")) });
            original.step();
            await Promise.resolve();
            await Promise.resolve();

            const restored = new BehaviourTree(definition, { a: () => State.SUCCEEDED });
            restored.restore(roundTrip(original.snapshot()));

            let originalError = "";
            try {
                original.step();
            } catch (error) {
                originalError = (error as Error).message;
            }
            assert.throws(() => restored.step(), Error, originalError);
        });

        it("with a pending update promise restores as not yet started and calls the action function again", () => {
            const sequence = "root { sequence { action [first] action [a] } }";
            const original = new BehaviourTree(sequence, {
                first: () => State.SUCCEEDED,
                a: () => new Promise<State>(() => undefined)
            });
            original.step();

            const snapshot = roundTrip(original.snapshot());
            assert.strictEqual(original.getTreeNodeDetails().children![0].children![1].state, State.RUNNING);

            const first = sinon.stub().returns(State.SUCCEEDED);
            const a = sinon.stub().returns(State.SUCCEEDED);
            const restored = new BehaviourTree(sequence, { first, a });
            restored.restore(snapshot);
            assert.isFalse(a.called);

            restored.step();

            assert.isTrue(a.calledOnce);
            assert.isFalse(first.called);
            assert.strictEqual(restored.getState(), State.SUCCEEDED);
        });

        it("with a pending update promise calls the entry callback of the action again", () => {
            const entry = "root { action [a] entry(onEntry) }";
            const original = new BehaviourTree(entry, {
                a: () => new Promise<State>(() => undefined),
                onEntry: () => undefined
            });
            original.step();

            const onEntry = sinon.stub();
            const restored = new BehaviourTree(entry, { a: () => State.RUNNING, onEntry });
            restored.restore(original.snapshot());
            restored.step();

            assert.isTrue(onEntry.calledOnce);
        });

        it("is not affected by the settling of a promise from before the restore", async () => {
            let resolveOld: (state: State) => void = () => undefined;
            const tree = new BehaviourTree(definition, { a: () => new Promise<State>((r) => (resolveOld = r)) });
            tree.step();

            const source = new BehaviourTree(definition, { a: () => Promise.resolve(State.FAILED) });
            source.step();
            await Promise.resolve();
            tree.restore(source.snapshot());

            resolveOld(State.SUCCEEDED);
            await Promise.resolve();
            tree.step();
            assert.strictEqual(tree.getState(), State.FAILED);
        });
    });

    describe("will not be restored, leaving the tree unchanged, if", () => {
        const definition = "root { sequence { repeat [3] { action [a] } wait [100] lotto { action [a] action [a] } } }";
        const agent = { a: () => State.RUNNING };

        const createSnapshot = () => {
            const tree = new BehaviourTree(definition, agent, { random: () => 0.9 });
            tree.step();
            return JSON.parse(JSON.stringify(tree.snapshot()));
        };

        const findNode = (node: any, type: string): any =>
            node.type === type ? node : node.children?.map((c: any) => findNode(c, type)).find(Boolean);

        const cases: [string, (snapshot: any) => any, string][] = [
            ["it is null", () => null, "invalid snapshot"],
            ["it is a string", () => "snapshot", "invalid snapshot"],
            ["it is a number", () => 1, "invalid snapshot"],
            ["it is an array", (s) => [s], "invalid snapshot"],
            ["it is an object without the snapshot fields", () => ({}), "invalid snapshot"],
            ["its version is not supported", (s) => ({ ...s, version: 2 }), "unsupported snapshot version"],
            ["it has no definition", (s) => (delete s.definition, s), "invalid snapshot"],
            ["its definition is not a string", (s) => ({ ...s, definition: 1 }), "invalid snapshot"],
            ["its definition is not the definition of the tree", (s) => ({ ...s, definition: "x" }), "does not match"],
            ["it has no root", (s) => (delete s.root, s), "invalid snapshot"],
            ["its root is not an object", (s) => ({ ...s, root: "root" }), "invalid snapshot"],
            [
                "a node type does not match the tree",
                (s) => ((s.root.child = undefined), (s.root.type = "sequence"), s),
                "expected root node"
            ],
            [
                "a node name does not match the tree",
                (s) => ((findNode(s.root, "action").name = "other"), s),
                "expected action node"
            ],
            [
                "a node has a state that does not exist",
                (s) => ((s.root.state = "mistreevous.nope"), s),
                "invalid state"
            ],
            [
                "a node has the wrong number of children",
                (s) => (findNode(s.root, "lotto").children.pop(), s),
                "children"
            ],
            ["a node has no children where it needs them", (s) => (delete s.root.children, s), "children"],
            [
                "a repeat count is not a valid number",
                (s) => ((findNode(s.root, "repeat").currentIterationCount = -1), s),
                "repeat"
            ],
            [
                "a repeat target is missing",
                (s) => (delete findNode(s.root, "repeat").targetIterationCount, s),
                "repeat"
            ],
            [
                "a wait duration is not a valid number",
                (s) => ((findNode(s.root, "wait").waitedDuration = "1"), s),
                "wait"
            ],
            ["a lotto selection is out of range", (s) => ((findNode(s.root, "lotto").selectedChild = 5), s), "lotto"],
            [
                "an action promise is malformed",
                (s) => ((findNode(s.root, "action").promise = { isResolved: 1 }), s),
                "action"
            ],
            [
                "an action promise is set on an action that has not been updated",
                (s) => (
                    (findNode(s.root, "lotto").children[0].promise = {
                        isResolved: true,
                        value: "mistreevous.succeeded"
                    }),
                    s
                ),
                "action"
            ]
        ];

        for (const [description, corrupt, message] of cases) {
            it(description, () => {
                const tree = new BehaviourTree(definition, agent, { random: () => 0.9 });
                tree.step();
                tree.step();
                const before = tree.snapshot();

                assert.throws(() => tree.restore(corrupt(createSnapshot())), Error, message);
                assert.deepEqual(tree.snapshot(), before);
            });
        }
    });

    describe("of a tree with a different definition", () => {
        const agent = { a: () => State.RUNNING, b: () => true };

        // A wait node snapshot includes the time elapsed, which must not change between taking two snapshots.
        let clock: SinonFakeTimers;
        beforeEach(() => (clock = sinon.useFakeTimers()));
        afterEach(() => clock.restore());

        // Each pair has the same node types and names, so only the definition fingerprint tells them apart.
        const pairs: [string, string, string][] = [
            ["an action argument", "root { action [a, 1] }", "root { action [a, 2] }"],
            ["a wait duration", "root { wait [100] }", "root { wait [200] }"],
            [
                "lotto weights",
                "root { lotto [1, 2] { action [a] action [a] } }",
                "root { lotto [2, 1] { action [a] action [a] } }"
            ],
            ["a repeat count", "root { repeat [3] { action [a] } }", "root { repeat [4] { action [a] } }"],
            ["a retry count", "root { retry [3] { action [a] } }", "root { retry [4] { action [a] } }"],
            ["a guard argument", "root { action [a] while(b, 1) }", "root { action [a] while(b, 2) }"],
            ["a guard abort result", "root { action [a] while(b) }", "root { action [a] while(b) then succeed }"],
            ["a callback", "root { action [a] entry(a) }", "root { action [a] entry(b) }"],
            ["a guard type", "root { action [a] while(b) }", "root { action [a] until(b) }"],
            [
                "a sub tree",
                "root { branch [s] } root [s] { action [a, 1] }",
                "root { branch [s] } root [s] { action [a, 2] }"
            ]
        ];

        for (const [description, source, target] of pairs) {
            it(`is rejected, leaving the tree unchanged, when it differs by ${description}`, () => {
                const original = new BehaviourTree(source, agent);
                original.step();
                const tree = new BehaviourTree(target, agent);
                tree.step();
                const before = tree.snapshot();

                assert.throws(
                    () => tree.restore(roundTrip(original.snapshot())),
                    Error,
                    "snapshot does not match the tree's definition"
                );
                assert.deepEqual(tree.snapshot(), before);
            });
        }

        it("is rejected when it has a different structure", () => {
            const other = new BehaviourTree("root { repeat [3] { action [a] } }", agent);
            other.step();
            const tree = new BehaviourTree("root { sequence { action [a] action [a] } }", agent);
            assert.throws(() => tree.restore(other.snapshot()), Error, "does not match the tree's definition");
        });
    });

    describe("of a tree with an equivalent definition", () => {
        const agent = { a: () => State.RUNNING, b: () => true, c: () => undefined };

        // A wait node snapshot includes the time elapsed, which must not change between taking two snapshots.
        let clock: SinonFakeTimers;
        beforeEach(() => (clock = sinon.useFakeTimers()));
        afterEach(() => clock.restore());

        const pairs: [string, string, any][] = [
            ["an action", "root { action [a] }", { type: "root", child: { type: "action", call: "a" } }],
            [
                "an action with arguments of every type",
                'root { action [a, 1, "x", true, null, $p] }',
                { type: "root", child: { type: "action", call: "a", args: [1, "x", true, null, { $: "p" }] } }
            ],
            ["a condition", "root { condition [b] }", { type: "root", child: { type: "condition", call: "b" } }],
            [
                "waits",
                "root { sequence { wait [100] wait [1, 2] wait } }",
                {
                    type: "root",
                    child: {
                        type: "sequence",
                        children: [
                            { type: "wait", duration: 100 },
                            { type: "wait", duration: [1, 2] },
                            { type: "wait" }
                        ]
                    }
                }
            ],
            [
                "every composite node",
                "root { selector { parallel { race { all { action [a] } } } lotto [1] { action [a] } } }",
                {
                    type: "root",
                    child: {
                        type: "selector",
                        children: [
                            {
                                type: "parallel",
                                children: [
                                    {
                                        type: "race",
                                        children: [{ type: "all", children: [{ type: "action", call: "a" }] }]
                                    }
                                ]
                            },
                            { type: "lotto", weights: [1], children: [{ type: "action", call: "a" }] }
                        ]
                    }
                }
            ],
            [
                "every decorator node",
                "root { flip { succeed { fail { repeat { retry [2] { action [a] } } } } } }",
                {
                    type: "root",
                    child: {
                        type: "flip",
                        child: {
                            type: "succeed",
                            child: {
                                type: "fail",
                                child: {
                                    type: "repeat",
                                    child: { type: "retry", attempts: 2, child: { type: "action", call: "a" } }
                                }
                            }
                        }
                    }
                }
            ],
            [
                "every attribute",
                "root { action [a] while(b, 1) until(b) entry(c) step(c, 2) exit(c) }",
                {
                    type: "root",
                    child: {
                        type: "action",
                        call: "a",
                        while: { call: "b", args: [1] },
                        until: { call: "b" },
                        entry: { call: "c" },
                        step: { call: "c", args: [2] },
                        exit: { call: "c" }
                    }
                }
            ],
            [
                "a guard that succeeds on abort",
                "root { action [a] while(b) then succeed }",
                { type: "root", child: { type: "action", call: "a", while: { call: "b", succeedOnAbort: true } } }
            ],
            [
                "sub trees in a different order",
                "root { branch [s] } root [s] { branch [t] } root [t] { action [a] }",
                [
                    { type: "root", id: "t", child: { type: "action", call: "a" } },
                    { type: "root", child: { type: "branch", ref: "s" } },
                    { type: "root", id: "s", child: { type: "branch", ref: "t" } }
                ]
            ]
        ];

        // Adds the 'args' and 'succeedOnAbort' values that MDSL always sets, as every other part of the definition is spelled out.
        const withDefaults = (node: any, key = ""): any =>
            Array.isArray(node)
                ? node.map((item) => withDefaults(item))
                : node && typeof node === "object"
                ? Object.fromEntries(
                      Object.entries({
                          ...(typeof node.call === "string" && { args: [] }),
                          ...(["while", "until"].includes(key) && { succeedOnAbort: false }),
                          ...node
                      }).map(([k, v]) => [k, withDefaults(v, k)])
                  )
                : node;

        const withReversedKeys = (node: any): any =>
            Array.isArray(node)
                ? node.map(withReversedKeys)
                : node && typeof node === "object"
                ? Object.fromEntries(
                      Object.entries(node)
                          .reverse()
                          .map(([k, v]) => [k, withReversedKeys(v)])
                  )
                : node;

        for (const [description, mdsl, json] of pairs) {
            for (const [form, equivalent] of [
                ["JSON", json],
                ["JSON with explicit defaults", withDefaults(json)],
                ["JSON with the keys in reverse order", withReversedKeys(json)]
            ] as [string, any][]) {
                it(`restores into ${form} for ${description}`, () => {
                    const original = new BehaviourTree(mdsl, agent);
                    original.step();
                    const tree = new BehaviourTree(equivalent, agent);

                    tree.restore(roundTrip(original.snapshot()));

                    assert.deepEqual(stripIds(tree.getTreeNodeDetails()), stripIds(original.getTreeNodeDetails()));
                    assert.deepEqual(tree.snapshot(), original.snapshot());
                });
            }
        }

        it("restores a single root object into an array of one root", () => {
            const original = new BehaviourTree({ type: "root", child: { type: "action", call: "a" } }, agent);
            original.step();
            const tree = new BehaviourTree([{ type: "root", child: { type: "action", call: "a" } }], agent);
            tree.restore(original.snapshot());
            assert.deepEqual(tree.snapshot(), original.snapshot());
        });
    });
});
