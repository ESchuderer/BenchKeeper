# Reject snapshots of another definition, restore pending actions as not started

Status: ready-for-agent

Spec: `.scratch/snapshot-restore/spec.md`

## Goal

1. Each snapshot records which tree definition it belongs to. `restore()` throws an `Error` whose message says that the snapshot does not match the tree's definition when the snapshot is of another definition. An MDSL definition and its equivalent JSON definition are the same definition. Input that is not a snapshot (`null`, a string, a number, an array, an object without the snapshot's fields) is rejected with an `Error`. A rejected `restore()` leaves the tree as it was.
2. An action whose promise is pending when the snapshot is taken is saved as not yet started. The restored tree calls its action function again on its next step. `snapshot()` no longer throws for it. The README documents this next to the snapshot API.

## Decisions

- `BehaviourTreeSnapshot` gets a `definition` string: a hash of the canonical form of the validated JSON definition. The format stays at `version: 1` because it is not released.
- Canonical form: object keys sorted, `undefined` values dropped, empty `args` and `succeedOnAbort: false` dropped (MDSL always emits them, JSON may omit them), root node definitions sorted by `id`.
- Not covered: the contents of subtrees added with `BehaviourTree.register`.
- A pending action is saved with state `READY` and no promise result, so `entry` is called again with the action function.
- Version stays 4.4.0 (unreleased). The Version History row is updated.

## Acceptance criteria

- [ ] Snapshot of a different definition: `restore()` throws, message contains `does not match the tree's definition`, tree unchanged.
- [ ] MDSL snapshot restores into a tree built from the equivalent JSON definition, and the reverse.
- [ ] `null`, string, number, array, `{}`, `{ version: 1 }` and a snapshot without `definition` are rejected with an `Error`, tree unchanged.
- [ ] Pending action: `snapshot()` does not throw, restored action calls its function again on the next step.
- [ ] README and Version History updated. `npm test` passes.
