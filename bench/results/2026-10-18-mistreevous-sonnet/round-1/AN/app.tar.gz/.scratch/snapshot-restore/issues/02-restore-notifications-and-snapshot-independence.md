# Restore does not call onNodeStateChange, snapshots are independent of the tree

Status: ready-for-agent

Spec: `.scratch/snapshot-restore/spec.md`

## Goal

1. `restore()` does not call `onNodeStateChange`. The next `step()` reports changes as usual.
2. After `const s = tree.snapshot()`, stepping the tree does not change `s`. After `restored.restore(s)`, stepping `restored` does not change `s`. A snapshot taken right after `restore(s)`, before any step, equals `s` (after a JSON round trip of both).

## Decisions

- `restore()` sets node states directly instead of through `setState`. This replaces the spec decision that `onNodeStateChange` fires for restored nodes.
- A running `wait` node that uses the clock keeps counting after `restore()`, so a snapshot taken later than the restore shows the time that has passed since. Only a snapshot taken at the same clock time equals `s`.
- Version stays 4.4.0 (unreleased, latest on npm is 4.3.1). The Version History row is updated.

## Acceptance criteria

- [x] `restore()` does not call `onNodeStateChange`, including over nodes that are not in the `READY` state. The next `step()` calls it with the correct previous states.
- [x] Tests for the three snapshot independence statements, using the clock and `getDeltaTime`, over every node type and a settled and a pending action promise.
- [x] README and Version History updated. `npm test` passes.
