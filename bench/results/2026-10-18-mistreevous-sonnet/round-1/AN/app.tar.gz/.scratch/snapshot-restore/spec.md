# Snapshot and restore of tree execution state

Status: ready-for-agent

## Goal

`BehaviourTree.snapshot()` returns the execution state as a plain object. `restore(snapshot)` applies it to a tree built from the same definition. The restored tree then behaves as the original would have: same node states, same agent function calls in the same order, same result.

## Snapshot format (version 1)

```ts
type BehaviourTreeSnapshot = { version: 1; root: NodeSnapshot };

type NodeSnapshot = {
    type: string;        // node type, checked on restore
    name: string;        // node name from getName(), checked on restore (catches a different definition)
    state: State;        // READY | RUNNING | SUCCEEDED | FAILED
    children?: NodeSnapshot[];   // composite and decorator nodes, same order as the tree
    // per type, keys omitted when not applicable (no undefined values, so JSON round trip is identity):
    selectedChild?: number | null;          // lotto: index of the drawn child
    targetIterationCount?: number | null;   // repeat
    currentIterationCount?: number;         // repeat
    targetAttemptCount?: number | null;     // retry
    currentAttemptCount?: number;           // retry
    totalDuration?: number | null;          // wait: chosen duration in ms
    waitedDuration?: number;                // wait: ms waited at snapshot time
    pendingResult?: ...;                    // action: settled promise result not yet consumed by a step
};
```

Composite progress (which children are done or running) is the child states. Node ids are per instance and not part of the snapshot.

## Decisions

- Wait, `Date` mode: `waitedDuration = now - initialUpdateTime` at snapshot time; restore sets `initialUpdateTime = now - waitedDuration`. `getDeltaTime` mode: the accumulated `waitedDuration` is stored as is. Downtime is not counted in either mode.
- Action with a pending (unsettled) promise: `snapshot()` throws. The result cannot be serialised, and restoring without it would call the action function a second time. A settled but unconsumed promise result is stored.
- `restore()` validates the whole snapshot (version, node type, node name, child count, state values, counts) before it changes anything. An invalid snapshot throws and leaves the tree unchanged.
- `restore()` sets node states directly, so `onNodeStateChange` is not called. The next `step()` reports changes as usual.
- Promises started before `restore()` cannot write into restored action nodes.
- `snapshot()` and `restore()` throw when called from inside `step()` (tree state is half-updated).
- Finished tree: stored as is. The next `step()` resets the root, which draws new random values.
- Version 4.4.0, README method docs with example, Version History row.
