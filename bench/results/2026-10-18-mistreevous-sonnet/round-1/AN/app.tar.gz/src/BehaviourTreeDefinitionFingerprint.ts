import { RootNodeDefinition } from "./BehaviourTreeDefinition";

/**
 * Gets the canonical form of a part of a JSON definition.
 * Properties that MDSL always includes but that JSON definitions can leave out are dropped when they have their default value.
 * @param value The part of a JSON definition.
 * @returns The canonical form of the part of the definition.
 */
function canonicalise(value: unknown): unknown {
    if (Array.isArray(value)) {
        return value.map(canonicalise);
    }

    if (typeof value !== "object" || value === null) {
        return value;
    }

    const canonical: { [key: string]: unknown } = {};

    for (const key of Object.keys(value).sort()) {
        const propertyValue = (value as { [key: string]: unknown })[key];

        const isDefault =
            propertyValue === undefined ||
            // The arguments of an action, condition or attribute.
            (key === "args" && Array.isArray(propertyValue) && propertyValue.length === 0) ||
            // Whether an aborted node succeeds, which is false for a guard unless defined otherwise.
            (key === "succeedOnAbort" && propertyValue === false);

        if (!isDefault) {
            canonical[key] = canonicalise(propertyValue);
        }
    }

    return canonical;
}

/**
 * Gets a hash of a string as a 53 bit hex string (cyrb53).
 * @param value The string to hash.
 * @returns The hash.
 */
function hash(value: string): string {
    let h1 = 0xdeadbeef;
    let h2 = 0x41c6ce57;

    for (let index = 0; index < value.length; index++) {
        const code = value.charCodeAt(index);

        h1 = Math.imul(h1 ^ code, 2654435761);
        h2 = Math.imul(h2 ^ code, 1597334677);
    }

    h1 = Math.imul(h1 ^ (h1 >>> 16), 2246822507) ^ Math.imul(h2 ^ (h2 >>> 13), 3266489909);
    h2 = Math.imul(h2 ^ (h2 >>> 16), 2246822507) ^ Math.imul(h1 ^ (h1 >>> 13), 3266489909);

    return (4294967296 * (2097151 & h2) + (h1 >>> 0)).toString(16);
}

/**
 * Gets a fingerprint of a tree definition.
 * An MDSL definition and its equivalent JSON definition have the same fingerprint, as the MDSL definition is converted to JSON first.
 * The fingerprint does not include the subtrees that are registered with BehaviourTree.register.
 * @param rootNodeDefinitions The root node definitions of the tree definition in JSON form.
 * @returns The fingerprint of the tree definition.
 */
export function createDefinitionFingerprint(rootNodeDefinitions: RootNodeDefinition[]): string {
    // The order of the root node definitions does not change the tree, so they are put in the order of their identifiers.
    // This is not a locale comparison, as the fingerprint has to be the same on every machine.
    const sortedRootNodeDefinitions = [...rootNodeDefinitions].sort((a, b) => {
        const [aId, bId] = [a.id ?? "", b.id ?? ""];

        return aId < bId ? -1 : aId > bId ? 1 : 0;
    });

    return hash(JSON.stringify(canonicalise(sortedRootNodeDefinitions)));
}
