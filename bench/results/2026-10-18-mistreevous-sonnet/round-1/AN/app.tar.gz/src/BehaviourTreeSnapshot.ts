import { AnyState } from "./State";

/**
 * The result of a settled action node promise that has not been used by a tree step yet.
 */
export type ActionPromiseResultSnapshot = {
    /**
     * Whether the promise was resolved, otherwise it was rejected.
     */
    isResolved: boolean;
    /**
     * The state that the promise resolved with, or null if it resolved with an invalid value.
     * If the promise was rejected then this is the rejection reason as a string.
     */
    value: string | null;
};

/**
 * The execution state of a single node in a behaviour tree.
 * Properties that do not apply to the type of the node are not defined.
 */
export type NodeSnapshot = {
    /**
     * The node type.
     */
    type: string;
    /**
     * The node name.
     */
    name: string;
    /**
     * The state of the node.
     */
    state: AnyState;
    /**
     * The snapshots of the child nodes of this node, defined if this is a composite or decorator node.
     */
    children?: NodeSnapshot[];
    /**
     * The index of the child node picked by a lotto node, or null if it has not picked one.
     */
    selectedChild?: number | null;
    /**
     * The number of iterations a repeat node will make, or null if it will repeat indefinitely or has not started.
     */
    targetIterationCount?: number | null;
    /**
     * The number of iterations a repeat node has completed.
     */
    currentIterationCount?: number;
    /**
     * The number of attempts a retry node will make, or null if it will retry indefinitely or has not started.
     */
    targetAttemptCount?: number | null;
    /**
     * The number of attempts a retry node has made.
     */
    currentAttemptCount?: number;
    /**
     * The duration in milliseconds that a wait node will wait for, or null if it will wait indefinitely or has not started.
     */
    totalDuration?: number | null;
    /**
     * The duration in milliseconds that a wait node has waited for at the time of the snapshot.
     */
    waitedDuration?: number;
    /**
     * The settled result of the promise returned by an action node, if it has settled.
     */
    promiseResult?: ActionPromiseResultSnapshot;
};

/**
 * The execution state of a behaviour tree, as a plain object that is unchanged by a JSON round trip.
 * A snapshot can only be restored to a tree built from the same definition as the tree it was taken from.
 */
export type BehaviourTreeSnapshot = {
    /**
     * The snapshot format version.
     */
    version: 1;
    /**
     * A fingerprint of the definition of the tree that the snapshot was taken from.
     * An MDSL definition and its equivalent JSON definition have the same fingerprint.
     */
    definition: string;
    /**
     * The snapshot of the root node of the tree.
     */
    root: NodeSnapshot;
};

/**
 * Gets whether a value is an integer that is not negative.
 * @param value The value to check.
 * @returns Whether a value is an integer that is not negative.
 */
export function isNonNegativeInteger(value: unknown): value is number {
    return typeof value === "number" && Number.isInteger(value) && value >= 0;
}
