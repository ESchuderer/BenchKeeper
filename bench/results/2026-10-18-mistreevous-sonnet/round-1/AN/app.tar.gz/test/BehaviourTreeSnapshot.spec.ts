import { assert } from "chai";
import sinon, { SinonFakeTimers } from "sinon";

import { BehaviourTree, BehaviourTreeOptions, BehaviourTreeSnapshot, NodeDetails, State } from "../src/index";
import { Agent } from "../src/Agent";
import { RootNodeDefinition } from "../src/BehaviourTreeDefinition";

type Run = {
    tree: BehaviourTree;
    calls: string[];
};

/**
 * Creates an agent with a function for each of the given names, each of which records its name in the calls array
 * and then returns the result of the function defined for it.
 */
const createAgent = (calls: string[], results: { [name: string]: () => any }): Agent => {
    const agent: Agent = {};

    for (const name of Object.keys(results)) {
        agent[name] = () => {
            calls.push(name);
            return results[name]();
        };
    }

    return agent;
};

const createRun = (
    definition: string | RootNodeDefinition | RootNodeDefinition[],
    results: { [name: string]: () => any },
    options: BehaviourTreeOptions = {}
): Run => {
    const calls: string[] = [];

    return { tree: new BehaviourTree(definition, createAgent(calls, results), options), calls };
};

/** Node identifiers are generated for each tree instance, so they are left out when comparing trees. */
const withoutIds = (details: NodeDetails): any => ({
    ...details,
    id: undefined,
    children: details.children?.map(withoutIds)
});

const roundTrip = <T>(value: T): T => JSON.parse(JSON.stringify(value));

/** Restores the target tree from a JSON round-tripped snapshot of the source tree. */
const transfer = (source: Run, target: Run): void => {
    target.tree.restore(roundTrip(source.tree.snapshot()));

    assert.deepEqual(withoutIds(target.tree.getTreeNodeDetails()), withoutIds(source.tree.getTreeNodeDetails()));
};

/** Steps both trees, checking that every step leaves them in the same state and that they call the same agent functions. */
const assertSameFuture = (original: Run, restored: Run, steps: number): void => {
    original.calls.length = 0;
    restored.calls.length = 0;

    for (let step = 1; step <= steps; step++) {
        original.tree.step();
        restored.tree.step();

        assert.deepEqual(
            withoutIds(restored.tree.getTreeNodeDetails()),
            withoutIds(original.tree.getTreeNodeDetails()),
            `node details differ after step ${step}`
        );
    }

    assert.deepEqual(restored.calls, original.calls);
};

describe("A BehaviourTree", () => {
    describe("snapshot()", () => {
        it("returns a plain object that is unchanged by a JSON round trip", () => {
            const definition = `root {
                parallel {
                    lotto { action [Running] action [Running] }
                    repeat [1,3] {
                        retry [2,4] {
                            sequence {
                                condition [IsTrue]
                                wait [100,200]
                                action [Running]
                            }
                        }
                    }
                    parallel { action [Running] race { action [Failing] all { action [Running] } } }
                    flip { selector { action [Failing] succeed { action [Running] } fail { action [Running] } } }
                }
            }`;
            const { tree } = createRun(definition, {
                Running: () => State.RUNNING,
                Failing: () => State.FAILED,
                IsTrue: () => true
            });

            const readySnapshot = tree.snapshot();
            assert.deepEqual(roundTrip(readySnapshot), readySnapshot);

            tree.step();
            tree.step();

            const runningSnapshot = tree.snapshot();
            assert.deepEqual(roundTrip(runningSnapshot), runningSnapshot);
        });

        it("does not change the state of the tree", () => {
            const run = createRun("root { sequence { action [Running] action [Running] } }", {
                Running: () => State.RUNNING
            });
            run.tree.step();

            const before = withoutIds(run.tree.getTreeNodeDetails());
            run.tree.snapshot();

            assert.deepEqual(withoutIds(run.tree.getTreeNodeDetails()), before);
        });

        it("saves an action that is waiting on a promise that has not settled as not started", () => {
            const run = createRun("root { sequence { action [Done] action [Pending] } }", {
                Done: () => State.SUCCEEDED,
                Pending: () => new Promise(() => {})
            });
            run.tree.step();

            const before = withoutIds(run.tree.getTreeNodeDetails());
            const snapshot = roundTrip(run.tree.snapshot());
            const [done, pending] = snapshot.root.children![0].children!;

            assert.strictEqual(done.state, State.SUCCEEDED);
            assert.strictEqual(pending.state, State.READY);
            assert.notProperty(pending, "promiseResult");

            // The tree that the snapshot was taken from is not changed and keeps waiting on its promise.
            assert.deepEqual(withoutIds(run.tree.getTreeNodeDetails()), before);
            run.calls.length = 0;
            run.tree.step();
            assert.deepEqual(run.calls, []);
        });

        describe("records the definition it was taken from", () => {
            const getDefinition = (definition: string | RootNodeDefinition | RootNodeDefinition[]) =>
                createRun(definition, {}).tree.snapshot().definition;

            it("so that equal definitions give the same value, whatever their layout", () => {
                assert.isString(getDefinition("root { action [Work] }"));
                assert.strictEqual(
                    getDefinition("root { action [Work] }"),
                    getDefinition("root {\n    /* work */\n    action [Work]\n}")
                );
            });

            it("so that an MDSL definition and its equivalent JSON definition give the same value", () => {
                assert.strictEqual(
                    getDefinition("root { sequence while(Alive) { action [Work, 1] wait [10, 20] } }"),
                    getDefinition({
                        type: "root",
                        child: {
                            type: "sequence",
                            while: { call: "Alive" },
                            children: [
                                { type: "action", call: "Work", args: [1] },
                                { type: "wait", duration: [10, 20] }
                            ]
                        }
                    })
                );
            });

            it("so that different definitions give different values", () => {
                const definitions = [
                    "root { action [Work] }",
                    "root { action [Other] }",
                    "root { action [Work, 1] }",
                    "root { action [Work, 2] }",
                    "root { action [Work] while(Alive) }",
                    "root { action [Work] until(Alive) }",
                    "root { action [Work] entry(Alive) }",
                    "root { sequence { action [Work] } }",
                    "root { wait [10] }",
                    "root { wait [20] }"
                ];
                const values = definitions.map(getDefinition);

                assert.strictEqual(new Set(values).size, definitions.length);
            });
        });

        it("cannot be taken during a step", () => {
            const tree: BehaviourTree = new BehaviourTree("root { action [TakeSnapshot] }", {
                TakeSnapshot: () => {
                    tree.snapshot();
                }
            });

            assert.throws(() => tree.step(), Error, "cannot take a snapshot while the tree is being stepped");

            // The tree is usable again after the failed step.
            assert.doesNotThrow(() => tree.snapshot());
        });
    });

    describe("restore()", () => {
        describe("sets a tree built from the same definition to the state of the snapshot", () => {
            it("so that finished children of composite nodes are not run again", () => {
                const flags = { ready: false };
                const results = {
                    Done: () => State.SUCCEEDED,
                    Waiting: () => (flags.ready ? State.SUCCEEDED : State.RUNNING),
                    Last: () => State.SUCCEEDED
                };
                const definition =
                    "root { sequence { action [Done] parallel { action [Done] action [Waiting] } action [Last] } }";
                const original = createRun(definition, results);
                const restored = createRun(definition, results);

                original.tree.step();
                transfer(original, restored);
                flags.ready = true;

                assertSameFuture(original, restored, 1);
                assert.notInclude(restored.calls, "Done");
                assert.deepEqual(restored.calls, ["Waiting", "Last"]);
                assert.strictEqual(restored.tree.getState(), State.SUCCEEDED);
            });

            it("so that entry callbacks are not called again for running nodes", () => {
                const flags = { ready: false };
                const results = {
                    Work: () => (flags.ready ? State.SUCCEEDED : State.RUNNING),
                    OnEntry: () => undefined,
                    OnExit: () => undefined
                };
                const definition = "root { action [Work] entry(OnEntry) exit(OnExit) }";
                const original = createRun(definition, results);
                const restored = createRun(definition, results);

                original.tree.step();
                assert.deepEqual(original.calls, ["OnEntry", "Work"]);

                transfer(original, restored);
                flags.ready = true;

                assertSameFuture(original, restored, 1);
                assert.deepEqual(restored.calls, ["Work", "OnExit"]);
            });

            it("including when the tree has not been stepped or has progressed beyond the snapshot", () => {
                const run = createRun("root { sequence { action [Done] action [Running] } }", {
                    Done: () => State.SUCCEEDED,
                    Running: () => State.RUNNING
                });
                const readyDetails = withoutIds(run.tree.getTreeNodeDetails());
                const readySnapshot = roundTrip(run.tree.snapshot());

                run.tree.step();
                run.tree.restore(readySnapshot);

                assert.deepEqual(withoutIds(run.tree.getTreeNodeDetails()), readyDetails);
                assert.deepEqual(run.tree.snapshot(), readySnapshot);
            });

            it("without calling onNodeStateChange, which is called for the changes of the next step as usual", () => {
                const flags = { ready: false };
                const results = {
                    Done: () => State.SUCCEEDED,
                    Work: () => (flags.ready ? State.SUCCEEDED : State.RUNNING)
                };
                const definition = "root { sequence { action [Done] action [Work] } }";
                const changes: { type: string; previousState: State; state: State }[] = [];
                const original = createRun(definition, results);
                const restored = createRun(definition, results, {
                    onNodeStateChange: ({ type, previousState, state }) => changes.push({ type, previousState, state })
                });

                original.tree.step();
                transfer(original, restored);

                assert.deepEqual(changes, []);

                // Restoring over nodes that are not in the ready state is not a state change either.
                restored.tree.reset();
                changes.length = 0;
                restored.tree.restore(roundTrip(original.tree.snapshot()));

                assert.deepEqual(changes, []);

                flags.ready = true;
                restored.tree.step();

                assert.deepEqual(changes, [
                    { type: "action", previousState: State.RUNNING, state: State.SUCCEEDED },
                    { type: "sequence", previousState: State.RUNNING, state: State.SUCCEEDED },
                    { type: "root", previousState: State.RUNNING, state: State.SUCCEEDED }
                ]);
            });
        });

        describe("keeps the iteration and attempt counts of repeat and retry nodes", () => {
            it("(repeat)", () => {
                const results = { Work: () => State.SUCCEEDED };
                const definition = "root { repeat [3] { action [Work] } }";
                const original = createRun(definition, results);
                const restored = createRun(definition, results);

                original.tree.step();
                original.tree.step();
                transfer(original, restored);

                assertSameFuture(original, restored, 2);
                assert.deepEqual(restored.calls, ["Work"]);
                assert.strictEqual(restored.tree.getState(), State.SUCCEEDED);
            });

            it("(retry)", () => {
                const results = { Work: () => State.FAILED };
                const definition = "root { retry [3] { action [Work] } }";
                const original = createRun(definition, results);
                const restored = createRun(definition, results);

                original.tree.step();
                original.tree.step();
                transfer(original, restored);

                assertSameFuture(original, restored, 2);
                assert.deepEqual(restored.calls, ["Work"]);
                assert.strictEqual(restored.tree.getState(), State.FAILED);
            });
        });

        describe("keeps random choices that were already made", () => {
            it("(repeat iteration count)", () => {
                const results = { Work: () => State.SUCCEEDED };
                const definition = "root { repeat [1,5] { action [Work] } }";
                // A random value of 0 picks the minimum of one iteration, 0.99 would pick five.
                const original = createRun(definition, results, { random: () => 0 });
                const restored = createRun(definition, results, { random: () => 0.99 });

                original.tree.step();
                transfer(original, restored);

                assertSameFuture(original, restored, 1);
                assert.strictEqual(restored.tree.getState(), State.SUCCEEDED);
            });

            it("(retry attempt count)", () => {
                const results = { Work: () => State.FAILED };
                const definition = "root { retry [1,5] { action [Work] } }";
                const original = createRun(definition, results, { random: () => 0 });
                const restored = createRun(definition, results, { random: () => 0.99 });

                original.tree.step();
                transfer(original, restored);

                assertSameFuture(original, restored, 1);
                assert.strictEqual(restored.tree.getState(), State.FAILED);
            });

            it("(lotto child)", () => {
                const flags = { ready: false };
                const results = {
                    First: () => (flags.ready ? State.SUCCEEDED : State.RUNNING),
                    Second: () => (flags.ready ? State.SUCCEEDED : State.RUNNING)
                };
                const definition = "root { lotto { action [First] action [Second] } }";

                // A random value of 0 picks the first child, 0.99 picks the second.
                const control = createRun(definition, results, { random: () => 0.99 });
                control.tree.step();
                assert.deepEqual(control.calls, ["Second"]);

                const original = createRun(definition, results, { random: () => 0 });
                const restored = createRun(definition, results, { random: () => 0.99 });

                original.tree.step();
                transfer(original, restored);
                flags.ready = true;

                assertSameFuture(original, restored, 1);
                assert.deepEqual(restored.calls, ["First"]);
                assert.strictEqual(restored.tree.getState(), State.SUCCEEDED);
            });

            describe("(wait duration)", () => {
                let clock: SinonFakeTimers;

                beforeEach(() => {
                    clock = sinon.useFakeTimers();
                });

                afterEach(() => {
                    clock.restore();
                });

                it("using the clock", () => {
                    const definition = "root { wait [1000,5000] }";
                    // A random value of 0 picks the minimum of 1000ms, 0.99 would pick 4960ms.
                    const original = createRun(definition, {}, { random: () => 0 });
                    const restored = createRun(definition, {}, { random: () => 0.99 });

                    original.tree.step();
                    clock.tick(500);
                    transfer(original, restored);

                    clock.tick(499);
                    restored.tree.step();
                    assert.strictEqual(restored.tree.getState(), State.RUNNING);

                    clock.tick(1);
                    restored.tree.step();
                    assert.strictEqual(restored.tree.getState(), State.SUCCEEDED);
                });

                it("using getDeltaTime", () => {
                    const definition = "root { wait [1000,5000] }";
                    const original = createRun(definition, {}, { random: () => 0, getDeltaTime: () => 0.5 });
                    const restored = createRun(definition, {}, { random: () => 0.99, getDeltaTime: () => 0.25 });

                    original.tree.step();
                    transfer(original, restored);

                    // 500ms were waited before the snapshot, 250ms more after the first step and 250ms more after the second.
                    restored.tree.step();
                    assert.strictEqual(restored.tree.getState(), State.RUNNING);
                    restored.tree.step();
                    assert.strictEqual(restored.tree.getState(), State.SUCCEEDED);
                });
            });
        });

        describe("makes a wait node wait only for the remaining time", () => {
            let clock: SinonFakeTimers;

            beforeEach(() => {
                clock = sinon.useFakeTimers();
            });

            afterEach(() => {
                clock.restore();
            });

            it("when using the clock, counting the time up to the snapshot but not the time after it", () => {
                const definition = "root { wait [1000] }";
                const original = createRun(definition, {});
                const restored = createRun(definition, {});

                original.tree.step();

                // The snapshot is taken 400ms after the last step, which counts as waited time.
                clock.tick(400);
                const snapshot = roundTrip(original.tree.snapshot());

                // The process is down for an hour.
                clock.tick(60 * 60 * 1000);
                restored.tree.restore(snapshot);

                restored.tree.step();
                assert.strictEqual(restored.tree.getState(), State.RUNNING);

                clock.tick(599);
                restored.tree.step();
                assert.strictEqual(restored.tree.getState(), State.RUNNING);

                clock.tick(1);
                restored.tree.step();
                assert.strictEqual(restored.tree.getState(), State.SUCCEEDED);
            });

            it("when using getDeltaTime, ignoring the clock", () => {
                const definition = "root { wait [1000] }";
                const original = createRun(definition, {}, { getDeltaTime: () => 0.4 });
                const restored = createRun(definition, {}, { getDeltaTime: () => 0.3 });

                original.tree.step();
                const snapshot = roundTrip(original.tree.snapshot());

                clock.tick(60 * 60 * 1000);
                restored.tree.restore(snapshot);

                // 400ms were waited before the snapshot, so 700ms after this step and 1000ms after the next one.
                restored.tree.step();
                assert.strictEqual(restored.tree.getState(), State.RUNNING);

                restored.tree.step();
                assert.strictEqual(restored.tree.getState(), State.SUCCEEDED);
            });

            it("when the wait has no duration and waits until it is aborted", () => {
                const definition = "root { wait }";
                const original = createRun(definition, {});
                const restored = createRun(definition, {});

                original.tree.step();
                clock.tick(1000);
                transfer(original, restored);

                clock.tick(1000000);
                assertSameFuture(original, restored, 1);
                assert.strictEqual(restored.tree.getState(), State.RUNNING);
            });
        });

        describe("restores a snapshot of a finished tree as finished", () => {
            it("so that the next step starts a new run with new random choices", () => {
                const results = { Work: () => State.SUCCEEDED };
                const definition = "root { repeat [1,3] { action [Work] } }";
                // A random value of 0 picks one iteration, 0.99 picks three.
                const original = createRun(definition, results, { random: () => 0 });
                const restored = createRun(definition, results, { random: () => 0.99 });

                original.tree.step();
                original.tree.step();
                assert.strictEqual(original.tree.getState(), State.SUCCEEDED);

                transfer(original, restored);
                assert.strictEqual(restored.tree.getState(), State.SUCCEEDED);
                assert.deepEqual(restored.calls, []);

                for (let step = 1; step <= 3; step++) {
                    restored.tree.step();
                    assert.strictEqual(restored.tree.getState(), State.RUNNING, `state after step ${step}`);
                }

                restored.tree.step();
                assert.strictEqual(restored.tree.getState(), State.SUCCEEDED);
                assert.deepEqual(restored.calls, ["Work", "Work", "Work"]);
            });
        });

        describe("handles action nodes that use promises", () => {
            const tick = () => new Promise((resolve) => setImmediate(resolve));

            it("by keeping a result that settled but was not yet used by a step", async () => {
                const definition = "root { action [Work] }";
                const original = createRun(definition, { Work: () => Promise.resolve(State.SUCCEEDED) });
                const restored = createRun(definition, { Work: () => Promise.resolve(State.FAILED) });

                original.tree.step();
                await tick();
                transfer(original, restored);

                restored.tree.step();

                assert.strictEqual(restored.tree.getState(), State.SUCCEEDED);
                assert.deepEqual(restored.calls, []);
            });

            it("by keeping a rejection that was not yet used by a step", async () => {
                const definition = "root { action [Work] }";
                const original = createRun(definition, { Work: () => Promise.reject("boom") });
                const restored = createRun(definition, { Work: () => Promise.resolve(State.SUCCEEDED) });

                original.tree.step();
                await tick();
                transfer(original, restored);

                assert.throws(() => restored.tree.step(), Error, "promise rejected with 'boom'");
                assert.deepEqual(restored.calls, []);
            });

            it("so that a promise started before the restore cannot change the restored state", async () => {
                const definition = "root { action [Work] }";
                const original = createRun(definition, { Work: () => Promise.resolve(State.SUCCEEDED) });
                let resolveStalePromise: (state: State) => void = () => {};
                const restored = createRun(definition, {
                    Work: () => new Promise((resolve) => (resolveStalePromise = resolve))
                });

                original.tree.step();
                restored.tree.step();
                await tick();

                transfer(original, restored);
                resolveStalePromise(State.FAILED);
                await tick();

                restored.tree.step();
                assert.strictEqual(restored.tree.getState(), State.SUCCEEDED);
            });
        });

        describe("accepts a snapshot of the equivalent definition in the other format", () => {
            const results = {
                Alive: () => true,
                OnEntry: () => undefined,
                Done: () => State.SUCCEEDED,
                Check: () => true,
                Stop: () => false
            };
            const mdsl = `
                root {
                    sequence while(Alive, 1) entry(OnEntry) {
                        action [Done, "a", 2, true, null]
                        repeat [2] { action [Done] }
                        wait [100, 200]
                        selector { condition [Check] action [Done] until(Stop) }
                        branch [Sub]
                    }
                }
                root [Sub] { action [Done] }
            `;
            // The JSON definition leaves out the empty arguments and the 'succeedOnAbort' value that MDSL always includes.
            const json: RootNodeDefinition[] = [
                {
                    type: "root",
                    id: "Sub",
                    child: { type: "action", call: "Done" }
                },
                {
                    type: "root",
                    child: {
                        type: "sequence",
                        while: { call: "Alive", args: [1] },
                        entry: { call: "OnEntry" },
                        children: [
                            { type: "action", call: "Done", args: ["a", 2, true, null] },
                            { type: "repeat", iterations: 2, child: { type: "action", call: "Done" } },
                            { type: "wait", duration: [100, 200] },
                            {
                                type: "selector",
                                children: [
                                    { type: "condition", call: "Check" },
                                    { type: "action", call: "Done", until: { call: "Stop" } }
                                ]
                            },
                            { type: "branch", ref: "Sub" }
                        ]
                    }
                }
            ];

            it("when an MDSL snapshot is restored to a JSON tree", () => {
                const original = createRun(mdsl, results);
                const restored = createRun(json, results);

                original.tree.step();
                transfer(original, restored);

                assertSameFuture(original, restored, 1);
            });

            it("when a JSON snapshot is restored to an MDSL tree", () => {
                const original = createRun(json, results);
                const restored = createRun(mdsl, results);

                original.tree.step();
                transfer(original, restored);

                assertSameFuture(original, restored, 1);
            });
        });

        describe("restores an action that was waiting on a promise that had not settled as not started", () => {
            const definition = "root { sequence { action [Done] action [Work] entry(OnEntry) } }";
            const createOriginal = () =>
                createRun(definition, {
                    Done: () => State.SUCCEEDED,
                    Work: () => new Promise(() => {}),
                    OnEntry: () => undefined
                });

            it("so that its action function is called again on the next step", async () => {
                const original = createOriginal();
                const restored = createRun(definition, {
                    Done: () => State.SUCCEEDED,
                    Work: () => State.SUCCEEDED,
                    OnEntry: () => undefined
                });

                original.tree.step();
                restored.tree.restore(roundTrip(original.tree.snapshot()));

                assert.deepEqual(
                    withoutIds(restored.tree.getTreeNodeDetails()).children[0].children.map(
                        ({ state }: NodeDetails) => state
                    ),
                    [State.SUCCEEDED, State.READY]
                );

                restored.tree.step();

                // The finished action is not called again, and the pending action is started again.
                assert.deepEqual(restored.calls, ["OnEntry", "Work"]);
                assert.strictEqual(restored.tree.getState(), State.SUCCEEDED);
            });

            it("so that it starts a new promise that the restored tree waits on", async () => {
                const original = createOriginal();
                let workCalls = 0;
                const restored = createRun(definition, {
                    Done: () => State.SUCCEEDED,
                    Work: () => {
                        workCalls++;
                        return Promise.resolve(State.FAILED);
                    },
                    OnEntry: () => undefined
                });

                original.tree.step();
                restored.tree.restore(roundTrip(original.tree.snapshot()));

                restored.tree.step();
                assert.strictEqual(restored.tree.getState(), State.RUNNING);

                await new Promise((resolve) => setImmediate(resolve));

                restored.tree.step();
                assert.strictEqual(workCalls, 1);
                assert.strictEqual(restored.tree.getState(), State.FAILED);
            });
        });

        describe("will error and leave the tree unchanged if", () => {
            const definition = "root { sequence { action [Done] wait [100] } }";
            const results = { Done: () => State.SUCCEEDED };

            const createSnapshot = (): BehaviourTreeSnapshot => {
                const { tree } = createRun(definition, results);
                tree.step();
                return roundTrip(tree.snapshot());
            };

            const assertRejected = (snapshot: any, message: string) => {
                const { tree } = createRun(definition, results);
                const before = withoutIds(tree.getTreeNodeDetails());
                const snapshotBefore = tree.snapshot();

                assert.throws(() => tree.restore(snapshot), Error, message);
                assert.deepEqual(withoutIds(tree.getTreeNodeDetails()), before);
                assert.deepEqual(tree.snapshot(), snapshotBefore);
            };

            it("the snapshot is not an object", () => {
                assertRejected(null, "invalid snapshot");
                assertRejected(undefined, "invalid snapshot");
                assertRejected("snapshot", "invalid snapshot");
                assertRejected(42, "invalid snapshot");
                assertRejected(true, "invalid snapshot");
            });

            it("the snapshot is an array", () => {
                assertRejected([], "invalid snapshot");
                assertRejected([createSnapshot()], "invalid snapshot");
            });

            it("the snapshot is an object without the fields of a snapshot", () => {
                const { definition, root } = createSnapshot();

                assertRejected({}, "invalid snapshot");
                assertRejected({ foo: "bar" }, "invalid snapshot");
                assertRejected({ version: 1, root }, "invalid snapshot");
                assertRejected({ version: 1, definition }, "invalid snapshot");
                assertRejected({ definition, root }, "invalid snapshot");
                assertRejected({ version: 1, definition: 1, root }, "invalid snapshot");
            });

            it("the snapshot version is not supported", () => {
                assertRejected({ ...createSnapshot(), version: 2 }, "unsupported snapshot version");
            });

            it("the snapshot is missing its root node", () => {
                assertRejected({ version: 1 }, "invalid snapshot");
            });

            it("the snapshot was taken from a tree with a different definition", () => {
                const other = createRun("root { sequence { action [Other] wait [100] } }", {
                    Other: () => State.RUNNING
                });
                other.tree.step();

                assertRejected(roundTrip(other.tree.snapshot()), "does not match the tree's definition");
            });

            it("the snapshot was taken from a tree with a definition that has the same nodes but other details", () => {
                for (const otherDefinition of [
                    "root { sequence { action [Done, 1] wait [100] } }",
                    "root { sequence { action [Done] wait [200] } }",
                    "root { sequence { action [Done] until(NotDone) wait [100] } }",
                    "root { selector { action [Done] wait [100] } }",
                    "root { sequence entry(Done) { action [Done] wait [100] } }"
                ]) {
                    const other = createRun(otherDefinition, { ...results, NotDone: () => false });
                    other.tree.step();

                    assertRejected(roundTrip(other.tree.snapshot()), "does not match the tree's definition");
                }
            });

            it("a node has a different number of children", () => {
                const snapshot = createSnapshot();
                snapshot.root.children![0].children!.pop();

                assertRejected(snapshot, "child");
            });

            it("a node has an unknown state", () => {
                const snapshot = createSnapshot();
                snapshot.root.children![0].children![1].state = "mistreevous.unknown" as any;

                assertRejected(snapshot, "state");
            });

            it("a wait node has an invalid duration, after other nodes in the snapshot are valid", () => {
                const snapshot = createSnapshot();
                snapshot.root.children![0].children![1].totalDuration = "100" as any;

                assertRejected(snapshot, "duration");
            });
        });

        it("cannot be called during a step", () => {
            const tree: BehaviourTree = new BehaviourTree("root { action [Restore] }", {
                Restore: () => {
                    tree.restore(snapshot);
                }
            });
            const snapshot = tree.snapshot();

            assert.throws(() => tree.step(), Error, "cannot restore a snapshot while the tree is being stepped");
        });
    });

    describe("a snapshot is independent of the tree", () => {
        const timeModes: [string, BehaviourTreeOptions][] = [
            ["using the clock", {}],
            ["using getDeltaTime", { getDeltaTime: () => 0.06 }]
        ];

        const definition = `root {
            parallel {
                lotto { action [Running] action [Running] }
                repeat [1,3] {
                    retry [2,4] {
                        sequence {
                            condition [IsTrue]
                            wait [100,200]
                            action [Failing]
                        }
                    }
                }
                parallel { action [Running] race { action [Failing] all { action [Running] } } }
                flip { selector { action [Failing] succeed { action [Running] } fail { action [Running] } } }
                parallel { action [Settled] action [Pending] }
            }
        }`;

        const tick = () => new Promise((resolve) => setImmediate(resolve));

        let clock: SinonFakeTimers;

        beforeEach(() => {
            clock = sinon.useFakeTimers({ toFake: ["Date"] });
        });

        afterEach(() => {
            clock.restore();
        });

        const createTree = (options: BehaviourTreeOptions): BehaviourTree =>
            createRun(
                definition,
                {
                    Running: () => State.RUNNING,
                    Failing: () => State.FAILED,
                    IsTrue: () => true,
                    Settled: () => Promise.resolve(State.SUCCEEDED),
                    Pending: () => new Promise(() => {})
                },
                { random: () => 0.5, ...options }
            ).tree;

        /** Steps the tree and lets time pass and promises settle. */
        const stepAndSettle = async (tree: BehaviourTree) => {
            tree.step();
            clock.tick(60);
            await tick();
        };

        for (const [timeMode, options] of timeModes) {
            describe(timeMode, () => {
                it("so that stepping the tree it was taken from does not change it", async () => {
                    const tree = createTree(options);

                    for (let step = 1; step <= 6; step++) {
                        const snapshot = tree.snapshot();
                        const expected = roundTrip(snapshot);

                        await stepAndSettle(tree);

                        assert.deepEqual(roundTrip(snapshot), expected, `changed by step ${step}`);
                    }
                });

                it("so that stepping a tree it was restored to does not change it", async () => {
                    const original = createTree(options);

                    for (let step = 1; step <= 6; step++) {
                        const snapshot = original.snapshot();
                        const expected = roundTrip(snapshot);
                        const restored = createTree(options);

                        restored.restore(snapshot);

                        for (let restoredStep = 1; restoredStep <= 3; restoredStep++) {
                            await stepAndSettle(restored);

                            assert.deepEqual(
                                roundTrip(snapshot),
                                expected,
                                `snapshot from step ${step} changed by step ${restoredStep} of the restored tree`
                            );
                        }

                        await stepAndSettle(original);
                    }
                });

                it("so that a snapshot taken right after restoring it is equal to it", async () => {
                    const original = createTree(options);

                    for (let step = 1; step <= 6; step++) {
                        const snapshot = original.snapshot();
                        const restored = createTree(options);

                        restored.restore(snapshot);

                        assert.deepEqual(
                            roundTrip(restored.snapshot()),
                            roundTrip(snapshot),
                            `snapshot from step ${step}`
                        );

                        await stepAndSettle(original);
                    }
                });
            });
        }
    });
});
