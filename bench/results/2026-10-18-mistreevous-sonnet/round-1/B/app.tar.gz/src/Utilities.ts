/**
 * Create a randomly generated node uid.
 * @returns A randomly generated node uid.
 */
export function createUid(): string {
    const S4 = function () {
        return (((1 + Math.random()) * 0x10000) | 0).toString(16).substring(1);
    };
    return S4() + S4() + "-" + S4() + "-" + S4() + "-" + S4() + "-" + S4() + S4() + S4();
}

/**
 * Gets whether a value is a non-negative integer.
 * @param value The value to check.
 * @returns Whether the value is a non-negative integer.
 */
export function isCount(value: unknown): boolean {
    return Number.isInteger(value) && (value as number) >= 0;
}

/**
 * Creates an identifier for a tree definition, which is the same for any definition with the same content regardless of the order of its properties.
 * It is a 53 bit hash (cyrb53), so definitions that differ are not guaranteed to have different identifiers but a collision is very unlikely.
 * @param definition The tree definition as JSON.
 * @returns The identifier.
 */
export function createDefinitionId(definition: unknown): string {
    const content = JSON.stringify(definition, (_key, value) =>
        value && typeof value === "object" && !Array.isArray(value)
            ? Object.fromEntries(Object.entries(value).sort(([a], [b]) => (a < b ? -1 : 1)))
            : value
    );

    let h1 = 0xdeadbeef;
    let h2 = 0x41c6ce57;

    for (let i = 0; i < content.length; i++) {
        h1 = Math.imul(h1 ^ content.charCodeAt(i), 2654435761);
        h2 = Math.imul(h2 ^ content.charCodeAt(i), 1597334677);
    }

    h1 = Math.imul(h1 ^ (h1 >>> 16), 2246822507) ^ Math.imul(h2 ^ (h2 >>> 13), 3266489909);
    h2 = Math.imul(h2 ^ (h2 >>> 16), 2246822507) ^ Math.imul(h1 ^ (h1 >>> 13), 3266489909);

    return (4294967296 * (2097151 & h2) + (h1 >>> 0)).toString(16);
}
