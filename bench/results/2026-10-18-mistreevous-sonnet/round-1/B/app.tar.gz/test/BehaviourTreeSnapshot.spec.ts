import { assert } from "chai";
import sinon, { SinonFakeTimers } from "sinon";

import { BehaviourTree, BehaviourTreeSnapshot, NodeDetails, State } from "../src/index";

/**
 * A repeating sequence of pseudo-random numbers that can be cloned part way through.
 */
class Randoms {
    private values: number[];
    private index: number;

    constructor(values: number[], index = 0) {
        this.values = values;
        this.index = index;
    }

    next = () => this.values[this.index++ % this.values.length];

    clone = () => new Randoms(this.values, this.index);
}

/**
 * Creates an agent where each scripted function logs its name when called and returns the next scripted value (the last one repeating).
 */
function createAgent(scripts: Record<string, any[]>) {
    const log: string[] = [];
    const remaining: Record<string, any[]> = structuredClone(scripts);
    const agent: any = {};

    Object.keys(remaining).forEach((name) => {
        agent[name] = () => {
            log.push(name);
            return remaining[name].length > 1 ? remaining[name].shift() : remaining[name][0];
        };
    });

    return { agent, log, remaining };
}

/**
 * Gets the node details without the ids, which are different for every tree instance.
 */
function withoutIds({ id, children, ...details }: NodeDetails): any {
    return { ...details, children: children?.map(withoutIds) };
}

type Scenario = {
    name: string;
    definition: string;
    scripts: Record<string, any[]>;
    steps: number;
    random?: number[];
    deltaTime?: number;
};

/**
 * For every step at which a tree could be snapshotted, check that restoring the snapshot to a new tree gives a tree that
 * has the same node states and, from then on, calls the same agent functions in the same order and has the same results.
 */
function assertRestoredTreeBehavesLikeOriginal({ definition, scripts, steps, random, deltaTime }: Scenario) {
    for (let stepsBeforeSnapshot = 0; stepsBeforeSnapshot <= steps; stepsBeforeSnapshot++) {
        const original = createAgent(scripts);
        const originalRandoms = new Randoms(random ?? [0.5]);
        const options = (randoms: Randoms) => ({
            random: randoms.next,
            ...(deltaTime === undefined ? {} : { getDeltaTime: () => deltaTime })
        });
        const originalTree = new BehaviourTree(definition, original.agent, options(originalRandoms));

        for (let step = 0; step < stepsBeforeSnapshot; step++) {
            originalTree.step();
        }

        const snapshot = JSON.parse(JSON.stringify(originalTree.snapshot()));

        const restored = createAgent(original.remaining);
        const restoredTree = new BehaviourTree(definition, restored.agent, options(originalRandoms.clone()));
        restoredTree.restore(snapshot);

        original.log.length = 0;

        const context = `after ${stepsBeforeSnapshot} steps`;
        assert.deepEqual(
            withoutIds(restoredTree.getTreeNodeDetails()),
            withoutIds(originalTree.getTreeNodeDetails()),
            context
        );

        for (let step = 0; step < steps; step++) {
            originalTree.step();
            restoredTree.step();

            const stepContext = `${context} and then ${step + 1} more`;
            assert.deepEqual(restored.log, original.log, stepContext);
            assert.deepEqual(
                withoutIds(restoredTree.getTreeNodeDetails()),
                withoutIds(originalTree.getTreeNodeDetails()),
                stepContext
            );
            assert.equal(restoredTree.getState(), originalTree.getState(), stepContext);
        }
    }
}

describe("A behaviour tree", () => {
    describe("snapshot", () => {
        it("is a plain object that is unchanged by a round trip through JSON", () => {
            const { agent } = createAgent({ A: [State.RUNNING], B: [State.SUCCEEDED], C: [true] });
            const tree = new BehaviourTree(
                "root { sequence { condition [C] repeat [3] { action [B] } parallel { action [A] wait [1000] } } }",
                agent
            );

            tree.step();

            const snapshot: BehaviourTreeSnapshot = tree.snapshot();

            assert.deepEqual(JSON.parse(JSON.stringify(snapshot)), snapshot);
        });

        it("is not changed by later steps of the tree", () => {
            const { agent } = createAgent({ A: [State.RUNNING, State.SUCCEEDED] });
            const tree = new BehaviourTree("root { action [A] }", agent);

            tree.step();

            const snapshot = tree.snapshot();
            const before = JSON.stringify(snapshot);

            tree.step();

            assert.equal(JSON.stringify(snapshot), before);
        });

        it("can be restored to a tree that was built from the same definition", () => {
            const definition = "root { sequence { action [A] action [B] } }";
            const { agent } = createAgent({ A: [State.RUNNING, State.SUCCEEDED], B: [State.RUNNING] });
            const tree = new BehaviourTree(definition, agent);

            tree.step();
            tree.step();

            const restored = new BehaviourTree(definition, createAgent({ A: [], B: [State.RUNNING] }).agent);
            restored.restore(JSON.parse(JSON.stringify(tree.snapshot())));

            assert.deepEqual(withoutIds(restored.getTreeNodeDetails()), withoutIds(tree.getTreeNodeDetails()));
            assert.isTrue(restored.isRunning());
        });

        it("restores over the existing state of the tree it is restored to", () => {
            const definition = "root { sequence { action [A] action [B] } }";
            const { agent } = createAgent({ A: [State.SUCCEEDED], B: [State.RUNNING] });
            const tree = new BehaviourTree(definition, agent);
            const freshSnapshot = tree.snapshot();

            tree.step();
            tree.restore(freshSnapshot);

            assert.equal(tree.getState(), State.READY);
            assert.deepEqual(
                withoutIds(tree.getTreeNodeDetails()),
                withoutIds(new BehaviourTree(definition, agent).getTreeNodeDetails())
            );
        });

        it("restores without calling any agent function or onNodeStateChange", () => {
            const definition = "root { sequence entry(E) exit(X) { action [A] } }";
            const { agent, log } = createAgent({ A: [State.RUNNING], E: [undefined], X: [undefined] });
            const tree = new BehaviourTree(definition, agent);

            tree.step();

            const snapshot = tree.snapshot();
            const changes: string[] = [];
            const restored = new BehaviourTree(definition, agent, {
                onNodeStateChange: ({ type }) => changes.push(type)
            });

            log.length = 0;
            restored.restore(snapshot);
            tree.restore(new BehaviourTree(definition, agent).snapshot());

            assert.deepEqual(log, []);
            assert.deepEqual(changes, []);
        });

        it("restores over a tree that has been stepped without calling onNodeStateChange, which then reports changes as usual when stepped", () => {
            const definition = "root { sequence { action [A] action [B] } }";
            const { agent } = createAgent({ A: [State.SUCCEEDED], B: [State.RUNNING] });
            const changes: string[] = [];
            const tree = new BehaviourTree(definition, agent, {
                onNodeStateChange: ({ type, previousState, state }) => changes.push(`${type} ${previousState} ${state}`)
            });
            const freshSnapshot = tree.snapshot();

            tree.step();

            const runningSnapshot = tree.snapshot();

            changes.length = 0;
            tree.restore(freshSnapshot);
            tree.restore(runningSnapshot);
            tree.restore(freshSnapshot);

            assert.deepEqual(changes, []);

            tree.step();

            assert.deepEqual(changes, [
                `action ${State.READY} ${State.SUCCEEDED}`,
                `action ${State.READY} ${State.RUNNING}`,
                `sequence ${State.READY} ${State.RUNNING}`,
                `root ${State.READY} ${State.RUNNING}`
            ]);
        });

        describe("is independent of the trees it is taken from and restored to", () => {
            const definition =
                "root { sequence { repeat [2] { action [A] } lotto { action [B] action [B] } wait [500, 1000] } }";
            const createTree = () =>
                new BehaviourTree(definition, createAgent({ A: [State.SUCCEEDED], B: [State.RUNNING] }).agent, {
                    random: () => 0.5,
                    getDeltaTime: () => 0.1
                });

            it("so stepping the tree it was taken from does not change it", () => {
                const tree = createTree();

                tree.step();
                tree.step();

                const snapshot = tree.snapshot();
                const before = JSON.stringify(snapshot);

                tree.step();
                tree.step();

                assert.equal(JSON.stringify(snapshot), before);
            });

            it("so stepping the tree it was restored to does not change it", () => {
                const tree = createTree();

                tree.step();
                tree.step();

                const snapshot = tree.snapshot();
                const before = JSON.stringify(snapshot);
                const restored = createTree();

                restored.restore(snapshot);
                restored.step();
                restored.step();

                assert.equal(JSON.stringify(snapshot), before);
            });

            it("so a snapshot taken right after restoring it is equal to it", () => {
                const tree = createTree();

                for (let steps = 0; steps < 5; steps++) {
                    const snapshot = JSON.parse(JSON.stringify(tree.snapshot()));
                    const restored = createTree();

                    restored.restore(snapshot);

                    assert.deepEqual(JSON.parse(JSON.stringify(restored.snapshot())), snapshot, `after ${steps} steps`);

                    tree.step();
                }
            });
        });

        describe("records the definition it belongs to", () => {
            const { agent } = createAgent({ A: [State.RUNNING], B: [State.RUNNING] });

            it("which is a string that is the same for any tree built from the same definition", () => {
                const definition = "root { sequence { action [A] action [B] } }";
                const tree = new BehaviourTree(definition, agent);
                const { definition: id } = tree.snapshot();

                tree.step();

                assert.isString(id);
                assert.equal(tree.snapshot().definition, id);
                assert.equal(new BehaviourTree(definition, agent).snapshot().definition, id);
            });

            it("so that a snapshot of another definition is rejected when restored", () => {
                const other = new BehaviourTree("root { sequence { action [A] action [C] } }", agent);

                assert.throws(
                    () =>
                        new BehaviourTree("root { sequence { action [A] action [B] } }", agent).restore(
                            other.snapshot()
                        ),
                    Error,
                    "error restoring tree: snapshot does not match the tree's definition"
                );
            });

            it("so that a snapshot of a definition that only differs by node arguments is rejected, leaving the tree as it was", () => {
                const first = new BehaviourTree("root { action [A, 1] }", agent);
                const second = new BehaviourTree("root { action [A, 2] }", agent);

                first.step();

                const before = first.snapshot();

                assert.throws(
                    () => first.restore(second.snapshot()),
                    Error,
                    "snapshot does not match the tree's definition"
                );
                assert.deepEqual(first.snapshot(), before);
            });

            it("which is the same for an MDSL definition and its equivalent JSON definition", () => {
                const mdsl = new BehaviourTree(
                    'root { sequence { action [A, 1, "x"] repeat [2] { wait [100] } } }',
                    agent
                );
                const json = new BehaviourTree(
                    {
                        type: "root",
                        child: {
                            type: "sequence",
                            children: [
                                { call: "A", type: "action", args: [1, "x"] },
                                { type: "repeat", iterations: 2, child: { duration: 100, type: "wait" } }
                            ]
                        }
                    },
                    agent
                );

                mdsl.step();
                json.restore(mdsl.snapshot());

                assert.deepEqual(json.snapshot(), mdsl.snapshot());
            });

            it("which is the same for a root node definition and an array of root node definitions", () => {
                const root = { type: "root", child: { type: "action", call: "A" } } as const;

                assert.equal(
                    new BehaviourTree(root, agent).snapshot().definition,
                    new BehaviourTree([root], agent).snapshot().definition
                );
            });
        });

        describe("throws an error when restored if", () => {
            const definition = "root { sequence { action [A] action [B] } }";
            const { agent } = createAgent({ A: [State.RUNNING], B: [State.RUNNING] });
            const validSnapshot = () => {
                const tree = new BehaviourTree(definition, agent);
                tree.step();
                return JSON.parse(JSON.stringify(tree.snapshot()));
            };

            const cases: [string, (snapshot: any) => any, string][] = [
                ["it is not an object", () => "snapshot", "error restoring tree: snapshot must be an object"],
                ["it is null", () => null, "error restoring tree: snapshot must be an object"],
                [
                    "a node type does not match the tree",
                    (s) => ((s.children[0].children[0].type = "condition"), s),
                    "error restoring tree: snapshot does not match tree at node 'A'"
                ],
                [
                    "a node name does not match the tree",
                    (s) => ((s.children[0].children[1].name = "Z"), s),
                    "error restoring tree: snapshot does not match tree at node 'B'"
                ],
                [
                    "a node state is not a valid state",
                    (s) => ((s.children[0].state = "mistreevous.nope"), s),
                    "error restoring tree: snapshot has an invalid state for node 'SEQUENCE'"
                ],
                [
                    "a node has the wrong number of children",
                    (s) => (s.children[0].children.pop(), s),
                    "error restoring tree: snapshot does not have the children of node 'SEQUENCE'"
                ],
                [
                    "a node has no children",
                    (s) => (delete s.children, s),
                    "error restoring tree: snapshot does not have the children of node 'ROOT'"
                ]
            ];

            cases.forEach(([description, corrupt, message]) => {
                it(description, () => {
                    const tree = new BehaviourTree(definition, agent);

                    assert.throws(() => tree.restore(corrupt(validSnapshot())), Error, message);
                });
            });

            it("it is not a snapshot at all", () => {
                const tree = new BehaviourTree(definition, agent);

                tree.step();

                const before = tree.snapshot();

                [undefined, null, "snapshot", 1, true, [], [validSnapshot()], {}, { state: State.READY }].forEach(
                    (notASnapshot) => {
                        assert.throws(() => tree.restore(notASnapshot as any), Error, "error restoring tree: ");
                        assert.deepEqual(tree.snapshot(), before);
                    }
                );
            });

            it("it has no valid definition", () => {
                const snapshot = validSnapshot();

                [undefined, null, 1, {}].forEach((invalid) => {
                    snapshot.definition = invalid;
                    assert.throws(
                        () => new BehaviourTree(definition, agent).restore(snapshot),
                        Error,
                        "error restoring tree: "
                    );
                });
            });

            it("and leaves the tree as it was", () => {
                const tree = new BehaviourTree(definition, agent);
                tree.step();
                const before = tree.snapshot();
                const corrupt = validSnapshot();

                // The first node is valid, it is the last one that is not.
                corrupt.children[0].children[1].name = "Z";

                assert.throws(() => tree.restore(corrupt));
                assert.deepEqual(tree.snapshot(), before);
            });
        });

        describe("restored to a tree gives a tree that behaves like the original for", () => {
            const R = State.RUNNING;
            const S = State.SUCCEEDED;
            const F = State.FAILED;

            const scenarios: Scenario[] = [
                {
                    name: "a sequence",
                    definition: "root { sequence { action [A] condition [C] action [B] } }",
                    scripts: { A: [R, R, S], C: [true], B: [undefined, S] },
                    steps: 6
                },
                {
                    name: "a selector",
                    definition: "root { selector { action [A] condition [C] action [B] } }",
                    scripts: { A: [R, F], C: [false], B: [R, R, S] },
                    steps: 7
                },
                {
                    name: "a parallel that fails",
                    definition: "root { parallel { action [A] action [B] action [C] } }",
                    scripts: { A: [R, R, S], B: [R, R, R, F], C: [R] },
                    steps: 6
                },
                {
                    name: "a parallel that succeeds",
                    definition: "root { parallel { action [A] action [B] } }",
                    scripts: { A: [R, S], B: [R, R, S] },
                    steps: 5
                },
                {
                    name: "a race",
                    definition: "root { race { action [A] action [B] action [C] } }",
                    scripts: { A: [R, R, R, S], B: [R, F], C: [R] },
                    steps: 6
                },
                {
                    name: "an all",
                    definition: "root { all { action [A] action [B] action [C] } }",
                    scripts: { A: [R, R, S], B: [R, F], C: [R, R, R, S] },
                    steps: 7
                },
                {
                    name: "flip, succeed and fail decorators",
                    definition:
                        "root { sequence { flip { action [A] } succeed { action [B] } fail { action [C] } action [D] } }",
                    scripts: { A: [R, F], B: [R, F], C: [R, S], D: [S] },
                    steps: 8
                },
                {
                    name: "entry, step and exit callbacks",
                    definition:
                        "root { sequence entry(E1) step(S1) exit(X1) { action [A] entry(E2) step(S2) exit(X2) } }",
                    scripts: { A: [R, R, S], E1: [], E2: [], S1: [], S2: [], X1: [], X2: [] },
                    steps: 5
                },
                {
                    name: "guards that abort running nodes",
                    definition:
                        "root { sequence { sequence while(G) exit(X) { action [A] action [B] } sequence until(U) { action [C] } } }",
                    scripts: {
                        A: [R, R, S],
                        B: [R],
                        C: [R],
                        G: [true, true, true, false],
                        U: [false, false, true],
                        X: []
                    },
                    steps: 8
                },
                {
                    name: "a repeat with a fixed number of iterations",
                    definition: "root { repeat [3] { action [A] } }",
                    scripts: { A: [R, S, S, R, S] },
                    steps: 8
                },
                {
                    name: "a repeat with a random number of iterations",
                    definition: "root { sequence { repeat [2, 5] { action [A] } repeat [2, 5] { action [B] } } }",
                    scripts: { A: [S], B: [S] },
                    random: [0.9, 0.1],
                    steps: 12
                },
                {
                    name: "a repeat that never stops",
                    definition: "root { repeat { sequence { action [A] action [B] } } }",
                    scripts: { A: [S], B: [R, S] },
                    steps: 8
                },
                {
                    name: "a retry with a fixed number of attempts",
                    definition: "root { retry [3] { action [A] } }",
                    scripts: { A: [R, F, F, R, F] },
                    steps: 8
                },
                {
                    name: "a retry with a random number of attempts",
                    definition: "root { sequence { retry [2, 5] { action [A] } retry [2, 5] { action [B] } } }",
                    scripts: { A: [F], B: [F] },
                    random: [0.9, 0.1],
                    steps: 12
                },
                {
                    name: "nested repeats and retries",
                    definition: "root { repeat [2] { retry [2] { sequence { action [A] action [B] } } } }",
                    scripts: { A: [S, R, S], B: [F, S, R, S] },
                    steps: 12
                },
                {
                    name: "a lotto that picks a different child each time",
                    definition: "root { repeat [4] { lotto [1, 2, 3] { action [A] action [B] action [C] } } }",
                    scripts: { A: [R, S], B: [R, R, S], C: [S] },
                    random: [0.9, 0.1, 0.4, 0.7],
                    steps: 14
                },
                {
                    name: "a wait with a fixed duration",
                    definition: "root { sequence { action [A] wait [1000] action [B] } }",
                    scripts: { A: [S], B: [S] },
                    deltaTime: 0.3,
                    steps: 7
                },
                {
                    name: "waits with a random duration",
                    definition: "root { repeat [3] { wait [500, 1500] } }",
                    scripts: {},
                    random: [0.9, 0.1, 0.5],
                    deltaTime: 0.4,
                    steps: 12
                },
                {
                    name: "a wait that is aborted by a guard",
                    definition: "root { sequence { parallel { wait [5000] while(G) action [A] } wait [100] } }",
                    scripts: { A: [R], G: [true, true, false] },
                    deltaTime: 0.1,
                    steps: 8
                }
            ];

            scenarios.forEach((scenario) => {
                it(scenario.name, () => assertRestoredTreeBehavesLikeOriginal(scenario));
            });
        });

        describe("of a wait node", () => {
            let clock: SinonFakeTimers;

            beforeEach(() => {
                clock = sinon.useFakeTimers();
            });

            afterEach(() => {
                clock.restore();
            });

            it("restores a wait that only waits for the remaining time, not counting the time since the snapshot (Date)", () => {
                const tree = new BehaviourTree("root { wait [1000] }", {});

                tree.step();
                clock.tick(600);

                // There has been no step since 600ms passed, but they still count as time waited.
                const snapshot = JSON.parse(JSON.stringify(tree.snapshot()));

                clock.tick(3 * 24 * 60 * 60 * 1000);

                const restored = new BehaviourTree("root { wait [1000] }", {});
                restored.restore(snapshot);

                restored.step();
                assert.equal(restored.getState(), State.RUNNING);

                clock.tick(399);
                restored.step();
                assert.equal(restored.getState(), State.RUNNING);

                clock.tick(1);
                restored.step();
                assert.equal(restored.getState(), State.SUCCEEDED);
            });

            it("restores a wait that only waits for the remaining time, not counting the time since the snapshot (getDeltaTime)", () => {
                let deltaTime = 0.4;
                const definition = "root { wait [1000] }";
                const tree = new BehaviourTree(definition, {}, { getDeltaTime: () => deltaTime });

                tree.step();
                tree.step();

                const snapshot = JSON.parse(JSON.stringify(tree.snapshot()));

                clock.tick(3 * 24 * 60 * 60 * 1000);

                const restored = new BehaviourTree(definition, {}, { getDeltaTime: () => deltaTime });
                restored.restore(snapshot);

                deltaTime = 0.1;
                restored.step();
                assert.equal(restored.getState(), State.RUNNING);

                restored.step();
                assert.equal(restored.getState(), State.SUCCEEDED);
            });

            it("restores a wait that has already waited long enough but has not been stepped since", () => {
                const tree = new BehaviourTree("root { wait [1000] }", {});

                tree.step();
                clock.tick(1500);

                const restored = new BehaviourTree("root { wait [1000] }", {});
                restored.restore(tree.snapshot());
                restored.step();

                assert.equal(restored.getState(), State.SUCCEEDED);
            });
        });

        describe("of a tree that has finished", () => {
            it("restores a finished tree that starts a new run, with new random choices, on the next step", () => {
                const definition = "root { repeat [1, 5] { action [A] } }";
                const { agent } = createAgent({ A: [State.SUCCEEDED] });
                const tree = new BehaviourTree(definition, agent, { random: () => 0 });

                // A run of one iteration takes two steps.
                tree.step();
                tree.step();
                assert.equal(tree.getState(), State.SUCCEEDED);

                const restoredAgent = createAgent({ A: [State.SUCCEEDED] });
                const restored = new BehaviourTree(definition, restoredAgent.agent, { random: () => 0.99 });
                restored.restore(JSON.parse(JSON.stringify(tree.snapshot())));

                assert.equal(restored.getState(), State.SUCCEEDED);
                assert.deepEqual(restoredAgent.log, []);

                // A new run of five iterations takes six steps.
                for (let step = 0; step < 5; step++) {
                    restored.step();
                    assert.equal(restored.getState(), State.RUNNING);
                }

                restored.step();
                assert.equal(restored.getState(), State.SUCCEEDED);
                assert.equal(restoredAgent.log.length, 5);
            });
        });

        describe("of a promise-based action", () => {
            const definition = "root { sequence { action [A] action [B] } }";

            it("restores a promise that has not settled as not yet started, so the action is called again when stepped", () => {
                const tree = new BehaviourTree(definition, {
                    A: () => new Promise(() => {}),
                    B: () => State.SUCCEEDED
                });

                tree.step();

                const snapshot = JSON.parse(JSON.stringify(tree.snapshot()));
                const { agent, log } = createAgent({ A: [State.SUCCEEDED], B: [State.SUCCEEDED] });
                const restored = new BehaviourTree(definition, agent);

                restored.restore(snapshot);

                assert.deepEqual(log, []);

                restored.step();

                assert.deepEqual(log, ["A", "B"]);
                assert.equal(restored.getState(), State.SUCCEEDED);
            });

            it("restores a promise that has not settled to the tree it was taken from, which then calls the action again", async () => {
                let calls = 0;
                const tree = new BehaviourTree(definition, {
                    A: () => (++calls === 1 ? new Promise(() => {}) : Promise.resolve(State.SUCCEEDED)),
                    B: () => State.SUCCEEDED
                });

                tree.step();
                tree.restore(tree.snapshot());
                tree.step();
                await Promise.resolve();
                tree.step();

                assert.equal(calls, 2);
                assert.equal(tree.getState(), State.SUCCEEDED);
            });

            it("restores a resolved promise as its result, without calling the action again", async () => {
                const tree = new BehaviourTree(definition, {
                    A: () => Promise.resolve(State.SUCCEEDED),
                    B: () => State.SUCCEEDED
                });

                tree.step();
                await Promise.resolve();

                const snapshot = JSON.parse(JSON.stringify(tree.snapshot()));
                const { agent, log } = createAgent({ A: [State.FAILED], B: [State.SUCCEEDED] });
                const restored = new BehaviourTree(definition, agent);

                restored.restore(snapshot);
                restored.step();

                assert.deepEqual(log, ["B"]);
                assert.equal(restored.getState(), State.SUCCEEDED);
            });

            it("restores a rejected promise as an error when stepped", async () => {
                const tree = new BehaviourTree(definition, {
                    A: () => Promise.reject(new Error("boom")),
                    B: () => State.SUCCEEDED
                });

                tree.step();
                await new Promise((resolve) => setImmediate(resolve));

                const restored = new BehaviourTree(definition, createAgent({ A: [], B: [] }).agent);

                restored.restore(JSON.parse(JSON.stringify(tree.snapshot())));

                assert.throws(
                    () => restored.step(),
                    Error,
                    "error stepping tree: action function 'A' promise rejected with 'Error: boom'"
                );
            });

            it("restores a promise that resolved with an invalid value as an error when stepped", async () => {
                const tree = new BehaviourTree(definition, {
                    A: () => Promise.resolve({ not: "a state" }),
                    B: () => State.SUCCEEDED
                });

                tree.step();
                await Promise.resolve();

                const restored = new BehaviourTree(definition, createAgent({ A: [], B: [] }).agent);

                restored.restore(JSON.parse(JSON.stringify(tree.snapshot())));

                assert.throws(() => restored.step(), Error, "action node promise resolved with an invalid value");
            });
        });

        describe("throws an error when restored if a node has an invalid", () => {
            const cases: [string, string, (snapshot: any) => void, string][] = [
                [
                    "iteration count",
                    "root { repeat [3] { action [A] } }",
                    (s) => (s.children[0].currentIterationCount = -1),
                    "currentIterationCount"
                ],
                [
                    "target iteration count",
                    "root { repeat [3] { action [A] } }",
                    (s) => (s.children[0].targetIterationCount = "3"),
                    "targetIterationCount"
                ],
                [
                    "attempt count",
                    "root { retry [3] { action [A] } }",
                    (s) => (s.children[0].currentAttemptCount = 1.5),
                    "currentAttemptCount"
                ],
                [
                    "target attempt count",
                    "root { retry [3] { action [A] } }",
                    (s) => delete s.children[0].targetAttemptCount,
                    "targetAttemptCount"
                ],
                [
                    "selected child",
                    "root { lotto { action [A] action [B] } }",
                    (s) => (s.children[0].selectedChild = 2),
                    "selectedChild"
                ],
                [
                    "total duration",
                    "root { wait [1000] }",
                    (s) => (s.children[0].totalDuration = "1000"),
                    "totalDuration"
                ],
                [
                    "waited duration",
                    "root { wait [1000] }",
                    (s) => (s.children[0].waitedDuration = null),
                    "waitedDuration"
                ],
                [
                    "promise result",
                    "root { action [A] }",
                    (s) => (s.children[0].updatePromiseResult = { isResolved: "yes" }),
                    "updatePromiseResult"
                ]
            ];

            cases.forEach(([description, definition, corrupt, field]) => {
                it(description, () => {
                    const { agent } = createAgent({ A: [State.RUNNING], B: [State.RUNNING] });
                    const tree = new BehaviourTree(definition, agent);

                    tree.step();

                    const snapshot = JSON.parse(JSON.stringify(tree.snapshot()));

                    corrupt(snapshot);

                    assert.throws(
                        () => new BehaviourTree(definition, agent).restore(snapshot),
                        Error,
                        `error restoring tree: snapshot has an invalid '${field}' for node`
                    );
                });
            });
        });
    });
});
