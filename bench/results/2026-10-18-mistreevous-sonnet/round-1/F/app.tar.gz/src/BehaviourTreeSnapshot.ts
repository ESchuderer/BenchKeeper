import State, { AnyState } from "./State";

/**
 * The current version of the behaviour tree snapshot format.
 */
export const SNAPSHOT_VERSION = 1;

/**
 * A snapshot of the execution state of a node in a behaviour tree.
 */
export type NodeSnapshot = {
    /**
     * The tree node type.
     */
    type: string;
    /**
     * The state of the tree node.
     */
    state: AnyState;
    /**
     * The snapshots of the child nodes of this node, defined if this is a composite or decorator node.
     */
    children?: NodeSnapshot[];
    /**
     * The index of the child that was picked to be the active one, or null if none has been picked yet, defined if this is a lotto node.
     */
    selectedChildIndex?: number | null;
    /**
     * The number of iterations that were picked as the target, or null if there is no target, defined if this is a repeat node.
     */
    targetIterationCount?: number | null;
    /**
     * The number of iterations completed so far, defined if this is a repeat node.
     */
    currentIterationCount?: number;
    /**
     * The number of attempts that were picked as the target, or null if there is no target, defined if this is a retry node.
     */
    targetAttemptCount?: number | null;
    /**
     * The number of attempts made so far, defined if this is a retry node.
     */
    currentAttemptCount?: number;
    /**
     * The total duration in milliseconds that the node will wait for, or null if it will wait indefinitely, defined if this is a wait node.
     */
    totalDuration?: number | null;
    /**
     * The duration in milliseconds that the node has waited for so far, defined if this is a wait node.
     */
    waitedDuration?: number;
};

/**
 * A snapshot of the execution state of a behaviour tree, which can be serialised to JSON and used to restore the state of a tree built from the same definition.
 */
export type BehaviourTreeSnapshot = {
    /**
     * The version of the snapshot format.
     */
    version: typeof SNAPSHOT_VERSION;
    /**
     * A fingerprint of the definition of the tree that the snapshot was taken from, which is the same for an MDSL definition and the equivalent JSON definition.
     */
    definition: string;
    /**
     * The snapshot of the root node, which includes the snapshots of every node in the tree.
     */
    root: NodeSnapshot;
};

/**
 * Creates the error to throw for an invalid snapshot of the node at the given path.
 */
function createInvalidSnapshotError(path: string, message: string): Error {
    return new Error(`invalid snapshot at '${path}': ${message}`);
}

/**
 * Asserts that a node snapshot is an object of the expected node type with a valid state.
 * @param snapshot The node snapshot.
 * @param path The path of the node in the snapshot, used in error messages.
 * @param type The expected node type.
 */
export function assertNodeSnapshot(snapshot: unknown, path: string, type: string): asserts snapshot is NodeSnapshot {
    if (typeof snapshot !== "object" || snapshot === null) {
        throw createInvalidSnapshotError(path, "expected an object");
    }

    const { type: snapshotType, state } = snapshot as NodeSnapshot;

    if (snapshotType !== type) {
        throw createInvalidSnapshotError(path, `expected a '${type}' node but found '${snapshotType}'`);
    }

    if (!Object.values(State).includes(state)) {
        throw createInvalidSnapshotError(path, `expected a node state but found '${state}'`);
    }
}

/**
 * Asserts that a node snapshot has a snapshot for each of the given children, which are validated.
 * @param snapshot The node snapshot.
 * @param path The path of the node in the snapshot, used in error messages.
 * @param children The tree nodes that the snapshot nodes will be restored to.
 */
export function assertChildSnapshots(
    snapshot: NodeSnapshot,
    path: string,
    children: { validateSnapshot(snapshot: unknown, path: string): void }[]
): void {
    if (!Array.isArray(snapshot.children)) {
        throw createInvalidSnapshotError(path, `expected ${children.length} children but found none`);
    }

    if (snapshot.children.length !== children.length) {
        throw createInvalidSnapshotError(
            path,
            `expected ${children.length} children but found ${snapshot.children.length}`
        );
    }

    children.forEach((child, index) => child.validateSnapshot(snapshot.children![index], `${path}.children[${index}]`));
}

/**
 * Asserts that a property of a node snapshot is a non-negative integer, or optionally null.
 * @param snapshot The node snapshot.
 * @param path The path of the node in the snapshot, used in error messages.
 * @param property The name of the property to check.
 * @param allowNull Whether null is a valid value.
 */
export function assertCount(
    snapshot: NodeSnapshot,
    path: string,
    property: "targetIterationCount" | "currentIterationCount" | "targetAttemptCount" | "currentAttemptCount",
    allowNull: boolean
): void {
    const value = snapshot[property];

    if ((allowNull && value === null) || (Number.isInteger(value) && value! >= 0)) {
        return;
    }

    throw createInvalidSnapshotError(
        path,
        `expected '${property}' to be a non-negative integer${allowNull ? " or null" : ""} but found '${value}'`
    );
}

/**
 * Asserts that the selected child index of a lotto node snapshot is the index of one of its children.
 * A lotto node that is not running may not have selected a child, so null is also valid for it.
 * @param snapshot The lotto node snapshot.
 * @param path The path of the node in the snapshot, used in error messages.
 * @param childCount The number of children of the lotto node.
 */
export function assertSelectedChildIndex(snapshot: NodeSnapshot, path: string, childCount: number): void {
    const { selectedChildIndex } = snapshot;
    // A lotto node that is resolved by its own guards before it is updated has not selected a child either.
    const canBeNull = snapshot.state !== State.RUNNING;

    if (
        (canBeNull && selectedChildIndex === null) ||
        (Number.isInteger(selectedChildIndex) && selectedChildIndex! >= 0 && selectedChildIndex! < childCount)
    ) {
        return;
    }

    throw createInvalidSnapshotError(
        path,
        `expected 'selectedChildIndex' to be the index of one of the ${childCount} children${
            canBeNull ? " or null" : ""
        } but found '${selectedChildIndex}'`
    );
}

/**
 * Asserts that a property of a wait node snapshot is a non-negative number, or optionally null.
 * @param snapshot The wait node snapshot.
 * @param path The path of the node in the snapshot, used in error messages.
 * @param property The name of the property to check.
 * @param allowNull Whether null is a valid value.
 */
export function assertDuration(
    snapshot: NodeSnapshot,
    path: string,
    property: "totalDuration" | "waitedDuration",
    allowNull: boolean
): void {
    const value = snapshot[property];

    if ((allowNull && value === null) || (Number.isFinite(value) && value! >= 0)) {
        return;
    }

    throw createInvalidSnapshotError(
        path,
        `expected '${property}' to be a non-negative number${allowNull ? " or null" : ""} but found '${value}'`
    );
}
