/**
 * Create a randomly generated node uid.
 * @returns A randomly generated node uid.
 */
export function createUid(): string {
    const S4 = function () {
        return (((1 + Math.random()) * 0x10000) | 0).toString(16).substring(1);
    };
    return S4() + S4() + "-" + S4() + "-" + S4() + "-" + S4() + "-" + S4() + S4() + S4();
}

/**
 * Creates a hash of a string from two seeded runs of the cyrb53 hash function, as a string of 28 hexadecimal characters.
 * This is not cryptographically secure, it is only used to tell whether two strings are different.
 * @param value The string to hash.
 * @returns The hash of the string.
 */
export function createHash(value: string): string {
    const hash = (seed: number): string => {
        let h1 = 0xdeadbeef ^ seed;
        let h2 = 0x41c6ce57 ^ seed;

        for (let index = 0; index < value.length; index++) {
            const code = value.charCodeAt(index);
            h1 = Math.imul(h1 ^ code, 2654435761);
            h2 = Math.imul(h2 ^ code, 1597334677);
        }

        h1 = Math.imul(h1 ^ (h1 >>> 16), 2246822507) ^ Math.imul(h2 ^ (h2 >>> 13), 3266489909);
        h2 = Math.imul(h2 ^ (h2 >>> 16), 2246822507) ^ Math.imul(h1 ^ (h1 >>> 13), 3266489909);

        // This is a 53 bit number, which is 14 hexadecimal characters.
        return (4294967296 * (2097151 & h2) + (h1 >>> 0)).toString(16).padStart(14, "0");
    };

    return hash(0) + hash(1);
}
