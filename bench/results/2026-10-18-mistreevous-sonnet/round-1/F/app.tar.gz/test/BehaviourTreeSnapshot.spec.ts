import { assert } from "chai";
import sinon, { SinonFakeTimers } from "sinon";

import { BehaviourTree, State } from "../src/index";
import { NodeStateChange } from "../src/BehaviourTreeOptions";
import { RootNodeDefinition } from "../src/BehaviourTreeDefinition";

import { findNode } from "./TestUtilities";
import {
    AgentResults,
    assertRestoredTreeMatchesOriginalFromEveryStep,
    createAgent,
    getComparableDetails,
    throughJSON
} from "./SnapshotTestUtilities";

describe("A BehaviourTree", () => {
    beforeEach(() => BehaviourTree.unregisterAll());

    describe("has a snapshot method that", () => {
        it("returns the state of a tree that has not been stepped", () => {
            const tree = new BehaviourTree("root { sequence { action [work] action [quick] } }", {});

            const snapshot = tree.snapshot();

            assert.strictEqual(snapshot.version, 1);
            assert.strictEqual(snapshot.root.type, "root");
            assert.strictEqual(snapshot.root.state, State.READY);
            assert.strictEqual(snapshot.root.children?.[0].type, "sequence");
            assert.deepEqual(
                snapshot.root.children?.[0].children?.map((child) => [child.type, child.state]),
                [
                    ["action", State.READY],
                    ["action", State.READY]
                ]
            );
        });

        it("returns the state of each node in a tree that has been stepped", () => {
            const agent = { quick: () => State.SUCCEEDED, work: () => State.RUNNING };
            const tree = new BehaviourTree("root { sequence { action [quick] action [work] action [quick] } }", agent);

            tree.step();

            const sequence = tree.snapshot().root.children![0];

            assert.strictEqual(sequence.state, State.RUNNING);
            assert.deepEqual(
                sequence.children!.map((child) => child.state),
                [State.SUCCEEDED, State.RUNNING, State.READY]
            );
        });

        it("returns a plain object that is unchanged by serialising it to JSON and parsing it again", () => {
            const results: AgentResults = {
                work: (callCount) => (callCount < 3 ? undefined : State.SUCCEEDED),
                quick: () => State.SUCCEEDED,
                isReady: () => true
            };
            const definition = `root {
                sequence {
                    condition [isReady]
                    parallel {
                        action [work]
                        selector { action [quick] }
                    }
                    flip { succeed { fail { action [quick] } } }
                }
            }`;
            const tree = new BehaviourTree(definition, createAgent(results, {}, []));

            for (let step = 0; step < 4; step++) {
                tree.step();

                const snapshot = tree.snapshot();

                assert.deepEqual(throughJSON(snapshot), snapshot);
                assert.isFalse(JSON.stringify(snapshot).includes("undefined"));
            }
        });

        it("returns a snapshot that is not changed by further steps or changes to the snapshot", () => {
            const agent = { work: () => State.RUNNING, quick: () => State.SUCCEEDED };
            const tree = new BehaviourTree("root { sequence { action [quick] action [work] } }", agent);

            const initial = throughJSON(tree.snapshot());
            const snapshot = tree.snapshot();

            tree.step();

            assert.deepEqual(snapshot, initial);

            snapshot.root.state = State.FAILED;
            snapshot.root.children![0].children!.pop();

            assert.strictEqual(tree.snapshot().root.state, State.RUNNING);
            assert.lengthOf(tree.snapshot().root.children![0].children!, 2);
        });

        it("returns a snapshot that stays independent of the trees it is taken from and restored to", () => {
            const definition =
                "root { sequence { wait [1000] repeat [3] { lotto { action [work] action [quick] } } } }";
            const agent = { work: () => State.RUNNING, quick: () => State.SUCCEEDED };
            const clock = sinon.useFakeTimers();

            try {
                const original = new BehaviourTree(definition, agent);

                original.step();
                clock.tick(400);
                original.step();

                const snapshot = original.snapshot();
                const expected = throughJSON(snapshot);

                // Stepping the tree that the snapshot was taken from does not change it.
                clock.tick(700);
                original.step();
                original.step();
                assert.deepEqual(snapshot, expected);

                // Restoring it, and stepping the restored tree, does not change it either.
                const restored = new BehaviourTree(definition, agent);
                restored.restore(snapshot);
                assert.deepEqual(throughJSON(restored.snapshot()), expected);

                clock.tick(700);
                restored.step();
                restored.step();
                restored.step();
                assert.deepEqual(snapshot, expected);
            } finally {
                clock.restore();
            }
        });
    });

    describe("has snapshot and restore methods that, for an action that returns a promise,", () => {
        const waitForPromises = () => new Promise((resolve) => setTimeout(resolve, 0));

        it("make snapshot save the action as not started while it is awaiting its promise", async () => {
            const definition = "root { sequence { action [quick] action [work] action [quick] } }";
            const resolvers: ((state: State) => void)[] = [];
            const calls: string[] = [];
            const agent = {
                quick: () => {
                    calls.push("quick");
                    return State.SUCCEEDED;
                },
                work: () => {
                    calls.push("work");
                    return new Promise<State>((resolve) => resolvers.push(resolve));
                }
            };
            const tree = new BehaviourTree(definition, agent);

            tree.step();

            const getSequenceStates = () => {
                const sequence = tree.snapshot().root.children![0];
                return [sequence.state, ...sequence.children!.map((child) => child.state)];
            };

            assert.deepEqual(getSequenceStates(), [State.RUNNING, State.SUCCEEDED, State.READY, State.READY]);

            // Taking a snapshot does not change the tree, which is still waiting for the promise that the action function returned.
            assert.strictEqual(findNode(tree, "action", "work").state, State.RUNNING);

            // The action is awaiting its promise until the node is next updated, even if the promise has settled.
            resolvers[0](State.SUCCEEDED);
            await waitForPromises();

            assert.deepEqual(getSequenceStates(), [State.RUNNING, State.SUCCEEDED, State.READY, State.READY]);

            tree.step();

            assert.strictEqual(tree.getState(), State.SUCCEEDED);
            assert.deepEqual(calls, ["quick", "work", "quick"]);
            assert.deepEqual(getSequenceStates(), [State.SUCCEEDED, State.SUCCEEDED, State.SUCCEEDED, State.SUCCEEDED]);
        });

        it("make restore leave a tree that calls the action function again on its next step", async () => {
            const definition = "root { sequence { action [quick] action [work] action [quick] } }";
            const createPromiseAgent = (calls: string[], resolvers: ((state: State) => void)[]) => ({
                quick: () => {
                    calls.push("quick");
                    return State.SUCCEEDED;
                },
                work: () => {
                    calls.push("work");
                    return new Promise<State>((resolve) => resolvers.push(resolve));
                }
            });

            const original = new BehaviourTree(definition, createPromiseAgent([], []));
            original.step();

            const calls: string[] = [];
            const resolvers: ((state: State) => void)[] = [];
            const restored = new BehaviourTree(definition, createPromiseAgent(calls, resolvers));

            restored.restore(throughJSON(original.snapshot()));

            // Nothing is called by the restore, and the action has not started.
            assert.deepEqual(calls, []);
            assert.strictEqual(restored.getState(), State.RUNNING);
            assert.strictEqual(findNode(restored, "action", "work").state, State.READY);

            // The action function is called again on the next step, but not those of actions that had already finished.
            restored.step();

            assert.deepEqual(calls, ["work"]);
            assert.strictEqual(findNode(restored, "action", "work").state, State.RUNNING);

            // Further steps wait for the new promise, as they would for any action.
            restored.step();
            assert.deepEqual(calls, ["work"]);

            resolvers[0](State.SUCCEEDED);
            await waitForPromises();
            restored.step();

            assert.deepEqual(calls, ["work", "quick"]);
            assert.strictEqual(restored.getState(), State.SUCCEEDED);
        });

        it("make restore call the entry callback of the action again, but not those of other nodes", () => {
            const definition = `root {
                parallel {
                    sequence entry(enterSequence) {
                        action [work] entry(enterWork)
                    }
                    action [slow] entry(enterSlow)
                }
            }`;
            const createEntryAgent = (calls: string[]) => ({
                enterSequence: () => calls.push("enterSequence"),
                enterWork: () => calls.push("enterWork"),
                enterSlow: () => calls.push("enterSlow"),
                work: () => {
                    calls.push("work");
                    return new Promise<State>(() => {});
                },
                slow: () => {
                    calls.push("slow");
                    return State.RUNNING;
                }
            });

            const original = new BehaviourTree(definition, createEntryAgent([]));
            original.step();

            const calls: string[] = [];
            const restored = new BehaviourTree(definition, createEntryAgent(calls));
            restored.restore(throughJSON(original.snapshot()));

            restored.step();

            assert.deepEqual(calls, ["enterWork", "work", "slow"]);
        });

        it("make restore ignore the promise that the action was awaiting in the tree the snapshot was taken from", async () => {
            const definition = "root { parallel { action [work] wait [100] } }";
            const resolvers: ((state: State) => void)[] = [];
            const agent = { work: () => new Promise<State>((resolve) => resolvers.push(resolve)) };
            const original = new BehaviourTree(definition, agent);
            original.step();

            const restored = new BehaviourTree(definition, agent);
            restored.restore(throughJSON(original.snapshot()));
            restored.step();

            assert.lengthOf(resolvers, 2);

            // The promise of the original tree does not affect the restored tree.
            resolvers[0](State.FAILED);
            await waitForPromises();
            restored.step();

            assert.strictEqual(findNode(restored, "action", "work").state, State.RUNNING);

            resolvers[1](State.SUCCEEDED);
            await waitForPromises();
            restored.step();

            assert.strictEqual(findNode(restored, "action", "work").state, State.SUCCEEDED);
        });

        it("make snapshot save the result of the action once it has finished, or if it was reset or has not started", async () => {
            const definition = "root { action [work] }";
            const agent = { work: () => Promise.resolve(State.FAILED) };
            const tree = new BehaviourTree(definition, agent);

            assert.doesNotThrow(() => tree.snapshot());

            tree.step();
            tree.reset();

            assert.doesNotThrow(() => tree.snapshot());

            tree.step();
            await waitForPromises();
            tree.step();

            const snapshot = throughJSON(tree.snapshot());
            assert.strictEqual(snapshot.root.state, State.FAILED);

            const restored = new BehaviourTree(definition, agent);
            restored.restore(snapshot);

            assert.strictEqual(restored.getState(), State.FAILED);
        });

        it("make restore discard the promise of an action that the snapshot is restored over", async () => {
            const definition = "root { action [work] }";
            const resolvers: ((state: State) => void)[] = [];
            const agent = { work: () => new Promise<State>((resolve) => resolvers.push(resolve)) };
            const tree = new BehaviourTree(definition, agent);

            const readySnapshot = tree.snapshot();

            tree.step();

            tree.restore(readySnapshot);

            assert.strictEqual(tree.getState(), State.READY);

            // The function is called again and it is the new promise that the action waits for.
            tree.step();
            assert.lengthOf(resolvers, 2);

            resolvers[0](State.FAILED);
            await waitForPromises();
            tree.step();

            assert.strictEqual(tree.getState(), State.RUNNING);

            resolvers[1](State.SUCCEEDED);
            await waitForPromises();
            tree.step();

            assert.strictEqual(tree.getState(), State.SUCCEEDED);
        });
    });

    describe("has a restore method that", () => {
        describe("sets a tree built from the same definition to the state of the tree that the snapshot was taken from", () => {
            describe("and carries on exactly like the original tree for a", () => {
                it("sequence node", () => {
                    assertRestoredTreeMatchesOriginalFromEveryStep(
                        "root { sequence { action [quick] action [work] action [quick] } }",
                        {
                            quick: () => State.SUCCEEDED,
                            work: (callCount) => (callCount < 3 ? undefined : State.SUCCEEDED)
                        }
                    );
                });

                it("selector node", () => {
                    assertRestoredTreeMatchesOriginalFromEveryStep(
                        "root { selector { condition [isReady] action [failing] action [work] action [quick] } }",
                        {
                            isReady: (callCount) => callCount > 2,
                            failing: () => State.FAILED,
                            work: (callCount) => (callCount < 3 ? undefined : State.FAILED),
                            quick: () => State.SUCCEEDED
                        }
                    );
                });

                it("parallel node", () => {
                    assertRestoredTreeMatchesOriginalFromEveryStep(
                        "root { parallel { action [work] action [slow] action [quick] } }",
                        {
                            work: (callCount) => (callCount < 3 ? undefined : State.SUCCEEDED),
                            slow: (callCount) => (callCount < 5 ? undefined : State.SUCCEEDED),
                            quick: () => State.SUCCEEDED
                        }
                    );
                });

                it("parallel node where a child fails after others have started running", () => {
                    assertRestoredTreeMatchesOriginalFromEveryStep(
                        "root { parallel { action [work] action [slow] } }",
                        {
                            work: () => undefined,
                            slow: (callCount) => (callCount < 4 ? undefined : State.FAILED)
                        }
                    );
                });

                it("race node", () => {
                    assertRestoredTreeMatchesOriginalFromEveryStep("root { race { action [work] action [slow] } }", {
                        work: () => undefined,
                        slow: (callCount) => (callCount < 4 ? undefined : State.SUCCEEDED)
                    });
                });

                it("all node", () => {
                    assertRestoredTreeMatchesOriginalFromEveryStep("root { all { action [work] action [slow] } }", {
                        work: (callCount) => (callCount < 2 ? undefined : State.FAILED),
                        slow: (callCount) => (callCount < 5 ? undefined : State.SUCCEEDED)
                    });
                });

                it("flip, succeed and fail nodes", () => {
                    assertRestoredTreeMatchesOriginalFromEveryStep(
                        `root {
                            sequence {
                                flip { action [work] }
                                succeed { action [failing] }
                                fail { action [quick] }
                            }
                        }`,
                        {
                            work: (callCount) => (callCount < 3 ? undefined : State.FAILED),
                            failing: () => State.FAILED,
                            quick: () => State.SUCCEEDED
                        }
                    );
                });

                it("repeat node with an explicit iteration count", () => {
                    assertRestoredTreeMatchesOriginalFromEveryStep("root { repeat [3] { action [work] } }", {
                        work: (callCount) => (callCount % 2 === 0 ? State.SUCCEEDED : undefined)
                    });
                });

                it("repeat node with a random iteration count", () => {
                    assertRestoredTreeMatchesOriginalFromEveryStep(
                        "root { repeat [1, 8] { action [work] } }",
                        {
                            work: (callCount) => (callCount % 2 === 0 ? State.SUCCEEDED : undefined)
                        },
                        { totalSteps: 30 }
                    );
                });

                it("repeat node with no iteration count that is ended by its child failing", () => {
                    assertRestoredTreeMatchesOriginalFromEveryStep(
                        "root { repeat { sequence { action [work] condition [shouldContinue] } } }",
                        {
                            work: (callCount) => (callCount % 2 === 0 ? State.SUCCEEDED : undefined),
                            shouldContinue: (callCount) => callCount < 4
                        },
                        { totalSteps: 16 }
                    );
                });

                it("nested repeat nodes", () => {
                    assertRestoredTreeMatchesOriginalFromEveryStep(
                        "root { repeat [2, 3] { sequence { action [quick] repeat [2] { action [work] } } } }",
                        {
                            quick: () => State.SUCCEEDED,
                            work: (callCount) => (callCount % 2 === 0 ? State.SUCCEEDED : undefined)
                        },
                        { totalSteps: 30 }
                    );
                });

                it("retry node with an explicit attempt count", () => {
                    assertRestoredTreeMatchesOriginalFromEveryStep("root { retry [3] { action [flaky] } }", {
                        flaky: (callCount) => (callCount % 2 === 0 ? State.FAILED : undefined)
                    });
                });

                it("retry node with a random attempt count", () => {
                    assertRestoredTreeMatchesOriginalFromEveryStep(
                        "root { retry [1, 8] { action [flaky] } }",
                        {
                            flaky: (callCount) => (callCount % 2 === 0 ? State.FAILED : undefined)
                        },
                        { totalSteps: 30 }
                    );
                });

                it("retry node with no attempt count that is ended by its child succeeding", () => {
                    assertRestoredTreeMatchesOriginalFromEveryStep(
                        "root { retry { action [flaky] } }",
                        {
                            flaky: (callCount) =>
                                callCount < 7 ? (callCount % 2 === 0 ? State.FAILED : undefined) : State.SUCCEEDED
                        },
                        { totalSteps: 16 }
                    );
                });

                it("lotto node", () => {
                    assertRestoredTreeMatchesOriginalFromEveryStep(
                        "root { lotto { action [first] action [second] action [third] } }",
                        {
                            first: (callCount) => (callCount < 3 ? undefined : State.SUCCEEDED),
                            second: (callCount) => (callCount < 2 ? undefined : State.FAILED),
                            third: () => State.SUCCEEDED
                        },
                        { totalSteps: 24 }
                    );
                });

                it("lotto node with weights inside a repeat node", () => {
                    assertRestoredTreeMatchesOriginalFromEveryStep(
                        "root { repeat [4] { lotto [1, 5, 2] { action [first] action [second] action [third] } } }",
                        {
                            first: (callCount) => (callCount % 2 === 0 ? State.SUCCEEDED : undefined),
                            second: (callCount) => (callCount % 3 === 0 ? State.FAILED : undefined),
                            third: () => State.SUCCEEDED
                        },
                        { totalSteps: 30 }
                    );
                });

                it("tree with entry, step and exit callbacks", () => {
                    assertRestoredTreeMatchesOriginalFromEveryStep(
                        `root {
                            sequence entry(onEntry) step(onStep) exit(onExit) {
                                action [work] entry(onWorkEntry) step(onWorkStep) exit(onWorkExit)
                                action [quick]
                            }
                        }`,
                        {
                            onEntry: () => undefined,
                            onStep: () => undefined,
                            onExit: () => undefined,
                            onWorkEntry: () => undefined,
                            onWorkStep: () => undefined,
                            onWorkExit: () => undefined,
                            work: (callCount) => (callCount < 3 ? undefined : State.SUCCEEDED),
                            quick: () => State.SUCCEEDED
                        }
                    );
                });

                it("tree with while and until guards that abort running nodes", () => {
                    assertRestoredTreeMatchesOriginalFromEveryStep(
                        `root {
                            selector {
                                sequence while(isOk) {
                                    action [work] exit(onWorkExit)
                                    action [slow]
                                }
                                sequence until(isDone) {
                                    action [work] entry(onWorkEntry)
                                    action [slow]
                                }
                                action [quick]
                            }
                        }`,
                        {
                            isOk: (callCount) => callCount < 3,
                            isDone: (callCount) => callCount > 3,
                            onWorkEntry: () => undefined,
                            onWorkExit: () => undefined,
                            work: (callCount) => (callCount < 6 ? undefined : State.SUCCEEDED),
                            slow: () => undefined,
                            quick: () => State.SUCCEEDED
                        },
                        { totalSteps: 14 }
                    );
                });

                it("lotto node that is ended by its own guard before it picks a child", () => {
                    assertRestoredTreeMatchesOriginalFromEveryStep(
                        "root { selector { lotto while(isOk) { action [work] action [work] } action [quick] } }",
                        { isOk: () => false, work: () => undefined, quick: () => State.SUCCEEDED },
                        { totalSteps: 4 }
                    );
                });

                it("tree with a branch node that references a subtree", () => {
                    const definition = `
                        root { sequence { action [quick] branch [Work] } }
                        root [Work] { sequence { action [work] action [quick] } }
                    `;

                    assertRestoredTreeMatchesOriginalFromEveryStep(definition, {
                        quick: () => State.SUCCEEDED,
                        work: (callCount) => (callCount < 3 ? undefined : State.SUCCEEDED)
                    });
                });

                it("tree defined using JSON", () => {
                    const definition: RootNodeDefinition = {
                        type: "root",
                        child: {
                            type: "sequence",
                            children: [
                                { type: "action", call: "quick" },
                                { type: "action", call: "work" }
                            ]
                        }
                    };

                    assertRestoredTreeMatchesOriginalFromEveryStep(definition, {
                        quick: () => State.SUCCEEDED,
                        work: (callCount) => (callCount < 3 ? undefined : State.SUCCEEDED)
                    });
                });
            });

            it("without calling any agent functions", () => {
                const results: AgentResults = {
                    work: () => undefined,
                    onEntry: () => undefined,
                    onExit: () => undefined
                };
                const definition = "root { sequence entry(onEntry) exit(onExit) { action [work] } }";

                const original = new BehaviourTree(definition, createAgent(results, {}, []));
                original.step();

                const restoredLog: string[] = [];
                const restored = new BehaviourTree(definition, createAgent(results, {}, restoredLog));
                restored.step();
                restoredLog.length = 0;

                // Restoring over a tree that has already been stepped and is running does not abort anything.
                restored.restore(original.snapshot());

                assert.isEmpty(restoredLog);
                assert.strictEqual(restored.getState(), State.RUNNING);
            });

            it("when the tree has already been stepped past the point where the snapshot was taken", () => {
                const results: AgentResults = {
                    work: (callCount) => (callCount < 4 ? undefined : State.SUCCEEDED),
                    quick: () => State.SUCCEEDED
                };
                const definition = "root { sequence { action [quick] action [work] action [quick] } }";

                const callCounts = {};
                const log: string[] = [];
                const tree = new BehaviourTree(definition, createAgent(results, callCounts, log));

                tree.step();
                tree.step();

                const snapshot = throughJSON(tree.snapshot());
                const detailsAtSnapshot = getComparableDetails(tree.getTreeNodeDetails());

                tree.step();
                tree.step();
                tree.step();

                assert.strictEqual(tree.getState(), State.SUCCEEDED);

                tree.restore(snapshot);

                assert.deepEqual(getComparableDetails(tree.getTreeNodeDetails()), detailsAtSnapshot);
                assert.strictEqual(tree.getState(), State.RUNNING);

                // The same snapshot can be restored more than once.
                tree.restore(snapshot);

                assert.deepEqual(getComparableDetails(tree.getTreeNodeDetails()), detailsAtSnapshot);
            });

            it("for a tree that has not been stepped", () => {
                const definition = "root { sequence { action [work] } }";
                const tree = new BehaviourTree(definition, {});
                const restored = new BehaviourTree(definition, { work: () => State.SUCCEEDED });

                restored.step();
                restored.restore(tree.snapshot());

                assert.strictEqual(restored.getState(), State.READY);
                assert.strictEqual(findNode(restored, "action").state, State.READY);
            });
        });

        describe("does not make random choices that were already made by the tree the snapshot was taken from", () => {
            const definitions: [string, string][] = [
                ["repeat node iteration count", "root { repeat [2, 5] { action [work] } }"],
                ["retry node attempt count", "root { retry [2, 5] { action [work] } }"],
                ["lotto node child", "root { lotto { action [work] action [work] action [work] } }"]
            ];

            for (const [description, definition] of definitions) {
                it(`such as a ${description}`, () => {
                    const agent = { work: () => undefined };
                    const original = new BehaviourTree(definition, agent, { random: () => 0.5 });
                    original.step();

                    let randomCalls = 0;
                    const restored = new BehaviourTree(definition, agent, {
                        random: () => {
                            randomCalls++;
                            return 0.99;
                        }
                    });
                    restored.restore(throughJSON(original.snapshot()));
                    restored.step();
                    restored.step();

                    assert.strictEqual(randomCalls, 0);
                    assert.deepEqual(restored.snapshot(), original.snapshot());
                });
            }
        });

        describe("restores a wait node so that it", () => {
            const HOUR = 60 * 60 * 1000;

            let clock: SinonFakeTimers;

            beforeEach(() => (clock = sinon.useFakeTimers()));
            afterEach(() => clock.restore());

            describe("carries on exactly like the original tree when", () => {
                it("the clock is used to get the elapsed time", () => {
                    assertRestoredTreeMatchesOriginalFromEveryStep(
                        "root { sequence { wait [1000] action [quick] wait [500] } }",
                        { quick: () => State.SUCCEEDED },
                        { totalSteps: 14, afterStep: () => clock.tick(300) }
                    );
                });

                it("the 'getDeltaTime' option is used to get the elapsed time", () => {
                    assertRestoredTreeMatchesOriginalFromEveryStep(
                        "root { sequence { wait [1000] action [quick] wait [500] } }",
                        { quick: () => State.SUCCEEDED },
                        {
                            totalSteps: 14,
                            getTreeOptions: (random) => ({ random, getDeltaTime: () => 0.3 }),
                            // The clock moves a lot more than the delta time so that it would be noticed if it was used.
                            afterStep: () => clock.tick(5000)
                        }
                    );
                });

                it("the duration is picked at random from a range", () => {
                    assertRestoredTreeMatchesOriginalFromEveryStep(
                        "root { repeat [3] { wait [200, 2000] } }",
                        {},
                        { totalSteps: 40, afterStep: () => clock.tick(250) }
                    );
                });

                it("the wait is in a parallel node alongside another wait", () => {
                    assertRestoredTreeMatchesOriginalFromEveryStep(
                        "root { parallel { wait [700] sequence { wait [300] action [quick] wait [600] } } }",
                        { quick: () => State.SUCCEEDED },
                        { totalSteps: 12, afterStep: () => clock.tick(200) }
                    );
                });
            });

            describe("only waits for the time that was left when the snapshot was taken, not for time that passed before the restore", () => {
                const definition = "root { sequence { wait [1000] action [done] } }";

                it("using the clock", () => {
                    const original = new BehaviourTree(definition, { done: () => State.SUCCEEDED });

                    original.step();
                    clock.tick(400);
                    original.step();

                    const snapshot = throughJSON(original.snapshot());

                    // The process is down for a long time.
                    clock.tick(10 * HOUR);

                    const restored = new BehaviourTree(definition, { done: () => State.SUCCEEDED });
                    restored.restore(snapshot);

                    restored.step();
                    assert.strictEqual(findNode(restored, "wait").state, State.RUNNING);

                    clock.tick(599);
                    restored.step();
                    assert.strictEqual(findNode(restored, "wait").state, State.RUNNING);

                    clock.tick(1);
                    restored.step();
                    assert.strictEqual(findNode(restored, "wait").state, State.SUCCEEDED);
                    assert.strictEqual(restored.getState(), State.SUCCEEDED);
                });

                it("using the clock, when time passed between the last step and the snapshot", () => {
                    const original = new BehaviourTree(definition, { done: () => State.SUCCEEDED });

                    original.step();
                    clock.tick(400);

                    const snapshot = throughJSON(original.snapshot());

                    clock.tick(10 * HOUR);

                    const restored = new BehaviourTree(definition, { done: () => State.SUCCEEDED });
                    restored.restore(snapshot);

                    clock.tick(599);
                    restored.step();
                    assert.strictEqual(findNode(restored, "wait").state, State.RUNNING);

                    clock.tick(1);
                    restored.step();
                    assert.strictEqual(findNode(restored, "wait").state, State.SUCCEEDED);
                });

                it("using the 'getDeltaTime' option", () => {
                    const options = { getDeltaTime: () => 0.1 };
                    const original = new BehaviourTree(definition, { done: () => State.SUCCEEDED }, options);

                    for (let step = 0; step < 3; step++) {
                        original.step();
                    }

                    const snapshot = throughJSON(original.snapshot());

                    clock.tick(10 * HOUR);

                    const restored = new BehaviourTree(definition, { done: () => State.SUCCEEDED }, options);
                    restored.restore(snapshot);

                    // The wait has waited for 300ms and needs a further seven steps of 100ms.
                    for (let step = 0; step < 6; step++) {
                        restored.step();
                        assert.strictEqual(findNode(restored, "wait").state, State.RUNNING);
                    }

                    restored.step();
                    assert.strictEqual(findNode(restored, "wait").state, State.SUCCEEDED);
                });

                it("when restored to a tree that gets the elapsed time in a different way to the original", () => {
                    const original = new BehaviourTree(
                        definition,
                        { done: () => State.SUCCEEDED },
                        { getDeltaTime: () => 0.3 }
                    );

                    original.step();
                    original.step();

                    const snapshot = throughJSON(original.snapshot());

                    clock.tick(10 * HOUR);

                    const restored = new BehaviourTree(definition, { done: () => State.SUCCEEDED });
                    restored.restore(snapshot);

                    // The wait has waited for 600ms and needs a further 400ms.
                    clock.tick(399);
                    restored.step();
                    assert.strictEqual(findNode(restored, "wait").state, State.RUNNING);

                    clock.tick(1);
                    restored.step();
                    assert.strictEqual(findNode(restored, "wait").state, State.SUCCEEDED);
                });
            });

            it("keeps a random duration that was already picked", () => {
                const definition = "root { wait [1000, 5000] }";

                let originalRandomCalls = 0;
                const original = new BehaviourTree(definition, {}, { random: () => (originalRandomCalls++, 0.5) });

                original.step();
                clock.tick(1000);
                original.step();

                const snapshot = throughJSON(original.snapshot());

                // A random function that would pick the minimum duration if it was called, which has already passed.
                let restoredRandomCalls = 0;
                const restored = new BehaviourTree(definition, {}, { random: () => (restoredRandomCalls++, 0) });
                restored.restore(snapshot);

                restored.step();
                assert.strictEqual(findNode(restored, "wait").state, State.RUNNING);

                // The picked duration is 3000ms, of which 1000ms had passed.
                clock.tick(1999);
                restored.step();
                assert.strictEqual(findNode(restored, "wait").state, State.RUNNING);

                clock.tick(1);
                restored.step();
                assert.strictEqual(findNode(restored, "wait").state, State.SUCCEEDED);

                assert.strictEqual(originalRandomCalls, 1);
                assert.strictEqual(restoredRandomCalls, 0);
            });

            it("restores a wait node that was given an elapsed time that is not a valid duration", () => {
                const definition = "root { sequence { wait [1000] action [quick] } }";
                const agent = { quick: () => State.SUCCEEDED };

                // The clock moving backwards gives a negative elapsed time that is counted as no time at all.
                const clockTree = new BehaviourTree(definition, agent);
                clockTree.step();
                clock.setSystemTime(clock.now - 500);

                assert.doesNotThrow(() =>
                    new BehaviourTree(definition, agent).restore(throughJSON(clockTree.snapshot()))
                );

                // A delta time can be any number, but the snapshot has to be a duration that can be saved as JSON.
                for (const deltaTime of [-0.1, Infinity]) {
                    const tree = new BehaviourTree(definition, agent, { getDeltaTime: () => deltaTime });
                    tree.step();

                    const restored = new BehaviourTree(definition, agent);
                    restored.restore(throughJSON(tree.snapshot()));

                    assert.strictEqual(
                        findNode(restored, "wait").state,
                        tree.getTreeNodeDetails().children![0].children![0].state
                    );
                }
            });

            it("keeps waiting indefinitely if it has no duration", () => {
                const original = new BehaviourTree("root { wait }", {});
                original.step();

                clock.tick(HOUR);

                const restored = new BehaviourTree("root { wait }", {});
                restored.restore(throughJSON(original.snapshot()));

                clock.tick(HOUR);
                restored.step();

                assert.strictEqual(findNode(restored, "wait").state, State.RUNNING);
            });

            it("does not keep waiting once it has finished", () => {
                const tree = new BehaviourTree("root { wait [1000] }", {});

                tree.step();
                clock.tick(1500);
                tree.step();

                const snapshot = throughJSON(tree.snapshot());

                clock.tick(HOUR);

                assert.deepEqual(tree.snapshot(), snapshot);
            });

            it("only counts time that passed while the wait node was running", () => {
                const tree = new BehaviourTree("root { wait [1000] }", {});

                clock.tick(HOUR);

                // A wait node that has not been updated has not started waiting yet.
                const snapshot = throughJSON(tree.snapshot());
                const restored = new BehaviourTree("root { wait [1000] }", {});
                restored.restore(snapshot);

                restored.step();
                clock.tick(999);
                restored.step();

                assert.strictEqual(findNode(restored, "wait").state, State.RUNNING);

                clock.tick(1);
                restored.step();

                assert.strictEqual(findNode(restored, "wait").state, State.SUCCEEDED);
            });
        });

        describe("restores a tree that had finished as finished", () => {
            it("and makes new random choices on the next step", () => {
                const definition =
                    "root { sequence { repeat [1, 4] { action [quick] } lotto { action [first] action [second] } } }";
                const agent = {
                    quick: () => State.SUCCEEDED,
                    first: () => State.SUCCEEDED,
                    second: () => State.SUCCEEDED
                };

                const original = new BehaviourTree(definition, agent, { random: () => 0 });

                // With a random value of zero the repeat node does one iteration and the lotto node picks the first child.
                while (original.getState() !== State.SUCCEEDED) {
                    original.step();
                }

                const snapshot = throughJSON(original.snapshot());

                const randomValues = [0.99, 0.99];
                const restored = new BehaviourTree(definition, agent, { random: () => randomValues.shift() ?? 0 });
                restored.restore(snapshot);

                assert.strictEqual(restored.getState(), State.SUCCEEDED);
                assert.lengthOf(randomValues, 2);

                restored.step();

                // With a random value of 0.99 the repeat node now does four iterations and the lotto node picks the second child.
                assert.lengthOf(randomValues, 1);

                let steps = 1;
                while (restored.getState() !== State.SUCCEEDED) {
                    restored.step();
                    steps++;
                }

                assert.isAtLeast(steps, 4);
                assert.lengthOf(randomValues, 0);
                assert.strictEqual(findNode(restored, "action", "second").state, State.SUCCEEDED);
                assert.strictEqual(findNode(restored, "action", "first").state, State.READY);
            });

            it("and starts a new run on the next step", () => {
                const results: AgentResults = {
                    work: (callCount) => (callCount % 2 === 1 ? undefined : State.SUCCEEDED),
                    quick: () => State.SUCCEEDED
                };
                const definition = "root { sequence { action [work] action [quick] } }";

                const log: string[] = [];
                const tree = new BehaviourTree(definition, createAgent(results, {}, log));

                tree.step();
                tree.step();

                assert.strictEqual(tree.getState(), State.SUCCEEDED);

                const restoredLog: string[] = [];
                const restored = new BehaviourTree(
                    definition,
                    createAgent(results, { work: 2, quick: 1 }, restoredLog)
                );
                restored.restore(throughJSON(tree.snapshot()));

                assert.strictEqual(restored.getState(), State.SUCCEEDED);
                assert.strictEqual(findNode(restored, "action", "work").state, State.SUCCEEDED);
                assert.strictEqual(findNode(restored, "action", "quick").state, State.SUCCEEDED);
                assert.deepEqual(restoredLog, []);

                restored.step();

                assert.strictEqual(restored.getState(), State.RUNNING);
                assert.deepEqual(restoredLog, ["work"]);
            });

            it("and a failed tree", () => {
                const definition = "root { sequence { action [failing] action [quick] } }";
                const agent = { failing: () => State.FAILED, quick: () => State.SUCCEEDED };

                const tree = new BehaviourTree(definition, agent);
                tree.step();

                const restored = new BehaviourTree(definition, agent);
                restored.restore(throughJSON(tree.snapshot()));

                assert.strictEqual(restored.getState(), State.FAILED);
                assert.strictEqual(findNode(restored, "action", "quick").state, State.READY);
            });
        });

        describe("does not call the onNodeStateChange option, as restoring is not a state change, and", () => {
            const definition = "root { sequence { action [quick] action [work] } }";

            // The work action keeps running for its first call and succeeds on the next.
            const createWorkAgent = () => {
                let workCalls = 0;

                return {
                    quick: () => State.SUCCEEDED,
                    work: () => (++workCalls > 1 ? State.SUCCEEDED : State.RUNNING)
                };
            };

            it("restores the node states without it for a tree that was not stepped or had been stepped further", () => {
                const original = new BehaviourTree(definition, createWorkAgent());
                original.step();

                const changes: [string, State, State][] = [];
                const onNodeStateChange = ({ type, previousState, state }: NodeStateChange) =>
                    changes.push([type, previousState, state]);

                const fresh = new BehaviourTree(definition, createWorkAgent(), { onNodeStateChange });
                fresh.restore(original.snapshot());

                assert.deepEqual(changes, []);

                const stepped = new BehaviourTree(definition, createWorkAgent(), { onNodeStateChange });
                stepped.step();
                stepped.step();
                changes.length = 0;
                stepped.restore(original.snapshot());

                assert.deepEqual(changes, []);
                assert.deepEqual(fresh.snapshot(), original.snapshot());
                assert.deepEqual(stepped.snapshot(), original.snapshot());
            });

            it("reports the changes made by the next step as usual, from the states that were restored", () => {
                const original = new BehaviourTree(definition, createWorkAgent());
                original.step();

                // The agent of the restored tree is in the state that the agent of the original tree was in.
                const agent = createWorkAgent();
                agent.work();

                const changes: [string, State, State][] = [];
                const restored = new BehaviourTree(definition, agent, {
                    onNodeStateChange: ({ type, previousState, state }) => changes.push([type, previousState, state])
                });
                restored.restore(original.snapshot());

                assert.deepEqual(changes, []);

                restored.step();

                assert.sameDeepMembers(changes, [
                    ["action", State.RUNNING, State.SUCCEEDED],
                    ["sequence", State.RUNNING, State.SUCCEEDED],
                    ["root", State.RUNNING, State.SUCCEEDED]
                ]);
            });
        });

        describe("checks that the snapshot was taken from a tree of the same definition and", () => {
            const mismatchMessage = "snapshot does not match the tree's definition";

            const agent = {
                isAlive: () => true,
                isDone: () => false,
                onEnter: () => {},
                quick: () => State.SUCCEEDED,
                work: () => State.RUNNING
            };

            // A definition that uses every kind of node and attribute, in MDSL and as the equivalent JSON.
            const mdsl = `
                /* The main tree. */
                root {
                    sequence while(isAlive) until(isDone) then succeed entry(onEnter, 1, "two", true, null, $three) {
                        action [quick]
                        condition [isAlive, 1]
                        repeat [2, 4] {
                            retry [3] {
                                lotto [1, 5] {
                                    action [work] step(onEnter) exit(onEnter, 2)
                                    wait [10, 20]
                                }
                            }
                        }
                        parallel { race { wait [5] wait } all { flip { succeed { fail { branch [Sub] } } } } }
                        selector { branch [Sub] }
                    }
                }
                root [Sub] {
                    action [work, 7]
                }
            `;

            const json: RootNodeDefinition[] = [
                {
                    type: "root",
                    child: {
                        type: "sequence",
                        while: { call: "isAlive" },
                        until: { call: "isDone", succeedOnAbort: true },
                        entry: { call: "onEnter", args: [1, "two", true, null, { $: "three" }] },
                        children: [
                            { type: "action", call: "quick" },
                            { type: "condition", call: "isAlive", args: [1] },
                            {
                                type: "repeat",
                                iterations: [2, 4],
                                child: {
                                    type: "retry",
                                    attempts: 3,
                                    child: {
                                        type: "lotto",
                                        weights: [1, 5],
                                        children: [
                                            {
                                                type: "action",
                                                call: "work",
                                                step: { call: "onEnter" },
                                                exit: { call: "onEnter", args: [2] }
                                            },
                                            { type: "wait", duration: [10, 20] }
                                        ]
                                    }
                                }
                            },
                            {
                                type: "parallel",
                                children: [
                                    { type: "race", children: [{ type: "wait", duration: 5 }, { type: "wait" }] },
                                    {
                                        type: "all",
                                        children: [
                                            {
                                                type: "flip",
                                                child: {
                                                    type: "succeed",
                                                    child: { type: "fail", child: { type: "branch", ref: "Sub" } }
                                                }
                                            }
                                        ]
                                    }
                                ]
                            },
                            { type: "selector", children: [{ type: "branch", ref: "Sub" }] }
                        ]
                    }
                },
                { type: "root", id: "Sub", child: { type: "action", call: "work", args: [7] } }
            ];

            const createSteppedTree = (definition: string | RootNodeDefinition[], steps = 3) => {
                const tree = new BehaviourTree(definition, agent);
                for (let step = 0; step < steps; step++) {
                    tree.step();
                }
                return tree;
            };

            describe("includes in the snapshot a definition that", () => {
                it("is a string that does not change as the tree is stepped", () => {
                    const tree = new BehaviourTree(mdsl, agent);
                    const { definition } = tree.snapshot();

                    assert.isString(definition);
                    assert.isNotEmpty(definition);

                    tree.step();
                    tree.step();

                    assert.strictEqual(tree.snapshot().definition, definition);
                });

                it("is the same for every tree built from the same definition", () => {
                    assert.strictEqual(
                        new BehaviourTree(mdsl, agent).snapshot().definition,
                        new BehaviourTree(mdsl, agent).snapshot().definition
                    );
                });

                it("is the same for a tree built from MDSL and one built from the equivalent JSON", () => {
                    assert.strictEqual(
                        new BehaviourTree(mdsl, agent).snapshot().definition,
                        new BehaviourTree(json, agent).snapshot().definition
                    );
                });

                it("is not changed by serialising the snapshot to JSON", () => {
                    const snapshot = createSteppedTree(mdsl).snapshot();

                    assert.deepEqual(throughJSON(snapshot), snapshot);
                });
            });

            describe("accepts a snapshot taken from a tree built from", () => {
                it("the same MDSL definition", () => {
                    const snapshot = throughJSON(createSteppedTree(mdsl).snapshot());
                    const tree = new BehaviourTree(mdsl, agent);

                    tree.restore(snapshot);

                    assert.deepEqual(tree.snapshot(), snapshot);
                });

                it("the equivalent JSON definition when it was taken from a tree built from MDSL", () => {
                    const original = createSteppedTree(mdsl);
                    const tree = new BehaviourTree(json, agent);

                    tree.restore(throughJSON(original.snapshot()));

                    assert.deepEqual(tree.snapshot(), original.snapshot());
                    assert.deepEqual(
                        getComparableDetails(tree.getTreeNodeDetails()),
                        getComparableDetails(original.getTreeNodeDetails())
                    );
                });

                it("the equivalent MDSL definition when it was taken from a tree built from JSON", () => {
                    const original = createSteppedTree(json);
                    const tree = new BehaviourTree(mdsl, agent);

                    tree.restore(throughJSON(original.snapshot()));

                    assert.deepEqual(tree.snapshot(), original.snapshot());
                });

                it("a JSON definition that is a single root node object, written in a different order", () => {
                    const original = new BehaviourTree(
                        { type: "root", child: { type: "wait", duration: 5 } } as RootNodeDefinition,
                        agent
                    );
                    const tree = new BehaviourTree(
                        [{ child: { duration: 5, type: "wait" }, type: "root" }] as RootNodeDefinition[],
                        agent
                    );

                    assert.doesNotThrow(() => tree.restore(original.snapshot()));
                });

                it("a JSON definition with properties that are not used to build the tree", () => {
                    const original = new BehaviourTree("root { sequence { action [quick] wait [5] } }", agent);
                    const tree = new BehaviourTree(
                        {
                            type: "root",
                            comment: "not used",
                            child: {
                                type: "sequence",
                                children: [
                                    { type: "action", call: "quick", duration: 5 },
                                    { type: "wait", duration: 5, call: "ignored" }
                                ]
                            }
                        } as unknown as RootNodeDefinition,
                        agent
                    );

                    assert.doesNotThrow(() => tree.restore(original.snapshot()));
                });

                it("MDSL that is only formatted differently", () => {
                    const original = new BehaviourTree("root { sequence { action [quick] wait [5] } }", agent);
                    const tree = new BehaviourTree(
                        `root {
                            /* The actions. */
                            sequence {
                                action [quick]
                                wait [  5 ]
                            }
                        }`,
                        agent
                    );

                    assert.doesNotThrow(() => tree.restore(original.snapshot()));
                });

                it("a definition with its subtrees in a different order", () => {
                    const [main, sub] = json;
                    const tree = new BehaviourTree([sub, main], agent);

                    assert.doesNotThrow(() => tree.restore(createSteppedTree(json).snapshot()));
                });

                it("a definition that references a globally registered subtree that is the same", () => {
                    BehaviourTree.register("Global", "root { action [work, 7] }");

                    const definition = "root { sequence { action [quick] branch [Global] } }";
                    const original = createSteppedTree(definition);

                    assert.doesNotThrow(() => new BehaviourTree(definition, agent).restore(original.snapshot()));
                });
            });

            describe("rejects a snapshot taken from a tree built from a different definition", () => {
                const differences: [string, string, string][] = [
                    [
                        "with a different action",
                        "root { sequence { action [quick] action [work] } }",
                        "root { sequence { action [work] action [quick] } }"
                    ],
                    ["with a different action argument", "root { action [work, 1] }", "root { action [work, 2] }"],
                    ["with an extra action argument", "root { action [work] }", "root { action [work, null] }"],
                    ["with a different argument type", "root { action [work, 1] }", 'root { action [work, "1"] }'],
                    ["with an agent property argument", "root { action [work, $a] }", 'root { action [work, "$a"] }'],
                    ["with a condition rather than an action", "root { action [quick] }", "root { condition [quick] }"],
                    ["with a different wait duration", "root { wait [100] }", "root { wait [101] }"],
                    [
                        "with a wait duration range rather than a duration",
                        "root { wait [100] }",
                        "root { wait [100, 100] }"
                    ],
                    ["with a wait that has no duration", "root { wait [100] }", "root { wait }"],
                    [
                        "with different repeat iterations",
                        "root { repeat [3] { action [work] } }",
                        "root { repeat [4] { action [work] } }"
                    ],
                    [
                        "with a different retry attempt range",
                        "root { retry [1, 3] { action [work] } }",
                        "root { retry [1, 4] { action [work] } }"
                    ],
                    [
                        "with different lotto weights",
                        "root { lotto [1, 2] { action [work] action [quick] } }",
                        "root { lotto [2, 1] { action [work] action [quick] } }"
                    ],
                    [
                        "with a lotto that has weights",
                        "root { lotto { action [work] action [quick] } }",
                        "root { lotto [1, 1] { action [work] action [quick] } }"
                    ],
                    [
                        "with a different while guard",
                        "root { action [work] while(isAlive) }",
                        "root { action [work] while(isDone) }"
                    ],
                    [
                        "with a while guard rather than an until guard",
                        "root { action [work] while(isAlive) }",
                        "root { action [work] until(isAlive) }"
                    ],
                    [
                        "with a different state when a guard aborts the node",
                        "root { action [work] while(isAlive) then succeed }",
                        "root { action [work] while(isAlive) then fail }"
                    ],
                    [
                        "with a guard that was removed",
                        "root { action [work] while(isAlive) }",
                        "root { action [work] }"
                    ],
                    [
                        "with a different entry callback",
                        "root { action [work] entry(onEnter) }",
                        "root { action [work] entry(quick) }"
                    ],
                    [
                        "with a callback argument",
                        "root { action [work] exit(onEnter) }",
                        "root { action [work] exit(onEnter, 1) }"
                    ],
                    [
                        "with a step callback rather than an exit callback",
                        "root { action [work] step(onEnter) }",
                        "root { action [work] exit(onEnter) }"
                    ],
                    [
                        "with an attribute on a different node",
                        "root { sequence entry(onEnter) { action [work] } }",
                        "root { sequence { action [work] entry(onEnter) } }"
                    ],
                    [
                        "with a different composite",
                        "root { sequence { action [work] } }",
                        "root { selector { action [work] } }"
                    ],
                    [
                        "with a different decorator",
                        "root { flip { action [work] } }",
                        "root { succeed { action [work] } }"
                    ],
                    [
                        "with a different arrangement of nodes",
                        "root { sequence { sequence { action [work] } action [quick] } }",
                        "root { sequence { sequence { action [work] action [quick] } } }"
                    ],
                    [
                        "with a different subtree",
                        "root { branch [Sub] } root [Sub] { action [work] }",
                        "root { branch [Sub] } root [Sub] { action [quick] }"
                    ]
                ];

                for (const [description, original, other] of differences) {
                    it(description, () => {
                        const snapshot = throughJSON(createSteppedTree(original, 1).snapshot());
                        const tree = new BehaviourTree(other, agent);

                        assert.throws(() => tree.restore(snapshot), Error, mismatchMessage);

                        // It is not valid whichever way round the trees are.
                        const otherSnapshot = throughJSON(new BehaviourTree(other, agent).snapshot());

                        assert.throws(
                            () => new BehaviourTree(original, agent).restore(otherSnapshot),
                            Error,
                            mismatchMessage
                        );
                    });
                }

                it("with a different JSON definition of the same structure", () => {
                    const withCall = (call: string): RootNodeDefinition => ({
                        type: "root",
                        child: { type: "action", call }
                    });
                    const snapshot = new BehaviourTree(withCall("work"), agent).snapshot();

                    assert.throws(
                        () => new BehaviourTree(withCall("quick"), agent).restore(snapshot),
                        Error,
                        mismatchMessage
                    );
                });

                it("with a different MDSL definition that has the same structure as a JSON definition", () => {
                    const snapshot = new BehaviourTree(json, agent).snapshot();

                    assert.throws(
                        () =>
                            new BehaviourTree(mdsl.replace("wait [10, 20]", "wait [10, 21]"), agent).restore(snapshot),
                        Error,
                        mismatchMessage
                    );
                });

                it("that references a globally registered subtree that has changed since", () => {
                    const definition = "root { sequence { action [quick] branch [Global] } }";

                    BehaviourTree.register("Global", "root { action [work] }");
                    const snapshot = throughJSON(createSteppedTree(definition, 1).snapshot());

                    BehaviourTree.register("Global", "root { action [quick] }");

                    assert.throws(() => new BehaviourTree(definition, agent).restore(snapshot), Error, mismatchMessage);
                });
            });

            it("leaves a tree that rejected a snapshot of another definition exactly as it was", () => {
                const changes: string[] = [];
                const tree = new BehaviourTree("root { sequence { action [quick] action [work] } }", agent, {
                    onNodeStateChange: ({ type, state }) => changes.push(`${type}:${state}`)
                });
                const snapshot = throughJSON(
                    createSteppedTree("root { sequence { action [work] action [quick] } }", 2).snapshot()
                );

                tree.step();

                const detailsBefore = getComparableDetails(tree.getTreeNodeDetails());
                const snapshotBefore = tree.snapshot();
                changes.length = 0;

                assert.throws(() => tree.restore(snapshot), Error, mismatchMessage);

                assert.deepEqual(changes, []);
                assert.deepEqual(getComparableDetails(tree.getTreeNodeDetails()), detailsBefore);
                assert.deepEqual(tree.snapshot(), snapshotBefore);

                // The tree carries on as if the restore was never attempted.
                tree.step();

                assert.strictEqual(findNode(tree, "action", "work").state, State.RUNNING);
            });

            describe("rejects input that is not a snapshot with an error and leaves the tree as it was", () => {
                const definition = "root { sequence { action [quick] action [work] } }";
                const validSnapshot = () => throughJSON(createSteppedTree(definition, 1).snapshot());

                const notSnapshots: [string, unknown][] = [
                    ["undefined", undefined],
                    ["null", null],
                    ["a string", "snapshot"],
                    ["a JSON string of a snapshot", JSON.stringify(validSnapshot())],
                    ["a number", 42],
                    ["a boolean", true],
                    ["an array", []],
                    ["an array containing a snapshot", [validSnapshot()]],
                    ["an empty object", {}],
                    ["an object without the snapshot fields", { foo: "bar" }],
                    ["a function", () => validSnapshot()],
                    ["a snapshot without a version", { ...validSnapshot(), version: undefined }],
                    ["a snapshot without a definition", { ...validSnapshot(), definition: undefined }],
                    ["a snapshot with a definition that is not a string", { ...validSnapshot(), definition: 7 }],
                    ["a snapshot with a null definition", { ...validSnapshot(), definition: null }],
                    ["a snapshot with an empty definition", { ...validSnapshot(), definition: "" }],
                    ["a snapshot with a definition that is not one of a tree", { ...validSnapshot(), definition: "x" }],
                    ["a snapshot without a root", { ...validSnapshot(), root: undefined }],
                    ["a snapshot with a root that is not an object", { ...validSnapshot(), root: "root" }]
                ];

                for (const [description, value] of notSnapshots) {
                    it(`such as ${description}`, () => {
                        const tree = new BehaviourTree(definition, agent);
                        tree.step();

                        const detailsBefore = getComparableDetails(tree.getTreeNodeDetails());

                        assert.throws(() => tree.restore(value as any), Error);
                        assert.deepEqual(getComparableDetails(tree.getTreeNodeDetails()), detailsBefore);
                    });
                }
            });
        });

        describe("will error if the snapshot", () => {
            const definition = "root { sequence { action [quick] action [work] } }";
            const agent = { quick: () => State.SUCCEEDED, work: () => State.RUNNING };

            const getValidSnapshot = () => {
                const tree = new BehaviourTree(definition, agent);
                tree.step();
                return throughJSON(tree.snapshot());
            };

            it("is not an object", () => {
                const tree = new BehaviourTree(definition, agent);

                for (const value of [undefined, null, "snapshot", 42, true, [], [getValidSnapshot()]]) {
                    assert.throws(() => tree.restore(value as any), Error, "invalid snapshot: expected an object");
                }
            });

            it("is from an unsupported version", () => {
                const tree = new BehaviourTree(definition, agent);
                const snapshot = { ...getValidSnapshot(), version: 2 } as any;

                assert.throws(() => tree.restore(snapshot), Error, "invalid snapshot: unsupported version '2'");
            });

            it("does not have a root node snapshot", () => {
                const tree = new BehaviourTree(definition, agent);
                const snapshot = { ...getValidSnapshot(), root: undefined } as any;

                assert.throws(() => tree.restore(snapshot), Error, "invalid snapshot at 'root': expected an object");
            });

            it("has a node with a state that is not a node state", () => {
                const tree = new BehaviourTree(definition, agent);
                const snapshot = getValidSnapshot();
                snapshot.root.children![0].children![1].state = "bogus" as State;

                assert.throws(
                    () => tree.restore(snapshot),
                    Error,
                    "invalid snapshot at 'root.children[0].children[1]': expected a node state but found 'bogus'"
                );
            });

            it("has a node of a different type to the tree node", () => {
                const tree = new BehaviourTree(definition, agent);
                const snapshot = getValidSnapshot();
                snapshot.root.children![0].type = "selector";

                assert.throws(
                    () => tree.restore(snapshot),
                    Error,
                    "invalid snapshot at 'root.children[0]': expected a 'sequence' node but found 'selector'"
                );
            });

            it("has a node with a different number of children to the tree node", () => {
                const tree = new BehaviourTree(definition, agent);
                const snapshot = getValidSnapshot();
                snapshot.root.children![0].children!.pop();

                assert.throws(
                    () => tree.restore(snapshot),
                    Error,
                    "invalid snapshot at 'root.children[0]': expected 2 children but found 1"
                );
            });

            it("has a node without children when the tree node has children", () => {
                const tree = new BehaviourTree(definition, agent);
                const snapshot = getValidSnapshot();
                delete snapshot.root.children![0].children;

                assert.throws(
                    () => tree.restore(snapshot),
                    Error,
                    "invalid snapshot at 'root.children[0]': expected 2 children but found none"
                );
            });

            describe("has a repeat, retry or lotto node with a value that is not valid", () => {
                const getRunningSnapshot = (definition: string) => {
                    const tree = new BehaviourTree(definition, { work: () => undefined }, { random: () => 0.5 });
                    tree.step();
                    return throughJSON(tree.snapshot());
                };

                const cases: [string, string, string, any, string][] = [
                    [
                        "repeat",
                        "root { repeat [2, 5] { action [work] } }",
                        "currentIterationCount",
                        -1,
                        "a non-negative integer"
                    ],
                    [
                        "repeat",
                        "root { repeat [2, 5] { action [work] } }",
                        "currentIterationCount",
                        1.5,
                        "a non-negative integer"
                    ],
                    [
                        "repeat",
                        "root { repeat [2, 5] { action [work] } }",
                        "currentIterationCount",
                        undefined,
                        "a non-negative integer"
                    ],
                    [
                        "repeat",
                        "root { repeat [2, 5] { action [work] } }",
                        "targetIterationCount",
                        "3",
                        "a non-negative integer or null"
                    ],
                    [
                        "retry",
                        "root { retry [2, 5] { action [work] } }",
                        "currentAttemptCount",
                        "0",
                        "a non-negative integer"
                    ],
                    [
                        "retry",
                        "root { retry [2, 5] { action [work] } }",
                        "targetAttemptCount",
                        -2,
                        "a non-negative integer or null"
                    ],
                    [
                        "lotto",
                        "root { lotto { action [work] action [work] } }",
                        "selectedChildIndex",
                        2,
                        "the index of one of the 2 children"
                    ],
                    [
                        "lotto",
                        "root { lotto { action [work] action [work] } }",
                        "selectedChildIndex",
                        null,
                        "the index of one of the 2 children"
                    ]
                ];

                for (const [type, definition, property, value, expected] of cases) {
                    it(`such as a ${type} node with a '${property}' of '${value}'`, () => {
                        const tree = new BehaviourTree(definition, { work: () => undefined });
                        const snapshot = getRunningSnapshot(definition);
                        snapshot.root.children![0][property as "targetIterationCount"] = value;

                        assert.throws(
                            () => tree.restore(snapshot),
                            Error,
                            `invalid snapshot at 'root.children[0]': expected '${property}' to be ${expected} but found '${value}'`
                        );
                    });
                }

                const waitCases: [string, any][] = [
                    ["totalDuration", -1],
                    ["totalDuration", "1000"],
                    ["totalDuration", undefined],
                    ["waitedDuration", -1],
                    ["waitedDuration", null],
                    ["waitedDuration", "0"]
                ];

                for (const [property, value] of waitCases) {
                    it(`such as a wait node with a '${property}' of '${value}'`, () => {
                        const tree = new BehaviourTree("root { wait [1000] }", {});
                        const snapshot = getRunningSnapshot("root { wait [1000] }");
                        snapshot.root.children![0][property as "totalDuration"] = value;

                        assert.throws(
                            () => tree.restore(snapshot),
                            Error,
                            `invalid snapshot at 'root.children[0]': expected '${property}' to be a non-negative number${
                                property === "totalDuration" ? " or null" : ""
                            } but found '${value}'`
                        );
                    });
                }

                it("such as a lotto node that has not picked a child yet", () => {
                    const definition = "root { lotto { action [work] action [work] } }";
                    const tree = new BehaviourTree(definition, { work: () => undefined });
                    const snapshot = getRunningSnapshot(definition);
                    snapshot.root.children![0].selectedChildIndex = null;
                    snapshot.root.state = State.READY;
                    snapshot.root.children![0].state = State.READY;
                    snapshot.root.children![0].children!.forEach((child) => (child.state = State.READY));

                    // A lotto node that has not been updated has no selected child.
                    assert.doesNotThrow(() => tree.restore(snapshot));
                });
            });

            it("and leaves the tree as it was without restoring any of the snapshot", () => {
                const tree = new BehaviourTree(definition, agent);
                const snapshot = getValidSnapshot();

                tree.step();
                tree.step();

                const detailsBefore = getComparableDetails(tree.getTreeNodeDetails());

                // The problem is in the last node of the tree, after nodes that could have been restored.
                snapshot.root.children![0].children![1].type = "condition";
                snapshot.root.state = State.READY;

                assert.throws(() => tree.restore(snapshot), Error, "invalid snapshot");
                assert.deepEqual(getComparableDetails(tree.getTreeNodeDetails()), detailsBefore);
            });
        });
    });
});
