import { assert } from "chai";

import { BehaviourTree, BehaviourTreeOptions, NodeDetails } from "../src/index";
import { RootNodeDefinition } from "../src/BehaviourTreeDefinition";
import { Agent } from "../src/Agent";

/**
 * A mapping of agent function names to functions that get the result of a call from the number of times that function has been called.
 */
export type AgentResults = { [functionName: string]: (callCount: number) => any };

/**
 * A seeded pseudo-random number generator that can be forked to continue from its current position.
 */
export class SeededRandom {
    constructor(private seed: number) {}

    next(): number {
        let t = (this.seed += 0x6d2b79f5);
        t = Math.imul(t ^ (t >>> 15), t | 1);
        t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
        return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    }

    clone(): SeededRandom {
        return new SeededRandom(this.seed);
    }
}

/**
 * Creates an agent whose functions log each call and get their result from the number of times they have been called.
 * @param results The functions to define on the agent and the results they return.
 * @param callCounts The number of times that each function has been called, which is the agent state.
 * @param log The log that function calls are added to.
 */
export function createAgent(results: AgentResults, callCounts: { [name: string]: number }, log: string[]): Agent {
    const agent: Agent = {};

    for (const [name, getResult] of Object.entries(results)) {
        agent[name] = () => {
            callCounts[name] = (callCounts[name] ?? 0) + 1;
            log.push(name);
            return getResult(callCounts[name]);
        };
    }

    return agent;
}

/**
 * Gets the details of a node and all of its children without the unique ids, which differ between tree instances.
 */
export function getComparableDetails(node: NodeDetails): any {
    const { id, children, ...details } = node;
    return { ...details, children: children?.map(getComparableDetails) };
}

/**
 * Makes a copy of a snapshot, as it would be after being stored somewhere and loaded again.
 */
export function throughJSON<T>(value: T): T {
    return JSON.parse(JSON.stringify(value));
}

/**
 * For every step at which a tree could be snapshotted, asserts that a new tree restored from the snapshot, given a copy of the agent
 * state, carries on exactly like the tree the snapshot was taken from: the same node states, the same agent function calls in the same order.
 * @param definition The tree definition.
 * @param results The agent function results.
 * @param options.totalSteps The total number of steps to take.
 * @param options.getTreeOptions Gets the tree options, given a function to use for random numbers.
 * @param options.afterStep A function called after each step, to advance time for example.
 */
export function assertRestoredTreeMatchesOriginalFromEveryStep(
    definition: string | RootNodeDefinition | RootNodeDefinition[],
    results: AgentResults,
    {
        totalSteps = 12,
        getTreeOptions = (random: () => number) => ({ random }),
        afterStep = () => {}
    }: {
        totalSteps?: number;
        getTreeOptions?: (random: () => number) => BehaviourTreeOptions;
        afterStep?: () => void;
    } = {}
): void {
    for (let stepsBeforeSnapshot = 0; stepsBeforeSnapshot <= totalSteps; stepsBeforeSnapshot++) {
        const context = `with a snapshot taken after ${stepsBeforeSnapshot} steps`;

        const random = new SeededRandom(7);
        const callCounts = {};
        const log: string[] = [];
        const original = new BehaviourTree(
            definition,
            createAgent(results, callCounts, log),
            getTreeOptions(() => random.next())
        );

        for (let step = 0; step < stepsBeforeSnapshot; step++) {
            original.step();
            afterStep();
        }

        const snapshot = throughJSON(original.snapshot());

        // The restored tree gets its own agent in the same state as the original agent, and a random function in the same position.
        const restoredRandom = random.clone();
        const restoredCallCounts = { ...callCounts };
        const restoredLog: string[] = [];
        const restored = new BehaviourTree(
            definition,
            createAgent(results, restoredCallCounts, restoredLog),
            getTreeOptions(() => restoredRandom.next())
        );

        restored.restore(snapshot);

        assert.deepEqual(
            getComparableDetails(restored.getTreeNodeDetails()),
            getComparableDetails(original.getTreeNodeDetails()),
            `node details differ immediately after restoring ${context}`
        );
        assert.deepEqual(
            restored.snapshot(),
            original.snapshot(),
            `snapshots differ immediately after restoring ${context}`
        );

        log.length = 0;

        for (let step = stepsBeforeSnapshot; step < totalSteps; step++) {
            original.step();
            restored.step();
            afterStep();

            assert.deepEqual(
                getComparableDetails(restored.getTreeNodeDetails()),
                getComparableDetails(original.getTreeNodeDetails()),
                `node details differ after step ${step + 1} ${context}`
            );
            assert.deepEqual(restoredLog, log, `agent function calls differ after step ${step + 1} ${context}`);
            assert.strictEqual(restored.getState(), original.getState());
            assert.deepEqual(
                restored.snapshot(),
                original.snapshot(),
                `snapshots differ after step ${step + 1} ${context}`
            );
        }
    }
}
