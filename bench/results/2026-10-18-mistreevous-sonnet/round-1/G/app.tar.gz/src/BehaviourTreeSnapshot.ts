import { AnyState } from "./State";
import { RootNodeDefinition } from "./BehaviourTreeDefinition";

/**
 * A snapshot of the execution state of a single node in a behaviour tree.
 * A node snapshot is a plain object that survives JSON serialisation unchanged.
 */
export type NodeSnapshot = {
    /**
     * The node type.
     */
    type: string;
    /**
     * The state of the node.
     */
    state: AnyState;
    /**
     * The snapshots of the child nodes, in definition order. Defined for composite and decorator nodes.
     */
    children?: NodeSnapshot[];
    /**
     * The number of iterations that a repeat node will make, or null if it will repeat indefinitely. Defined for repeat nodes.
     * This is the number that was chosen at random if the node was defined with minimum and maximum iterations.
     */
    targetIterationCount?: number | null;
    /**
     * The number of iterations that a repeat node has completed. Defined for repeat nodes.
     */
    currentIterationCount?: number;
    /**
     * The number of attempts that a retry node will make, or null if it will retry indefinitely. Defined for retry nodes.
     * This is the number that was chosen at random if the node was defined with minimum and maximum attempts.
     */
    targetAttemptCount?: number | null;
    /**
     * The number of attempts that a retry node has made. Defined for retry nodes.
     */
    currentAttemptCount?: number;
    /**
     * The index of the child that a lotto node picked, or null if it has not picked one. Defined for lotto nodes.
     */
    selectedChildIndex?: number | null;
    /**
     * The total duration in milliseconds that a wait node will wait for, or null if it will wait indefinitely. Defined for wait nodes.
     * This is the duration that was chosen at random if the node was defined with minimum and maximum durations.
     */
    totalDuration?: number | null;
    /**
     * The duration in milliseconds that a wait node has waited for, up until the time that the snapshot was taken. Defined for wait nodes.
     */
    waitedDuration?: number;
    /**
     * The result of a promise that an action node is waiting on, if it settled but has not been handled by a step of the tree yet,
     * otherwise null. Defined for action nodes. The value is the resolved state, or the string representation of an invalid resolved
     * value or rejection reason. A promise that has not settled cannot be part of a snapshot, so an action node that is waiting on
     * one is recorded with a state of READY, as if it had not started, and will call its agent function again on the next step of
     * a restored tree.
     */
    updatePromiseResult?: { isResolved: boolean; value: string } | null;
};

/**
 * A snapshot of the execution state of a behaviour tree, as returned by `BehaviourTree.snapshot()`.
 * A snapshot is a plain object that survives JSON serialisation unchanged, and can be used to restore a tree
 * that was built from the same definition via `BehaviourTree.restore()`.
 */
export type BehaviourTreeSnapshot = {
    /**
     * The snapshot format version.
     */
    version: 1;
    /**
     * The identifier of the definition of the tree that the snapshot was taken from, which is the same for an MDSL definition
     * and the equivalent JSON definition. A snapshot can only be restored to a tree with a matching definition identifier.
     */
    definition: string;
    /**
     * The snapshot of the root node, which mirrors the structure of the tree.
     */
    root: NodeSnapshot;
};

/**
 * The current snapshot format version.
 */
export const SNAPSHOT_VERSION = 1;

/**
 * Validates that a snapshot property is a finite, non-negative number, optionally an integer and optionally null.
 * @param snapshot The node snapshot.
 * @param property The name of the property to validate.
 * @param path The path of the node in the snapshot, for use in error messages.
 * @param options Whether the number has to be an integer and whether it can be null.
 */
export function validateSnapshotNumber(
    snapshot: NodeSnapshot,
    property: keyof NodeSnapshot,
    path: string,
    { isInteger = false, isNullable = false } = {}
) {
    const value = snapshot[property];

    if (isNullable && value === null) {
        return;
    }

    if (typeof value === "number" && Number.isFinite(value) && value >= 0 && (!isInteger || Number.isInteger(value))) {
        return;
    }

    throw new Error(
        `invalid snapshot: expected '${property}' to be a non-negative ${isInteger ? "integer" : "number"}${
            isNullable ? " or null" : ""
        } at '${path}'`
    );
}

/**
 * Gets an identifier for a tree definition, which is the same for definitions that are equivalent, such as an MDSL definition and
 * the JSON definition that it converts to. Two definitions are equivalent if they have the same nodes, attributes and arguments,
 * regardless of the order of properties and root nodes, and regardless of whether empty arguments and a 'succeedOnAbort' of false
 * were left out. The identifier does not include globally registered subtrees, which are not part of the definition.
 * @param rootNodeDefinitions The validated root node definitions of the tree.
 * @returns The definition identifier.
 */
export function getDefinitionId(rootNodeDefinitions: RootNodeDefinition[]): string {
    const canonicalise = (value: unknown): unknown => {
        if (Array.isArray(value)) {
            return value.map(canonicalise);
        }

        if (typeof value === "object" && value !== null) {
            return Object.fromEntries(
                Object.entries(value)
                    .filter(([key, property]) => {
                        const isDefault =
                            (key === "args" && Array.isArray(property) && property.length === 0) ||
                            (key === "succeedOnAbort" && property === false);

                        return property !== undefined && !isDefault;
                    })
                    .sort(([keyA], [keyB]) => (keyA < keyB ? -1 : 1))
                    .map(([key, property]) => [key, canonicalise(property)])
            );
        }

        return value;
    };

    // The order of the root nodes has no effect on the tree, so sort them.
    const canonicalRootNodes = rootNodeDefinitions
        .map((rootNodeDefinition) => JSON.stringify(canonicalise(rootNodeDefinition)))
        .sort();

    return hash(JSON.stringify(canonicalRootNodes));
}

/**
 * Gets a 53 bit hash of a string as a hex string, using cyrb53.
 */
function hash(value: string): string {
    let h1 = 0xdeadbeef;
    let h2 = 0x41c6ce57;

    for (let index = 0; index < value.length; index++) {
        const code = value.charCodeAt(index);

        h1 = Math.imul(h1 ^ code, 2654435761);
        h2 = Math.imul(h2 ^ code, 1597334677);
    }

    h1 = Math.imul(h1 ^ (h1 >>> 16), 2246822507) ^ Math.imul(h2 ^ (h2 >>> 13), 3266489909);
    h2 = Math.imul(h2 ^ (h2 >>> 16), 2246822507) ^ Math.imul(h1 ^ (h1 >>> 13), 3266489909);

    return (4294967296 * (2097151 & h2) + (h1 >>> 0)).toString(16);
}
