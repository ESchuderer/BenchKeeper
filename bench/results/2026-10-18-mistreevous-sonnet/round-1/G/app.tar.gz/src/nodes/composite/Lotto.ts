import createLotto from "lotto-draw";

import Node from "../Node";
import { NodeSnapshot } from "../../BehaviourTreeSnapshot";
import Composite from "./Composite";
import State from "../../State";
import { Agent } from "../../Agent";
import Attribute from "../../attributes/Attribute";
import { BehaviourTreeOptions } from "../../BehaviourTreeOptions";

/**
 * A LOTTO node.
 * A winning child is picked on the initial update of this node, based on ticket weighting.
 * The state of this node will match the state of the winning child.
 */
export default class Lotto extends Composite {
    /**
     * @param attributes The node attributes.
     * @param options The behaviour tree options.
     * @param weights The child node weights.
     * @param children The child nodes.
     */
    constructor(
        attributes: Attribute[],
        options: BehaviourTreeOptions,
        private weights: number[] | undefined,
        children: Node[]
    ) {
        super("lotto", attributes, options, children);
    }

    /**
     * The child node selected to be the active one.
     */
    private selectedChild: Node | undefined;

    /**
     * Called when the node is being updated.
     * @param agent The agent.
     */
    protected onUpdate(agent: Agent): void {
        // If this node is in the READY state then we need to pick a winning child node.
        if (this.is(State.READY)) {
            // Create a lotto draw with which to randomly pick a child node to become the active one.
            const lottoDraw = createLotto<Node>({
                // Hook up the optional 'random' behaviour tree function option to the one used by 'lotto-draw'.
                random: this.options.random,
                // Pass in each child node as a participant in the lotto draw with their respective ticket count.
                participants: this.children.map((child, index) => [child, this.weights?.[index] || 1])
            });

            // Randomly pick a child based on ticket weighting, this will become the active child for this composite node.
            this.selectedChild = lottoDraw.draw() || undefined;
        }

        // If something went wrong and we don't have an active child then we should throw an error.
        if (!this.selectedChild) {
            throw new Error("failed to update lotto node as it has no active child");
        }

        // If the selected child has never been updated or is running then we will need to update it now.
        if (this.selectedChild.getState() === State.READY || this.selectedChild.getState() === State.RUNNING) {
            this.selectedChild.update(agent);
        }

        // The state of the lotto node is the state of its selected child.
        this.setState(this.selectedChild.getState());
    }

    /**
     * Gets the name of the node.
     */
    getName = () => (this.weights ? `LOTTO [${this.weights.join(",")}]` : "LOTTO");

    /**
     * Gets a snapshot of the execution state of this node.
     * @returns A snapshot of the execution state of this node, as a plain object.
     */
    public getSnapshot(): NodeSnapshot {
        const selectedChildIndex = this.selectedChild ? this.children.indexOf(this.selectedChild) : -1;

        return {
            ...super.getSnapshot(),
            selectedChildIndex: selectedChildIndex === -1 ? null : selectedChildIndex
        };
    }

    /**
     * Validates that a snapshot can be restored to this node, throwing an error if it cannot. This does not change the node.
     * @param snapshot The snapshot to validate.
     * @param path The path of this node in the snapshot, for use in error messages.
     */
    public validateSnapshot(snapshot: NodeSnapshot, path: string): void {
        super.validateSnapshot(snapshot, path);

        const { selectedChildIndex, state } = snapshot;

        if (selectedChildIndex === null) {
            // A lotto node that has been updated has always picked a child.
            if (state !== State.READY) {
                throw new Error(
                    `invalid snapshot: expected 'selectedChildIndex' to be defined for a node with a state of '${state}' at '${path}'`
                );
            }
        } else if (
            typeof selectedChildIndex !== "number" ||
            !Number.isInteger(selectedChildIndex) ||
            selectedChildIndex < 0 ||
            selectedChildIndex >= this.children.length
        ) {
            throw new Error(
                `invalid snapshot: expected 'selectedChildIndex' to be the index of a child or null at '${path}'`
            );
        }
    }

    /**
     * Restores this node to the execution state in a snapshot, which must have been validated.
     * @param snapshot The snapshot to restore.
     */
    public restoreSnapshot(snapshot: NodeSnapshot): void {
        super.restoreSnapshot(snapshot);

        this.selectedChild =
            snapshot.selectedChildIndex === null ? undefined : this.children[snapshot.selectedChildIndex!];
    }
}
