import { assert } from "chai";
import sinon, { SinonFakeTimers } from "sinon";

import { BehaviourTree, State, convertMDSLToJSON } from "../src/index";
import type { BehaviourTreeSnapshot, BehaviourTreeOptions, NodeDetails } from "../src/index";
import { findNode } from "./TestUtilities";

/**
 * A script of results for the actions of a test agent, keyed by action name.
 * An action with an undefined result stays in the RUNNING state, and one with a promise result stays in the RUNNING state until the promise settles.
 */
type Script = { [actionName: string]: State.SUCCEEDED | State.FAILED | Promise<any> | undefined };

/**
 * A behaviour tree along with the log of the agent function calls made on its behalf.
 */
type Run = { tree: BehaviourTree; log: string[] };

/**
 * Create a behaviour tree whose agent logs every action, condition, guard and callback function call.
 * @param definition The tree definition.
 * @param script The action results, which can be changed by a test at any time.
 * @param options The behaviour tree options.
 */
function createRun(definition: string | object, script: Script, options: BehaviourTreeOptions = {}): Run {
    const log: string[] = [];

    const agent = new Proxy(
        {},
        {
            get: (_, name: string) => () => {
                log.push(name);

                // Conditions and guards are named 'Is...', everything else is an action or callback.
                return name.startsWith("Is") ? script[name] !== State.FAILED : script[name];
            }
        }
    );

    return { tree: new BehaviourTree(definition as string, agent, options), log };
}

/**
 * Takes a snapshot of the tree, checking that it survives a trip through JSON unchanged.
 */
function takeSnapshot(tree: BehaviourTree): BehaviourTreeSnapshot {
    const snapshot = tree.snapshot();
    const parsed = JSON.parse(JSON.stringify(snapshot));

    assert.deepStrictEqual(parsed, snapshot, "snapshot should be unchanged by a JSON round trip");

    return parsed;
}

/**
 * Creates a new run from the same definition, restored from a JSON round-tripped snapshot of the source run.
 * The log of the source run is cleared so that the two logs can be compared from this point on.
 */
function forkRun(source: Run, definition: string, script: Script, options: BehaviourTreeOptions = {}): Run {
    const snapshot = takeSnapshot(source.tree);

    const fork = createRun(definition, script, options);
    fork.tree.restore(snapshot);

    source.log.length = 0;

    return fork;
}

/**
 * Gets the details of every node without the node ids, which are different for every tree instance.
 */
function withoutIds(details: NodeDetails): object {
    const { id, children, ...rest } = details;

    return { ...rest, children: children?.map(withoutIds) };
}

/**
 * Asserts that two runs have the same node states and have made the same agent function calls.
 */
function assertSameBehaviour(original: Run, restored: Run) {
    assert.deepStrictEqual(
        withoutIds(restored.tree.getTreeNodeDetails()),
        withoutIds(original.tree.getTreeNodeDetails())
    );
    assert.deepStrictEqual(restored.log, original.log);
}

/**
 * Steps both runs and asserts that they behave the same.
 */
function stepBoth(original: Run, restored: Run) {
    original.tree.step();
    restored.tree.step();

    assertSameBehaviour(original, restored);
}

describe("A behaviour tree snapshot", () => {
    describe("is taken with snapshot() and", () => {
        it("is a plain object that is unchanged by a JSON round trip, for a tree that has not been stepped", () => {
            const { tree } = createRun("root { sequence { action [A] wait [100] } }", {});

            takeSnapshot(tree);
        });

        it("is a plain object that is unchanged by a JSON round trip, for a tree in the middle of a run", () => {
            const { tree } = createRun(
                `root {
                    parallel {
                        repeat [2, 4] { sequence { action [A] action [B] } }
                        retry { lotto { action [C] action [D] } }
                        wait [100, 500]
                        flip { condition [IsE] }
                    }
                }`,
                { A: State.SUCCEEDED, B: State.SUCCEEDED, C: State.FAILED }
            );

            tree.step();
            tree.step();

            takeSnapshot(tree);
        });

        it("is a new object every time", () => {
            const { tree } = createRun("root { action [A] }", {});

            assert.notStrictEqual(tree.snapshot(), tree.snapshot());
        });
    });

    describe("is applied with restore() and", () => {
        const definition = "root { sequence { action [Implement] action [Review] action [Approve] } }";

        it("restores the node states of a tree that has not been stepped", () => {
            const script: Script = { Implement: State.SUCCEEDED };
            const original = createRun(definition, script);
            const restored = forkRun(original, definition, script);

            assertSameBehaviour(original, restored);

            stepBoth(original, restored);
        });

        it("resumes the tree from where it was without calling the actions that already finished", () => {
            const script: Script = { Implement: State.SUCCEEDED, Review: State.SUCCEEDED, Approve: undefined };
            const original = createRun(definition, script);

            original.tree.step();

            assert.deepEqual(original.log, ["Implement", "Review", "Approve"]);

            const restored = forkRun(original, definition, script);

            assertSameBehaviour(original, restored);

            // Only the running action should be called when the restored tree is stepped.
            stepBoth(original, restored);
            assert.deepEqual(restored.log, ["Approve"]);

            script.Approve = State.SUCCEEDED;

            stepBoth(original, restored);

            assert.strictEqual(restored.tree.getState(), State.SUCCEEDED);
            assert.strictEqual(original.tree.getState(), State.SUCCEEDED);
        });

        it("restores which children of a parallel node are done and which are running", () => {
            const definition = "root { parallel { action [A] action [B] action [C] } }";
            const script: Script = { A: State.SUCCEEDED, B: undefined, C: undefined };
            const original = createRun(definition, script);

            original.tree.step();

            const restored = forkRun(original, definition, script);

            assertSameBehaviour(original, restored);

            stepBoth(original, restored);
            assert.deepEqual(restored.log, ["B", "C"]);

            script.B = State.SUCCEEDED;
            script.C = State.SUCCEEDED;

            stepBoth(original, restored);

            assert.strictEqual(restored.tree.getState(), State.SUCCEEDED);
        });

        it("restores a selector that has moved on from a failed child", () => {
            const definition = "root { selector { action [A] action [B] action [C] } }";
            const script: Script = { A: State.FAILED, B: undefined };
            const original = createRun(definition, script);

            original.tree.step();

            const restored = forkRun(original, definition, script);

            stepBoth(original, restored);

            script.B = State.FAILED;
            script.C = State.SUCCEEDED;

            stepBoth(original, restored);

            assert.strictEqual(restored.tree.getState(), State.SUCCEEDED);
        });

        it("restores race and all nodes", () => {
            for (const type of ["race", "all"]) {
                const definition = `root { ${type} { action [A] action [B] action [C] } }`;
                const script: Script = { A: State.FAILED, B: undefined, C: undefined };
                const original = createRun(definition, script);

                original.tree.step();

                const restored = forkRun(original, definition, script);

                stepBoth(original, restored);

                script.B = State.SUCCEEDED;
                script.C = State.FAILED;

                stepBoth(original, restored);

                assert.strictEqual(restored.tree.getState(), State.SUCCEEDED, type);
            }
        });

        it("restores decorator nodes", () => {
            for (const type of ["flip", "succeed", "fail"]) {
                const definition = `root { ${type} { sequence { action [A] action [B] } } }`;
                const script: Script = { A: State.SUCCEEDED, B: undefined };
                const original = createRun(definition, script);

                original.tree.step();

                const restored = forkRun(original, definition, script);

                assertSameBehaviour(original, restored);

                script.B = State.FAILED;

                stepBoth(original, restored);

                assert.deepEqual(restored.log, ["B"], type);
                assert.notStrictEqual(restored.tree.getState(), State.RUNNING, type);
            }
        });

        it("does not call the entry function of a node that was already running, but does call its step, exit and guards", () => {
            const definition = `root {
                action [Work] while(IsAllowed) entry(OnEntry) step(OnStep) exit(OnExit)
            }`;
            const script: Script = { Work: undefined };
            const original = createRun(definition, script);

            original.tree.step();

            assert.deepEqual(original.log, ["IsAllowed", "OnEntry", "OnStep", "Work"]);

            const restored = forkRun(original, definition, script);

            stepBoth(original, restored);
            assert.deepEqual(restored.log, ["IsAllowed", "OnStep", "Work"]);

            script.Work = State.SUCCEEDED;
            original.log.length = restored.log.length = 0;

            stepBoth(original, restored);
            assert.deepEqual(restored.log, ["IsAllowed", "OnStep", "Work", "OnExit"]);
        });

        it("restores an aborted guard", () => {
            const definition = `root { sequence { action [Work] while(IsAllowed) action [After] } }`;
            const script: Script = { Work: undefined };
            const original = createRun(definition, script);

            original.tree.step();

            const restored = forkRun(original, definition, script);

            script.IsAllowed = State.FAILED;

            stepBoth(original, restored);

            assert.strictEqual(restored.tree.getState(), State.FAILED);
        });

        it("restores a finished tree as finished, and the next step starts a new run", () => {
            for (const result of [State.SUCCEEDED, State.FAILED] as const) {
                const script: Script = { Implement: State.SUCCEEDED, Review: result, Approve: State.SUCCEEDED };
                const original = createRun(definition, script);

                original.tree.step();

                assert.strictEqual(original.tree.getState(), result);

                const restored = forkRun(original, definition, script);

                assertSameBehaviour(original, restored);
                assert.strictEqual(restored.tree.getState(), original.tree.getState());

                stepBoth(original, restored);
                assert.deepEqual(restored.log.slice(0, 2), ["Implement", "Review"]);
            }
        });

        it("replaces the state of a tree that has already been stepped", () => {
            const script: Script = { Implement: State.SUCCEEDED, Review: undefined };
            const original = createRun(definition, script);

            original.tree.step();

            const target = createRun(definition, { Implement: State.FAILED });

            target.tree.step();

            assert.strictEqual(target.tree.getState(), State.FAILED);

            target.tree.restore(takeSnapshot(original.tree));

            assert.strictEqual(target.tree.getState(), State.RUNNING);
            assert.deepStrictEqual(
                withoutIds(target.tree.getTreeNodeDetails()),
                withoutIds(original.tree.getTreeNodeDetails())
            );
        });

        it("does not call the onNodeStateChange option", () => {
            const changes: unknown[] = [];
            const options = { onNodeStateChange: (change: unknown) => changes.push(change) };
            const script: Script = { Implement: State.SUCCEEDED, Review: undefined };
            const original = createRun(definition, script);

            original.tree.step();

            const restored = createRun(definition, script, options);
            restored.tree.restore(takeSnapshot(original.tree));

            assert.deepEqual(changes, []);
        });

        describe("throws an error, and leaves the tree as it was, if the snapshot", () => {
            const script: Script = { Implement: State.SUCCEEDED, Review: undefined };

            const assertRejected = (modify: (snapshot: any) => any, message: string) => {
                const source = createRun(definition, script);
                source.tree.step();

                const target = createRun(definition, script);
                const before = withoutIds(target.tree.getTreeNodeDetails());

                const modified = modify(takeSnapshot(source.tree));

                assert.throws(() => target.tree.restore(modified), Error, message);
                assert.deepStrictEqual(withoutIds(target.tree.getTreeNodeDetails()), before);
            };

            it("is not an object", () => {
                assertRejected(() => null, "invalid snapshot");
                assertRejected(() => "snapshot", "invalid snapshot");
            });

            it("has an unsupported version", () => {
                assertRejected((snapshot) => ({ ...snapshot, version: 2 }), "unsupported snapshot version");
            });

            it("was taken from a tree with a different node type", () => {
                assertRejected((snapshot) => {
                    snapshot.root.children[0].children[1].type = "condition";
                    return snapshot;
                }, "expected a node of type 'action'");
            });

            it("was taken from a tree with a different number of children", () => {
                assertRejected((snapshot) => {
                    snapshot.root.children[0].children.pop();
                    return snapshot;
                }, "expected 3 children but found 2");
            });

            it("has a node with an invalid state", () => {
                // This is the last node that would be restored, so a restore that applies as it goes would already have changed the tree.
                assertRejected((snapshot) => {
                    snapshot.root.children[0].children[2].state = "nope";
                    return snapshot;
                }, "invalid state");
            });
        });
    });
});

/**
 * Steps both runs, asserting that they behave the same, until the original tree is no longer running.
 * @returns The number of steps that were taken.
 */
function stepBothUntilFinished(original: Run, restored: Run, maxSteps = 100): number {
    let steps = 0;

    while (original.tree.isRunning()) {
        assert.isBelow(steps++, maxSteps, "tree did not finish");

        stepBoth(original, restored);
    }

    assert.isFalse(restored.tree.isRunning());

    return steps;
}

const count = (log: string[], name: string) => log.filter((entry) => entry === name).length;

describe("A behaviour tree snapshot of repeat and retry nodes", () => {
    describe("keeps the iteration count of a repeat node", () => {
        const definition = "root { repeat [3] { action [Work] } }";

        it("so that only the remaining iterations are made", () => {
            const script: Script = { Work: State.SUCCEEDED };
            const original = createRun(definition, script);

            original.tree.step();
            original.tree.step();

            const restored = forkRun(original, definition, script);

            stepBothUntilFinished(original, restored);

            // The original tree made three iterations in total, the restored tree must only have made the last one.
            assert.strictEqual(count(restored.log, "Work"), 1);
            assert.strictEqual(restored.tree.getState(), State.SUCCEEDED);
        });

        it("including for a repeat node without a limit", () => {
            const script: Script = { Work: State.SUCCEEDED };
            const definition = "root { repeat { action [Work] } }";
            const original = createRun(definition, script);

            original.tree.step();
            original.tree.step();

            const restored = forkRun(original, definition, script);

            stepBoth(original, restored);
            stepBoth(original, restored);

            script.Work = State.FAILED;

            stepBoth(original, restored);

            assert.strictEqual(restored.tree.getState(), State.FAILED);
        });
    });

    describe("keeps the attempt count of a retry node", () => {
        it("so that only the remaining attempts are made", () => {
            const definition = "root { retry [3] { action [Work] } }";
            const script: Script = { Work: State.FAILED };
            const original = createRun(definition, script);

            original.tree.step();
            original.tree.step();

            const restored = forkRun(original, definition, script);

            stepBothUntilFinished(original, restored);

            assert.strictEqual(count(restored.log, "Work"), 1);
            assert.strictEqual(restored.tree.getState(), State.FAILED);
        });
    });

    describe("keeps the random iteration or attempt count that was chosen", () => {
        it("for a repeat node", () => {
            const definition = "root { repeat [2, 5] { action [Work] } }";
            const script: Script = { Work: State.SUCCEEDED };

            // The original tree chooses five iterations, but the restored tree would choose two if it chose again.
            const original = createRun(definition, script, { random: () => 0.99 });

            original.tree.step();

            const restored = forkRun(original, definition, script, { random: () => 0 });

            stepBothUntilFinished(original, restored);

            assert.strictEqual(count(restored.log, "Work"), 4);
            assert.strictEqual(restored.tree.getState(), State.SUCCEEDED);
        });

        it("for a retry node", () => {
            const definition = "root { retry [2, 5] { action [Work] } }";
            const script: Script = { Work: State.FAILED };
            const original = createRun(definition, script, { random: () => 0.99 });

            original.tree.step();

            const restored = forkRun(original, definition, script, { random: () => 0 });

            stepBothUntilFinished(original, restored);

            assert.strictEqual(count(restored.log, "Work"), 4);
            assert.strictEqual(restored.tree.getState(), State.FAILED);
        });
    });

    it("makes new random choices when a finished tree is stepped again after being restored", () => {
        const definition = "root { repeat [2, 5] { action [Work] } }";
        const script: Script = { Work: State.SUCCEEDED };
        const random = { value: 0.99 };
        const options = { random: () => random.value };
        const original = createRun(definition, script, options);

        original.tree.step();

        while (original.tree.isRunning()) {
            original.tree.step();
        }

        assert.strictEqual(count(original.log, "Work"), 5);

        random.value = 0;

        const restored = forkRun(original, definition, script, options);

        assert.strictEqual(restored.tree.getState(), State.SUCCEEDED);

        restored.tree.step();
        original.tree.step();

        assert.isTrue(restored.tree.isRunning());

        stepBothUntilFinished(original, restored);

        assert.strictEqual(count(restored.log, "Work"), 2);
    });
});

describe("A behaviour tree snapshot of repeat and retry nodes is rejected if it has", () => {
    const cases = [
        { type: "repeat", property: "currentIterationCount", value: -1 },
        { type: "repeat", property: "currentIterationCount", value: 1.5 },
        { type: "repeat", property: "targetIterationCount", value: "3" },
        { type: "retry", property: "currentAttemptCount", value: null },
        { type: "retry", property: "targetAttemptCount", value: undefined }
    ];

    for (const { type, property, value } of cases) {
        it(`${property} of ${JSON.stringify(value) ?? "undefined"} for a ${type} node`, () => {
            const definition = `root { ${type} [3] { action [Work] } }`;
            const { tree } = createRun(definition, { Work: undefined });

            tree.step();

            const snapshot: any = takeSnapshot(tree);
            snapshot.root.children[0][property] = value;

            assert.throws(() => tree.restore(snapshot), Error, `expected '${property}' to be a non-negative integer`);
        });
    }
});

describe("A behaviour tree snapshot of a lotto node", () => {
    const definition = "root { lotto [1, 1, 1] { action [A] action [B] action [C] } }";

    it("keeps the child that was picked, instead of picking again", () => {
        const script: Script = { A: undefined, B: undefined, C: undefined };

        // The original tree picks the last child, but the restored tree would pick the first if it picked again.
        const original = createRun(definition, script, { random: () => 0.99 });

        original.tree.step();

        assert.deepEqual(original.log, ["C"]);

        const restored = forkRun(original, definition, script, { random: () => 0 });

        assertSameBehaviour(original, restored);

        stepBoth(original, restored);
        assert.deepEqual(restored.log, ["C"]);

        script.C = State.SUCCEEDED;

        stepBoth(original, restored);

        assert.strictEqual(restored.tree.getState(), State.SUCCEEDED);
    });

    it("picks again after being restored in a finished state, when the tree is stepped again", () => {
        const script: Script = { A: State.SUCCEEDED, B: State.SUCCEEDED, C: State.SUCCEEDED };
        const random = { value: 0.99 };
        const options = { random: () => random.value };
        const original = createRun(definition, script, options);

        original.tree.step();

        assert.deepEqual(original.log, ["C"]);
        assert.strictEqual(original.tree.getState(), State.SUCCEEDED);

        random.value = 0;

        const restored = forkRun(original, definition, script, options);

        stepBoth(original, restored);

        assert.deepEqual(restored.log, ["A"]);
    });

    describe("is rejected if the picked child", () => {
        for (const value of [-1, 3, 1.5, "1", undefined]) {
            it(`is ${JSON.stringify(value) ?? "undefined"}`, () => {
                const { tree } = createRun(definition, {});

                tree.step();

                const snapshot: any = takeSnapshot(tree);
                snapshot.root.children[0].selectedChildIndex = value;

                assert.throws(
                    () => tree.restore(snapshot),
                    Error,
                    "expected 'selectedChildIndex' to be the index of a child or null"
                );
            });
        }
    });
});

describe("A behaviour tree snapshot of a lotto node that is rejected if it", () => {
    it("has no picked child but has been updated", () => {
        const { tree } = createRun("root { lotto { action [A] action [B] } }", {});

        tree.step();

        const snapshot: any = takeSnapshot(tree);
        snapshot.root.children[0].selectedChildIndex = null;

        assert.throws(() => tree.restore(snapshot), Error, "expected 'selectedChildIndex' to be defined");
    });
});

describe("A behaviour tree snapshot of a wait node", () => {
    let clock: SinonFakeTimers;

    beforeEach(() => {
        clock = sinon.useFakeTimers();
    });

    afterEach(() => {
        clock.restore();
    });

    describe("using the clock", () => {
        const definition = "root { wait [1000] }";

        it("keeps how long the node has waited, and not the time that passed before it was restored", () => {
            const original = createRun(definition, {});

            original.tree.step();

            clock.tick(400);

            // There is no step between the time passing and the snapshot, the time still has to count as the node has been waiting.
            const snapshot = takeSnapshot(original.tree);

            // This is a lot more than the remaining duration.
            clock.tick(100000);

            const restored = createRun(definition, {});
            restored.tree.restore(snapshot);

            assert.strictEqual(restored.tree.getState(), State.RUNNING);

            restored.tree.step();

            assert.strictEqual(restored.tree.getState(), State.RUNNING);

            clock.tick(599);
            restored.tree.step();

            assert.strictEqual(restored.tree.getState(), State.RUNNING);

            clock.tick(1);
            restored.tree.step();

            assert.strictEqual(restored.tree.getState(), State.SUCCEEDED);
        });

        it("keeps a wait that is running as part of a larger tree", () => {
            const definition = "root { sequence { action [Before] wait [1000] action [After] } }";
            const script: Script = { Before: State.SUCCEEDED, After: State.SUCCEEDED };
            const original = createRun(definition, script);

            original.tree.step();

            clock.tick(900);

            const snapshot = takeSnapshot(original.tree);

            clock.tick(50000);

            const restored = createRun(definition, script);
            restored.tree.restore(snapshot);

            restored.tree.step();

            assert.deepEqual(restored.log, []);
            assert.strictEqual(restored.tree.getState(), State.RUNNING);

            clock.tick(100);
            restored.tree.step();

            assert.deepEqual(restored.log, ["After"]);
            assert.strictEqual(restored.tree.getState(), State.SUCCEEDED);
        });

        it("keeps the random duration that was chosen, instead of choosing again", () => {
            const definition = "root { wait [1000, 5000] }";

            // The original tree chooses a duration of 4960ms, but the restored tree would choose 1000ms if it chose again.
            const original = createRun(definition, {}, { random: () => 0.99 });

            original.tree.step();

            clock.tick(1000);

            const snapshot = takeSnapshot(original.tree);

            clock.tick(100000);

            const restored = createRun(definition, {}, { random: () => 0 });
            restored.tree.restore(snapshot);

            restored.tree.step();

            assert.strictEqual(restored.tree.getState(), State.RUNNING);

            clock.tick(3959);
            restored.tree.step();

            assert.strictEqual(restored.tree.getState(), State.RUNNING);

            clock.tick(1);
            restored.tree.step();

            assert.strictEqual(restored.tree.getState(), State.SUCCEEDED);
        });

        it("keeps a wait without a duration waiting indefinitely", () => {
            const definition = "root { wait }";
            const original = createRun(definition, {});

            original.tree.step();

            const restored = createRun(definition, {});
            restored.tree.restore(takeSnapshot(original.tree));

            clock.tick(1000000);
            restored.tree.step();

            assert.strictEqual(restored.tree.getState(), State.RUNNING);
        });

        it("is restored as finished if the wait had finished, and the next step starts waiting again", () => {
            const definition = "root { wait [1000] }";
            const original = createRun(definition, {});

            original.tree.step();

            clock.tick(1000);
            original.tree.step();

            assert.strictEqual(original.tree.getState(), State.SUCCEEDED);

            const snapshot = takeSnapshot(original.tree);

            clock.tick(5000);

            const restored = createRun(definition, {});
            restored.tree.restore(snapshot);

            assert.strictEqual(restored.tree.getState(), State.SUCCEEDED);

            restored.tree.step();

            assert.strictEqual(restored.tree.getState(), State.RUNNING);

            clock.tick(999);
            restored.tree.step();

            assert.strictEqual(restored.tree.getState(), State.RUNNING);

            clock.tick(1);
            restored.tree.step();

            assert.strictEqual(restored.tree.getState(), State.SUCCEEDED);
        });
    });

    describe("using the getDeltaTime option", () => {
        const definition = "root { wait [1000] }";

        it("keeps how long the node has waited, and not the time that passed before it was restored", () => {
            const deltaTime = { value: 0.4 };
            const options = { getDeltaTime: () => deltaTime.value };
            const original = createRun(definition, {}, options);

            original.tree.step();

            const snapshot = takeSnapshot(original.tree);

            clock.tick(100000);

            const restored = createRun(definition, {}, options);
            restored.tree.restore(snapshot);

            deltaTime.value = 0.5;

            stepBoth(original, restored);

            assert.strictEqual(restored.tree.getState(), State.RUNNING);

            deltaTime.value = 0.1;

            stepBoth(original, restored);

            assert.strictEqual(restored.tree.getState(), State.SUCCEEDED);
        });

        it("keeps the random duration that was chosen, instead of choosing again", () => {
            const definition = "root { wait [1000, 5000] }";
            const options = { getDeltaTime: () => 1 };
            const original = createRun(definition, {}, { ...options, random: () => 0.99 });

            original.tree.step();

            const restored = createRun(definition, {}, { ...options, random: () => 0 });
            restored.tree.restore(takeSnapshot(original.tree));

            // The chosen duration is 4960ms, so four more steps of 1000ms are not enough.
            for (let step = 0; step < 3; step++) {
                restored.tree.step();
            }

            assert.strictEqual(restored.tree.getState(), State.RUNNING);

            restored.tree.step();

            assert.strictEqual(restored.tree.getState(), State.SUCCEEDED);
        });
    });

    describe("is rejected if it has", () => {
        const cases = [
            { property: "totalDuration", value: -1 },
            { property: "totalDuration", value: "1000" },
            { property: "totalDuration", value: undefined },
            { property: "waitedDuration", value: -1 },
            { property: "waitedDuration", value: null },
            { property: "waitedDuration", value: undefined }
        ];

        for (const { property, value } of cases) {
            it(`${property} of ${JSON.stringify(value) ?? "undefined"}`, () => {
                const { tree } = createRun("root { wait [1000] }", {});

                tree.step();

                const snapshot: any = takeSnapshot(tree);
                snapshot.root.children[0][property] = value;

                assert.throws(
                    () => tree.restore(snapshot),
                    Error,
                    `expected '${property}' to be a non-negative number`
                );
            });
        }
    });
});

/**
 * Waits for any settled promises to have been handled.
 */
const flushPromises = () => new Promise((resolve) => setImmediate(resolve));

describe("A behaviour tree snapshot of an action node that returned a promise", () => {
    const definition = "root { sequence { action [Work] action [After] } }";

    it("restores a promise that has not settled as an action that has not started, which is called again", async () => {
        const script: Script = { Work: new Promise(() => {}) };
        const original = createRun(definition, script);

        original.tree.step();

        assert.strictEqual(findNode(original.tree, "action", "Work").state, State.RUNNING);

        const restored = forkRun(original, definition, script);

        assert.strictEqual(findNode(restored.tree, "action", "Work").state, State.READY);
        assert.strictEqual(restored.tree.getState(), State.RUNNING);

        // The promise can't be restored, so the action function has to be called again to get a new one.
        script.Work = Promise.resolve(State.SUCCEEDED);
        script.After = State.SUCCEEDED;
        restored.log.length = 0;

        restored.tree.step();

        assert.deepEqual(restored.log, ["Work"]);
        assert.strictEqual(restored.tree.getState(), State.RUNNING);

        await flushPromises();
        restored.tree.step();

        assert.deepEqual(restored.log, ["Work", "After"]);
        assert.strictEqual(restored.tree.getState(), State.SUCCEEDED);
    });

    it("restores a promise that has not settled as an action that calls its entry function again", () => {
        const entryDefinition = "root { action [Work] entry(OnEntry) }";
        const script: Script = { Work: new Promise(() => {}) };
        const original = createRun(entryDefinition, script);

        original.tree.step();

        assert.deepEqual(original.log, ["OnEntry", "Work"]);

        const restored = forkRun(original, entryDefinition, script);

        restored.tree.step();

        assert.deepEqual(restored.log, ["OnEntry", "Work"]);
    });

    it("restores a promise that has not settled as an action that has not started, in the tree it was taken from", () => {
        const script: Script = { Work: new Promise(() => {}) };
        const { tree, log } = createRun(definition, script);

        tree.step();
        tree.restore(takeSnapshot(tree));

        assert.strictEqual(findNode(tree, "action", "Work").state, State.READY);

        tree.step();

        assert.deepEqual(log, ["Work", "Work"]);
    });

    it("restores a promise that resolved but has not been handled by a step yet", async () => {
        const script: Script = { Work: Promise.resolve(State.SUCCEEDED), After: State.SUCCEEDED };
        const original = createRun(definition, script);

        original.tree.step();

        await flushPromises();

        const restored = forkRun(original, definition, script);

        // The action function must not be called again, as the original tree would not have.
        stepBoth(original, restored);

        assert.deepEqual(restored.log, ["After"]);
        assert.strictEqual(restored.tree.getState(), State.SUCCEEDED);
    });

    it("restores a promise that resolved with an invalid value but has not been handled by a step yet", async () => {
        const script: Script = { Work: Promise.resolve("nonsense") };
        const original = createRun(definition, script);

        original.tree.step();

        await flushPromises();

        const restored = forkRun(original, definition, script);

        for (const { tree } of [original, restored]) {
            assert.throws(() => tree.step(), Error, "promise resolved with an invalid value");
        }
    });

    it("restores a promise that rejected but has not been handled by a step yet", async () => {
        for (const reason of [new Error("boom"), "boom"]) {
            const script: Script = { Work: Promise.reject(reason) };
            const original = createRun(definition, script);

            original.tree.step();

            await flushPromises();

            const restored = forkRun(original, definition, script);
            const message = `action function 'Work' promise rejected with '${reason}'`;

            for (const { tree } of [original, restored]) {
                assert.throws(() => tree.step(), Error, message);
            }
        }
    });

    it("is not affected by a promise from before the tree was restored settling afterwards", async () => {
        let resolveFirst: (state: State.SUCCEEDED) => void = () => {};
        let resolveSecond: (state: State.SUCCEEDED) => void = () => {};

        const script: Script = { Work: new Promise((resolve) => (resolveFirst = resolve)), After: State.SUCCEEDED };
        const { tree, log } = createRun(definition, script);

        tree.step();

        const snapshot = takeSnapshot(tree);

        // Restore the same tree, which will call the action function again.
        tree.restore(snapshot);

        script.Work = new Promise((resolve) => (resolveSecond = resolve));
        tree.step();

        assert.deepEqual(log, ["Work", "Work"]);

        // The promise that the restore replaced settles first, which should do nothing.
        resolveFirst(State.SUCCEEDED);

        await flushPromises();
        tree.step();

        assert.strictEqual(tree.getState(), State.RUNNING);
        assert.deepEqual(log, ["Work", "Work"]);

        resolveSecond(State.SUCCEEDED);

        await flushPromises();
        tree.step();

        assert.strictEqual(tree.getState(), State.SUCCEEDED);
        assert.deepEqual(log, ["Work", "Work", "After"]);
    });

    describe("is rejected if it has an updatePromiseResult that is", () => {
        const cases = [
            { updatePromiseResult: undefined },
            { updatePromiseResult: "resolved" },
            { updatePromiseResult: { isResolved: "yes", value: "mistreevous.succeeded" } },
            { updatePromiseResult: { isResolved: true, value: undefined } },
            { updatePromiseResult: { isResolved: true } }
        ];

        for (const { updatePromiseResult } of cases) {
            it(JSON.stringify(updatePromiseResult) ?? "undefined", () => {
                const { tree } = createRun("root { action [Work] }", { Work: new Promise(() => {}) });

                tree.step();

                const snapshot: any = takeSnapshot(tree);
                snapshot.root.children[0].updatePromiseResult = updatePromiseResult;

                assert.throws(() => tree.restore(snapshot), Error, "expected 'updatePromiseResult' to be null or");
            });
        }
    });
});

describe("A restored behaviour tree behaves exactly as the tree the snapshot was taken from", () => {
    const definition = `root {
        sequence {
            action [Implement]
            retry [1, 4] {
                sequence {
                    action [Review]
                    condition [IsReviewClean]
                }
            }
            parallel {
                repeat [2, 4] {
                    sequence {
                        action [RunCi]
                        wait [100, 300]
                    }
                }
                lotto [1, 2] {
                    action [NotifyTeam]
                    action [NotifyChannel]
                }
            }
            race {
                sequence {
                    wait [400]
                    action [Escalate]
                }
                action [WaitForApproval] while(IsRequestOpen) entry(OnWaiting) exit(OnApproved)
            }
        }
    }`;

    const STEP_MILLISECONDS = 50;
    const LAST_STEP = 60;

    /** The results of the agent functions, as a function of the step number so that every replay is the same. */
    const applyScript = (script: Script, step: number) => {
        script.Implement = step < 2 ? undefined : State.SUCCEEDED;
        script.Review = step % 7 < 3 ? undefined : step % 2 ? State.SUCCEEDED : State.FAILED;
        script.RunCi = step % 5 < 2 ? undefined : step % 3 ? State.SUCCEEDED : State.FAILED;
        script.WaitForApproval = step < 40 ? undefined : State.SUCCEEDED;
        script.IsRequestOpen = step < 55 ? State.SUCCEEDED : State.FAILED;
        script.NotifyTeam = step % 4 < 2 ? undefined : State.SUCCEEDED;
        script.NotifyChannel = step % 3 === 0 ? undefined : State.SUCCEEDED;
    };

    /** A seeded random function with a state that can be copied, so that a restored tree can continue the same sequence. */
    const createRandom = (seed: number) => {
        const state = { seed };

        const random = () => {
            // Mulberry32.
            let t = (state.seed += 0x6d2b79f5);
            t = Math.imul(t ^ (t >>> 15), t | 1);
            t ^= t + Math.imul(t ^ (t >>> 7), t | 61);

            return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
        };

        return { random, copy: () => createRandom(state.seed) };
    };

    for (const timing of ["getDeltaTime", "clock"]) {
        describe(`when waiting is timed by ${timing}`, () => {
            let clock: SinonFakeTimers;

            beforeEach(() => {
                clock = sinon.useFakeTimers();
            });

            afterEach(() => {
                clock.restore();
            });

            const getOptions = (random: () => number): BehaviourTreeOptions =>
                timing === "getDeltaTime" ? { random, getDeltaTime: () => STEP_MILLISECONDS / 1000 } : { random };

            const advanceTime = () => (timing === "clock" ? clock.tick(STEP_MILLISECONDS) : undefined);

            it("at every point of a run that is long enough to finish and start again", () => {
                for (const seed of [1, 2, 3, 4]) {
                    let finishedCount = 0;

                    for (let snapshotStep = 0; snapshotStep <= LAST_STEP; snapshotStep++) {
                        // Replay the original tree up to the point that the snapshot is taken at.
                        clock.setSystemTime(0);

                        const script: Script = {};
                        const random = createRandom(seed);
                        const original = createRun(definition, script, getOptions(random.random));

                        for (let step = 0; step < snapshotStep; step++) {
                            applyScript(script, step);
                            advanceTime();
                            original.tree.step();
                        }

                        const restoredRandom = random.copy();
                        const restored = forkRun(original, definition, script, getOptions(restoredRandom.random));

                        assertSameBehaviour(original, restored);

                        // Now run both trees to the end, which includes the tree finishing and starting a new run.
                        for (let step = snapshotStep; step <= LAST_STEP; step++) {
                            applyScript(script, step);
                            advanceTime();
                            stepBoth(original, restored);

                            if (!original.tree.isRunning()) {
                                finishedCount++;
                            }
                        }
                    }

                    assert.isAbove(finishedCount, 0, `the tree never finished for seed ${seed}`);
                }
            });
        });
    }
});

describe("A behaviour tree snapshot of a different definition", () => {
    // Waits are timed by the clock, which would otherwise move on between a tree being stepped and its snapshots being compared.
    let clock: SinonFakeTimers;

    beforeEach(() => {
        clock = sinon.useFakeTimers();
    });

    afterEach(() => {
        clock.restore();
    });

    const definition = "root { sequence { action [Implement] wait [100] action [Deploy] } }";
    const script: Script = { Implement: State.SUCCEEDED, Deploy: undefined };

    const takeSteppedSnapshot = (source: string) => {
        const { tree } = createRun(source, script);

        tree.step();

        return takeSnapshot(tree);
    };

    const differentDefinitions: { [description: string]: string } = {
        "an action with a different name": "root { sequence { action [Build] wait [100] action [Deploy] } }",
        "an action with different arguments": "root { sequence { action [Implement, 1] wait [100] action [Deploy] } }",
        "a wait with a different duration": "root { sequence { action [Implement] wait [200] action [Deploy] } }",
        "a wait with a duration range": "root { sequence { action [Implement] wait [100, 200] action [Deploy] } }",
        "a node attribute": "root { sequence { action [Implement] wait [100] action [Deploy] entry(OnDeploy) } }",
        "a guard": "root { sequence { action [Implement] wait [100] action [Deploy] while(IsOpen) } }",
        "a different structure": "root { selector { action [Implement] wait [100] action [Deploy] } }",
        "an extra node": "root { sequence { action [Implement] wait [100] action [Deploy] action [Notify] } }",
        "a subtree":
            "root { sequence { action [Implement] wait [100] branch [Deploy] } } root [Deploy] { action [Deploy] }"
    };

    for (const [description, other] of Object.entries(differentDefinitions)) {
        it(`is rejected by a tree with ${description}, and leaves the tree as it was`, () => {
            const target = createRun(other, script);

            target.tree.step();

            const before = withoutIds(target.tree.getTreeNodeDetails());
            const snapshotBefore = target.tree.snapshot();

            assert.throws(
                () => target.tree.restore(takeSteppedSnapshot(definition)),
                Error,
                "does not match the tree's definition"
            );
            assert.deepStrictEqual(withoutIds(target.tree.getTreeNodeDetails()), before);
            assert.deepStrictEqual(target.tree.snapshot(), snapshotBefore);
        });
    }

    it("is rejected by a tree with the same structure but different subtree actions", () => {
        const withSubtree = (action: string) =>
            `root { branch [Work] } root [Work] { sequence { action [${action}] wait [100] } }`;

        const { tree } = createRun(withSubtree("Other"), script);

        assert.throws(
            () => tree.restore(takeSteppedSnapshot(withSubtree("Implement"))),
            Error,
            "does not match the tree's definition"
        );
    });

    it("is rejected when a tree has been stepped, which carries on as if restore() was never called", () => {
        const original = createRun(definition, script);
        const target = createRun(definition, script);

        original.tree.step();
        target.tree.step();

        const other = createRun("root { sequence { action [Build] wait [100] action [Deploy] } }", script);
        other.tree.step();

        assert.throws(
            () => target.tree.restore(takeSnapshot(other.tree)),
            Error,
            "does not match the tree's definition"
        );

        assertSameBehaviour(original, target);
        stepBoth(original, target);
    });

    it("is accepted by a tree with the same definition", () => {
        const { tree } = createRun(definition, script);

        tree.restore(takeSteppedSnapshot(definition));
    });
});

describe("A behaviour tree snapshot of an MDSL definition and of the equivalent JSON definition", () => {
    const mdsl = `root {
        sequence {
            action [Implement, 1, "two", true, null]
            retry [2, 3] {
                lotto [1, 2] {
                    condition [IsReady] while(IsOpen, 5) until(IsClosed) entry(OnReady) step(OnStep) exit(OnExit)
                    wait [100, 200]
                }
            }
            wait
            branch [Deploy]
        }
    }
    root [Deploy] {
        action [Release] while(IsApproved)
    }`;

    // The definition as the MDSL parser returns it, which has explicit empty arguments and abort results.
    const parsed = convertMDSLToJSON(mdsl);

    // The same definition as a person might write it, without the empty arguments and abort results, and with other key orders.
    const handWritten = [
        {
            child: {
                children: [
                    { args: [1, "two", true, null], call: "Implement", type: "action" },
                    {
                        attempts: [2, 3],
                        child: {
                            weights: [1, 2],
                            children: [
                                {
                                    type: "condition",
                                    call: "IsReady",
                                    exit: { call: "OnExit" },
                                    step: { call: "OnStep" },
                                    entry: { call: "OnReady" },
                                    until: { call: "IsClosed" },
                                    while: { call: "IsOpen", args: [5] }
                                },
                                { type: "wait", duration: [100, 200] }
                            ],
                            type: "lotto"
                        },
                        type: "retry"
                    },
                    { type: "wait" },
                    { type: "branch", ref: "Deploy" }
                ],
                type: "sequence"
            },
            type: "root"
        },
        {
            id: "Deploy",
            child: { while: { call: "IsApproved" }, call: "Release", type: "action" },
            type: "root"
        }
    ];

    const script: Script = { Implement: State.SUCCEEDED };

    const equivalents: { [description: string]: string | object } = {
        MDSL: mdsl,
        "parsed JSON": parsed,
        "JSON with defaults omitted": handWritten,
        "JSON with the subtree first": [...handWritten].reverse()
    };

    for (const [from, fromDefinition] of Object.entries(equivalents)) {
        for (const [to, toDefinition] of Object.entries(equivalents)) {
            it(`restores a snapshot of the ${from} into a tree of the ${to}`, () => {
                const sourceRun = createRun(fromDefinition, script, { random: () => 0 });
                const targetRun = createRun(toDefinition, script, { random: () => 0 });

                sourceRun.tree.step();
                targetRun.tree.restore(takeSnapshot(sourceRun.tree));
                sourceRun.log.length = 0;

                assertSameBehaviour(sourceRun, targetRun);
                stepBoth(sourceRun, targetRun);
            });
        }
    }

    it("restores a snapshot of a single root node JSON definition into a tree of the equivalent MDSL", () => {
        const json = {
            type: "root",
            child: {
                type: "sequence",
                children: [
                    { type: "action", call: "A" },
                    { type: "action", call: "B", args: [1] }
                ]
            }
        };
        const jsonRun = createRun(json, { A: State.SUCCEEDED });
        const mdslRun = createRun("root { sequence { action [A] action [B, 1] } }", { A: State.SUCCEEDED });

        jsonRun.tree.step();
        mdslRun.tree.restore(takeSnapshot(jsonRun.tree));
        jsonRun.log.length = 0;
        stepBoth(jsonRun, mdslRun);

        jsonRun.tree.restore(takeSnapshot(mdslRun.tree));
        jsonRun.log.length = 0;
        mdslRun.log.length = 0;
        stepBoth(mdslRun, jsonRun);
    });

    it("rejects a snapshot between an MDSL definition and a JSON definition that differs", () => {
        const different = JSON.parse(JSON.stringify(handWritten));
        different[0].child.children[0].args = [1, "two", true, false];

        const source = createRun(mdsl, script);
        const target = createRun(different, script);

        source.tree.step();

        assert.throws(
            () => target.tree.restore(takeSnapshot(source.tree)),
            Error,
            "does not match the tree's definition"
        );
    });

    it("rejects a snapshot between definitions that differ only by a guard abort result", () => {
        const source = createRun("root { action [A] while(IsOpen) }", {});
        const target = createRun(
            { type: "root", child: { type: "action", call: "A", while: { call: "IsOpen", succeedOnAbort: true } } },
            {}
        );

        assert.throws(
            () => target.tree.restore(takeSnapshot(source.tree)),
            Error,
            "does not match the tree's definition"
        );
    });
});

describe("restore() rejects input that is not a snapshot with an error, and leaves the tree as it was", () => {
    const definition = "root { sequence { action [A] action [B] } }";
    const script: Script = { A: State.SUCCEEDED, B: undefined };

    const validSnapshot = (): any => {
        const { tree } = createRun(definition, script);

        tree.step();

        return takeSnapshot(tree);
    };

    const without = (property: string) => {
        const snapshot = validSnapshot();

        delete snapshot[property];

        return snapshot;
    };

    const inputs: { [description: string]: unknown } = {
        null: null,
        undefined: undefined,
        "a string": "snapshot",
        "a JSON string of a snapshot": JSON.stringify(validSnapshot()),
        "a number": 42,
        "a boolean": true,
        "an array": [],
        "an array of a snapshot": [validSnapshot()],
        "an empty object": {},
        "an object with only a version": { version: 1 },
        "an object with unrelated fields": { name: "snapshot", state: "mistreevous.running" },
        "a snapshot without a definition": without("definition"),
        "a snapshot without a root": without("root"),
        "a snapshot with a definition that is not a string": { ...validSnapshot(), definition: 42 },
        "a snapshot with a root that is not an object": { ...validSnapshot(), root: "root" },
        "a snapshot with a null root": { ...validSnapshot(), root: null }
    };

    for (const [description, input] of Object.entries(inputs)) {
        it(description, () => {
            const { tree, log } = createRun(definition, script);

            tree.step();

            const before = withoutIds(tree.getTreeNodeDetails());
            const snapshotBefore = tree.snapshot();

            assert.throws(() => tree.restore(input as BehaviourTreeSnapshot), Error);
            assert.deepStrictEqual(withoutIds(tree.getTreeNodeDetails()), before);
            assert.deepStrictEqual(tree.snapshot(), snapshotBefore);

            // The tree carries on as if restore() was never called.
            log.length = 0;
            tree.step();

            assert.deepEqual(log, ["B"]);
        });
    }
});

describe("Restoring a behaviour tree from a snapshot is not a state change", () => {
    const definition = `root {
        parallel {
            sequence {
                action [Implement]
                wait [100]
                action [Review]
            }
            repeat [3] { lotto { action [NotifyTeam] action [NotifyChannel] } }
            retry [2] { action [RunCi] }
        }
    }`;

    const script: Script = {
        Implement: State.SUCCEEDED,
        Review: undefined,
        NotifyTeam: State.SUCCEEDED,
        NotifyChannel: State.SUCCEEDED,
        RunCi: State.FAILED
    };

    /** Describes a state change without its node id, which is different for every tree instance. */
    const describeChange = ({ type, previousState, state }: { type: string; previousState: State; state: State }) =>
        `${type}: ${previousState} -> ${state}`;

    for (const [description, stepsBeforeRestore] of [
        ["a tree that has not been stepped", 0],
        ["a tree that has been stepped", 3]
    ] as const) {
        it(`does not call onNodeStateChange when restoring ${description}, and the next step reports changes as usual`, () => {
            const originalChanges: string[] = [];
            const original = createRun(definition, script, {
                onNodeStateChange: (change) => originalChanges.push(describeChange(change))
            });

            original.tree.step();
            original.tree.step();

            const snapshot = takeSnapshot(original.tree);

            const restoredChanges: string[] = [];
            const restored = createRun(definition, script, {
                onNodeStateChange: (change) => restoredChanges.push(describeChange(change))
            });

            for (let step = 0; step < stepsBeforeRestore; step++) {
                restored.tree.step();
            }

            restoredChanges.length = 0;
            originalChanges.length = 0;

            restored.tree.restore(snapshot);

            assert.deepEqual(restoredChanges, [], "restore() should not report any state changes");

            original.tree.step();
            restored.tree.step();

            assert.isNotEmpty(originalChanges, "the original tree should have reported changes for its step");
            assert.deepEqual(restoredChanges, originalChanges);
        });
    }

    it("does not call onNodeStateChange for an action that had a promise pending", () => {
        const changes: string[] = [];
        const pending: Script = { Implement: new Promise(() => {}) };
        const original = createRun("root { action [Implement] }", pending);

        original.tree.step();

        const restored = createRun("root { action [Implement] }", pending, {
            onNodeStateChange: (change) => changes.push(describeChange(change))
        });

        restored.tree.restore(takeSnapshot(original.tree));

        assert.deepEqual(changes, []);
    });
});

describe("A behaviour tree snapshot is independent of the trees it was taken from and restored to", () => {
    let clock: SinonFakeTimers;

    beforeEach(() => (clock = sinon.useFakeTimers()));
    afterEach(() => clock.restore());

    const definition = `root {
        sequence {
            parallel {
                sequence {
                    action [Implement]
                    wait [100, 300]
                }
                repeat [2, 4] { lotto { action [NotifyTeam] action [NotifyChannel] } }
                retry [2] { action [RunCi] }
                action [Deploy]
            }
            wait [500]
            action [Review]
        }
    }`;

    const createScript = (): Script => ({
        Implement: State.SUCCEEDED,
        NotifyTeam: State.SUCCEEDED,
        NotifyChannel: State.FAILED,
        RunCi: State.FAILED,
        Deploy: new Promise(() => {}),
        Review: undefined
    });

    const copy = (snapshot: BehaviourTreeSnapshot): BehaviourTreeSnapshot => JSON.parse(JSON.stringify(snapshot));

    /** Steps a tree for a number of steps, moving the clock on after each one. */
    const stepFor = (tree: BehaviourTree, steps: number) => {
        for (let step = 0; step < steps; step++) {
            tree.step();
            clock.tick(60);
        }
    };

    it("is not changed by stepping the tree it was taken from", () => {
        const { tree } = createRun(definition, createScript());

        for (let step = 0; step < 15; step++) {
            const snapshot = takeSnapshot(tree);
            const before = copy(snapshot);

            stepFor(tree, 1);

            assert.deepStrictEqual(snapshot, before, `snapshot changed by step ${step}`);
        }
    });

    it("is not changed by stepping a tree it was restored to", () => {
        const source = createRun(definition, createScript());

        stepFor(source.tree, 3);

        const snapshot = takeSnapshot(source.tree);
        const before = copy(snapshot);

        const restored = createRun(definition, createScript());
        restored.tree.restore(snapshot);

        for (let step = 0; step < 15; step++) {
            stepFor(restored.tree, 1);

            assert.deepStrictEqual(snapshot, before, `snapshot changed by step ${step} of the restored tree`);
        }
    });

    it("is equal to a snapshot taken right after it was restored, before any step", () => {
        const source = createRun(definition, createScript());

        for (let step = 0; step < 15; step++) {
            const snapshot = takeSnapshot(source.tree);

            const restored = createRun(definition, createScript());
            restored.tree.restore(snapshot);

            assert.deepStrictEqual(takeSnapshot(restored.tree), snapshot, `snapshot taken after step ${step}`);

            stepFor(source.tree, 1);
        }
    });
});
