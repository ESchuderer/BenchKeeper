import { RootNodeDefinition } from "./BehaviourTreeDefinition";

/**
 * Gets whether a definition property has the value that a tree is built with when the property is left out, which is the case for
 * empty arguments and for guards that move to the FAILED state when they abort. The MDSL converter always writes these properties,
 * while a JSON definition written by hand usually will not.
 * @param key The name of the property.
 * @param value The value of the property.
 * @returns true if the property has the value that is used when it is left out, otherwise false.
 */
function isDefaultValue(key: string, value: unknown): boolean {
    return (
        (key === "args" && Array.isArray(value) && value.length === 0) || (key === "succeedOnAbort" && value === false)
    );
}

/**
 * Gets a copy of a value in which the properties of every object are in alphabetical order and properties that are undefined, or that
 * have the value used when they are left out, are themselves left out, so that values that mean the same thing are serialised as the same text.
 * @param value The value to get a canonical copy of.
 * @returns The canonical copy of the value.
 */
function canonicalise(value: unknown): unknown {
    if (Array.isArray(value)) {
        return value.map(canonicalise);
    }

    if (typeof value === "object" && value !== null) {
        const source = value as { [key: string]: unknown };
        const copy: { [key: string]: unknown } = {};

        Object.keys(source)
            .sort()
            .filter((key) => typeof source[key] !== "undefined" && !isDefaultValue(key, source[key]))
            .forEach((key) => (copy[key] = canonicalise(source[key])));

        return copy;
    }

    return value;
}

/**
 * Gets a 53-bit hash of a string, which is not secure, but is quick and spreads similar strings far apart.
 * This is the cyrb53 hash by bryc, which is in the public domain.
 * @param text The text to hash.
 * @param seed The seed for the hash, which gives a different hash for each seed.
 * @returns The hash of the text.
 */
function hash(text: string, seed: number): number {
    let h1 = 0xdeadbeef ^ seed;
    let h2 = 0x41c6ce57 ^ seed;

    for (let index = 0; index < text.length; index++) {
        const code = text.charCodeAt(index);

        h1 = Math.imul(h1 ^ code, 2654435761);
        h2 = Math.imul(h2 ^ code, 1597334677);
    }

    h1 = Math.imul(h1 ^ (h1 >>> 16), 2246822507) ^ Math.imul(h2 ^ (h2 >>> 13), 3266489909);
    h2 = Math.imul(h2 ^ (h2 >>> 16), 2246822507) ^ Math.imul(h1 ^ (h1 >>> 13), 3266489909);

    return 4294967296 * (2097151 & h2) + (h1 >>> 0);
}

/**
 * Gets a fingerprint of a tree definition, which is the same for any definitions that describe the same tree, so for an MDSL definition
 * and the JSON definition that it converts to, however the JSON properties and the subtrees are ordered. It is used to tell whether a
 * snapshot was taken from a tree of the same definition, and is only a guard against restoring a snapshot to the wrong tree by mistake.
 * @param definition The root node definitions of the tree, as JSON.
 * @returns The fingerprint of the definition.
 */
export function getDefinitionFingerprint(definition: RootNodeDefinition[]): string {
    // The main root node has no 'id', and the order of the subtrees is of no consequence to the tree.
    const rootNodeDefinitions = [...definition].sort((a, b) => {
        const idA = a.id ?? "";
        const idB = b.id ?? "";

        return idA < idB ? -1 : idA > idB ? 1 : 0;
    });

    const text = JSON.stringify(canonicalise(rootNodeDefinitions));

    return [hash(text, 0), hash(text, 1)].map((value) => value.toString(16).padStart(14, "0")).join("");
}
