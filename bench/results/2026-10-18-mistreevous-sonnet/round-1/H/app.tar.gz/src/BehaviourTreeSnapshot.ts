import { AnyState } from "./State";

/**
 * The properties common to the snapshot of every node.
 */
interface NodeSnapshotBase<TType extends string> {
    /**
     * The node type.
     */
    type: TType;
    /**
     * The state of the node.
     */
    state: AnyState;
}

/**
 * The snapshot of a node that has children, one snapshot for each child in the order the children are defined.
 */
interface ParentNodeSnapshotBase<TType extends string> extends NodeSnapshotBase<TType> {
    /**
     * The snapshots of the child nodes.
     */
    children: NodeSnapshot[];
}

/**
 * The snapshot of a root, flip, succeed, fail, sequence, selector, parallel, race or all node.
 * The progress of these nodes is entirely described by their own state and the state of their children.
 */
export type StatelessParentNodeSnapshot = ParentNodeSnapshotBase<
    "root" | "flip" | "succeed" | "fail" | "sequence" | "selector" | "parallel" | "race" | "all"
>;

/**
 * The snapshot of a condition node.
 */
export type ConditionNodeSnapshot = NodeSnapshotBase<"condition">;

/**
 * The snapshot of an action node.
 */
export interface ActionNodeSnapshot extends NodeSnapshotBase<"action"> {
    /**
     * The result of the promise returned by the action function, for a promise that has settled but has not yet been
     * handled by an update of the node. This is null if there is no such promise.
     */
    updatePromiseResult: UpdatePromiseResultSnapshot | null;
}

/**
 * The result of a settled promise returned by an action function.
 */
export interface UpdatePromiseResultSnapshot {
    /**
     * Whether the promise was resolved rather than rejected.
     */
    isResolved: boolean;
    /**
     * The value that the promise resolved with, or null if that was not a string, or a description of the reason that it was rejected.
     */
    value: string | null;
}

/**
 * The snapshot of a wait node.
 */
export interface WaitNodeSnapshot extends NodeSnapshotBase<"wait"> {
    /**
     * The total duration in milliseconds that the node will wait for, or null if it will wait indefinitely.
     * If the duration was chosen at random then this is the duration that was chosen.
     */
    totalDuration: number | null;
    /**
     * The duration in milliseconds that the node has waited for at the time that the snapshot was taken.
     */
    waitedDuration: number;
}

/**
 * The snapshot of a repeat node.
 */
export interface RepeatNodeSnapshot extends ParentNodeSnapshotBase<"repeat"> {
    /**
     * The number of iterations that the node is to make, or null if it will iterate indefinitely.
     * If the number of iterations was chosen at random then this is the number that was chosen.
     */
    targetIterationCount: number | null;
    /**
     * The number of iterations that the node has made.
     */
    currentIterationCount: number;
}

/**
 * The snapshot of a retry node.
 */
export interface RetryNodeSnapshot extends ParentNodeSnapshotBase<"retry"> {
    /**
     * The number of attempts that the node is to make, or null if it will attempt indefinitely.
     * If the number of attempts was chosen at random then this is the number that was chosen.
     */
    targetAttemptCount: number | null;
    /**
     * The number of attempts that the node has made.
     */
    currentAttemptCount: number;
}

/**
 * The snapshot of a lotto node.
 */
export interface LottoNodeSnapshot extends ParentNodeSnapshotBase<"lotto"> {
    /**
     * The index of the child that was picked to be the active one, or null if no child has been picked.
     */
    selectedChildIndex: number | null;
}

/**
 * The snapshot of any node that has children.
 */
export type ParentNodeSnapshot =
    | StatelessParentNodeSnapshot
    | RepeatNodeSnapshot
    | RetryNodeSnapshot
    | LottoNodeSnapshot;

/**
 * The snapshot of any node in a behaviour tree.
 */
export type NodeSnapshot =
    | StatelessParentNodeSnapshot
    | ConditionNodeSnapshot
    | ActionNodeSnapshot
    | WaitNodeSnapshot
    | RepeatNodeSnapshot
    | RetryNodeSnapshot
    | LottoNodeSnapshot;

/**
 * A snapshot of the execution state of a behaviour tree, as returned by `BehaviourTree.snapshot()`.
 * This is a plain object that can be serialised as JSON, and later passed to `BehaviourTree.restore()` on a tree
 * that was created from the same definition. It should be treated as opaque, its format is not part of the API.
 */
export type BehaviourTreeSnapshot = StatelessParentNodeSnapshot & {
    type: "root";
    /**
     * A fingerprint of the definition of the tree that the snapshot was taken from, which is the same for an MDSL definition
     * and the equivalent JSON definition. A snapshot can only be restored to a tree with a definition of the same fingerprint.
     */
    definitionFingerprint: string;
};
