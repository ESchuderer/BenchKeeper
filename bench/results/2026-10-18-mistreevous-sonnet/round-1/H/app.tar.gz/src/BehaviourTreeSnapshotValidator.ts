import { NodeDetails } from "./nodes/Node";
import State from "./State";

/**
 * Whether the specified value is a non-null, non-array object.
 */
const isObject = (value: unknown): value is { [key: string]: unknown } =>
    typeof value === "object" && value !== null && !Array.isArray(value);

/**
 * Validates that a snapshot was taken from a tree of the same definition and has the same shape as a tree, so that restoring it cannot fail part way through.
 * @param snapshot The snapshot to validate, which could have come from anywhere (such as a database) and so is untrusted.
 * @param details The details of the root node of the tree that the snapshot is to be restored to.
 * @param definitionFingerprint The fingerprint of the definition of the tree that the snapshot is to be restored to.
 * @throws An error describing the first problem found with the snapshot.
 */
export function validateSnapshot(snapshot: unknown, details: NodeDetails, definitionFingerprint: string): void {
    // The definition is checked before the shape of the tree, as a snapshot of another definition is likely to have a different shape.
    if (isObject(snapshot)) {
        if (typeof snapshot.definitionFingerprint !== "string" || snapshot.definitionFingerprint.length === 0) {
            throw new Error("invalid snapshot: expected 'definitionFingerprint' to be a non-empty string at 'root'");
        }

        if (snapshot.definitionFingerprint !== definitionFingerprint) {
            throw new Error("invalid snapshot: snapshot does not match the tree's definition");
        }
    }

    validateNodeSnapshot(snapshot, details, "root");
}

/**
 * Validates that a property of a node snapshot is a count, which is a non-negative integer.
 * @param snapshot The node snapshot.
 * @param property The name of the property holding the count.
 * @param isNullable Whether the count can be null, which is how a count that is not limited is stored.
 * @param path The path to the node, for use in error messages.
 */
function validateCount(snapshot: { [key: string]: unknown }, property: string, isNullable: boolean, path: string) {
    const value = snapshot[property];

    if ((isNullable && value === null) || (Number.isInteger(value) && (value as number) >= 0)) {
        return;
    }

    throw new Error(
        `invalid snapshot: expected '${property}' to be ${
            isNullable ? "null or " : ""
        }a non-negative integer at '${path}'`
    );
}

/**
 * Validates the snapshot of a node and, recursively, the snapshots of its children.
 * @param snapshot The node snapshot.
 * @param details The details of the node that the snapshot is to be restored to.
 * @param path The path to the node, for use in error messages.
 */
function validateNodeSnapshot(snapshot: unknown, details: NodeDetails, path: string): void {
    if (!isObject(snapshot)) {
        throw new Error(`invalid snapshot: expected an object at '${path}'`);
    }

    if (snapshot.type !== details.type) {
        throw new Error(
            `invalid snapshot: expected node of type '${details.type}' but got '${snapshot.type}' at '${path}'`
        );
    }

    if (!Object.values(State).includes(snapshot.state as State)) {
        throw new Error(`invalid snapshot: invalid node state '${snapshot.state}' at '${path}'`);
    }

    switch (details.type) {
        case "repeat":
            validateCount(snapshot, "targetIterationCount", true, path);
            validateCount(snapshot, "currentIterationCount", false, path);
            break;

        case "retry":
            validateCount(snapshot, "targetAttemptCount", true, path);
            validateCount(snapshot, "currentAttemptCount", false, path);
            break;

        case "action": {
            const result = snapshot.updatePromiseResult;

            if (
                result !== null &&
                !(
                    isObject(result) &&
                    typeof result.isResolved === "boolean" &&
                    (result.value === null || typeof result.value === "string")
                )
            ) {
                throw new Error(
                    `invalid snapshot: expected 'updatePromiseResult' to be null or an object with a boolean 'isResolved' and a string or null 'value' at '${path}'`
                );
            }
            break;
        }

        case "wait":
            if (
                snapshot.totalDuration !== null &&
                !(Number.isFinite(snapshot.totalDuration) && (snapshot.totalDuration as number) >= 0)
            ) {
                throw new Error(
                    `invalid snapshot: expected 'totalDuration' to be null or a non-negative number at '${path}'`
                );
            }

            if (!Number.isFinite(snapshot.waitedDuration)) {
                throw new Error(`invalid snapshot: expected 'waitedDuration' to be a number at '${path}'`);
            }
            break;

        case "lotto": {
            const index = snapshot.selectedChildIndex;
            const childCount = details.children?.length ?? 0;

            if (index === null && snapshot.state === State.RUNNING) {
                throw new Error(
                    `invalid snapshot: expected 'selectedChildIndex' to be the index of a child for a running node at '${path}'`
                );
            }

            if (
                index !== null &&
                !(Number.isInteger(index) && (index as number) >= 0 && (index as number) < childCount)
            ) {
                throw new Error(
                    `invalid snapshot: expected 'selectedChildIndex' to be null or the index of a child at '${path}'`
                );
            }
            break;
        }
    }

    const expectedChildren = details.children ?? [];

    if (expectedChildren.length > 0) {
        if (!Array.isArray(snapshot.children) || snapshot.children.length !== expectedChildren.length) {
            const actual = Array.isArray(snapshot.children) ? snapshot.children.length : "none";
            throw new Error(
                `invalid snapshot: expected ${expectedChildren.length} children but got ${actual} at '${path}'`
            );
        }

        expectedChildren.forEach((childDetails, index) =>
            validateNodeSnapshot((snapshot.children as unknown[])[index], childDetails, `${path}.children[${index}]`)
        );
    }
}
