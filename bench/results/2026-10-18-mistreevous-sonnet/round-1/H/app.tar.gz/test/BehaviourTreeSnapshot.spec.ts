import { assert } from "chai";

import sinon from "sinon";

import {
    BehaviourTree,
    BehaviourTreeOptions,
    BehaviourTreeSnapshot,
    NodeDetails,
    State,
    convertMDSLToJSON
} from "../src/index";
import { RootNodeDefinition } from "../src/BehaviourTreeDefinition";
import { findNode } from "./TestUtilities";

/**
 * A script of results to return from agent functions, keyed on function name.
 * Each function returns the next result in its list, and keeps returning the last one once the list is exhausted.
 */
type Script = { [functionName: string]: any[] };

/**
 * Creates an agent whose functions record their calls in a log and return results from the given script.
 * @param script The script of results to return from agent functions.
 * @returns The agent, the log of calls made to it and a function to get a script of what is left to return.
 */
function createAgent(script: Script) {
    const queues: Script = {};
    Object.keys(script).forEach((name) => (queues[name] = [...script[name]]));

    const log: string[] = [];
    const agent: { [name: string]: any } = {};

    Object.keys(queues).forEach((name) => {
        agent[name] = (...args: any[]) => {
            log.push(args.length ? `${name}(${args.map((arg) => JSON.stringify(arg)).join(",")})` : name);
            return queues[name].length > 1 ? queues[name].shift() : queues[name][0];
        };
    });

    const remaining = (): Script => {
        const result: Script = {};
        Object.keys(queues).forEach((name) => (result[name] = [...queues[name]]));
        return result;
    };

    return { agent, log, remaining };
}

/**
 * Gets the details of every node in the tree without the node identifiers, which are random for each tree instance.
 */
function getDetailsWithoutIds(tree: BehaviourTree): any {
    const strip = (details: NodeDetails): any => {
        const { id, children, ...rest } = details;
        return children ? { ...rest, children: children.map(strip) } : rest;
    };

    return strip(tree.getTreeNodeDetails());
}

/**
 * Serialises and deserialises a value as JSON.
 */
const roundTrip = <T>(value: T): T => JSON.parse(JSON.stringify(value));

/**
 * Asserts that, whatever point of its run a tree is snapshotted at, a second tree restored from that snapshot goes on
 * to have the same node states, make the same agent function calls in the same order and reach the same result.
 * @param definition The tree definition.
 * @param script The script of results to return from agent functions.
 * @param maxSteps The number of steps to take with each tree after restoring.
 * @param options The behaviour tree options.
 */
function assertRestoredTreeBehavesLikeOriginal(
    definition: string,
    script: Script,
    maxSteps: number,
    options: BehaviourTreeOptions = {}
) {
    for (let stepsBeforeSnapshot = 0; stepsBeforeSnapshot <= maxSteps; stepsBeforeSnapshot++) {
        const original = createAgent(script);
        const originalTree = new BehaviourTree(definition, original.agent, options);

        for (let step = 0; step < stepsBeforeSnapshot; step++) {
            originalTree.step();
        }

        // The restored tree models the same agent, so it carries on from what the original agent had left to do.
        const restored = createAgent(original.remaining());
        const restoredTree = new BehaviourTree(definition, restored.agent, options);
        const snapshot = roundTrip(originalTree.snapshot());
        restoredTree.restore(snapshot);

        const context = `after ${stepsBeforeSnapshot} steps before the snapshot`;
        original.log.length = 0;

        assert.deepEqual(getDetailsWithoutIds(restoredTree), getDetailsWithoutIds(originalTree), `${context}`);

        for (let step = 0; step < maxSteps; step++) {
            originalTree.step();
            restoredTree.step();

            assert.deepEqual(restored.log, original.log, `${context}, calls after step ${step}`);
            assert.deepEqual(getDetailsWithoutIds(restoredTree), getDetailsWithoutIds(originalTree), context);
            assert.strictEqual(restoredTree.getState(), originalTree.getState(), context);
        }
    }
}

describe("A BehaviourTree", () => {
    describe("snapshot", () => {
        it("returns a plain object that is unchanged by serialising it to JSON and back", () => {
            const { agent } = createAgent({ A: [State.SUCCEEDED], B: [undefined, State.SUCCEEDED] });
            const tree = new BehaviourTree(
                "root { sequence { action [A] parallel { action [B] wait [1000] } lotto { wait [10, 20] } } }",
                agent
            );

            tree.step();

            const snapshot = tree.snapshot();

            assert.deepEqual(roundTrip(snapshot), snapshot);
            assert.isTrue(JSON.stringify(roundTrip(snapshot)) === JSON.stringify(snapshot));
        });

        it("returns plain data, unchanged by serialising it to JSON and back, for every type of node", async () => {
            const agent = {
                A: () => {},
                C: () => true,
                SettledPromise: () => Promise.resolve(State.SUCCEEDED)
            };
            const tree = new BehaviourTree(
                `root {
                    parallel {
                        repeat [2,3] { action [A] }
                        repeat { action [A] }
                        retry [1,2] { action [A] }
                        retry { action [A] }
                        lotto { wait [100] wait [100] }
                        wait [100, 200]
                        wait
                        action [SettledPromise]
                        sequence { condition [C] flip { succeed { fail { action [A] } } } }
                        selector { action [A] }
                        race { action [A] }
                        all { action [A] }
                    }
                }`,
                agent,
                { random: () => 0.5 }
            );

            tree.step();
            await new Promise<void>((resolve) => setImmediate(resolve));

            const snapshot = tree.snapshot();

            assert.deepEqual(roundTrip(snapshot), snapshot);

            const assertPlainData = (value: unknown, path: string) => {
                if (typeof value === "object" && value !== null) {
                    const prototype = Object.getPrototypeOf(value);
                    assert.isTrue(prototype === Object.prototype || prototype === Array.prototype, path);
                    Object.entries(value).forEach(([key, child]) => assertPlainData(child, `${path}.${key}`));
                } else {
                    assert.notInclude(["function", "undefined", "symbol", "bigint"], typeof value, path);
                }
            };
            assertPlainData(snapshot, "snapshot");
        });

        it("returns an object that is not affected by later steps of the tree", () => {
            const { agent } = createAgent({ A: [undefined, State.SUCCEEDED] });
            const tree = new BehaviourTree("root { action [A] }", agent);

            tree.step();

            const snapshot = tree.snapshot();
            const copy = roundTrip(snapshot);

            tree.step();

            assert.deepEqual(snapshot, copy);
        });

        it("captures the state of a tree that has not been stepped", () => {
            const { agent } = createAgent({ A: [State.SUCCEEDED] });
            const tree = new BehaviourTree("root { action [A] }", agent);

            const snapshot = tree.snapshot();

            assert.strictEqual(snapshot.type, "root");
            assert.strictEqual(snapshot.state, State.READY);
        });
    });

    describe("a snapshot is independent of the trees it is used with, so that", () => {
        const definition = `root {
            parallel {
                sequence { action [A] wait [250] action [A] }
                repeat [3] { sequence { action [B] wait [40, 80] } }
                retry [2] { action [B] }
                lotto { wait [100] action [B] }
                action [Settled]
                action [Rejected]
            }
        }`;
        const script = {
            A: [State.SUCCEEDED],
            B: [undefined, undefined, State.FAILED, State.SUCCEEDED]
        };

        let clock: sinon.SinonFakeTimers;

        beforeEach(() => {
            clock = sinon.useFakeTimers({ toFake: ["Date"] });
        });

        afterEach(() => {
            clock.restore();
        });

        /**
         * Steps a tree, ignoring the error thrown by the rejected promise, then lets the promises settle and time pass.
         */
        const stepAndWait = async (tree: BehaviourTree) => {
            try {
                tree.step();
            } catch {
                // The rejected promise makes a step throw, which doesn't matter here.
            }
            await new Promise<void>((resolve) => setImmediate(resolve));
            clock.tick(30);
        };

        const createTree = () => {
            const agent = {
                ...createAgent(script).agent,
                Settled: () => Promise.resolve(State.SUCCEEDED),
                Rejected: () => Promise.reject(new Error("rejected"))
            };
            return new BehaviourTree(definition, agent, { random: () => 0.5 });
        };

        it("stepping the tree it was taken from does not change it", async () => {
            const tree = createTree();

            for (let step = 0; step < 12; step++) {
                await stepAndWait(tree);

                const snapshot = tree.snapshot();
                const copy = roundTrip(snapshot);

                await stepAndWait(tree);
                await stepAndWait(tree);

                assert.deepEqual(snapshot, copy, `after step ${step}`);
            }
        });

        it("stepping a tree that it was restored to does not change it", async () => {
            const source = createTree();
            const target = createTree();

            for (let step = 0; step < 12; step++) {
                await stepAndWait(source);

                const snapshot = source.snapshot();
                const copy = roundTrip(snapshot);

                target.restore(snapshot);
                await stepAndWait(target);
                await stepAndWait(target);
                await stepAndWait(target);

                assert.deepEqual(snapshot, copy, `after step ${step}`);
            }
        });

        it("a snapshot taken straight after restoring it is the same snapshot", async () => {
            const source = createTree();
            const target = createTree();

            for (let step = 0; step < 12; step++) {
                await stepAndWait(source);

                const snapshot = source.snapshot();
                target.restore(snapshot);

                assert.deepEqual(roundTrip(target.snapshot()), roundTrip(snapshot), `after step ${step}`);

                await stepAndWait(target);
            }
        });
    });

    describe("restore", () => {
        it("sets the node states of the tree to those of the snapshot, replacing any it had", () => {
            const { agent } = createAgent({ A: [State.SUCCEEDED], B: [undefined, State.SUCCEEDED] });
            const definition = "root { sequence { action [A] action [B] } }";
            const source = new BehaviourTree(definition, agent);
            source.step();

            const target = new BehaviourTree(definition, createAgent({ A: [State.FAILED] }).agent);
            target.step();
            assert.strictEqual(target.getState(), State.FAILED);

            target.restore(source.snapshot());

            assert.deepEqual(getDetailsWithoutIds(target), getDetailsWithoutIds(source));
            assert.isTrue(target.isRunning());
        });

        it("can restore the same snapshot more than once", () => {
            const { agent } = createAgent({ A: [State.SUCCEEDED], B: [undefined, State.SUCCEEDED] });
            const definition = "root { sequence { action [A] action [B] } }";
            const source = new BehaviourTree(definition, agent);
            source.step();
            const snapshot = source.snapshot();

            const target = new BehaviourTree(
                definition,
                createAgent({ A: [State.SUCCEEDED], B: [State.FAILED] }).agent
            );

            target.restore(snapshot);
            target.step();
            assert.strictEqual(target.getState(), State.FAILED);

            target.restore(snapshot);
            assert.strictEqual(target.getState(), State.RUNNING);
            assert.deepEqual(getDetailsWithoutIds(target), getDetailsWithoutIds(source));
        });

        describe("does not call the onNodeStateChange option", () => {
            const definition = "root { sequence { action [A] parallel { action [B] action [C] } } }";
            const script = { A: [State.SUCCEEDED], B: [undefined, State.SUCCEEDED], C: [undefined, State.FAILED] };

            const createSnapshot = () => {
                const source = new BehaviourTree(definition, createAgent(script).agent);
                source.step();
                return roundTrip(source.snapshot());
            };

            it("even though the states of the nodes change", () => {
                const snapshot = createSnapshot();
                const changes: string[] = [];
                const target = new BehaviourTree(definition, createAgent(script).agent, {
                    onNodeStateChange: ({ type, previousState, state }) =>
                        changes.push(`${type}:${previousState}>${state}`)
                });

                target.restore(snapshot);

                assert.isTrue(target.isRunning());
                assert.deepEqual(changes, []);
            });

            it("when restoring a tree that had already run and finished", () => {
                const snapshot = createSnapshot();
                const onNodeStateChange = sinon.spy();
                const target = new BehaviourTree(definition, createAgent({ A: [State.FAILED] }).agent, {
                    onNodeStateChange
                });
                target.step();
                onNodeStateChange.resetHistory();

                target.restore(snapshot);

                sinon.assert.notCalled(onNodeStateChange);
            });

            it("and still calls it for the changes made by the next step", () => {
                const snapshot = createSnapshot();
                const changes: string[] = [];
                const finishingAgent = createAgent({ A: [State.SUCCEEDED], B: [State.SUCCEEDED], C: [State.FAILED] });
                const target = new BehaviourTree(definition, finishingAgent.agent, {
                    onNodeStateChange: ({ type, previousState, state }) =>
                        changes.push(`${type}:${previousState}>${state}`)
                });

                target.restore(snapshot);
                target.step();

                // The previous states are the restored states, as the restore itself was not reported.
                assert.sameMembers(changes, [
                    `action:${State.RUNNING}>${State.SUCCEEDED}`,
                    `action:${State.RUNNING}>${State.FAILED}`,
                    `parallel:${State.RUNNING}>${State.FAILED}`,
                    `sequence:${State.RUNNING}>${State.FAILED}`,
                    `root:${State.RUNNING}>${State.FAILED}`
                ]);
            });
        });

        describe("results in a tree that behaves exactly like the tree that was snapshotted for", () => {
            it("sequence nodes", () => {
                assertRestoredTreeBehavesLikeOriginal(
                    "root { sequence { action [A] action [B] condition [C] action [D] } }",
                    {
                        A: [State.SUCCEEDED],
                        B: [undefined, undefined, State.SUCCEEDED],
                        C: [true],
                        D: [State.SUCCEEDED]
                    },
                    6
                );
            });

            it("selector nodes", () => {
                assertRestoredTreeBehavesLikeOriginal(
                    "root { selector { action [A] action [B] action [C] } }",
                    { A: [State.FAILED], B: [undefined, undefined, State.FAILED], C: [undefined, State.SUCCEEDED] },
                    7
                );
            });

            it("parallel nodes", () => {
                assertRestoredTreeBehavesLikeOriginal(
                    "root { parallel { action [A] action [B] action [C] } }",
                    {
                        A: [State.SUCCEEDED],
                        B: [undefined, undefined, State.SUCCEEDED],
                        C: [undefined, State.SUCCEEDED]
                    },
                    5
                );
                assertRestoredTreeBehavesLikeOriginal(
                    "root { parallel { action [A] action [B] action [C] } }",
                    { A: [undefined, undefined, State.FAILED], B: [undefined], C: [undefined] },
                    5
                );
            });

            it("race nodes", () => {
                assertRestoredTreeBehavesLikeOriginal(
                    "root { race { action [A] action [B] action [C] } }",
                    { A: [undefined], B: [undefined, undefined, State.SUCCEEDED], C: [State.FAILED] },
                    5
                );
                assertRestoredTreeBehavesLikeOriginal(
                    "root { race { action [A] action [B] } }",
                    { A: [undefined, State.FAILED], B: [undefined, undefined, State.FAILED] },
                    5
                );
            });

            it("all nodes", () => {
                assertRestoredTreeBehavesLikeOriginal(
                    "root { all { action [A] action [B] action [C] } }",
                    { A: [State.FAILED], B: [undefined, undefined, State.SUCCEEDED], C: [undefined, State.FAILED] },
                    5
                );
            });

            it("flip, succeed and fail nodes", () => {
                assertRestoredTreeBehavesLikeOriginal(
                    "root { sequence { flip { action [A] } succeed { action [B] } fail { action [C] } } }",
                    { A: [undefined, State.FAILED], B: [undefined, State.FAILED], C: [undefined, State.SUCCEEDED] },
                    7
                );
            });

            it("nodes with entry, step and exit callbacks", () => {
                assertRestoredTreeBehavesLikeOriginal(
                    'root { sequence { action [A] entry(Log, "entry A") step(Log, "step A") exit(Log, "exit A") action [B] exit(Log, "exit B") } }',
                    { A: [undefined, undefined, State.SUCCEEDED], B: [undefined, State.FAILED], Log: [undefined] },
                    6
                );
            });

            it("nodes that are aborted by guards", () => {
                assertRestoredTreeBehavesLikeOriginal(
                    'root { sequence { action [A] while(IsOk) exit(Log, "exit A") action [B] } }',
                    { A: [undefined], B: [State.SUCCEEDED], IsOk: [true, true, true, false], Log: [undefined] },
                    7
                );
                assertRestoredTreeBehavesLikeOriginal(
                    "root { parallel { sequence until(IsDone) { action [A] action [B] } action [C] } }",
                    {
                        A: [undefined],
                        B: [State.SUCCEEDED],
                        C: [undefined, undefined, State.SUCCEEDED],
                        IsDone: [false, false, true]
                    },
                    7
                );
            });

            it("a tree that combines many node types", () => {
                assertRestoredTreeBehavesLikeOriginal(
                    `root {
                        sequence {
                            condition [IsReady]
                            parallel {
                                sequence { action [A] action [B] }
                                race { action [C] action [D] }
                                all { action [E] action [F] }
                            }
                            selector { flip { action [G] } succeed { action [H] } }
                        }
                    }`,
                    {
                        IsReady: [true],
                        A: [State.SUCCEEDED],
                        B: [undefined, undefined, State.SUCCEEDED],
                        C: [undefined, undefined, undefined, State.SUCCEEDED],
                        D: [undefined],
                        E: [State.SUCCEEDED],
                        F: [undefined, State.FAILED],
                        G: [undefined, State.SUCCEEDED],
                        H: [State.SUCCEEDED]
                    },
                    10
                );
            });

            it("a tree that uses a branch node to reference a subtree", () => {
                assertRestoredTreeBehavesLikeOriginal(
                    "root { sequence { branch [Sub] action [B] } } root [Sub] { sequence { action [A] action [A] } }",
                    { A: [State.SUCCEEDED, undefined, State.SUCCEEDED], B: [State.SUCCEEDED] },
                    6
                );
            });
        });

        describe("keeps the progress of", () => {
            const iterationNodes = [
                { name: "repeat", node: "repeat", childResult: State.SUCCEEDED, endState: State.SUCCEEDED },
                { name: "retry", node: "retry", childResult: State.FAILED, endState: State.FAILED }
            ];

            iterationNodes.forEach(({ name, node, childResult, endState }) => {
                describe(`${name} nodes, including`, () => {
                    // The child resolves after a step in which it is running, so an iteration takes two steps.
                    const script = { A: [undefined, childResult] };

                    it("an explicit number of iterations", () => {
                        assertRestoredTreeBehavesLikeOriginal(`root { ${node} [3] { action [A] } }`, script, 9);
                    });

                    it("an unbounded number of iterations", () => {
                        assertRestoredTreeBehavesLikeOriginal(`root { ${node} { action [A] } }`, script, 6);
                    });

                    it("an iteration count that was chosen at random", () => {
                        assertRestoredTreeBehavesLikeOriginal(`root { ${node} [2,5] { action [A] } }`, script, 12, {
                            random: () => 0.5
                        });
                    });

                    it("the progress made so far, rather than starting the iterations again", () => {
                        const definition = `root { ${node} [3] { action [A] } }`;
                        const source = new BehaviourTree(definition, createAgent({ A: [childResult] }).agent);
                        source.step();
                        source.step();

                        const { agent, log } = createAgent({ A: [childResult] });
                        const target = new BehaviourTree(definition, agent);
                        target.restore(roundTrip(source.snapshot()));

                        // Two of the three iterations were already made, so only one more is left, and then the node finishes.
                        target.step();
                        target.step();

                        assert.deepEqual(log, ["A"]);
                        assert.strictEqual(target.getState(), endState);
                    });

                    it("the iteration count that was chosen at random, rather than choosing another", () => {
                        const definition = `root { ${node} [2,5] { action [A] } }`;
                        const source = new BehaviourTree(definition, createAgent({ A: [childResult] }).agent, {
                            random: () => 0
                        });
                        source.step();

                        // Had this tree picked an iteration count then it would be five, but the source tree picked two.
                        const random = sinon.spy(() => 0.99);
                        const { agent, log } = createAgent({ A: [childResult] });
                        const target = new BehaviourTree(definition, agent, { random });
                        target.restore(roundTrip(source.snapshot()));

                        target.step();
                        target.step();

                        assert.deepEqual(log, ["A"]);
                        assert.strictEqual(target.getState(), endState);
                        assert.isTrue(random.notCalled);
                    });

                    it("a finished tree, which chooses an iteration count again when it next runs", () => {
                        const definition = `root { ${node} [2,5] { action [A] } }`;
                        const source = new BehaviourTree(definition, createAgent({ A: [childResult] }).agent, {
                            random: () => 0
                        });
                        while (source.getState() !== endState) {
                            source.step();
                        }

                        const { agent, log } = createAgent({ A: [childResult] });
                        const target = new BehaviourTree(definition, agent, { random: () => 0.99 });
                        target.restore(roundTrip(source.snapshot()));
                        assert.strictEqual(target.getState(), endState);

                        // The new run picks five iterations rather than the two of the run that was snapshotted.
                        do {
                            target.step();
                        } while (target.isRunning());

                        assert.strictEqual(log.length, 5);
                    });
                });
            });
        });

        describe("keeps the child picked by a lotto node, so that", () => {
            const definition = "root { lotto [1,1,3] { action [A] action [B] action [C] } }";
            const script = {
                A: [undefined, State.SUCCEEDED],
                B: [undefined, State.FAILED],
                C: [undefined, State.SUCCEEDED]
            };

            it("the restored tree behaves like the original", () => {
                // These random numbers pick each of the three children in turn.
                [0, 0.3, 0.9].forEach((random) =>
                    assertRestoredTreeBehavesLikeOriginal(definition, script, 4, { random: () => random })
                );
            });

            it("the child is not picked again", () => {
                const source = new BehaviourTree(definition, createAgent(script).agent, { random: () => 0.9 });
                source.step();

                // Had this tree picked a child then it would have been the first one, but the source tree picked the last.
                const random = sinon.spy(() => 0);
                const { agent, log } = createAgent({ ...script, C: [State.SUCCEEDED] });
                const target = new BehaviourTree(definition, agent, { random });
                target.restore(roundTrip(source.snapshot()));

                target.step();

                assert.deepEqual(log, ["C"]);
                assert.strictEqual(target.getState(), State.SUCCEEDED);
                assert.isTrue(random.notCalled);
            });

            it("a finished tree picks a child again when it next runs", () => {
                const source = new BehaviourTree(definition, createAgent({ C: [State.SUCCEEDED] }).agent, {
                    random: () => 0.9
                });
                source.step();
                assert.strictEqual(source.getState(), State.SUCCEEDED);

                const { agent, log } = createAgent(script);
                const target = new BehaviourTree(definition, agent, { random: () => 0 });
                target.restore(roundTrip(source.snapshot()));
                target.step();

                assert.deepEqual(log, ["A"]);
            });

            it("a lotto node that was aborted before it picked a child can be restored", () => {
                const guardedDefinition = "root { lotto while(IsOk) { action [A] action [B] } }";
                const { agent } = createAgent({ A: [State.SUCCEEDED], B: [State.SUCCEEDED], IsOk: [false] });
                const source = new BehaviourTree(guardedDefinition, agent);
                source.step();
                assert.strictEqual(source.getState(), State.FAILED);

                const target = new BehaviourTree(guardedDefinition, createAgent({ IsOk: [true] }).agent);
                target.restore(roundTrip(source.snapshot()));

                assert.deepEqual(getDetailsWithoutIds(target), getDetailsWithoutIds(source));
            });

            it("a lotto node aborted by a race that it is part of can be restored", () => {
                assertRestoredTreeBehavesLikeOriginal(
                    "root { race { lotto { action [A] action [B] } action [C] } }",
                    { A: [undefined], B: [undefined], C: [undefined, undefined, State.SUCCEEDED] },
                    5,
                    { random: () => 0.7 }
                );
            });
        });

        describe("keeps how long a wait node has waited, so that", () => {
            const HOUR = 60 * 60 * 1000;
            let clock: sinon.SinonFakeTimers;

            beforeEach(() => {
                clock = sinon.useFakeTimers();
            });

            afterEach(() => {
                clock.restore();
            });

            const createWaitTree = (definition: string, options: BehaviourTreeOptions = {}) =>
                new BehaviourTree(definition, createAgent({}).agent, options);

            describe("using the clock", () => {
                it("a restored node waits only for the time it had left", () => {
                    const source = createWaitTree("root { wait [10000] }");
                    source.step();
                    clock.tick(3000);
                    source.step();
                    const snapshot = roundTrip(source.snapshot());

                    // None of the time spent not running counts towards the wait.
                    clock.tick(HOUR);
                    const target = createWaitTree("root { wait [10000] }");
                    target.restore(snapshot);
                    target.step();
                    assert.strictEqual(target.getState(), State.RUNNING);

                    clock.tick(6999);
                    target.step();
                    assert.strictEqual(target.getState(), State.RUNNING);

                    clock.tick(1);
                    target.step();
                    assert.strictEqual(target.getState(), State.SUCCEEDED);
                });

                it("the time waited since the node was last stepped is counted", () => {
                    const source = createWaitTree("root { wait [10000] }");
                    source.step();
                    clock.tick(9000);
                    const snapshot = roundTrip(source.snapshot());

                    clock.tick(HOUR);
                    const target = createWaitTree("root { wait [10000] }");
                    target.restore(snapshot);
                    target.step();
                    assert.strictEqual(target.getState(), State.RUNNING);

                    clock.tick(999);
                    target.step();
                    assert.strictEqual(target.getState(), State.RUNNING);

                    clock.tick(1);
                    target.step();
                    assert.strictEqual(target.getState(), State.SUCCEEDED);
                });

                it("the time that passes after a snapshot is taken still counts for the tree it was taken from", () => {
                    const source = createWaitTree("root { wait [10000] }");
                    source.step();
                    clock.tick(3000);
                    source.snapshot();

                    clock.tick(7000);
                    source.step();

                    assert.strictEqual(source.getState(), State.SUCCEEDED);
                });

                it("a tree can be restored to a snapshot of itself", () => {
                    const tree = createWaitTree("root { sequence { wait [10000] wait [5000] } }");
                    tree.step();
                    clock.tick(4000);
                    tree.step();
                    const snapshot = roundTrip(tree.snapshot());

                    clock.tick(HOUR);
                    tree.step();
                    assert.strictEqual(findNode(tree, "wait", "WAIT 10000ms").state, State.SUCCEEDED);

                    tree.restore(snapshot);
                    assert.strictEqual(findNode(tree, "wait", "WAIT 10000ms").state, State.RUNNING);

                    clock.tick(5999);
                    tree.step();
                    assert.strictEqual(findNode(tree, "wait", "WAIT 10000ms").state, State.RUNNING);

                    clock.tick(1);
                    tree.step();
                    assert.strictEqual(findNode(tree, "wait", "WAIT 10000ms").state, State.SUCCEEDED);
                    assert.strictEqual(findNode(tree, "wait", "WAIT 5000ms").state, State.RUNNING);
                });

                it("a duration that was chosen at random is kept rather than chosen again", () => {
                    const definition = "root { wait [1000, 5000] }";
                    // This random number gives a duration of 3000ms.
                    const source = createWaitTree(definition, { random: () => 0.5 });
                    source.step();
                    clock.tick(1000);
                    const snapshot = roundTrip(source.snapshot());

                    // Had this tree chosen a duration then it would be almost 5000ms.
                    const random = sinon.spy(() => 0.99);
                    const target = createWaitTree(definition, { random });
                    target.restore(snapshot);

                    clock.tick(1999);
                    target.step();
                    assert.strictEqual(target.getState(), State.RUNNING);

                    clock.tick(1);
                    target.step();
                    assert.strictEqual(target.getState(), State.SUCCEEDED);
                    assert.isTrue(random.notCalled);
                });

                it("a node that waits indefinitely carries on waiting", () => {
                    const source = createWaitTree("root { wait }");
                    source.step();
                    clock.tick(HOUR);

                    const target = createWaitTree("root { wait }");
                    target.restore(roundTrip(source.snapshot()));
                    clock.tick(HOUR);
                    target.step();

                    assert.strictEqual(target.getState(), State.RUNNING);
                });

                it("a finished node waits for its whole duration the next time it runs", () => {
                    const source = createWaitTree("root { wait [1000] }");
                    source.step();
                    clock.tick(1000);
                    source.step();
                    assert.strictEqual(source.getState(), State.SUCCEEDED);

                    const target = createWaitTree("root { wait [1000] }");
                    target.restore(roundTrip(source.snapshot()));
                    assert.strictEqual(target.getState(), State.SUCCEEDED);

                    clock.tick(HOUR);
                    target.step();
                    assert.strictEqual(target.getState(), State.RUNNING);

                    clock.tick(999);
                    target.step();
                    assert.strictEqual(target.getState(), State.RUNNING);

                    clock.tick(1);
                    target.step();
                    assert.strictEqual(target.getState(), State.SUCCEEDED);
                });
            });

            describe("using the 'getDeltaTime' option", () => {
                it("a restored node waits only for the time it had left", () => {
                    let deltaTime = 3;
                    const getDeltaTime = () => deltaTime;

                    const source = createWaitTree("root { wait [10000] }", { getDeltaTime });
                    source.step();
                    const snapshot = roundTrip(source.snapshot());

                    // Neither the clock nor the delta time that was last given count towards the wait.
                    clock.tick(HOUR);
                    deltaTime = 2;
                    const target = createWaitTree("root { wait [10000] }", { getDeltaTime });
                    target.restore(snapshot);

                    // Three seconds were waited by the source, and the restored tree waits another two a step.
                    target.step();
                    target.step();
                    target.step();
                    assert.strictEqual(target.getState(), State.RUNNING);

                    deltaTime = 0.999;
                    target.step();
                    assert.strictEqual(target.getState(), State.RUNNING);

                    deltaTime = 0.001;
                    target.step();
                    assert.strictEqual(target.getState(), State.SUCCEEDED);
                });

                it("a duration that was chosen at random is kept rather than chosen again", () => {
                    const getDeltaTime = () => 1;
                    const definition = "root { wait [1000, 5000] }";
                    const source = createWaitTree(definition, { getDeltaTime, random: () => 0.5 });
                    source.step();

                    const random = sinon.spy(() => 0.99);
                    const target = createWaitTree(definition, { getDeltaTime, random });
                    target.restore(roundTrip(source.snapshot()));

                    // A total of three seconds is waited, and one has been.
                    target.step();
                    assert.strictEqual(target.getState(), State.RUNNING);

                    target.step();
                    assert.strictEqual(target.getState(), State.SUCCEEDED);
                    assert.isTrue(random.notCalled);
                });
            });

            describe("a snapshot taken using one way of keeping time can be restored to a tree using the other", () => {
                it("the clock to 'getDeltaTime'", () => {
                    const source = createWaitTree("root { wait [10000] }");
                    source.step();
                    clock.tick(3000);

                    const target = createWaitTree("root { wait [10000] }", { getDeltaTime: () => 6.999 });
                    target.restore(roundTrip(source.snapshot()));
                    target.step();
                    assert.strictEqual(target.getState(), State.RUNNING);

                    target.step();
                    assert.strictEqual(target.getState(), State.SUCCEEDED);
                });

                it("'getDeltaTime' to the clock", () => {
                    const source = createWaitTree("root { wait [10000] }", { getDeltaTime: () => 3 });
                    source.step();

                    clock.tick(HOUR);
                    const target = createWaitTree("root { wait [10000] }");
                    target.restore(roundTrip(source.snapshot()));

                    clock.tick(6999);
                    target.step();
                    assert.strictEqual(target.getState(), State.RUNNING);

                    clock.tick(1);
                    target.step();
                    assert.strictEqual(target.getState(), State.SUCCEEDED);
                });
            });
        });

        describe("keeps the result of the promise returned by an action node, so that", () => {
            const flushPromises = () => new Promise<void>((resolve) => setImmediate(resolve));

            // Creates an action node tree whose action function returns the promise returned by 'createPromise' once.
            const createAsyncActionTree = (createPromise: () => Promise<unknown>) => {
                const log: string[] = [];
                const agent = {
                    A: () => {
                        log.push("A");
                        return createPromise();
                    },
                    B: () => {}
                };

                return { tree: new BehaviourTree("root { sequence { action [A] action [B] } }", agent), log };
            };

            const assertRestoredTreeThrowsLikeOriginal = (createPromise: () => Promise<unknown>, message: string) => {
                const source = createAsyncActionTree(createPromise);
                source.tree.step();
                return flushPromises().then(() => {
                    const target = createAsyncActionTree(() => new Promise(() => {}));
                    target.tree.restore(roundTrip(source.tree.snapshot()));

                    assert.throws(() => source.tree.step(), Error, message);
                    assert.throws(() => target.tree.step(), Error, message);
                    assert.deepEqual(target.log, []);
                });
            };

            it("a promise that resolved with a finished state is handled by the next step", async () => {
                for (const result of [State.SUCCEEDED, State.FAILED]) {
                    const source = createAsyncActionTree(() => Promise.resolve(result));
                    source.tree.step();
                    await flushPromises();

                    // The restored tree models the same agent, so its action function would never be called a second time.
                    const target = createAsyncActionTree(() => new Promise(() => {}));
                    target.tree.restore(roundTrip(source.tree.snapshot()));

                    assert.deepEqual(getDetailsWithoutIds(target.tree), getDetailsWithoutIds(source.tree));

                    source.tree.step();
                    target.tree.step();

                    assert.deepEqual(target.log, []);
                    assert.deepEqual(getDetailsWithoutIds(target.tree), getDetailsWithoutIds(source.tree));
                    assert.strictEqual(findNode(target.tree, "action", "A").state, result);
                }
            });

            it("a promise that was rejected causes the next step to throw", () =>
                assertRestoredTreeThrowsLikeOriginal(
                    () => Promise.reject(new Error("approval service down")),
                    "error stepping tree: action function 'A' promise rejected with 'Error: approval service down'"
                ));

            it("a promise that resolved with an invalid value causes the next step to throw", () =>
                assertRestoredTreeThrowsLikeOriginal(
                    () => Promise.resolve({ not: "a state" }),
                    "action node promise resolved with an invalid value, expected a State.SUCCEEDED or State.FAILED value to be returned"
                ));

            describe("a promise that is yet to settle", () => {
                // Creates a tree with an action 'A' that returns a promise which only settles when told to for the first call,
                // and a promise that has already resolved with 'SUCCEEDED' for every call after that.
                const createPendingActionTree = (definition = "root { sequence { action [A] action [B] } }") => {
                    const log: string[] = [];
                    let callCount = 0;
                    let settleFirstPromise: (state: State) => void = () => {};
                    const agent = {
                        A: () => {
                            log.push("A");
                            return ++callCount === 1
                                ? new Promise((resolve) => (settleFirstPromise = resolve))
                                : Promise.resolve(State.SUCCEEDED);
                        },
                        B: () => {
                            log.push("B");
                            return State.SUCCEEDED;
                        }
                    };

                    return {
                        tree: new BehaviourTree(definition, agent),
                        log,
                        settleFirstPromise: (state: State) => settleFirstPromise(state)
                    };
                };

                it("does not stop a snapshot being taken, even straight after the step that called the action function", () => {
                    const { tree } = createPendingActionTree();
                    tree.step();

                    const snapshot = tree.snapshot();

                    assert.deepEqual(roundTrip(snapshot), snapshot);
                });

                it("has no effect on the tree that the snapshot was taken from", async () => {
                    const source = createPendingActionTree();
                    source.tree.step();
                    const detailsBefore = getDetailsWithoutIds(source.tree);

                    source.tree.snapshot();

                    assert.deepEqual(getDetailsWithoutIds(source.tree), detailsBefore);

                    // The promise still settles in the tree that it belongs to, which does not call the action function again.
                    source.settleFirstPromise(State.SUCCEEDED);
                    await flushPromises();
                    source.tree.step();

                    assert.deepEqual(source.log, ["A", "B"]);
                    assert.strictEqual(source.tree.getState(), State.SUCCEEDED);
                });

                it("is restored as an action that has not yet started", () => {
                    const source = createPendingActionTree();
                    source.tree.step();

                    const target = createPendingActionTree();
                    target.tree.restore(roundTrip(source.tree.snapshot()));

                    assert.strictEqual(findNode(target.tree, "action", "A").state, State.READY);
                    assert.strictEqual(findNode(target.tree, "action", "B").state, State.READY);
                    assert.isTrue(target.tree.isRunning());
                    assert.deepEqual(target.log, []);
                });

                it("causes the restored tree to call the action function again on its next step", async () => {
                    const source = createPendingActionTree();
                    source.tree.step();

                    const target = createPendingActionTree();
                    target.tree.restore(roundTrip(source.tree.snapshot()));
                    target.tree.step();

                    assert.deepEqual(target.log, ["A"]);
                    assert.strictEqual(findNode(target.tree, "action", "A").state, State.RUNNING);

                    // The restored tree now waits for the promise that this call returned, and carries on once it settles.
                    target.settleFirstPromise(State.SUCCEEDED);
                    await flushPromises();
                    target.tree.step();

                    assert.deepEqual(target.log, ["A", "B"]);
                    assert.strictEqual(target.tree.getState(), State.SUCCEEDED);
                });

                it("is not affected by the original promise settling after the snapshot is restored to the same tree", async () => {
                    const { tree, log, settleFirstPromise } = createPendingActionTree();
                    tree.step();

                    tree.restore(roundTrip(tree.snapshot()));

                    // The original promise settles with a result that would end the run if the tree was still waiting for it.
                    settleFirstPromise(State.FAILED);
                    await flushPromises();
                    tree.step();

                    assert.deepEqual(log, ["A", "A"]);
                    assert.strictEqual(findNode(tree, "action", "A").state, State.RUNNING);

                    // The promise returned by the second call has already resolved.
                    await flushPromises();
                    tree.step();

                    assert.deepEqual(log, ["A", "A", "B"]);
                    assert.strictEqual(tree.getState(), State.SUCCEEDED);
                });

                it("leaves the progress of the rest of the tree as it was", () => {
                    const definition =
                        "root { sequence { action [B] parallel { action [A] wait [1000] } action [B] } }";
                    const source = createPendingActionTree(definition);
                    source.tree.step();

                    const target = createPendingActionTree(definition);
                    target.tree.restore(roundTrip(source.tree.snapshot()));

                    assert.strictEqual(findNode(target.tree, "parallel").state, State.RUNNING);
                    assert.strictEqual(findNode(target.tree, "wait").state, State.RUNNING);
                    assert.strictEqual(findNode(target.tree, "action", "A").state, State.READY);

                    target.tree.step();

                    // The first action 'B' had already finished, so it is not called again.
                    assert.deepEqual(target.log, ["A"]);
                });

                it("causes the entry callback of the action to be called again, as the action starts again", () => {
                    const entries: string[] = [];
                    const agent = {
                        A: () => new Promise(() => {}),
                        OnEntry: () => entries.push("entry")
                    };
                    const definition = "root { action [A] entry(OnEntry) }";
                    const source = new BehaviourTree(definition, agent);
                    source.step();
                    assert.deepEqual(entries, ["entry"]);

                    const target = new BehaviourTree(definition, agent);
                    target.restore(roundTrip(source.snapshot()));
                    target.step();

                    assert.deepEqual(entries, ["entry", "entry"]);
                });
            });

            it("a promise from before a restore cannot change the restored tree", async () => {
                let resolvePromise: (state: State) => void = () => {};
                const target = createAsyncActionTree(() => new Promise((resolve) => (resolvePromise = resolve)));
                target.tree.step();

                // This snapshot has the action node with a promise that resolved as having failed.
                const source = createAsyncActionTree(() => Promise.resolve(State.FAILED));
                source.tree.step();
                await flushPromises();
                target.tree.restore(roundTrip(source.tree.snapshot()));

                resolvePromise(State.SUCCEEDED);
                await flushPromises();
                target.tree.step();

                assert.strictEqual(findNode(target.tree, "action", "A").state, State.FAILED);
            });

            it("a promise from before a restore cannot change a restored action node that was not waiting for one", async () => {
                let resolvePromise: (state: State) => void = () => {};
                const target = createAsyncActionTree(() => new Promise((resolve) => (resolvePromise = resolve)));
                target.tree.step();

                // This snapshot has the action node running, without a promise.
                const source = new BehaviourTree("root { sequence { action [A] action [B] } }", { A: () => {} });
                source.step();
                target.tree.restore(roundTrip(source.snapshot()));

                resolvePromise(State.SUCCEEDED);
                await flushPromises();

                // The action function is called again by the step, as it would be for the source tree.
                target.tree.step();
                assert.deepEqual(target.log, ["A", "A"]);
            });
        });

        describe("restores a snapshot of a finished tree as finished", () => {
            it("with the next step starting a new run", () => {
                const definition = "root { sequence { action [A] action [B] } }";
                const { agent, log } = createAgent({ A: [State.SUCCEEDED], B: [State.SUCCEEDED] });
                const source = new BehaviourTree(definition, agent);
                source.step();
                assert.strictEqual(source.getState(), State.SUCCEEDED);

                const restored = createAgent({ A: [State.SUCCEEDED], B: [State.FAILED] });
                const target = new BehaviourTree(definition, restored.agent);
                target.restore(roundTrip(source.snapshot()));

                assert.strictEqual(target.getState(), State.SUCCEEDED);
                assert.deepEqual(getDetailsWithoutIds(target), getDetailsWithoutIds(source));
                assert.deepEqual(restored.log, []);

                target.step();

                assert.deepEqual(restored.log, ["A", "B"]);
                assert.strictEqual(target.getState(), State.FAILED);
            });

            it("for a tree that failed", () => {
                const definition = "root { selector { action [A] action [B] } }";
                const source = new BehaviourTree(
                    definition,
                    createAgent({ A: [State.FAILED], B: [State.FAILED] }).agent
                );
                source.step();
                assert.strictEqual(source.getState(), State.FAILED);

                const target = new BehaviourTree(definition, createAgent({ A: [State.SUCCEEDED] }).agent);
                target.restore(roundTrip(source.snapshot()));

                assert.strictEqual(target.getState(), State.FAILED);
                target.step();
                assert.strictEqual(target.getState(), State.SUCCEEDED);
            });
        });

        describe("will error and leave the tree unchanged if the snapshot is of another definition", () => {
            const MISMATCH_MESSAGE = "snapshot does not match the tree's definition";

            const createTree = (definition: string | RootNodeDefinition | RootNodeDefinition[], options = {}) =>
                new BehaviourTree(
                    definition,
                    createAgent({ A: [undefined], B: [undefined], C: [true] }).agent,
                    options
                );

            // Asserts that restoring a snapshot of the source definition to a tree of the target definition throws an
            // error about the definitions not matching, and leaves the target tree as it was.
            const assertRestoreIsRejected = (
                sourceDefinition: string | RootNodeDefinition | RootNodeDefinition[],
                targetDefinition: string | RootNodeDefinition | RootNodeDefinition[]
            ) => {
                const source = createTree(sourceDefinition);
                source.step();
                const snapshot = roundTrip(source.snapshot());

                const stateChanges: string[] = [];
                const target = createTree(targetDefinition, { onNodeStateChange: () => stateChanges.push("changed") });
                target.step();
                const detailsBefore = getDetailsWithoutIds(target);
                stateChanges.length = 0;

                assert.throws(() => target.restore(snapshot), Error, MISMATCH_MESSAGE);

                assert.deepEqual(getDetailsWithoutIds(target), detailsBefore);
                assert.deepEqual(stateChanges, []);

                // The tree carries on as if the restore was never attempted.
                assert.doesNotThrow(() => target.step());
            };

            // Asserts that a snapshot of the source definition can be restored to a tree of the target definition, which then
            // has the same node states as the source tree.
            const assertRestoreIsAccepted = (
                sourceDefinition: string | RootNodeDefinition | RootNodeDefinition[],
                targetDefinition: string | RootNodeDefinition | RootNodeDefinition[]
            ) => {
                const source = createTree(sourceDefinition);
                source.step();

                const target = createTree(targetDefinition);
                target.restore(roundTrip(source.snapshot()));

                assert.deepEqual(getDetailsWithoutIds(target), getDetailsWithoutIds(source));
            };

            it("when it has the same structure but calls a different function", () =>
                assertRestoreIsRejected(
                    "root { sequence { action [A] action [B] } }",
                    "root { sequence { action [A] action [C] } }"
                ));

            it("when it has a different structure", () => {
                assertRestoreIsRejected(
                    "root { sequence { action [A] action [B] } }",
                    "root { selector { action [A] action [B] } }"
                );
                assertRestoreIsRejected(
                    "root { sequence { action [A] action [B] } }",
                    "root { sequence { action [A] } }"
                );
                assertRestoreIsRejected("root { action [A] }", "root { sequence { action [A] } }");
            });

            it("when it is of a different type of node with the same state", () =>
                assertRestoreIsRejected("root { action [A] }", "root { wait [100] }"));

            it("when it has different arguments", () => {
                assertRestoreIsRejected('root { action [A, 1, "x"] }', 'root { action [A, 2, "x"] }');
                assertRestoreIsRejected("root { action [A, 1] }", "root { action [A] }");
                assertRestoreIsRejected("root { action [A, true] }", 'root { action [A, "true"] }');
            });

            it("when it has a different wait duration, repeat iteration count or retry attempt count", () => {
                assertRestoreIsRejected("root { wait [100] }", "root { wait [200] }");
                assertRestoreIsRejected("root { wait [100, 200] }", "root { wait [100, 300] }");
                assertRestoreIsRejected("root { wait [100] }", "root { wait }");
                assertRestoreIsRejected("root { repeat [2] { action [A] } }", "root { repeat [3] { action [A] } }");
                assertRestoreIsRejected("root { repeat [2] { action [A] } }", "root { repeat { action [A] } }");
                assertRestoreIsRejected("root { retry [2] { action [A] } }", "root { retry [3] { action [A] } }");
            });

            it("when it has different lotto weights", () =>
                assertRestoreIsRejected(
                    "root { lotto [1, 2] { action [A] action [B] } }",
                    "root { lotto [2, 1] { action [A] action [B] } }"
                ));

            it("when it has a guard that moves to a different state when it aborts", () =>
                assertRestoreIsRejected("root { action [A] while(C) }", "root { action [A] while(C) then succeed }"));

            it("when it has different guards or callbacks", () => {
                assertRestoreIsRejected("root { action [A] while(C) }", "root { action [A] until(C) }");
                assertRestoreIsRejected("root { action [A] while(C) }", "root { action [A] while(C, 1) }");
                assertRestoreIsRejected("root { action [A] entry(B) }", "root { action [A] exit(B) }");
                assertRestoreIsRejected("root { action [A] }", "root { action [A] step(B) }");
            });

            it("when it has different subtrees", () =>
                assertRestoreIsRejected(
                    "root { branch [Sub] } root [Sub] { action [A] }",
                    "root { branch [Sub] } root [Sub] { action [B] }"
                ));

            it("when it is of a definition that only differs from the tree's by being a different tree", () => {
                const source = createTree("root { sequence { action [A] action [B] } }");
                source.step();
                const target = createTree("root { sequence { action [B] action [A] } }");

                assert.throws(() => target.restore(source.snapshot()), Error, MISMATCH_MESSAGE);
            });

            it("is a plain Error, rather than an error that only mentions the structure of the tree", () => {
                const source = createTree("root { sequence { action [A] } }");
                const target = createTree("root { selector { action [A] action [B] } }");

                try {
                    target.restore(source.snapshot());
                    assert.fail("expected restore to throw");
                } catch (error) {
                    assert.instanceOf(error, Error);
                    assert.include((error as Error).message, MISMATCH_MESSAGE);
                }
            });

            it("without affecting a promise that the tree is waiting for", async () => {
                let resolvePromise: (state: State) => void = () => {};
                const target = new BehaviourTree("root { sequence { action [A] action [B] } }", {
                    A: () => new Promise((resolve) => (resolvePromise = resolve)),
                    B: () => State.SUCCEEDED
                });
                target.step();

                const source = createTree("root { sequence { action [A] } }");
                source.step();

                assert.throws(() => target.restore(source.snapshot()), Error, MISMATCH_MESSAGE);

                resolvePromise(State.SUCCEEDED);
                await new Promise<void>((resolve) => setImmediate(resolve));
                target.step();

                assert.strictEqual(target.getState(), State.SUCCEEDED);
            });

            describe("but accepts a snapshot of the same definition", () => {
                it("written as MDSL, with different layout and comments", () =>
                    assertRestoreIsAccepted(
                        "root { sequence { action [A] wait [100] } }",
                        `root {
                            /* the same tree */
                            sequence {
                                action [A]
                                wait [100]
                            }
                        }`
                    ));

                it("when it is MDSL and the tree was created from the equivalent JSON", () => {
                    const mdsl = `root {
                        sequence {
                            action [A, 1, "x", true, null] while(C, 2) entry(B)
                            parallel { wait [100, 200] repeat [2, 3] { lotto [1, 2] { action [B] action [C] } } }
                            retry [2] { condition [C] }
                        }
                    }`;

                    assertRestoreIsAccepted(mdsl, convertMDSLToJSON(mdsl)[0]);
                    assertRestoreIsAccepted(mdsl, convertMDSLToJSON(mdsl));
                });

                it("when it is JSON and the tree was created from the equivalent MDSL", () => {
                    const mdsl = "root { sequence { action [A, 1] wait [100] } }";

                    assertRestoreIsAccepted(convertMDSLToJSON(mdsl)[0], mdsl);
                    assertRestoreIsAccepted(convertMDSLToJSON(mdsl), mdsl);
                });

                it("when it is MDSL with subtrees and the tree was created from the equivalent JSON", () => {
                    const mdsl =
                        "root { branch [A1] } root [A1] { sequence { action [A] branch [B1] } } root [B1] { action [B] }";

                    assertRestoreIsAccepted(mdsl, convertMDSLToJSON(mdsl));
                    assertRestoreIsAccepted(convertMDSLToJSON(mdsl), mdsl);
                });

                it("when the JSON is written with its properties and its subtrees in a different order", () => {
                    const json: RootNodeDefinition[] = [
                        {
                            type: "root",
                            child: {
                                type: "sequence",
                                children: [
                                    { type: "action", call: "A", args: [1, "x"], while: { call: "C", args: [] } },
                                    { type: "branch", ref: "Sub" }
                                ]
                            }
                        },
                        { type: "root", id: "Sub", child: { type: "action", call: "B" } }
                    ];
                    const reordered: RootNodeDefinition[] = [
                        { id: "Sub", child: { call: "B", type: "action" }, type: "root" },
                        {
                            child: {
                                children: [
                                    { while: { args: [], call: "C" }, args: [1, "x"], call: "A", type: "action" },
                                    { ref: "Sub", type: "branch" }
                                ],
                                type: "sequence"
                            },
                            type: "root"
                        }
                    ];

                    assertRestoreIsAccepted(json, reordered);
                    assertRestoreIsAccepted(reordered, json);
                });

                it("when the JSON leaves out the arguments and abort result that the MDSL converter always writes", () => {
                    const mdsl = "root { sequence { action [A] while(C) entry(B) condition [C] until(C) } }";
                    const handWritten: RootNodeDefinition = {
                        type: "root",
                        child: {
                            type: "sequence",
                            children: [
                                {
                                    type: "action",
                                    call: "A",
                                    while: { call: "C" },
                                    entry: { call: "B" }
                                },
                                { type: "condition", call: "C", until: { call: "C" } }
                            ]
                        }
                    };

                    assertRestoreIsAccepted(mdsl, handWritten);
                    assertRestoreIsAccepted(handWritten, mdsl);
                });

                it("when the JSON gives empty arguments and an abort result of fail explicitly", () =>
                    assertRestoreIsAccepted(
                        { type: "root", child: { type: "action", call: "A", while: { call: "C" } } },
                        {
                            type: "root",
                            child: {
                                type: "action",
                                call: "A",
                                args: [],
                                while: { call: "C", args: [], succeedOnAbort: false }
                            }
                        }
                    ));

                it("when the JSON has properties that are undefined", () =>
                    assertRestoreIsAccepted(
                        { type: "root", child: { type: "action", call: "A" } },
                        { type: "root", child: { type: "action", call: "A", args: undefined, while: undefined } }
                    ));

                it("when the definition object is changed after the tree was created", () => {
                    const definition: RootNodeDefinition = { type: "root", child: { type: "action", call: "A" } };
                    const source = createTree(definition);
                    source.step();
                    const snapshot = roundTrip(source.snapshot());

                    (definition.child as { call: string }).call = "B";

                    const target = createTree({ type: "root", child: { type: "action", call: "A" } });
                    assert.doesNotThrow(() => target.restore(snapshot));
                });
            });

            it("or are different in the way that does not matter to a restore, accepts a snapshot", () => {
                // The agent, options and registered functions are not part of the definition.
                const definition = "root { sequence { action [A] action [B] } }";
                const source = createTree(definition, { random: () => 0.1 });
                source.step();

                const target = new BehaviourTree(definition, createAgent({ A: [State.FAILED] }).agent, {
                    random: () => 0.9,
                    getDeltaTime: () => 1
                });

                assert.doesNotThrow(() => target.restore(roundTrip(source.snapshot())));
            });
        });

        describe("will error and leave the tree unchanged if what it is given is not a snapshot, as it is", () => {
            const definition = "root { sequence { action [A] action [B] } }";
            let tree: BehaviourTree;
            let validSnapshot: any;
            let detailsBefore: any;
            let stateChanges: string[];

            beforeEach(() => {
                stateChanges = [];
                const { agent } = createAgent({ A: [State.SUCCEEDED], B: [undefined] });
                const source = new BehaviourTree(definition, agent);
                source.step();
                validSnapshot = roundTrip(source.snapshot());

                tree = new BehaviourTree(definition, createAgent({ A: [undefined], B: [undefined] }).agent, {
                    onNodeStateChange: () => stateChanges.push("changed")
                });
                tree.step();
                detailsBefore = getDetailsWithoutIds(tree);
                stateChanges.length = 0;
            });

            const assertNotRestored = (value: any) => {
                assert.throws(() => tree.restore(value), Error);
                assert.deepEqual(getDetailsWithoutIds(tree), detailsBefore);
                assert.deepEqual(stateChanges, []);
            };

            [
                ["null", null],
                ["undefined", undefined],
                ["a string", "root"],
                ["a JSON string of a snapshot", JSON.stringify({ type: "root", state: State.READY })],
                ["a number", 1],
                ["a boolean", true],
                ["an array", []],
                ["an array of snapshots", [{ type: "root" }]],
                ["a function", () => {}],
                ["an object without the snapshot's fields", {}],
                ["an object with only some of the snapshot's fields", { type: "root", state: State.READY }]
            ].forEach(([description, value]) =>
                it(`${description}`, () => {
                    assertNotRestored(value);
                })
            );

            it("a node snapshot that is not the root of a tree", () => assertNotRestored(validSnapshot.children[0]));

            it("a snapshot that does not say which definition it belongs to", () => {
                const { definitionFingerprint, ...withoutFingerprint } = validSnapshot;

                assert.isString(definitionFingerprint);
                assertNotRestored(withoutFingerprint);
            });

            [
                ["a number", 1],
                ["null", null],
                ["an empty string", ""],
                ["an object", {}]
            ].forEach(([description, value]) =>
                it(`a snapshot whose definition is ${description}`, () =>
                    assertNotRestored({ ...validSnapshot, definitionFingerprint: value }))
            );

            it("a valid snapshot can still be restored after any of them are rejected", () => {
                assertNotRestored(null);
                assertNotRestored({});

                tree.restore(validSnapshot);

                assert.strictEqual(findNode(tree, "action", "A").state, State.SUCCEEDED);
                assert.strictEqual(findNode(tree, "action", "B").state, State.RUNNING);
            });
        });

        describe("will error and leave the tree unchanged if the snapshot", () => {
            const definition = "root { sequence { action [A] parallel { action [B] action [C] } } }";
            let tree: BehaviourTree;
            let validSnapshot: any;
            let detailsBefore: any;

            beforeEach(() => {
                const { agent } = createAgent({ A: [State.SUCCEEDED], B: [undefined], C: [undefined] });
                tree = new BehaviourTree(definition, agent);
                tree.step();
                validSnapshot = roundTrip(tree.snapshot());
                detailsBefore = getDetailsWithoutIds(tree);
            });

            const assertRestoreFails = (snapshot: any, message: string, target: BehaviourTree = tree) => {
                // Make sure the tree has moved on from the state it was in when snapshotted.
                target.reset();
                const resetDetails = getDetailsWithoutIds(target);

                assert.throws(() => target.restore(snapshot), Error, message);
                assert.deepEqual(getDetailsWithoutIds(target), resetDetails);
            };

            it("is not an object", () => {
                assertRestoreFails(null as any, "invalid snapshot: expected an object at 'root'");
                assertRestoreFails("snapshot" as any, "invalid snapshot: expected an object at 'root'");
                assertRestoreFails([] as any, "invalid snapshot: expected an object at 'root'");
            });

            it("has a node of the wrong type", () => {
                const snapshot = roundTrip(validSnapshot);
                snapshot.children[0].children[1].children[0].type = "condition";

                assertRestoreFails(
                    snapshot,
                    "invalid snapshot: expected node of type 'action' but got 'condition' at 'root.children[0].children[1].children[0]'"
                );
            });

            it("has a node with the wrong number of children", () => {
                const snapshot = roundTrip(validSnapshot);
                snapshot.children[0].children[1].children.pop();

                assertRestoreFails(
                    snapshot,
                    "invalid snapshot: expected 2 children but got 1 at 'root.children[0].children[1]'"
                );
            });

            it("has a node with no children array when it needs one", () => {
                const snapshot = roundTrip(validSnapshot);
                delete snapshot.children[0].children;

                assertRestoreFails(
                    snapshot,
                    "invalid snapshot: expected 2 children but got none at 'root.children[0]'"
                );
            });

            it("has a node with an invalid state", () => {
                const snapshot = roundTrip(validSnapshot);
                snapshot.children[0].children[0].state = "not-a-state";

                assertRestoreFails(
                    snapshot,
                    "invalid snapshot: invalid node state 'not-a-state' at 'root.children[0].children[0]'"
                );
            });

            describe("has a repeat or retry node with an invalid", () => {
                const iterationNodeDefinitions = [
                    { node: "repeat", target: "targetIterationCount", current: "currentIterationCount" },
                    { node: "retry", target: "targetAttemptCount", current: "currentAttemptCount" }
                ];

                iterationNodeDefinitions.forEach(({ node, target, current }) => {
                    const invalidCounts = [-1, 1.5, "1", undefined];

                    // Snapshots a repeat or retry node that is part way through, with a count then set to an invalid value.
                    const assertInvalidCountFails = (property: string, expected: string) =>
                        invalidCounts.forEach((value) => {
                            const iterationTree = new BehaviourTree(
                                `root { ${node} [2,4] { action [A] } }`,
                                createAgent({ A: [undefined] }).agent
                            );
                            iterationTree.step();
                            const snapshot: any = roundTrip(iterationTree.snapshot());
                            snapshot.children[0][property] = value;

                            assertRestoreFails(
                                snapshot,
                                `invalid snapshot: expected '${property}' to be ${expected} at 'root.children[0]'`,
                                iterationTree
                            );
                        });

                    it(`${current} that is not a non-negative integer (${node})`, () =>
                        assertInvalidCountFails(current, "a non-negative integer"));

                    it(`${target} that is not null or a non-negative integer (${node})`, () =>
                        assertInvalidCountFails(target, "null or a non-negative integer"));
                });
            });

            describe("has an action node with an invalid updatePromiseResult", () => {
                [undefined, "settled", [], { isResolved: "yes", value: null }, { isResolved: true, value: 1 }].forEach(
                    (value) =>
                        it(`of ${JSON.stringify(value)}`, () => {
                            const snapshot: any = roundTrip(validSnapshot);
                            snapshot.children[0].children[0].updatePromiseResult = value;

                            assertRestoreFails(
                                snapshot,
                                "invalid snapshot: expected 'updatePromiseResult' to be null or an object with a boolean 'isResolved' and a string or null 'value' at 'root.children[0].children[0]'"
                            );
                        })
                );
            });

            describe("has a wait node with an invalid", () => {
                const assertInvalidWaitFails = (property: string, expected: string, values: unknown[]) =>
                    values.forEach((value) => {
                        const waitTree = new BehaviourTree("root { wait [1000] }", createAgent({}).agent);
                        waitTree.step();
                        const snapshot: any = roundTrip(waitTree.snapshot());
                        snapshot.children[0][property] = value;

                        assertRestoreFails(
                            snapshot,
                            `invalid snapshot: expected '${property}' to be ${expected} at 'root.children[0]'`,
                            waitTree
                        );
                    });

                it("totalDuration", () =>
                    assertInvalidWaitFails("totalDuration", "null or a non-negative number", [
                        -1,
                        "1",
                        undefined,
                        NaN
                    ]));

                it("waitedDuration", () =>
                    assertInvalidWaitFails("waitedDuration", "a number", ["1", null, undefined, NaN, Infinity]));
            });

            it("has a running lotto node with no selectedChildIndex", () => {
                const lottoTree = new BehaviourTree(
                    "root { lotto { action [A] action [B] } }",
                    createAgent({ A: [undefined], B: [undefined] }).agent
                );
                lottoTree.step();
                const snapshot: any = roundTrip(lottoTree.snapshot());
                snapshot.children[0].selectedChildIndex = null;

                assertRestoreFails(
                    snapshot,
                    "invalid snapshot: expected 'selectedChildIndex' to be the index of a child for a running node at 'root.children[0]'",
                    lottoTree
                );
            });

            describe("has a lotto node with a selectedChildIndex that", () => {
                const assertInvalidIndexFails = (value: unknown) => {
                    const lottoTree = new BehaviourTree(
                        "root { lotto { action [A] action [B] } }",
                        createAgent({ A: [undefined], B: [undefined] }).agent
                    );
                    lottoTree.step();
                    const snapshot: any = roundTrip(lottoTree.snapshot());
                    snapshot.children[0].selectedChildIndex = value;

                    assertRestoreFails(
                        snapshot,
                        "invalid snapshot: expected 'selectedChildIndex' to be null or the index of a child at 'root.children[0]'",
                        lottoTree
                    );
                };

                it("is not a number", () => {
                    assertInvalidIndexFails("1");
                    assertInvalidIndexFails(undefined);
                });

                it("is not an integer", () => assertInvalidIndexFails(0.5));
                it("is negative", () => assertInvalidIndexFails(-1));
                it("is not the index of a child", () => assertInvalidIndexFails(2));
            });

            it("is valid but is restored after a failed restore", () => {
                assert.throws(() => tree.restore({ type: "root" } as any));
                tree.reset();
                tree.restore(validSnapshot);

                assert.deepEqual(getDetailsWithoutIds(tree), detailsBefore);
            });
        });
    });
});
