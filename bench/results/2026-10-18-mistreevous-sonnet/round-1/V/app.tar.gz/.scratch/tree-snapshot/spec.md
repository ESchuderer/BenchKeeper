Status: ready-for-agent

# Snapshot and restore a behaviour tree's execution state

Feature request: long-running workflows (hours/days, process restarts) need to persist a tree's execution
state and resume it. Storage, event handling and scheduling stay in the application.

## Public API (the seam all tests go through)

- `BehaviourTree#snapshot(): BehaviourTreeSnapshot`
- `BehaviourTree#restore(snapshot: BehaviourTreeSnapshot): void`
- `BehaviourTreeSnapshot` (and `NodeSnapshot`) exported from the package as types.

Tests drive these through `BehaviourTree` only: `step()`, `getTreeNodeDetails()`, agent function call logs, the
`random` / `getDeltaTime` options and (for `Date`) sinon fake timers. No test reaches into node internals.

## Format

Plain JSON, no `undefined`, functions, class instances, `NaN` or `Infinity`:

```
{ version: 1, definition: string, root: NodeSnapshot }
NodeSnapshot = { id, type, state, ...type specific }
```

The snapshot mirrors the node tree (`children` arrays). Nodes are matched by position, not by id.
`id` is kept so a restored tree reports the same ids in `getTreeNodeDetails()` / `onNodeStateChange`.
`version` lets later releases change the format and reject (or migrate) old snapshots.
`definition` is a fingerprint (hash) of the definition the tree was built from, see "Definition" below.

| Node                                  | State kept besides `id`, `type`, `state`                                         |
| ------------------------------------- | -------------------------------------------------------------------------------- |
| root, flip, succeed, fail             | `children` (one)                                                                 |
| sequence, selector, parallel, race, all | `children` (each child's state says which are done / running)                  |
| lotto                                 | `children`, `selectedChild` (index or `null`)                                    |
| repeat / retry                        | `children`, `target` (random or fixed count, `null` = unbounded), `current`      |
| wait                                  | `totalDuration` (ms, `null` = indefinite), `waitedDuration` (ms)                 |
| action                                | settled-but-unconsumed promise result, if any (`promiseResult`)                  |
| condition                             | nothing                                                                          |

### Wait timing

`waitedDuration` is the time already waited at snapshot time: in `Date` mode `now - initialUpdateTime` (the node only
refreshes it on update), in `getDeltaTime` mode the accumulated value. On restore the node sets
`initialUpdateTime = now - waitedDuration`, so time between snapshot and restore does not count in either mode.
Only a RUNNING wait keeps timing state (`0` / `null` otherwise) which also keeps the snapshot free of non-finite numbers.

### Async actions

A promise cannot be serialised. An action whose promise has settled but not yet been consumed by a step stores the
result (resolved state, or rejection reason as a string). An action still awaiting an unsettled promise is saved as
not yet started (state `READY`, no `promiseResult`): the restored tree calls its action function (and `entry`)
again on its next step. This is a documented limitation, not "behaves exactly like the original". `snapshot()` does
not throw for it.

### Definition

The fingerprint is a hash of a normalised form of the resolved tree: it only contains what the builder makes of the
definition (defaults for `args` and `succeedOnAbort` applied, branches replaced by the subtree they reference,
globally registered subtrees included), so an MDSL definition and its equivalent JSON definition, however they are
formatted or ordered, have the same fingerprint, and anything that changes the built tree changes it.

## Rules

- `restore` is atomic: the whole snapshot is validated (version, node types, child counts, field types) before any
  node is touched; an invalid or mismatched snapshot throws `invalid snapshot: ...` and leaves the tree as it was. Input that is not a
  snapshot (not an object, an array, no `version`/`definition`) is rejected the same way. A snapshot whose `definition`
  is not the tree's is rejected with `invalid snapshot: the snapshot does not match the tree's definition`, before its
  nodes are looked at.
- `restore` is not execution: no `entry`/`step`/`exit` callbacks, guards or agent functions run, and
  `onNodeStateChange` is not called. A pending promise of the tree being restored over is discarded.
- `snapshot` / `restore` throw if called while the tree is being stepped (e.g. from an agent function): the node
  states are mid-update and would not be a consistent restore point.
- A finished tree restores as finished; the next `step()` resets it and makes its random choices again.
- Snapshots are copies: mutating one afterwards does not affect the tree, and vice versa.

## Out of scope

- Global registrations (`BehaviourTree.register`) and agent state: owned by the application.

## Housekeeping

README section + example, Version History row, version bump to 4.4.0 (new feature, minor), rebuilt `dist`.
