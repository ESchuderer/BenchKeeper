import { AnyNodeDefinition, NodeDefinition, RootNodeDefinition } from "./BehaviourTreeDefinition";
import { MAIN_ROOT_NODE_KEY, RootNodeDefinitionMap, createRootNodeDefinitionMap } from "./BehaviourTreeBuilder";
import { isInteger } from "./BehaviourTreeDefinitionUtilities";
import { hashString } from "./Utilities";

/**
 * Gets the normalised form of the 'while' and 'until' guard attributes of a node definition, with the defaults that the builder applies.
 * @param guard The guard attribute definition, if there is one.
 */
function normaliseGuard(guard: NodeDefinition["while"]) {
    return guard && { call: guard.call, args: guard.args ?? [], succeedOnAbort: !!guard.succeedOnAbort };
}

/**
 * Gets the normalised form of the 'entry', 'step' and 'exit' callback attributes of a node definition, with the defaults that the builder applies.
 * @param callback The callback attribute definition, if there is one.
 */
function normaliseCallback(callback: NodeDefinition["entry"]) {
    return callback && { call: callback.call, args: callback.args ?? [] };
}

/**
 * Gets the normalised form of the iterations, attempts or duration of a node definition, which is a number, a pair of numbers, or null if there is none.
 * @param value The value from the node definition.
 */
function normaliseCount(value: number | [number, number] | undefined) {
    if (Array.isArray(value)) {
        return [value[0], value[1]];
    }

    return isInteger(value) ? value! : null;
}

/**
 * Gets the normalised form of a node definition, and of all of its nested nodes.
 * This is only concerned with what the builder makes of a definition, and not with how it was written, so that for example the same tree defined with MDSL and
 * with JSON is described in the same way. Branch nodes are replaced by the nodes of the subtree that they reference.
 * @param definition The node definition.
 * @param rootNodeDefinitionMap The mapping of root node identifers to root node definitions, including globally registered subtree root node definitions.
 */
function normaliseNode(definition: AnyNodeDefinition, rootNodeDefinitionMap: RootNodeDefinitionMap): unknown {
    const normaliseChild = (child: AnyNodeDefinition) => normaliseNode(child, rootNodeDefinitionMap);

    // The attributes of a branch node are never used, it is replaced by the child of the root node that it references.
    if (definition.type === "branch") {
        return normaliseChild(rootNodeDefinitionMap[definition.ref].child);
    }

    // The order of the properties is part of the result, so it is always the same.
    const common = {
        type: definition.type,
        while: normaliseGuard(definition.while),
        until: normaliseGuard(definition.until),
        entry: normaliseCallback(definition.entry),
        step: normaliseCallback(definition.step),
        exit: normaliseCallback(definition.exit)
    };

    switch (definition.type) {
        case "root":
        case "flip":
        case "succeed":
        case "fail":
            return { ...common, child: normaliseChild(definition.child) };

        case "repeat":
            return {
                ...common,
                iterations: normaliseCount(definition.iterations),
                child: normaliseChild(definition.child)
            };

        case "retry":
            return {
                ...common,
                attempts: normaliseCount(definition.attempts),
                child: normaliseChild(definition.child)
            };

        case "sequence":
        case "selector":
        case "parallel":
        case "race":
        case "all":
            return { ...common, children: definition.children.map(normaliseChild) };

        case "lotto":
            return {
                ...common,
                weights: definition.children.map((_, index) => definition.weights?.[index] || 1),
                children: definition.children.map(normaliseChild)
            };

        case "action":
        case "condition":
            return { ...common, call: definition.call, args: definition.args ?? [] };

        case "wait":
            return { ...common, duration: normaliseCount(definition.duration) };

        default:
            throw new Error(`unexpected node type '${(definition as NodeDefinition).type}'`);
    }
}

/**
 * Creates a fingerprint of a tree definition, which is the same for any definitions that build the same tree and is otherwise different.
 * Definitions are considered to be the same when they only differ in how they are written, for example when one is MDSL and the other is its equivalent JSON.
 * This takes the globally registered subtrees into account, as the tree built from the definition does.
 * @param definition The root node definitions, which must have been validated.
 * @returns The fingerprint of the definition.
 */
export function createDefinitionFingerprint(definition: RootNodeDefinition[]): string {
    const rootNodeDefinitionMap = createRootNodeDefinitionMap(definition);

    return hashString(JSON.stringify(normaliseNode(rootNodeDefinitionMap[MAIN_ROOT_NODE_KEY], rootNodeDefinitionMap)));
}
