import { AnyState } from "./State";

/**
 * The snapshot of a node in a behaviour tree, mirroring the structure of the tree.
 * Only the properties relevant to the type of the node are defined.
 */
export type NodeSnapshot = {
    /**
     * The node unique identifier.
     */
    id: string;
    /**
     * The node type.
     */
    type: string;
    /**
     * The node state.
     */
    state: AnyState;
    /**
     * The snapshots of the child nodes, defined for composite and decorator nodes.
     */
    children?: NodeSnapshot[];
    /**
     * The number of iterations (repeat node) or attempts (retry node) to make in total, or null if unbounded.
     * This will be the explicit number or the number that was randomly chosen between the minimum and maximum.
     */
    target?: number | null;
    /**
     * The number of iterations (repeat node) or attempts (retry node) completed so far.
     */
    current?: number;
    /**
     * The index of the child node that a lotto node picked, or null if it has not picked one yet.
     */
    selectedChild?: number | null;
    /**
     * The duration in milliseconds that a wait node is waiting for in total, or null if it will wait indefinitely.
     * This will be the explicit duration or the duration that was randomly chosen between the minimum and maximum.
     * This is only meaningful for a wait node in the running state.
     */
    totalDuration?: number | null;
    /**
     * The duration in milliseconds that a wait node has waited for so far.
     * This is only meaningful for a wait node in the running state.
     */
    waitedDuration?: number;
    /**
     * The settled result of the promise that an action node in the running state is waiting on, if it has settled but has not been used by a tree step yet.
     * The value is the resolved node state (or null if it was not a valid one), or the rejection reason as a string.
     */
    promiseResult?: { isResolved: boolean; value: string | null } | null;
};

/**
 * A snapshot of the execution state of a behaviour tree.
 * This is a plain object that can be passed through `JSON.stringify` and `JSON.parse` unchanged.
 */
export type BehaviourTreeSnapshot = {
    /**
     * The snapshot format version.
     */
    version: 1;
    /**
     * A fingerprint of the definition of the tree that the snapshot was taken from.
     * A snapshot can only be restored to a tree with the same definition, whether it was defined as MDSL or as JSON.
     */
    definition: string;
    /**
     * The snapshot of the root node.
     */
    root: NodeSnapshot;
};

/**
 * Creates the error to throw when a snapshot is invalid.
 * @param message The description of what is invalid.
 * @param path The path to the invalid part of the snapshot, if it is not the snapshot as a whole.
 * @returns The error to throw.
 */
export function createInvalidSnapshotError(message: string, path?: string): Error {
    return new Error(`invalid snapshot: ${message}${path ? ` at '${path}'` : ""}`);
}

/**
 * Gets whether the value is a non-negative integer.
 * @param value The value to check.
 */
export function isNonNegativeInteger(value: unknown): value is number {
    return Number.isInteger(value) && (value as number) >= 0;
}

/**
 * Gets whether the value is a finite number.
 * @param value The value to check.
 */
export function isFiniteNumber(value: unknown): value is number {
    return typeof value === "number" && Number.isFinite(value);
}
