import Node, { NodeDetails } from "../Node";
import { NodeSnapshot, createInvalidSnapshotError } from "../../BehaviourTreeSnapshot";
import State from "../../State";
import { Agent } from "../../Agent";
import Attribute from "../../attributes/Attribute";
import { BehaviourTreeOptions } from "../../BehaviourTreeOptions";

/**
 * A composite node that wraps child nodes.
 */
export default abstract class Composite extends Node {
    /**
     * @param type The node type.
     * @param attributes The node attributes.
     * @param options The behaviour tree options.
     * @param children The child nodes.
     */
    constructor(type: string, attributes: Attribute[], options: BehaviourTreeOptions, protected children: Node[]) {
        super(type, attributes, options);
    }

    /**
     * Gets the children of this node.
     */
    getChildren = () => this.children;

    /**
     * Reset the state of the node.
     */
    reset = () => {
        // Reset the state of this node.
        this.setState(State.READY);

        // Reset the state of any child nodes.
        this.children.forEach((child) => child.reset());
    };

    /**
     * Abort the running of this node.
     * @param agent The agent.
     */
    abort = (agent: Agent) => {
        // There is nothing to do if this node is not in the running state.
        if (!this.is(State.RUNNING)) {
            return;
        }

        // Abort any child nodes.
        this.children.forEach((child) => child.abort(agent));

        // Reset the state of this node.
        this.reset();

        this.attributes.exit?.callAgentFunction(agent, false, true);
    };

    /**
     * Gets the details of this node instance.
     * @returns The details of this node instance.
     */
    public getDetails(): NodeDetails {
        return {
            ...super.getDetails(),
            children: this.children.map((child) => child.getDetails())
        };
    }

    /**
     * Gets the snapshot of this node instance.
     * @returns The snapshot of this node instance.
     */
    public getSnapshot(): NodeSnapshot {
        return {
            ...super.getSnapshot(),
            children: this.children.map((child) => child.getSnapshot())
        };
    }

    /**
     * Checks that a snapshot can be restored to this node instance and its children, throwing an error if not.
     * @param snapshot The snapshot to check.
     * @param path The path to the snapshot node, for use in error messages.
     */
    public validateSnapshot(snapshot: NodeSnapshot, path: string): void {
        super.validateSnapshot(snapshot, path);

        const childSnapshots = Array.isArray(snapshot.children) ? snapshot.children : [];
        const children = this.children;

        if (childSnapshots.length !== children.length) {
            throw createInvalidSnapshotError(
                `expected ${children.length} children but found ${childSnapshots.length}`,
                path
            );
        }

        children.forEach((child, index) => child.validateSnapshot(childSnapshots[index], `${path}.children[${index}]`));
    }

    /**
     * Restores this node instance, and its children, to the state described by a snapshot.
     * @param snapshot The snapshot to restore.
     */
    public restoreSnapshot(snapshot: NodeSnapshot): void {
        super.restoreSnapshot(snapshot);

        this.children.forEach((child, index) => child.restoreSnapshot(snapshot.children![index]));
    }
}
