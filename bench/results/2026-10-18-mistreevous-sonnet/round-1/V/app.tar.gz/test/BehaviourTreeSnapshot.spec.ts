import { assert } from "chai";
import sinon, { SinonFakeTimers } from "sinon";

import { BehaviourTree, BehaviourTreeOptions, BehaviourTreeSnapshot, State } from "../src/index";
import { Agent } from "../src/Agent";
import { RootNodeDefinition } from "../src/BehaviourTreeDefinition";

/**
 * Passes a snapshot through JSON, as an application persisting it would.
 */
function persist(snapshot: BehaviourTreeSnapshot): BehaviourTreeSnapshot {
    return JSON.parse(JSON.stringify(snapshot));
}

/**
 * A scenario in which a tree is snapshotted part way through, and the original tree and a tree restored from the snapshot are then compared.
 * Everything the application owns (the agent state and the random number generator) lives in a plain 'world' object, so that the restored tree can be given the
 * world as it was at the time of the snapshot.
 */
type Scenario<World> = {
    definition: string;
    createWorld: () => World;
    createAgent: (world: World, calls: string[]) => Agent;
    createOptions?: (world: World) => BehaviourTreeOptions;
    totalSteps: number;
};

/**
 * Asserts that, for every step at which a snapshot could be taken, a tree restored from that snapshot behaves exactly like the original tree.
 */
function assertRestoredTreeMatchesOriginal<World>(scenario: Scenario<World>) {
    for (let stepsBeforeSnapshot = 0; stepsBeforeSnapshot <= scenario.totalSteps; stepsBeforeSnapshot++) {
        const context = `snapshot taken after ${stepsBeforeSnapshot} steps`;

        const world = scenario.createWorld();
        const calls: string[] = [];
        const original = new BehaviourTree(
            scenario.definition,
            scenario.createAgent(world, calls),
            scenario.createOptions?.(world)
        );

        for (let step = 0; step < stepsBeforeSnapshot; step++) {
            original.step();
        }

        const snapshot = persist(original.snapshot());
        assert.deepStrictEqual(original.snapshot(), snapshot, `${context}, snapshot is not unchanged by JSON`);
        const restoredWorld: World = JSON.parse(JSON.stringify(world));
        const restoredCalls: string[] = [];
        const restored = new BehaviourTree(
            scenario.definition,
            scenario.createAgent(restoredWorld, restoredCalls),
            scenario.createOptions?.(restoredWorld)
        );

        restored.restore(snapshot);

        assert.deepEqual(restored.getTreeNodeDetails(), original.getTreeNodeDetails(), context);
        assert.deepEqual(restored.snapshot(), snapshot, context);

        for (let step = stepsBeforeSnapshot; step < scenario.totalSteps; step++) {
            calls.length = 0;
            original.step();
            restored.step();

            const stepContext = `${context}, step ${step + 1}`;
            assert.deepEqual(restoredCalls.splice(0), calls, stepContext);
            assert.deepEqual(restored.getTreeNodeDetails(), original.getTreeNodeDetails(), stepContext);
            assert.deepEqual(restored.snapshot(), original.snapshot(), stepContext);
        }
    }
}

/**
 * A world containing the state of a seeded random number generator.
 */
type RandomWorld = { seed: number };

/**
 * Gets a 'random' tree option that is driven by the state held in the world, so that its sequence can be continued by a restored tree.
 */
function randomFromWorld(world: RandomWorld): BehaviourTreeOptions {
    return {
        random: () => {
            world.seed = (world.seed * 1103515245 + 12345) % 2147483648;
            return world.seed / 2147483648;
        }
    };
}

/**
 * Lets any promise reactions that are ready to run, run.
 */
const settle = () => new Promise((resolve) => setImmediate(resolve));

/**
 * Creates a promise that is resolved or rejected by the caller.
 */
function createDeferred<T>() {
    let resolve!: (value: T) => void;
    let reject!: (reason: any) => void;
    const promise = new Promise<T>((res, rej) => ((resolve = res), (reject = rej)));
    return { promise, resolve, reject };
}

describe("A BehaviourTree instance", () => {
    describe("has a 'snapshot' function and a 'restore' function that", () => {
        it("resume a tree that is part way through its execution", () => {
            const definition = `root {
                sequence {
                    action [First]
                    action [Second]
                    action [Third]
                }
            }`;

            const calls: string[] = [];
            const createAgent = (secondResult: State | undefined): any => ({
                First: () => (calls.push("First"), State.SUCCEEDED),
                Second: () => (calls.push("Second"), secondResult),
                Third: () => (calls.push("Third"), State.SUCCEEDED)
            });

            const original = new BehaviourTree(definition, createAgent(State.RUNNING));
            original.step();
            assert.deepEqual(calls, ["First", "Second"]);

            const snapshot = persist(original.snapshot());

            calls.length = 0;
            const restored = new BehaviourTree(definition, createAgent(State.SUCCEEDED));
            restored.restore(snapshot);

            assert.deepEqual(restored.getTreeNodeDetails().state, State.RUNNING);
            assert.deepEqual(calls, []);

            restored.step();

            // The first action had already succeeded so it must not be called again.
            assert.deepEqual(calls, ["Second", "Third"]);
            assert.strictEqual(restored.getState(), State.SUCCEEDED);
        });

        describe("keep the iteration count of a repeat node", () => {
            it("when it is explicit", () => {
                assertRestoredTreeMatchesOriginal({
                    definition: "root { repeat [3] { action [Work] } }",
                    createWorld: () => ({}),
                    createAgent: (world, calls) => ({ Work: () => (calls.push("Work"), State.SUCCEEDED) }),
                    totalSteps: 5
                });
            });

            it("when it was randomly chosen between a minimum and maximum", () => {
                assertRestoredTreeMatchesOriginal<RandomWorld>({
                    definition: "root { repeat [1,6] { action [Work] } }",
                    createWorld: () => ({ seed: 7 }),
                    createAgent: (world, calls) => ({ Work: () => (calls.push("Work"), State.SUCCEEDED) }),
                    createOptions: randomFromWorld,
                    totalSteps: 9
                });
            });
        });

        describe("keep the attempt count of a retry node", () => {
            it("when it is explicit", () => {
                assertRestoredTreeMatchesOriginal({
                    definition: "root { retry [3] { action [Work] } }",
                    createWorld: () => ({}),
                    createAgent: (world, calls) => ({ Work: () => (calls.push("Work"), State.FAILED) }),
                    totalSteps: 5
                });
            });

            it("when it was randomly chosen between a minimum and maximum", () => {
                assertRestoredTreeMatchesOriginal<RandomWorld>({
                    definition: "root { retry [1,6] { action [Work] } }",
                    createWorld: () => ({ seed: 7 }),
                    createAgent: (world, calls) => ({ Work: () => (calls.push("Work"), State.FAILED) }),
                    createOptions: randomFromWorld,
                    totalSteps: 9
                });
            });
        });

        it("keep the child that a lotto node picked", () => {
            type World = RandomWorld & { calls: number };

            const createAction = (name: string, world: World, calls: string[]) => () => {
                calls.push(name);
                world.calls += 1;
                return world.calls >= 3 ? State.SUCCEEDED : State.RUNNING;
            };

            assertRestoredTreeMatchesOriginal<World>({
                definition: "root { lotto [1, 5, 2] { action [A] action [B] action [C] } }",
                createWorld: () => ({ seed: 3, calls: 0 }),
                createAgent: (world, calls) => ({
                    A: createAction("A", world, calls),
                    B: createAction("B", world, calls),
                    C: createAction("C", world, calls)
                }),
                createOptions: randomFromWorld,
                totalSteps: 5
            });
        });

        describe("keep how long a wait node has waited and what duration it is waiting for", () => {
            describe("using the 'getDeltaTime' option", () => {
                it("when the duration is explicit", () => {
                    assertRestoredTreeMatchesOriginal({
                        definition: "root { wait [1000] }",
                        createWorld: () => ({}),
                        createAgent: () => ({}),
                        createOptions: () => ({ getDeltaTime: () => 0.3 }),
                        totalSteps: 5
                    });
                });

                it("when the duration was randomly chosen between a minimum and maximum", () => {
                    assertRestoredTreeMatchesOriginal<RandomWorld>({
                        definition: "root { wait [500, 2500] }",
                        createWorld: () => ({ seed: 11 }),
                        createAgent: () => ({}),
                        createOptions: (world) => ({ ...randomFromWorld(world), getDeltaTime: () => 0.3 }),
                        totalSteps: 10
                    });
                });

                it("when the wait is indefinite", () => {
                    assertRestoredTreeMatchesOriginal({
                        definition: "root { wait }",
                        createWorld: () => ({}),
                        createAgent: () => ({}),
                        createOptions: () => ({ getDeltaTime: () => 0.3 }),
                        totalSteps: 3
                    });
                });

                it("without counting the time that passes before the snapshot is restored", () => {
                    const clock = sinon.useFakeTimers();

                    try {
                        const definition = "root { wait [1000] }";
                        const options = { getDeltaTime: () => 0.4 };

                        const original = new BehaviourTree(definition, {}, options);
                        original.step();
                        original.step();
                        const snapshot = persist(original.snapshot());

                        clock.tick(24 * 60 * 60 * 1000);

                        const restored = new BehaviourTree(definition, {}, options);
                        restored.restore(snapshot);

                        // 800ms of the 1000ms had been waited for when the snapshot was taken.
                        assert.strictEqual(restored.getState(), State.RUNNING);
                        restored.step();
                        assert.strictEqual(restored.getState(), State.SUCCEEDED);
                    } finally {
                        clock.restore();
                    }
                });
            });

            describe("using the clock", () => {
                let clock: SinonFakeTimers;

                beforeEach(() => {
                    clock = sinon.useFakeTimers();
                });

                afterEach(() => {
                    clock.restore();
                });

                it("without counting the time that passes before the snapshot is restored", () => {
                    const definition = "root { wait [1000] }";

                    const original = new BehaviourTree(definition, {});
                    original.step();
                    clock.tick(600);
                    original.step();
                    assert.strictEqual(original.getState(), State.RUNNING);

                    const snapshot = persist(original.snapshot());

                    clock.tick(24 * 60 * 60 * 1000);

                    const restored = new BehaviourTree(definition, {});
                    restored.restore(snapshot);
                    restored.step();
                    assert.strictEqual(restored.getState(), State.RUNNING);

                    // Only 400ms of the wait remain.
                    clock.tick(399);
                    restored.step();
                    assert.strictEqual(restored.getState(), State.RUNNING);

                    clock.tick(1);
                    restored.step();
                    assert.strictEqual(restored.getState(), State.SUCCEEDED);
                });

                it("counting the time that passed after the snapshot was taken but before the next step", () => {
                    const definition = "root { wait [1000] }";

                    const original = new BehaviourTree(definition, {});
                    original.step();
                    clock.tick(600);

                    // No step happened at the 600ms mark, so the wait node itself has not noticed that time has passed.
                    const snapshot = persist(original.snapshot());

                    const restored = new BehaviourTree(definition, {});
                    restored.restore(snapshot);

                    clock.tick(399);
                    restored.step();
                    assert.strictEqual(restored.getState(), State.RUNNING);

                    clock.tick(1);
                    restored.step();
                    assert.strictEqual(restored.getState(), State.SUCCEEDED);
                });

                it("when the duration was randomly chosen between a minimum and maximum", () => {
                    const definition = "root { wait [1000, 5000] }";
                    // This will pick a duration of 3000ms.
                    const options = { random: () => 0.5 };

                    const original = new BehaviourTree(definition, {}, options);
                    original.step();
                    clock.tick(2000);
                    original.step();

                    const snapshot = persist(original.snapshot());

                    clock.tick(60 * 1000);

                    // A restored tree that made its own random choice would wait for 1000ms.
                    const restored = new BehaviourTree(definition, {}, { random: () => 0 });
                    restored.restore(snapshot);

                    clock.tick(999);
                    restored.step();
                    assert.strictEqual(restored.getState(), State.RUNNING);

                    clock.tick(1);
                    restored.step();
                    assert.strictEqual(restored.getState(), State.SUCCEEDED);
                });
            });
        });

        describe("handle a promise-based action node", () => {
            const definition = "root { sequence { action [Before] action [Async] action [After] } }";

            const createAgent = (calls: string[], asyncResult: () => Promise<State>): Agent => ({
                Before: () => (calls.push("Before"), State.SUCCEEDED),
                Async: () => (calls.push("Async"), asyncResult()),
                After: () => (calls.push("After"), State.SUCCEEDED)
            });

            describe("whose promise has not settled by restoring it as not yet started", () => {
                it("so that the restored tree calls the action function again on its next step", async () => {
                    const calls: string[] = [];
                    const original = new BehaviourTree(
                        definition,
                        createAgent(calls, () => createDeferred<State>().promise)
                    );
                    original.step();

                    const snapshot = persist(original.snapshot());
                    assert.deepEqual(snapshot, original.snapshot());

                    calls.length = 0;
                    const deferred = createDeferred<State>();
                    const restored = new BehaviourTree(
                        definition,
                        createAgent(calls, () => deferred.promise)
                    );
                    restored.restore(snapshot);

                    // The action has not started, but the nodes around it carry on from where they were.
                    const details = restored.getTreeNodeDetails();
                    const sequence = details.children![0];
                    assert.strictEqual(details.state, State.RUNNING);
                    assert.strictEqual(sequence.state, State.RUNNING);
                    assert.deepEqual(
                        sequence.children!.map(({ state }) => state),
                        [State.SUCCEEDED, State.READY, State.READY]
                    );
                    assert.deepEqual(calls, []);

                    // The action function is called again, and not the ones before it that had already succeeded.
                    restored.step();
                    assert.deepEqual(calls, ["Async"]);
                    assert.strictEqual(restored.getState(), State.RUNNING);

                    deferred.resolve(State.SUCCEEDED);
                    await settle();
                    restored.step();
                    assert.deepEqual(calls, ["Async", "After"]);
                    assert.strictEqual(restored.getState(), State.SUCCEEDED);
                });

                it("including its entry callback, as it is run for the first time", () => {
                    const calls: string[] = [];
                    const entryDefinition = "root { action [Async] entry(OnEntry) exit(OnExit) }";
                    const createEntryAgent = (): Agent => ({
                        Async: () => (calls.push("Async"), createDeferred<State>().promise),
                        OnEntry: () => void calls.push("OnEntry"),
                        OnExit: () => void calls.push("OnExit")
                    });

                    const original = new BehaviourTree(entryDefinition, createEntryAgent());
                    original.step();
                    assert.deepEqual(calls, ["OnEntry", "Async"]);

                    calls.length = 0;
                    const restored = new BehaviourTree(entryDefinition, createEntryAgent());
                    restored.restore(original.snapshot());
                    restored.step();

                    assert.deepEqual(calls, ["OnEntry", "Async"]);
                });

                describe("whichever type of node it is inside of", () => {
                    const wrappers = [
                        "sequence { ACTION }",
                        "selector { ACTION }",
                        "parallel { ACTION }",
                        "race { ACTION action [Other] }",
                        "all { ACTION }",
                        "lotto { ACTION }",
                        "repeat [2] { ACTION }",
                        "retry [2] { ACTION }",
                        "flip { ACTION }",
                        "succeed { ACTION }",
                        "fail { ACTION }",
                        "sequence { condition [Pass] ACTION }"
                    ];

                    for (const wrapper of wrappers) {
                        it(wrapper.replace("ACTION", "action [Async]"), async () => {
                            const treeDefinition = `root { ${wrapper.replace("ACTION", "action [Async]")} }`;
                            let asyncCalls = 0;
                            const createWrappedAgent = (): Agent => ({
                                Async: () => (asyncCalls++, createDeferred<State>().promise),
                                Other: () => State.RUNNING,
                                Pass: () => true
                            });

                            const original = new BehaviourTree(treeDefinition, createWrappedAgent());
                            original.step();
                            assert.strictEqual(asyncCalls, 1);

                            let resolveRestored!: (state: State) => void;
                            const restored = new BehaviourTree(treeDefinition, {
                                ...createWrappedAgent(),
                                Async: () => (
                                    asyncCalls++, new Promise<State>((resolve) => (resolveRestored = resolve))
                                )
                            });
                            restored.restore(persist(original.snapshot()));
                            assert.strictEqual(restored.getState(), State.RUNNING);

                            restored.step();
                            assert.strictEqual(asyncCalls, 2);

                            // Waiting for the promise of the restored tree does not call the action function again.
                            restored.step();
                            assert.strictEqual(asyncCalls, 2);

                            resolveRestored(State.SUCCEEDED);
                            await settle();
                            restored.step();
                            assert.notStrictEqual(restored.getState(), State.READY);
                            assert.isAtLeast(asyncCalls, 2);
                        });
                    }
                });

                it("without changing the tree that the snapshot was taken from", async () => {
                    const calls: string[] = [];
                    const deferred = createDeferred<State>();
                    const tree = new BehaviourTree(
                        definition,
                        createAgent(calls, () => deferred.promise)
                    );
                    tree.step();

                    const detailsBefore = tree.getTreeNodeDetails();
                    tree.snapshot();
                    assert.deepEqual(tree.getTreeNodeDetails(), detailsBefore);

                    // The action is still waiting on its own promise, and does not ask for another.
                    calls.length = 0;
                    tree.step();
                    deferred.resolve(State.SUCCEEDED);
                    await settle();
                    tree.step();
                    assert.deepEqual(calls, ["After"]);
                    assert.strictEqual(tree.getState(), State.SUCCEEDED);
                });

                it("while keeping the settled promise of an action next to it", async () => {
                    const parallelDefinition = "root { parallel { action [Settled] action [Pending] } }";
                    const calls: string[] = [];
                    const tree = new BehaviourTree(parallelDefinition, {
                        Settled: () => (calls.push("Settled"), Promise.resolve(State.SUCCEEDED)),
                        Pending: () => (calls.push("Pending"), createDeferred<State>().promise)
                    });
                    tree.step();
                    await settle();

                    const snapshot = persist(tree.snapshot());

                    calls.length = 0;
                    const restored = new BehaviourTree(parallelDefinition, {
                        Settled: () => (calls.push("Settled"), Promise.resolve(State.FAILED)),
                        Pending: () => (calls.push("Pending"), Promise.resolve(State.SUCCEEDED))
                    });
                    restored.restore(snapshot);
                    restored.step();
                    await settle();
                    restored.step();

                    assert.deepEqual(calls, ["Pending"]);
                    assert.strictEqual(restored.getState(), State.SUCCEEDED);
                });

                it("so that the promise of the original tree cannot settle the restored one", async () => {
                    const originalPromise = createDeferred<State>();
                    const original = new BehaviourTree(
                        definition,
                        createAgent([], () => originalPromise.promise)
                    );
                    original.step();

                    const restored = new BehaviourTree(
                        definition,
                        createAgent([], () => createDeferred<State>().promise)
                    );
                    restored.restore(original.snapshot());
                    restored.step();

                    originalPromise.resolve(State.SUCCEEDED);
                    await settle();
                    restored.step();

                    assert.strictEqual(restored.getState(), State.RUNNING);
                });
            });

            for (const result of [State.SUCCEEDED, State.FAILED]) {
                it(`by keeping the result of a promise that resolved with ${result} but has not been used yet`, async () => {
                    const calls: string[] = [];
                    const original = new BehaviourTree(
                        definition,
                        createAgent(calls, () => Promise.resolve(result))
                    );
                    original.step();
                    await settle();

                    const snapshot = persist(original.snapshot());

                    calls.length = 0;
                    const restored = new BehaviourTree(
                        definition,
                        createAgent(calls, () => Promise.resolve(State.RUNNING as any))
                    );
                    restored.restore(snapshot);
                    restored.step();

                    // The action function must not be called again, its result is already known.
                    assert.deepEqual(calls, result === State.SUCCEEDED ? ["After"] : []);
                    assert.strictEqual(restored.getState(), result);
                });
            }

            it("by keeping the reason of a promise that was rejected but has not been used yet", async () => {
                const original = new BehaviourTree(
                    definition,
                    createAgent([], () => Promise.reject(new Error("boom")))
                );
                original.step();
                await settle();

                const snapshot = persist(original.snapshot());

                const restored = new BehaviourTree(
                    definition,
                    createAgent([], () => Promise.resolve(State.SUCCEEDED))
                );
                restored.restore(snapshot);

                assert.throws(
                    () => restored.step(),
                    Error,
                    "error stepping tree: action function 'Async' promise rejected with 'Error: boom'"
                );
            });

            it("by not letting a promise from before a restore settle the restored node", async () => {
                const stale = createDeferred<State>();
                const fresh = createDeferred<State>();
                const promises = [stale.promise, fresh.promise];

                const tree = new BehaviourTree(
                    definition,
                    createAgent([], () => promises.shift()!)
                );
                const initialSnapshot = tree.snapshot();

                // This leaves the stale promise pending.
                tree.step();

                // The restored tree will call the action function again, which leaves the fresh promise pending.
                tree.restore(initialSnapshot);
                tree.step();

                stale.resolve(State.SUCCEEDED);
                await settle();
                tree.step();

                assert.strictEqual(tree.getState(), State.RUNNING);
            });
        });

        it("keep the state of every type of node, including guards and callbacks", () => {
            type World = RandomWorld & { counts: { [name: string]: number } };

            const definition = `root {
                sequence {
                    repeat [2] {
                        race {
                            action [Slow]
                            wait [5000]
                        }
                    }
                    selector {
                        retry [2] { action [Flaky] }
                        flip { condition [Never] }
                    }
                    all {
                        lotto [1, 3] {
                            action [First]
                            action [Second]
                        }
                        action [Quick]
                    }
                    parallel {
                        action [Guarded] while(IsOpen) entry(OnEntry) step(OnStep) exit(OnExit)
                        succeed { fail { action [Quick] } }
                    }
                }
            }`;

            const createAgent = (world: World, calls: string[]): Agent => {
                const count = (name: string) => {
                    calls.push(name);
                    return (world.counts[name] = (world.counts[name] || 0) + 1);
                };

                return {
                    Slow: () => (count("Slow") % 6 === 0 ? State.SUCCEEDED : State.RUNNING),
                    Flaky: () => (count("Flaky") === 4 ? State.SUCCEEDED : State.FAILED),
                    Never: () => (count("Never"), false),
                    First: () => (count("First") % 2 === 0 ? State.SUCCEEDED : State.RUNNING),
                    Second: () => (count("Second") % 2 === 0 ? State.SUCCEEDED : State.RUNNING),
                    Quick: () => (count("Quick"), State.SUCCEEDED),
                    Guarded: () => (count("Guarded") === 3 ? State.SUCCEEDED : State.RUNNING),
                    IsOpen: () => count("IsOpen") !== 4,
                    OnEntry: () => void count("OnEntry"),
                    OnStep: () => void count("OnStep"),
                    OnExit: () => void count("OnExit")
                };
            };

            assertRestoredTreeMatchesOriginal<World>({
                definition,
                createWorld: () => ({ seed: 5, counts: {} }),
                createAgent,
                createOptions: (world) => ({ ...randomFromWorld(world), getDeltaTime: () => 1.5 }),
                totalSteps: 30
            });

            // Make sure that the scenario really did exercise the tree.
            const calls: string[] = [];
            const tree = new BehaviourTree(definition, createAgent({ seed: 5, counts: {} }, calls), {
                ...randomFromWorld({ seed: 5 }),
                getDeltaTime: () => 1.5
            });
            for (let step = 0; step < 30; step++) {
                tree.step();
            }
            assert.includeMembers(calls, ["Slow", "Flaky", "Never", "Quick", "Guarded", "OnEntry", "OnStep", "OnExit"]);
        });

        describe("restore a finished tree as finished", () => {
            it("so that the next step starts a new run", () => {
                const definition = "root { sequence { action [First] action [Second] } }";
                const calls: string[] = [];
                const agent = {
                    First: () => (calls.push("First"), State.SUCCEEDED),
                    Second: () => (calls.push("Second"), State.SUCCEEDED)
                };

                const original = new BehaviourTree(definition, agent);
                original.step();
                assert.strictEqual(original.getState(), State.SUCCEEDED);

                const restored = new BehaviourTree(definition, agent);
                restored.restore(persist(original.snapshot()));
                assert.strictEqual(restored.getState(), State.SUCCEEDED);

                calls.length = 0;
                restored.step();

                assert.deepEqual(calls, ["First", "Second"]);
                assert.strictEqual(restored.getState(), State.SUCCEEDED);
            });

            it("so that the new run makes its random choices again", () => {
                assertRestoredTreeMatchesOriginal<RandomWorld>({
                    definition: `root {
                        sequence {
                            repeat [1, 4] { action [Work] }
                            lotto { action [First] action [Second] action [Third] }
                            wait [100, 900]
                        }
                    }`,
                    createWorld: () => ({ seed: 21 }),
                    createAgent: (world, calls) => ({
                        Work: () => (calls.push("Work"), State.SUCCEEDED),
                        First: () => (calls.push("First"), State.SUCCEEDED),
                        Second: () => (calls.push("Second"), State.SUCCEEDED),
                        Third: () => (calls.push("Third"), State.SUCCEEDED)
                    }),
                    createOptions: (world) => ({ ...randomFromWorld(world), getDeltaTime: () => 0.2 }),
                    totalSteps: 40
                });
            });
        });

        describe("reject an invalid snapshot, leaving the tree as it was", () => {
            const definition = `root {
                sequence {
                    action [Work]
                    repeat [3] { action [Work] }
                    retry [3] { action [Work] }
                    lotto { action [Work] action [Work] }
                    wait [1000]
                }
            }`;
            const agent = { Work: () => State.RUNNING };

            // Gets a tree that has been stepped part way, so that there is state to leave alone.
            const createSteppedTree = () => {
                const tree = new BehaviourTree(
                    definition,
                    { Work: () => State.SUCCEEDED },
                    { getDeltaTime: () => 0.1 }
                );
                tree.step();
                tree.step();
                return tree;
            };

            const cases: [string, (snapshot: any) => any, string][] = [
                ["it is null", () => null, "invalid snapshot: expected an object"],
                ["it is undefined", () => undefined, "invalid snapshot: expected an object"],
                ["it is a string", () => "snapshot", "invalid snapshot: expected an object"],
                ["it is a number", () => 42, "invalid snapshot: expected an object"],
                ["it is a boolean", () => true, "invalid snapshot: expected an object"],
                ["it is an array", (snapshot) => [snapshot], "invalid snapshot: expected an object"],
                ["it is an empty array", () => [], "invalid snapshot: expected an object"],
                ["it is an empty object", () => ({}), "invalid snapshot: unsupported version 'undefined'"],
                [
                    "it is an object without the fields of a snapshot",
                    () => ({ type: "root", state: State.READY, children: [] }),
                    "invalid snapshot: unsupported version 'undefined'"
                ],
                [
                    "it has no definition",
                    ({ version, root }) => ({ version, root }),
                    "invalid snapshot: expected a string definition"
                ],
                [
                    "it has a definition that is not a string",
                    (snapshot) => ({ ...snapshot, definition: 42 }),
                    "invalid snapshot: expected a string definition"
                ],
                [
                    "it has the root of a snapshot but nothing else",
                    ({ root }) => ({ root }),
                    "invalid snapshot: unsupported version 'undefined'"
                ],
                [
                    "it has an unsupported version",
                    (snapshot) => ({ ...snapshot, version: 2 }),
                    "invalid snapshot: unsupported version '2'"
                ],
                [
                    "it has no root",
                    (snapshot) => ({ version: snapshot.version, definition: snapshot.definition }),
                    "invalid snapshot: expected an object at 'root'"
                ],
                [
                    "a node is of a different type",
                    (snapshot) => ((snapshot.root.children[0].children[1].type = "retry"), snapshot),
                    "invalid snapshot: expected node of type 'repeat' but found 'retry' at 'root.children[0].children[1]'"
                ],
                [
                    "a node has a different number of children",
                    (snapshot) => (snapshot.root.children[0].children.pop(), snapshot),
                    "invalid snapshot: expected 5 children but found 4 at 'root.children[0]'"
                ],
                [
                    "a node has no children array",
                    (snapshot) => (delete snapshot.root.children[0].children, snapshot),
                    "invalid snapshot: expected 5 children but found 0 at 'root.children[0]'"
                ],
                [
                    "a node has an invalid state",
                    (snapshot) => ((snapshot.root.children[0].children[4].state = "running"), snapshot),
                    "invalid snapshot: invalid state 'running' at 'root.children[0].children[4]'"
                ],
                [
                    "a node has an invalid id",
                    (snapshot) => ((snapshot.root.children[0].children[0].id = 42), snapshot),
                    "invalid snapshot: expected a string id at 'root.children[0].children[0]'"
                ],
                [
                    "a repeat node has an invalid iteration count",
                    (snapshot) => ((snapshot.root.children[0].children[1].current = -1), snapshot),
                    "invalid snapshot: expected a non-negative integer 'current' at 'root.children[0].children[1]'"
                ],
                [
                    "a retry node has an invalid target attempt count",
                    (snapshot) => ((snapshot.root.children[0].children[2].target = "3"), snapshot),
                    "invalid snapshot: expected a non-negative integer or null 'target' at 'root.children[0].children[2]'"
                ],
                [
                    "a lotto node has a selected child that does not exist",
                    (snapshot) => ((snapshot.root.children[0].children[3].selectedChild = 2), snapshot),
                    "invalid snapshot: expected a valid child index or null 'selectedChild' at 'root.children[0].children[3]'"
                ],
                [
                    "a wait node has an invalid waited duration",
                    (snapshot) => ((snapshot.root.children[0].children[4].waitedDuration = "1"), snapshot),
                    "invalid snapshot: expected a finite number 'waitedDuration' at 'root.children[0].children[4]'"
                ],
                [
                    "a wait node has an invalid total duration",
                    (snapshot) => ((snapshot.root.children[0].children[4].totalDuration = {}), snapshot),
                    "invalid snapshot: expected a non-negative number or null 'totalDuration' at 'root.children[0].children[4]'"
                ],
                [
                    "an action node has an invalid promise result",
                    (snapshot) => (
                        (snapshot.root.children[0].children[0].promiseResult = { isResolved: "yes" }), snapshot
                    ),
                    "invalid snapshot: expected a promise result of null or an object with 'isResolved' and 'value' at 'root.children[0].children[0]'"
                ]
            ];

            for (const [description, corrupt, message] of cases) {
                it(`when ${description}`, () => {
                    const tree = createSteppedTree();
                    const before = tree.snapshot();
                    const detailsBefore = tree.getTreeNodeDetails();

                    // Corrupt a snapshot of a tree in a different state, so that restoring any part of it would be noticed.
                    const other = new BehaviourTree(definition, agent, { getDeltaTime: () => 0.1 });
                    other.step();

                    assert.throws(
                        () => tree.restore(corrupt(JSON.parse(JSON.stringify(other.snapshot())))),
                        Error,
                        message
                    );

                    assert.deepEqual(tree.snapshot(), before);
                    assert.deepEqual(tree.getTreeNodeDetails(), detailsBefore);
                });
            }
        });

        describe("record the definition of the tree in the snapshot", () => {
            it("as a string that survives JSON", () => {
                const snapshot = new BehaviourTree("root { action [Work] }", {}).snapshot();

                assert.isString(snapshot.definition);
                assert.deepEqual(persist(snapshot), snapshot);
            });

            it("which is the same for every tree built from the same definition, whatever its state", () => {
                const definition = "root { sequence { action [Work] wait [1000] } }";
                const first = new BehaviourTree(definition, { Work: () => State.SUCCEEDED });
                const second = new BehaviourTree(definition, { Work: () => State.RUNNING });
                second.step();

                assert.strictEqual(first.snapshot().definition, second.snapshot().definition);
            });

            it("which is different for trees built from different definitions", () => {
                const definitions = [
                    "root { action [Work] }",
                    "root { action [Other] }",
                    "root { action [Work, 1] }",
                    "root { action [Work, 2] }",
                    'root { action [Work, "1"] }',
                    "root { condition [Work] }",
                    "root { action [Work] while(IsOpen) }",
                    "root { action [Work] until(IsOpen) }",
                    "root { action [Work] while(IsOpen) entry(Log) }",
                    "root { action [Work] while(IsOpen, true) }",
                    "root { action [Work] while(IsOpen, 1) }",
                    "root { action [Work] while(IsOpen, 2) }",
                    "root { action [Work] entry(Log) }",
                    "root { action [Work] step(Log) }",
                    "root { action [Work] exit(Log) }",
                    "root { action [Work] exit(Log, 1) }",
                    "root { sequence { action [Work] } }",
                    "root { selector { action [Work] } }",
                    "root { sequence { action [Work] action [Work] } }",
                    "root { repeat { action [Work] } }",
                    "root { repeat [2] { action [Work] } }",
                    "root { repeat [3] { action [Work] } }",
                    "root { repeat [2, 3] { action [Work] } }",
                    "root { retry [2] { action [Work] } }",
                    "root { wait }",
                    "root { wait [1000] }",
                    "root { wait [1000, 2000] }",
                    "root { lotto { action [Work] action [Work] } }",
                    "root { lotto [1, 3] { action [Work] action [Work] } }",
                    "root { lotto [3, 1] { action [Work] action [Work] } }"
                ];

                const fingerprints = definitions.map(
                    (definition) => new BehaviourTree(definition, {}).snapshot().definition
                );

                assert.strictEqual(new Set(fingerprints).size, definitions.length);
            });
        });

        describe("reject a snapshot of a different definition, leaving the tree as it was", () => {
            const definition = `root {
                sequence {
                    action [Work, 1]
                    repeat [3] { action [Work, 2] }
                    wait [1000]
                    action [Work, 3] while(IsOpen)
                }
            }`;
            const agent = {
                Work: () => State.RUNNING,
                Rest: () => State.RUNNING,
                IsOpen: () => true,
                IsClosed: () => false
            };

            const differentDefinitions: [string, string][] = [
                [
                    "a different node type",
                    `root { sequence { action [Work, 1] repeat [3] { action [Work, 2] } wait [1000] action [Work, 3] until(IsOpen) } }`
                ],
                [
                    "a different number of children",
                    `root { sequence { action [Work, 1] repeat [3] { action [Work, 2] } wait [1000] } }`
                ],
                [
                    "the same shape but a different action",
                    `root { sequence { action [Rest, 1] repeat [3] { action [Work, 2] } wait [1000] action [Work, 3] while(IsOpen) } }`
                ],
                [
                    "the same shape but different action arguments",
                    `root { sequence { action [Work, 1] repeat [3] { action [Work, 9] } wait [1000] action [Work, 3] while(IsOpen) } }`
                ],
                [
                    "the same shape but a different repeat count",
                    `root { sequence { action [Work, 1] repeat [4] { action [Work, 2] } wait [1000] action [Work, 3] while(IsOpen) } }`
                ],
                [
                    "the same shape but a different wait duration",
                    `root { sequence { action [Work, 1] repeat [3] { action [Work, 2] } wait [2000] action [Work, 3] while(IsOpen) } }`
                ],
                [
                    "the same shape but a different guard",
                    `root { sequence { action [Work, 1] repeat [3] { action [Work, 2] } wait [1000] action [Work, 3] while(IsClosed) } }`
                ],
                [
                    "the same shape but a different composite type",
                    `root { selector { action [Work, 1] repeat [3] { action [Work, 2] } wait [1000] action [Work, 3] while(IsOpen) } }`
                ],
                ["a single node", `root { action [Work, 1] }`]
            ];

            // Gets a tree that has been stepped part way, so that there is state to leave alone.
            const createSteppedTree = () => {
                const tree = new BehaviourTree(definition, agent, { getDeltaTime: () => 0.1 });
                tree.step();
                return tree;
            };

            for (const [description, otherDefinition] of differentDefinitions) {
                it(`when it has ${description}`, () => {
                    const tree = createSteppedTree();
                    const before = tree.snapshot();
                    const detailsBefore = tree.getTreeNodeDetails();

                    const other = new BehaviourTree(otherDefinition, agent, { getDeltaTime: () => 0.1 });
                    other.step();

                    assert.throws(
                        () => tree.restore(persist(other.snapshot())),
                        Error,
                        "snapshot does not match the tree's definition"
                    );

                    assert.deepEqual(tree.snapshot(), before);
                    assert.deepEqual(tree.getTreeNodeDetails(), detailsBefore);
                });
            }

            it("when it was not taken from a tree with the same registered subtrees", () => {
                const treeDefinition = "root { branch [Shared] }";

                BehaviourTree.register("Shared", "root { action [Work] }");
                const before = new BehaviourTree(treeDefinition, agent);
                const snapshot = before.snapshot();

                BehaviourTree.register("Shared", "root { action [Rest] }");
                try {
                    const after = new BehaviourTree(treeDefinition, agent);

                    assert.throws(
                        () => after.restore(snapshot),
                        Error,
                        "snapshot does not match the tree's definition"
                    );
                } finally {
                    BehaviourTree.unregisterAll();
                }
            });

            it("without disturbing a promise that the tree is waiting for", async () => {
                const deferred = createDeferred<State>();
                const tree = new BehaviourTree("root { sequence { action [Async] action [After] } }", {
                    Async: () => deferred.promise,
                    After: () => State.SUCCEEDED
                });
                tree.step();

                assert.throws(
                    () => tree.restore(new BehaviourTree("root { action [Async] }", {}).snapshot()),
                    Error,
                    "snapshot does not match the tree's definition"
                );

                deferred.resolve(State.SUCCEEDED);
                await settle();
                tree.step();
                assert.strictEqual(tree.getState(), State.SUCCEEDED);
            });
        });

        describe("treat definitions as the same", () => {
            const agent = { Work: () => State.SUCCEEDED, IsOpen: () => true, Log: () => {} };

            const mdsl = `root {
                sequence while(IsOpen, 1, "x", null, true, $flag) entry(Log) {
                    action [Work, 1, -2.5, "s", false] until(IsOpen) exit(Log, 1)
                    action [Work]
                    wait [100, 200]
                    wait [500]
                    wait
                    repeat [2, 3] { condition [IsOpen] }
                    repeat { flip { fail { succeed { condition [IsOpen, 1] } } } }
                    retry [2] { action [Work] while(IsOpen) }
                    lotto [2, 1] { action [Work] action [Work] }
                    lotto { action [Work] }
                    parallel { race { action [Work] } all { action [Work] } }
                    selector step(Log) { branch [Shared] branch [Shared] }
                }
            }
            root [Shared] { action [Work] }`;

            // The same definition as JSON, written by hand: no empty 'args' arrays and no 'succeedOnAbort: false'.
            const json: RootNodeDefinition[] = [
                {
                    type: "root",
                    child: {
                        type: "sequence",
                        while: { call: "IsOpen", args: [1, "x", null, true, { $: "flag" }] },
                        entry: { call: "Log" },
                        children: [
                            {
                                type: "action",
                                call: "Work",
                                args: [1, -2.5, "s", false],
                                until: { call: "IsOpen" },
                                exit: { call: "Log", args: [1] }
                            },
                            { type: "action", call: "Work" },
                            { type: "wait", duration: [100, 200] },
                            { type: "wait", duration: 500 },
                            { type: "wait" },
                            { type: "repeat", iterations: [2, 3], child: { type: "condition", call: "IsOpen" } },
                            {
                                type: "repeat",
                                child: {
                                    type: "flip",
                                    child: {
                                        type: "fail",
                                        child: {
                                            type: "succeed",
                                            child: { type: "condition", call: "IsOpen", args: [1] }
                                        }
                                    }
                                }
                            },
                            {
                                type: "retry",
                                attempts: 2,
                                child: {
                                    type: "action",
                                    call: "Work",
                                    while: { call: "IsOpen", succeedOnAbort: false }
                                }
                            },
                            {
                                type: "lotto",
                                weights: [2, 1],
                                children: [
                                    { type: "action", call: "Work" },
                                    { type: "action", call: "Work" }
                                ]
                            },
                            { type: "lotto", children: [{ type: "action", call: "Work" }] },
                            {
                                type: "parallel",
                                children: [
                                    { type: "race", children: [{ type: "action", call: "Work" }] },
                                    { type: "all", children: [{ type: "action", call: "Work" }] }
                                ]
                            },
                            {
                                type: "selector",
                                step: { call: "Log" },
                                children: [
                                    { type: "branch", ref: "Shared" },
                                    { type: "branch", ref: "Shared" }
                                ]
                            }
                        ]
                    }
                },
                { type: "root", id: "Shared", child: { type: "action", call: "Work" } }
            ];

            // Gets a copy of a JSON value in which the keys of every object are in the opposite order.
            const reverseKeys = (value: any): any =>
                Array.isArray(value)
                    ? value.map(reverseKeys)
                    : value && typeof value === "object"
                    ? Object.fromEntries(
                          Object.entries(value)
                              .reverse()
                              .map(([key, child]) => [key, reverseKeys(child)])
                      )
                    : value;

            const equivalent: [string, string | RootNodeDefinition | RootNodeDefinition[]][] = [
                ["an MDSL definition", mdsl],
                [
                    "the same MDSL definition with different formatting and comments",
                    mdsl.replace(/\s+/g, " ").replace("root [Shared]", "/* shared */ root [Shared]")
                ],
                ["the equivalent JSON definition", json],
                ["the equivalent JSON definition with its root nodes in a different order", [json[1], json[0]]],
                ["the equivalent JSON definition with its keys in a different order", reverseKeys(json)]
            ];

            it("when they are an MDSL definition and its equivalent JSON definition, in either direction", () => {
                for (const [, from] of equivalent) {
                    for (const [description, to] of equivalent) {
                        const source = new BehaviourTree(from, agent);
                        source.step();
                        const target = new BehaviourTree(to, agent);

                        assert.doesNotThrow(() => target.restore(persist(source.snapshot())), description);
                        assert.deepEqual(target.snapshot(), source.snapshot(), description);
                    }
                }
            });

            it("when a single root node is defined as an object rather than as an array", () => {
                const definition: RootNodeDefinition = { type: "root", child: { type: "action", call: "Work" } };

                const source = new BehaviourTree("root { action [Work] }", agent);
                const target = new BehaviourTree(definition, agent);

                assert.doesNotThrow(() => target.restore(source.snapshot()));
                assert.doesNotThrow(() => source.restore(target.snapshot()));
            });

            it("when the definition only differs in how a subtree is reached", () => {
                const source = new BehaviourTree(
                    "root { sequence { branch [Work] } } root [Work] { action [Work] }",
                    agent
                );
                const target = new BehaviourTree("root { sequence { action [Work] } }", agent);

                assert.doesNotThrow(() => target.restore(source.snapshot()));
            });
        });

        describe("refuse to be used while the tree is being stepped", () => {
            const definition = "root { action [Work] }";

            it("when taking a snapshot", () => {
                const tree: BehaviourTree = new BehaviourTree(definition, {
                    Work: () => (tree.snapshot(), State.SUCCEEDED)
                });

                assert.throws(() => tree.step(), Error, "cannot take snapshot while the tree is being stepped");
            });

            it("when restoring a snapshot", () => {
                const snapshot = new BehaviourTree(definition, {}).snapshot();
                const tree: BehaviourTree = new BehaviourTree(definition, {
                    Work: () => (tree.restore(snapshot), State.SUCCEEDED)
                });

                assert.throws(() => tree.step(), Error, "cannot restore snapshot while the tree is being stepped");
            });

            it("but allow it again once the step has finished, even if it failed", () => {
                let shouldThrow = true;
                const tree = new BehaviourTree(definition, {
                    Work: () => {
                        if (shouldThrow) {
                            throw new Error("failed");
                        }
                        return State.RUNNING;
                    }
                });

                assert.throws(() => tree.step(), Error, "failed");

                assert.doesNotThrow(() => tree.restore(tree.snapshot()));

                shouldThrow = false;
                tree.step();
                assert.doesNotThrow(() => tree.restore(tree.snapshot()));
            });
        });

        it("do not call any callbacks, guards or state change handlers when restoring", () => {
            const definition = "root { sequence { action [Work] entry(OnEntry) exit(OnExit) while(IsOpen) } }";
            const calls: string[] = [];
            const agent = {
                Work: () => (calls.push("Work"), State.RUNNING),
                OnEntry: () => void calls.push("OnEntry"),
                OnExit: () => void calls.push("OnExit"),
                IsOpen: () => (calls.push("IsOpen"), true)
            };

            const original = new BehaviourTree(definition, agent);
            original.step();
            const snapshot = original.snapshot();

            calls.length = 0;
            const changes: string[] = [];
            const restored = new BehaviourTree(definition, agent, {
                onNodeStateChange: ({ type }) => changes.push(type)
            });
            restored.restore(snapshot);

            assert.deepEqual(calls, []);
            assert.deepEqual(changes, []);
            assert.strictEqual(restored.getState(), State.RUNNING);
        });

        it("work with copies, so that changing a snapshot never changes a tree and the other way around", () => {
            const definition = "root { sequence { repeat [3] { action [Work] } wait [1000] } }";
            const agent = { Work: () => State.SUCCEEDED };
            const options = { getDeltaTime: () => 0.1 };

            const tree = new BehaviourTree(definition, agent, options);
            tree.step();

            const snapshot = tree.snapshot();
            const expected = JSON.parse(JSON.stringify(snapshot));

            // Changing a snapshot that was taken must not change the tree.
            snapshot.root.children![0].children![0].current = 2;
            assert.deepEqual(tree.snapshot(), expected);

            // Changing a snapshot that was restored must not change the tree.
            const restored = new BehaviourTree(definition, agent, options);
            const toRestore = JSON.parse(JSON.stringify(expected));
            restored.restore(toRestore);
            toRestore.root.children[0].children[0].current = 2;
            toRestore.root.children[0].state = State.FAILED;
            assert.deepEqual(restored.snapshot(), expected);

            // Stepping a tree must not change a snapshot that was taken from it.
            const takenBeforeStep = tree.snapshot();
            tree.step();
            assert.deepEqual(takenBeforeStep, expected);
            assert.notDeepEqual(tree.snapshot(), expected);
        });

        it("do not report any state changes when restoring over a tree that has already run, but report them as usual on the next step", () => {
            const definition = "root { sequence { repeat [2] { action [Work] } wait [1000] action [Finish] } }";
            const agent = { Work: () => State.SUCCEEDED, Finish: () => State.SUCCEEDED };

            const originalChanges: string[] = [];
            const original = new BehaviourTree(definition, agent, {
                getDeltaTime: () => 0.4,
                onNodeStateChange: ({ id, previousState, state }) =>
                    originalChanges.push(`${id} ${previousState} ${state}`)
            });
            original.step();
            original.step();
            const snapshot = persist(original.snapshot());

            // The tree that is restored has already run, so that its nodes are in different states to those in the snapshot.
            const restoredChanges: string[] = [];
            const restored = new BehaviourTree(definition, agent, {
                getDeltaTime: () => 0.4,
                onNodeStateChange: ({ id, previousState, state }) =>
                    restoredChanges.push(`${id} ${previousState} ${state}`)
            });
            for (let step = 0; step < 10; step++) {
                restored.step();
            }
            assert.strictEqual(restored.getState(), State.SUCCEEDED);

            restoredChanges.length = 0;
            restored.restore(snapshot);
            assert.deepEqual(restoredChanges, []);

            // The next step reports the changes that the original tree reports for its next step.
            originalChanges.length = 0;
            original.step();
            restored.step();
            assert.isNotEmpty(originalChanges);
            assert.deepEqual(restoredChanges, originalChanges);
        });

        it("are not changed by stepping a tree, and a tree restored from one is not changed by stepping either", () => {
            const definition = "root { sequence { repeat [3] { action [Work] } wait [1000] } }";
            const agent = { Work: () => State.SUCCEEDED };
            const options = { getDeltaTime: () => 0.1 };

            // Step far enough for the wait node to be running part way through its duration.
            const tree = new BehaviourTree(definition, agent, options);
            for (let step = 0; step < 5; step++) {
                tree.step();
            }
            assert.isAbove(tree.snapshot().root.children![0].children![1].waitedDuration!, 0);

            // Stepping the tree that a snapshot was taken from must not change the snapshot.
            const snapshot = tree.snapshot();
            const expected = persist(snapshot);
            tree.step();
            tree.step();
            assert.deepEqual(persist(snapshot), expected);

            // Stepping a tree that a snapshot was restored to must not change the snapshot.
            const restored = new BehaviourTree(definition, agent, options);
            restored.restore(snapshot);

            // A snapshot taken straight after restoring is the snapshot that was restored.
            assert.deepEqual(persist(restored.snapshot()), expected);

            for (let step = 0; step < 6; step++) {
                restored.step();
                assert.deepEqual(persist(snapshot), expected);
            }
            assert.notDeepEqual(persist(restored.snapshot()), expected);
        });

        it("can roll a tree back to an earlier point in its own execution", () => {
            const definition = "root { sequence { repeat [3] { action [Work] } action [Finish] } }";
            const calls: string[] = [];
            const tree = new BehaviourTree(definition, {
                Work: () => (calls.push("Work"), State.SUCCEEDED),
                Finish: () => (calls.push("Finish"), State.SUCCEEDED)
            });

            tree.step();
            const snapshot = persist(tree.snapshot());

            calls.length = 0;
            for (let step = 0; step < 3; step++) {
                tree.step();
            }
            const callsAfterSnapshot = [...calls];
            assert.strictEqual(tree.getState(), State.SUCCEEDED);

            tree.restore(snapshot);
            assert.strictEqual(tree.getState(), State.RUNNING);

            calls.length = 0;
            for (let step = 0; step < 3; step++) {
                tree.step();
            }
            assert.deepEqual(calls, callsAfterSnapshot);
        });
    });
});
