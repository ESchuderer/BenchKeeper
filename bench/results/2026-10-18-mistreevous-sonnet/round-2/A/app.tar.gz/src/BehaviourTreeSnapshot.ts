import State, { AnyState, CompleteState } from "./State";
import { RootNodeDefinition } from "./BehaviourTreeDefinition";

/**
 * The snapshot properties common to every node.
 */
type BaseNodeSnapshot<TType extends string> = {
    /**
     * The node type.
     */
    type: TType;
    /**
     * The state of the node.
     */
    state: AnyState;
};

/**
 * The snapshot properties of a node that has child nodes.
 */
type ParentNodeSnapshot = {
    /**
     * The snapshots of the child nodes, in the same order as the children of the node.
     */
    children: NodeSnapshot[];
};

/**
 * The result of the update promise of an action node that has settled, but has yet to be used by the node.
 */
export type UpdatePromiseResultSnapshot =
    | {
          /**
           * Whether the promise resolved rather than rejected.
           */
          isResolved: true;
          /**
           * The state that the promise resolved with, or null if the promise resolved with something that is not a valid state.
           */
          value: CompleteState | null;
      }
    | {
          /**
           * Whether the promise resolved rather than rejected.
           */
          isResolved: false;
          /**
           * The reason that the promise rejected, converted to a string.
           */
          value: string;
      };

/**
 * A snapshot of an action node.
 */
export type ActionNodeSnapshot = BaseNodeSnapshot<"action"> & {
    /**
     * The result of the update promise returned by the action function if it has settled but has yet to be used by the node, otherwise null.
     * An update promise that is yet to settle cannot be kept, so the state of the node is READY instead and it calls the action function again once restored.
     */
    updatePromiseResult: UpdatePromiseResultSnapshot | null;
};

/**
 * A snapshot of a wait node.
 */
export type WaitNodeSnapshot = BaseNodeSnapshot<"wait"> & {
    /**
     * The total duration in milliseconds that the node will wait for, or null if the node has not started or waits indefinitely.
     * This is the duration that was chosen at random if the node has a minimum and maximum duration.
     */
    totalDuration: number | null;
    /**
     * The duration in milliseconds that the node has waited for so far.
     * This does not include any time that passes between the snapshot being taken and being restored.
     */
    waitedDuration: number;
};

/**
 * A snapshot of a lotto node.
 */
export type LottoNodeSnapshot = BaseNodeSnapshot<"lotto"> &
    ParentNodeSnapshot & {
        /**
         * The index of the child node that was picked at random to be the active one, or null if the node has not picked one.
         */
        selectedChildIndex: number | null;
    };

/**
 * A snapshot of a repeat node.
 */
export type RepeatNodeSnapshot = BaseNodeSnapshot<"repeat"> &
    ParentNodeSnapshot & {
        /**
         * The number of iterations completed so far.
         */
        currentIterationCount: number;
        /**
         * The number of iterations to make, or null if the node has not started or repeats indefinitely.
         * This is the number that was chosen at random if the node has a minimum and maximum number of iterations.
         */
        targetIterationCount: number | null;
    };

/**
 * A snapshot of a retry node.
 */
export type RetryNodeSnapshot = BaseNodeSnapshot<"retry"> &
    ParentNodeSnapshot & {
        /**
         * The number of attempts completed so far.
         */
        currentAttemptCount: number;
        /**
         * The number of attempts to make, or null if the node has not started or retries indefinitely.
         * This is the number that was chosen at random if the node has a minimum and maximum number of attempts.
         */
        targetAttemptCount: number | null;
    };

/**
 * A snapshot of the state of a single node in a behaviour tree.
 */
export type NodeSnapshot =
    | (BaseNodeSnapshot<"root" | "sequence" | "selector" | "parallel" | "race" | "all" | "flip" | "succeed" | "fail"> &
          ParentNodeSnapshot)
    | LottoNodeSnapshot
    | RepeatNodeSnapshot
    | RetryNodeSnapshot
    | WaitNodeSnapshot
    | ActionNodeSnapshot
    | BaseNodeSnapshot<"condition">;

/**
 * A snapshot of the state of a node that is handled without regard to the properties specific to its type.
 */
export type AnyNodeSnapshot = {
    type: string;
    state: AnyState;
    children?: AnyNodeSnapshot[];
    [property: string]: unknown;
};

/**
 * A snapshot of the execution state of a behaviour tree.
 * This is a plain object that is safe to convert to JSON and back.
 */
export type BehaviourTreeSnapshot = {
    /**
     * The snapshot format version.
     */
    version: 1;
    /**
     * An identifier of the definition of the tree that the snapshot was taken from.
     * This is the same for an MDSL definition and the equivalent JSON definition.
     */
    definition: string;
    /**
     * The snapshot of the main root node.
     */
    root: NodeSnapshot;
};

/**
 * The current snapshot format version.
 */
export const SNAPSHOT_VERSION = 1;

/**
 * Converts a definition value to a form in which equivalent definitions are identical, with the properties of objects in order and
 * those that have no effect, such as an empty array of arguments, left out.
 * @param value The definition value.
 * @returns The definition value in its canonical form.
 */
function canonicaliseDefinitionValue(value: unknown): unknown {
    if (Array.isArray(value)) {
        return value.map(canonicaliseDefinitionValue);
    }

    if (!isObject(value)) {
        return value;
    }

    return Object.fromEntries(
        Object.keys(value)
            .sort()
            .filter((key) => {
                const property = value[key];

                // The arguments of an attribute are optional and the 'succeedOnAbort' flag of a guard is false unless defined.
                return (
                    property !== undefined &&
                    !(key === "args" && Array.isArray(property) && property.length === 0) &&
                    !(key === "succeedOnAbort" && property === false)
                );
            })
            .map((key) => [key, canonicaliseDefinitionValue(value[key])])
    );
}

/**
 * Creates an identifier of a tree definition, which is the same for any definitions that are equivalent.
 * Registered subtrees are not part of the definition.
 * @param rootNodeDefinitions The root node definitions of the tree as JSON, which can have been converted from MDSL.
 * @returns An identifier of the definition.
 */
export function createDefinitionIdentifier(rootNodeDefinitions: RootNodeDefinition[]): string {
    // The order of the root nodes is of no importance, as they are referred to by id. The main root node has no id.
    const canonicalDefinition = JSON.stringify(
        canonicaliseDefinitionValue([...rootNodeDefinitions].sort((a, b) => ((a.id ?? "") < (b.id ?? "") ? -1 : 1)))
    );

    // This is a 64-bit variation of the cyrb53 hash, which is not secure but is more than enough to tell definitions apart.
    let h1 = 0xdeadbeef;
    let h2 = 0x41c6ce57;

    for (let index = 0; index < canonicalDefinition.length; index++) {
        const code = canonicalDefinition.charCodeAt(index);
        h1 = Math.imul(h1 ^ code, 2654435761);
        h2 = Math.imul(h2 ^ code, 1597334677);
    }

    h1 = Math.imul(h1 ^ (h1 >>> 16), 2246822507) ^ Math.imul(h2 ^ (h2 >>> 13), 3266489909);
    h2 = Math.imul(h2 ^ (h2 >>> 16), 2246822507) ^ Math.imul(h1 ^ (h1 >>> 13), 3266489909);

    return (h2 >>> 0).toString(16).padStart(8, "0") + (h1 >>> 0).toString(16).padStart(8, "0");
}

/**
 * A node that can validate snapshots.
 */
type SnapshotValidator = {
    validateSnapshot(snapshot: unknown): void;
};

/**
 * Gets whether a value is a non-null object.
 * @param value The value to check.
 * @returns Whether the value is a non-null object.
 */
export function isObject(value: unknown): value is Record<string, unknown> {
    return typeof value === "object" && value !== null;
}

/**
 * Gets whether a value is a valid node state.
 * @param value The value to check.
 * @returns Whether the value is a valid node state.
 */
export function isNodeState(value: unknown): value is AnyState {
    return Object.values(State).includes(value as State);
}

/**
 * Validates that a node snapshot property is a non-negative integer, or optionally null.
 * @param nodeType The type of the node.
 * @param snapshot The node snapshot, which has already been confirmed to be an object.
 * @param property The name of the property to validate.
 * @param nullable Whether the property can be null.
 */
export function validateCount(
    nodeType: string,
    snapshot: Record<string, unknown>,
    property: string,
    nullable: boolean
): void {
    const value = snapshot[property];

    if ((nullable && value === null) || (Number.isInteger(value) && (value as number) >= 0)) {
        return;
    }

    throw new Error(
        `expected ${
            nullable ? "null or " : ""
        }a non-negative integer for the '${property}' of a '${nodeType}' node but found '${value}'`
    );
}

/**
 * Validates that a node snapshot property is a finite number, optionally non-negative or null.
 * @param nodeType The type of the node.
 * @param snapshot The node snapshot, which has already been confirmed to be an object.
 * @param property The name of the property to validate.
 * @param nullable Whether the property can be null.
 * @param nonNegative Whether the property must not be negative.
 */
export function validateNumber(
    nodeType: string,
    snapshot: Record<string, unknown>,
    property: string,
    nullable: boolean,
    nonNegative: boolean
): void {
    const value = snapshot[property];

    if ((nullable && value === null) || (Number.isFinite(value) && (!nonNegative || (value as number) >= 0))) {
        return;
    }

    throw new Error(
        `expected ${nullable ? "null or " : ""}a ${
            nonNegative ? "non-negative " : ""
        }number for the '${property}' of a '${nodeType}' node but found '${value}'`
    );
}

/**
 * Validates that a node snapshot property is either null or the result of an update promise.
 * @param nodeType The type of the node.
 * @param snapshot The node snapshot, which has already been confirmed to be an object.
 * @param property The name of the property to validate.
 */
export function validateUpdatePromiseResult(
    nodeType: string,
    snapshot: Record<string, unknown>,
    property: string
): void {
    const value = snapshot[property];

    const isValid =
        value === null ||
        (isObject(value) &&
            (value.isResolved === true
                ? value.value === null || value.value === State.SUCCEEDED || value.value === State.FAILED
                : value.isResolved === false && typeof value.value === "string"));

    if (!isValid) {
        throw new Error(
            `expected null or a valid update promise result for the '${property}' of an '${nodeType}' node`
        );
    }
}

/**
 * Validates the child node snapshots of a node snapshot against the child nodes of a node.
 * @param nodeType The type of the node.
 * @param childNodes The child nodes of the node.
 * @param snapshot The node snapshot, which has already been confirmed to be an object.
 */
export function validateChildSnapshots(
    nodeType: string,
    childNodes: SnapshotValidator[],
    snapshot: Record<string, unknown>
): void {
    const childSnapshots = snapshot.children;
    const expected = `expected ${childNodes.length} child node snapshot${childNodes.length === 1 ? "" : "s"}`;

    if (!Array.isArray(childSnapshots)) {
        throw new Error(`${expected} for a '${nodeType}' node but found none`);
    }

    if (childSnapshots.length !== childNodes.length) {
        throw new Error(`${expected} for a '${nodeType}' node but found ${childSnapshots.length}`);
    }

    childNodes.forEach((childNode, index) => childNode.validateSnapshot(childSnapshots[index]));
}
