import Node, { NodeDetails } from "../Node";
import State from "../../State";
import { Agent } from "../../Agent";
import Attribute from "../../attributes/Attribute";
import { BehaviourTreeOptions } from "../../BehaviourTreeOptions";
import { AnyNodeSnapshot, validateChildSnapshots } from "../../BehaviourTreeSnapshot";

/**
 * A decorator node that wraps a single child node.
 */
export default abstract class Decorator extends Node {
    /**
     * @param type The node type.
     * @param attributes The node attributes.
     * @param options The behaviour tree options.
     * @param child The child node.
     */
    constructor(type: string, attributes: Attribute[], options: BehaviourTreeOptions, protected child: Node) {
        super(type, attributes, options);
    }

    /**
     * Gets the children of this node.
     */
    getChildren = () => [this.child];

    /**
     * Reset the state of the node.
     */
    reset = () => {
        // Reset the state of this node.
        this.setState(State.READY);

        // Reset the state of the child node.
        this.child.reset();
    };

    /**
     * Abort the running of this node.
     * @param agent The agent.
     */
    abort = (agent: Agent) => {
        // There is nothing to do if this node is not in the running state.
        if (!this.is(State.RUNNING)) {
            return;
        }

        // Abort the child node.
        this.child.abort(agent);

        // Reset the state of this node.
        this.reset();

        this.attributes.exit?.callAgentFunction(agent, false, true);
    };

    /**
     * Gets the details of this node instance.
     * @returns The details of this node instance.
     */
    public getDetails(): NodeDetails {
        return {
            ...super.getDetails(),
            children: [this.child.getDetails()]
        };
    }

    /**
     * Gets a snapshot of the state of this node.
     * @returns A snapshot of the state of this node.
     */
    public getSnapshot(): AnyNodeSnapshot {
        return {
            ...super.getSnapshot(),
            children: [this.child.getSnapshot()]
        };
    }

    /**
     * Validates that a snapshot is one that this node can be restored to, throwing an error if it is not.
     * @param snapshot The node snapshot.
     */
    public validateSnapshot(snapshot: unknown): asserts snapshot is AnyNodeSnapshot {
        super.validateSnapshot(snapshot);

        validateChildSnapshots(this.getType(), [this.child], snapshot);
    }

    /**
     * Restores this node to the state in a snapshot that has already been validated.
     * @param snapshot The node snapshot.
     */
    public restoreSnapshot(snapshot: AnyNodeSnapshot): void {
        super.restoreSnapshot(snapshot);

        this.child.restoreSnapshot(snapshot.children![0]);
    }
}
