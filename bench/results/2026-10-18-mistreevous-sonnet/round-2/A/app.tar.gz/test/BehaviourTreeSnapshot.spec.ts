import { assert } from "chai";
import sinon, { SinonFakeTimers } from "sinon";

import { BehaviourTree, BehaviourTreeOptions, BehaviourTreeSnapshot, State } from "../src/index";
import { assertRestoreMatchesOriginal, createAgent, Script, STEP_DURATION } from "./SnapshotUtilities";

/**
 * Take a snapshot of the tree and check that it survives being converted to JSON and back unchanged.
 */
const takeJsonSafeSnapshot = (tree: BehaviourTree): BehaviourTreeSnapshot => {
    const snapshot = tree.snapshot();
    assert.deepEqual(JSON.parse(JSON.stringify(snapshot)), snapshot);
    return snapshot;
};

/**
 * A script where the work actions run for a number of steps and then succeed.
 */
const workScript: Script = {
    WorkA: (step) => (step < 2 ? undefined : State.SUCCEEDED),
    WorkB: (step) => (step < 4 ? undefined : State.SUCCEEDED),
    WorkC: (step) => (step < 5 ? undefined : State.FAILED),
    Yes: () => true,
    No: () => false,
    Early: (step) => step < 3,
    Late: (step) => step >= 3
};

/**
 * A script where actions pass, fail, take two steps to pass or fail, or flip between failing and passing.
 */
const repeatScript: Script = {
    Pass: () => State.SUCCEEDED,
    Fail: () => State.FAILED,
    Slow: (step) => (step % 2 === 0 ? undefined : State.SUCCEEDED),
    SlowFail: (step) => (step % 2 === 0 ? undefined : State.FAILED),
    Flaky: (step) => (step % 7 === 6 ? State.FAILED : State.SUCCEEDED)
};

describe("A behaviour tree", () => {
    describe("snapshot()", () => {
        it("gets the state of every node in the tree as a plain object", () => {
            const tree = new BehaviourTree("root { sequence { condition [Yes] flip { condition [Yes] } } }", {
                Yes: () => true
            });

            assert.deepEqual(takeJsonSafeSnapshot(tree), {
                version: 1,
                definition: tree.snapshot().definition,
                root: {
                    type: "root",
                    state: State.READY,
                    children: [
                        {
                            type: "sequence",
                            state: State.READY,
                            children: [
                                { type: "condition", state: State.READY },
                                {
                                    type: "flip",
                                    state: State.READY,
                                    children: [{ type: "condition", state: State.READY }]
                                }
                            ]
                        }
                    ]
                }
            });

            tree.step();

            assert.deepEqual(takeJsonSafeSnapshot(tree), {
                version: 1,
                definition: tree.snapshot().definition,
                root: {
                    type: "root",
                    state: State.FAILED,
                    children: [
                        {
                            type: "sequence",
                            state: State.FAILED,
                            children: [
                                { type: "condition", state: State.SUCCEEDED },
                                {
                                    type: "flip",
                                    state: State.FAILED,
                                    children: [{ type: "condition", state: State.SUCCEEDED }]
                                }
                            ]
                        }
                    ]
                }
            });
        });

        it("identifies the definition of the tree", () => {
            const { definition } = takeJsonSafeSnapshot(new BehaviourTree("root { action [WorkA] }", {}));

            assert.typeOf(definition, "string");
            assert.isNotEmpty(definition);
            assert.equal(new BehaviourTree("root { action [WorkA] }", {}).snapshot().definition, definition);
            assert.equal(
                new BehaviourTree({ type: "root", child: { type: "action", call: "WorkA" } }, {}).snapshot().definition,
                definition
            );
            assert.notEqual(new BehaviourTree("root { action [WorkB] }", {}).snapshot().definition, definition);
        });

        it("has the same definition identifier at any point in the run of the tree", () => {
            const tree = new BehaviourTree(
                "root { action [WorkA] }",
                createAgent(workScript, [], () => 0)
            );
            const { definition } = tree.snapshot();

            tree.step();

            assert.equal(tree.snapshot().definition, definition);
        });

        it("does not call any agent functions or change the tree", () => {
            const calls: string[] = [];
            const tree = new BehaviourTree(
                "root { sequence { condition [Yes] action [WorkA] } }",
                createAgent(workScript, calls, () => 0)
            );

            tree.step();
            const callsBeforeSnapshot = calls.length;
            const detailsBeforeSnapshot = JSON.stringify(tree.getTreeNodeDetails());

            tree.snapshot();

            assert.lengthOf(calls, callsBeforeSnapshot);
            assert.equal(JSON.stringify(tree.getTreeNodeDetails()), detailsBeforeSnapshot);
        });

        it("gets a new object each time that can be modified without affecting the tree or other snapshots", () => {
            const tree = new BehaviourTree("root { sequence { condition [Yes] } }", { Yes: () => true });
            tree.step();

            const snapshot = tree.snapshot();
            (snapshot.root as any).state = State.READY;
            (snapshot.root as any).children.length = 0;

            assert.equal(tree.getState(), State.SUCCEEDED);
            assert.equal(tree.snapshot().root.state, State.SUCCEEDED);
            assert.lengthOf((tree.snapshot().root as any).children, 1);
        });
    });

    describe("restore()", () => {
        const definition = "root { sequence { action [WorkA] action [WorkB] } }";

        it("sets the state of every node in the tree and does not call any agent functions", () => {
            const calls: string[] = [];
            const original = new BehaviourTree(
                definition,
                createAgent(workScript, calls, () => 0)
            );
            original.step();

            const restoredCalls: string[] = [];
            const restored = new BehaviourTree(
                definition,
                createAgent(workScript, restoredCalls, () => 0)
            );
            restored.restore(JSON.parse(JSON.stringify(original.snapshot())));

            assert.equal(restored.getState(), State.RUNNING);
            assert.deepEqual(
                restored.getTreeNodeDetails().children![0].children!.map(({ state }) => state),
                [State.RUNNING, State.READY]
            );
            assert.deepEqual(restoredCalls, []);
        });

        it("does not call the 'onNodeStateChange' option", () => {
            const original = new BehaviourTree(
                definition,
                createAgent(workScript, [], () => 0)
            );
            original.step();

            const changes: unknown[] = [];
            const restored = new BehaviourTree(
                definition,
                createAgent(workScript, [], () => 0),
                {
                    onNodeStateChange: (change) => changes.push(change)
                }
            );
            restored.restore(original.snapshot());

            assert.deepEqual(changes, []);
        });

        it("replaces any existing state of the tree", () => {
            let step = 0;
            const tree = new BehaviourTree(
                definition,
                createAgent(workScript, [], () => step)
            );

            const beforeAnySteps = tree.snapshot();
            tree.step();
            const afterFirstStep = tree.snapshot();
            step = 2;
            tree.step();
            tree.step();
            assert.equal(tree.getState(), State.RUNNING);

            tree.restore(afterFirstStep);
            assert.deepEqual(tree.snapshot(), afterFirstStep);

            tree.restore(beforeAnySteps);
            assert.deepEqual(tree.snapshot(), beforeAnySteps);
            assert.equal(tree.getState(), State.READY);
        });

        it("does not keep a reference to the snapshot", () => {
            const tree = new BehaviourTree(
                definition,
                createAgent(workScript, [], () => 0)
            );
            tree.step();
            const snapshot = tree.snapshot();

            const restored = new BehaviourTree(
                definition,
                createAgent(workScript, [], () => 0)
            );
            restored.restore(snapshot);
            (snapshot.root as any).state = State.READY;

            assert.equal(restored.getState(), State.RUNNING);
        });

        describe("will error and leave the tree unchanged if the snapshot", () => {
            const createStartedTree = () => {
                const tree = new BehaviourTree(
                    definition,
                    createAgent(workScript, [], () => 0)
                );
                tree.step();
                return tree;
            };

            const validSnapshot = () => JSON.parse(JSON.stringify(createStartedTree().snapshot()));

            const cases: [string, (snapshot: any) => unknown, string][] = [
                ["is null", () => null, "invalid snapshot: expected an object"],
                ["is not an object", () => "snapshot", "invalid snapshot: expected an object"],
                [
                    "has an unsupported version",
                    (snapshot) => ({ ...snapshot, version: 2 }),
                    "invalid snapshot: unsupported version '2'"
                ],
                [
                    "has no root node snapshot",
                    ({ version, definition }) => ({ version, definition }),
                    "invalid snapshot: expected an object for the snapshot of a 'root' node"
                ],
                [
                    "has a root node of the wrong type",
                    (snapshot) => ({ ...snapshot, root: { ...snapshot.root, type: "sequence" } }),
                    "invalid snapshot: expected a node of type 'root' but found 'sequence'"
                ],
                [
                    "has a nested node of the wrong type",
                    (snapshot) => {
                        snapshot.root.children[0].children[1].type = "wait";
                        return snapshot;
                    },
                    "invalid snapshot: expected a node of type 'action' but found 'wait'"
                ],
                [
                    "has a node with an invalid state",
                    (snapshot) => {
                        snapshot.root.children[0].children[0].state = "mistreevous.nope";
                        return snapshot;
                    },
                    "invalid snapshot: invalid node state 'mistreevous.nope'"
                ],
                [
                    "has a node with the wrong number of children",
                    (snapshot) => {
                        snapshot.root.children[0].children.pop();
                        return snapshot;
                    },
                    "invalid snapshot: expected 2 child node snapshots for a 'sequence' node but found 1"
                ],
                [
                    "has a node with no children",
                    (snapshot) => {
                        delete snapshot.root.children[0].children;
                        return snapshot;
                    },
                    "invalid snapshot: expected 2 child node snapshots for a 'sequence' node but found none"
                ]
            ];

            cases.forEach(([description, corrupt, expectedMessage]) => {
                it(description, () => {
                    const tree = createStartedTree();
                    const before = tree.snapshot();

                    assert.throws(() => tree.restore(corrupt(validSnapshot()) as any), Error, expectedMessage);
                    assert.deepEqual(tree.snapshot(), before);
                });
            });

            it("is for a tree with a different definition of another shape", () => {
                const tree = createStartedTree();
                const before = tree.snapshot();
                const other = new BehaviourTree("root { selector { action [WorkA] action [WorkB] } }", {});

                assert.throws(
                    () => tree.restore(other.snapshot()),
                    Error,
                    "invalid snapshot: snapshot does not match the tree's definition"
                );
                assert.deepEqual(tree.snapshot(), before);
            });
        });

        describe("will error and leave the tree unchanged if the snapshot is for a tree with a definition of the same shape that only differs in", () => {
            const cases: [string, string, string][] = [
                ["an action name", "root { action [A] }", "root { action [B] }"],
                ["an action argument", "root { action [A, 1] }", "root { action [A, 2] }"],
                ["an action argument type", "root { action [A, 1] }", 'root { action [A, "1"] }'],
                ["an agent property argument", "root { action [A, $x] }", "root { action [A, $y] }"],
                ["a wait duration", "root { wait [100] }", "root { wait [200] }"],
                [
                    "a repeat iteration count",
                    "root { repeat [2] { action [A] } }",
                    "root { repeat [3] { action [A] } }"
                ],
                [
                    "a retry attempt range",
                    "root { retry [1, 3] { action [A] } }",
                    "root { retry [1, 4] { action [A] } }"
                ],
                [
                    "lotto weights",
                    "root { lotto [1, 2] { action [A] action [B] } }",
                    "root { lotto [2, 1] { action [A] action [B] } }"
                ],
                ["a guard type", "root { action [A] while(G) }", "root { action [A] until(G) }"],
                ["a guard function", "root { action [A] while(G) }", "root { action [A] while(H) }"],
                ["a guard abort state", "root { action [A] while(G) }", "root { action [A] while(G) then succeed }"],
                ["a callback type", "root { action [A] entry(G) }", "root { action [A] exit(G) }"],
                [
                    "the order of children",
                    "root { sequence { action [A] action [B] } }",
                    "root { sequence { action [B] action [A] } }"
                ],
                [
                    "a subtree",
                    "root { branch [Sub] } root [Sub] { action [A] }",
                    "root { branch [Sub] } root [Sub] { action [B] }"
                ],
                ["a subtree being defined", "root { action [A] }", "root { action [A] } root [Sub] { action [A] }"]
            ];

            cases.forEach(([description, definitionA, definitionB]) => {
                it(description, () => {
                    const tree = new BehaviourTree(definitionA, {});
                    const other = new BehaviourTree(definitionB, {});
                    const before = tree.snapshot();

                    assert.throws(
                        () => tree.restore(other.snapshot()),
                        Error,
                        "invalid snapshot: snapshot does not match the tree's definition"
                    );
                    assert.deepEqual(tree.snapshot(), before);
                });
            });
        });

        describe("will error and leave the tree unchanged if the value is not a snapshot because it is", () => {
            const validSnapshot = () => new BehaviourTree(definition, {}).snapshot();

            const cases: [string, () => unknown][] = [
                ["null", () => null],
                ["undefined", () => undefined],
                ["a string", () => "snapshot"],
                ["a number", () => 1],
                ["a boolean", () => true],
                ["an array", () => []],
                ["an array of a snapshot", () => [validSnapshot()]],
                ["an empty object", () => ({})],
                ["an object with only a version", () => ({ version: 1 })],
                ["an object with only a root", () => ({ root: validSnapshot().root })],
                ["an object with only a definition", () => ({ definition: validSnapshot().definition })],
                ["a snapshot with no definition", () => ({ version: 1, root: validSnapshot().root })],
                ["a snapshot with a definition that is not a string", () => ({ ...validSnapshot(), definition: 5 })],
                ["a snapshot with no root", () => ({ version: 1, definition: validSnapshot().definition })]
            ];

            cases.forEach(([description, createValue]) => {
                it(description, () => {
                    const tree = new BehaviourTree(
                        definition,
                        createAgent(workScript, [], () => 0)
                    );
                    tree.step();
                    const before = tree.snapshot();

                    assert.throws(() => tree.restore(createValue() as any), Error, "invalid snapshot");
                    assert.deepEqual(tree.snapshot(), before);
                });
            });
        });

        describe("accepts a snapshot of a tree built from the same definition when the definition is", () => {
            const mdsl = `root {
                sequence while(Check, 1, "two", null, true, $three) entry(Enter) {
                    action [Work, 1, $x]
                    wait
                    wait [5]
                    wait [1, 2]
                    repeat { condition [Yes] }
                    repeat [3] { action [Work] until(Stop) then succeed }
                    retry [1, 2] { action [Work] exit(Leave) }
                    lotto [1, 2] { action [WorkA] action [WorkB] }
                    lotto { action [WorkA] }
                    branch [Sub]
                }
            }
            root [Sub] { succeed { fail { flip { action [WorkA] } } } }`;

            const json = [
                {
                    type: "root",
                    child: {
                        type: "sequence",
                        while: { call: "Check", args: [1, "two", null, true, { $: "three" }] },
                        entry: { call: "Enter" },
                        children: [
                            { type: "action", call: "Work", args: [1, { $: "x" }] },
                            { type: "wait" },
                            { type: "wait", duration: 5 },
                            { type: "wait", duration: [1, 2] },
                            { type: "repeat", child: { type: "condition", call: "Yes" } },
                            {
                                type: "repeat",
                                iterations: 3,
                                child: {
                                    type: "action",
                                    call: "Work",
                                    until: { call: "Stop", succeedOnAbort: true }
                                }
                            },
                            {
                                type: "retry",
                                attempts: [1, 2],
                                child: { type: "action", call: "Work", exit: { call: "Leave", args: [] } }
                            },
                            {
                                type: "lotto",
                                weights: [1, 2],
                                children: [
                                    { type: "action", call: "WorkA" },
                                    { type: "action", call: "WorkB" }
                                ]
                            },
                            { type: "lotto", children: [{ type: "action", call: "WorkA" }] },
                            { type: "branch", ref: "Sub" }
                        ]
                    }
                },
                {
                    type: "root",
                    id: "Sub",
                    child: {
                        type: "succeed",
                        child: { type: "fail", child: { type: "flip", child: { type: "action", call: "WorkA" } } }
                    }
                }
            ];

            const reverseProperties = (value: unknown): unknown =>
                Array.isArray(value)
                    ? value.map(reverseProperties)
                    : value && typeof value === "object"
                    ? Object.fromEntries(
                          Object.entries(value)
                              .reverse()
                              .map(([key, property]) => [key, reverseProperties(property)])
                      )
                    : value;

            const cases: [string, unknown, string, unknown][] = [
                ["MDSL", mdsl, "JSON", json],
                ["MDSL", mdsl, "the same MDSL with different formatting", mdsl.replace(/\s+/g, " ")],
                ["JSON", json, "the same JSON with the root nodes in another order", [...json].reverse()],
                ["JSON", json, "the same JSON with the properties in another order", reverseProperties(json)],
                [
                    "a single JSON root node",
                    { type: "root", child: { type: "action", call: "Work" } },
                    "MDSL",
                    "root { action [Work] }"
                ]
            ];

            cases.forEach(([descriptionA, a, descriptionB, b]) => {
                it(`${descriptionA} for the tree and ${descriptionB} for the snapshot`, () => {
                    const treeA = new BehaviourTree(a as any, {});
                    const treeB = new BehaviourTree(b as any, {});

                    assert.equal(treeA.snapshot().definition, treeB.snapshot().definition);
                    assert.doesNotThrow(() => treeA.restore(JSON.parse(JSON.stringify(treeB.snapshot()))));
                    assert.doesNotThrow(() => treeB.restore(JSON.parse(JSON.stringify(treeA.snapshot()))));
                });
            });

            it("a JSON definition that is changed after the tree is built", () => {
                const definition = { type: "root", child: { type: "action", call: "Work" } };
                const tree = new BehaviourTree(definition as any, {});
                const before = tree.snapshot();

                (definition.child as any).call = "Other";

                assert.doesNotThrow(() => tree.restore(before));
                assert.equal(tree.snapshot().definition, before.definition);
            });
        });

        describe("results in a tree that behaves exactly as the original does for", () => {
            const cases: [string, string][] = [
                ["a sequence node", "root { sequence { action [WorkA] condition [Yes] action [WorkB] } }"],
                ["a selector node", "root { selector { condition [No] action [WorkC] action [WorkB] } }"],
                ["a parallel node", "root { parallel { action [WorkA] action [WorkB] action [WorkA] } }"],
                ["a race node", "root { race { action [WorkB] action [WorkA] action [WorkC] } }"],
                ["an all node", "root { all { action [WorkC] action [WorkB] action [WorkA] } }"],
                ["a flip node", "root { sequence { flip { action [WorkC] } action [WorkA] } }"],
                ["a succeed node", "root { sequence { succeed { action [WorkC] } action [WorkA] } }"],
                ["a fail node", "root { selector { fail { action [WorkA] } action [WorkB] } }"],
                ["a condition node", "root { selector { condition [No] condition [Yes] } }"],
                [
                    "a branch node",
                    "root { sequence { branch [Sub] action [WorkB] } } root [Sub] { sequence { action [WorkA] } }"
                ],
                [
                    "entry, step and exit callbacks",
                    "root { sequence { action [WorkA] entry(Yes) step(No) exit(WorkB) action [WorkB] exit(WorkA) } }"
                ],
                [
                    "'while' and 'until' guards",
                    "root { sequence { action [WorkB] while(Yes) until(Late) action [WorkB] } }"
                ],
                [
                    "a node aborted by a guard",
                    "root { parallel { action [WorkB] while(Early) action [WorkB] until(Late) action [WorkA] } }"
                ]
            ];

            cases.forEach(([description, definition]) => {
                it(description, () => {
                    assertRestoreMatchesOriginal({ definition, script: workScript, steps: 9 });
                });
            });
        });
    });

    describe("snapshot() and restore() for a repeat node", () => {
        const countScript: Script = { Pass: () => State.SUCCEEDED, Fail: () => State.FAILED };

        const getRepeatSnapshot = (tree: BehaviourTree) => (tree.snapshot().root as any).children[0];

        it("keep the iteration count and target iteration count", () => {
            const tree = new BehaviourTree(
                "root { repeat [3] { action [Pass] } }",
                createAgent(countScript, [], () => 0)
            );

            assert.deepEqual(getRepeatSnapshot(tree), {
                type: "repeat",
                state: State.READY,
                currentIterationCount: 0,
                targetIterationCount: null,
                children: [{ type: "action", state: State.READY, updatePromiseResult: null }]
            });

            tree.step();
            tree.step();

            assert.deepEqual(getRepeatSnapshot(tree), {
                type: "repeat",
                state: State.RUNNING,
                currentIterationCount: 2,
                targetIterationCount: 3,
                children: [{ type: "action", state: State.SUCCEEDED, updatePromiseResult: null }]
            });
        });

        it("keep a target iteration count that was chosen at random", () => {
            const tree = new BehaviourTree(
                "root { repeat [2,5] { action [Pass] } }",
                createAgent(countScript, [], () => 0),
                {
                    random: () => 0.99
                }
            );
            tree.step();

            assert.equal(getRepeatSnapshot(tree).targetIterationCount, 5);
        });

        it("do not call the 'random' function option for a target iteration count that was already chosen", () => {
            const original = new BehaviourTree(
                "root { repeat [2,5] { action [Pass] } }",
                createAgent(countScript, [], () => 0),
                {
                    random: () => 0.99
                }
            );
            original.step();
            original.step();

            const restored = new BehaviourTree(
                "root { repeat [2,5] { action [Pass] } }",
                createAgent(countScript, [], () => 0),
                {
                    random: () => {
                        throw new Error("random should not be called");
                    }
                }
            );
            restored.restore(original.snapshot());

            // 2 iterations are done, so the restored tree has 3 more of the 5 chosen to do before it succeeds on the following step.
            restored.step();
            restored.step();
            restored.step();
            assert.equal(restored.getState(), State.RUNNING);
            restored.step();
            assert.equal(restored.getState(), State.SUCCEEDED);
        });

        it("will error if the counts in the snapshot are invalid", () => {
            const tree = new BehaviourTree(
                "root { repeat [3] { action [Pass] } }",
                createAgent(countScript, [], () => 0)
            );
            tree.step();

            const corrupt = (change: (repeat: any) => void) => {
                const snapshot = JSON.parse(JSON.stringify(tree.snapshot()));
                change(snapshot.root.children[0]);
                return snapshot;
            };

            assert.throws(
                () => tree.restore(corrupt((repeat) => (repeat.currentIterationCount = -1))),
                Error,
                "invalid snapshot: expected a non-negative integer for the 'currentIterationCount' of a 'repeat' node but found '-1'"
            );
            assert.throws(
                () => tree.restore(corrupt((repeat) => (repeat.targetIterationCount = 1.5))),
                Error,
                "invalid snapshot: expected null or a non-negative integer for the 'targetIterationCount' of a 'repeat' node but found '1.5'"
            );
            assert.throws(
                () => tree.restore(corrupt((repeat) => delete repeat.targetIterationCount)),
                Error,
                "invalid snapshot: expected null or a non-negative integer for the 'targetIterationCount' of a 'repeat' node but found 'undefined'"
            );
        });

        describe("result in a tree that behaves exactly as the original does for", () => {
            const cases: [string, string][] = [
                ["an explicit number of iterations", "root { repeat [3] { action [Slow] } }"],
                ["a random number of iterations", "root { repeat [2,5] { action [Slow] } }"],
                ["an infinite number of iterations", "root { repeat { action [Slow] } }"],
                ["a child that fails", "root { repeat [4] { sequence { action [Slow] action [Flaky] } } }"],
                [
                    "a repeat node in a sequence",
                    "root { sequence { repeat [2,4] { action [Pass] } repeat [2] { action [Slow] } } }"
                ],
                ["nested repeat nodes", "root { repeat [2,3] { repeat [1,3] { action [Slow] } } }"],
                [
                    "a repeat node with zero iterations",
                    "root { sequence { repeat [0] { action [Pass] } action [Slow] } }"
                ]
            ];

            cases.forEach(([description, definition]) => {
                it(description, () => {
                    assertRestoreMatchesOriginal({ definition, script: repeatScript, steps: 30 });
                });
            });
        });
    });

    describe("snapshot() and restore() for a retry node", () => {
        const countScript: Script = { Pass: () => State.SUCCEEDED, Fail: () => State.FAILED };

        const getRetrySnapshot = (tree: BehaviourTree) => (tree.snapshot().root as any).children[0];

        it("keep the attempt count and target attempt count", () => {
            const tree = new BehaviourTree(
                "root { retry [3] { action [Fail] } }",
                createAgent(countScript, [], () => 0)
            );

            assert.deepEqual(getRetrySnapshot(tree), {
                type: "retry",
                state: State.READY,
                currentAttemptCount: 0,
                targetAttemptCount: null,
                children: [{ type: "action", state: State.READY, updatePromiseResult: null }]
            });

            tree.step();
            tree.step();

            assert.deepEqual(getRetrySnapshot(tree), {
                type: "retry",
                state: State.RUNNING,
                currentAttemptCount: 2,
                targetAttemptCount: 3,
                children: [{ type: "action", state: State.FAILED, updatePromiseResult: null }]
            });
        });

        it("keep a target attempt count that was chosen at random", () => {
            const tree = new BehaviourTree(
                "root { retry [2,5] { action [Fail] } }",
                createAgent(countScript, [], () => 0),
                {
                    random: () => 0.99
                }
            );
            tree.step();

            assert.equal(getRetrySnapshot(tree).targetAttemptCount, 5);
        });

        it("do not call the 'random' function option for a target attempt count that was already chosen", () => {
            const original = new BehaviourTree(
                "root { retry [2,5] { action [Fail] } }",
                createAgent(countScript, [], () => 0),
                {
                    random: () => 0.99
                }
            );
            original.step();
            original.step();

            const restored = new BehaviourTree(
                "root { retry [2,5] { action [Fail] } }",
                createAgent(countScript, [], () => 0),
                {
                    random: () => {
                        throw new Error("random should not be called");
                    }
                }
            );
            restored.restore(original.snapshot());

            // 2 attempts are done, so the restored tree has 3 more of the 5 chosen to make before it fails on the following step.
            restored.step();
            restored.step();
            restored.step();
            assert.equal(restored.getState(), State.RUNNING);
            restored.step();
            assert.equal(restored.getState(), State.FAILED);
        });

        it("will error if the counts in the snapshot are invalid", () => {
            const tree = new BehaviourTree(
                "root { retry [3] { action [Fail] } }",
                createAgent(countScript, [], () => 0)
            );
            tree.step();

            const snapshot = JSON.parse(JSON.stringify(tree.snapshot()));
            snapshot.root.children[0].currentAttemptCount = "2";

            assert.throws(
                () => tree.restore(snapshot),
                Error,
                "invalid snapshot: expected a non-negative integer for the 'currentAttemptCount' of a 'retry' node but found '2'"
            );
        });

        describe("result in a tree that behaves exactly as the original does for", () => {
            const cases: [string, string][] = [
                ["an explicit number of attempts", "root { retry [3] { action [SlowFail] } }"],
                ["a random number of attempts", "root { retry [2,5] { action [SlowFail] } }"],
                ["an infinite number of attempts", "root { retry { action [SlowFail] } }"],
                [
                    "a child that eventually succeeds",
                    "root { retry [6] { sequence { action [Slow] action [Flaky] } } }"
                ],
                [
                    "a retry node in a sequence",
                    "root { sequence { retry [2,4] { action [Fail] } retry [2] { action [SlowFail] } } }"
                ],
                ["nested retry nodes", "root { retry [2,3] { retry [1,3] { action [SlowFail] } } }"],
                [
                    "a repeat node inside a retry node",
                    "root { retry [3] { repeat [2,4] { sequence { action [Slow] action [Flaky] } } } }"
                ]
            ];

            cases.forEach(([description, definition]) => {
                it(description, () => {
                    assertRestoreMatchesOriginal({ definition, script: repeatScript, steps: 30 });
                });
            });
        });
    });

    describe("snapshot() and restore() for a lotto node", () => {
        const lottoScript: Script = {
            ChildA: (step) => (step % 2 === 0 ? undefined : State.SUCCEEDED),
            ChildB: (step) => (step % 3 === 0 ? undefined : State.FAILED),
            ChildC: () => State.SUCCEEDED,
            Pass: () => State.SUCCEEDED
        };

        const definition = "root { lotto { action [ChildA] action [ChildB] action [ChildC] } }";

        const getLottoSnapshot = (tree: BehaviourTree) => (tree.snapshot().root as any).children[0];

        it("keep the index of the child that was picked", () => {
            const tree = new BehaviourTree(
                definition,
                createAgent(lottoScript, [], () => 0),
                { random: () => 0.99 }
            );

            assert.equal(getLottoSnapshot(tree).selectedChildIndex, null);

            tree.step();

            assert.equal(getLottoSnapshot(tree).type, "lotto");
            assert.equal(getLottoSnapshot(tree).selectedChildIndex, 2);
        });

        it("do not call the 'random' function option for a child that was already picked", () => {
            const original = new BehaviourTree(
                definition,
                createAgent(lottoScript, [], () => 0),
                { random: () => 0 }
            );
            original.step();

            const calls: string[] = [];
            const restored = new BehaviourTree(
                definition,
                createAgent(lottoScript, calls, () => 1),
                {
                    random: () => {
                        throw new Error("random should not be called");
                    }
                }
            );
            restored.restore(original.snapshot());
            restored.step();

            assert.deepEqual(calls, ["ChildA"]);
            assert.equal(restored.getState(), State.SUCCEEDED);
        });

        it("will error if the selected child index in the snapshot is invalid", () => {
            const tree = new BehaviourTree(
                definition,
                createAgent(lottoScript, [], () => 0)
            );
            tree.step();

            [3, -1, 1.5, "1", undefined].forEach((selectedChildIndex) => {
                const snapshot = JSON.parse(JSON.stringify(tree.snapshot()));
                snapshot.root.children[0].selectedChildIndex = selectedChildIndex;

                assert.throws(
                    () => tree.restore(snapshot),
                    Error,
                    `invalid snapshot: expected null or the index of a child node for the 'selectedChildIndex' of a 'lotto' node but found '${selectedChildIndex}'`
                );
            });
        });

        describe("result in a tree that behaves exactly as the original does for", () => {
            const cases: [string, string][] = [
                ["a lotto node", definition],
                [
                    "a lotto node with weights",
                    "root { lotto [1,5,2] { action [ChildA] action [ChildB] action [ChildC] } }"
                ],
                [
                    "a lotto node in a sequence",
                    "root { sequence { action [Pass] lotto { action [ChildA] action [ChildB] } action [Pass] } }"
                ],
                [
                    "a lotto node that is repeated",
                    "root { repeat { lotto { action [ChildA] action [ChildB] action [ChildC] } } }"
                ],
                [
                    "nested lotto nodes",
                    "root { repeat { lotto { lotto { action [ChildA] action [ChildB] } action [ChildC] } } }"
                ]
            ];

            cases.forEach(([description, definition]) => {
                it(description, () => {
                    assertRestoreMatchesOriginal({ definition, script: lottoScript, steps: 20 });
                });
            });
        });
    });

    describe("snapshot() and restore() for a wait node", () => {
        const waitScript: Script = {
            Before: () => State.SUCCEEDED,
            After: () => State.SUCCEEDED,
            Check: (step) => step % 5 !== 4,
            Slow: (step) => (step % 3 === 0 ? undefined : State.SUCCEEDED)
        };

        const getWaitSnapshot = (tree: BehaviourTree) => (tree.snapshot().root as any).children[0];

        describe("with a fake clock", () => {
            let clock: SinonFakeTimers;

            beforeEach(() => {
                clock = sinon.useFakeTimers({ now: 1_000_000, toFake: ["Date"] });
            });

            afterEach(() => {
                clock.restore();
            });

            describe("keep the total duration and the duration waited so far", () => {
                it("(before the node has started)", () => {
                    const tree = new BehaviourTree("root { wait [1000] }", {});

                    assert.deepEqual(getWaitSnapshot(tree), {
                        type: "wait",
                        state: State.READY,
                        totalDuration: null,
                        waitedDuration: 0
                    });
                });

                it("(using the clock, including time that passed since the last step)", () => {
                    const tree = new BehaviourTree("root { wait [1000] }", {});

                    tree.step();
                    clock.tick(300);
                    tree.step();
                    clock.tick(100);

                    assert.deepEqual(getWaitSnapshot(tree), {
                        type: "wait",
                        state: State.RUNNING,
                        totalDuration: 1000,
                        waitedDuration: 400
                    });
                });

                it("(using the 'getDeltaTime' function option, ignoring the clock)", () => {
                    const tree = new BehaviourTree("root { wait [1000] }", {}, { getDeltaTime: () => 0.25 });

                    tree.step();
                    tree.step();
                    clock.tick(5000);

                    assert.deepEqual(getWaitSnapshot(tree), {
                        type: "wait",
                        state: State.RUNNING,
                        totalDuration: 1000,
                        waitedDuration: 500
                    });
                });

                it("(after the node has finished waiting)", () => {
                    const tree = new BehaviourTree("root { wait [1000] }", {});

                    tree.step();
                    clock.tick(1500);
                    tree.step();
                    clock.tick(5000);

                    assert.deepEqual(getWaitSnapshot(tree), {
                        type: "wait",
                        state: State.SUCCEEDED,
                        totalDuration: 1000,
                        waitedDuration: 1500
                    });
                });

                it("(for a duration chosen at random)", () => {
                    const tree = new BehaviourTree("root { wait [1000, 2000] }", {}, { random: () => 0.5 });

                    tree.step();

                    assert.equal(getWaitSnapshot(tree).totalDuration, 1500);
                });

                it("(for a node that waits indefinitely)", () => {
                    const tree = new BehaviourTree("root { wait }", {});

                    tree.step();
                    clock.tick(1000);

                    assert.deepEqual(getWaitSnapshot(tree), {
                        type: "wait",
                        state: State.RUNNING,
                        totalDuration: null,
                        waitedDuration: 0
                    });
                });
            });

            describe("restore a node that only waits for the remaining time, not counting the time that passes between the snapshot and the restore", () => {
                const hours = (count: number) => count * 60 * 60 * 1000;

                it("(using the clock)", () => {
                    const original = new BehaviourTree("root { wait [1000] }", {});
                    original.step();
                    clock.tick(400);
                    const snapshot = JSON.parse(JSON.stringify(original.snapshot()));

                    clock.tick(hours(48));
                    const restored = new BehaviourTree("root { wait [1000] }", {});
                    restored.restore(snapshot);
                    assert.equal(restored.getState(), State.RUNNING);

                    clock.tick(500);
                    restored.step();
                    assert.equal(restored.getState(), State.RUNNING);

                    clock.tick(100);
                    restored.step();
                    assert.equal(restored.getState(), State.SUCCEEDED);
                });

                it("(using the 'getDeltaTime' function option)", () => {
                    let deltaTime = 0.4;
                    const options = { getDeltaTime: () => deltaTime };

                    const original = new BehaviourTree("root { wait [1000] }", {}, options);
                    original.step();
                    const snapshot = JSON.parse(JSON.stringify(original.snapshot()));

                    clock.tick(hours(48));
                    const restored = new BehaviourTree("root { wait [1000] }", {}, options);
                    restored.restore(snapshot);

                    restored.step();
                    assert.equal(restored.getState(), State.RUNNING);

                    deltaTime = 0.2;
                    restored.step();
                    assert.equal(restored.getState(), State.SUCCEEDED);
                });

                it("(using the clock after taking the snapshot with the 'getDeltaTime' function option)", () => {
                    const original = new BehaviourTree("root { wait [1000] }", {}, { getDeltaTime: () => 0.4 });
                    original.step();
                    const snapshot = JSON.parse(JSON.stringify(original.snapshot()));

                    clock.tick(hours(48));
                    const restored = new BehaviourTree("root { wait [1000] }", {});
                    restored.restore(snapshot);

                    clock.tick(599);
                    restored.step();
                    assert.equal(restored.getState(), State.RUNNING);

                    clock.tick(1);
                    restored.step();
                    assert.equal(restored.getState(), State.SUCCEEDED);
                });

                it("(using the 'getDeltaTime' function option after taking the snapshot with the clock)", () => {
                    const original = new BehaviourTree("root { wait [1000] }", {});
                    original.step();
                    clock.tick(400);
                    const snapshot = JSON.parse(JSON.stringify(original.snapshot()));

                    clock.tick(hours(48));
                    const restored = new BehaviourTree("root { wait [1000] }", {}, { getDeltaTime: () => 0.3 });
                    restored.restore(snapshot);

                    restored.step();
                    assert.equal(restored.getState(), State.RUNNING);

                    restored.step();
                    assert.equal(restored.getState(), State.SUCCEEDED);
                });

                it("(when it had already waited for longer than the total duration)", () => {
                    const original = new BehaviourTree("root { wait [1000] }", {});
                    original.step();
                    clock.tick(5000);
                    const snapshot = JSON.parse(JSON.stringify(original.snapshot()));

                    const restored = new BehaviourTree("root { wait [1000] }", {});
                    restored.restore(snapshot);
                    restored.step();

                    assert.equal(restored.getState(), State.SUCCEEDED);
                });
            });

            it("restore a duration chosen at random without calling the 'random' function option", () => {
                const original = new BehaviourTree("root { wait [1000, 2000] }", {}, { random: () => 0.5 });
                original.step();
                const snapshot = JSON.parse(JSON.stringify(original.snapshot()));

                const restored = new BehaviourTree(
                    "root { wait [1000, 2000] }",
                    {},
                    {
                        random: () => {
                            throw new Error("random should not be called");
                        }
                    }
                );
                restored.restore(snapshot);

                clock.tick(1499);
                restored.step();
                assert.equal(restored.getState(), State.RUNNING);

                clock.tick(1);
                restored.step();
                assert.equal(restored.getState(), State.SUCCEEDED);
            });

            it("restore a node that waits indefinitely", () => {
                const original = new BehaviourTree("root { wait }", {});
                original.step();

                const restored = new BehaviourTree("root { wait }", {});
                restored.restore(JSON.parse(JSON.stringify(original.snapshot())));
                clock.tick(1000 * 60 * 60 * 24 * 365);
                restored.step();

                assert.equal(restored.getState(), State.RUNNING);
            });

            it("will error if the durations in the snapshot are invalid", () => {
                const tree = new BehaviourTree("root { wait [1000] }", {});
                tree.step();

                const corrupt = (change: (wait: any) => void) => {
                    const snapshot = JSON.parse(JSON.stringify(tree.snapshot()));
                    change(snapshot.root.children[0]);
                    return snapshot;
                };

                const cases: [(wait: any) => void, string][] = [
                    [
                        (wait) => (wait.totalDuration = -1),
                        "expected null or a non-negative number for the 'totalDuration' of a 'wait' node but found '-1'"
                    ],
                    [
                        (wait) => (wait.totalDuration = "1000"),
                        "expected null or a non-negative number for the 'totalDuration' of a 'wait' node but found '1000'"
                    ],
                    [
                        (wait) => delete wait.totalDuration,
                        "expected null or a non-negative number for the 'totalDuration' of a 'wait' node but found 'undefined'"
                    ],
                    [
                        (wait) => (wait.waitedDuration = null),
                        "expected a number for the 'waitedDuration' of a 'wait' node but found 'null'"
                    ],
                    [
                        (wait) => (wait.waitedDuration = "5"),
                        "expected a number for the 'waitedDuration' of a 'wait' node but found '5'"
                    ]
                ];

                cases.forEach(([change, message]) => {
                    assert.throws(() => tree.restore(corrupt(change)), Error, `invalid snapshot: ${message}`);
                });
            });
        });

        describe("result in a tree that behaves exactly as the original does for", () => {
            const cases: [string, string][] = [
                ["a wait node", "root { sequence { action [Before] wait [1000] action [After] } }"],
                [
                    "a wait node with a random duration",
                    "root { sequence { action [Before] wait [500, 2000] action [After] } }"
                ],
                [
                    "a repeated wait node with a random duration",
                    "root { repeat { sequence { wait [300, 1500] action [Slow] } } }"
                ],
                ["several wait nodes running at once", "root { all { wait [700] wait [1000, 3000] wait [100] } }"],
                [
                    "a wait node that is aborted",
                    "root { race { wait [3000] sequence { wait [1200] action [After] } } }"
                ],
                [
                    "an indefinite wait node that is aborted by a guard",
                    "root { sequence { wait while(Check) action [After] } }"
                ],
                [
                    "a wait node with no steps taken in between",
                    "root { sequence { wait [0] wait [300] action [After] } }"
                ]
            ];

            const waitTimings: [string, (getRandom: () => number) => BehaviourTreeOptions | undefined][] = [
                ["using the clock", () => undefined],
                ["using the 'getDeltaTime' function option", () => ({ getDeltaTime: () => STEP_DURATION / 1000 })]
            ];

            waitTimings.forEach(([timing, options]) => {
                describe(timing, () => {
                    cases.forEach(([description, definition]) => {
                        it(description, () => {
                            assertRestoreMatchesOriginal({
                                definition,
                                script: waitScript,
                                steps: 25,
                                options
                            });
                        });
                    });
                });
            });
        });
    });

    describe("snapshot() and restore() for an action node", () => {
        const definition = "root { sequence { action [Work] action [Finish] } }";

        const getActionSnapshot = (tree: BehaviourTree) => (tree.snapshot().root as any).children[0].children[0];

        const flushPromises = () => new Promise((resolve) => setImmediate(resolve));

        /**
         * Create a tree with a 'Work' action that returns a promise that we settle ourselves.
         */
        const createPromiseTree = (calls: string[] = []) => {
            const settle: { resolve: (state: unknown) => void; reject: (reason: unknown) => void } = {
                resolve: () => undefined,
                reject: () => undefined
            };

            const agent = {
                Work: () => {
                    calls.push("Work");
                    return new Promise((resolve, reject) => Object.assign(settle, { resolve, reject }));
                },
                Finish: () => {
                    calls.push("Finish");
                    return State.SUCCEEDED;
                }
            };

            return { tree: new BehaviourTree(definition, agent as any), settle, calls };
        };

        it("keep no update promise result for an action that does not return a promise", () => {
            const tree = new BehaviourTree(definition, { Work: () => State.RUNNING, Finish: () => State.SUCCEEDED });

            assert.deepEqual(getActionSnapshot(tree), {
                type: "action",
                state: State.READY,
                updatePromiseResult: null
            });

            tree.step();

            assert.deepEqual(getActionSnapshot(tree), {
                type: "action",
                state: State.RUNNING,
                updatePromiseResult: null
            });
        });

        it("keep the result of an update promise that has resolved", async () => {
            const { tree, settle } = createPromiseTree();
            tree.step();
            settle.resolve(State.SUCCEEDED);
            await flushPromises();

            assert.deepEqual(getActionSnapshot(tree), {
                type: "action",
                state: State.RUNNING,
                updatePromiseResult: { isResolved: true, value: State.SUCCEEDED }
            });
        });

        it("keep the result of an update promise that has rejected", async () => {
            const { tree, settle } = createPromiseTree();
            tree.step();
            settle.reject(new Error("boom"));
            await flushPromises();

            assert.deepEqual(getActionSnapshot(tree), {
                type: "action",
                state: State.RUNNING,
                updatePromiseResult: { isResolved: false, value: "Error: boom" }
            });
        });

        it("keep no update promise result after the result of the promise has been used", async () => {
            const { tree, settle } = createPromiseTree();
            tree.step();
            settle.resolve(State.FAILED);
            await flushPromises();
            tree.step();

            assert.deepEqual(getActionSnapshot(tree), {
                type: "action",
                state: State.FAILED,
                updatePromiseResult: null
            });
        });

        it("keep an action whose update promise is yet to settle as not yet started", async () => {
            const { tree, settle } = createPromiseTree();
            tree.step();

            assert.deepEqual(getActionSnapshot(tree), {
                type: "action",
                state: State.READY,
                updatePromiseResult: null
            });

            // The tree that the snapshot was taken from is not affected, and the snapshot reflects the promise once it settles.
            settle.resolve(State.SUCCEEDED);
            await flushPromises();

            assert.deepEqual(getActionSnapshot(tree), {
                type: "action",
                state: State.RUNNING,
                updatePromiseResult: { isResolved: true, value: State.SUCCEEDED }
            });

            tree.step();

            assert.equal(tree.getState(), State.SUCCEEDED);
        });

        it("restore an action whose update promise was yet to settle so that its action function is called again on the next step", async () => {
            const original = createPromiseTree();
            original.tree.step();
            const snapshot = JSON.parse(JSON.stringify(original.tree.snapshot()));
            assert.deepEqual(original.calls, ["Work"]);

            const restored = createPromiseTree();
            restored.tree.restore(snapshot);

            assert.equal(restored.tree.getState(), State.RUNNING);
            assert.deepEqual(
                restored.tree.getTreeNodeDetails().children![0].children!.map(({ state }) => state),
                [State.READY, State.READY]
            );
            assert.deepEqual(restored.calls, []);

            restored.tree.step();
            assert.deepEqual(restored.calls, ["Work"]);
            assert.equal(restored.tree.getState(), State.RUNNING);

            // It is now waiting on the new promise, and carries on from there.
            restored.tree.step();
            assert.deepEqual(restored.calls, ["Work"]);

            restored.settle.resolve(State.SUCCEEDED);
            await flushPromises();
            restored.tree.step();

            assert.deepEqual(restored.calls, ["Work", "Finish"]);
            assert.equal(restored.tree.getState(), State.SUCCEEDED);
        });

        it("restore an action whose update promise was yet to settle without it being affected by the promise that was discarded", async () => {
            const original = createPromiseTree();
            original.tree.step();
            const snapshot = original.tree.snapshot();

            // Restore it over the tree that it was taken from, then settle the promise that the snapshot could not keep.
            original.tree.restore(snapshot);
            original.settle.resolve(State.FAILED);
            await flushPromises();
            original.tree.step();

            assert.equal(original.tree.getState(), State.RUNNING);
            assert.deepEqual(original.calls, ["Work", "Work"]);
        });

        it("restore an action whose update promise was yet to settle that is nested in a tree with other running nodes", async () => {
            const calls: string[] = [];
            const agent = {
                Pending: () => {
                    calls.push("Pending");
                    return new Promise(() => undefined);
                },
                Running: () => {
                    calls.push("Running");
                    return State.RUNNING;
                }
            };
            const nestedDefinition = "root { parallel { sequence { action [Pending] } action [Running] } }";

            const original = new BehaviourTree(nestedDefinition, agent as any);
            original.step();
            original.step();
            assert.deepEqual(calls, ["Pending", "Running", "Running"]);

            calls.length = 0;
            const restored = new BehaviourTree(nestedDefinition, agent as any);
            restored.restore(JSON.parse(JSON.stringify(original.snapshot())));
            restored.step();

            assert.deepEqual(calls, ["Pending", "Running"]);
            assert.equal(restored.getState(), State.RUNNING);
        });

        it("restore an action whose update promise was yet to settle so that its 'entry' callback is called again as it starts", () => {
            const calls: string[] = [];
            const agent = {
                Enter: () => calls.push("Enter"),
                Work: () => new Promise(() => undefined)
            };
            const entryDefinition = "root { action [Work] entry(Enter) }";

            const original = new BehaviourTree(entryDefinition, agent as any);
            original.step();
            assert.deepEqual(calls, ["Enter"]);

            const restored = new BehaviourTree(entryDefinition, agent as any);
            restored.restore(original.snapshot());
            assert.deepEqual(calls, ["Enter"]);

            restored.step();
            assert.deepEqual(calls, ["Enter", "Enter"]);
        });

        it("restore the result of an update promise that has resolved without calling the action function again", async () => {
            const original = createPromiseTree();
            original.tree.step();
            original.settle.resolve(State.SUCCEEDED);
            await flushPromises();
            const snapshot = JSON.parse(JSON.stringify(original.tree.snapshot()));

            const restored = createPromiseTree();
            restored.tree.restore(snapshot);
            restored.tree.step();

            assert.deepEqual(restored.calls, ["Finish"]);
            assert.equal(restored.tree.getState(), State.SUCCEEDED);
        });

        it("restore the result of an update promise that has rejected so that it is handled in the same way", async () => {
            const original = createPromiseTree();
            original.tree.step();
            original.settle.reject(new Error("boom"));
            await flushPromises();
            const snapshot = JSON.parse(JSON.stringify(original.tree.snapshot()));

            let originalError: Error | undefined;
            try {
                original.tree.step();
            } catch (error) {
                originalError = error as Error;
            }

            const restored = createPromiseTree();
            restored.tree.restore(snapshot);

            assert.isDefined(originalError);
            assert.throws(() => restored.tree.step(), Error, originalError!.message);
            assert.deepEqual(restored.calls, []);
        });

        it("restore the result of an update promise that has resolved with an invalid value so that it is handled in the same way", async () => {
            const original = createPromiseTree();
            original.tree.step();
            original.settle.resolve("not a state");
            await flushPromises();
            const snapshot = JSON.parse(JSON.stringify(original.tree.snapshot()));

            const restored = createPromiseTree();
            restored.tree.restore(snapshot);

            assert.throws(
                () => restored.tree.step(),
                Error,
                "action node promise resolved with an invalid value, expected a State.SUCCEEDED or State.FAILED value to be returned"
            );
        });

        it("restore a running action that does not use a promise so that it is called again on the next step", () => {
            let result: State | undefined = undefined;
            const calls: string[] = [];
            const agent = {
                Work: () => {
                    calls.push("Work");
                    return result;
                },
                Finish: () => State.SUCCEEDED
            };

            const original = new BehaviourTree(definition, agent);
            original.step();

            calls.length = 0;
            const restored = new BehaviourTree(definition, agent);
            restored.restore(JSON.parse(JSON.stringify(original.snapshot())));
            restored.step();
            result = State.SUCCEEDED;
            restored.step();

            assert.deepEqual(calls, ["Work", "Work"]);
            assert.equal(restored.getState(), State.SUCCEEDED);
        });

        it("restore over an action with an update promise that is yet to settle so that it cannot change the restored state", async () => {
            // Take a snapshot of a tree where the update promise has already resolved.
            const source = createPromiseTree();
            source.tree.step();
            source.settle.resolve(State.FAILED);
            await flushPromises();
            const snapshot = source.tree.snapshot();

            // Restore it over a tree that is waiting on a different update promise, which then resolves.
            const target = createPromiseTree();
            target.tree.step();
            target.tree.restore(snapshot);
            target.settle.resolve(State.SUCCEEDED);
            await flushPromises();
            target.tree.step();

            assert.equal(target.tree.getState(), State.FAILED);
            assert.deepEqual(target.calls, ["Work"]);
        });

        it("will error if the update promise result in the snapshot is invalid", () => {
            const tree = new BehaviourTree(definition, { Work: () => State.RUNNING, Finish: () => State.SUCCEEDED });
            tree.step();

            const invalidResults = [
                undefined,
                "resolved",
                { isResolved: "yes", value: State.SUCCEEDED },
                { isResolved: true, value: State.RUNNING },
                { isResolved: true, value: "mistreevous.succeeded!" },
                { isResolved: false, value: 5 },
                { isResolved: false }
            ];

            invalidResults.forEach((updatePromiseResult) => {
                const snapshot = JSON.parse(JSON.stringify(tree.snapshot()));
                snapshot.root.children[0].children[0].updatePromiseResult = updatePromiseResult;

                assert.throws(
                    () => tree.restore(snapshot),
                    Error,
                    "invalid snapshot: expected null or a valid update promise result for the 'updatePromiseResult' of an 'action' node"
                );
            });
        });
    });

    describe("restore() of a snapshot of a finished tree", () => {
        const definition =
            "root { sequence { lotto { action [PassA] action [PassB] } repeat [2,5] { action [PassA] } } }";
        const script: Script = { PassA: () => State.SUCCEEDED, PassB: () => State.SUCCEEDED };

        const getNodeSnapshots = (tree: BehaviourTree) => {
            const sequence = (tree.snapshot().root as any).children[0];
            return { lotto: sequence.children[0], repeat: sequence.children[1] };
        };

        const runToCompletion = (tree: BehaviourTree) => {
            for (let steps = 0; steps < 20 && !(tree.getState() === State.SUCCEEDED); steps++) {
                tree.step();
            }
            assert.equal(tree.getState(), State.SUCCEEDED);
        };

        it("results in a finished tree", () => {
            const original = new BehaviourTree(
                definition,
                createAgent(script, [], () => 0),
                { random: () => 0.99 }
            );
            runToCompletion(original);

            const restored = new BehaviourTree(
                definition,
                createAgent(script, [], () => 0)
            );
            restored.restore(JSON.parse(JSON.stringify(original.snapshot())));

            assert.equal(restored.getState(), State.SUCCEEDED);
            assert.isFalse(restored.isRunning());
            assert.deepEqual(restored.snapshot(), original.snapshot());
        });

        it("starts a new run on the next step, which makes its random choices again", () => {
            const original = new BehaviourTree(
                definition,
                createAgent(script, [], () => 0),
                { random: () => 0.99 }
            );
            runToCompletion(original);
            assert.equal(getNodeSnapshots(original).lotto.selectedChildIndex, 1);
            assert.equal(getNodeSnapshots(original).repeat.targetIterationCount, 5);

            const calls: string[] = [];
            const restored = new BehaviourTree(
                definition,
                createAgent(script, calls, () => 0),
                { random: () => 0 }
            );
            restored.restore(JSON.parse(JSON.stringify(original.snapshot())));
            restored.step();

            // The new run chose the first lotto child and 2 iterations rather than the second child and 5 iterations of the last run.
            assert.deepEqual(calls, ["PassA", "PassA"]);
            assert.equal(restored.getState(), State.RUNNING);
            assert.equal(getNodeSnapshots(restored).lotto.selectedChildIndex, 0);
            assert.equal(getNodeSnapshots(restored).repeat.targetIterationCount, 2);
        });

        it("is the same for a tree that failed", () => {
            const original = new BehaviourTree("root { sequence { action [PassA] condition [No] } }", {
                PassA: () => State.SUCCEEDED,
                No: () => false
            });
            original.step();
            assert.equal(original.getState(), State.FAILED);

            const restored = new BehaviourTree("root { sequence { action [PassA] condition [No] } }", {
                PassA: () => State.SUCCEEDED,
                No: () => true
            });
            restored.restore(original.snapshot());
            assert.equal(restored.getState(), State.FAILED);

            // A new run uses the new agent behaviour.
            restored.step();
            assert.equal(restored.getState(), State.SUCCEEDED);
        });
    });

    describe("restore() with an 'onNodeStateChange' option", () => {
        const definition = `root {
            sequence {
                action [WorkA]
                repeat [2] { action [WorkB] }
                wait [1000]
                lotto { action [WorkC] action [WorkB] }
            }
        }`;

        let clock: SinonFakeTimers;

        beforeEach(() => {
            clock = sinon.useFakeTimers({ now: 1_000_000, toFake: ["Date"] });
        });

        afterEach(() => {
            clock.restore();
        });

        const createLoggedTree = (getStep: () => number) => {
            const changes: { type: string; previousState: State; state: State }[] = [];
            const tree = new BehaviourTree(definition, createAgent(workScript, [], getStep), {
                random: () => 0.9,
                onNodeStateChange: ({ type, previousState, state }) => changes.push({ type, previousState, state })
            });
            return { tree, changes };
        };

        it("is not called for any node, whatever the states of the tree before and after", () => {
            let step = 0;
            const original = createLoggedTree(() => step);
            const snapshots: BehaviourTreeSnapshot[] = [JSON.parse(JSON.stringify(original.tree.snapshot()))];
            for (step = 0; step < 8; step++) {
                clock.tick(STEP_DURATION * 4);
                original.tree.step();
                snapshots.push(JSON.parse(JSON.stringify(original.tree.snapshot())));
            }

            // Restore each snapshot over a tree that is in a different state.
            const restored = createLoggedTree(() => step);
            snapshots.forEach((snapshot, snapshotIndex) => {
                step = (snapshotIndex + 3) % 8;
                restored.tree.reset();
                restored.tree.step();
                restored.changes.length = 0;

                restored.tree.restore(snapshot);

                assert.deepEqual(restored.changes, [], `changes after restoring snapshot ${snapshotIndex}`);
                assert.deepEqual(restored.tree.snapshot(), snapshot);
            });
        });

        it("is called as usual by the next step, as if the tree had not been restored", () => {
            let step = 0;
            const original = createLoggedTree(() => step);
            for (step = 0; step < 3; step++) {
                clock.tick(STEP_DURATION);
                original.tree.step();
            }
            const snapshot = JSON.parse(JSON.stringify(original.tree.snapshot()));

            // Carry on with the original tree, noting every state change from here.
            original.changes.length = 0;
            for (; step < 8; step++) {
                clock.tick(STEP_DURATION);
                original.tree.step();
            }
            assert.isAbove(original.changes.length, 0);

            // A restored tree makes exactly the same state changes, starting from the restored states.
            step = 3;
            const restored = createLoggedTree(() => step);
            restored.tree.restore(snapshot);
            for (; step < 8; step++) {
                clock.tick(STEP_DURATION);
                restored.tree.step();
            }

            assert.deepEqual(restored.changes, original.changes);
        });
    });

    describe("a snapshot is independent of the trees it is taken from and restored to", () => {
        const definition = `root {
            sequence {
                action [WorkA]
                repeat [2,3] { action [WorkB] }
                wait [1000, 2000]
                lotto { action [WorkC] action [WorkB] }
            }
        }`;

        let clock: SinonFakeTimers;

        beforeEach(() => {
            clock = sinon.useFakeTimers({ now: 1_000_000, toFake: ["Date"] });
        });

        afterEach(() => {
            clock.restore();
        });

        const createTree = (getStep: () => number) =>
            new BehaviourTree(definition, createAgent(workScript, [], getStep), { random: () => 0.3 });

        it("so stepping the tree it was taken from does not change it", () => {
            let step = 0;
            const tree = createTree(() => step);

            for (step = 0; step < 8; step++) {
                clock.tick(STEP_DURATION);
                tree.step();

                const snapshot = tree.snapshot();
                const json = JSON.stringify(snapshot);

                for (let extraSteps = 0; extraSteps < 8; extraSteps++) {
                    clock.tick(STEP_DURATION);
                    tree.step();
                }

                assert.equal(JSON.stringify(snapshot), json, `snapshot taken after step ${step}`);
                tree.restore(snapshot);
            }
        });

        it("so stepping a tree it was restored to does not change it", () => {
            let step = 0;
            const original = createTree(() => step);
            const restored = createTree(() => step);

            for (step = 0; step < 8; step++) {
                clock.tick(STEP_DURATION);
                original.step();

                const snapshot = original.snapshot();
                const json = JSON.stringify(snapshot);

                restored.restore(snapshot);
                for (let extraSteps = 0; extraSteps < 8; extraSteps++) {
                    clock.tick(STEP_DURATION);
                    restored.step();
                }

                assert.equal(JSON.stringify(snapshot), json, `snapshot taken after step ${step}`);
            }
        });

        it("so a snapshot taken straight after restoring it is the same", () => {
            let step = 0;
            const original = createTree(() => step);
            const restored = createTree(() => step);

            for (step = 0; step < 8; step++) {
                clock.tick(STEP_DURATION);
                original.step();

                const snapshot = original.snapshot();
                restored.restore(snapshot);

                assert.deepEqual(
                    JSON.parse(JSON.stringify(restored.snapshot())),
                    JSON.parse(JSON.stringify(snapshot)),
                    `snapshot taken after step ${step}`
                );
            }
        });

        it("including the result of an update promise", async () => {
            const agent = { Work: () => Promise.resolve(State.SUCCEEDED) };
            const original = new BehaviourTree("root { action [Work] }", agent);
            const restored = new BehaviourTree("root { action [Work] }", agent);

            original.step();
            await Promise.resolve();

            const snapshot = original.snapshot();
            const json = JSON.stringify(snapshot);
            assert.deepEqual((snapshot.root as any).children[0].updatePromiseResult, {
                isResolved: true,
                value: State.SUCCEEDED
            });

            restored.restore(snapshot);
            assert.equal(JSON.stringify(restored.snapshot()), json);

            restored.step();
            original.step();

            assert.equal(restored.getState(), State.SUCCEEDED);
            assert.equal(JSON.stringify(snapshot), json);
        });
    });
});
