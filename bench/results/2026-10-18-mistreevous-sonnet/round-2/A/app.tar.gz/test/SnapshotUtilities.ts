import { assert } from "chai";
import sinon from "sinon";

import { BehaviourTree, BehaviourTreeOptions, NodeDetails, State } from "../src/index";
import { RootNodeDefinition } from "../src/BehaviourTreeDefinition";

/**
 * A mapping of agent function names to functions that return the result of calling the agent function on a given tree step.
 */
export type Script = { [name: string]: (step: number) => State | boolean | undefined | Promise<State> };

/**
 * Everything that can be observed about a single step of a tree.
 */
type StepRecord = {
    calls: string[];
    treeState: State;
    nodes: Omit<NodeDetails, "id">;
};

/**
 * The time that passes between each step in a run, in milliseconds.
 */
export const STEP_DURATION = 300;

/**
 * The time that passes between a snapshot being taken and being restored, in milliseconds.
 */
const DOWNTIME = 1000 * 60 * 60 * 100;

/**
 * Some pseudo-random numbers to cycle through.
 */
const RANDOM_VALUES = [0.05, 0.95, 0.5, 0.3, 0.7, 0.15, 0.85, 0.6, 0.4, 0.25, 0.75, 0.01, 0.99, 0.45, 0.55];

/**
 * Strip node ids, which are unique to a tree instance, from node details.
 */
function stripIds({ id, children, ...details }: NodeDetails): Omit<NodeDetails, "id"> {
    return children ? { ...details, children: children.map(stripIds) as any } : details;
}

/**
 * Creates a script-driven agent that logs every function call.
 */
export function createAgent(script: Script, calls: string[], getStep: () => number) {
    return Object.fromEntries(
        Object.keys(script).map((name) => [
            name,
            () => {
                calls.push(name);
                return script[name](getStep());
            }
        ])
    );
}

/**
 * Assert that a tree restored from a snapshot taken at any point in the run of another tree continues to behave exactly as that
 * other tree does: it has the same node states and calls the same agent functions in the same order on every remaining step.
 *
 * A large amount of time passes between each snapshot being taken and restored, and the pseudo-random numbers used by the
 * restored tree continue from where the original left off, so choices already made have to come from the snapshot.
 */
export function assertRestoreMatchesOriginal(args: {
    definition: string | RootNodeDefinition | RootNodeDefinition[];
    script: Script;
    steps: number;
    options?: (getRandom: () => number) => BehaviourTreeOptions | undefined;
}) {
    const clock = sinon.useFakeTimers({ now: 1_000_000, toFake: ["Date"] });

    try {
        let randomPosition = 0;
        const getRandom = () => RANDOM_VALUES[randomPosition++ % RANDOM_VALUES.length];

        let step = 0;
        const calls: string[] = [];

        const createTree = () =>
            new BehaviourTree(
                args.definition,
                createAgent(args.script, calls, () => step),
                {
                    random: getRandom,
                    ...args.options?.(getRandom)
                }
            );

        const stepTree = (tree: BehaviourTree, stepNumber: number): StepRecord => {
            step = stepNumber;
            calls.length = 0;
            clock.tick(STEP_DURATION);
            tree.step();
            return { calls: [...calls], treeState: tree.getState(), nodes: stripIds(tree.getTreeNodeDetails()) };
        };

        // Run the original tree to completion, taking a snapshot (as JSON) before the first step and after each step.
        const original = createTree();
        const records: StepRecord[] = [];
        const takeSnapshot = () => {
            const snapshot = original.snapshot();
            const json = JSON.stringify(snapshot);
            assert.deepEqual(JSON.parse(json), snapshot, "snapshot after conversion to JSON and back");
            return { json, randomPosition };
        };
        const snapshots = [takeSnapshot()];
        for (let stepNumber = 0; stepNumber < args.steps; stepNumber++) {
            records.push(stepTree(original, stepNumber));
            snapshots.push(takeSnapshot());
        }

        // Restore each snapshot to a new tree and check that it carries on just as the original did.
        snapshots.forEach(({ json, randomPosition: savedRandomPosition }, snapshotIndex) => {
            clock.tick(DOWNTIME);
            randomPosition = savedRandomPosition;

            const restored = createTree();
            restored.restore(JSON.parse(json));

            assert.deepEqual(
                restored.snapshot(),
                JSON.parse(json),
                `snapshot taken straight after restoring ${snapshotIndex}`
            );

            assert.deepEqual(
                stripIds(restored.getTreeNodeDetails()),
                snapshotIndex === 0 ? stripIds(createTree().getTreeNodeDetails()) : records[snapshotIndex - 1].nodes,
                `node states after restoring snapshot ${snapshotIndex}`
            );

            for (let stepNumber = snapshotIndex; stepNumber < args.steps; stepNumber++) {
                assert.deepEqual(
                    stepTree(restored, stepNumber),
                    records[stepNumber],
                    `step ${stepNumber} after restoring snapshot ${snapshotIndex}`
                );
            }
        });
    } finally {
        clock.restore();
    }
}
