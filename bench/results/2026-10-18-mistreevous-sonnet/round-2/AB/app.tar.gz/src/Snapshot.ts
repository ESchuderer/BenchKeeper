import State, { AnyState } from "./State";
import { RootNodeDefinition } from "./BehaviourTreeDefinition";

/**
 * The current version of the snapshot format.
 */
export const SNAPSHOT_VERSION = 1;

/**
 * A snapshot of the execution state of a single tree node, and of the nodes nested within it.
 * A node snapshot is a plain object that is safe to pass through JSON serialisation.
 * Only the properties relevant to the type of node, and to the state it is in, will be defined.
 */
export type NodeSnapshot = {
    /**
     * The tree node type.
     */
    type: string;
    /**
     * The tree node name.
     */
    name: string;
    /**
     * The state of the tree node.
     * An action node that is waiting on a pending promise is not yet started as far as the snapshot is concerned, so it has a state of READY.
     */
    state: AnyState;
    /**
     * The snapshots of the child nodes, defined if this is a composite or decorator node.
     */
    children?: NodeSnapshot[];
    /**
     * The index of the child node picked by this node, defined if this is a lotto node that has picked a child.
     */
    selectedChildIndex?: number;
    /**
     * The number of iterations to make, or null for no limit, defined if this is a repeat node that has been updated.
     */
    targetIterationCount?: number | null;
    /**
     * The number of iterations made, defined if this is a repeat node that has been updated.
     */
    currentIterationCount?: number;
    /**
     * The number of attempts to make, or null for no limit, defined if this is a retry node that has been updated.
     */
    targetAttemptCount?: number | null;
    /**
     * The number of attempts made, defined if this is a retry node that has been updated.
     */
    currentAttemptCount?: number;
    /**
     * The duration in milliseconds to wait for, or null to wait indefinitely, defined if this is a running wait node.
     */
    totalDuration?: number | null;
    /**
     * The duration in milliseconds that has been waited for, defined if this is a running wait node.
     */
    waitedDuration?: number;
    /**
     * The settled result of the promise returned by the action function, defined if this is a running action node
     * that is waiting on a promise that has settled but has not yet been handled by a tree step.
     */
    updatePromiseResult?: {
        /**
         * Whether the promise was resolved rather than rejected.
         */
        isResolved: boolean;
        /**
         * The state the promise resolved with, or the rejection reason as a string.
         */
        value: string | null;
    };
};

/**
 * A snapshot of the execution state of a behaviour tree, as returned by `BehaviourTree.snapshot()`.
 * A tree snapshot is a plain object that is safe to pass through JSON serialisation.
 */
export type TreeSnapshot = {
    /**
     * The version of the snapshot format.
     */
    version: typeof SNAPSHOT_VERSION;
    /**
     * An identifier of the tree definition that the snapshot was taken from, which is the same for an MDSL definition and its equivalent JSON definition.
     * A snapshot can only be restored to a tree with the same definition.
     */
    definition: string;
    /**
     * The snapshot of the root node, and of every node nested within it.
     */
    root: NodeSnapshot;
};

/**
 * Gets whether the specified value is a valid node state.
 * @param value The value to check.
 * @returns Whether the specified value is a valid node state.
 */
export function isNodeState(value: unknown): value is AnyState {
    return Object.values(State).includes(value as State);
}

/**
 * Gets whether the specified value is a non-negative integer.
 * @param value The value to check.
 * @returns Whether the specified value is a non-negative integer.
 */
export function isCount(value: unknown): value is number {
    return typeof value === "number" && Number.isInteger(value) && value >= 0;
}

/**
 * Gets whether the specified value is a finite number.
 * @param value The value to check.
 * @returns Whether the specified value is a finite number.
 */
export function isFiniteNumber(value: unknown): value is number {
    return typeof value === "number" && Number.isFinite(value);
}

/**
 * Gets a copy of a tree definition in a canonical form, so that definitions that build the same tree have the same canonical form.
 * Properties are sorted and undefined properties are removed, as are empty `args` and a false `succeedOnAbort`, which are the same as not defining them.
 * @param value The tree definition, or part of a tree definition.
 * @returns The canonical form of the tree definition.
 */
function canonicalise(value: unknown): unknown {
    if (Array.isArray(value)) {
        return value.map(canonicalise);
    }

    if (typeof value !== "object" || value === null) {
        return value;
    }

    const properties = value as { [key: string]: unknown };
    const result: { [key: string]: unknown } = {};

    for (const key of Object.keys(properties).sort()) {
        const property = properties[key];

        if (
            property === undefined ||
            (key === "args" && Array.isArray(property) && property.length === 0) ||
            (key === "succeedOnAbort" && !property)
        ) {
            continue;
        }

        result[key] = key === "succeedOnAbort" ? true : canonicalise(property);
    }

    return result;
}

/**
 * Gets an identifier for a tree definition. This is the same for any definitions that build the same tree, such as an MDSL definition and its
 * equivalent JSON definition, and will be different for any definitions that do not. The identifier must not change between versions as
 * snapshots will have been stored with it.
 * @param definition The tree definition as an array of root node definitions.
 * @returns An identifier for the tree definition.
 */
export function getDefinitionId(definition: RootNodeDefinition[]): string {
    // The order of the sub-root nodes does not matter, but the main root node is the one without an identifier.
    const rootNodes = [
        ...definition.filter(({ id }) => id === undefined),
        ...definition.filter(({ id }) => id !== undefined).sort((a, b) => (a.id! < b.id! ? -1 : 1))
    ];

    // This is the cyrb53 hash of the canonical definition, which is not secure but is more than enough to tell definitions apart.
    const text = JSON.stringify(canonicalise(rootNodes));
    let h1 = 0xdeadbeef;
    let h2 = 0x41c6ce57;

    for (let index = 0; index < text.length; index++) {
        const code = text.charCodeAt(index);
        h1 = Math.imul(h1 ^ code, 2654435761);
        h2 = Math.imul(h2 ^ code, 1597334677);
    }

    h1 = Math.imul(h1 ^ (h1 >>> 16), 2246822507) ^ Math.imul(h2 ^ (h2 >>> 13), 3266489909);
    h2 = Math.imul(h2 ^ (h2 >>> 16), 2246822507) ^ Math.imul(h1 ^ (h1 >>> 13), 3266489909);

    return (4294967296 * (2097151 & h2) + (h1 >>> 0)).toString(16);
}
