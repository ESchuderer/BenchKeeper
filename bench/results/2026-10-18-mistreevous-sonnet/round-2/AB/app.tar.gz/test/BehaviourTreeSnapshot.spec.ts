import { assert } from "chai";
import sinon, { SinonFakeTimers } from "sinon";

import { BehaviourTree, State, TreeSnapshot, convertMDSLToJSON } from "../src/index";
import { RootNodeDefinition } from "../src/BehaviourTreeDefinition";

import { getTreeNodeDetailsWithoutIds } from "./TestUtilities";

/**
 * Create an agent that logs the name of each of its functions as they are called.
 * 'Hold' stays in the running state until the agent is released, 'Ok' succeeds and 'No' fails.
 */
function createAgent() {
    const agent = {
        log: [] as string[],
        released: false,
        Hold(name: string | number) {
            agent.log.push(`Hold:${name}`);
            return agent.released ? State.SUCCEEDED : State.RUNNING;
        },
        Ok(name: string | number) {
            agent.log.push(`Ok:${name}`);
            return State.SUCCEEDED;
        },
        No(name: string | number) {
            agent.log.push(`No:${name}`);
            return State.FAILED;
        }
    };

    return agent;
}

/**
 * Take a snapshot of the tree, passing it through JSON serialisation as it would be if it were stored.
 */
function takeStoredSnapshot(tree: BehaviourTree): TreeSnapshot {
    return JSON.parse(JSON.stringify(tree.snapshot()));
}

describe("A BehaviourTree", () => {
    describe("has a snapshot method that", () => {
        it("returns a plain object that is unchanged by a JSON round trip", () => {
            const tree = new BehaviourTree(
                "root { sequence { action [Ok, 1] parallel { action [Hold, 2] action [Hold, 3] } } }",
                createAgent()
            );

            for (let step = 0; step < 2; step++) {
                const snapshot = tree.snapshot();

                assert.deepEqual(JSON.parse(JSON.stringify(snapshot)), snapshot);

                tree.step();
            }
        });

        it("does not alter the tree or call any agent functions", () => {
            const agent = createAgent();
            const tree = new BehaviourTree("root { sequence { action [Ok, 1] action [Hold, 2] } }", agent);

            tree.step();

            const detailsBefore = getTreeNodeDetailsWithoutIds(tree);
            const logBefore = [...agent.log];

            tree.snapshot();

            assert.deepEqual(getTreeNodeDetailsWithoutIds(tree), detailsBefore);
            assert.deepEqual(agent.log, logBefore);
        });
    });

    describe("has a restore method that", () => {
        const definitions: { [name: string | number]: string } = {
            sequence: "root { sequence { action [Ok, 1] action [Hold, 2] action [Ok, 3] } }",
            selector: "root { selector { action [No, 1] action [Hold, 2] action [Ok, 3] } }",
            parallel: "root { parallel { action [Ok, 1] action [Hold, 2] action [Hold, 3] } }",
            race: "root { race { action [No, 1] action [Hold, 2] action [Hold, 3] } }",
            all: "root { all { action [Ok, 1] action [Hold, 2] action [No, 3] } }",
            flip: "root { sequence { action [Ok, 1] flip { action [Hold, 2] } } }",
            succeed: "root { sequence { action [Ok, 1] succeed { action [Hold, 2] } action [Ok, 3] } }",
            fail: "root { selector { fail { action [Hold, 1] } action [Ok, 2] } }",
            "nested composites": `root {
                sequence {
                    selector { action [No, 1] sequence { action [Ok, 2] action [Hold, 3] } }
                    action [Ok, 4]
                }
            }`
        };

        for (const [name, definition] of Object.entries(definitions)) {
            it(`gives a tree using ${name} nodes the same node states, and it then behaves as the original would`, () => {
                const originalAgent = createAgent();
                const original = new BehaviourTree(definition, originalAgent);

                original.step();

                const restoredAgent = createAgent();
                const restored = new BehaviourTree(definition, restoredAgent);

                restored.restore(takeStoredSnapshot(original));

                assert.deepEqual(getTreeNodeDetailsWithoutIds(restored), getTreeNodeDetailsWithoutIds(original));
                assert.strictEqual(restored.getState(), original.getState());
                assert.deepEqual(restoredAgent.log, [], "restoring should not call any agent functions");

                // Let both trees carry on from the same point.
                originalAgent.log.length = 0;
                originalAgent.released = true;
                restoredAgent.released = true;

                for (let step = 0; step < 3; step++) {
                    original.step();
                    restored.step();

                    assert.deepEqual(restoredAgent.log, originalAgent.log);
                    assert.deepEqual(getTreeNodeDetailsWithoutIds(restored), getTreeNodeDetailsWithoutIds(original));
                }
            });
        }

        it("does not call the entry callback again for a node that was already running", () => {
            const definition = "root { action [Hold, 1] entry(Entered) }";

            const originalAgent = { ...createAgent(), entered: 0, Entered: () => originalAgent.entered++ };
            const original = new BehaviourTree(definition, originalAgent);
            original.step();

            const restoredAgent = { ...createAgent(), entered: 0, Entered: () => restoredAgent.entered++ };
            const restored = new BehaviourTree(definition, restoredAgent);
            restored.restore(takeStoredSnapshot(original));
            restored.step();

            assert.strictEqual(originalAgent.entered, 1);
            assert.strictEqual(restoredAgent.entered, 0);
        });

        it("restores a tree that has not been stepped yet", () => {
            const agent = createAgent();
            const definition = "root { sequence { action [Ok, 1] action [Ok, 2] } }";
            const snapshot = takeStoredSnapshot(new BehaviourTree(definition, createAgent()));

            const tree = new BehaviourTree(definition, agent);
            tree.step();
            tree.restore(snapshot);

            assert.strictEqual(tree.getState(), State.READY);

            tree.step();

            assert.deepEqual(agent.log, ["Ok:1", "Ok:2", "Ok:1", "Ok:2"]);
        });

        it("restores a tree that has already moved on, back to the snapshot state", () => {
            const agent = createAgent();
            const tree = new BehaviourTree(
                "root { sequence { action [Ok, 1] action [Hold, 2] action [Ok, 3] } }",
                agent
            );

            tree.step();

            const snapshot = takeStoredSnapshot(tree);
            const detailsAtSnapshot = getTreeNodeDetailsWithoutIds(tree);

            agent.released = true;
            tree.step();

            assert.strictEqual(tree.getState(), State.SUCCEEDED);

            tree.restore(snapshot);

            assert.deepEqual(getTreeNodeDetailsWithoutIds(tree), detailsAtSnapshot);
        });

        it("restores a finished tree as finished, and the next step starts a new run", () => {
            const definition = "root { sequence { action [Ok, 1] action [Ok, 2] } }";

            const original = new BehaviourTree(definition, createAgent());
            original.step();

            assert.strictEqual(original.getState(), State.SUCCEEDED);

            const agent = createAgent();
            const restored = new BehaviourTree(definition, agent);
            restored.restore(takeStoredSnapshot(original));

            assert.strictEqual(restored.getState(), State.SUCCEEDED);
            assert.deepEqual(getTreeNodeDetailsWithoutIds(restored), getTreeNodeDetailsWithoutIds(original));

            restored.step();

            assert.deepEqual(agent.log, ["Ok:1", "Ok:2"]);
            assert.strictEqual(restored.getState(), State.SUCCEEDED);
        });

        it("does not call the onNodeStateChange option, and the next step reports changes as usual", () => {
            const definition = "root { sequence { action [Ok, 1] action [Hold, 2] action [Ok, 3] } }";

            const original = new BehaviourTree(definition, createAgent());
            original.step();

            const changes: { type: string; previousState: State; state: State }[] = [];
            const restoredAgent = createAgent();
            const restored = new BehaviourTree(definition, restoredAgent, {
                onNodeStateChange: ({ type, previousState, state }) => changes.push({ type, previousState, state })
            });

            restored.restore(takeStoredSnapshot(original));

            assert.deepEqual(changes, []);

            // Changes are reported from the restored node states.
            restoredAgent.released = true;
            restored.step();

            assert.sameDeepMembers(changes, [
                { type: "action", previousState: State.RUNNING, state: State.SUCCEEDED },
                { type: "action", previousState: State.READY, state: State.SUCCEEDED },
                { type: "sequence", previousState: State.RUNNING, state: State.SUCCEEDED },
                { type: "root", previousState: State.RUNNING, state: State.SUCCEEDED }
            ]);
        });

        it("does not call the onNodeStateChange option when restoring a tree that has already moved on", () => {
            const definition = "root { sequence { action [Ok, 1] action [Hold, 2] } }";

            const agent = createAgent();
            const changes: State[] = [];
            const tree = new BehaviourTree(definition, agent, {
                onNodeStateChange: ({ state }) => changes.push(state)
            });

            tree.step();

            const snapshot = takeStoredSnapshot(tree);

            agent.released = true;
            tree.step();
            changes.length = 0;

            tree.restore(snapshot);

            assert.deepEqual(changes, []);
        });

        describe("will throw an error and leave the tree untouched if", () => {
            const definition = "root { sequence { action [Ok, 1] action [Hold, 2] } }";

            function createSteppedTree() {
                const tree = new BehaviourTree(definition, createAgent());
                tree.step();
                return tree;
            }

            /**
             * Restore the snapshot to a tree that is part way through a run, checking that the restore fails and changes nothing.
             */
            function assertRestoreFails(snapshot: any, message: string | RegExp) {
                const tree = createSteppedTree();
                const detailsBefore = getTreeNodeDetailsWithoutIds(tree);

                assert.throws(() => tree.restore(snapshot), Error, message);
                assert.deepEqual(getTreeNodeDetailsWithoutIds(tree), detailsBefore);
            }

            /**
             * Take a snapshot of a tree built from the definition that is finished, which differs from the state of a stepped tree.
             */
            function takeFinishedSnapshot(): any {
                const agent = createAgent();
                agent.released = true;

                const tree = new BehaviourTree(definition, agent);
                tree.step();
                tree.step();

                return takeStoredSnapshot(tree);
            }

            it("the snapshot is not an object", () => {
                assertRestoreFails(null, "invalid snapshot: expected an object");
                assertRestoreFails(undefined, "invalid snapshot: expected an object");
                assertRestoreFails("snapshot", "invalid snapshot: expected an object");
                assertRestoreFails(42, "invalid snapshot: expected an object");
                assertRestoreFails(true, "invalid snapshot: expected an object");
                assertRestoreFails([], "invalid snapshot: expected an object");
                assertRestoreFails([takeFinishedSnapshot()], "invalid snapshot: expected an object");
            });

            it("the snapshot is an object that does not have the fields of a snapshot", () => {
                const snapshot = takeFinishedSnapshot();

                assertRestoreFails({}, /invalid snapshot/);
                assertRestoreFails({ some: "thing" }, /invalid snapshot/);
                assertRestoreFails({ version: snapshot.version }, /invalid snapshot/);
                assertRestoreFails({ version: snapshot.version, definition: snapshot.definition }, /invalid snapshot/);
                assertRestoreFails({ version: snapshot.version, root: snapshot.root }, /invalid snapshot/);
                assertRestoreFails({ definition: snapshot.definition, root: snapshot.root }, /invalid snapshot/);
                assertRestoreFails({ ...snapshot, definition: 42 }, /invalid snapshot/);
                assertRestoreFails({ ...snapshot, root: null }, /invalid snapshot/);
                assertRestoreFails({ ...snapshot, root: "root" }, /invalid snapshot/);
            });

            it("the snapshot version is not supported", () => {
                assertRestoreFails({ ...takeStoredSnapshot(createSteppedTree()), version: 99 }, "unsupported version");
            });

            it("the snapshot was taken from a tree with a different definition", () => {
                const others = [
                    // A different argument.
                    "root { sequence { action [Ok, 1] action [Hold, 3] } }",
                    // A different function.
                    "root { sequence { action [Ok, 1] action [No, 2] } }",
                    // Different nodes.
                    "root { selector { action [Ok, 1] action [Hold, 2] } }",
                    // A different structure.
                    "root { sequence { action [Ok, 1] } }",
                    "root { sequence { action [Ok, 1] action [Hold, 2] action [Ok, 3] } }",
                    "root { action [Ok, 1] }",
                    // Different attributes.
                    "root { sequence { action [Ok, 1] action [Hold, 2] entry(Entered) } }",
                    "root { sequence while(Allowed) { action [Ok, 1] action [Hold, 2] } }",
                    "root { sequence while(Allowed, true) { action [Ok, 1] action [Hold, 2] } }",
                    // Different counts and durations.
                    "root { repeat [2] { action [Ok, 1] } }",
                    "root { wait [100] }"
                ];

                for (const other of others) {
                    assertRestoreFails(
                        takeStoredSnapshot(new BehaviourTree(other, createAgent())),
                        /snapshot does not match the .*definition/
                    );
                }
            });

            it("the snapshot was taken from a tree with a different definition but the same structure", () => {
                // These have exactly the same nodes, so they would otherwise be accepted and restored, which corrupts the tree.
                const pairs = [
                    ["root { repeat [2] { action [Ok, 1] } }", "root { repeat [3] { action [Ok, 1] } }"],
                    ["root { repeat [3] { action [Ok, 1] } }", "root { repeat [2] { action [Ok, 1] } }"],
                    ["root { repeat [2] { action [Ok, 1] } }", "root { repeat [2, 3] { action [Ok, 1] } }"],
                    ["root { wait [100] }", "root { wait [200] }"]
                ];

                for (const [from, to] of pairs) {
                    const original = new BehaviourTree(from, createAgent());
                    original.step();

                    const tree = new BehaviourTree(to, createAgent());
                    const detailsBefore = getTreeNodeDetailsWithoutIds(tree);

                    assert.throws(
                        () => tree.restore(takeStoredSnapshot(original)),
                        Error,
                        /snapshot does not match the .*definition/
                    );
                    assert.deepEqual(getTreeNodeDetailsWithoutIds(tree), detailsBefore);
                }
            });

            it("the snapshot was taken from a tree with a different structure", () => {
                const snapshot = takeStoredSnapshot(createSteppedTree());
                snapshot.root.children![0].children!.pop();

                assertRestoreFails(snapshot, "root.children[0]: expected 2 children but got 1");
            });

            it("the snapshot was taken from a tree with different nodes", () => {
                const snapshot = takeStoredSnapshot(createSteppedTree());
                snapshot.root.children![0].type = "selector";

                assertRestoreFails(snapshot, "expected a 'sequence' node but got a 'selector' node");
            });

            it("a node state is not valid", () => {
                const snapshot = takeStoredSnapshot(createSteppedTree()) as any;
                snapshot.root.children[0].children[1].state = "mistreevous.bogus";

                assertRestoreFails(snapshot, "invalid state");
            });

            it("but a failed restore does not stop a later valid restore", () => {
                const tree = createSteppedTree();
                const finished = takeFinishedSnapshot();

                assert.throws(() => tree.restore({ ...finished, definition: "other" }), Error);

                tree.restore(finished);

                assert.strictEqual(tree.getState(), State.SUCCEEDED);
            });
        });

        describe("accepts a snapshot taken from a tree with an equivalent definition, so that", () => {
            const mdsl = `
                root {
                    sequence while(Allowed) entry(Entered, "sequence") {
                        action [Ok, 1]
                        selector {
                            action [Hold, "two"] exit(Left) until(Done, true, 3)
                            condition [Allowed, null]
                            branch [Sub]
                        }
                        repeat [2, 3] { wait [5, 10] }
                        retry { lotto [2, 1] { wait [3] wait } }
                    }
                }
                root [Sub] { flip { action [No, 4] } }
            `;

            // The same definition as the MDSL above, written the way that it would be by hand, without the empty arguments or false flags.
            const json: RootNodeDefinition[] = [
                {
                    type: "root",
                    child: {
                        type: "sequence",
                        while: { call: "Allowed" },
                        entry: { call: "Entered", args: ["sequence"] },
                        children: [
                            { type: "action", call: "Ok", args: [1] },
                            {
                                type: "selector",
                                children: [
                                    {
                                        type: "action",
                                        call: "Hold",
                                        args: ["two"],
                                        exit: { call: "Left" },
                                        until: { call: "Done", args: [true, 3] }
                                    },
                                    { type: "condition", call: "Allowed", args: [null] },
                                    { type: "branch", ref: "Sub" }
                                ]
                            },
                            { type: "repeat", iterations: [2, 3], child: { type: "wait", duration: [5, 10] } },
                            {
                                type: "retry",
                                child: {
                                    type: "lotto",
                                    weights: [2, 1],
                                    children: [{ type: "wait", duration: 3 }, { type: "wait" }]
                                }
                            }
                        ]
                    }
                },
                { type: "root", id: "Sub", child: { type: "flip", child: { type: "action", call: "No", args: [4] } } }
            ];

            const createFullAgent = () => ({
                ...createAgent(),
                Allowed: () => true,
                Done: () => false,
                Entered: () => {},
                Left: () => {}
            });

            const clone = <T>(value: T): T => JSON.parse(JSON.stringify(value));

            type Definition = string | RootNodeDefinition | RootNodeDefinition[];

            /**
             * Restore a snapshot taken from a tree built using the first definition to a tree built using the second.
             */
            function assertRestoreAccepted(from: Definition, to: Definition) {
                const original = new BehaviourTree(from, createFullAgent());
                original.step();

                const restored = new BehaviourTree(to, createFullAgent());
                restored.restore(takeStoredSnapshot(original));

                assert.strictEqual(restored.getState(), State.RUNNING);
                assert.deepEqual(getTreeNodeDetailsWithoutIds(restored), getTreeNodeDetailsWithoutIds(original));
            }

            it("an MDSL definition is restored to the equivalent JSON definition", () => {
                assertRestoreAccepted(mdsl, json);
            });

            it("a JSON definition is restored to the equivalent MDSL definition", () => {
                assertRestoreAccepted(json, mdsl);
            });

            it("the output of converting the MDSL definition to JSON is the same definition", () => {
                assertRestoreAccepted(mdsl, convertMDSLToJSON(mdsl));
                assertRestoreAccepted(convertMDSLToJSON(mdsl), json);
            });

            it("a JSON definition with the order of its properties changed is the same definition", () => {
                const reordered = JSON.parse(
                    JSON.stringify(json, (_, value) =>
                        value && typeof value === "object" && !Array.isArray(value)
                            ? Object.fromEntries(Object.entries(value).reverse())
                            : value
                    )
                );

                assertRestoreAccepted(json, reordered);
                assertRestoreAccepted(reordered, mdsl);
            });

            it("a JSON definition that is explicit about the defaults is the same definition", () => {
                const explicit = clone(json);
                (explicit[0].child as any).while.args = [];
                (explicit[0].child as any).while.succeedOnAbort = false;

                assertRestoreAccepted(mdsl, explicit);
                assertRestoreAccepted(explicit, json);
            });

            it("a definition with the sub-root nodes in a different order is the same definition", () => {
                assertRestoreAccepted(json, [json[1], json[0]]);
            });

            it("a single root node definition is the same definition as an array containing it", () => {
                const definition = "root { sequence { action [Ok, 1] action [Hold, 2] } }";

                assertRestoreAccepted(definition, convertMDSLToJSON(definition)[0]);
                assertRestoreAccepted(convertMDSLToJSON(definition)[0], definition);
            });

            it("a definition with different whitespace and comments is the same definition", () => {
                assertRestoreAccepted(
                    mdsl,
                    `root{sequence while(Allowed) entry(Entered,"sequence"){/* one */ action[Ok,1] selector{action[Hold,"two"] exit(Left) until(Done,true,3) condition[Allowed,null] branch[Sub]} repeat[2,3]{wait[5,10]} retry{lotto[2,1]{wait[3] wait}}}} root[Sub]{flip{action[No,4]}}`
                );
            });

            it("a definition that differs in a way that matters is not the same definition", () => {
                const changes: ((definition: RootNodeDefinition[]) => void)[] = [
                    (d) => ((d[1].child as any).child.args = [5]),
                    (d) => ((d[0].child as any).while.succeedOnAbort = true),
                    (d) => ((d[0].child as any).children[2].iterations = [2, 4]),
                    (d) => ((d[0].child as any).children[3].child.weights = [1, 2]),
                    (d) => ((d[0].child as any).children[0].args = ["1"]),
                    (d) => ((d[0].child as any).children[1].children[0].args = [{ $: "two" }])
                ];

                for (const change of changes) {
                    const changed = clone(json);
                    change(changed);

                    const original = new BehaviourTree(json, createFullAgent());
                    const restored = new BehaviourTree(changed, createFullAgent());

                    assert.throws(
                        () => restored.restore(takeStoredSnapshot(original)),
                        Error,
                        /snapshot does not match the .*definition/
                    );
                }
            });
        });
    });

    describe("restores the counts of", () => {
        /**
         * Step the tree until it is no longer running, returning the number of steps that it took.
         */
        function stepToCompletion(tree: BehaviourTree): number {
            let steps = 0;

            do {
                tree.step();
                steps++;
            } while (tree.isRunning() && steps < 100);

            return steps;
        }

        /**
         * Count the number of calls in a log of agent function calls.
         */
        const countCalls = (log: string[], call: string) => log.filter((entry) => entry === call).length;

        describe("a repeat node, which will make the remaining iterations only", () => {
            it("when it has an explicit iteration count", () => {
                const definition = "root { repeat [4] { action [Ok, 1] } }";

                const originalAgent = createAgent();
                const original = new BehaviourTree(definition, originalAgent);
                original.step();
                original.step();

                const restoredAgent = createAgent();
                const restored = new BehaviourTree(definition, restoredAgent);
                restored.restore(takeStoredSnapshot(original));

                stepToCompletion(original);
                stepToCompletion(restored);

                assert.strictEqual(countCalls(originalAgent.log, "Ok:1"), 4);
                assert.strictEqual(countCalls(restoredAgent.log, "Ok:1"), 2);
                assert.strictEqual(restored.getState(), State.SUCCEEDED);
                assert.deepEqual(getTreeNodeDetailsWithoutIds(restored), getTreeNodeDetailsWithoutIds(original));
            });

            it("when it has a randomly picked iteration count", () => {
                const definition = "root { repeat [2, 5] { action [Ok, 1] } }";

                // This random function will pick the maximum of 5 iterations.
                const originalAgent = createAgent();
                const original = new BehaviourTree(definition, originalAgent, { random: () => 0.99 });
                original.step();
                original.step();

                // This random function would pick the minimum of 2 iterations, but should never be called.
                const random = sinon.stub().returns(0);
                const restoredAgent = createAgent();
                const restored = new BehaviourTree(definition, restoredAgent, { random });
                restored.restore(takeStoredSnapshot(original));

                stepToCompletion(original);
                stepToCompletion(restored);

                assert.strictEqual(countCalls(originalAgent.log, "Ok:1"), 5);
                assert.strictEqual(countCalls(restoredAgent.log, "Ok:1"), 3);
                assert.strictEqual(random.callCount, 0);
            });

            it("when it repeats indefinitely", () => {
                const definition = "root { repeat { action [Ok, 1] } }";

                const original = new BehaviourTree(definition, createAgent());
                original.step();

                const agent = createAgent();
                const restored = new BehaviourTree(definition, agent);
                restored.restore(takeStoredSnapshot(original));

                for (let step = 0; step < 10; step++) {
                    restored.step();
                }

                assert.strictEqual(countCalls(agent.log, "Ok:1"), 10);
                assert.strictEqual(restored.getState(), State.RUNNING);
            });

            it("and picks a new random iteration count for the run after a finished one", () => {
                const definition = "root { repeat [2, 5] { action [Ok, 1] } }";

                const original = new BehaviourTree(definition, createAgent(), { random: () => 0.99 });
                stepToCompletion(original);

                const agent = createAgent();
                const restored = new BehaviourTree(definition, agent, { random: () => 0 });
                restored.restore(takeStoredSnapshot(original));

                assert.strictEqual(restored.getState(), State.SUCCEEDED);

                stepToCompletion(restored);

                assert.strictEqual(countCalls(agent.log, "Ok:1"), 2);
            });
        });

        describe("a retry node, which will make the remaining attempts only", () => {
            it("when it has an explicit attempt count", () => {
                const definition = "root { retry [4] { action [No, 1] } }";

                const originalAgent = createAgent();
                const original = new BehaviourTree(definition, originalAgent);
                original.step();
                original.step();

                const restoredAgent = createAgent();
                const restored = new BehaviourTree(definition, restoredAgent);
                restored.restore(takeStoredSnapshot(original));

                stepToCompletion(original);
                stepToCompletion(restored);

                assert.strictEqual(countCalls(originalAgent.log, "No:1"), 4);
                assert.strictEqual(countCalls(restoredAgent.log, "No:1"), 2);
                assert.strictEqual(restored.getState(), State.FAILED);
                assert.deepEqual(getTreeNodeDetailsWithoutIds(restored), getTreeNodeDetailsWithoutIds(original));
            });

            it("when it has a randomly picked attempt count", () => {
                const definition = "root { retry [2, 5] { action [No, 1] } }";

                // This random function will pick the maximum of 5 attempts.
                const originalAgent = createAgent();
                const original = new BehaviourTree(definition, originalAgent, { random: () => 0.99 });
                original.step();
                original.step();

                // This random function would pick the minimum of 2 attempts, but should never be called.
                const random = sinon.stub().returns(0);
                const restoredAgent = createAgent();
                const restored = new BehaviourTree(definition, restoredAgent, { random });
                restored.restore(takeStoredSnapshot(original));

                stepToCompletion(original);
                stepToCompletion(restored);

                assert.strictEqual(countCalls(originalAgent.log, "No:1"), 5);
                assert.strictEqual(countCalls(restoredAgent.log, "No:1"), 3);
                assert.strictEqual(random.callCount, 0);
            });

            it("and picks a new random attempt count for the run after a finished one", () => {
                const definition = "root { retry [2, 5] { action [No, 1] } }";

                const original = new BehaviourTree(definition, createAgent(), { random: () => 0.99 });
                stepToCompletion(original);

                const agent = createAgent();
                const restored = new BehaviourTree(definition, agent, { random: () => 0 });
                restored.restore(takeStoredSnapshot(original));

                assert.strictEqual(restored.getState(), State.FAILED);

                stepToCompletion(restored);

                assert.strictEqual(countCalls(agent.log, "No:1"), 2);
            });
        });
    });

    describe("restores the child picked by a lotto node, so that", () => {
        const definition = "root { lotto [1, 1, 1] { action [Hold, 1] action [Hold, 2] action [Hold, 3] } }";

        /**
         * Find the single child action that a lotto node picked from the agent function call log.
         */
        function getPickedCall(log: string[]): string {
            const picked = Array.from(new Set(log));

            assert.lengthOf(picked, 1);

            return picked[0];
        }

        it("it carries on with the same child rather than picking again", () => {
            const originalAgent = createAgent();
            const original = new BehaviourTree(definition, originalAgent, { random: () => 0 });
            original.step();

            const pickedByOriginal = getPickedCall(originalAgent.log);

            // The restored tree has a random function that would pick the last child, but it should never be called.
            const random = sinon.stub().returns(0.99);
            const restoredAgent = createAgent();
            const restored = new BehaviourTree(definition, restoredAgent, { random });
            restored.restore(takeStoredSnapshot(original));

            restored.step();
            restoredAgent.released = true;
            restored.step();

            assert.strictEqual(getPickedCall(restoredAgent.log), pickedByOriginal);
            assert.strictEqual(restored.getState(), State.SUCCEEDED);
            assert.strictEqual(random.callCount, 0);
            assert.deepEqual(getTreeNodeDetailsWithoutIds(restored).children[0].state, State.SUCCEEDED);
        });

        it("it picks a child again for the run after a finished one", () => {
            const originalAgent = createAgent();
            const original = new BehaviourTree(definition, originalAgent, { random: () => 0 });
            originalAgent.released = true;
            original.step();

            const pickedByOriginal = getPickedCall(originalAgent.log);

            const restoredAgent = createAgent();
            const restored = new BehaviourTree(definition, restoredAgent, { random: () => 0.99 });
            restored.restore(takeStoredSnapshot(original));

            assert.strictEqual(restored.getState(), State.SUCCEEDED);

            restoredAgent.released = true;
            restored.step();

            assert.notStrictEqual(getPickedCall(restoredAgent.log), pickedByOriginal);
        });

        it("it can be restored if a failed guard resolved it before it picked a child", () => {
            const guardedDefinition = "root { lotto while(Never) { action [Hold, 1] action [Hold, 2] } }";
            const guardedAgent = { ...createAgent(), Never: () => false };
            const original = new BehaviourTree(guardedDefinition, guardedAgent);
            original.step();

            assert.strictEqual(original.getState(), State.FAILED);

            const restored = new BehaviourTree(guardedDefinition, { ...createAgent(), Never: () => false });
            restored.restore(takeStoredSnapshot(original));

            assert.deepEqual(getTreeNodeDetailsWithoutIds(restored), getTreeNodeDetailsWithoutIds(original));
        });

        it("it throws an error if the snapshot of a lotto node that picked a child has no valid child index", () => {
            const original = new BehaviourTree(definition, createAgent());
            original.step();

            const snapshot = takeStoredSnapshot(original) as any;
            snapshot.root.children[0].selectedChildIndex = 3;

            const restored = new BehaviourTree(definition, createAgent());

            assert.throws(
                () => restored.restore(snapshot),
                Error,
                "root.children[0]: invalid selected child index '3'"
            );
        });
    });

    describe("restores the timing of a wait node, so that", () => {
        let clock: SinonFakeTimers;

        beforeEach(() => {
            clock = sinon.useFakeTimers();
        });

        afterEach(() => {
            clock.restore();
        });

        const getWaitState = (tree: BehaviourTree) => getTreeNodeDetailsWithoutIds(tree).children[0].state;

        describe("using the clock", () => {
            it("it only waits for the remaining time, and not for the time that passed while it was stored", () => {
                const definition = "root { wait [1000] }";

                const original = new BehaviourTree(definition, {});
                original.step();
                clock.tick(400);
                original.step();

                const snapshot = takeStoredSnapshot(original);

                // Plenty of time passes before the snapshot is restored, and it should not count towards the wait.
                clock.tick(100000);

                const restored = new BehaviourTree(definition, {});
                restored.restore(snapshot);
                restored.step();

                assert.strictEqual(getWaitState(restored), State.RUNNING);

                clock.tick(599);
                restored.step();

                assert.strictEqual(getWaitState(restored), State.RUNNING);

                clock.tick(1);
                restored.step();

                assert.strictEqual(getWaitState(restored), State.SUCCEEDED);
                assert.strictEqual(restored.getState(), State.SUCCEEDED);
            });

            it("it counts the time that passed since the last step up to when the snapshot was taken", () => {
                const definition = "root { wait [1000] }";

                const original = new BehaviourTree(definition, {});
                original.step();
                clock.tick(900);

                const snapshot = takeStoredSnapshot(original);

                clock.tick(100000);

                const restored = new BehaviourTree(definition, {});
                restored.restore(snapshot);
                restored.step();

                assert.strictEqual(getWaitState(restored), State.RUNNING);

                clock.tick(99);
                restored.step();

                assert.strictEqual(getWaitState(restored), State.RUNNING);

                clock.tick(1);
                restored.step();

                assert.strictEqual(getWaitState(restored), State.SUCCEEDED);
            });

            it("it can be restored to a tree that has been stepped since", () => {
                const definition = "root { wait [1000] }";

                const tree = new BehaviourTree(definition, {});
                tree.step();
                clock.tick(300);

                const snapshot = takeStoredSnapshot(tree);

                clock.tick(700);
                tree.step();

                assert.strictEqual(tree.getState(), State.SUCCEEDED);

                clock.tick(5000);
                tree.restore(snapshot);
                tree.step();

                assert.strictEqual(tree.getState(), State.RUNNING);

                clock.tick(699);
                tree.step();

                assert.strictEqual(tree.getState(), State.RUNNING);

                clock.tick(1);
                tree.step();

                assert.strictEqual(tree.getState(), State.SUCCEEDED);
            });

            it("it keeps the randomly picked duration", () => {
                const definition = "root { wait [500, 1000] }";

                // This random function will pick the maximum duration of 1000.
                const original = new BehaviourTree(definition, {}, { random: () => 0.999 });
                original.step();
                clock.tick(200);

                const snapshot = takeStoredSnapshot(original);

                // This random function would pick the minimum duration of 500, but should never be called.
                const random = sinon.stub().returns(0);
                const restored = new BehaviourTree(definition, {}, { random });

                clock.tick(100000);
                restored.restore(snapshot);
                restored.step();
                clock.tick(799);
                restored.step();

                assert.strictEqual(getWaitState(restored), State.RUNNING);

                clock.tick(1);
                restored.step();

                assert.strictEqual(getWaitState(restored), State.SUCCEEDED);
                assert.strictEqual(random.callCount, 0);
            });

            it("it carries on waiting indefinitely if there is no duration", () => {
                const definition = "root { wait }";

                const original = new BehaviourTree(definition, {});
                original.step();
                clock.tick(1000);

                const restored = new BehaviourTree(definition, {});
                restored.restore(takeStoredSnapshot(original));

                clock.tick(100000000);
                restored.step();

                assert.strictEqual(getWaitState(restored), State.RUNNING);
            });

            it("it waits for the full duration again for the run after a finished one", () => {
                const definition = "root { wait [1000] }";

                const original = new BehaviourTree(definition, {});
                original.step();
                clock.tick(1000);
                original.step();

                assert.strictEqual(original.getState(), State.SUCCEEDED);

                const restored = new BehaviourTree(definition, {});
                restored.restore(takeStoredSnapshot(original));

                assert.strictEqual(restored.getState(), State.SUCCEEDED);

                clock.tick(5000);
                restored.step();

                assert.strictEqual(restored.getState(), State.RUNNING);

                clock.tick(999);
                restored.step();

                assert.strictEqual(restored.getState(), State.RUNNING);

                clock.tick(1);
                restored.step();

                assert.strictEqual(restored.getState(), State.SUCCEEDED);
            });
        });

        describe("using the getDeltaTime option", () => {
            it("it only waits for the remaining time, and not for the time that passed while it was stored", () => {
                const definition = "root { wait [1000] }";
                const getDeltaTime = () => 0.1;

                const original = new BehaviourTree(definition, {}, { getDeltaTime });

                // The wait node has waited for 400ms after four steps.
                for (let step = 0; step < 4; step++) {
                    original.step();
                }

                const snapshot = takeStoredSnapshot(original);

                clock.tick(100000);

                const restored = new BehaviourTree(definition, {}, { getDeltaTime });
                restored.restore(snapshot);

                // Another five steps takes it to 900ms, a sixth to the full 1000ms.
                for (let step = 0; step < 5; step++) {
                    restored.step();
                }

                assert.strictEqual(getWaitState(restored), State.RUNNING);

                restored.step();

                assert.strictEqual(getWaitState(restored), State.SUCCEEDED);
            });

            it("it can be restored to a tree that uses the clock instead", () => {
                const definition = "root { wait [1000] }";

                const original = new BehaviourTree(definition, {}, { getDeltaTime: () => 0.4 });
                original.step();
                original.step();

                const snapshot = takeStoredSnapshot(original);

                clock.tick(100000);

                const restored = new BehaviourTree(definition, {});
                restored.restore(snapshot);
                restored.step();

                assert.strictEqual(getWaitState(restored), State.RUNNING);

                clock.tick(199);
                restored.step();

                assert.strictEqual(getWaitState(restored), State.RUNNING);

                clock.tick(1);
                restored.step();

                assert.strictEqual(getWaitState(restored), State.SUCCEEDED);
            });
        });

        it("it throws an error if the snapshot of a running wait node has invalid timing", () => {
            const definition = "root { wait [1000] }";

            const original = new BehaviourTree(definition, {});
            original.step();

            const snapshot = takeStoredSnapshot(original) as any;
            snapshot.root.children[0].waitedDuration = "a while";

            const restored = new BehaviourTree(definition, {});

            assert.throws(
                () => restored.restore(snapshot),
                Error,
                "root.children[0]: invalid waited duration 'a while'"
            );
        });
    });

    describe("restores an action node that returned a promise, so that", () => {
        /**
         * Create an agent with an action function that returns a promise that is under the control of the test.
         */
        function createAsyncAgent() {
            const agent = {
                calls: 0,
                entered: 0,
                promises: [] as { resolve: (value: any) => void; reject: (reason: any) => void }[],
                Entered() {
                    agent.entered++;
                },
                Ok() {
                    return State.SUCCEEDED;
                },
                Async() {
                    agent.calls++;

                    return new Promise((resolve, reject) => agent.promises.push({ resolve, reject }));
                }
            };

            return agent;
        }

        /**
         * Wait for any settled promises to have their results handled.
         */
        const flushPromises = () => new Promise((resolve) => setImmediate(resolve));

        const definition = "root { action [Async] }";

        it("a pending promise, which can't be stored, is replaced by calling the action function again", async () => {
            const originalAgent = createAsyncAgent();
            const original = new BehaviourTree(definition, originalAgent);
            original.step();

            const snapshot = takeStoredSnapshot(original);

            const restoredAgent = createAsyncAgent();
            const restored = new BehaviourTree(definition, restoredAgent);
            restored.restore(snapshot);

            assert.strictEqual(restored.getState(), State.RUNNING);
            assert.strictEqual(restoredAgent.calls, 0);

            restored.step();
            restored.step();

            // The action function is called once to replace the lost promise, and then not again while that is pending.
            assert.strictEqual(restoredAgent.calls, 1);
            assert.strictEqual(restored.getState(), State.RUNNING);

            restoredAgent.promises[0].resolve(State.SUCCEEDED);
            await flushPromises();
            restored.step();

            assert.strictEqual(restored.getState(), State.SUCCEEDED);
        });

        it("a pending promise is stored as an action that has not started", () => {
            const original = new BehaviourTree(definition, createAsyncAgent());
            original.step();

            const snapshot = takeStoredSnapshot(original);

            assert.strictEqual(snapshot.root.state, State.RUNNING);
            assert.strictEqual(snapshot.root.children![0].state, State.READY);

            const restored = new BehaviourTree(definition, createAsyncAgent());
            restored.restore(snapshot);

            const { state, children } = getTreeNodeDetailsWithoutIds(restored);

            assert.strictEqual(state, State.RUNNING);
            assert.strictEqual(children![0].state, State.READY);
        });

        it("a pending promise does not change the state of the tree it was stored from", () => {
            const agent = createAsyncAgent();
            const tree = new BehaviourTree(definition, agent);
            tree.step();

            const detailsBefore = getTreeNodeDetailsWithoutIds(tree);

            tree.snapshot();
            tree.step();

            assert.deepEqual(getTreeNodeDetailsWithoutIds(tree), detailsBefore);
            assert.strictEqual(agent.calls, 1);
        });

        it("an action that has not started will have its entry callback called again with its action function", () => {
            const entryDefinition = "root { action [Async] entry(Entered) }";

            const originalAgent = createAsyncAgent();
            const original = new BehaviourTree(entryDefinition, originalAgent);
            original.step();

            const restoredAgent = createAsyncAgent();
            const restored = new BehaviourTree(entryDefinition, restoredAgent);
            restored.restore(takeStoredSnapshot(original));

            assert.strictEqual(originalAgent.entered, 1);
            assert.strictEqual(restoredAgent.entered, 0);

            restored.step();
            restored.step();

            assert.strictEqual(restoredAgent.entered, 1);
            assert.strictEqual(restoredAgent.calls, 1);
        });

        it("an action that is running without a promise stays running", () => {
            const entryDefinition = "root { action [Hold] entry(Entered) }";
            const agent = { ...createAsyncAgent(), Hold: () => State.RUNNING };

            const original = new BehaviourTree(entryDefinition, agent);
            original.step();

            const snapshot = takeStoredSnapshot(original);

            assert.strictEqual(snapshot.root.children![0].state, State.RUNNING);

            const restoredAgent = { ...createAsyncAgent(), Hold: () => State.RUNNING };
            const restored = new BehaviourTree(entryDefinition, restoredAgent);
            restored.restore(snapshot);
            restored.step();

            assert.strictEqual(restoredAgent.entered, 0);
        });

        it("an action that has not started is not running, so its exit callback is not called if it is aborted", () => {
            const guardDefinition = "root { sequence while(Allowed) { action [Async] exit(Left) } }";
            const createGuardAgent = () => ({
                ...createAsyncAgent(),
                allowed: true,
                lefts: 0,
                Allowed() {
                    return this.allowed;
                },
                Left() {
                    this.lefts++;
                }
            });

            const originalAgent = createGuardAgent();
            const original = new BehaviourTree(guardDefinition, originalAgent);
            original.step();

            const restoredAgent = createGuardAgent();
            const restored = new BehaviourTree(guardDefinition, restoredAgent);
            restored.restore(takeStoredSnapshot(original));

            originalAgent.allowed = false;
            restoredAgent.allowed = false;
            original.step();
            restored.step();

            assert.strictEqual(originalAgent.lefts, 1);
            assert.strictEqual(restoredAgent.lefts, 0);
            assert.strictEqual(restored.getState(), original.getState());
        });

        describe("an action that has not started carries on as part of", () => {
            const definitions: { [name: string]: string } = {
                sequence: "root { sequence { action [Ok] action [Async] action [Ok] } }",
                selector: "root { selector { action [Async] action [Ok] } }",
                parallel: "root { parallel { action [Async] action [Ok] } }",
                race: "root { race { action [Async] action [Async] } }",
                all: "root { all { action [Async] action [Ok] } }",
                lotto: "root { lotto { action [Async] action [Ok] } }",
                repeat: "root { repeat [2] { action [Async] } }",
                retry: "root { retry [2] { action [Async] } }",
                flip: "root { flip { action [Async] } }",
                "a nested tree":
                    "root { sequence { selector { sequence { action [Ok] action [Async] } } action [Ok] } }"
            };

            for (const [name, treeDefinition] of Object.entries(definitions)) {
                it(`${name} nodes, which behave as they would have if the promise had been kept`, async () => {
                    const originalAgent = createAsyncAgent();
                    const original = new BehaviourTree(treeDefinition, originalAgent, { random: () => 0 });
                    original.step();

                    const restoredAgent = createAsyncAgent();
                    const restored = new BehaviourTree(treeDefinition, restoredAgent, { random: () => 0 });
                    restored.restore(takeStoredSnapshot(original));
                    restored.step();

                    assert.strictEqual(restoredAgent.calls, originalAgent.calls);

                    for (const { agent, tree } of [
                        { agent: originalAgent, tree: original },
                        { agent: restoredAgent, tree: restored }
                    ]) {
                        agent.promises.forEach(({ resolve }) => resolve(State.SUCCEEDED));
                        await flushPromises();
                        tree.step();
                    }

                    assert.strictEqual(restored.getState(), original.getState());
                    assert.deepEqual(getTreeNodeDetailsWithoutIds(restored), getTreeNodeDetailsWithoutIds(original));
                });
            }
        });

        it("a promise that resolved but was not yet handled by a step is not lost", async () => {
            const originalAgent = createAsyncAgent();
            const original = new BehaviourTree(definition, originalAgent);
            original.step();

            originalAgent.promises[0].resolve(State.FAILED);
            await flushPromises();

            const restoredAgent = createAsyncAgent();
            const restored = new BehaviourTree(definition, restoredAgent);
            restored.restore(takeStoredSnapshot(original));
            restored.step();

            assert.strictEqual(restoredAgent.calls, 0);
            assert.strictEqual(restored.getState(), State.FAILED);
        });

        it("a promise that rejected but was not yet handled by a step is not lost", async () => {
            const originalAgent = createAsyncAgent();
            const original = new BehaviourTree(definition, originalAgent);
            original.step();

            originalAgent.promises[0].reject(new Error("some-error"));
            await flushPromises();

            const restoredAgent = createAsyncAgent();
            const restored = new BehaviourTree(definition, restoredAgent);
            restored.restore(takeStoredSnapshot(original));

            assert.throws(
                () => restored.step(),
                Error,
                "error stepping tree: action function 'Async' promise rejected with 'Error: some-error'"
            );
            assert.strictEqual(restoredAgent.calls, 0);
        });

        it("a promise that rejected with a reason that can't be converted to a string doesn't stop a snapshot being taken", async () => {
            const originalAgent = createAsyncAgent();
            const original = new BehaviourTree(definition, originalAgent);
            original.step();

            originalAgent.promises[0].reject(Object.create(null));
            await flushPromises();

            const snapshot = takeStoredSnapshot(original);

            const restored = new BehaviourTree(definition, createAsyncAgent());
            restored.restore(snapshot);

            assert.throws(() => restored.step(), Error, "action function 'Async' promise rejected");
        });

        it("a promise that resolved with an invalid value still causes an error", async () => {
            const originalAgent = createAsyncAgent();
            const original = new BehaviourTree(definition, originalAgent);
            original.step();

            originalAgent.promises[0].resolve({ not: "a state" });
            await flushPromises();

            const restored = new BehaviourTree(definition, createAsyncAgent());
            restored.restore(takeStoredSnapshot(original));

            assert.throws(
                () => restored.step(),
                Error,
                "action node promise resolved with an invalid value, expected a State.SUCCEEDED or State.FAILED value to be returned"
            );
        });

        it("a promise from before the restore can't change the state afterwards", async () => {
            const agent = createAsyncAgent();
            const tree = new BehaviourTree(definition, agent);
            tree.step();

            tree.restore(takeStoredSnapshot(tree));
            tree.step();

            assert.strictEqual(agent.calls, 2);

            // The promise from before the restore settles, but it belongs to a run that has been abandoned.
            agent.promises[0].resolve(State.SUCCEEDED);
            await flushPromises();
            tree.step();

            assert.strictEqual(tree.getState(), State.RUNNING);
            assert.strictEqual(agent.calls, 2);
        });

        it("a promise from before a reset can't change the state afterwards", async () => {
            const agent = createAsyncAgent();
            const tree = new BehaviourTree(definition, agent);
            tree.step();

            tree.reset();
            tree.step();

            agent.promises[0].resolve(State.SUCCEEDED);
            await flushPromises();
            tree.step();

            assert.strictEqual(tree.getState(), State.RUNNING);
        });
    });

    describe("keeps a snapshot independent of the trees, so that", () => {
        let clock: SinonFakeTimers;

        beforeEach(() => {
            // Only the date is faked as the tests wait on real promises.
            clock = sinon.useFakeTimers({ toFake: ["Date"] });
        });

        afterEach(() => {
            clock.restore();
        });

        /**
         * Create an agent with an action that returns a promise that has already settled, and one that never does.
         */
        function createPromiseAgent() {
            return {
                ...createAgent(),
                Resolved: () => Promise.resolve(State.SUCCEEDED),
                Rejected: () => Promise.reject(new Error("failed")),
                Pending: () => new Promise<State>(() => {})
            };
        }

        const definitions: { [name: string]: string } = {
            composites: "root { sequence { action [Ok, 1] parallel { action [Hold, 2] action [Hold, 3] } } }",
            lotto: "root { lotto { action [Hold, 1] action [Hold, 2] action [Hold, 3] } }",
            repeat: "root { repeat [3] { sequence { action [Ok, 1] action [Hold, 2] } } }",
            retry: "root { retry [3] { sequence { action [Ok, 1] action [No, 2] } } }",
            wait: "root { sequence { wait [1000] action [Ok, 1] } }",
            "wait using a random duration": "root { sequence { wait [100, 1000] action [Ok, 1] } }",
            "a resolved promise": "root { sequence { action [Resolved] action [Ok, 1] } }",
            "a rejected promise": "root { action [Rejected] }",
            "a pending promise": "root { action [Pending] }"
        };

        for (const [name, definition] of Object.entries(definitions)) {
            it(`stepping the tree does not change it, restoring it does not change it and a restored tree gives the same snapshot, using ${name}`, async () => {
                const tree = new BehaviourTree(definition, createPromiseAgent());

                for (let step = 0; step < 4; step++) {
                    try {
                        tree.step();
                    } catch {
                        // An action that is rejected throws when its result is handled by a step.
                    }

                    await new Promise((resolve) => setImmediate(resolve));
                    clock.tick(300);

                    const snapshot = tree.snapshot();
                    const stored = JSON.parse(JSON.stringify(snapshot));

                    // Carry on stepping the tree that the snapshot was taken from.
                    for (let more = 0; more < 3; more++) {
                        try {
                            tree.step();
                        } catch {
                            // As above.
                        }

                        clock.tick(300);
                    }

                    assert.deepEqual(snapshot, stored, "stepping the original tree changed the snapshot");

                    const restored = new BehaviourTree(definition, createPromiseAgent());

                    // Give the tree some state to be replaced by the restore.
                    try {
                        restored.step();
                    } catch {
                        // As above.
                    }

                    restored.restore(snapshot);

                    assert.deepEqual(
                        JSON.parse(JSON.stringify(restored.snapshot())),
                        stored,
                        "a snapshot taken after a restore is not the one that was restored"
                    );

                    for (let more = 0; more < 3; more++) {
                        try {
                            restored.step();
                        } catch {
                            // As above.
                        }

                        await new Promise((resolve) => setImmediate(resolve));
                        clock.tick(300);
                    }

                    assert.deepEqual(snapshot, stored, "stepping the restored tree changed the snapshot");

                    // Start the original tree again from where it was, ready for the next snapshot.
                    tree.restore(snapshot);
                }
            });
        }
    });
});
