import { assert } from "chai";
import sinon, { SinonFakeTimers } from "sinon";

import { BehaviourTree, State } from "../src/index";

import { getTreeNodeDetailsWithoutIds } from "./TestUtilities";

/**
 * A definition that uses every type of node, along with guards and callbacks, with plenty of random choices to make.
 */
const definition = `
root {
    sequence entry(Log, "sequence-entry") {
        action [Work, 1] entry(Log, "work-1-entry") step(Log, "work-1-step") exit(LogExit, "work-1-exit")
        parallel {
            repeat [2, 4] {
                sequence {
                    action [Work, 2]
                    wait [150, 450]
                }
            }
            retry [2, 4] {
                action [Flaky, 3]
            }
        }
        lotto [2, 1, 1] {
            action [Work, 4]
            sequence {
                action [Work, 5]
                wait [100, 300]
            }
            action [Flaky, 6]
        }
        race exit(LogExit, "race-exit") {
            wait [300]
            repeat {
                sequence {
                    action [Work, 7] exit(LogExit, "work-7-exit")
                    action [Stuck] exit(LogExit, "stuck-exit")
                }
            }
        }
        all {
            action [Work, 8]
            flip {
                action [Flaky, 9]
            }
        }
        selector {
            sequence while(Allowed) {
                repeat [3] {
                    action [Work, 10]
                }
            }
            action [Work, 11]
        }
        succeed {
            action [Flaky, 12]
        }
        fail {
            wait
            until(Done)
        }
    }
}`;

type Counts = { [name: string]: number };

/**
 * Create an agent that logs everything that is done to it. Work alternates between running and succeeding, and Flaky
 * mostly fails. The counts of the calls it has had are all of the state that the agent has.
 */
function createAgent(counts: Counts = {}) {
    const count = (name: string) => (counts[name] = (counts[name] ?? 0) + 1);

    const agent = {
        counts,
        log: [] as string[],
        Work(label: number) {
            const n = count(`Work:${label}`);
            agent.log.push(`Work:${label}:${n}`);
            return n % 2 === 0 ? State.SUCCEEDED : State.RUNNING;
        },
        Flaky(label: number) {
            const n = count(`Flaky:${label}`);
            agent.log.push(`Flaky:${label}:${n}`);
            return n % 2 === 0 ? State.SUCCEEDED : State.FAILED;
        },
        Stuck() {
            agent.log.push(`Stuck:${count("Stuck")}`);
            return State.RUNNING;
        },
        Allowed() {
            const n = count("Allowed");
            agent.log.push(`Allowed:${n}`);
            return n % 11 !== 0;
        },
        Done() {
            const n = count("Done");
            agent.log.push(`Done:${n}`);
            return n % 7 === 0;
        },
        Log(label: string) {
            agent.log.push(`Log:${label}`);
        },
        LogExit({ succeeded, aborted }: { succeeded: boolean; aborted: boolean }, label: string) {
            agent.log.push(`LogExit:${label}:${succeeded}:${aborted}`);
        }
    };

    return agent;
}

/**
 * Create a repeatable sequence of pseudo-random numbers, starting from the specified point in the sequence.
 */
function createRandom(start: number = 0) {
    let index = start;

    const random = () => {
        const value = Math.abs(Math.sin(++index * 12.9898) * 43758.5453);
        return value - Math.floor(value);
    };

    return { random, getIndex: () => index };
}

type StepRecord = {
    log: string[];
    state: State;
    details: any;
};

describe("A BehaviourTree restored from a snapshot", () => {
    let clock: SinonFakeTimers;

    beforeEach(() => {
        clock = sinon.useFakeTimers();
    });

    afterEach(() => {
        clock.restore();
    });

    const STEPS = 160;

    for (const timing of ["getDeltaTime option", "clock"]) {
        describe(`using the ${timing}`, () => {
            const getOptions = (random: () => number) =>
                timing === "clock" ? { random } : { random, getDeltaTime: () => 0.1 };

            it("behaves exactly as the tree that the snapshot was taken from would have", () => {
                const agent = createAgent();
                const { random, getIndex } = createRandom();
                const tree = new BehaviourTree(definition, agent, getOptions(random));

                type Moment = {
                    snapshot: string;
                    counts: Counts;
                    randomIndex: number;
                    time: number;
                    detailsBefore: any;
                    steps: StepRecord[];
                };

                const moments: Moment[] = [];
                const allSteps: StepRecord[] = [];

                for (let step = 0; step < STEPS; step++) {
                    // Some time passes between steps, and a snapshot is taken part of the way through it.
                    clock.tick(50);

                    moments.push({
                        snapshot: JSON.stringify(tree.snapshot()),
                        counts: { ...agent.counts },
                        randomIndex: getIndex(),
                        time: clock.now,
                        detailsBefore: getTreeNodeDetailsWithoutIds(tree),
                        steps: allSteps
                    });

                    clock.tick(50);

                    agent.log.length = 0;
                    tree.step();

                    allSteps.push({
                        log: [...agent.log],
                        state: tree.getState(),
                        details: getTreeNodeDetailsWithoutIds(tree)
                    });
                }
                // Make sure that the tree went through plenty to make this worthwhile.
                assert.isAbove(allSteps.filter(({ state }) => state === State.FAILED).length, 1);
                assert.isAbove(allSteps.filter(({ log }) => log.includes("LogExit:stuck-exit:false:true")).length, 0);

                moments.forEach((moment, momentIndex) => {
                    // Restore the snapshot to a brand new tree that has a clock and random number generator that carry on from the same place.
                    clock.setSystemTime(moment.time);

                    const restoredAgent = createAgent({ ...moment.counts });
                    const restoredRandom = createRandom(moment.randomIndex);
                    const restored = new BehaviourTree(definition, restoredAgent, getOptions(restoredRandom.random));

                    restored.restore(JSON.parse(moment.snapshot));

                    assert.deepEqual(
                        getTreeNodeDetailsWithoutIds(restored),
                        moment.detailsBefore,
                        `node states after restore at step ${momentIndex}`
                    );
                    assert.strictEqual(restoredRandom.getIndex(), moment.randomIndex);
                    assert.deepEqual(restoredAgent.log, []);

                    for (let step = momentIndex; step < STEPS; step++) {
                        // The snapshot was taken half way through the time that passes before the first step.
                        clock.tick(step === momentIndex ? 50 : 100);

                        restoredAgent.log.length = 0;
                        restored.step();

                        const expected = allSteps[step];
                        const message = `step ${step} after restoring at step ${momentIndex}`;

                        assert.deepEqual(restoredAgent.log, expected.log, `agent calls for ${message}`);
                        assert.strictEqual(restored.getState(), expected.state, `tree state for ${message}`);
                        assert.deepEqual(
                            getTreeNodeDetailsWithoutIds(restored),
                            expected.details,
                            `node states for ${message}`
                        );
                    }
                });
            });
        });
    }
});
