import { BehaviourTree, NodeDetails } from "../src/index";
import { AnyNodeDefinition } from "../src/BehaviourTreeDefinition";

/**
 * Get the details for the specified node type and caption from the given behaviour tree instance, or error if it doesn't exist.
 * @param tree The behaviour tree instance.
 * @param type The type of the node to get.
 * @param name The name of the node to get.
 * @returns The details for the specified node type and caption from the given behaviour tree instance.
 */
export function findNode(tree: BehaviourTree, type: AnyNodeDefinition["type"], name?: string): NodeDetails {
    const findNodeFromDetails = (node: NodeDetails): NodeDetails | null => {
        if (node.type === type && (!name || node.name === name)) {
            return node;
        }

        return (node.children ?? []).map(findNodeFromDetails).find((childNode) => !!childNode) ?? null;
    };

    const targetNode = findNodeFromDetails(tree.getTreeNodeDetails());

    if (!targetNode) {
        throw new Error(
            name
                ? `cannot find flattened tree node with type: '${type}' caption: '${name}'`
                : `cannot find flattened tree node with type: '${type}'`
        );
    }

    return targetNode;
}

/**
 * Get the details of every node in the given behaviour tree instance with the randomly generated node identifiers removed,
 * so that the details of two different tree instances built from the same definition can be compared.
 * @param tree The behaviour tree instance.
 * @returns The details of every node in the given behaviour tree instance, without node identifiers.
 */
export function getTreeNodeDetailsWithoutIds(tree: BehaviourTree): any {
    const removeIds = ({ id, children, ...details }: NodeDetails): any => ({
        ...details,
        ...(children ? { children: children.map(removeIds) } : {})
    });

    return removeIds(tree.getTreeNodeDetails());
}
