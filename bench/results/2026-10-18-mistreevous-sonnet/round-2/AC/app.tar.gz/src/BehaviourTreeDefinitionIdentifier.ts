import { RootNodeDefinition } from "./BehaviourTreeDefinition";

/**
 * The names of the properties of a node definition that define an attribute.
 */
const ATTRIBUTE_PROPERTIES = ["while", "until", "entry", "step", "exit"];

/**
 * Gets a copy of an attribute definition with the values that are assumed when a property is left out, so that these can be left out or spelled out.
 * @param attribute The attribute definition.
 * @param isGuard Whether the attribute is a guard.
 * @returns The attribute definition with its default values.
 */
function withAttributeDefaults(attribute: any, isGuard: boolean): any {
    return {
        ...attribute,
        args: attribute.args ?? [],
        ...(isGuard ? { succeedOnAbort: !!attribute.succeedOnAbort } : {})
    };
}

/**
 * Gets a copy of a node definition, and each of its nested node definitions, with the values that are assumed when a property is left out.
 * The same definition is written differently in MDSL, which always spells out these values, and in JSON, which can leave them out.
 * @param node The node definition.
 * @returns The node definition with its default values.
 */
function withNodeDefaults(node: any): any {
    const result = { ...node };

    if (node.type === "action" || node.type === "condition") {
        result.args = node.args ?? [];
    }

    for (const property of ATTRIBUTE_PROPERTIES) {
        if (node[property]) {
            result[property] = withAttributeDefaults(node[property], property === "while" || property === "until");
        }
    }

    if (Array.isArray(node.children)) {
        result.children = node.children.map(withNodeDefaults);
    }

    if (node.child) {
        result.child = withNodeDefaults(node.child);
    }

    return result;
}

/**
 * Converts a value to JSON in which the properties of objects are always in the same order and those that are undefined are left out.
 * @param value The value.
 * @returns The JSON for the value.
 */
function toOrderedJSON(value: unknown): string {
    if (Array.isArray(value)) {
        return `[${value.map(toOrderedJSON).join(",")}]`;
    }

    if (typeof value === "object" && value !== null) {
        const record = value as Record<string, unknown>;

        const properties = Object.keys(record)
            .filter((key) => record[key] !== undefined)
            .sort()
            .map((key) => `${JSON.stringify(key)}:${toOrderedJSON(record[key])}`);

        return `{${properties.join(",")}}`;
    }

    return JSON.stringify(value) ?? "null";
}

/**
 * Gets a 53-bit hash of a string (cyrb53).
 * @param value The string to hash.
 * @param seed The seed of the hash.
 * @returns The hash as a number.
 */
function hash(value: string, seed: number): number {
    let first = 0xdeadbeef ^ seed;
    let second = 0x41c6ce57 ^ seed;

    for (let index = 0; index < value.length; index++) {
        const code = value.charCodeAt(index);

        first = Math.imul(first ^ code, 2654435761);
        second = Math.imul(second ^ code, 1597334677);
    }

    first = Math.imul(first ^ (first >>> 16), 2246822507) ^ Math.imul(second ^ (second >>> 13), 3266489909);
    second = Math.imul(second ^ (second >>> 16), 2246822507) ^ Math.imul(first ^ (first >>> 13), 3266489909);

    return 4294967296 * (2097151 & second) + (first >>> 0);
}

/**
 * Compares two strings by their code units, which unlike a locale comparison does not depend on the environment.
 * @param left The first string.
 * @param right The second string.
 * @returns A negative number if the first string comes first, a positive number if it comes last, otherwise zero.
 */
function compare(left: string, right: string): number {
    return left < right ? -1 : left > right ? 1 : 0;
}

/**
 * Creates the identifier of a tree definition, which is the same for every definition that results in the same tree.
 * This means that a definition in MDSL has the same identifier as its equivalent JSON definition, whatever the layout of the MDSL, the order of the properties of the JSON,
 * the order of the root node definitions or whether JSON properties with default values are left out. The identifier does not include globally registered subtrees.
 * @param definition The root node definitions of the tree, as returned by definition validation.
 * @returns The identifier of the definition.
 */
export function createDefinitionIdentifier(definition: RootNodeDefinition[]): string {
    // The main root node has no 'id' so comes first, and the order of the subtree root nodes does not change the tree.
    const rootNodes = definition.map(withNodeDefaults).sort((left, right) => compare(left.id ?? "", right.id ?? ""));

    const json = toOrderedJSON(rootNodes);

    // Two hashes with different seeds are used to make it unlikely that one will be shared by two different definitions.
    return [hash(json, 0), hash(json, 1)].map((value) => value.toString(16).padStart(14, "0")).join("");
}
