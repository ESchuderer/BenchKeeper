import { AnyState } from "./State";

/**
 * The current version of the snapshot format.
 */
export const SNAPSHOT_VERSION = 1;

/**
 * A snapshot of the execution state of a single node in a behaviour tree.
 * This is a plain object that can be serialised using JSON, only the properties relevant to the node type are defined.
 */
export type NodeSnapshot = {
    /**
     * The tree node type.
     */
    type: string;
    /**
     * The state of the tree node.
     */
    state: AnyState;
    /**
     * The snapshots of the child nodes, defined if this is a composite or decorator node.
     */
    children?: NodeSnapshot[];
    /**
     * How the update promise returned by the action function settled, defined if this is a running action node whose update promise has settled.
     * A promise that is still pending cannot be restored, so an action node with one is snapshotted as not yet started, and will call its action function again on the next update.
     * The value is the string representation of the value that the promise resolved with or the reason that it was rejected with.
     */
    updatePromiseResult?: { isResolved: boolean; value: string };
    /**
     * The duration in milliseconds that the node will wait for in total, or null if it will wait indefinitely, defined if this is a wait node.
     * This includes any random selection that was made between the minimum and maximum durations.
     * This is only set while the node is running, and is otherwise null.
     */
    totalDuration?: number | null;
    /**
     * The duration in milliseconds that the node has waited for so far, defined if this is a wait node.
     * This is only set while the node is running, and is otherwise 0.
     */
    waitedDuration?: number;
    /**
     * The index of the child node that was randomly selected to be the active one, or null if there is none, defined if this is a lotto node.
     */
    selectedChildIndex?: number | null;
    /**
     * The number of iterations that the node will make in total, or null if it will repeat indefinitely, defined if this is a repeat node.
     * This includes any random selection that was made between the minimum and maximum iteration counts.
     */
    targetIterationCount?: number | null;
    /**
     * The number of iterations that the node has completed, defined if this is a repeat node.
     */
    currentIterationCount?: number;
    /**
     * The number of attempts that the node will make in total, or null if it will retry indefinitely, defined if this is a retry node.
     * This includes any random selection that was made between the minimum and maximum attempt counts.
     */
    targetAttemptCount?: number | null;
    /**
     * The number of attempts that the node has made, defined if this is a retry node.
     */
    currentAttemptCount?: number;
};

/**
 * A snapshot of the execution state of a behaviour tree, as returned by `BehaviourTree.snapshot()`.
 * This is a plain object that is unchanged by JSON serialisation and deserialisation.
 */
export type BehaviourTreeSnapshot = {
    /**
     * The version of the snapshot format.
     */
    version: typeof SNAPSHOT_VERSION;
    /**
     * The identifier of the definition of the tree that the snapshot was taken from, which is the same for an MDSL definition and its equivalent JSON definition.
     * A snapshot can only be restored to a tree with the same definition.
     */
    definition: string;
    /**
     * The snapshot of the root node, which includes every node in the tree below it.
     */
    root: NodeSnapshot;
};

/**
 * Gets whether a value from a snapshot is a valid count, which is a non-negative integer.
 * @param value The value from a snapshot.
 * @returns Whether the value is a valid count.
 */
export function isCount(value: unknown): value is number {
    return typeof value === "number" && Number.isInteger(value) && value >= 0;
}
