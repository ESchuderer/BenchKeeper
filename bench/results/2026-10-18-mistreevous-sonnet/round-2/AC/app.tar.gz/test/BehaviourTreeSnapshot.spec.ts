import { assert } from "chai";
import sinon, { SinonFakeTimers } from "sinon";

import { BehaviourTree, BehaviourTreeOptions, BehaviourTreeSnapshot, State, convertMDSLToJSON } from "../src/index";
import { Agent } from "../src/Agent";
import { RootNodeDefinition } from "../src/BehaviourTreeDefinition";

import { findNode, withoutNodeIds } from "./TestUtilities";

/**
 * Environment shared by the agents of every tree in a test.
 * Each key defines an agent function that logs its own name when called and returns the current value for that key.
 */
type Env = { [functionName: string]: any };

/**
 * A tree definition in any of the forms that a tree can be built from.
 */
type Definition = string | RootNodeDefinition | RootNodeDefinition[];

/**
 * A tree, the log of agent function calls made on its behalf and its options.
 */
type Run = { tree: BehaviourTree; log: string[]; env: Env };

/**
 * Creates a tree whose agent functions are defined by the keys of the environment.
 */
function createRun(definition: Definition, env: Env, options: BehaviourTreeOptions = {}): Run {
    const log: string[] = [];
    const agent: Agent = {};

    for (const functionName of Object.keys(env)) {
        agent[functionName] = () => {
            log.push(functionName);
            return env[functionName];
        };
    }

    return { tree: new BehaviourTree(definition, agent, options), log, env };
}

/**
 * Takes a snapshot of the original tree and restores it, via JSON, into a new tree built from the same definition.
 * The log of the original is cleared so that it only holds what is called from this point onwards.
 */
function restoreCopy(original: Run, definition: string, options: BehaviourTreeOptions = {}): Run {
    const copy = createRun(definition, original.env, options);

    copy.tree.restore(JSON.parse(JSON.stringify(original.tree.snapshot())));
    original.log.length = 0;

    return copy;
}

/**
 * Asserts that two runs have the same node states and have called the same agent functions in the same order.
 */
function assertSame(original: Run, copy: Run) {
    assert.deepEqual(
        withoutNodeIds(copy.tree.getTreeNodeDetails()),
        withoutNodeIds(original.tree.getTreeNodeDetails())
    );
    assert.deepEqual(copy.log, original.log);
}

/**
 * Steps both runs the given number of times, asserting after each step that they are the same.
 */
function stepBoth(original: Run, copy: Run, steps = 1) {
    for (let step = 0; step < steps; step++) {
        original.tree.step();
        copy.tree.step();
        assertSame(original, copy);
    }
}

describe("A BehaviourTree snapshot", () => {
    describe("is a plain object that", () => {
        it("survives JSON serialisation unchanged for a tree that has not been stepped", () => {
            const { tree } = createRun("root { sequence { action [A] repeat [2, 4] { wait [10, 20] } } }", {
                A: State.SUCCEEDED
            });

            const snapshot = tree.snapshot();

            assert.deepEqual(JSON.parse(JSON.stringify(snapshot)), snapshot);
        });

        it("survives JSON serialisation unchanged for a tree that is running", () => {
            const { tree } = createRun(
                "root { sequence { action [A] lotto { action [B] action [C] } retry [2, 4] { action [D] } wait [10, 20] } }",
                { A: State.SUCCEEDED, B: State.SUCCEEDED, C: State.SUCCEEDED, D: State.FAILED }
            );

            tree.step();
            tree.step();

            const snapshot = tree.snapshot();

            assert.deepEqual(JSON.parse(JSON.stringify(snapshot)), snapshot);
        });

        it("does not change the tree and is the same each time it is taken", () => {
            const { tree } = createRun("root { sequence { action [A] action [B] } }", {
                A: State.SUCCEEDED,
                B: undefined
            });

            tree.step();

            const details = withoutNodeIds(tree.getTreeNodeDetails());
            const snapshot = tree.snapshot();

            assert.deepEqual(tree.snapshot(), snapshot);
            assert.deepEqual(withoutNodeIds(tree.getTreeNodeDetails()), details);
        });

        it("is not changed by later steps of the tree", () => {
            const env = { A: undefined as State | undefined };
            const { tree } = createRun("root { action [A] }", env);

            tree.step();

            const snapshot = tree.snapshot();
            const snapshotJSON = JSON.stringify(snapshot);

            env.A = State.SUCCEEDED;
            tree.step();

            assert.strictEqual(JSON.stringify(snapshot), snapshotJSON);
        });
    });

    describe("can be restored to a tree built from the same definition", () => {
        it("so that the node states are the same as those of the original tree", () => {
            const definition = "root { sequence { action [A] selector { condition [B] action [C] } action [D] } }";
            const original = createRun(definition, { A: State.SUCCEEDED, B: false, C: undefined, D: undefined });

            original.tree.step();

            const copy = restoreCopy(original, definition);

            assert.strictEqual(copy.tree.getState(), State.RUNNING);
            assert.isTrue(copy.tree.isRunning());
            assert.strictEqual(findNode(copy.tree, "action", "A").state, State.SUCCEEDED);
            assert.strictEqual(findNode(copy.tree, "condition", "B").state, State.FAILED);
            assert.strictEqual(findNode(copy.tree, "action", "C").state, State.RUNNING);
            assert.strictEqual(findNode(copy.tree, "action", "D").state, State.READY);
            assertSame(original, copy);
        });

        it("without calling any agent functions", () => {
            const definition = "root { sequence { action [A] action [B] } }";
            const original = createRun(definition, { A: State.SUCCEEDED, B: undefined });

            original.tree.step();

            const copy = restoreCopy(original, definition);

            assert.deepEqual(copy.log, []);
        });

        it("when the tree was built from a JSON definition", () => {
            const definition: RootNodeDefinition = {
                type: "root",
                child: { type: "sequence", children: [{ type: "action", call: "A" }] }
            };
            const original = new BehaviourTree(definition, { A: () => State.RUNNING });
            const copy = new BehaviourTree(definition, { A: () => State.RUNNING });

            original.step();
            copy.restore(JSON.parse(JSON.stringify(original.snapshot())));

            assert.deepEqual(withoutNodeIds(copy.getTreeNodeDetails()), withoutNodeIds(original.getTreeNodeDetails()));
        });

        it("even if the tree has already been stepped, replacing the state it had", () => {
            const definition = "root { sequence { action [A] action [B] action [C] } }";
            const original = createRun(definition, { A: State.SUCCEEDED, B: undefined, C: undefined });
            const copy = createRun(definition, original.env);

            original.tree.step();

            // Take the copy further along than the original.
            original.env.B = State.SUCCEEDED;
            copy.tree.step();
            original.env.B = undefined;
            copy.tree.step();

            const snapshot = original.tree.snapshot();
            original.log.length = 0;
            copy.log.length = 0;
            copy.tree.restore(snapshot);

            assert.strictEqual(findNode(copy.tree, "action", "C").state, State.READY);
            stepBoth(original, copy, 3);
        });

        it("without calling the 'onNodeStateChange' option or any callbacks of the nodes", () => {
            const definition = "root { sequence { action [A] entry(OnEntry) exit(OnExit) action [B] } }";
            const original = createRun(definition, {
                A: State.SUCCEEDED,
                B: undefined,
                OnEntry: undefined,
                OnExit: undefined
            });

            original.tree.step();

            const changes: string[] = [];
            const copy = createRun(definition, original.env, {
                onNodeStateChange: ({ type, previousState, state }) => changes.push(`${type} ${previousState} ${state}`)
            });

            copy.tree.restore(original.tree.snapshot());

            assert.deepEqual(changes, []);
            assert.deepEqual(copy.log, []);

            // Restoring over a tree that has already been stepped is not a state change either.
            copy.env.A = undefined;
            copy.tree.step();
            changes.length = 0;
            copy.tree.restore(original.tree.snapshot());

            assert.deepEqual(changes, []);
        });

        it("and reports the changes made by the next step as usual", () => {
            const definition = "root { sequence { action [A] action [B] } }";
            const original = createRun(definition, { A: State.SUCCEEDED, B: undefined });

            original.tree.step();

            const changes: string[] = [];
            const copy = createRun(definition, original.env, {
                onNodeStateChange: ({ type, previousState, state }) => changes.push(`${type} ${previousState} ${state}`)
            });

            copy.tree.restore(original.tree.snapshot());
            copy.env.B = State.SUCCEEDED;
            copy.tree.step();

            assert.deepEqual(changes, [
                `action ${State.RUNNING} ${State.SUCCEEDED}`,
                `sequence ${State.RUNNING} ${State.SUCCEEDED}`,
                `root ${State.RUNNING} ${State.SUCCEEDED}`
            ]);
        });

        it("and the restored tree does not share state with the snapshot", () => {
            const definition = "root { sequence { action [A] action [B] } }";
            const original = createRun(definition, { A: State.SUCCEEDED, B: undefined });

            original.tree.step();

            const snapshot = original.tree.snapshot();
            const copy = createRun(definition, original.env);
            copy.tree.restore(snapshot);

            const restoredSnapshot = copy.tree.snapshot();
            copy.env.B = State.SUCCEEDED;
            copy.tree.step();

            assert.deepEqual(snapshot, restoredSnapshot);
        });

        it("and taking another snapshot gives the same snapshot", () => {
            const definition = "root { sequence { action [A] repeat [2, 5] { action [B] } } }";
            const original = createRun(definition, { A: State.SUCCEEDED, B: State.SUCCEEDED }, { random: () => 0.9 });

            original.tree.step();
            original.tree.step();

            const snapshot = JSON.parse(JSON.stringify(original.tree.snapshot()));
            const copy = createRun(definition, original.env);
            copy.tree.restore(snapshot);

            assert.deepEqual(copy.tree.snapshot(), snapshot);
        });

        it("and stepping either tree does not change the snapshot, however long it runs", async () => {
            const definition =
                "root { sequence { action [A] repeat [2, 4] { wait [10, 20] } lotto { action [B] action [C] } action [P] action [D] } }";
            const env = {
                A: State.SUCCEEDED,
                B: undefined,
                C: State.FAILED,
                D: undefined,
                P: Promise.resolve(State.SUCCEEDED)
            };
            const clock = sinon.useFakeTimers();

            try {
                const original = createRun(definition, env, { random: () => 0.5 });

                for (let step = 0; step < 12; step++) {
                    const earlierSnapshot = original.tree.snapshot();
                    const earlierSnapshotJSON = JSON.stringify(earlierSnapshot);

                    original.tree.step();
                    await Promise.resolve();
                    clock.tick(7);

                    // Stepping the original tree does not change a snapshot taken before.
                    assert.strictEqual(JSON.stringify(earlierSnapshot), earlierSnapshotJSON);

                    const snapshot = JSON.parse(JSON.stringify(original.tree.snapshot()));
                    const snapshotJSON = JSON.stringify(snapshot);
                    const copy = createRun(definition, env, { random: () => 0.5 });

                    copy.tree.restore(snapshot);

                    // The snapshot taken straight after restoring is the snapshot that was restored.
                    assert.strictEqual(JSON.stringify(JSON.parse(JSON.stringify(copy.tree.snapshot()))), snapshotJSON);

                    for (let copySteps = 0; copySteps < 4; copySteps++) {
                        copy.tree.step();
                        await Promise.resolve();
                        clock.tick(7);

                        // Neither does stepping the restored tree.
                        assert.strictEqual(JSON.stringify(snapshot), snapshotJSON);
                    }
                }
            } finally {
                clock.restore();
            }
        });
    });

    describe("restores nodes so that the restored tree behaves like the original", () => {
        const definitions = {
            sequence: "root { sequence { action [A] action [B] action [C] } }",
            selector: "root { selector { action [A] action [B] action [C] } }",
            parallel: "root { parallel { action [A] action [B] action [C] } }",
            race: "root { race { action [A] action [B] action [C] } }",
            all: "root { all { action [A] action [B] action [C] } }",
            flip: "root { sequence { flip { action [A] } action [B] action [C] } }",
            succeed: "root { sequence { succeed { action [A] } action [B] action [C] } }",
            fail: "root { selector { fail { action [A] } action [B] action [C] } }"
        };

        for (const [nodeType, definition] of Object.entries(definitions)) {
            it(`(${nodeType})`, () => {
                const env: Env = { A: undefined, B: undefined, C: undefined };
                const original = createRun(definition, env);

                // Moves each child of the node into a different state, where the node type allows it.
                original.tree.step();
                env.A = nodeType === "selector" || nodeType === "fail" ? State.FAILED : State.SUCCEEDED;
                original.tree.step();

                const copy = restoreCopy(original, definition);

                env.B = State.RUNNING;
                stepBoth(original, copy, 2);

                env.B = State.FAILED;
                env.C = State.SUCCEEDED;
                stepBoth(original, copy, 2);
                assertSame(original, copy);
            });
        }

        it("so that completed children are not run again and running children are updated", () => {
            const definition = "root { sequence { action [A] action [B] action [C] } }";
            const original = createRun(definition, { A: State.SUCCEEDED, B: undefined, C: undefined });

            original.tree.step();

            const copy = restoreCopy(original, definition);
            copy.env.B = State.SUCCEEDED;
            copy.tree.step();

            assert.deepEqual(copy.log, ["B", "C"]);
        });

        it("so that entry callbacks are not called again for nodes that are already running, and exit callbacks are called once finished", () => {
            const definition = "root { sequence { action [A] entry(OnEntry) exit(OnExit) step(OnStep) } }";
            const env: Env = { A: undefined, OnEntry: undefined, OnExit: undefined, OnStep: undefined };
            const original = createRun(definition, env);

            original.tree.step();

            const copy = restoreCopy(original, definition);

            env.A = State.SUCCEEDED;
            stepBoth(original, copy);

            assert.deepEqual(copy.log, ["OnStep", "A", "OnExit"]);
        });

        it("so that guards are still evaluated", () => {
            const definition = "root { sequence { action [A] while(IsReady) } }";
            const env: Env = { IsReady: true, A: undefined };
            const original = createRun(definition, env);

            original.tree.step();

            const copy = restoreCopy(original, definition);

            env.IsReady = false;
            stepBoth(original, copy);

            assert.strictEqual(findNode(copy.tree, "action", "A").state, State.FAILED);
        });

        it("so that a tree restored to the ready state can be stepped as if it had never run", () => {
            const definition = "root { sequence { action [A] action [B] } }";
            const original = createRun(definition, { A: State.SUCCEEDED, B: State.SUCCEEDED });

            const copy = restoreCopy(original, definition);

            assert.strictEqual(copy.tree.getState(), State.READY);
            stepBoth(original, copy);
            assert.strictEqual(copy.tree.getState(), State.SUCCEEDED);
        });
    });

    describe("restores a tree that uses branches", () => {
        afterEach(() => BehaviourTree.unregisterAll());

        it("(defined in the same definition)", () => {
            const definition = `
                root { sequence { branch [Work] branch [Work] } }
                root [Work] { sequence { action [A] repeat [2] { action [B] } } }
            `;
            const original = createRun(definition, { A: State.SUCCEEDED, B: undefined });

            original.tree.step();

            const copy = restoreCopy(original, definition);

            original.env.B = State.SUCCEEDED;
            stepBoth(original, copy, 8);
        });

        it("(globally registered)", () => {
            BehaviourTree.register("Work", "root { sequence { action [A] repeat [2] { action [B] } } }");

            const definition = "root { sequence { branch [Work] branch [Work] } }";
            const original = createRun(definition, { A: State.SUCCEEDED, B: undefined });

            original.tree.step();

            const copy = restoreCopy(original, definition);

            original.env.B = State.SUCCEEDED;
            stepBoth(original, copy, 8);
        });
    });

    describe("restores a finished tree", () => {
        for (const finishedState of [State.SUCCEEDED, State.FAILED]) {
            it(`as finished (${finishedState})`, () => {
                const definition = "root { sequence { action [A] action [B] } }";
                const original = createRun(definition, { A: State.SUCCEEDED, B: finishedState });

                original.tree.step();
                assert.strictEqual(original.tree.getState(), finishedState);

                const copy = restoreCopy(original, definition);

                assert.strictEqual(copy.tree.getState(), finishedState);
                assert.isFalse(copy.tree.isRunning());
                assert.deepEqual(copy.log, []);
                assertSame(original, copy);
            });
        }

        it("so that the next step starts a new run", () => {
            const definition = "root { sequence { action [A] entry(OnEntry) action [B] } }";
            const env: Env = { A: State.SUCCEEDED, B: State.SUCCEEDED, OnEntry: undefined };
            const original = createRun(definition, env);

            original.tree.step();

            const copy = restoreCopy(original, definition);

            stepBoth(original, copy);

            assert.deepEqual(copy.log, ["OnEntry", "A", "B"]);
        });
    });

    describe("cannot be restored if", () => {
        const definition = "root { sequence { action [A] repeat [3] { action [B] } } }";
        let source: Run;
        let snapshot: BehaviourTreeSnapshot;

        beforeEach(() => {
            source = createRun(definition, { A: State.SUCCEEDED, B: undefined });
            source.tree.step();
            snapshot = JSON.parse(JSON.stringify(source.tree.snapshot()));
        });

        /**
         * Asserts that restoring the snapshot fails, and that the failure left the tree it was restored to as it was.
         */
        function assertRestoreFails(invalidSnapshot: any, message: string, targetDefinition = definition) {
            const target = createRun(targetDefinition, { A: State.SUCCEEDED, B: undefined });
            target.tree.step();

            const before = target.tree.snapshot();

            assert.throws(() => target.tree.restore(invalidSnapshot), Error, message);
            assert.deepEqual(target.tree.snapshot(), before);
        }

        /**
         * Asserts that restoring the snapshot fails because of its nodes rather than its definition, by recording the definition of the tree it is restored to.
         * This is how a snapshot that was edited, rather than taken from a tree of another definition, would be rejected.
         */
        function assertNodesRejected(invalidSnapshot: any, message: string, targetDefinition = definition) {
            const { definition: targetDefinitionId } = createRun(targetDefinition, {}).tree.snapshot();

            assertRestoreFails({ ...invalidSnapshot, definition: targetDefinitionId }, message, targetDefinition);
        }

        it("it is not an object", () => {
            assertRestoreFails(null, "invalid snapshot: expected an object");
            assertRestoreFails(undefined, "invalid snapshot: expected an object");
            assertRestoreFails("snapshot", "invalid snapshot: expected an object");
            assertRestoreFails(1, "invalid snapshot: expected an object");
            assertRestoreFails(true, "invalid snapshot: expected an object");
            assertRestoreFails([], "invalid snapshot: expected an object");
            assertRestoreFails([snapshot], "invalid snapshot: expected an object");
        });

        it("it is an object without the fields of a snapshot", () => {
            assertRestoreFails({}, "invalid snapshot: unsupported version 'undefined'");
            assertRestoreFails({ foo: "bar" }, "invalid snapshot: unsupported version 'undefined'");
            assertRestoreFails({ root: snapshot.root }, "invalid snapshot: unsupported version 'undefined'");
        });

        it("it does not record a definition", () => {
            const { definition: _, ...withoutDefinition } = snapshot;

            assertRestoreFails(withoutDefinition, "does not match the tree's definition");
            assertRestoreFails({ ...snapshot, definition: null }, "does not match the tree's definition");
            assertRestoreFails({ ...snapshot, definition: 1 }, "does not match the tree's definition");
        });

        it("it has no root node, even if the definition matches", () => {
            const { root: _, ...withoutRoot } = snapshot;

            assertRestoreFails(withoutRoot, "invalid snapshot: expected an object for the node");
        });

        it("it has an unsupported version", () => {
            assertRestoreFails({ ...snapshot, version: 99 }, "invalid snapshot: unsupported version '99'");
            assertRestoreFails({ root: snapshot.root }, "invalid snapshot: unsupported version 'undefined'");
        });

        it("it has no root node", () => {
            assertNodesRejected(
                { version: snapshot.version, definition: snapshot.definition },
                "invalid snapshot: expected an object for the node"
            );
        });

        it("a node has a different type to the node it would be restored to", () => {
            assertNodesRejected(
                snapshot,
                "invalid snapshot: expected a 'selector' node but got 'sequence'",
                "root { selector { action [A] } }"
            );
        });

        it("a node has a different number of children to the node it would be restored to", () => {
            assertNodesRejected(
                snapshot,
                "invalid snapshot: expected 1 children for 'sequence' node but got 2",
                "root { sequence { action [A] } }"
            );
        });

        it("a node is missing its children", () => {
            const invalid = JSON.parse(JSON.stringify(snapshot));
            delete invalid.root.children[0].children;

            assertNodesRejected(invalid, "invalid snapshot: expected an array of children for 'sequence' node");
        });

        it("a repeat node has an invalid iteration count", () => {
            const invalid = JSON.parse(JSON.stringify(snapshot));
            invalid.root.children[0].children[1].currentIterationCount = -1;

            assertNodesRejected(invalid, "invalid snapshot: invalid current iteration count '-1' for 'repeat' node");

            invalid.root.children[0].children[1].currentIterationCount = 0;
            delete invalid.root.children[0].children[1].targetIterationCount;

            assertNodesRejected(
                invalid,
                "invalid snapshot: invalid target iteration count 'undefined' for 'repeat' node"
            );
        });

        it("a retry node has an invalid attempt count", () => {
            const retryDefinition = "root { retry [3] { action [A] } }";
            const retry = createRun(retryDefinition, { A: State.FAILED });
            retry.tree.step();

            const invalid = JSON.parse(JSON.stringify(retry.tree.snapshot()));

            invalid.root.children[0].currentAttemptCount = 1.5;
            assertNodesRejected(
                invalid,
                "invalid snapshot: invalid current attempt count '1.5' for 'retry' node",
                retryDefinition
            );

            invalid.root.children[0].currentAttemptCount = 0;
            invalid.root.children[0].targetAttemptCount = "3";
            assertNodesRejected(
                invalid,
                "invalid snapshot: invalid target attempt count '3' for 'retry' node",
                retryDefinition
            );
        });

        it("a lotto node has an invalid selected child", () => {
            const lottoDefinition = "root { lotto { action [A] action [B] } }";
            const lotto = createRun(lottoDefinition, { A: undefined, B: undefined });
            lotto.tree.step();

            const invalid = JSON.parse(JSON.stringify(lotto.tree.snapshot()));

            // The index must be valid for the children of the node that the snapshot is restored to.
            invalid.root.children[0].selectedChildIndex = 2;
            assertNodesRejected(
                invalid,
                "invalid snapshot: invalid selected child index '2' for 'lotto' node",
                lottoDefinition
            );

            // A node that has been updated must have a selected child.
            invalid.root.children[0].selectedChildIndex = null;
            assertNodesRejected(
                invalid,
                "invalid snapshot: invalid selected child index 'null' for 'lotto' node",
                lottoDefinition
            );
        });

        it("a wait node has an invalid duration", () => {
            // The waited duration is measured from the clock, so it must not change while we compare snapshots.
            const clock = sinon.useFakeTimers();

            try {
                const waitDefinition = "root { wait [1000] }";
                const wait = createRun(waitDefinition, {});
                wait.tree.step();

                const invalid = JSON.parse(JSON.stringify(wait.tree.snapshot()));

                invalid.root.children[0].waitedDuration = null;
                assertNodesRejected(
                    invalid,
                    "invalid snapshot: invalid waited duration 'null' for 'wait' node",
                    waitDefinition
                );

                invalid.root.children[0].waitedDuration = 0;
                invalid.root.children[0].totalDuration = "1000";
                assertNodesRejected(
                    invalid,
                    "invalid snapshot: invalid total duration '1000' for 'wait' node",
                    waitDefinition
                );
            } finally {
                clock.restore();
            }
        });

        it("an action node has an invalid promise result", () => {
            const actionDefinition = "root { action [A] }";
            const action = createRun(actionDefinition, { A: Promise.resolve(State.SUCCEEDED) });
            action.tree.step();

            const invalid = JSON.parse(JSON.stringify(action.tree.snapshot()));

            invalid.root.children[0].updatePromiseResult = { isResolved: true, value: 1 };
            assertNodesRejected(
                invalid,
                "invalid snapshot: invalid update promise result for 'action' node",
                actionDefinition
            );

            // A settled promise is only possible for a running action.
            invalid.root.children[0].updatePromiseResult = { isResolved: true, value: State.SUCCEEDED };
            invalid.root.children[0].state = State.READY;
            assertNodesRejected(
                invalid,
                "invalid snapshot: invalid update promise result for 'action' node",
                actionDefinition
            );
        });

        it("a deeply nested node is invalid", () => {
            const invalid = JSON.parse(JSON.stringify(snapshot));
            invalid.root.children[0].children[1].children[0].state = "mistreevous.unknown";

            assertNodesRejected(invalid, "invalid snapshot: invalid state 'mistreevous.unknown' for 'action' node");
        });
    });
});

describe("A BehaviourTree snapshot records the definition of its tree, so that", () => {
    const definition = "root { sequence { action [A, 1] repeat [3] { action [B] } wait [1000] } }";
    const env = {
        A: State.SUCCEEDED,
        B: undefined,
        Z: undefined,
        Y: undefined,
        E: undefined,
        X: undefined,
        S: undefined,
        G: true,
        C: true,
        IsOK: true,
        IsNotOK: true
    };

    /**
     * Asserts that a snapshot of a tree of one definition is rejected by a tree of another, and that the rejected tree is left as it was.
     */
    function assertDefinitionRejected(sourceDefinition: Definition, targetDefinition: Definition) {
        const source = createRun(sourceDefinition, env);
        const target = createRun(targetDefinition, env);

        source.tree.step();
        target.tree.step();

        const before = JSON.stringify(target.tree.snapshot());
        const details = withoutNodeIds(target.tree.getTreeNodeDetails());

        assert.throws(
            () => target.tree.restore(JSON.parse(JSON.stringify(source.tree.snapshot()))),
            Error,
            "the snapshot does not match the tree's definition"
        );
        assert.strictEqual(JSON.stringify(target.tree.snapshot()), before);
        assert.deepEqual(withoutNodeIds(target.tree.getTreeNodeDetails()), details);
    }

    /**
     * Asserts that a snapshot of a tree of one definition is accepted by a tree of another that is the same definition, in any form.
     */
    function assertDefinitionAccepted(sourceDefinition: Definition, targetDefinition: Definition) {
        const source = createRun(sourceDefinition, env);
        const target = createRun(targetDefinition, env);

        source.tree.step();
        target.tree.restore(JSON.parse(JSON.stringify(source.tree.snapshot())));

        assert.deepEqual(
            withoutNodeIds(target.tree.getTreeNodeDetails()),
            withoutNodeIds(source.tree.getTreeNodeDetails())
        );
    }

    it("the snapshot has the same definition each time it is taken, whatever the state of the tree", () => {
        const { tree } = createRun(definition, env);

        const initial = tree.snapshot().definition;

        assert.isString(initial);
        assert.isNotEmpty(initial);

        tree.step();
        tree.step();

        assert.strictEqual(tree.snapshot().definition, initial);

        tree.reset();

        assert.strictEqual(tree.snapshot().definition, initial);
    });

    it("the definition is the same for separate trees built from the same definition", () => {
        assert.strictEqual(
            createRun(definition, env).tree.snapshot().definition,
            createRun(definition, env).tree.snapshot().definition
        );
    });

    describe("a snapshot cannot be restored to a tree of another definition that has", () => {
        const cases: [string, string][] = [
            ["a different action", "root { sequence { action [Z, 1] repeat [3] { action [B] } wait [1000] } }"],
            ["different action arguments", "root { sequence { action [A, 2] repeat [3] { action [B] } wait [1000] } }"],
            ["no action arguments", "root { sequence { action [A] repeat [3] { action [B] } wait [1000] } }"],
            [
                "a different iteration count",
                "root { sequence { action [A, 1] repeat [4] { action [B] } wait [1000] } }"
            ],
            ["a different wait duration", "root { sequence { action [A, 1] repeat [3] { action [B] } wait [2000] } }"],
            ["a different node order", "root { sequence { repeat [3] { action [B] } action [A, 1] wait [1000] } }"],
            [
                "an added attribute",
                "root { sequence { action [A, 1] entry(E) repeat [3] { action [B] } wait [1000] } }"
            ],
            [
                "an extra subtree",
                `${"root { sequence { action [A, 1] repeat [3] { action [B] } wait [1000] } }"} root [Unused] { action [B] }`
            ]
        ];

        for (const [description, other] of cases) {
            it(`(${description})`, () => assertDefinitionRejected(definition, other));
        }

        it("(a different node type with the same shape)", () => {
            assertDefinitionRejected("root { sequence { action [A] } }", "root { selector { action [A] } }");
        });

        it("(a different guard)", () => {
            assertDefinitionRejected("root { action [A] while(IsOK) }", "root { action [A] while(IsNotOK) }");
            assertDefinitionRejected("root { action [A] while(IsOK) }", "root { action [A] until(IsOK) }");
            assertDefinitionRejected("root { action [A] while(IsOK, 1) }", "root { action [A] while(IsOK, 2) }");
        });

        it("(a different resolved state when aborted by a guard)", () => {
            assertDefinitionRejected(
                { type: "root", child: { type: "action", call: "A", while: { call: "G", succeedOnAbort: true } } },
                { type: "root", child: { type: "action", call: "A", while: { call: "G" } } }
            );
        });

        it("(different arguments of other types)", () => {
            assertDefinitionRejected("root { action [A, 1] }", 'root { action [A, "1"] }');
            assertDefinitionRejected("root { action [A, true] }", 'root { action [A, "true"] }');
            assertDefinitionRejected("root { action [A, null] }", "root { action [A] }");
        });

        it("(different subtree contents)", () => {
            assertDefinitionRejected(
                "root { branch [Sub] } root [Sub] { action [A] }",
                "root { branch [Sub] } root [Sub] { action [B] }"
            );
        });

        it("(a trailing difference in a long definition)", () => {
            const long = (last: string) => `root { sequence { ${"action [A] ".repeat(50)} action [${last}] } }`;

            assertDefinitionRejected(long("Y"), long("Z"));
        });
    });

    describe("a snapshot can be restored to a tree of the same definition that", () => {
        it("is written with different whitespace, layout and comments", () => {
            assertDefinitionAccepted(
                definition,
                `root {
                    /* the main sequence */
                    sequence {
                        action [A,1]
                        repeat [3] { action [B] }
                        wait [1000]
                    }
                }`
            );
        });

        it("is a JSON definition equivalent to the MDSL definition", () => {
            const json: RootNodeDefinition = {
                type: "root",
                child: {
                    type: "sequence",
                    children: [
                        { type: "action", call: "A", args: [1] },
                        { type: "repeat", iterations: 3, child: { type: "action", call: "B" } },
                        { type: "wait", duration: 1000 }
                    ]
                }
            };

            assertDefinitionAccepted(definition, json);
            assertDefinitionAccepted(json, definition);
            assertDefinitionAccepted(json, [json]);
            assertDefinitionAccepted([json], json);

            assert.strictEqual(
                createRun(definition, env).tree.snapshot().definition,
                new BehaviourTree(json, {}).snapshot().definition
            );
        });

        it("is a JSON definition with its properties in a different order and defaults left out or spelled out", () => {
            const mdsl = "root { sequence while(G, 1) entry(E) exit(X, 2) step(S) { action [A] condition [C] } }";

            const left: RootNodeDefinition = {
                type: "root",
                child: {
                    type: "sequence",
                    while: { call: "G", args: [1] },
                    entry: { call: "E" },
                    exit: { call: "X", args: [2] },
                    step: { call: "S" },
                    children: [
                        { type: "action", call: "A" },
                        { type: "condition", call: "C" }
                    ]
                } as any
            };
            const right: RootNodeDefinition = {
                child: {
                    children: [
                        { args: [], call: "A", type: "action" },
                        { call: "C", args: [], type: "condition" }
                    ],
                    step: { args: [], call: "S" },
                    exit: { args: [2], call: "X" },
                    entry: { args: [], call: "E" },
                    while: { succeedOnAbort: false, args: [1], call: "G" },
                    type: "sequence"
                } as any,
                type: "root"
            };

            assertDefinitionAccepted(mdsl, left);
            assertDefinitionAccepted(mdsl, right);
            assertDefinitionAccepted(left, right);
        });

        it("defines its subtrees in a different order, in MDSL or JSON", () => {
            const mdsl =
                "root { sequence { branch [One] branch [Two] } } root [One] { action [A] } root [Two] { action [B] }";
            const reordered =
                "root [Two] { action [B] } root [One] { action [A] } root { sequence { branch [One] branch [Two] } }";

            assertDefinitionAccepted(mdsl, reordered);
            assertDefinitionAccepted(mdsl, convertMDSLToJSON(reordered));
            assertDefinitionAccepted(convertMDSLToJSON(mdsl).reverse(), reordered);
        });

        it("has random ranges, weights and a wait without a duration", () => {
            const mdsl = "root { lotto [1, 2] { repeat [1, 3] { retry [2, 4] { wait [10, 20] } } wait } }";

            assertDefinitionAccepted(mdsl, convertMDSLToJSON(mdsl));
            assertDefinitionRejected(
                mdsl,
                "root { lotto [1, 3] { repeat [1, 3] { retry [2, 4] { wait [10, 20] } } wait } }"
            );
        });
    });

    it("a rejected snapshot leaves a tree that has settled promises and running waits behaving as it did", async () => {
        const clock = sinon.useFakeTimers({ toFake: ["Date"] });

        try {
            const targetDefinition = "root { sequence { action [A] wait [1000] action [B] } }";
            const target = createRun(targetDefinition, { A: Promise.resolve(State.SUCCEEDED), B: State.SUCCEEDED });
            const control = createRun(targetDefinition, { A: Promise.resolve(State.SUCCEEDED), B: State.SUCCEEDED });

            for (const run of [target, control]) {
                run.tree.step();
            }
            await new Promise((resolve) => setImmediate(resolve));

            const other = createRun("root { sequence { action [A] wait [500] action [B] } }", target.env);
            other.tree.step();

            assert.throws(() => target.tree.restore(other.tree.snapshot()), Error, "does not match");

            for (let step = 0; step < 4; step++) {
                clock.tick(400);
                target.tree.step();
                control.tree.step();

                assertSame(control, target);
            }

            assert.strictEqual(target.tree.getState(), State.SUCCEEDED);
        } finally {
            clock.restore();
        }
    });
});

describe("A BehaviourTree snapshot of a tree with", () => {
    describe("a repeat node", () => {
        it("restores the iteration count so that only the remaining iterations are made", () => {
            const definition = "root { repeat [3] { action [A] } }";
            const original = createRun(definition, { A: State.SUCCEEDED });

            original.tree.step();
            original.tree.step();

            const copy = restoreCopy(original, definition);

            // One more iteration, then a step to finish.
            stepBoth(original, copy, 2);

            assert.strictEqual(copy.tree.getState(), State.SUCCEEDED);
            assert.deepEqual(copy.log, ["A"]);
        });

        it("restores a randomly selected iteration count rather than selecting another", () => {
            const definition = "root { repeat [2, 5] { action [A] } }";
            const original = createRun(definition, { A: State.SUCCEEDED }, { random: () => 0.99 });

            original.tree.step();
            original.tree.step();

            // This would select two iterations if it was used, which would have been completed by now.
            const copy = restoreCopy(original, definition, { random: () => 0 });

            // Three more iterations, then a step to finish.
            stepBoth(original, copy, 4);

            assert.strictEqual(copy.tree.getState(), State.SUCCEEDED);
            assert.deepEqual(copy.log, ["A", "A", "A"]);
        });

        it("restores a repeat node that has no iteration count and repeats until its child fails", () => {
            const definition = "root { repeat { action [A] } }";
            const original = createRun(definition, { A: State.SUCCEEDED });

            original.tree.step();
            original.tree.step();

            const copy = restoreCopy(original, definition);

            stepBoth(original, copy, 2);
            assert.strictEqual(copy.tree.getState(), State.RUNNING);

            original.env.A = State.FAILED;
            stepBoth(original, copy);
            assert.strictEqual(copy.tree.getState(), State.FAILED);
        });

        it("restores the iteration count of repeat nodes nested in other repeat nodes", () => {
            const definition = "root { repeat [2] { repeat [3] { action [A] } } }";
            const original = createRun(definition, { A: State.SUCCEEDED });

            // Each of the two outer iterations takes four steps, the last of which resolves the inner repeat.
            for (let step = 0; step < 6; step++) {
                original.tree.step();
            }

            const copy = restoreCopy(original, definition);

            stepBoth(original, copy, 3);

            assert.strictEqual(copy.tree.getState(), State.SUCCEEDED);
        });
    });

    describe("a lotto node", () => {
        const definition = "root { lotto { action [A] action [B] action [C] } }";

        for (const [description, originalRandom, restoredRandom, picked] of [
            ["a child other than the first", 0.99, 0, "C"],
            ["the first child", 0, 0.99, "A"]
        ] as const) {
            it(`restores the selected child rather than selecting another (${description})`, () => {
                const env: Env = { A: undefined, B: undefined, C: undefined };
                const original = createRun(definition, env, { random: () => originalRandom });

                original.tree.step();

                const copy = restoreCopy(original, definition, { random: () => restoredRandom });

                stepBoth(original, copy, 2);
                assert.deepEqual(copy.log, [picked, picked]);

                env[picked] = State.SUCCEEDED;
                stepBoth(original, copy);
                assert.strictEqual(copy.tree.getState(), State.SUCCEEDED);
            });
        }

        it("restores the selected child of a lotto node with weighted children", () => {
            const weighted = "root { lotto [1, 1, 8] { action [A] action [B] action [C] } }";
            const original = createRun(weighted, { A: undefined, B: undefined, C: undefined }, { random: () => 0.99 });

            original.tree.step();

            const copy = restoreCopy(original, weighted, { random: () => 0 });

            stepBoth(original, copy, 2);
            assert.deepEqual(copy.log, ["C", "C"]);
        });

        it("restores the state of a lotto node that has not been stepped", () => {
            const original = createRun(definition, { A: State.SUCCEEDED, B: State.SUCCEEDED, C: State.SUCCEEDED });

            // The selection is made when the copy is first stepped.
            const copy = restoreCopy(original, definition, { random: () => 0.99 });
            copy.tree.step();

            assert.deepEqual(copy.log, ["C"]);
        });
    });

    describe("a wait node", () => {
        let clock: SinonFakeTimers;

        beforeEach(() => {
            clock = sinon.useFakeTimers();
        });

        afterEach(() => {
            clock.restore();
        });

        const waitState = (run: Run) => findNode(run.tree, "wait").state;

        describe("using the clock", () => {
            const definition = "root { wait [1000] }";

            it("restores the wait so that only the remaining time is waited", () => {
                const original = createRun(definition, {});

                original.tree.step();
                clock.tick(600);

                const copy = restoreCopy(original, definition);

                copy.tree.step();
                assert.strictEqual(waitState(copy), State.RUNNING);

                clock.tick(399);
                copy.tree.step();
                assert.strictEqual(waitState(copy), State.RUNNING);

                clock.tick(1);
                copy.tree.step();
                assert.strictEqual(waitState(copy), State.SUCCEEDED);
            });

            it("does not count the time between taking the snapshot and restoring it", () => {
                const original = createRun(definition, {});

                original.tree.step();
                clock.tick(600);

                const snapshot = JSON.parse(JSON.stringify(original.tree.snapshot()));

                // The process is down for a day.
                clock.tick(24 * 60 * 60 * 1000);

                const copy = createRun(definition, {});
                copy.tree.restore(snapshot);

                copy.tree.step();
                assert.strictEqual(waitState(copy), State.RUNNING);

                clock.tick(400);
                copy.tree.step();
                assert.strictEqual(waitState(copy), State.SUCCEEDED);
            });

            it("counts the time between restoring the snapshot and stepping the tree", () => {
                const original = createRun(definition, {});

                original.tree.step();
                clock.tick(600);

                const copy = restoreCopy(original, definition);

                clock.tick(400);
                copy.tree.step();

                assert.strictEqual(waitState(copy), State.SUCCEEDED);
            });

            it("counts the time since the wait was last stepped when the snapshot is taken", () => {
                const original = createRun(definition, {});

                original.tree.step();
                clock.tick(900);

                const snapshot = original.tree.snapshot();

                clock.tick(10000);

                const copy = createRun(definition, {});
                copy.tree.restore(snapshot);

                // 100ms remain, and the 10000ms between the snapshot and the restore do not count.
                copy.tree.step();
                assert.strictEqual(waitState(copy), State.RUNNING);

                clock.tick(100);
                copy.tree.step();
                assert.strictEqual(waitState(copy), State.SUCCEEDED);
            });

            it("restores a wait that had already waited long enough, which succeeds on the next step", () => {
                const original = createRun(definition, {});

                original.tree.step();
                clock.tick(1500);

                const copy = restoreCopy(original, definition);

                copy.tree.step();
                assert.strictEqual(waitState(copy), State.SUCCEEDED);
            });

            it("restores a randomly selected duration rather than selecting another", () => {
                const randomDefinition = "root { wait [500, 1500] }";
                const original = createRun(randomDefinition, {}, { random: () => 0.99 });

                original.tree.step();
                clock.tick(600);

                // This would select a duration of 500ms if it was used, which would have been waited by now.
                const copy = restoreCopy(original, randomDefinition, { random: () => 0 });

                // The original selected a duration of 1490ms.
                clock.tick(800);
                copy.tree.step();
                assert.strictEqual(waitState(copy), State.RUNNING);

                clock.tick(90);
                copy.tree.step();
                assert.strictEqual(waitState(copy), State.SUCCEEDED);
            });

            it("restores a wait with no duration that waits until it is aborted", () => {
                const indefiniteDefinition = "root { wait while(IsReady) }";
                const original = createRun(indefiniteDefinition, { IsReady: true });

                original.tree.step();
                clock.tick(10000);

                const copy = restoreCopy(original, indefiniteDefinition);

                clock.tick(10000);
                copy.tree.step();
                assert.strictEqual(waitState(copy), State.RUNNING);

                original.env.IsReady = false;
                copy.tree.step();
                assert.strictEqual(waitState(copy), State.FAILED);
            });

            it("restores the state of a wait that has not run or has finished", () => {
                const original = createRun("root { sequence { wait [100] wait [100] } }", {});

                const readyCopy = restoreCopy(original, "root { sequence { wait [100] wait [100] } }");
                assert.strictEqual(findNode(readyCopy.tree, "wait").state, State.READY);

                original.tree.step();
                clock.tick(100);
                original.tree.step();

                const copy = restoreCopy(original, "root { sequence { wait [100] wait [100] } }");

                assert.deepEqual(
                    withoutNodeIds(copy.tree.getTreeNodeDetails()),
                    withoutNodeIds(original.tree.getTreeNodeDetails())
                );
                assert.strictEqual(findNode(copy.tree, "wait").state, State.SUCCEEDED);

                clock.tick(100);
                copy.tree.step();
                assert.strictEqual(copy.tree.getState(), State.SUCCEEDED);
            });
        });

        describe("using the 'getDeltaTime' option", () => {
            const definition = "root { wait [1000] }";

            it("restores the wait so that only the remaining time is waited", () => {
                const options = { getDeltaTime: () => 0.25 };
                const original = createRun(definition, {}, options);

                original.tree.step();
                original.tree.step();

                const copy = restoreCopy(original, definition, options);

                // The wait is at 500ms after two steps, as the delta time is also added on the initial step.
                stepBoth(original, copy);
                assert.strictEqual(waitState(copy), State.RUNNING);

                stepBoth(original, copy);
                assert.strictEqual(waitState(copy), State.SUCCEEDED);
            });

            it("does not count the time between taking the snapshot and restoring it", () => {
                const options = { getDeltaTime: () => 0.25 };
                const original = createRun(definition, {}, options);

                original.tree.step();
                original.tree.step();

                const snapshot = JSON.parse(JSON.stringify(original.tree.snapshot()));

                clock.tick(24 * 60 * 60 * 1000);

                const copy = createRun(definition, {}, options);
                copy.tree.restore(snapshot);

                copy.tree.step();
                assert.strictEqual(waitState(copy), State.RUNNING);

                copy.tree.step();
                assert.strictEqual(waitState(copy), State.SUCCEEDED);
            });

            it("restores a randomly selected duration rather than selecting another", () => {
                const randomDefinition = "root { wait [500, 1500] }";
                const original = createRun(randomDefinition, {}, { getDeltaTime: () => 0.25, random: () => 0.99 });

                original.tree.step();
                original.tree.step();

                // This would select a duration of 500ms if it was used, which would have been waited by now.
                const copy = restoreCopy(original, randomDefinition, { getDeltaTime: () => 0.25, random: () => 0 });

                // The original selected a duration of 1490ms.
                stepBoth(original, copy, 3);
                assert.strictEqual(waitState(copy), State.RUNNING);

                stepBoth(original, copy);
                assert.strictEqual(waitState(copy), State.SUCCEEDED);
            });
        });

        describe("restored to a tree that measures time differently", () => {
            const definition = "root { wait [1000] }";

            it("restores a wait that was using 'getDeltaTime' to a tree that uses the clock", () => {
                const original = createRun(definition, {}, { getDeltaTime: () => 0.25 });

                original.tree.step();
                original.tree.step();

                const copy = restoreCopy(original, definition);

                clock.tick(499);
                copy.tree.step();
                assert.strictEqual(waitState(copy), State.RUNNING);

                clock.tick(1);
                copy.tree.step();
                assert.strictEqual(waitState(copy), State.SUCCEEDED);
            });

            it("restores a wait that was using the clock to a tree that uses 'getDeltaTime'", () => {
                const original = createRun(definition, {});

                original.tree.step();
                clock.tick(600);

                const copy = restoreCopy(original, definition, { getDeltaTime: () => 0.25 });

                copy.tree.step();
                assert.strictEqual(waitState(copy), State.RUNNING);

                copy.tree.step();
                assert.strictEqual(waitState(copy), State.SUCCEEDED);
            });
        });
    });

    describe("a promise-based action node", () => {
        const definition = "root { sequence { action [A] action [B] } }";

        /**
         * Waits for promise callbacks that have been queued to be called.
         */
        const settlePromises = () => new Promise((resolve) => setImmediate(resolve));

        /**
         * Creates a promise that can be settled by the test.
         */
        function createDeferred() {
            let resolve!: (value: State) => void;
            const promise = new Promise<State>((resolvePromise) => (resolve = resolvePromise));

            return { promise, resolve };
        }

        it("restores an action with a pending promise as not yet started, and calls the action function again on the next step", () => {
            const original = createRun(definition, { A: new Promise(() => {}), B: State.SUCCEEDED });

            original.tree.step();

            assert.strictEqual(findNode(original.tree, "action", "A").state, State.RUNNING);

            const snapshot = original.tree.snapshot();

            assert.deepEqual(JSON.parse(JSON.stringify(snapshot)), snapshot);

            const copy = restoreCopy(original, definition);

            assert.strictEqual(findNode(copy.tree, "action", "A").state, State.READY);
            assert.strictEqual(copy.tree.getState(), State.RUNNING);
            assert.deepEqual(copy.log, []);

            // The pending promise cannot be restored, so the action starts again.
            copy.tree.step();

            assert.deepEqual(copy.log, ["A"]);
            assert.strictEqual(findNode(copy.tree, "action", "A").state, State.RUNNING);
        });

        it("starts an action with a pending promise again as a new action, calling its entry callback", async () => {
            const entryDefinition = "root { sequence { action [A] entry(OnEntry) exit(OnExit) action [B] } }";
            const deferred = createDeferred();
            const original = createRun(entryDefinition, {
                A: deferred.promise,
                B: State.SUCCEEDED,
                OnEntry: undefined,
                OnExit: undefined
            });

            original.tree.step();

            const copy = restoreCopy(original, entryDefinition);

            copy.tree.step();

            assert.deepEqual(copy.log, ["OnEntry", "A"]);

            // Once its promise settles it goes on as any action would.
            deferred.resolve(State.SUCCEEDED);
            await settlePromises();
            copy.tree.step();

            assert.deepEqual(copy.log, ["OnEntry", "A", "OnExit", "B"]);
            assert.strictEqual(copy.tree.getState(), State.SUCCEEDED);
        });

        it("restores pending actions nested in other nodes as not yet started, leaving settled siblings alone", async () => {
            const nestedDefinition =
                "root { parallel { action [Slow] repeat [2] { action [Fast] } flip { action [Slow] } } }";
            const original = createRun(nestedDefinition, {
                Slow: new Promise(() => {}),
                Fast: Promise.resolve(State.SUCCEEDED)
            });

            original.tree.step();
            await settlePromises();

            const copy = restoreCopy(original, nestedDefinition);
            const [slow, repeat, flip] = withoutNodeIds(copy.tree.getTreeNodeDetails()).children![0].children!;

            assert.strictEqual(slow.state, State.READY);
            assert.strictEqual(repeat.state, State.RUNNING);
            assert.strictEqual(repeat.children![0].state, State.RUNNING);
            assert.strictEqual(flip.state, State.RUNNING);
            assert.strictEqual(flip.children![0].state, State.READY);

            copy.tree.step();

            // Both slow actions start again, while the settled fast action is handled without being called again.
            assert.deepEqual(copy.log, ["Slow", "Slow"]);
        });

        it("restores an action whose pending promise settles after the snapshot was taken as not yet started", async () => {
            const deferred = createDeferred();
            const original = createRun(definition, { A: deferred.promise, B: State.SUCCEEDED });

            original.tree.step();

            const snapshot = JSON.parse(JSON.stringify(original.tree.snapshot()));

            deferred.resolve(State.SUCCEEDED);
            await settlePromises();

            // The snapshot is a record of the moment that it was taken.
            const copy = createRun(definition, { A: State.RUNNING, B: State.SUCCEEDED });
            copy.tree.restore(snapshot);

            assert.strictEqual(findNode(copy.tree, "action", "A").state, State.READY);

            copy.tree.step();

            assert.deepEqual(copy.log, ["A"]);
        });

        for (const settledState of [State.SUCCEEDED, State.FAILED]) {
            it(`restores an action whose promise resolved with ${settledState}, without calling the action function again`, async () => {
                const original = createRun(definition, { A: Promise.resolve(settledState), B: State.SUCCEEDED });

                original.tree.step();
                await settlePromises();

                const snapshot = original.tree.snapshot();

                assert.deepEqual(JSON.parse(JSON.stringify(snapshot)), snapshot);

                const copy = restoreCopy(original, definition);

                assert.strictEqual(findNode(copy.tree, "action", "A").state, State.RUNNING);

                stepBoth(original, copy);

                assert.strictEqual(findNode(copy.tree, "action", "A").state, settledState);
                assert.notInclude(copy.log, "A");
            });
        }

        it("restores an action whose promise was rejected, which errors on the next step as the original does", async () => {
            const original = createRun(definition, { A: Promise.reject(new Error("boom")), B: State.SUCCEEDED });

            original.tree.step();
            await settlePromises();

            const copy = restoreCopy(original, definition);

            const message = "error stepping tree: action function 'A' promise rejected with 'Error: boom'";

            assert.throws(() => original.tree.step(), Error, message);
            assert.throws(() => copy.tree.step(), Error, message);
            assert.notInclude(copy.log, "A");
        });

        it("is not affected by a promise returned before the snapshot was restored", async () => {
            const stale = createDeferred();
            const target = createRun(definition, { A: stale.promise, B: State.SUCCEEDED });
            target.tree.step();

            const source = createRun(definition, { A: Promise.resolve(State.SUCCEEDED), B: State.SUCCEEDED });
            source.tree.step();
            await settlePromises();

            target.tree.restore(source.tree.snapshot());
            target.log.length = 0;

            stale.resolve(State.FAILED);
            await settlePromises();

            target.tree.step();

            assert.strictEqual(findNode(target.tree, "action", "A").state, State.SUCCEEDED);
            assert.deepEqual(target.log, ["B"]);
        });

        it("is not affected by a promise returned before the tree was reset", async () => {
            const stale = createDeferred();
            const run = createRun(definition, { A: stale.promise, B: State.SUCCEEDED });
            run.tree.step();

            run.tree.reset();
            run.env.A = createDeferred().promise;
            run.tree.step();

            stale.resolve(State.SUCCEEDED);
            await settlePromises();

            run.tree.step();

            assert.strictEqual(findNode(run.tree, "action", "A").state, State.RUNNING);
        });
    });

    describe("a retry node", () => {
        it("restores the attempt count so that only the remaining attempts are made", () => {
            const definition = "root { retry [3] { action [A] } }";
            const original = createRun(definition, { A: State.FAILED });

            original.tree.step();
            original.tree.step();

            const copy = restoreCopy(original, definition);

            // One more attempt, then a step to finish.
            stepBoth(original, copy, 2);

            assert.strictEqual(copy.tree.getState(), State.FAILED);
            assert.deepEqual(copy.log, ["A"]);
        });

        it("restores a randomly selected attempt count rather than selecting another", () => {
            const definition = "root { retry [2, 5] { action [A] } }";
            const original = createRun(definition, { A: State.FAILED }, { random: () => 0.99 });

            original.tree.step();
            original.tree.step();

            // This would select two attempts if it was used, which would have been made by now.
            const copy = restoreCopy(original, definition, { random: () => 0 });

            // Three more attempts, then a step to finish.
            stepBoth(original, copy, 4);

            assert.strictEqual(copy.tree.getState(), State.FAILED);
            assert.deepEqual(copy.log, ["A", "A", "A"]);
        });

        it("restores a retry node that has no attempt count and retries until its child succeeds", () => {
            const definition = "root { retry { action [A] } }";
            const original = createRun(definition, { A: State.FAILED });

            original.tree.step();
            original.tree.step();

            const copy = restoreCopy(original, definition);

            stepBoth(original, copy, 2);
            assert.strictEqual(copy.tree.getState(), State.RUNNING);

            original.env.A = State.SUCCEEDED;
            stepBoth(original, copy);
            assert.strictEqual(copy.tree.getState(), State.SUCCEEDED);
        });
    });
});

describe("A BehaviourTree snapshot of a finished tree", () => {
    it("makes a new random wait duration selection when the restored tree is stepped again", () => {
        const clock = sinon.useFakeTimers();

        try {
            const definition = "root { wait [500, 1500] }";
            const original = createRun(definition, {}, { random: () => 0.99 });

            original.tree.step();
            clock.tick(1490);
            original.tree.step();

            assert.strictEqual(original.tree.getState(), State.SUCCEEDED);

            // This will select a duration of 500ms.
            const copy = restoreCopy(original, definition, { random: () => 0 });

            assert.strictEqual(copy.tree.getState(), State.SUCCEEDED);

            copy.tree.step();
            assert.strictEqual(copy.tree.getState(), State.RUNNING);

            clock.tick(500);
            copy.tree.step();
            assert.strictEqual(copy.tree.getState(), State.SUCCEEDED);
        } finally {
            clock.restore();
        }
    });

    it("makes a new lotto selection when the restored tree is stepped again", () => {
        const definition = "root { lotto { action [A] action [B] action [C] } }";
        const original = createRun(
            definition,
            { A: State.SUCCEEDED, B: State.SUCCEEDED, C: State.SUCCEEDED },
            { random: () => 0.99 }
        );

        original.tree.step();

        assert.deepEqual(original.log, ["C"]);

        const copy = restoreCopy(original, definition, { random: () => 0 });

        assert.strictEqual(copy.tree.getState(), State.SUCCEEDED);

        copy.tree.step();

        assert.deepEqual(copy.log, ["A"]);
    });

    it("makes new random iteration and attempt count selections when the restored tree is stepped again", () => {
        const definition = "root { sequence { repeat [2, 5] { action [A] } retry [2, 5] { action [B] } } }";
        const env: Env = { A: State.SUCCEEDED, B: State.FAILED };
        const original = createRun(definition, env, { random: () => 0.99 });

        // Five iterations of A then five attempts of B.
        for (let step = 0; step < 11; step++) {
            original.tree.step();
        }

        assert.strictEqual(original.tree.getState(), State.FAILED);

        // This will select two iterations and two attempts.
        const copy = restoreCopy(original, definition, { random: () => 0 });

        assert.strictEqual(copy.tree.getState(), State.FAILED);

        for (let step = 0; step < 5; step++) {
            copy.tree.step();
        }

        assert.deepEqual(copy.log, ["A", "A", "B", "B"]);
        assert.strictEqual(copy.tree.getState(), State.FAILED);
    });
});

describe("A BehaviourTree restored from a snapshot taken at any point of a long run", () => {
    const definition = `root {
        sequence {
            action [Setup] entry(OnEntry) exit(OnExit)
            parallel {
                repeat [2, 4] { sequence { action [Work] step(OnStep) wait [30, 90] } }
                retry [1, 3] { selector { condition [Check] action [Fix] } }
                race { wait [100, 300] action [Poll] }
            }
            lotto [1, 2, 3] {
                action [First]
                sequence { action [Second] wait [20, 60] }
                flip { condition [Check] }
            }
            all {
                succeed { action [Third] }
                fail { action [Fourth] while(IsOk) }
            }
            selector { action [Approve] while(IsOk) wait [200] }
        }
    }`;

    const functionNames = [
        ...["Setup", "Work", "Fix", "Poll", "First", "Second", "Third", "Fourth", "Approve"],
        ...["Check", "IsOk", "OnEntry", "OnExit", "OnStep"]
    ];

    /**
     * A number between 0 and 1 that is decided only by its inputs, so that every tree gets the same answer at a given step.
     */
    function roll(...parts: (string | number)[]): number {
        let hash = 2166136261;

        for (const character of parts.join(":")) {
            hash = Math.imul(hash ^ character.charCodeAt(0), 16777619);
        }

        return (hash >>> 0) / 4294967296;
    }

    /**
     * Creates a seeded pseudo-random number generator that counts how many numbers it has generated.
     */
    function createRandom(seed: number, skip = 0) {
        let state = seed;
        const generator = { count: 0, next: () => 0 };

        generator.next = () => {
            generator.count++;
            state = (state + 0x6d2b79f5) | 0;
            let t = Math.imul(state ^ (state >>> 15), 1 | state);
            t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
            return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
        };

        for (let index = 0; index < skip; index++) {
            generator.next();
        }

        return generator;
    }

    type FuzzRun = Run & { random: ReturnType<typeof createRandom> };

    /**
     * Creates a tree for which every agent function gives an answer that depends only on the seed, the current step and the function.
     */
    function createFuzzRun(seed: number, clock: { step: number }, options: BehaviourTreeOptions, skip = 0): FuzzRun {
        const log: string[] = [];
        const agent: Agent = {};
        const random = createRandom(seed, skip);

        for (const name of functionNames) {
            agent[name] = () => {
                log.push(name);

                const value = roll(seed, clock.step, name);

                if (name === "IsOk") {
                    return value < 0.9;
                }

                if (name === "Check") {
                    return value < 0.5;
                }

                // Actions may be running, succeeded or failed, callbacks ignore this.
                return value < 0.4 ? undefined : value < 0.7 ? State.SUCCEEDED : State.FAILED;
            };
        }

        const tree = new BehaviourTree(definition, agent, { random: random.next, ...options });

        return { tree, log, env: {}, random };
    }

    const timings: [string, () => BehaviourTreeOptions][] = [
        ["the clock", () => ({})],
        ["the 'getDeltaTime' option", () => ({ getDeltaTime: () => 0.037 })]
    ];

    for (const [timing, getOptions] of timings) {
        it(`behaves exactly like the original tree for the rest of the run, using ${timing}`, function () {
            this.timeout(30000);
            const clock = sinon.useFakeTimers();

            try {
                for (const seed of [1, 2, 3]) {
                    for (let snapshotStep = 0; snapshotStep <= 40; snapshotStep++) {
                        const time = { step: 0 };
                        const original = createFuzzRun(seed, time, getOptions());

                        for (; time.step < snapshotStep; time.step++) {
                            original.tree.step();
                            clock.tick(37);
                        }

                        // The new random number generator needs to be at the same point as the original for the same numbers to be generated.
                        const copy = createFuzzRun(seed, time, getOptions(), original.random.count);

                        copy.tree.restore(JSON.parse(JSON.stringify(original.tree.snapshot())));
                        original.log.length = 0;

                        assert.deepEqual(copy.tree.snapshot(), original.tree.snapshot());

                        for (let step = 0; step < 40; step++, time.step++) {
                            stepBoth(original, copy);
                            clock.tick(37);

                            assert.deepEqual(
                                copy.tree.snapshot(),
                                original.tree.snapshot(),
                                `snapshots differ at step ${time.step} of seed ${seed} restored at step ${snapshotStep}`
                            );
                        }
                    }
                }
            } finally {
                clock.restore();
            }
        });
    }
});
