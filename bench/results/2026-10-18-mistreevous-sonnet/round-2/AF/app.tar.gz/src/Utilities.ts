/**
 * Create a randomly generated node uid.
 * @returns A randomly generated node uid.
 */
export function createUid(): string {
    const S4 = function () {
        return (((1 + Math.random()) * 0x10000) | 0).toString(16).substring(1);
    };
    return S4() + S4() + "-" + S4() + "-" + S4() + "-" + S4() + "-" + S4() + S4() + S4();
}

/**
 * Gets whether a value is a non-negative integer, as used for iteration and attempt counts.
 * @param value The value to check.
 * @returns Whether the value is a non-negative integer.
 */
export function isCount(value: unknown): value is number {
    return Number.isInteger(value) && (value as number) >= 0;
}

/**
 * Throws an error describing an invalid snapshot if the condition does not hold.
 * @param condition The condition that must hold for the snapshot to be valid.
 * @param message The description of what is wrong with the snapshot if the condition does not hold.
 */
export function checkSnapshot(condition: boolean, message: string): asserts condition {
    if (!condition) {
        throw new Error(message);
    }
}

/**
 * Gets an identifier for a definition that is the same for any two definitions that only differ in the order of their object keys,
 * and in properties that have their default value, which is what makes an MDSL definition and its equivalent JSON definition the same.
 * shortcut: a 53-bit hash rather than the whole definition to keep snapshots small, upgrade if a collision between definitions ever matters.
 * @param definition The definition as JSON.
 * @returns The identifier of the definition.
 */
export function getDefinitionId(definition: unknown): string {
    const canonical = JSON.stringify(definition, (_, value) =>
        value && typeof value === "object" && !Array.isArray(value)
            ? Object.fromEntries(
                  Object.entries(value)
                      .filter(
                          ([key, v]) =>
                              !(key === "args" && Array.isArray(v) && !v.length) &&
                              !(key === "succeedOnAbort" && v === false)
                      )
                      .sort(([a], [b]) => (a < b ? -1 : a > b ? 1 : 0))
              )
            : value
    );

    // The cyrb53 hash.
    let h1 = 0xdeadbeef;
    let h2 = 0x41c6ce57;
    for (let index = 0; index < canonical.length; index++) {
        const code = canonical.charCodeAt(index);
        h1 = Math.imul(h1 ^ code, 2654435761);
        h2 = Math.imul(h2 ^ code, 1597334677);
    }
    h1 = Math.imul(h1 ^ (h1 >>> 16), 2246822507) ^ Math.imul(h2 ^ (h2 >>> 13), 3266489909);
    h2 = Math.imul(h2 ^ (h2 >>> 16), 2246822507) ^ Math.imul(h1 ^ (h1 >>> 13), 3266489909);

    return (4294967296 * (2097151 & h2) + (h1 >>> 0)).toString(16);
}
