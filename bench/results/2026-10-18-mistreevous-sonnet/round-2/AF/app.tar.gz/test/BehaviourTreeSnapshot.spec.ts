import { assert } from "chai";
import sinon, { SinonFakeTimers } from "sinon";

import { BehaviourTree, State } from "../src/index";
import type { BehaviourTreeSnapshot, NodeDetails } from "../src/index";
import { findNode } from "./TestUtilities";

/**
 * Get the details of a tree without the node ids, which are different for every tree instance.
 */
const states = (tree: BehaviourTree) => {
    const strip = ({ id, children, ...rest }: NodeDetails): any => ({ ...rest, children: children?.map(strip) });
    return strip(tree.getTreeNodeDetails());
};

/**
 * Step a tree until it reaches a state, failing instead of looping forever if it never does.
 */
const stepUntil = (tree: BehaviourTree, state: State) => {
    for (let step = 0; tree.getState() !== state; step++) {
        assert.isBelow(step, 50, `tree did not reach ${state}`);
        tree.step();
    }
};

const throughJSON = (snapshot: BehaviourTreeSnapshot): BehaviourTreeSnapshot => JSON.parse(JSON.stringify(snapshot));

/**
 * A seedable random function whose position can be copied.
 */
const createRandom = (seed: number) => {
    const random = () => {
        random.seed = (random.seed * 1664525 + 1013904223) % 2 ** 32;
        return random.seed / 2 ** 32;
    };
    random.seed = seed;
    return random;
};

/**
 * An agent that logs every call made to it, with data that can be copied.
 */
const createAgent = (data: { log: string[]; counts: { [name: string]: number } } = { log: [], counts: {} }) => {
    const count = (name: string) => (data.counts[name] = (data.counts[name] || 0) + 1);
    const action = (name: string) => () => {
        const calls = count(name);
        data.log.push(name);
        return calls % 2 ? State.RUNNING : State.SUCCEEDED;
    };

    return {
        data,
        A: action("A"),
        B: action("B"),
        C: action("C"),
        D: action("D"),
        E: action("E"),
        Flaky: () => {
            data.log.push("Flaky");
            return count("Flaky") % 3 ? State.FAILED : State.SUCCEEDED;
        },
        No: () => (data.log.push("No"), false),
        onEntry: () => void data.log.push("entry"),
        onExit: (succeeded: boolean, aborted: boolean) => void data.log.push(`exit ${succeeded} ${aborted}`)
    };
};

const RICH_DEFINITION = `root {
    sequence {
        repeat [2,4] entry(onEntry) exit(onExit) {
            sequence {
                action [A]
                wait [20,60]
            }
        }
        retry [2,3] {
            action [Flaky]
        }
        lotto [1,3] exit(onExit) {
            action [B]
            action [C]
        }
        parallel {
            action [D]
            wait [30]
        }
        race {
            wait [50]
            action [E]
        }
        all {
            wait [20]
            action [A]
        }
        flip {
            action [B]
        }
        selector {
            condition [No]
            succeed {
                action [C]
            }
        }
    }
}`;

describe("A BehaviourTree snapshot", () => {
    describe("is a plain object that", () => {
        it("survives a JSON round trip unchanged", () => {
            const agent = createAgent();
            const tree = new BehaviourTree(RICH_DEFINITION, agent, {
                random: createRandom(1),
                getDeltaTime: () => 0.01
            });

            for (let step = 0; step < 15; step++) {
                tree.step();
                const snapshot = tree.snapshot();
                assert.deepStrictEqual(throughJSON(snapshot), snapshot);
            }
        });

        it("is not changed by later steps of the tree", () => {
            const tree = new BehaviourTree("root { repeat [3] { action [A] } }", createAgent());
            tree.step();
            const snapshot = tree.snapshot();
            const before = JSON.stringify(snapshot);
            tree.step();
            tree.step();
            assert.strictEqual(JSON.stringify(snapshot), before);
        });
    });

    describe("can be restored to a tree built from the same definition", () => {
        const modes = {
            "using Date": () => {
                let clock: SinonFakeTimers;
                return {
                    options: {},
                    setup: () => (clock = sinon.useFakeTimers({ now: 1000 })),
                    teardown: () => clock.restore(),
                    advance: () => clock.tick(10),
                    // Lots of time passes between taking a snapshot and restoring it.
                    gap: () => void clock.tick(1_000_000)
                };
            },
            "using getDeltaTime": () => ({
                options: { getDeltaTime: () => 0.01 },
                setup: () => {},
                teardown: () => {},
                advance: () => {},
                gap: () => {}
            })
        };

        Object.entries(modes).forEach(([modeName, createMode]) => {
            it(`so that it behaves exactly like the original at every step (${modeName})`, () => {
                const mode = createMode();
                mode.setup();

                try {
                    for (let stepsBeforeSnapshot = 0; stepsBeforeSnapshot < 40; stepsBeforeSnapshot++) {
                        const run = (tree: BehaviourTree, agent: ReturnType<typeof createAgent>) => {
                            const trace: any[] = [];
                            for (let step = 0; step < 40; step++) {
                                tree.step();
                                mode.advance();
                                trace.push({ details: states(tree), log: [...agent.data.log] });
                            }
                            return trace;
                        };

                        const random = createRandom(stepsBeforeSnapshot);
                        const agent = createAgent();
                        const tree = new BehaviourTree(RICH_DEFINITION, agent, { ...mode.options, random });

                        for (let step = 0; step < stepsBeforeSnapshot; step++) {
                            tree.step();
                            mode.advance();
                        }

                        const snapshot = throughJSON(tree.snapshot());
                        const restoredAgent = createAgent(JSON.parse(JSON.stringify(agent.data)));
                        const restoredRandom = createRandom(random.seed);
                        const restoredTree = new BehaviourTree(RICH_DEFINITION, restoredAgent, {
                            ...mode.options,
                            random: restoredRandom
                        });
                        restoredTree.restore(snapshot);
                        assert.deepStrictEqual(
                            states(restoredTree),
                            states(tree),
                            `restored state (${stepsBeforeSnapshot})`
                        );

                        // Run the original on from the time of the snapshot, then jump forward in time to restore and run the other tree.
                        const expected = run(tree, agent);
                        mode.gap();
                        restoredTree.restore(snapshot);
                        const actual = run(restoredTree, restoredAgent);

                        assert.deepStrictEqual(actual, expected, `after ${stepsBeforeSnapshot} steps`);
                        assert.strictEqual(restoredRandom.seed, random.seed);
                    }
                } finally {
                    mode.teardown();
                }
            });
        });
    });

    describe("keeps the progress of", () => {
        it("repeat nodes", () => {
            const definition = "root { repeat [3] { action [A] } }";
            const agent = createAgent();
            // The action only succeeds on every second call, so 4 steps make 2 iterations.
            const tree = new BehaviourTree(definition, agent);
            for (let i = 0; i < 4; i++) tree.step();

            const restoredAgent = createAgent();
            const restored = new BehaviourTree(definition, restoredAgent);
            restored.restore(throughJSON(tree.snapshot()));
            restoredAgent.data.counts.A = 4;

            // The third iteration takes 2 steps, and the step after that finds that there are no more.
            restored.step();
            restored.step();
            assert.strictEqual(restored.getState(), State.RUNNING);
            restored.step();
            assert.strictEqual(restored.getState(), State.SUCCEEDED);
            assert.deepEqual(restoredAgent.data.log, ["A", "A"]);
        });

        it("retry nodes", () => {
            const definition = "root { retry [3] { action [Fail] } }";
            let calls = 0;
            const agent = {
                Fail: () => {
                    calls++;
                    return State.FAILED;
                }
            };
            const tree = new BehaviourTree(definition, agent);
            tree.step();
            tree.step();
            assert.strictEqual(calls, 2);

            calls = 0;
            const restored = new BehaviourTree(definition, agent);
            restored.restore(throughJSON(tree.snapshot()));
            restored.step();
            assert.strictEqual(calls, 1);
            assert.strictEqual(restored.getState(), State.RUNNING);
            restored.step();
            assert.strictEqual(restored.getState(), State.FAILED);
            assert.strictEqual(calls, 1);
        });

        describe("random choices that were already made, when the restored tree would have chosen differently", () => {
            const noRandom = { random: () => 0 };

            it("for repeat nodes", () => {
                let calls = 0;
                const agent = { Ok: () => (calls++, State.SUCCEEDED) };
                const definition = "root { repeat [1,10] { action [Ok] } }";
                // This picks 4 iterations.
                const tree = new BehaviourTree(definition, agent, { random: () => 0.3 });
                tree.step();

                calls = 0;
                const restored = new BehaviourTree(definition, agent, noRandom);
                restored.restore(throughJSON(tree.snapshot()));
                stepUntil(restored, State.SUCCEEDED);
                assert.strictEqual(calls, 3);
            });

            it("for retry nodes", () => {
                let calls = 0;
                const agent = { Fail: () => (calls++, State.FAILED) };
                const definition = "root { retry [1,10] { action [Fail] } }";
                // This picks 4 attempts.
                const tree = new BehaviourTree(definition, agent, { random: () => 0.3 });
                tree.step();

                calls = 0;
                const restored = new BehaviourTree(definition, agent, noRandom);
                restored.restore(throughJSON(tree.snapshot()));
                stepUntil(restored, State.FAILED);
                assert.strictEqual(calls, 3);
            });

            it("for lotto nodes", () => {
                const calls: string[] = [];
                const agent = {
                    First: () => (calls.push("First"), State.RUNNING),
                    Second: () => (calls.push("Second"), State.RUNNING),
                    Third: () => (calls.push("Third"), State.RUNNING)
                };
                const definition = "root { lotto { action [First] action [Second] action [Third] } }";
                const tree = new BehaviourTree(definition, agent, { random: () => 0.9 });
                tree.step();

                calls.length = 0;
                const restored = new BehaviourTree(definition, agent, noRandom);
                restored.restore(throughJSON(tree.snapshot()));
                restored.step();
                assert.deepEqual(calls, ["Third"]);
            });

            it("for wait nodes", () => {
                let delta = 1;
                const definition = "root { wait [1000,2000] }";
                // This picks a duration of 1500ms.
                const tree = new BehaviourTree(definition, {}, { random: () => 0.5, getDeltaTime: () => delta });
                tree.step();

                const restored = new BehaviourTree(definition, {}, { random: () => 0, getDeltaTime: () => delta });
                restored.restore(throughJSON(tree.snapshot()));
                delta = 0.1;
                restored.step();
                assert.strictEqual(restored.getState(), State.RUNNING);
                delta = 0.4;
                restored.step();
                assert.strictEqual(restored.getState(), State.SUCCEEDED);
            });
        });
    });

    describe("restores wait nodes so that they only wait for the remaining time", () => {
        it("when using Date", () => {
            const clock = sinon.useFakeTimers({ now: 0 });
            try {
                const tree = new BehaviourTree("root { wait [1000] }", {});
                tree.step();
                clock.tick(400);
                const snapshot = throughJSON(tree.snapshot());

                // Time passing before the restore doesn't count.
                clock.tick(5000);
                const restored = new BehaviourTree("root { wait [1000] }", {});
                restored.restore(snapshot);

                restored.step();
                assert.strictEqual(restored.getState(), State.RUNNING);
                clock.tick(599);
                restored.step();
                assert.strictEqual(restored.getState(), State.RUNNING);
                clock.tick(1);
                restored.step();
                assert.strictEqual(restored.getState(), State.SUCCEEDED);
            } finally {
                clock.restore();
            }
        });

        it("when using Date, without the time before the first step counting or changing a snapshot taken before it", () => {
            const clock = sinon.useFakeTimers({ now: 0 });
            try {
                const tree = new BehaviourTree("root { wait [1000] }", {});
                tree.step();
                clock.tick(400);
                const snapshot = throughJSON(tree.snapshot());

                const restored = new BehaviourTree("root { wait [1000] }", {});
                restored.restore(snapshot);
                clock.tick(300);
                assert.deepStrictEqual(throughJSON(restored.snapshot()), snapshot);

                restored.step();
                clock.tick(599);
                restored.step();
                assert.strictEqual(restored.getState(), State.RUNNING);
                clock.tick(1);
                restored.step();
                assert.strictEqual(restored.getState(), State.SUCCEEDED);
            } finally {
                clock.restore();
            }
        });

        it("when using getDeltaTime", () => {
            let delta = 0.4;
            const options = { getDeltaTime: () => delta };
            const tree = new BehaviourTree("root { wait [1000] }", {}, options);
            tree.step();
            const snapshot = throughJSON(tree.snapshot());

            const restored = new BehaviourTree("root { wait [1000] }", {}, options);
            restored.restore(snapshot);
            delta = 0.5;
            restored.step();
            assert.strictEqual(restored.getState(), State.RUNNING);
            delta = 0.1;
            restored.step();
            assert.strictEqual(restored.getState(), State.SUCCEEDED);
        });

        it("that wait indefinitely", () => {
            const tree = new BehaviourTree("root { wait }", {});
            tree.step();
            const restored = new BehaviourTree("root { wait }", {});
            restored.restore(throughJSON(tree.snapshot()));
            restored.step();
            assert.strictEqual(restored.getState(), State.RUNNING);
        });
    });

    describe("of a finished tree", () => {
        it("restores as finished, and the next step starts a new run that makes new random choices", () => {
            const definition =
                "root { sequence { repeat [1,5] { action [Ok] } lotto { action [First] action [Second] } } }";
            const calls: string[] = [];
            const agent = {
                Ok: () => (calls.push("Ok"), State.SUCCEEDED),
                First: () => (calls.push("First"), State.SUCCEEDED),
                Second: () => (calls.push("Second"), State.SUCCEEDED)
            };
            // The first run picks 1 iteration and the first lotto child.
            const firstPicks = [0, 0];
            const tree = new BehaviourTree(definition, agent, { random: () => firstPicks.shift()! });
            stepUntil(tree, State.SUCCEEDED);
            assert.deepEqual(calls, ["Ok", "First"]);

            // The next run picks 5 iterations and the second lotto child.
            const picks = [0.99, 0.99];
            const restored = new BehaviourTree(definition, agent, { random: () => picks.shift()! });
            restored.restore(throughJSON(tree.snapshot()));
            assert.strictEqual(restored.getState(), State.SUCCEEDED);
            assert.deepEqual(states(restored), states(tree));
            assert.lengthOf(picks, 2);

            calls.length = 0;
            restored.step();
            stepUntil(restored, State.SUCCEEDED);
            assert.deepEqual(calls, ["Ok", "Ok", "Ok", "Ok", "Ok", "Second"]);
            assert.lengthOf(picks, 0);
        });
    });

    describe("restores action nodes with", () => {
        const flush = () => new Promise((resolve) => setImmediate(resolve));

        it("a settled promise, without calling the action function again", async () => {
            let calls = 0;
            const agent = {
                Act: () => (calls++, Promise.resolve(State.SUCCEEDED))
            };
            const tree = new BehaviourTree("root { action [Act] }", agent);
            tree.step();
            await flush();

            const restored = new BehaviourTree("root { action [Act] }", agent);
            restored.restore(throughJSON(tree.snapshot()));
            restored.step();
            assert.strictEqual(restored.getState(), State.SUCCEEDED);
            assert.strictEqual(calls, 1);
        });

        it("a rejected promise, which errors on the next step", async () => {
            const agent = { Act: () => Promise.reject("nope") };
            const tree = new BehaviourTree("root { action [Act] }", agent);
            tree.step();
            await flush();

            const restored = new BehaviourTree("root { action [Act] }", agent);
            restored.restore(throughJSON(tree.snapshot()));
            assert.throws(() => restored.step(), Error, "action function 'Act' promise rejected with 'nope'");
        });

        it("a pending promise, which can't be saved, as not yet started so the action function is called again", () => {
            let calls = 0;
            const agent = { Act: () => (calls++, new Promise<State.SUCCEEDED>(() => {})) };
            const definition = "root { sequence { action [Act] } }";
            const tree = new BehaviourTree(definition, agent);
            tree.step();
            const snapshot = throughJSON(tree.snapshot());
            assert.strictEqual(findNode(tree, "action", "Act").state, State.RUNNING);

            const restored = new BehaviourTree(definition, agent);
            restored.restore(snapshot);
            assert.strictEqual(findNode(restored, "action", "Act").state, State.READY);
            assert.strictEqual(calls, 1);
            restored.step();
            assert.strictEqual(calls, 2);
            assert.strictEqual(findNode(restored, "action", "Act").state, State.RUNNING);
        });
    });

    describe("restoring", () => {
        it("does not call onNodeStateChange, and the next step reports changes as usual", () => {
            const changes: any[] = [];
            const definition = "root { sequence { action [A] action [B] } }";
            const tree = new BehaviourTree(definition, createAgent());
            tree.step();
            // The restored tree's agent has already called A once, so A finishes on the next step.
            const restored = new BehaviourTree(definition, createAgent({ log: [], counts: { A: 1 } }), {
                onNodeStateChange: (c) => changes.push(c)
            });
            restored.restore(tree.snapshot());
            assert.lengthOf(changes, 0);
            restored.step();
            assert.isAbove(changes.length, 0);
        });

        it("gives a snapshot taken before any step that equals the one restored", () => {
            const tree = new BehaviourTree(RICH_DEFINITION, createAgent(), {
                random: createRandom(1),
                getDeltaTime: () => 0.01
            });
            for (let step = 0; step < 15; step++) {
                tree.step();
                const snapshot = tree.snapshot();
                const restored = new BehaviourTree(RICH_DEFINITION, createAgent(), { getDeltaTime: () => 0.01 });
                restored.restore(snapshot);
                assert.deepStrictEqual(throughJSON(restored.snapshot()), throughJSON(snapshot));
            }
        });

        it("is not changed by stepping the restored tree", () => {
            const tree = new BehaviourTree(RICH_DEFINITION, createAgent(), {
                random: createRandom(1),
                getDeltaTime: () => 0.01
            });
            for (let step = 0; step < 15; step++) {
                tree.step();
                const snapshot = tree.snapshot();
                const before = JSON.stringify(snapshot);
                const restored = new BehaviourTree(RICH_DEFINITION, createAgent(), { getDeltaTime: () => 0.01 });
                restored.restore(snapshot);
                for (let i = 0; i < 5; i++) restored.step();
                assert.strictEqual(JSON.stringify(snapshot), before);
            }
        });

        it("onto a tree that has already been stepped replaces its state", () => {
            const definition = "root { sequence { action [A] action [B] } }";
            const tree = new BehaviourTree(definition, createAgent());
            const snapshot = tree.snapshot();
            tree.step();
            tree.step();
            tree.restore(snapshot);
            assert.strictEqual(tree.getState(), State.READY);
            assert.strictEqual(findNode(tree, "action", "A").state, State.READY);
        });

        describe("will error and leave the tree untouched if", () => {
            const definition =
                "root { sequence { repeat [3] { action [A] } wait [100] lotto { action [B] action [C] } } }";
            const cases: { [name: string]: (snapshot: any) => any } = {
                "it is not a snapshot": () => ({}),
                "it is null": () => null,
                "the version is unknown": (s) => ({ ...s, version: 99 }),
                "a node has a different type": (s) => {
                    s.root.children[0].type = "selector";
                    return s;
                },
                "a node has a missing child": (s) => {
                    s.root.children[0].children.pop();
                    return s;
                },
                "a node has an unknown state": (s) => {
                    s.root.children[0].children[1].state = "running";
                    return s;
                },
                "a repeat count is invalid": (s) => {
                    s.root.children[0].children[0].currentCount = -1;
                    return s;
                },
                "a wait duration is invalid": (s) => {
                    s.root.children[0].children[1].waitedDuration = "soon";
                    return s;
                },
                "a lotto selection is out of range": (s) => {
                    s.root.children[0].children[2].children[0].state = State.RUNNING;
                    s.root.children[0].children[2].selectedChild = 2;
                    return s;
                }
            };

            Object.entries(cases).forEach(([name, corrupt]) => {
                it(name, () => {
                    const source = new BehaviourTree(definition, createAgent());
                    const tree = new BehaviourTree(definition, createAgent());
                    tree.step();
                    const before = JSON.stringify(tree.snapshot());
                    const bad = corrupt(throughJSON(source.snapshot()));

                    assert.throws(() => tree.restore(bad), Error, /^error restoring tree: /);
                    assert.strictEqual(JSON.stringify(tree.snapshot()), before);
                });
            });

            it("it was taken from a tree with a different structure", () => {
                const other = new BehaviourTree("root { action [A] }", createAgent());
                const tree = new BehaviourTree(definition, createAgent());
                assert.throws(() => tree.restore(other.snapshot()), Error, /^error restoring tree: /);
            });
        });

        describe("a snapshot of another definition", () => {
            const restoreFails = (definition: string, otherDefinition: string) => {
                // A wait node using the clock is a little further along every time it is snapshotted.
                const options = { getDeltaTime: () => 0 };
                const tree = new BehaviourTree(definition, createAgent(), options);
                tree.step();
                const before = JSON.stringify(tree.snapshot());
                const other = new BehaviourTree(otherDefinition, createAgent(), options);
                other.step();

                assert.throws(
                    () => tree.restore(throughJSON(other.snapshot())),
                    Error,
                    /does not match the tree's definition/
                );
                assert.strictEqual(JSON.stringify(tree.snapshot()), before);
            };

            it("is rejected when only a node argument is different", () => {
                restoreFails("root { repeat [3] { action [A] } }", "root { repeat [4] { action [A] } }");
            });

            it("is rejected when only a wait duration is different", () => {
                restoreFails("root { wait [100] }", "root { wait [200] }");
            });

            it("is rejected when only an action name is different", () => {
                restoreFails(
                    "root { sequence { action [A] action [B] } }",
                    "root { sequence { action [A] action [C] } }"
                );
            });

            it("is rejected when only an attribute is different", () => {
                restoreFails("root { action [A] entry(onEntry) }", "root { action [A] exit(onExit) }");
            });

            it("is rejected when only a subtree is different", () => {
                restoreFails(
                    "root { branch [Sub] } root [Sub] { action [A] }",
                    "root { branch [Sub] } root [Sub] { action [B] }"
                );
            });

            it("is accepted for an MDSL definition and its equivalent JSON definition", () => {
                const mdsl =
                    'root { sequence { repeat [2] entry(onEntry) { action [A, 1, "x"] while(Ok) } wait [10, 20] } }';
                const json = {
                    type: "root",
                    child: {
                        type: "sequence",
                        children: [
                            {
                                type: "repeat",
                                iterations: 2,
                                entry: { call: "onEntry" },
                                child: { type: "action", call: "A", args: [1, "x"], while: { call: "Ok" } }
                            },
                            { type: "wait", duration: [10, 20] }
                        ]
                    }
                };
                // The order of the keys is not part of a definition.
                const reordered = JSON.parse(JSON.stringify(json), (_, value) =>
                    value && typeof value === "object" && !Array.isArray(value)
                        ? Object.fromEntries(Object.entries(value).reverse())
                        : value
                );
                const agent = () => ({ ...createAgent(), Ok: () => true });
                const source = new BehaviourTree(mdsl, agent());
                source.step();

                [json, reordered, [json]].forEach((definition: any) => {
                    const tree = new BehaviourTree(definition, agent());
                    tree.restore(throughJSON(source.snapshot()));
                    assert.deepEqual(states(tree), states(source));

                    const back = new BehaviourTree(mdsl, agent());
                    back.restore(throughJSON(tree.snapshot()));
                    assert.deepEqual(states(back), states(source));
                });
            });
        });

        describe("will error and leave the tree untouched if the input", () => {
            const inputs: { [name: string]: (snapshot: any) => any } = {
                "is null": () => null,
                "is undefined": () => undefined,
                "is a string": () => "snapshot",
                "is a number": () => 42,
                "is an array": () => [],
                "is an object without the snapshot fields": () => ({ foo: "bar" }),
                "has no definition": (s) => ({ ...s, definition: undefined }),
                "has a definition that is not a string": (s) => ({ ...s, definition: 7 }),
                "has no root": (s) => ({ ...s, root: undefined })
            };

            Object.entries(inputs).forEach(([name, corrupt]) => {
                it(name, () => {
                    const tree = new BehaviourTree("root { sequence { action [A] action [B] } }", createAgent());
                    tree.step();
                    const before = JSON.stringify(tree.snapshot());

                    assert.throws(() => tree.restore(corrupt(throughJSON(tree.snapshot()))), Error);
                    assert.strictEqual(JSON.stringify(tree.snapshot()), before);
                });
            });
        });
    });
});
