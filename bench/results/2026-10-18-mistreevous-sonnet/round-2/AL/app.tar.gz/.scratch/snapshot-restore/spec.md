# Snapshot and restore tree execution state

## Goal
Long-running workflows must survive a process restart. `BehaviourTree` gets `snapshot()` and `restore(snapshot)`.

## Acceptance criteria
- `snapshot()` returns a plain object that is unchanged by `JSON.parse(JSON.stringify(x))`. Its type `TreeSnapshot` is exported.
- `restore(snapshot)` on a tree built from the same definition gives the same `getTreeNodeDetails()` states, the same agent function calls in the same order and the same result as the original tree.
- Kept: node states, composite child progress, `repeat`/`retry` counts and targets, the `lotto` pick, random `wait` durations, elapsed `wait` time.
- A restored `wait` waits only for the remaining time. Time between snapshot and restore does not count (`Date` and `getDeltaTime`).
- A finished tree restores as finished. The next `step()` starts a new run with new random choices.
- A snapshot taken from a tree of another definition, or a value that is not a snapshot, is rejected with an `Error` and the tree is left unchanged. An MDSL definition and its equivalent JSON definition are the same definition.
- README documents the API with an example. Version History and package version are updated.

## Format
`{ type, state, children?, ...node data }`, mirroring the node tree. The root also has `definition`, the canonical string of the tree definition.
Node data: wait `totalDuration`, `waitedDuration`. Repeat/retry `targetCount`, `currentCount`. Lotto `selectedChildIndex`. Action `settledPromise`.

## Decisions
- `restore()` does not call `onNodeStateChange`. Node ids are not restored.
- An action with an unsettled promise (it cannot be serialised) is saved as READY, so the restored tree calls its action function again on its next step. A settled promise result is kept.
