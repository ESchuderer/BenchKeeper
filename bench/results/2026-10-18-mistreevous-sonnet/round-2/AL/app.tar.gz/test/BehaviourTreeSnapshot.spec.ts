import { assert } from "chai";
import sinon, { SinonFakeTimers } from "sinon";

import { BehaviourTree, BehaviourTreeOptions, NodeDetails, State, TreeSnapshot } from "../src/index";

type Agent = Record<string, any> & { log: string[]; calls: Record<string, number> };

/**
 * Creates an agent whose actions stay running until they have been called a set number of times.
 * The 'work' action takes 2 calls to succeed, 'fail' takes 2 calls to fail and 'quick' succeeds immediately.
 */
const createAgent = (): Agent => {
    const agent: Agent = {
        log: [],
        calls: {},
        work: () => agent.take("work", 2, State.SUCCEEDED),
        fail: () => agent.take("fail", 2, State.FAILED),
        quick: () => agent.take("quick", 1, State.SUCCEEDED),
        take: (name: string, callsNeeded: number, result: State) => {
            agent.calls[name] = (agent.calls[name] || 0) + 1;
            agent.log.push(name);
            return agent.calls[name] % callsNeeded === 0 ? result : State.RUNNING;
        }
    };

    return agent;
};

/** Gets the node states of a tree without the per-instance node ids. */
const getStates = (details: NodeDetails): any => ({
    name: details.name,
    state: details.state,
    children: details.children?.map(getStates)
});

/**
 * Steps a tree 'stepsBefore' times, snapshots it, restores the snapshot (after a JSON round trip) into a second tree
 * and then steps both trees 'stepsAfter' times, expecting the same agent calls and node states after every step.
 */
const assertSameAfterRestore = (
    definition: string,
    stepsBefore: number,
    stepsAfter: number,
    createOptions: (random: number) => BehaviourTreeOptions = () => ({})
) => {
    const originalAgent = createAgent();
    const original = new BehaviourTree(definition, originalAgent, createOptions(0.99));
    for (let step = 0; step < stepsBefore; step++) {
        original.step();
    }

    const restoredAgent = createAgent();
    Object.assign(restoredAgent.calls, originalAgent.calls);
    // The restored tree is given a random function that would make different choices to the original tree.
    const restored = new BehaviourTree(definition, restoredAgent, createOptions(0));
    restored.restore(JSON.parse(JSON.stringify(original.snapshot())));

    assert.deepEqual(getStates(restored.getTreeNodeDetails()), getStates(original.getTreeNodeDetails()));

    originalAgent.log.length = 0;
    for (let step = 0; step < stepsAfter; step++) {
        original.step();
        restored.step();
        assert.deepEqual(getStates(restored.getTreeNodeDetails()), getStates(original.getTreeNodeDetails()));
    }

    assert.deepEqual(restoredAgent.log, originalAgent.log);
    assert.notEqual(originalAgent.log.length, 0);
};

describe("A behaviour tree", () => {
    describe("snapshot", () => {
        it("is unchanged by a JSON round trip", () => {
            const tree = new BehaviourTree(
                `root {
                    sequence {
                        repeat [2, 4] { retry [2, 4] { action [fail] } }
                        lotto { action [work] action [quick] }
                        wait [100, 500]
                    }
                }`,
                createAgent(),
                { random: () => 0.5 }
            );
            tree.step();
            tree.step();

            const snapshot: TreeSnapshot = tree.snapshot();

            assert.deepEqual(JSON.parse(JSON.stringify(snapshot)), snapshot);
        });

        it("records an action node waiting on a pending promise as not yet started", () => {
            const agent = { slow: () => new Promise<State>(() => {}) };
            const tree = new BehaviourTree("root { action [slow] }", agent);
            tree.step();

            const snapshot = tree.snapshot();

            assert.strictEqual(snapshot.children![0].state, State.READY);
            assert.notProperty(snapshot.children![0], "settledPromise");
        });
    });

    describe("restore", () => {
        it("restores the progress of composite nodes", () => {
            assertSameAfterRestore("root { sequence { action [work] action [work] action [work] } }", 3, 6);
            assertSameAfterRestore("root { selector { action [fail] action [work] action [quick] } }", 3, 6);
            assertSameAfterRestore(
                "root { parallel { action [work] sequence { action [work] action [work] } } }",
                1,
                6
            );
            assertSameAfterRestore("root { race { sequence { action [work] action [work] } action [work] } }", 1, 6);
            assertSameAfterRestore("root { all { action [work] action [fail] action [quick] } }", 1, 6);
        });

        it("restores the iteration count of a repeat node", () => {
            assertSameAfterRestore("root { repeat [3] { action [work] } }", 3, 8);
        });

        it("restores the random iteration count of a repeat node", () => {
            const createOptions = (random: number) => ({ random: () => random });
            assertSameAfterRestore("root { repeat [2, 5] { action [work] } }", 3, 6, createOptions);
        });

        it("restores the attempt count of a retry node", () => {
            assertSameAfterRestore("root { retry [3] { action [fail] } }", 3, 8);
        });

        it("restores the random attempt count of a retry node", () => {
            const createOptions = (random: number) => ({ random: () => random });
            assertSameAfterRestore("root { retry [2, 5] { action [fail] } }", 3, 6, createOptions);
        });

        it("restores the child picked by a lotto node", () => {
            const createOptions = (random: number) => ({ random: () => random });
            assertSameAfterRestore("root { lotto { action [quick] action [work] } }", 1, 1, createOptions);
        });

        it("restores the state of decorator nodes", () => {
            assertSameAfterRestore("root { flip { succeed { fail { action [work] } } } }", 1, 4);
        });

        it("restores a tree that has not been stepped", () => {
            const tree = new BehaviourTree("root { action [work] }", createAgent());
            tree.restore(tree.snapshot());

            assert.strictEqual(tree.getState(), State.READY);
        });

        describe("restores a wait node that only waits for the remaining time", () => {
            let clock: SinonFakeTimers;

            beforeEach(() => {
                clock = sinon.useFakeTimers();
            });

            afterEach(() => {
                clock.restore();
            });

            it("when using the clock", () => {
                const original = new BehaviourTree("root { wait [1000] }", {});
                original.step();
                clock.tick(400);
                const snapshot = JSON.parse(JSON.stringify(original.snapshot()));

                // The time between the snapshot and the restore does not count.
                clock.tick(60 * 60 * 1000);
                const restored = new BehaviourTree("root { wait [1000] }", {});
                restored.restore(snapshot);

                restored.step();
                assert.strictEqual(restored.getState(), State.RUNNING);
                clock.tick(599);
                restored.step();
                assert.strictEqual(restored.getState(), State.RUNNING);
                clock.tick(1);
                restored.step();
                assert.strictEqual(restored.getState(), State.SUCCEEDED);
            });

            it("when using getDeltaTime", () => {
                const options = { getDeltaTime: () => 0.1 };
                const original = new BehaviourTree("root { wait [1000] }", {}, options);
                for (let step = 0; step < 4; step++) {
                    original.step();
                }
                const snapshot = JSON.parse(JSON.stringify(original.snapshot()));

                clock.tick(60 * 60 * 1000);
                const restored = new BehaviourTree("root { wait [1000] }", {}, options);
                restored.restore(snapshot);

                for (let step = 0; step < 5; step++) {
                    restored.step();
                    assert.strictEqual(restored.getState(), State.RUNNING);
                }
                restored.step();
                assert.strictEqual(restored.getState(), State.SUCCEEDED);
            });

            it("when the duration was picked at random", () => {
                const original = new BehaviourTree("root { wait [100, 1000] }", {}, { random: () => 0.99 });
                original.step();
                clock.tick(900);
                const snapshot = JSON.parse(JSON.stringify(original.snapshot()));

                // This random function would have picked a duration of 100ms.
                const restored = new BehaviourTree("root { wait [100, 1000] }", {}, { random: () => 0 });
                restored.restore(snapshot);

                restored.step();
                assert.strictEqual(restored.getState(), State.RUNNING);
                clock.tick(100);
                restored.step();
                assert.strictEqual(restored.getState(), State.SUCCEEDED);
            });
        });

        it("restores a finished tree as finished and starts a new run with new random choices on the next step", () => {
            const random = sinon.stub().returns(0.99);
            const original = new BehaviourTree("root { repeat [1, 3] { action [quick] } }", createAgent(), { random });
            for (let step = 0; step < 4; step++) {
                original.step();
            }
            assert.strictEqual(original.getState(), State.SUCCEEDED);

            const restoredRandom = sinon.stub().returns(0);
            const restoredAgent = createAgent();
            const restored = new BehaviourTree("root { repeat [1, 3] { action [quick] } }", restoredAgent, {
                random: restoredRandom
            });
            restored.restore(JSON.parse(JSON.stringify(original.snapshot())));

            assert.strictEqual(restored.getState(), State.SUCCEEDED);
            assert.isFalse(restoredRandom.called);

            // The new run makes its own random choice, which is 1 iteration.
            restored.step();
            assert.isTrue(restoredRandom.calledOnce);
            restored.step();
            assert.strictEqual(restored.getState(), State.SUCCEEDED);
            assert.strictEqual(restoredAgent.log.length, 1);
        });

        it("restores an action node that had a settled promise without calling its function again", async () => {
            const createPromiseAgent = (outcome: "resolve" | "reject") => ({
                calls: 0,
                run() {
                    this.calls += 1;
                    return outcome === "resolve" ? Promise.resolve(State.SUCCEEDED) : Promise.reject("nope");
                }
            });

            for (const outcome of ["resolve", "reject"] as const) {
                const originalAgent = createPromiseAgent(outcome);
                const original = new BehaviourTree("root { action [run] }", originalAgent);
                original.step();
                await Promise.resolve();
                const snapshot = JSON.parse(JSON.stringify(original.snapshot()));

                const restoredAgent = createPromiseAgent(outcome);
                const restored = new BehaviourTree("root { action [run] }", restoredAgent);
                restored.restore(snapshot);

                if (outcome === "resolve") {
                    restored.step();
                    assert.strictEqual(restored.getState(), State.SUCCEEDED);
                } else {
                    assert.throws(() => restored.step(), Error, "action function 'run' promise rejected with 'nope'");
                }
                assert.strictEqual(restoredAgent.calls, 0);
            }
        });

        it("does not call the onNodeStateChange option", () => {
            const original = new BehaviourTree("root { action [work] }", createAgent());
            original.step();

            const onNodeStateChange = sinon.spy();
            const restored = new BehaviourTree("root { action [work] }", createAgent(), { onNodeStateChange });
            restored.restore(original.snapshot());

            assert.isFalse(onNodeStateChange.called);
            assert.strictEqual(restored.getState(), State.RUNNING);
        });

        it("does not call the onNodeStateChange option for any node type and reports changes as usual on the next step", () => {
            const definition = `root {
                sequence {
                    repeat [2] { action [quick] }
                    retry [2] { condition [no] }
                    lotto { wait [100] action [work] }
                    flip { succeed { fail { wait [100] } } }
                    parallel { action [work] condition [yes] }
                }
            }`;
            const createAgentWithConditions = () => ({ ...createAgent(), yes: () => true, no: () => false });
            const original = new BehaviourTree(definition, createAgentWithConditions(), { random: () => 0 });
            for (let step = 0; step < 4; step++) {
                original.step();
            }

            const onNodeStateChange = sinon.spy();
            const restored = new BehaviourTree(definition, createAgentWithConditions(), {
                onNodeStateChange,
                random: () => 0
            });
            restored.restore(JSON.parse(JSON.stringify(original.snapshot())));
            assert.isFalse(onNodeStateChange.called);

            restored.step();
            assert.isTrue(onNodeStateChange.called);
        });

        describe("keeps a snapshot independent of the trees", () => {
            let clock: SinonFakeTimers;

            beforeEach(() => {
                clock = sinon.useFakeTimers();
            });

            afterEach(() => {
                clock.restore();
            });

            const definition = `root {
                sequence {
                    repeat [2, 4] { retry [2, 4] { action [fail] } }
                    lotto { action [work] action [quick] }
                    action [settled]
                    wait [100, 500]
                }
            }`;
            const createSettledAgent = () => ({ ...createAgent(), settled: () => Promise.resolve(State.SUCCEEDED) });
            const copy = (snapshot: TreeSnapshot) => JSON.parse(JSON.stringify(snapshot));
            const stepAndWait = async (tree: BehaviourTree) => {
                tree.step();
                clock.tick(50);
                await Promise.resolve();
            };

            it("when the tree that took it is stepped", async () => {
                const tree = new BehaviourTree(definition, createSettledAgent(), { random: () => 0.5 });
                for (let step = 0; step < 12; step++) {
                    await stepAndWait(tree);
                }

                const snapshot = tree.snapshot();
                const before = copy(snapshot);
                for (let step = 0; step < 12; step++) {
                    await stepAndWait(tree);
                }

                assert.deepEqual(snapshot, before);
            });

            it("when the tree that restored it is stepped", async () => {
                const source = new BehaviourTree(definition, createSettledAgent(), { random: () => 0.5 });
                for (let step = 0; step < 12; step++) {
                    await stepAndWait(source);
                }
                const snapshot = source.snapshot();
                const before = copy(snapshot);

                const restored = new BehaviourTree(definition, createSettledAgent(), { random: () => 0.5 });
                restored.restore(snapshot);
                for (let step = 0; step < 12; step++) {
                    await stepAndWait(restored);
                }

                assert.deepEqual(snapshot, before);
            });

            it("and a snapshot taken after restoring, before any step, equals it however much time has passed", () => {
                const source = new BehaviourTree("root { wait [1000] }", {});
                source.step();
                clock.tick(400);
                const snapshot = source.snapshot();

                const restored = new BehaviourTree("root { wait [1000] }", {});
                restored.restore(snapshot);
                clock.tick(10);

                assert.deepEqual(copy(restored.snapshot()), copy(snapshot));
            });

            it("and a snapshot taken straight after restoring equals it", async () => {
                const source = new BehaviourTree(definition, createSettledAgent(), { random: () => 0.5 });
                for (let step = 0; step < 12; step++) {
                    await stepAndWait(source);

                    const snapshot = source.snapshot();
                    const restored = new BehaviourTree(definition, createSettledAgent(), { random: () => 0.5 });
                    restored.restore(snapshot);

                    assert.deepEqual(copy(restored.snapshot()), copy(snapshot), `after step ${step + 1}`);
                }
            });
        });

        it("calls the function of an action node that had a pending promise again on the next step", () => {
            const definition = "root { sequence { action [slow] wait [10] } }";
            const original = new BehaviourTree(definition, { slow: () => new Promise<State>(() => {}) });
            original.step();
            const snapshot = JSON.parse(JSON.stringify(original.snapshot()));

            const restoredAgent = { slow: sinon.stub().returns(new Promise<State>(() => {})) };
            const restored = new BehaviourTree(definition, restoredAgent);
            restored.restore(snapshot);

            assert.isFalse(restoredAgent.slow.called);
            restored.step();
            assert.isTrue(restoredAgent.slow.calledOnce);
            assert.strictEqual(restored.getState(), State.RUNNING);
        });

        describe("accepts a snapshot of the same definition", () => {
            const mdsl = `root {
                sequence {
                    action [work, 1, "a", true] while(isOk)
                    repeat [2] { wait [100] }
                    branch [other]
                }
            }
            root [other] { action [quick] }`;
            const json = [
                {
                    type: "root",
                    child: {
                        type: "sequence",
                        children: [
                            { type: "action", call: "work", args: [1, "a", true], while: { call: "isOk" } },
                            { type: "repeat", iterations: 2, child: { type: "wait", duration: 100 } },
                            { type: "branch", ref: "other" }
                        ]
                    }
                },
                { type: "root", id: "other", child: { type: "action", call: "quick" } }
            ];

            const assertRestores = (from: any, to: any) => {
                const source = new BehaviourTree(from, { ...createAgent(), isOk: () => true });
                source.step();
                const tree = new BehaviourTree(to, { ...createAgent(), isOk: () => true });

                tree.restore(JSON.parse(JSON.stringify(source.snapshot())));

                assert.deepEqual(getStates(tree.getTreeNodeDetails()), getStates(source.getTreeNodeDetails()));
            };

            it("from an MDSL definition into a JSON definition", () => assertRestores(mdsl, json));

            it("from a JSON definition into an MDSL definition", () => assertRestores(json, mdsl));

            it("from a JSON definition with its properties in another order", () => {
                const reordered = JSON.parse(JSON.stringify(json), (_, value) =>
                    value && typeof value === "object" && !Array.isArray(value)
                        ? Object.fromEntries(Object.entries(value).reverse())
                        : value
                );
                assertRestores(json, reordered);
            });
        });

        describe("throws and leaves the tree unchanged if the snapshot", () => {
            const definition = "root { sequence { action [work] action [work] } }";

            const assertRejected = (modify: (snapshot: any) => void, message: string) => {
                const source = new BehaviourTree(definition, createAgent());
                source.step();
                const snapshot = JSON.parse(JSON.stringify(source.snapshot()));
                modify(snapshot);

                const tree = new BehaviourTree(definition, createAgent());
                const before = JSON.stringify(tree.snapshot());

                assert.throws(() => tree.restore(snapshot), Error, message);
                assert.strictEqual(JSON.stringify(tree.snapshot()), before);
            };

            it("is not an object", () => {
                const tree = new BehaviourTree(definition, createAgent());
                assert.throws(() => tree.restore(null as any), Error, "invalid snapshot");
            });

            it("is not a snapshot", () => {
                const source = new BehaviourTree(definition, createAgent());
                source.step();
                const { definition: _, ...withoutDefinition } = source.snapshot();

                const tree = new BehaviourTree(definition, createAgent());
                const before = JSON.stringify(tree.snapshot());
                const notSnapshots = [undefined, "snapshot", 42, true, [], [source.snapshot()], {}, { type: "root" }];

                [...notSnapshots, withoutDefinition].forEach((notASnapshot) => {
                    assert.throws(() => tree.restore(notASnapshot as any), Error, "invalid snapshot");
                    assert.strictEqual(JSON.stringify(tree.snapshot()), before);
                });
            });

            describe("is of another definition", () => {
                const assertOtherDefinition = (other: string) => {
                    const source = new BehaviourTree(other, createAgent());
                    source.step();

                    const tree = new BehaviourTree(definition, createAgent());
                    tree.step();
                    const before = JSON.stringify(tree.snapshot());

                    assert.throws(
                        () => tree.restore(JSON.parse(JSON.stringify(source.snapshot()))),
                        Error,
                        "the snapshot does not match the tree's definition"
                    );
                    assert.strictEqual(JSON.stringify(tree.snapshot()), before);
                };

                it("with another action", () =>
                    assertOtherDefinition("root { sequence { action [work] action [quick] } }"));

                it("with other action arguments", () =>
                    assertOtherDefinition("root { sequence { action [work, 1] action [work] } }"));

                it("with an attribute added", () =>
                    assertOtherDefinition("root { sequence { action [work] action [work] entry(work) } }"));

                it("with another node type of the same shape", () =>
                    assertOtherDefinition("root { selector { action [work] action [work] } }"));

                it("with another wait duration", () => {
                    const source = new BehaviourTree("root { wait [100] }", createAgent());
                    const tree = new BehaviourTree("root { wait [200] }", createAgent());

                    assert.throws(() => tree.restore(source.snapshot()), Error, "does not match the tree's definition");
                });
            });

            it("has a node of the wrong type", () => {
                assertRejected((s) => (s.children[0].children[1].type = "wait"), "invalid snapshot");
            });

            it("has the wrong number of children", () => {
                assertRejected((s) => s.children[0].children.pop(), "invalid snapshot");
            });

            it("has an unknown node state", () => {
                assertRejected((s) => (s.children[0].children[0].state = "bogus"), "invalid snapshot");
            });
        });
    });
});
