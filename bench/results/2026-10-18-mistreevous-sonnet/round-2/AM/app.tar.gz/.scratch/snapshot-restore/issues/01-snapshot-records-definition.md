# Snapshot records its definition

Status: ready-for-agent

## Goal
`restore()` must not apply a snapshot taken from another definition, as that corrupts the tree.

## Acceptance
- Each snapshot records the definition it was taken from. An MDSL definition and its equivalent JSON definition are the same definition.
- `restore()` throws an `Error` saying that the snapshot does not match the tree's definition when the definition differs, also when the node structure is identical (other action arguments, other wait duration).
- `restore()` throws an `Error` for input that is not a snapshot: `null`, a string, a number, an array, an object without the snapshot's fields.
- A rejected `restore()` leaves the tree exactly as it was.
