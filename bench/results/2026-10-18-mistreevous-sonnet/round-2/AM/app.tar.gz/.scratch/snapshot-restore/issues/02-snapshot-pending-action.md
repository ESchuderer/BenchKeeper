# Snapshot of an action with a pending promise

Status: ready-for-agent

## Goal
`snapshot()` no longer throws while an action promise is pending.

## Acceptance
- A pending action is saved as not yet started (state `READY`). The restored tree calls its action function again on its next step, and its `entry` callback runs again.
- The tree that was snapshotted is not changed by `snapshot()`.
- The README documents this limitation next to the snapshot API.
