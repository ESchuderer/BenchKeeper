# Snapshot and restore of tree execution state

Status: ready-for-agent

## Goal
`BehaviourTree.snapshot()` returns the execution state as JSON-safe data. `restore(snapshot)` sets a tree built from the same definition to that state.

## Format
`{ version: 1, definition: string, root: NodeSnapshot }`. `definition` identifies the tree definition (MDSL and equivalent JSON give the same value). A `NodeSnapshot` mirrors the tree: `type`, `name`, `state`, `children`, plus per type:
- `repeat`, `retry`: `targetCount`, `currentCount`
- `lotto`: `selectedChild` (index)
- `wait`: `totalDuration`, `waitedDuration` (ms)
- `action`: `promiseResult` when an action promise settled and was not yet consumed

## Decisions
- `restore` validates the whole snapshot before it changes anything.
- `restore` fires no `onNodeStateChange`, entry, exit or step callbacks and draws no random numbers.
- Node ids are not part of the snapshot.
- `wait`: waited time is stored, not timestamps. Time between snapshot and restore does not count (clock and `getDeltaTime`).
- `restore` throws if the input is not a snapshot or its `definition` differs from the tree's.
- An action whose promise is pending is snapshotted as not yet started (`READY`), as a promise cannot be serialized. The restored tree calls its action function again.

## Acceptance
- A restored tree and the source tree show the same node states, call the same agent functions in the same order and reach the same result, from any snapshot point.
- A snapshot of a finished tree restores as finished, the next `step()` draws random values again.
- README documents the API with an example, Version History row, version 4.4.0.
