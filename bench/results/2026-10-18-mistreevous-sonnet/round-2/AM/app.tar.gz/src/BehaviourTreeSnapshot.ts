import State from "./State";
import { NodeDetails, NodeSnapshot } from "./nodes/Node";
import { RootNodeDefinition } from "./BehaviourTreeDefinition";

/**
 * The execution state of a behaviour tree, as plain data that survives `JSON.stringify` and `JSON.parse` unchanged.
 */
export type BehaviourTreeSnapshot = {
    /**
     * The snapshot format version.
     */
    version: 1;
    /**
     * The identifier of the tree definition that the snapshot was taken from. An MDSL definition and its equivalent JSON definition have the same identifier.
     */
    definition: string;
    /**
     * The snapshot of the root node, which holds the snapshots of every nested node.
     */
    root: NodeSnapshot;
};

const isObject = (value: unknown): value is Record<string, unknown> =>
    typeof value === "object" && value !== null && !Array.isArray(value);
const isCount = (value: unknown) => Number.isInteger(value) && (value as number) >= 0;
const isDuration = (value: unknown) => typeof value === "number" && Number.isFinite(value) && value >= 0;

/**
 * Orders the keys of an object and fills in the values that the MDSL parser always sets but a JSON definition may leave out.
 * Used as a `JSON.stringify` replacer.
 */
const canonicalise = (key: string, value: unknown): unknown => {
    if (!isObject(value)) {
        return value;
    }

    const node = { ...value };

    if (typeof node.call === "string") {
        node.args ??= [];
    }

    if (key === "while" || key === "until") {
        node.succeedOnAbort ??= false;
    }

    return Object.fromEntries(Object.entries(node).sort(([a], [b]) => (a < b ? -1 : 1)));
};

/**
 * Gets the identifier of a tree definition, a hash of the definition in a form that does not depend on whether it was written as MDSL or JSON.
 * Subtrees registered with `BehaviourTree.register` are not part of the definition.
 * @param definition The root node definitions of the tree.
 * @returns The definition identifier.
 */
export const getDefinitionId = (definition: RootNodeDefinition[]): string => {
    const text = JSON.stringify(
        [...definition].sort((a, b) => ((a.id ?? "") < (b.id ?? "") ? -1 : 1)),
        canonicalise
    );

    // The cyrb53 string hash, as the `crypto` module is not available in browsers.
    let h1 = 0xdeadbeef;
    let h2 = 0x41c6ce57;

    for (let index = 0; index < text.length; index++) {
        const code = text.charCodeAt(index);
        h1 = Math.imul(h1 ^ code, 2654435761);
        h2 = Math.imul(h2 ^ code, 1597334677);
    }

    h1 = Math.imul(h1 ^ (h1 >>> 16), 2246822507) ^ Math.imul(h2 ^ (h2 >>> 13), 3266489909);
    h2 = Math.imul(h2 ^ (h2 >>> 16), 2246822507) ^ Math.imul(h1 ^ (h1 >>> 13), 3266489909);

    return (4294967296 * (2097151 & h2) + (h1 >>> 0)).toString(16);
};

/**
 * Checks the fields that are specific to the type of node.
 * @param snapshot The node snapshot.
 * @param details The details of the node.
 * @returns Whether the node type specific fields are valid.
 */
const hasValidData = (snapshot: Record<string, unknown>, details: NodeDetails): boolean => {
    switch (details.type) {
        case "repeat":
        case "retry":
            return (snapshot.targetCount === null || isCount(snapshot.targetCount)) && isCount(snapshot.currentCount);
        case "lotto":
            // A running lotto node has always picked a child, but one resolved by a guard on its first visit has not.
            return snapshot.selectedChild === null
                ? snapshot.state !== State.RUNNING
                : isCount(snapshot.selectedChild) && (snapshot.selectedChild as number) < details.children!.length;
        case "wait":
            // A negative delta time can make the waited duration negative.
            return (
                (snapshot.totalDuration === null || isDuration(snapshot.totalDuration)) &&
                Number.isFinite(snapshot.waitedDuration)
            );
        case "action": {
            const result = snapshot.promiseResult;
            return (
                result === undefined ||
                (isObject(result) && typeof result.isResolved === "boolean" && typeof result.value === "string")
            );
        }
        default:
            return true;
    }
};

/**
 * Validates a node snapshot against the details of the node it is going to be applied to.
 * @param snapshot The node snapshot.
 * @param details The details of the node.
 * @param path The path of the node, used in error messages.
 * @returns The error message, or undefined if the snapshot is valid for the node.
 */
const validateNodeSnapshot = (snapshot: unknown, details: NodeDetails, path: string): string | undefined => {
    if (!isObject(snapshot)) {
        return `expected an object for node at '${path}'`;
    }

    if (snapshot.type !== details.type || snapshot.name !== details.name) {
        return `expected ${details.type} node '${details.name}' at '${path}'`;
    }

    if (!Object.values(State).includes(snapshot.state as State)) {
        return `invalid state for node at '${path}'`;
    }

    const children = details.children;

    if (children) {
        if (!Array.isArray(snapshot.children) || snapshot.children.length !== children.length) {
            return `expected ${children.length} children for node at '${path}'`;
        }

        for (let index = 0; index < children.length; index++) {
            const error = validateNodeSnapshot(snapshot.children[index], children[index], `${path}/${index}`);

            if (error) {
                return error;
            }
        }
    }

    return hasValidData(snapshot, details) ? undefined : `invalid ${details.type} data for node at '${path}'`;
};

/**
 * Validates a snapshot against the tree it is going to be restored into.
 * @param snapshot The behaviour tree snapshot.
 * @param details The details of the root node of the tree.
 * @param definitionId The identifier of the definition of the tree.
 * @throws An error if the snapshot is not valid for the tree.
 */
export const validateSnapshot = (snapshot: unknown, details: NodeDetails, definitionId: string): void => {
    const error = !isObject(snapshot)
        ? "expected an object"
        : snapshot.version !== 1
        ? `unsupported version '${snapshot.version}'`
        : typeof snapshot.definition !== "string"
        ? "expected a definition"
        : snapshot.definition !== definitionId
        ? "the snapshot does not match the tree's definition"
        : validateNodeSnapshot(snapshot.root, details, "root");

    if (error) {
        throw new Error(`invalid snapshot: ${error}`);
    }
};
