import { assert } from "chai";
import sinon, { SinonFakeTimers } from "sinon";

import { BehaviourTree, BehaviourTreeSnapshot, NodeDetails, State } from "../src/index";

type Result = State.SUCCEEDED | State.FAILED | undefined;

type World = {
    step: number;
    delta: number;
    script: { [name: string]: (step: number) => Result };
};

/** A cyclic pseudo-random sequence that counts its draws. 'start' is the position to continue from. */
const makeRandom = (values: number[], start = 0) => {
    let drawn = start;
    return { fn: () => values[drawn++ % values.length], drawn: () => drawn };
};

/** Node ids are generated per tree instance, so they are left out when comparing trees. */
const stripIds = (details: NodeDetails): any => ({
    ...details,
    id: undefined,
    children: details.children?.map(stripIds)
});

const createAgent = (world: World, log: string[]) => ({
    Act: (name: string) => {
        log.push(name);
        return world.script[name](world.step);
    },
    Log: (message: string) => {
        log.push(message);
    },
    IsOpen: () => {
        log.push("IsOpen");
        return world.step < 6;
    }
});

const from = (step: number, result: State.SUCCEEDED | State.FAILED) => (s: number) => s >= step ? result : undefined;

/**
 * Steps a tree 'at' times, snapshots it (through JSON), restores the snapshot into a fresh tree and then steps both
 * trees in lockstep until 'steps', asserting that they stay identical. Returns the agent calls made by the restored tree.
 */
const resumeAt = (definition: string, script: World["script"], at: number, steps: number, randoms: number[]) => {
    const world: World = { step: 0, delta: 1, script };
    const sourceLog: string[] = [];
    const targetLog: string[] = [];
    const sourceRandom = makeRandom(randoms);
    const sourceTree = new BehaviourTree(definition, createAgent(world, sourceLog), {
        random: sourceRandom.fn,
        getDeltaTime: () => world.delta
    });

    for (world.step = 0; world.step < at; world.step++) {
        sourceTree.step();
    }

    const snapshot: BehaviourTreeSnapshot = JSON.parse(JSON.stringify(sourceTree.snapshot()));
    assert.deepEqual(snapshot, sourceTree.snapshot());

    const targetRandom = makeRandom(randoms, sourceRandom.drawn());
    const targetTree = new BehaviourTree(definition, createAgent(world, targetLog), {
        random: targetRandom.fn,
        getDeltaTime: () => world.delta
    });
    targetTree.restore(snapshot);

    assert.deepEqual(targetLog, [], "restore must not call agent functions");
    assert.equal(targetRandom.drawn(), sourceRandom.drawn(), "restore must not draw random numbers");
    assert.deepEqual(stripIds(targetTree.getTreeNodeDetails()), stripIds(sourceTree.getTreeNodeDetails()));

    sourceLog.length = 0;

    for (; world.step < steps; world.step++) {
        sourceTree.step();
        targetTree.step();
        assert.deepEqual(stripIds(targetTree.getTreeNodeDetails()), stripIds(sourceTree.getTreeNodeDetails()));
    }

    assert.deepEqual(targetLog, sourceLog);

    return targetLog;
};

/** Runs the lockstep comparison for every possible snapshot point. */
const resumeAtEveryStep = (definition: string, script: World["script"], steps = 14, randoms = [0.1, 0.8, 0.4, 0.6]) => {
    for (let at = 0; at <= steps; at++) {
        resumeAt(definition, script, at, steps, randoms);
    }
};

describe("A behaviour tree", () => {
    describe("restored from a snapshot behaves exactly like the tree that was snapshotted for", () => {
        it("a sequence", () => {
            const definition = 'root { sequence { action [Act, "a"] action [Act, "b"] action [Act, "c"] } }';
            const script: World["script"] = {
                a: from(1, State.SUCCEEDED),
                b: from(4, State.SUCCEEDED),
                c: from(6, State.SUCCEEDED)
            };

            resumeAtEveryStep(definition, script);

            // After step 2 'a' has succeeded and 'b' is running, so 'a' is not called again.
            assert.deepEqual(resumeAt(definition, script, 3, 7, [0.5]), ["b", "b", "c", "c", "c"]);
        });

        it("a selector", () => {
            resumeAtEveryStep('root { selector { action [Act, "a"] action [Act, "b"] action [Act, "c"] } }', {
                a: from(2, State.FAILED),
                b: from(5, State.FAILED),
                c: from(8, State.SUCCEEDED)
            });
        });

        it("a parallel", () => {
            resumeAtEveryStep('root { parallel { action [Act, "a"] action [Act, "b"] } }', {
                a: from(3, State.SUCCEEDED),
                b: from(5, State.SUCCEEDED)
            });
        });

        it("a race", () => {
            resumeAtEveryStep('root { race { action [Act, "a"] action [Act, "b"] } }', {
                a: from(5, State.SUCCEEDED),
                b: from(3, State.SUCCEEDED)
            });
        });

        it("an all", () => {
            resumeAtEveryStep('root { all { action [Act, "a"] action [Act, "b"] } }', {
                a: from(3, State.FAILED),
                b: from(5, State.SUCCEEDED)
            });
        });

        it("flip, succeed and fail", () => {
            resumeAtEveryStep(
                'root { sequence { flip { action [Act, "a"] } succeed { action [Act, "b"] } fail { action [Act, "c"] } } }',
                { a: from(2, State.FAILED), b: from(4, State.FAILED), c: from(6, State.SUCCEEDED) }
            );
        });

        it("a repeat with a fixed number of iterations", () => {
            const definition = 'root { repeat [3] { sequence { action [Act, "a"] action [Act, "b"] } } }';
            const script: World["script"] = {
                a: from(0, State.SUCCEEDED),
                b: (step) => (step % 3 === 0 ? State.SUCCEEDED : undefined)
            };

            resumeAtEveryStep(definition, script, 20);

            // Two of three iterations are done after step 3, the third one finishes on step 6 and step 7 does nothing.
            assert.deepEqual(resumeAt(definition, script, 4, 8, [0.5]), ["a", "b", "b", "b"]);
        });

        it("a repeat with a random number of iterations", () => {
            resumeAtEveryStep(
                'root { repeat [2, 4] { action [Act, "a"] } }',
                { a: (s) => (s % 2 ? State.SUCCEEDED : undefined) },
                20
            );
        });

        it("a retry with a fixed number of attempts", () => {
            const script: World["script"] = {
                a: (s) => [State.FAILED, undefined, State.FAILED, undefined, State.SUCCEEDED][s % 5] as Result
            };

            resumeAtEveryStep('root { retry [3] { action [Act, "a"] } }', script, 20);
            resumeAtEveryStep('root { retry [2] { action [Act, "a"] } }', script, 20);
        });

        it("a retry with a random number of attempts", () => {
            resumeAtEveryStep(
                'root { retry [2, 4] { action [Act, "a"] } }',
                { a: (s) => (s % 3 === 2 ? State.FAILED : undefined) },
                20
            );
        });

        it("a lotto", () => {
            resumeAtEveryStep(
                'root { lotto [1, 3] { action [Act, "a"] action [Act, "b"] } }',
                { a: from(2, State.SUCCEEDED), b: from(3, State.FAILED) },
                20,
                [0.05, 0.95, 0.5]
            );
        });

        it("a wait", () => {
            resumeAtEveryStep('root { sequence { wait [3000] action [Act, "a"] } }', { a: from(0, State.SUCCEEDED) });
        });

        it("a wait with a random duration", () => {
            resumeAtEveryStep(
                'root { sequence { wait [1000, 5000] action [Act, "a"] } }',
                { a: from(0, State.SUCCEEDED) },
                20,
                [0.1, 0.9, 0.5]
            );
        });

        it("nested nodes with random choices", () => {
            resumeAtEveryStep(
                'root { repeat [1, 3] { lotto { action [Act, "a"] sequence { wait [2000] action [Act, "b"] } } } }',
                { a: (s) => (s % 2 ? State.SUCCEEDED : undefined), b: from(0, State.SUCCEEDED) },
                30
            );
        });

        it("a tree with branches", () => {
            resumeAtEveryStep(
                'root { sequence { branch [Sub] action [Act, "b"] } } root [Sub] { repeat [2] { action [Act, "a"] } }',
                { a: (s) => (s % 2 ? State.SUCCEEDED : undefined), b: from(5, State.SUCCEEDED) }
            );
        });

        it("a lotto that a guard resolved before it picked a child", () => {
            resumeAtEveryStep(
                'root { lotto until(IsOpen) { action [Act, "a"] } }',
                { a: from(2, State.SUCCEEDED) },
                12
            );
        });

        it("a tree with callbacks and guards", () => {
            resumeAtEveryStep(
                'root { sequence { action [Act, "a"] entry(Log, "entry-a") exit(Log, "exit-a") while(IsOpen) action [Act, "b"] step(Log, "step-b") } }',
                { a: from(2, State.SUCCEEDED), b: from(8, State.SUCCEEDED) },
                12
            );
        });
    });

    describe("snapshotted with a wait that has a negative waited duration", () => {
        it("restores the snapshot", () => {
            const options = { getDeltaTime: () => -1 };
            const sourceTree = new BehaviourTree("root { wait [1000] }", {}, options);
            sourceTree.step();

            const targetTree = new BehaviourTree("root { wait [1000] }", {}, options);
            targetTree.restore(JSON.parse(JSON.stringify(sourceTree.snapshot())));

            assert.equal(targetTree.getState(), State.RUNNING);
        });
    });

    describe("restored from the snapshot of a finished tree", () => {
        const cases: [string, string][] = [
            ["repeat", 'root { repeat [1, 3] { action [Act, "a"] } }'],
            ["lotto", 'root { lotto { action [Act, "a"] action [Act, "a"] } }'],
            ["wait", "root { wait [1000, 5000] }"]
        ];

        cases.forEach(([name, definition]) => {
            it(`is finished and makes new random choices on the next step (${name})`, () => {
                const world: World = { step: 0, delta: 10, script: { a: from(0, State.SUCCEEDED) } };
                const sourceTree = new BehaviourTree(definition, createAgent(world, []), {
                    random: makeRandom([0.5]).fn,
                    getDeltaTime: () => world.delta
                });

                while (sourceTree.getState() !== State.SUCCEEDED) {
                    sourceTree.step();
                }

                const targetRandom = makeRandom([0.99]);
                const targetTree = new BehaviourTree(definition, createAgent(world, []), {
                    random: targetRandom.fn,
                    getDeltaTime: () => world.delta
                });
                targetTree.restore(JSON.parse(JSON.stringify(sourceTree.snapshot())));

                assert.equal(targetTree.getState(), State.SUCCEEDED);
                assert.equal(targetRandom.drawn(), 0);

                targetTree.step();

                assert.equal(targetRandom.drawn(), 1);
            });
        });
    });

    describe("restoring a snapshot", () => {
        let clock: SinonFakeTimers;

        beforeEach(() => {
            clock = sinon.useFakeTimers();
        });

        afterEach(() => {
            clock.restore();
        });

        it("makes a wait node wait only for the remaining time, whatever the clock did in between", () => {
            const sourceTree = new BehaviourTree("root { wait [1000] }", {});
            sourceTree.step();
            clock.tick(400);

            const snapshot = JSON.parse(JSON.stringify(sourceTree.snapshot()));
            clock.tick(100000);

            const targetTree = new BehaviourTree("root { wait [1000] }", {});
            targetTree.restore(snapshot);

            targetTree.step();
            assert.equal(targetTree.getState(), State.RUNNING);

            clock.tick(599);
            targetTree.step();
            assert.equal(targetTree.getState(), State.RUNNING);

            clock.tick(1);
            targetTree.step();
            assert.equal(targetTree.getState(), State.SUCCEEDED);
        });

        it("makes a wait node using 'getDeltaTime' wait only for the remaining time", () => {
            const options = { getDeltaTime: () => 0.4 };

            const sourceTree = new BehaviourTree("root { wait [1000] }", {}, options);
            sourceTree.step();
            sourceTree.step();
            assert.equal(sourceTree.getState(), State.RUNNING);

            const snapshot = JSON.parse(JSON.stringify(sourceTree.snapshot()));
            clock.tick(100000);

            const targetTree = new BehaviourTree("root { wait [1000] }", {}, options);
            targetTree.restore(snapshot);

            // 800ms were waited before the snapshot, 400ms more is enough.
            targetTree.step();
            assert.equal(targetTree.getState(), State.SUCCEEDED);
        });

        it("keeps a wait node without a duration waiting", () => {
            const sourceTree = new BehaviourTree("root { wait }", {});
            sourceTree.step();

            const targetTree = new BehaviourTree("root { wait }", {});
            targetTree.restore(JSON.parse(JSON.stringify(sourceTree.snapshot())));
            clock.tick(100000);
            targetTree.step();

            assert.equal(targetTree.getState(), State.RUNNING);
        });
    });

    describe("restoring a snapshot", () => {
        const definition = 'root { sequence { action [Act, "a"] repeat [2] { action [Act, "b"] } } }';
        const world: World = { step: 0, delta: 1, script: { a: from(0, State.SUCCEEDED), b: () => undefined } };

        const createSteppedTree = (options = {}) => {
            const tree = new BehaviourTree(definition, createAgent(world, []), options);
            tree.step();
            return tree;
        };

        it("does not call onNodeStateChange", () => {
            const snapshot = createSteppedTree().snapshot();
            const onNodeStateChange = sinon.spy();

            new BehaviourTree(definition, createAgent(world, []), { onNodeStateChange }).restore(snapshot);

            assert.isTrue(onNodeStateChange.notCalled);
        });

        it("can rewind the tree it was taken from", () => {
            const tree = createSteppedTree();
            const snapshot = tree.snapshot();
            const details = stripIds(tree.getTreeNodeDetails());

            tree.reset();
            tree.restore(snapshot);

            assert.deepEqual(stripIds(tree.getTreeNodeDetails()), details);
        });

        it("restores a snapshot of an unstepped tree as ready", () => {
            const tree = createSteppedTree();

            tree.restore(new BehaviourTree(definition, createAgent(world, [])).snapshot());

            assert.equal(tree.getState(), State.READY);
        });

        describe("throws and leaves the tree unchanged if", () => {
            const expectInvalid = (change: (snapshot: any) => void) => {
                const tree = createSteppedTree();
                const before = stripIds(tree.getTreeNodeDetails());
                const snapshot = JSON.parse(JSON.stringify(tree.snapshot()));
                change(snapshot);

                assert.throws(() => tree.restore(snapshot), Error, "invalid snapshot");
                assert.deepEqual(stripIds(tree.getTreeNodeDetails()), before);
            };

            it("the snapshot is not an object", () => {
                assert.throws(() => createSteppedTree().restore("snapshot" as any), Error, "invalid snapshot");
                assert.throws(() => createSteppedTree().restore(null as any), Error, "invalid snapshot");
            });
            it("the version is not supported", () => expectInvalid((s) => (s.version = 2)));
            it("a node state is not valid", () =>
                expectInvalid((s) => (s.root.children[0].children[1].state = "nope")));
            it("a node type differs", () => expectInvalid((s) => (s.root.children[0].children[0].type = "condition")));
            it("a node name differs", () => expectInvalid((s) => (s.root.children[0].children[0].name = "other")));
            it("a node has a different number of children", () =>
                expectInvalid((s) => s.root.children[0].children.pop()));
            it("an iteration count is invalid", () =>
                expectInvalid((s) => (s.root.children[0].children[1].currentCount = -1)));
            it("a lotto selection is out of range", () => {
                const tree = new BehaviourTree('root { lotto { action [Act, "a"] } }', createAgent(world, []));
                tree.step();
                const snapshot = JSON.parse(JSON.stringify(tree.snapshot()));
                snapshot.root.children[0].selectedChild = 1;

                assert.throws(() => tree.restore(snapshot), Error, "invalid snapshot");
            });
            it("a running lotto has no selection", () => {
                const runningWorld: World = { step: 0, delta: 1, script: { a: () => undefined } };
                const tree = new BehaviourTree('root { lotto { action [Act, "a"] } }', createAgent(runningWorld, []));
                tree.step();
                const snapshot = JSON.parse(JSON.stringify(tree.snapshot()));
                snapshot.root.children[0].selectedChild = null;

                assert.throws(() => tree.restore(snapshot), Error, "invalid snapshot");
            });
            it("a wait duration is invalid", () => {
                const tree = new BehaviourTree("root { wait [1000] }", {});
                tree.step();
                const snapshot = JSON.parse(JSON.stringify(tree.snapshot()));
                snapshot.root.children[0].waitedDuration = "soon";

                assert.throws(() => tree.restore(snapshot), Error, "invalid snapshot");
            });
        });
    });

    describe("restoring a snapshot at any point", () => {
        const definition =
            'root { sequence { action [Act, "a"] repeat [2] { lotto { action [Act, "b"] wait [3000] } } action [Act, "c"] } }';
        const script: World["script"] = {
            a: from(1, State.SUCCEEDED),
            b: (s) => (s % 2 ? State.SUCCEEDED : undefined),
            c: from(0, State.SUCCEEDED)
        };
        const points = [0, 1, 2, 3, 4, 5, 6, 7, 8];
        const summary = (changes: any[]) =>
            changes.map(({ type, previousState, state }) => [type, previousState, state]);

        const create = (world: World, options = {}) =>
            new BehaviourTree(definition, createAgent(world, []), {
                getDeltaTime: () => world.delta,
                random: () => 0.7,
                ...options
            });

        points.forEach((at) => {
            it(`does not call onNodeStateChange and leaves the next step reporting as usual (after ${at} steps)`, () => {
                const world: World = { step: 0, delta: 1, script };
                const sourceChanges: any[] = [];
                const sourceTree = create(world, { onNodeStateChange: (change: any) => sourceChanges.push(change) });
                for (world.step = 0; world.step < at; world.step++) {
                    sourceTree.step();
                }
                const snapshot = JSON.parse(JSON.stringify(sourceTree.snapshot()));

                const freshChanges: any[] = [];
                const freshTree = create(world, { onNodeStateChange: (change: any) => freshChanges.push(change) });
                freshTree.restore(snapshot);
                sourceTree.restore(snapshot);
                assert.deepEqual(freshChanges, [], "restoring into a fresh tree");

                sourceChanges.length = 0;
                freshTree.step();
                sourceTree.step();
                assert.deepEqual(summary(freshChanges), summary(sourceChanges), "the next step");
            });

            it(`does not change the snapshot when either tree is stepped, and restores to an equal snapshot (after ${at} steps)`, () => {
                const world: World = { step: 0, delta: 1, script };
                const sourceTree = create(world);
                for (world.step = 0; world.step < at; world.step++) {
                    sourceTree.step();
                }
                const snapshot = sourceTree.snapshot();
                const json = JSON.stringify(snapshot);

                const restoredTree = create(world);
                restoredTree.restore(snapshot);
                assert.deepEqual(JSON.parse(JSON.stringify(restoredTree.snapshot())), JSON.parse(json));

                for (let steps = 0; steps < 10; steps++, world.step++) {
                    sourceTree.step();
                    restoredTree.step();
                    assert.equal(JSON.stringify(snapshot), json);
                }
            });
        });

        it("keeps the settled promise result of an action out of reach of the stepped trees", async () => {
            const agent = { Act: async () => State.SUCCEEDED };
            const sourceTree = new BehaviourTree("root { sequence { action [Act] wait [3000] } }", agent, {
                getDeltaTime: () => 1
            });
            sourceTree.step();
            await Promise.resolve();
            const snapshot = sourceTree.snapshot();
            const json = JSON.stringify(snapshot);

            const restoredTree = new BehaviourTree("root { sequence { action [Act] wait [3000] } }", agent, {
                getDeltaTime: () => 1
            });
            restoredTree.restore(snapshot);
            assert.equal(JSON.stringify(restoredTree.snapshot()), json);

            sourceTree.step();
            restoredTree.step();
            assert.equal(JSON.stringify(snapshot), json);
        });
    });

    describe("restoring a snapshot of another definition", () => {
        const agent = () => ({
            Act: () => undefined,
            Cond: () => true,
            IsOpen: () => true,
            OnEnter: () => undefined
        });
        const steppedSnapshot = (definition: string) => {
            const tree = new BehaviourTree(definition, agent(), { getDeltaTime: () => 1 });
            tree.step();
            return JSON.parse(JSON.stringify(tree.snapshot()));
        };
        const mismatch = "snapshot does not match the tree's definition";

        const rejects = (treeDefinition: string, otherDefinition: string) => {
            const tree = new BehaviourTree(treeDefinition, agent(), { getDeltaTime: () => 1 });
            tree.step();
            const before = tree.snapshot();
            const details = stripIds(tree.getTreeNodeDetails());

            assert.throws(() => tree.restore(steppedSnapshot(otherDefinition)), Error, mismatch);
            assert.deepEqual(tree.snapshot(), before);
            assert.deepEqual(stripIds(tree.getTreeNodeDetails()), details);
        };

        it("throws if only the action arguments differ", () =>
            rejects('root { action [Act, "a"] }', 'root { action [Act, "b"] }'));
        it("throws if only a wait duration differs", () => rejects("root { wait [100] }", "root { wait [200] }"));
        it("throws if only the lotto weights differ", () =>
            rejects(
                "root { lotto [1, 2] { action [Act] action [Act] } }",
                "root { lotto [2, 1] { action [Act] action [Act] } }"
            ));
        it("throws if only a guard differs", () =>
            rejects("root { action [Act] while(IsOpen, 1) }", "root { action [Act] while(IsOpen, 2) }"));
        it("throws if the structure differs", () =>
            rejects("root { sequence { action [Act] } }", "root { selector { action [Act] condition [Cond] } }"));

        const mdsl = `
            root {
                sequence entry(OnEnter) while(IsOpen, 1) {
                    action [Act, "a", 2, true, null]
                    branch [Sub]
                    lotto [1, 2] {
                        condition [Cond]
                        wait [100, 200]
                    }
                }
            }
            root [Sub] {
                repeat [2] {
                    action [Act, "b"]
                }
            }`;
        const json: any = [
            {
                type: "root",
                id: "Sub",
                child: { type: "repeat", iterations: 2, child: { type: "action", call: "Act", args: ["b"] } }
            },
            {
                type: "root",
                child: {
                    children: [
                        { type: "action", call: "Act", args: ["a", 2, true, null] },
                        { ref: "Sub", type: "branch" },
                        {
                            type: "lotto",
                            weights: [1, 2],
                            children: [
                                { type: "condition", call: "Cond" },
                                { type: "wait", duration: [100, 200] }
                            ]
                        }
                    ],
                    type: "sequence",
                    while: { call: "IsOpen", args: [1] },
                    entry: { call: "OnEnter" }
                }
            }
        ];

        it("accepts the snapshot of the equivalent JSON definition for an MDSL definition", () => {
            const tree = new BehaviourTree(mdsl, agent());

            tree.restore(steppedSnapshot(json));

            assert.equal(tree.getState(), State.RUNNING);
        });

        it("accepts the snapshot of the equivalent MDSL definition for a JSON definition", () => {
            const tree = new BehaviourTree(json, agent());

            tree.restore(steppedSnapshot(mdsl));

            assert.equal(tree.getState(), State.RUNNING);
        });

        it("throws for input that is not a snapshot and leaves the tree unchanged", () => {
            const tree = new BehaviourTree("root { wait [1000] }", agent(), { getDeltaTime: () => 1 });
            tree.step();
            const before = tree.snapshot();
            const valid = tree.snapshot();
            const inputs = [
                null,
                undefined,
                "snapshot",
                42,
                [],
                [valid],
                {},
                { version: 1, root: valid.root },
                { definition: valid.definition, root: valid.root },
                { version: 1, definition: valid.definition },
                { version: 1, definition: 42, root: valid.root }
            ];

            for (const input of inputs) {
                assert.throws(() => tree.restore(input as any), Error);
            }

            assert.deepEqual(tree.snapshot(), before);
        });

        it("leaves a tree with a pending action exactly as it was", async () => {
            const pendingDefinition = "root { parallel { repeat [3] { action [Quick, 1] } action [Pending] } }";
            let resolve: (state: State) => void = () => {};
            let pendingCalls = 0;
            const tree = new BehaviourTree(pendingDefinition, {
                Quick: () => State.SUCCEEDED,
                Pending: () => {
                    pendingCalls++;
                    return new Promise((r) => (resolve = r as any));
                }
            });
            tree.step();
            const before = tree.snapshot();
            const other = new BehaviourTree(pendingDefinition.replace("Quick, 1", "Quick, 2"), {
                Quick: () => State.SUCCEEDED,
                Pending: () => new Promise(() => {})
            });
            other.step();

            assert.throws(() => tree.restore(other.snapshot()), Error, mismatch);
            assert.deepEqual(tree.snapshot(), before);

            resolve(State.SUCCEEDED);
            await Promise.resolve();
            tree.step();

            assert.equal(pendingCalls, 1);
            assert.equal(tree.getTreeNodeDetails().children![0].children![1].state, State.SUCCEEDED);
        });
    });

    describe("snapshotted with an action that returns a promise", () => {
        const definition = 'root { action [Act, "a"] }';

        it("snapshots a pending action as not yet started and leaves the tree it was taken from unchanged", async () => {
            let resolve: (state: State) => void = () => {};
            let calls = 0;
            const tree = new BehaviourTree(definition, {
                Act: () => {
                    calls++;
                    return new Promise<State.SUCCEEDED | State.FAILED>((r) => (resolve = r as any));
                }
            });
            tree.step();

            const snapshot = JSON.parse(JSON.stringify(tree.snapshot()));

            assert.equal(snapshot.root.children[0].state, State.READY);
            assert.notProperty(snapshot.root.children[0], "promiseResult");

            resolve(State.SUCCEEDED);
            await Promise.resolve();
            tree.step();

            assert.equal(calls, 1);
            assert.equal(tree.getState(), State.SUCCEEDED);
        });

        it("calls the action function and the entry callback again after restoring a pending action", async () => {
            const sequenceDefinition = "root { sequence { action [Done] action [Pending] entry(OnEntry) } }";
            const sourceLog: string[] = [];
            const sourceTree = new BehaviourTree(sequenceDefinition, {
                Done: () => (sourceLog.push("Done"), State.SUCCEEDED),
                Pending: () => (sourceLog.push("Pending"), new Promise(() => {})),
                OnEntry: () => sourceLog.push("OnEntry")
            });
            sourceTree.step();

            const targetLog: string[] = [];
            let resolve: (state: State) => void = () => {};
            const targetTree = new BehaviourTree(sequenceDefinition, {
                Done: () => (targetLog.push("Done"), State.SUCCEEDED),
                Pending: () => (targetLog.push("Pending"), new Promise((r) => (resolve = r as any))),
                OnEntry: () => targetLog.push("OnEntry")
            });
            targetTree.restore(JSON.parse(JSON.stringify(sourceTree.snapshot())));

            assert.deepEqual(targetLog, []);

            targetTree.step();

            assert.deepEqual(targetLog, ["OnEntry", "Pending"]);

            resolve(State.SUCCEEDED);
            await Promise.resolve();
            targetTree.step();

            assert.deepEqual(targetLog, ["OnEntry", "Pending"]);
            assert.equal(targetTree.getState(), State.SUCCEEDED);
        });

        it("ignores a promise of the tree that was pending when restoring", async () => {
            const resolvers: ((state: State) => void)[] = [];
            const tree = new BehaviourTree(definition, {
                Act: () => new Promise<State.SUCCEEDED | State.FAILED>((resolve) => resolvers.push(resolve as any))
            });
            const unstartedSnapshot = tree.snapshot();

            tree.step();
            tree.restore(unstartedSnapshot);
            tree.step();
            resolvers[0](State.SUCCEEDED);
            await Promise.resolve();
            tree.step();

            assert.equal(resolvers.length, 2);
            assert.equal(tree.getState(), State.RUNNING);
        });

        it("keeps the result of a settled promise", async () => {
            const sourceTree = new BehaviourTree(definition, { Act: () => Promise.resolve(State.SUCCEEDED) });
            sourceTree.step();
            await Promise.resolve();

            const calls: string[] = [];
            const targetTree = new BehaviourTree(definition, { Act: () => calls.push("Act") });
            targetTree.restore(JSON.parse(JSON.stringify(sourceTree.snapshot())));
            targetTree.step();

            assert.equal(targetTree.getState(), State.SUCCEEDED);
            assert.deepEqual(calls, []);
        });

        it("keeps the failure of a rejected promise", async () => {
            const sourceTree = new BehaviourTree(definition, { Act: () => Promise.reject(new Error("boom")) });
            sourceTree.step();
            await Promise.resolve();

            const targetTree = new BehaviourTree(definition, { Act: () => undefined });
            targetTree.restore(JSON.parse(JSON.stringify(sourceTree.snapshot())));

            assert.throws(() => targetTree.step(), Error, "promise rejected with 'Error: boom'");
            assert.throws(() => sourceTree.step(), Error, "promise rejected with 'Error: boom'");
        });
    });
});
