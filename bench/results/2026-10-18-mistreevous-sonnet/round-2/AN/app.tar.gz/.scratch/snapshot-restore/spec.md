# Snapshot and restore of tree execution state

Status: ready-for-agent

## Goal

`BehaviourTree.snapshot()` returns the execution state as a plain object (survives `JSON.stringify` / `JSON.parse` unchanged). `BehaviourTree.restore(snapshot)` sets a tree built from the same definition to that state. Afterwards the tree behaves as the original would have: same node states, same agent function calls in the same order, same result.

## Format

```
BehaviourTreeSnapshot = { version: 1, root: NodeSnapshot }
NodeSnapshot (all nodes) = { id, type, name, state, children?: NodeSnapshot[] }
```

`id` is the node uid (restored so `getTreeNodeDetails()` is identical). `type` and `name` are checked on restore to detect a different definition. `children` is present for composite and decorator nodes, in definition order.

Extra fields per node type (the state that is not derivable from children states):

| Node | Fields | Why |
|---|---|---|
| lotto | `selectedChild: number \| null` | random pick made on first update |
| repeat | `currentIterations`, `targetIterations: number \| null` | counter and random target |
| retry | `currentAttempts`, `targetAttempts: number \| null` | counter and random target |
| wait | `totalDuration: number \| null`, `waitedDuration` | random duration, elapsed time |
| action | `promise?: { isResolved, value }` | settled, not yet consumed promise result |
| sequence, selector, parallel, race, all, root, flip, succeed, fail, condition | none | progress is the children states |

## Rules

- Wait elapsed time: with `getDeltaTime`, the accumulated `waitedDuration`. Otherwise `Date.now() - initialUpdateTime` at snapshot time. On restore `initialUpdateTime = Date.now() - waitedDuration`, so time between snapshot and restore does not count.
- Finished tree: state restored as is. `step()` resets the root and runs again, drawing new random values.
- `snapshot()` throws if an action node has a pending (unsettled) promise: it cannot be serialized and the original would resolve it later.
- A promise callback from before a restore must not write into the restored node (identity check).
- `restore()` validates the whole snapshot before changing anything. Invalid: throws `Error("invalid snapshot: ...")`, tree unchanged.
- `restore()` calls no agent function, no `random()`, fires no `onNodeStateChange`.
- Types exported from the package index.

## Acceptance

- Tests per node type and the cross-cutting rules above, in `test/`.
- `npm test` passes.
- README section with example, Version History entry, version 4.4.0.
