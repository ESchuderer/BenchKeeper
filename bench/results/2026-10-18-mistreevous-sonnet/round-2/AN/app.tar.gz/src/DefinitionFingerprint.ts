import { RootNodeDefinition } from "./BehaviourTreeDefinition";

/**
 * Gets a value in a form that is the same for definitions that build the same tree: object keys are sorted, undefined
 * properties are left out and the defaults that the tree builder applies for omitted values are filled in.
 * @param value The definition value.
 * @param key The name of the property that holds the value.
 * @returns The value in its canonical form.
 */
function canonicalise(value: unknown, key?: string): unknown {
    if (Array.isArray(value)) {
        return value.map((element) => canonicalise(element));
    }

    if (typeof value !== "object" || value === null) {
        return value;
    }

    const properties: Record<string, unknown> = { ...value };

    // Action and condition nodes and node attributes call a function with no arguments if there are none defined.
    if (typeof properties.call === "string" && properties.args === undefined) {
        properties.args = [];
    }

    // A guard attribute fails the node it aborts unless it is defined to succeed it.
    if (key === "while" || key === "until") {
        properties.succeedOnAbort = !!properties.succeedOnAbort;
    }

    return Object.fromEntries(
        Object.keys(properties)
            .filter((name) => properties[name] !== undefined)
            .sort()
            .map((name) => [name, canonicalise(properties[name], name)])
    );
}

/**
 * Hashes a string to 53 bits (cyrb53, public domain), returned as a hexadecimal string.
 * @param text The string to hash.
 * @returns The hash of the string.
 */
function hash(text: string): string {
    let h1 = 0xdeadbeef;
    let h2 = 0x41c6ce57;

    for (let index = 0; index < text.length; index++) {
        const code = text.charCodeAt(index);
        h1 = Math.imul(h1 ^ code, 2654435761);
        h2 = Math.imul(h2 ^ code, 1597334677);
    }

    h1 = Math.imul(h1 ^ (h1 >>> 16), 2246822507) ^ Math.imul(h2 ^ (h2 >>> 13), 3266489909);
    h2 = Math.imul(h2 ^ (h2 >>> 16), 2246822507) ^ Math.imul(h1 ^ (h1 >>> 13), 3266489909);

    return (4294967296 * (2097151 & h2) + (h1 >>> 0)).toString(16);
}

/**
 * Gets the fingerprint of a validated tree definition, which is the same for an MDSL definition and its equivalent
 * JSON definition and differs for definitions that build different trees.
 * @param definition The root node definitions of the tree.
 * @returns The fingerprint of the tree definition.
 */
export function getDefinitionFingerprint(definition: RootNodeDefinition[]): string {
    // The order of the root nodes does not change the tree, so each is written out on its own and then put in order.
    const rootNodes = definition.map((rootNode) => JSON.stringify(canonicalise(rootNode))).sort();

    return hash(JSON.stringify(rootNodes));
}
