import { AnyState } from "./State";

/**
 * The properties that are part of the snapshot of every node.
 */
type NodeSnapshotBase<Type extends string> = {
    /**
     * The tree node identifier.
     */
    id: string;
    /**
     * The tree node type.
     */
    type: Type;
    /**
     * The tree node name, used to check that a snapshot is restored into a tree built from the same definition.
     */
    name: string;
    /**
     * The state of the tree node.
     */
    state: AnyState;
    /**
     * The snapshots of the child nodes in definition order, defined if this is a composite or decorator node.
     */
    children?: NodeSnapshot[];
};

/**
 * The snapshot of a node that keeps no state beyond its own state and the state of its children.
 */
export type StatelessNodeSnapshot = NodeSnapshotBase<
    "root" | "sequence" | "selector" | "parallel" | "race" | "all" | "flip" | "succeed" | "fail" | "condition"
>;

/**
 * The snapshot of a lotto node.
 */
export type LottoNodeSnapshot = NodeSnapshotBase<"lotto"> & {
    /**
     * The index of the child picked as the active one, or null if no child has been picked.
     */
    selectedChild: number | null;
};

/**
 * The snapshot of a repeat node.
 */
export type RepeatNodeSnapshot = NodeSnapshotBase<"repeat"> & {
    /**
     * The number of iterations completed.
     */
    currentIterations: number;
    /**
     * The number of iterations to make, which may have been chosen at random, or null for infinite iterations.
     */
    targetIterations: number | null;
};

/**
 * The snapshot of a retry node.
 */
export type RetryNodeSnapshot = NodeSnapshotBase<"retry"> & {
    /**
     * The number of attempts completed.
     */
    currentAttempts: number;
    /**
     * The number of attempts to make, which may have been chosen at random, or null for infinite attempts.
     */
    targetAttempts: number | null;
};

/**
 * The snapshot of a wait node.
 */
export type WaitNodeSnapshot = NodeSnapshotBase<"wait"> & {
    /**
     * The duration in milliseconds that the node waits for, which may have been chosen at random, or null to wait
     * indefinitely.
     */
    totalDuration: number | null;
    /**
     * The duration in milliseconds that the node has waited for when the snapshot was taken.
     */
    waitedDuration: number;
};

/**
 * The snapshot of an action node.
 */
export type ActionNodeSnapshot = NodeSnapshotBase<"action"> & {
    /**
     * The result of the promise returned by the action function, defined if the node is running and the promise has
     * settled but its result has not yet been handled by a tree step.
     */
    promise?: {
        /**
         * Whether the promise was resolved rather than rejected.
         */
        isResolved: boolean;
        /**
         * The promise resolved value or rejection reason as a string.
         */
        value: string;
    };
};

/**
 * The snapshot of any node.
 */
export type NodeSnapshot =
    | StatelessNodeSnapshot
    | LottoNodeSnapshot
    | RepeatNodeSnapshot
    | RetryNodeSnapshot
    | WaitNodeSnapshot
    | ActionNodeSnapshot;

/**
 * A snapshot of the execution state of a behaviour tree.
 * This is a plain object that is unchanged by a JSON.stringify and JSON.parse round trip.
 */
export type BehaviourTreeSnapshot = {
    /**
     * The snapshot format version.
     */
    version: 1;
    /**
     * The fingerprint of the definition of the tree that the snapshot was taken from, used to check that a snapshot is
     * restored into a tree built from the same definition. An MDSL definition and its equivalent JSON definition have
     * the same fingerprint.
     */
    definition: string;
    /**
     * The snapshot of the root node.
     */
    root: NodeSnapshot;
};
