/**
 * Gets whether a value is an object that is not null or an array.
 * @param value The value.
 * @returns Whether the value is an object that is not null or an array.
 */
export function isObject(value: unknown): value is Record<string, unknown> {
    return typeof value === "object" && value !== null && !Array.isArray(value);
}

/**
 * Throws an error for an invalid snapshot property.
 * @param name The property name.
 * @param value The property value.
 * @param path The path of the snapshot node.
 */
function throwInvalidProperty(name: string, value: unknown, path: string): never {
    throw new Error(`invalid ${name} '${String(value)}' at ${path}`);
}

/**
 * Checks that a snapshot property is a non-negative integer, or optionally null.
 * @param snapshot The snapshot node.
 * @param name The property name.
 * @param path The path of the snapshot node.
 * @param isNullAllowed Whether null is a valid value.
 */
export function checkCount(snapshot: Record<string, unknown>, name: string, path: string, isNullAllowed = false) {
    const value = snapshot[name];

    if (isNullAllowed && value === null) {
        return;
    }

    if (typeof value !== "number" || !Number.isInteger(value) || value < 0) {
        throwInvalidProperty(name, value, path);
    }
}

/**
 * Checks that a snapshot property is a finite number, or optionally null.
 * @param snapshot The snapshot node.
 * @param name The property name.
 * @param path The path of the snapshot node.
 * @param isNullAllowed Whether null is a valid value.
 */
export function checkNumber(snapshot: Record<string, unknown>, name: string, path: string, isNullAllowed = false) {
    const value = snapshot[name];

    if (isNullAllowed && value === null) {
        return;
    }

    if (typeof value !== "number" || !Number.isFinite(value)) {
        throwInvalidProperty(name, value, path);
    }
}
