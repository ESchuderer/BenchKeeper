import { assert } from "chai";
import sinon, { SinonFakeTimers } from "sinon";

import { BehaviourTree, BehaviourTreeOptions, State } from "../src/index";
import { RootNodeDefinition } from "../src/BehaviourTreeDefinition";

type Definition = string | RootNodeDefinition | RootNodeDefinition[];

type Limits = Record<string, number | { calls: number; then: State.SUCCEEDED | State.FAILED }>;

/**
 * Creates an agent whose actions are logged. Each action named in 'limits' stays in the RUNNING state until it has
 * been called the given number of times, then it succeeds or fails as given. 'counts' holds the agent's own state,
 * outside of the tree.
 */
function createAgent(log: string[], limits: Limits, counts: Record<string, number>) {
    const agent: Record<string, () => State.SUCCEEDED | State.FAILED | State.RUNNING> = {};

    Object.keys(limits).forEach((name) => {
        const limit = limits[name];
        const { calls, then } = typeof limit === "number" ? { calls: limit, then: State.SUCCEEDED as const } : limit;

        agent[name] = () => {
            log.push(name);
            counts[name] = (counts[name] ?? 0) + 1;
            return counts[name] >= calls ? then : State.RUNNING;
        };
    });

    return agent;
}

/**
 * Steps a tree, takes a snapshot that is passed through JSON, restores it into a new tree with its own agent and
 * checks that both trees behave identically for the following steps.
 */
function assertRestoredTreeMatchesOriginal(
    definition: Definition,
    limits: Limits,
    stepsBeforeSnapshot: number,
    stepsAfterRestore: number,
    createOptions: (isRestored: boolean) => BehaviourTreeOptions = () => ({})
) {
    const originalLog: string[] = [];
    const originalCounts: Record<string, number> = {};
    const original = new BehaviourTree(
        definition,
        createAgent(originalLog, limits, originalCounts),
        createOptions(false)
    );

    for (let step = 0; step < stepsBeforeSnapshot; step++) {
        original.step();
    }

    const snapshot = JSON.parse(JSON.stringify(original.snapshot()));

    const restoredLog: string[] = [];
    const restoredCounts = { ...originalCounts };
    const restored = new BehaviourTree(
        definition,
        createAgent(restoredLog, limits, restoredCounts),
        createOptions(true)
    );
    restored.restore(snapshot);

    originalLog.length = 0;

    assert.deepEqual(restored.getTreeNodeDetails(), original.getTreeNodeDetails());

    for (let step = 0; step < stepsAfterRestore; step++) {
        original.step();
        restored.step();

        assert.deepEqual(restored.getTreeNodeDetails(), original.getTreeNodeDetails());
        assert.deepEqual(restoredLog, originalLog);
    }

    return { original, restored, snapshot };
}

describe("A behaviour tree snapshot", () => {
    it("is a plain object that is unchanged by a JSON round trip", () => {
        const tree = new BehaviourTree("root { sequence { action [A] action [B] } }", {
            A: () => State.SUCCEEDED,
            B: () => State.RUNNING
        });

        tree.step();

        const snapshot = tree.snapshot();

        assert.deepEqual(JSON.parse(JSON.stringify(snapshot)), snapshot);
    });

    it("restores a partly completed sequence so that it carries on from the running child", () => {
        const { restored } = assertRestoredTreeMatchesOriginal(
            "root { sequence { action [A] action [B] action [C] } }",
            { A: 1, B: 3, C: 1 },
            2,
            4
        );

        assert.strictEqual(restored.getState(), State.SUCCEEDED);
    });
});

describe("A restored lotto node", () => {
    it("keeps the child that was picked before the snapshot", () => {
        const { restored } = assertRestoredTreeMatchesOriginal(
            "root { lotto { action [A] action [B] action [C] } }",
            { A: 5, B: 5, C: 5 },
            2,
            3,
            // The original picks the last child, a restored tree that picked again would pick the first.
            (isRestored) => ({ random: () => (isRestored ? 0 : 0.99) })
        );

        assert.strictEqual(restored.getState(), State.SUCCEEDED);
    });
});

describe("A restored repeat node", () => {
    it("keeps the number of iterations already made", () => {
        const { restored } = assertRestoredTreeMatchesOriginal("root { repeat [3] { action [A] } }", { A: 1 }, 1, 3);

        assert.strictEqual(restored.getState(), State.SUCCEEDED);
    });

    it("keeps the random iteration count that was already chosen", () => {
        const { restored } = assertRestoredTreeMatchesOriginal(
            "root { repeat [1,5] { action [A] } }",
            { A: 1 },
            2,
            4,
            // The original chooses 5 iterations, a restored tree that chose again would choose 1.
            (isRestored) => ({ random: () => (isRestored ? 0 : 0.99) })
        );

        assert.strictEqual(restored.getState(), State.SUCCEEDED);
    });
});

describe("A restored retry node", () => {
    it("keeps the number of attempts already made", () => {
        const { restored } = assertRestoredTreeMatchesOriginal(
            "root { retry [3] { action [A] } }",
            { A: { calls: 1, then: State.FAILED } },
            1,
            3
        );

        assert.strictEqual(restored.getState(), State.FAILED);
    });

    it("keeps the random attempt count that was already chosen", () => {
        const { restored } = assertRestoredTreeMatchesOriginal(
            "root { retry [1,5] { action [A] } }",
            { A: { calls: 1, then: State.FAILED } },
            2,
            4,
            // The original chooses 5 attempts, a restored tree that chose again would choose 1.
            (isRestored) => ({ random: () => (isRestored ? 0 : 0.99) })
        );

        assert.strictEqual(restored.getState(), State.FAILED);
    });
});

describe("A restored wait node", () => {
    describe("when the clock is used", () => {
        let clock: SinonFakeTimers;

        beforeEach(() => {
            clock = sinon.useFakeTimers();
        });

        afterEach(() => {
            clock.restore();
        });

        it("only waits for the time remaining, not counting the time between the snapshot and the restore", () => {
            const original = new BehaviourTree("root { wait [1000] }", {});

            original.step();
            clock.tick(400);

            // The snapshot is taken without a step, so the time waited is the time since the first step.
            const snapshot = JSON.parse(JSON.stringify(original.snapshot()));

            // An hour passes before the tree is restored.
            clock.tick(60 * 60 * 1000);

            const restored = new BehaviourTree("root { wait [1000] }", {});
            restored.restore(snapshot);

            restored.step();
            assert.strictEqual(restored.getState(), State.RUNNING);

            clock.tick(599);
            restored.step();
            assert.strictEqual(restored.getState(), State.RUNNING);

            clock.tick(1);
            restored.step();
            assert.strictEqual(restored.getState(), State.SUCCEEDED);
        });

        it("keeps the random duration that was already chosen", () => {
            const original = new BehaviourTree("root { wait [100,1000] }", {}, { random: () => 0.99 });

            original.step();
            clock.tick(500);

            const snapshot = JSON.parse(JSON.stringify(original.snapshot()));

            // The original chose a duration of 991ms, a restored tree that chose again would choose 100ms.
            const restored = new BehaviourTree("root { wait [100,1000] }", {}, { random: () => 0 });
            restored.restore(snapshot);

            clock.tick(300);
            restored.step();
            assert.strictEqual(restored.getState(), State.RUNNING);

            clock.tick(190);
            restored.step();
            assert.strictEqual(restored.getState(), State.RUNNING);

            clock.tick(1);
            restored.step();
            assert.strictEqual(restored.getState(), State.SUCCEEDED);
        });
    });

    it("only waits for the time remaining when 'getDeltaTime' is used, whatever the clock says", () => {
        const clock = sinon.useFakeTimers();

        try {
            const { restored } = assertRestoredTreeMatchesOriginal("root { wait [1000] }", {}, 2, 2, () => ({
                getDeltaTime: () => 0.3
            }));

            // 0.3 seconds for each of the four steps is more than the second that was waited for.
            assert.strictEqual(restored.getState(), State.SUCCEEDED);
        } finally {
            clock.restore();
        }
    });
});

describe("A restored finished tree", () => {
    it("is finished, and its next step starts a new run that makes its random choices again", () => {
        const definition = "root { lotto { action [A] action [B] } }";
        const randomValues = [0, 0.99];
        const createAgent = (log: string[]) => ({
            A: () => (log.push("A"), State.SUCCEEDED),
            B: () => (log.push("B"), State.SUCCEEDED)
        });

        // The first run picks the first child and the second run picks the second child.
        const originalLog: string[] = [];
        const original = new BehaviourTree(definition, createAgent(originalLog), { random: () => randomValues[0] });
        original.step();
        assert.deepEqual(originalLog, ["A"]);
        assert.strictEqual(original.getState(), State.SUCCEEDED);

        const snapshot = JSON.parse(JSON.stringify(original.snapshot()));

        const restoredLog: string[] = [];
        const restored = new BehaviourTree(definition, createAgent(restoredLog), { random: () => randomValues[1] });
        restored.restore(snapshot);

        assert.strictEqual(restored.getState(), State.SUCCEEDED);
        assert.deepEqual(restored.getTreeNodeDetails(), original.getTreeNodeDetails());
        assert.deepEqual(restoredLog, []);

        restored.step();

        assert.deepEqual(restoredLog, ["B"]);
        assert.strictEqual(restored.getState(), State.SUCCEEDED);
    });
});

describe("A snapshot of a tree with a promise-based action", () => {
    it("is taken with an action whose promise is pending saved as not yet started", () => {
        const tree = new BehaviourTree("root { action [A] }", { A: () => new Promise<State.SUCCEEDED>(() => {}) });

        tree.step();

        const snapshot = tree.snapshot();

        assert.strictEqual(snapshot.root.state, State.RUNNING);
        assert.strictEqual(snapshot.root.children![0].state, State.READY);
        assert.notProperty(snapshot.root.children![0], "promise");
        assert.deepEqual(JSON.parse(JSON.stringify(snapshot)), snapshot);
    });

    it("does not change the tree it is taken from when a promise is pending", async () => {
        let resolve: (state: State.SUCCEEDED) => void = () => {};
        const tree = new BehaviourTree("root { action [A] }", {
            A: () => new Promise<State.SUCCEEDED>((r) => (resolve = r))
        });

        tree.step();
        tree.snapshot();

        assert.strictEqual(tree.getTreeNodeDetails().children![0].state, State.RUNNING);

        resolve(State.SUCCEEDED);
        await Promise.resolve();
        tree.step();

        assert.strictEqual(tree.getState(), State.SUCCEEDED);
    });

    it("restores an action whose promise was pending so that its action function is called again on the next step", async () => {
        const definition = "root { sequence { action [A] action [B] action [C] } }";
        const log: string[] = [];
        const resolvers: ((state: State.SUCCEEDED) => void)[] = [];
        const createAgent = () => ({
            A: () => (log.push("A"), State.SUCCEEDED),
            B: () => (log.push("B"), new Promise<State.SUCCEEDED>((resolve) => resolvers.push(resolve))),
            C: () => (log.push("C"), State.SUCCEEDED)
        });

        const original = new BehaviourTree(definition, createAgent());
        original.step();

        const snapshot = JSON.parse(JSON.stringify(original.snapshot()));

        const restored = new BehaviourTree(definition, createAgent());
        restored.restore(snapshot);

        assert.strictEqual(restored.getState(), State.RUNNING);

        log.length = 0;
        restored.step();

        // A had already succeeded so is not called again, B is called again as it had not yet started.
        assert.deepEqual(log, ["B"]);
        assert.strictEqual(resolvers.length, 2);

        resolvers[1](State.SUCCEEDED);
        await Promise.resolve();
        restored.step();

        assert.deepEqual(log, ["B", "C"]);
        assert.strictEqual(restored.getState(), State.SUCCEEDED);
    });

    it("calls the entry callback of an action whose promise was pending again on the next step", () => {
        const definition = "root { action [A] entry(Hook) }";
        const log: string[] = [];
        const createAgent = () => ({
            A: () => (log.push("A"), new Promise<State.SUCCEEDED>(() => {})),
            Hook: () => void log.push("Hook")
        });

        const original = new BehaviourTree(definition, createAgent());
        original.step();

        const restored = new BehaviourTree(definition, createAgent());
        restored.restore(JSON.parse(JSON.stringify(original.snapshot())));

        log.length = 0;
        restored.step();

        assert.deepEqual(log, ["Hook", "A"]);
    });

    it("keeps the result of a settled promise next to an action whose promise is pending", async () => {
        const definition = "root { parallel { action [Settled] action [Pending] } }";
        const log: string[] = [];
        const createAgent = () => ({
            Settled: () => (log.push("Settled"), Promise.resolve(State.SUCCEEDED)),
            Pending: () => (log.push("Pending"), new Promise<State.SUCCEEDED>(() => {}))
        });

        const original = new BehaviourTree(definition, createAgent());
        original.step();
        await Promise.resolve();

        const snapshot = JSON.parse(JSON.stringify(original.snapshot()));

        assert.deepEqual(snapshot.root.children[0].children[0].promise, {
            isResolved: true,
            value: "mistreevous.succeeded"
        });
        assert.strictEqual(snapshot.root.children[0].children[1].state, State.READY);

        const restored = new BehaviourTree(definition, createAgent());
        restored.restore(snapshot);

        log.length = 0;
        restored.step();

        assert.deepEqual(log, ["Pending"]);
        assert.deepEqual(
            restored.getTreeNodeDetails().children![0].children!.map(({ state }) => state),
            [State.SUCCEEDED, State.RUNNING]
        );
    });

    it("can be taken once the promise has resolved, and the restored tree carries on without calling the action again", async () => {
        const definition = "root { sequence { action [A] action [B] } }";
        const createAgent = (log: string[]) => ({
            A: () => (log.push("A"), Promise.resolve(State.SUCCEEDED)),
            B: () => (log.push("B"), State.SUCCEEDED)
        });

        const originalLog: string[] = [];
        const original = new BehaviourTree(definition, createAgent(originalLog));
        original.step();
        await Promise.resolve();

        const snapshot = JSON.parse(JSON.stringify(original.snapshot()));

        const restoredLog: string[] = [];
        const restored = new BehaviourTree(definition, createAgent(restoredLog));
        restored.restore(snapshot);

        original.step();
        restored.step();

        assert.deepEqual(originalLog, ["A", "B"]);
        assert.deepEqual(restoredLog, ["B"]);
        assert.strictEqual(restored.getState(), State.SUCCEEDED);
        assert.deepEqual(restored.getTreeNodeDetails(), original.getTreeNodeDetails());
    });

    it("can be taken once the promise has rejected, and the restored tree throws the same error", async () => {
        const definition = "root { action [A] }";
        const agent = { A: () => Promise.reject(new Error("boom")) };

        const original = new BehaviourTree(definition, agent);
        original.step();
        await Promise.resolve();

        const snapshot = JSON.parse(JSON.stringify(original.snapshot()));

        const restored = new BehaviourTree(definition, agent);
        restored.restore(snapshot);

        const expectedMessage = "action function 'A' promise rejected with 'Error: boom'";
        assert.throws(() => original.step(), Error, expectedMessage);
        assert.throws(() => restored.step(), Error, expectedMessage);
    });

    it("is not affected by a promise from before a restore settling later", async () => {
        const definition = "root { action [A] }";
        const resolvers: ((state: State.SUCCEEDED) => void)[] = [];
        const agent = { A: () => new Promise<State.SUCCEEDED>((resolve) => resolvers.push(resolve)) };

        const tree = new BehaviourTree(definition, agent);
        const snapshot = JSON.parse(JSON.stringify(tree.snapshot()));

        // The first call returns a promise that is still pending when the snapshot is restored.
        tree.step();
        tree.restore(snapshot);

        // The second call returns a new promise that is still pending when the first one resolves.
        tree.step();
        resolvers[0](State.SUCCEEDED);
        await Promise.resolve();
        tree.step();

        assert.strictEqual(resolvers.length, 2);
        assert.strictEqual(tree.getState(), State.RUNNING);

        resolvers[1](State.SUCCEEDED);
        await Promise.resolve();
        tree.step();

        assert.strictEqual(tree.getState(), State.SUCCEEDED);
    });
});

describe("Restoring an invalid snapshot", () => {
    const createTree = (
        definition = "root { sequence { lotto { action [A] action [B] } wait [1000] repeat [3] { action [C] } } }"
    ) => new BehaviourTree(definition, { A: () => State.RUNNING, B: () => State.RUNNING, C: () => State.RUNNING });

    const takeSnapshot = () => {
        const tree = createTree();
        tree.step();
        return JSON.parse(JSON.stringify(tree.snapshot()));
    };

    it("throws if the snapshot is not an object", () => {
        assert.throws(() => createTree().restore(null as any), Error, "invalid snapshot: expected an object");
        assert.throws(() => createTree().restore("snapshot" as any), Error, "invalid snapshot: expected an object");
    });

    it("throws if the snapshot version is not supported", () => {
        const snapshot = takeSnapshot();
        snapshot.version = 2;

        assert.throws(() => createTree().restore(snapshot), Error, "invalid snapshot: unsupported version '2'");
    });

    it("throws if a node is not of the type in the tree", () => {
        const snapshot = takeSnapshot();
        snapshot.root.children[0].type = "selector";

        assert.throws(
            () => createTree().restore(snapshot),
            Error,
            "invalid snapshot: expected node type 'sequence' but got 'selector' at root.children[0]"
        );
    });

    it("throws if a node is not named as in the tree", () => {
        const snapshot = takeSnapshot();
        snapshot.root.children[0].children[1].name = "WAIT 2000ms";

        assert.throws(
            () => createTree().restore(snapshot),
            Error,
            "invalid snapshot: expected node name 'WAIT 1000ms' but got 'WAIT 2000ms' at root.children[0].children[1]"
        );
    });

    it("throws if a node does not have the children of the tree", () => {
        const snapshot = takeSnapshot();
        snapshot.root.children[0].children[0].children.push(snapshot.root.children[0].children[0].children[0]);

        assert.throws(
            () => createTree().restore(snapshot),
            Error,
            "invalid snapshot: expected 2 children but got 3 at root.children[0].children[0]"
        );
    });

    it("throws if a node state is not a state", () => {
        const snapshot = takeSnapshot();
        snapshot.root.state = "running";

        assert.throws(
            () => createTree().restore(snapshot),
            Error,
            "invalid snapshot: invalid node state 'running' at root"
        );
    });

    it("throws if the child selected by a lotto node does not exist", () => {
        const snapshot = takeSnapshot();
        snapshot.root.children[0].children[0].selectedChild = 2;

        assert.throws(
            () => createTree().restore(snapshot),
            Error,
            "invalid snapshot: invalid selectedChild '2' at root.children[0].children[0]"
        );
    });

    it("throws if a count or duration is not valid", () => {
        const snapshot = takeSnapshot();
        snapshot.root.children[0].children[2].currentIterations = -1;

        assert.throws(
            () => createTree().restore(snapshot),
            Error,
            "invalid snapshot: invalid currentIterations '-1' at root.children[0].children[2]"
        );

        const waitSnapshot = takeSnapshot();
        waitSnapshot.root.children[0].children[1].waitedDuration = "1000";

        assert.throws(
            () => createTree().restore(waitSnapshot),
            Error,
            "invalid snapshot: invalid waitedDuration '1000' at root.children[0].children[1]"
        );
    });

    it("throws if a lotto node that has started has no selected child", () => {
        const snapshot = takeSnapshot();
        snapshot.root.children[0].children[0].selectedChild = null;

        assert.throws(
            () => createTree().restore(snapshot),
            Error,
            "invalid snapshot: invalid selectedChild 'null' at root.children[0].children[0]"
        );
    });

    it("throws if an action that is not running has a promise result", () => {
        const snapshot = takeSnapshot();
        snapshot.root.children[0].children[0].children[0].promise = {
            isResolved: true,
            value: "mistreevous.succeeded"
        };
        snapshot.root.children[0].children[0].children[0].state = "mistreevous.ready";

        assert.throws(
            () => createTree().restore(snapshot),
            Error,
            "invalid snapshot: invalid promise at root.children[0].children[0].children[0]"
        );
    });

    it("leaves the tree as it was when the snapshot does not match it", () => {
        // Only the last node of the snapshot does not match the tree.
        const snapshot = takeSnapshot();
        snapshot.root.children[0].children[2].children[0].name = "D";

        const tree = createTree();
        tree.step();
        const before = tree.snapshot();

        assert.throws(() => tree.restore(snapshot), Error, "invalid snapshot");

        assert.deepEqual(tree.snapshot(), before);
    });
});

describe("Restoring a snapshot", () => {
    it("calls no agent functions, callbacks or random function, and reports no node state changes", () => {
        const definition = `root {
            sequence entry(Hook) step(Hook) exit(Hook) {
                lotto { action [A] action [B] }
                wait [100,200]
                repeat [1,3] { condition [Check] }
            }
        }`;
        const calls: string[] = [];
        const agent = {
            A: () => (calls.push("A"), State.RUNNING),
            B: () => (calls.push("B"), State.RUNNING),
            Check: () => (calls.push("Check"), true),
            Hook: () => calls.push("Hook")
        };

        const original = new BehaviourTree(definition, agent, { random: () => 0.5 });
        original.step();
        const snapshot = JSON.parse(JSON.stringify(original.snapshot()));

        calls.length = 0;
        const stateChanges: unknown[] = [];
        const restored = new BehaviourTree(definition, agent, {
            random: () => {
                calls.push("random");
                return 0.5;
            },
            onNodeStateChange: (change) => stateChanges.push(change)
        });
        restored.restore(snapshot);

        assert.deepEqual(calls, []);
        assert.deepEqual(stateChanges, []);
    });

    it("can be done to a tree that has already been stepped, replacing its state", () => {
        const definition = "root { sequence { action [A] action [B] } }";
        const limits = { A: 1, B: 1 };

        const logs: string[] = [];
        const first = new BehaviourTree(definition, createAgent([], limits, {}));
        first.step();
        const snapshot = JSON.parse(JSON.stringify(first.snapshot()));

        const second = new BehaviourTree(definition, createAgent(logs, limits, { A: 1, B: 1 }));
        second.step();
        assert.strictEqual(second.getState(), State.SUCCEEDED);

        second.restore(snapshot);

        assert.deepEqual(second.getTreeNodeDetails(), first.getTreeNodeDetails());
    });
});

describe("A restored tree", () => {
    const definitions: Record<string, string> = {
        sequence: "root { sequence { action [A] action [B] action [C] } }",
        selector: "root { selector { action [A] action [B] action [C] } }",
        parallel: "root { parallel { action [A] action [B] action [C] } }",
        race: "root { race { action [A] action [B] action [C] } }",
        all: "root { all { action [A] action [B] action [C] } }",
        flip: "root { flip { sequence { action [A] action [B] } } }",
        succeed: "root { succeed { sequence { action [A] action [B] } } }",
        fail: "root { fail { sequence { action [A] action [B] } } }",
        "nested repeat": "root { repeat [2] { sequence { action [A] repeat [2] { action [B] } } } }",
        "retry inside parallel": "root { parallel { retry [2] { action [C] } action [A] action [B] } }",
        branch: "root { sequence { branch [Sub] action [C] } } root [Sub] { sequence { action [A] action [B] } }"
    };

    Object.keys(definitions).forEach((name) => {
        it(`behaves like the original from any snapshot of a '${name}' tree`, () => {
            const limits: Limits = {
                A: 2,
                B: { calls: 3, then: State.FAILED },
                C: { calls: 2, then: State.SUCCEEDED }
            };

            for (let stepsBeforeSnapshot = 0; stepsBeforeSnapshot <= 8; stepsBeforeSnapshot++) {
                assertRestoredTreeMatchesOriginal(definitions[name], limits, stepsBeforeSnapshot, 8);
            }
        });
    });
});

describe("A restored tree with guards and callbacks", () => {
    it("aborts a running node whose guard is no longer satisfied, calling the exit callback as the original would", () => {
        const definition = `root {
            sequence {
                action [A] while(IsActive) exit(OnExit)
                action [B]
            }
        }`;
        const createAgent = (log: string[]) => ({
            isActive: true,
            IsActive: function (this: { isActive: boolean }) {
                return this.isActive;
            },
            A: () => (log.push("A"), State.RUNNING),
            B: () => (log.push("B"), State.RUNNING),
            OnExit: ({ succeeded, aborted }: { succeeded: boolean; aborted: boolean }) =>
                log.push(`exit ${succeeded} ${aborted}`)
        });

        const originalLog: string[] = [];
        const originalAgent = createAgent(originalLog);
        const original = new BehaviourTree(definition, originalAgent);
        original.step();

        const snapshot = JSON.parse(JSON.stringify(original.snapshot()));

        const restoredLog: string[] = [];
        const restoredAgent = createAgent(restoredLog);
        const restored = new BehaviourTree(definition, restoredAgent);
        restored.restore(snapshot);

        originalLog.length = 0;
        originalAgent.isActive = false;
        restoredAgent.isActive = false;

        original.step();
        restored.step();

        assert.deepEqual(originalLog, ["exit false true"]);
        assert.deepEqual(restoredLog, originalLog);
        assert.deepEqual(restored.getTreeNodeDetails(), original.getTreeNodeDetails());
    });
});

describe("A restored wait node, in unusual timing conditions", () => {
    let clock: SinonFakeTimers;

    beforeEach(() => {
        clock = sinon.useFakeTimers();
    });

    afterEach(() => {
        clock.restore();
    });

    it("does not count clock time that passes between the snapshot and the restore when 'getDeltaTime' is used", () => {
        const options = () => ({ getDeltaTime: () => 0.3 });

        const original = new BehaviourTree("root { wait [1000] }", {}, options());
        original.step();
        original.step();

        const snapshot = JSON.parse(JSON.stringify(original.snapshot()));

        clock.tick(60 * 60 * 1000);

        const restored = new BehaviourTree("root { wait [1000] }", {}, options());
        restored.restore(snapshot);

        restored.step();
        assert.strictEqual(restored.getState(), State.RUNNING);

        restored.step();
        assert.strictEqual(restored.getState(), State.SUCCEEDED);
    });

    it("can be restored from a snapshot taken after the clock went backwards", () => {
        clock.setSystemTime(10000);

        const original = new BehaviourTree("root { wait [1000] }", {});
        original.step();

        clock.setSystemTime(5000);

        const snapshot = JSON.parse(JSON.stringify(original.snapshot()));

        const restored = new BehaviourTree("root { wait [1000] }", {});
        restored.restore(snapshot);

        assert.deepEqual(restored.snapshot(), snapshot);
    });

    it("can be restored from a snapshot taken after an infinite delta time", () => {
        const original = new BehaviourTree("root { wait [1000] }", {}, { getDeltaTime: () => Infinity });
        original.step();

        const snapshot = JSON.parse(JSON.stringify(original.snapshot()));

        const restored = new BehaviourTree("root { wait [1000] }", {}, { getDeltaTime: () => Infinity });
        restored.restore(snapshot);

        assert.strictEqual(restored.getState(), State.SUCCEEDED);
    });
});

describe("Restoring a snapshot of a tree with a promise-based action", () => {
    it("is not affected by later changes to the snapshot object", async () => {
        const definition = "root { action [A] }";
        const agent = { A: () => Promise.reject(new Error("boom")) };

        const original = new BehaviourTree(definition, agent);
        original.step();
        await Promise.resolve();

        const snapshot = original.snapshot();

        const restored = new BehaviourTree(definition, agent);
        restored.restore(snapshot);

        (snapshot.root.children![0] as any).promise.value = "changed";

        assert.throws(() => restored.step(), Error, "promise rejected with 'Error: boom'");
    });
});

describe("A snapshot of a lotto node that failed its guard before picking a child", () => {
    it("can be restored", () => {
        const definition = "root { lotto while(IsOpen) { action [A] action [B] } }";
        const agent = { IsOpen: () => false, A: () => State.SUCCEEDED, B: () => State.SUCCEEDED };

        const original = new BehaviourTree(definition, agent);
        original.step();
        assert.strictEqual(original.getState(), State.FAILED);

        const restored = new BehaviourTree(definition, agent);
        restored.restore(JSON.parse(JSON.stringify(original.snapshot())));

        assert.strictEqual(restored.getState(), State.FAILED);
        assert.deepEqual(restored.getTreeNodeDetails(), original.getTreeNodeDetails());
    });
});

describe("The definition recorded in a snapshot", () => {
    const richMDSL = `root {
        sequence while(IsOpen, 1, "x", null, true) entry(Hook) {
            action [Act, 1]
            repeat [2,3] { wait [10,20] }
            lotto [1,2] { action [B] condition [Check, $flag] }
            branch [Sub]
        }
    }
    root [Sub] { retry [2] until(Done) { action [C] } }`;

    // The MDSL definition above written as JSON the way a person would, without the defaults that MDSL conversion adds.
    const richJSON: RootNodeDefinition[] = [
        {
            type: "root",
            child: {
                type: "sequence",
                while: { call: "IsOpen", args: [1, "x", null, true] },
                entry: { call: "Hook" },
                children: [
                    { type: "action", call: "Act", args: [1] },
                    { type: "repeat", iterations: [2, 3], child: { type: "wait", duration: [10, 20] } },
                    {
                        type: "lotto",
                        weights: [1, 2],
                        children: [
                            { type: "action", call: "B" },
                            { type: "condition", call: "Check", args: [{ $: "flag" }] }
                        ]
                    },
                    { type: "branch", ref: "Sub" }
                ]
            }
        },
        {
            type: "root",
            id: "Sub",
            child: {
                type: "retry",
                attempts: 2,
                until: { call: "Done", succeedOnAbort: false },
                child: { type: "action", call: "C" }
            }
        }
    ];

    const agent = {
        flag: true,
        IsOpen: () => true,
        IsClosed: () => true,
        Hook: () => {},
        Act: () => State.SUCCEEDED,
        B: () => State.RUNNING,
        Check: () => true,
        Done: () => false,
        C: () => State.RUNNING
    };

    const createTree = (definition: Definition) => new BehaviourTree(definition, agent);

    const takeSnapshot = (definition: Definition) => {
        const tree = createTree(definition);
        tree.step();
        return JSON.parse(JSON.stringify(tree.snapshot()));
    };

    it("is a string", () => {
        assert.isString(takeSnapshot(richMDSL).definition);
    });

    it("is the same for trees built from the same definition", () => {
        assert.strictEqual(takeSnapshot(richMDSL).definition, takeSnapshot(richMDSL).definition);
    });

    it("is the same for an MDSL definition and its equivalent JSON definition", () => {
        assert.strictEqual(takeSnapshot(richMDSL).definition, takeSnapshot(richJSON).definition);
    });

    it("is the same for root nodes in a different order and for MDSL with different formatting", () => {
        const reordered = [richJSON[1], richJSON[0]];
        const reformatted = richMDSL.replace(/\s+/g, " ") + " /* a comment */";

        assert.strictEqual(takeSnapshot(richMDSL).definition, takeSnapshot(reordered).definition);
        assert.strictEqual(takeSnapshot(richMDSL).definition, takeSnapshot(reformatted).definition);
    });

    it("is the same for a single root node object and an array holding it", () => {
        const root: RootNodeDefinition = { type: "root", child: { type: "action", call: "Act" } };

        assert.strictEqual(takeSnapshot(root).definition, takeSnapshot([root]).definition);
    });

    it("lets an MDSL snapshot be restored into a JSON tree, and a JSON snapshot into an MDSL tree", () => {
        const mdslTree = createTree(richMDSL);
        const jsonTree = createTree(richJSON);

        mdslTree.step();
        jsonTree.restore(JSON.parse(JSON.stringify(mdslTree.snapshot())));
        assert.deepEqual(jsonTree.getTreeNodeDetails(), mdslTree.getTreeNodeDetails());

        jsonTree.step();
        mdslTree.restore(JSON.parse(JSON.stringify(jsonTree.snapshot())));
        assert.deepEqual(mdslTree.getTreeNodeDetails(), jsonTree.getTreeNodeDetails());
    });

    // Each of these definitions has the node types, node names and numbers of children of the MDSL definition above.
    const differentDefinitions: [string, Definition][] = [
        ["an action argument", richMDSL.replace("Act, 1", "Act, 2")],
        ["a condition argument", richMDSL.replace("$flag", "$other")],
        ["a guard", richMDSL.replace("while(IsOpen", "while(IsClosed")],
        ["a guard argument", richMDSL.replace('"x"', '"y"')],
        ["a guard abort state", richMDSL.replace("until(Done)", "until(Done, true)")],
        ["a callback", richMDSL.replace("entry(Hook)", "exit(Hook)")],
        ["a lotto weight", richMDSL.replace("lotto [1,2]", "lotto [2,1]")],
        ["a subtree", richMDSL.replace("action [C] }", "action [D] }")],
        ["an unused root node", richMDSL + " root [Unused] { action [E] }"],
        [
            "a JSON definition with a different argument",
            JSON.parse(JSON.stringify(richJSON).replace('"args":[1]', '"args":[3]'))
        ]
    ];

    differentDefinitions.forEach(([difference, definition]) => {
        it(`is not the same for definitions that differ in ${difference}`, () => {
            assert.notStrictEqual(takeSnapshot(definition).definition, takeSnapshot(richMDSL).definition);
        });
    });

    it("is not the same for definitions that differ in the type, name or number of children of a node", () => {
        const definitions = [
            "root { sequence { action [Act] action [B] } }",
            "root { selector { action [Act] action [B] } }",
            "root { sequence { action [Act] action [C] } }",
            "root { sequence { action [Act] } }"
        ];

        const fingerprints = definitions.map((definition) => takeSnapshot(definition).definition);

        assert.strictEqual(new Set(fingerprints).size, definitions.length);
    });
});

describe("Restoring a snapshot of another tree definition", () => {
    const createTree = (definition: Definition, options: BehaviourTreeOptions = {}) =>
        new BehaviourTree(definition, { A: () => State.RUNNING, B: () => State.RUNNING }, options);

    const takeSnapshot = (definition: Definition) => {
        const tree = createTree(definition);
        tree.step();
        return JSON.parse(JSON.stringify(tree.snapshot()));
    };

    const expectedMessage = "the snapshot does not match the tree's definition";

    it("throws an error saying that the snapshot does not match the tree's definition", () => {
        const snapshot = takeSnapshot("root { sequence { action [A] action [B] } }");

        assert.throws(
            () => createTree("root { selector { action [A] action [B] } }").restore(snapshot),
            Error,
            expectedMessage
        );
    });

    it("throws when only an action argument differs, which the node names do not show", () => {
        const snapshot = takeSnapshot("root { action [A, 1] }");

        assert.throws(() => createTree("root { action [A, 2] }").restore(snapshot), Error, expectedMessage);
    });

    it("throws for a JSON definition that differs from an MDSL one", () => {
        const snapshot = takeSnapshot("root { sequence { action [A] action [B] } }");
        const definition: RootNodeDefinition = {
            type: "root",
            child: {
                type: "sequence",
                children: [
                    { type: "action", call: "A" },
                    { type: "action", call: "A" }
                ]
            }
        };

        assert.throws(() => createTree(definition).restore(snapshot), Error, expectedMessage);
    });

    it("leaves the tree exactly as it was, and calls neither agent functions nor the state change callback", () => {
        const onNodeStateChange = sinon.spy();
        const snapshot = takeSnapshot("root { sequence { action [A, 2] wait [1000] } }");

        const tree = createTree("root { sequence { action [A, 1] wait [1000] } }", { onNodeStateChange });
        tree.step();

        const snapshotBefore = tree.snapshot();
        const detailsBefore = tree.getTreeNodeDetails();
        onNodeStateChange.resetHistory();

        assert.throws(() => tree.restore(snapshot), Error, expectedMessage);

        assert.deepEqual(tree.snapshot(), snapshotBefore);
        assert.deepEqual(tree.getTreeNodeDetails(), detailsBefore);
        assert.isFalse(onNodeStateChange.called);
    });
});

describe("Restoring something that is not a snapshot", () => {
    const createTree = () =>
        new BehaviourTree("root { sequence { action [A] action [B] } }", {
            A: () => State.SUCCEEDED,
            B: () => State.RUNNING
        });

    const takeSnapshot = () => {
        const tree = createTree();
        tree.step();
        return JSON.parse(JSON.stringify(tree.snapshot()));
    };

    const withoutDefinition = () => {
        const snapshot = takeSnapshot();
        delete snapshot.definition;
        return snapshot;
    };

    const notSnapshots: [string, unknown][] = [
        ["null", null],
        ["undefined", undefined],
        ["a string", "snapshot"],
        ["a number", 1],
        ["a boolean", true],
        ["an array", [takeSnapshot()]],
        ["an empty array", []],
        ["an empty object", {}],
        ["an object with other fields", { state: "mistreevous.running" }],
        ["a snapshot without a root", { ...takeSnapshot(), root: undefined }],
        ["a snapshot without a version", { ...takeSnapshot(), version: undefined }],
        ["a snapshot without a definition", withoutDefinition()],
        ["a snapshot with a definition that is not a string", { ...takeSnapshot(), definition: 1 }],
        ["the snapshot of a node", takeSnapshot().root]
    ];

    notSnapshots.forEach(([description, value]) => {
        it(`throws an error for ${description} and leaves the tree as it was`, () => {
            const tree = createTree();
            tree.step();
            const before = tree.snapshot();

            assert.throws(() => tree.restore(value as any), Error);

            assert.deepEqual(tree.snapshot(), before);
        });
    });
});

describe("Restoring a snapshot and node state changes", () => {
    const definition = `root {
        sequence {
            lotto { action [A] action [B] }
            repeat [2] { action [A] }
            retry [2] { action [B] }
            wait [100]
            action [P]
        }
    }`;

    function createAgent() {
        let calls = 0;
        return {
            A: () => (++calls % 2 === 0 ? State.SUCCEEDED : State.RUNNING),
            B: () => (++calls % 2 === 0 ? State.FAILED : State.RUNNING),
            P: () => Promise.resolve(State.SUCCEEDED)
        };
    }

    [0, 1, 2, 3, 5, 8].forEach((stepsBeforeSnapshot) => {
        [0, 4].forEach((stepsBeforeRestore) => {
            it(`does not call onNodeStateChange after ${stepsBeforeSnapshot} steps, restored into a tree stepped ${stepsBeforeRestore} times, and the next step reports changes as usual`, () => {
                const original = new BehaviourTree(definition, createAgent(), { random: () => 0.5 });
                for (let step = 0; step < stepsBeforeSnapshot; step++) {
                    original.step();
                }
                const snapshot = JSON.parse(JSON.stringify(original.snapshot()));

                const stateChanges: { id: string; previousState: State; state: State }[] = [];
                const restored = new BehaviourTree(definition, createAgent(), {
                    random: () => 0.5,
                    onNodeStateChange: (change) => stateChanges.push(change)
                });
                for (let step = 0; step < stepsBeforeRestore; step++) {
                    restored.step();
                }

                stateChanges.length = 0;
                restored.restore(snapshot);
                assert.deepEqual(stateChanges, []);

                restored.step();
                stateChanges.forEach((change) => assert.notStrictEqual(change.previousState, change.state));
            });
        });
    });

    it("reports the transitions of the next step with the restored state as their previous state", () => {
        const definition = "root { sequence { action [A] action [B] } }";
        const agent = { A: () => State.SUCCEEDED, B: () => State.RUNNING };

        const original = new BehaviourTree(definition, agent);
        original.step();
        const snapshot = JSON.parse(JSON.stringify(original.snapshot()));

        const stateChanges: { type: string; previousState: State; state: State }[] = [];
        const restored = new BehaviourTree(definition, agent, {
            onNodeStateChange: ({ type, previousState, state }) => stateChanges.push({ type, previousState, state })
        });
        restored.restore(snapshot);
        restored.step();

        assert.deepEqual(stateChanges, []);

        agent.B = () => State.SUCCEEDED;
        restored.step();

        assert.deepEqual(stateChanges, [
            { type: "action", previousState: State.RUNNING, state: State.SUCCEEDED },
            { type: "sequence", previousState: State.RUNNING, state: State.SUCCEEDED },
            { type: "root", previousState: State.RUNNING, state: State.SUCCEEDED }
        ]);
    });
});

describe("A snapshot and the tree it is taken from or restored into", () => {
    const definition = `root {
        sequence {
            lotto { action [A] action [B] }
            repeat [2,3] { action [A] }
            retry [2,3] { action [B] }
            wait [100,200]
            action [P]
        }
    }`;

    function createAgent() {
        let calls = 0;
        return {
            A: () => (++calls % 3 === 0 ? State.SUCCEEDED : State.RUNNING),
            B: () => (++calls % 3 === 0 ? State.FAILED : State.RUNNING),
            P: () => Promise.resolve(State.SUCCEEDED)
        };
    }

    const toPlain = (value: unknown) => JSON.parse(JSON.stringify(value));

    [0, 1, 2, 4, 7].forEach((stepsBeforeSnapshot) => {
        describe(`after ${stepsBeforeSnapshot} steps`, () => {
            let clock: SinonFakeTimers;

            beforeEach(() => {
                clock = sinon.useFakeTimers(1000);
            });

            afterEach(() => {
                clock.restore();
            });

            function stepAndSnapshot() {
                const tree = new BehaviourTree(definition, createAgent(), { random: () => 0.4 });
                for (let step = 0; step < stepsBeforeSnapshot; step++) {
                    tree.step();
                    clock.tick(30);
                }
                return { tree, snapshot: tree.snapshot() };
            }

            async function stepMore(tree: BehaviourTree) {
                for (let step = 0; step < 10; step++) {
                    try {
                        tree.step();
                    } catch {
                        // A rejected promise or invalid action result is not what is being tested.
                    }
                    await Promise.resolve();
                    clock.tick(30);
                }
            }

            it("is not changed by stepping the tree it was taken from", async () => {
                const { tree, snapshot } = stepAndSnapshot();
                const before = toPlain(snapshot);

                await stepMore(tree);

                assert.deepEqual(snapshot, before);
            });

            it("is not changed by stepping a tree it was restored into", async () => {
                const { snapshot } = stepAndSnapshot();
                const before = toPlain(snapshot);

                const restored = new BehaviourTree(definition, createAgent(), { random: () => 0.4 });
                restored.restore(snapshot);
                await stepMore(restored);

                assert.deepEqual(snapshot, before);
            });

            it("is not changed by restoring it", () => {
                const { snapshot } = stepAndSnapshot();
                const before = toPlain(snapshot);

                new BehaviourTree(definition, createAgent(), { random: () => 0.4 }).restore(snapshot);

                assert.deepEqual(snapshot, before);
            });

            it("equals a snapshot taken from the restored tree before it is stepped", () => {
                const { snapshot } = stepAndSnapshot();

                const restored = new BehaviourTree(definition, createAgent(), { random: () => 0.4 });
                restored.restore(snapshot);

                assert.deepEqual(toPlain(restored.snapshot()), toPlain(snapshot));
            });

            it("equals a snapshot taken from the restored tree before it is stepped, when it was passed through JSON", () => {
                const { snapshot } = stepAndSnapshot();

                const restored = new BehaviourTree(definition, createAgent(), { random: () => 0.4 });
                restored.restore(toPlain(snapshot));

                assert.deepEqual(toPlain(restored.snapshot()), toPlain(snapshot));
            });
        });
    });

    it("is not changed by a promise that settles after it was taken", async () => {
        const definition = "root { action [P] }";
        let resolve: (state: State.SUCCEEDED) => void = () => {};
        const tree = new BehaviourTree(definition, { P: () => new Promise<State.SUCCEEDED>((r) => (resolve = r)) });

        tree.step();
        const snapshot = tree.snapshot();
        const before = toPlain(snapshot);

        resolve(State.SUCCEEDED);
        await Promise.resolve();
        tree.step();

        assert.deepEqual(snapshot, before);
    });

    it("keeps a settled promise result of an action that is restored and stepped, leaving the snapshot as it was", async () => {
        const definition = "root { action [P] }";
        const agent = { P: () => Promise.resolve(State.SUCCEEDED) };

        const original = new BehaviourTree(definition, agent);
        original.step();
        await Promise.resolve();
        const snapshot = original.snapshot();
        const before = toPlain(snapshot);

        const restored = new BehaviourTree(definition, agent);
        restored.restore(snapshot);
        assert.deepEqual(toPlain(restored.snapshot()), before);

        restored.step();
        assert.strictEqual(restored.getState(), State.SUCCEEDED);
        assert.deepEqual(snapshot, before);
    });
});
