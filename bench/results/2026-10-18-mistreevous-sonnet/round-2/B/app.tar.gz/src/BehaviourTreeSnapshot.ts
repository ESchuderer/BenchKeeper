import { AnyState } from "./State";
import { RootNodeDefinition } from "./BehaviourTreeDefinition";

/**
 * The snapshot of a single node, and the nodes beneath it.
 * Only the properties that are relevant to the type of the node are defined.
 */
export type NodeSnapshot = {
    /**
     * The tree node identifier.
     */
    id: string;
    /**
     * The tree node type.
     */
    type: string;
    /**
     * The tree node name, which is used to check that the snapshot is for the same tree definition.
     */
    name: string;
    /**
     * The state of the tree node.
     */
    state: AnyState;
    /**
     * The snapshots of the child nodes, defined if this is a composite or decorator node.
     */
    children?: NodeSnapshot[];
    /**
     * The number of iterations to make, or null if there is no limit, defined if this is a repeat node.
     */
    targetIterationCount?: number | null;
    /**
     * The number of iterations completed, defined if this is a repeat node.
     */
    currentIterationCount?: number;
    /**
     * The number of attempts to make, or null if there is no limit, defined if this is a retry node.
     */
    targetAttemptCount?: number | null;
    /**
     * The number of attempts completed, defined if this is a retry node.
     */
    currentAttemptCount?: number;
    /**
     * The index of the child that was picked, or null if none has been, defined if this is a lotto node.
     */
    selectedChildIndex?: number | null;
    /**
     * The duration in milliseconds to wait for, or null to wait indefinitely, defined if this is a wait node.
     */
    totalDuration?: number | null;
    /**
     * The duration in milliseconds that has been waited for, defined if this is a wait node.
     */
    waitedDuration?: number;
    /**
     * The settled result of the promise returned by the action function, defined if this is an action node that is using a promise.
     * The value is converted to a string.
     */
    updatePromiseResult?: { isResolved: boolean; value: string };
};

/**
 * The snapshot of the execution state of a behaviour tree. This is a plain object that can be serialised as JSON.
 */
export type BehaviourTreeSnapshot = {
    /**
     * The snapshot format version.
     */
    version: 1;
    /**
     * An identifier of the definition of the tree that the snapshot was taken from, which is the same for an MDSL definition and its JSON equivalent.
     */
    definition: string;
    /**
     * The snapshot of the root node.
     */
    root: NodeSnapshot;
};

/**
 * Sorts object keys and drops the values that MDSL always includes but that JSON can leave out, so that equivalent definitions look the same.
 * The arguments of a node are left as they are, as they can be any valid JSON.
 */
const canonicalise = (value: unknown, inArgs = false): unknown => {
    if (Array.isArray(value)) {
        return value.map((item) => canonicalise(item, inArgs));
    }

    if (typeof value !== "object" || value === null) {
        return value;
    }

    return Object.fromEntries(
        Object.entries(value)
            .filter(
                ([key, item]) =>
                    inArgs ||
                    !(
                        (key === "args" && Array.isArray(item) && !item.length) ||
                        (key === "succeedOnAbort" && item === false)
                    )
            )
            .sort(([a], [b]) => (a < b ? -1 : 1))
            .map(([key, item]) => [key, canonicalise(item, inArgs || key === "args")])
    );
};

/**
 * Gets an identifier of a tree definition, which is the same for an MDSL definition and its JSON equivalent.
 * @param rootNodeDefinitions The root node definitions of the tree, as returned by definition validation.
 * @returns The definition identifier, a 53 bit hash (cyrb53) of the canonical definition.
 */
export function getDefinitionId(rootNodeDefinitions: RootNodeDefinition[]): string {
    const roots = [...rootNodeDefinitions].sort((a, b) => ((a.id ?? "") < (b.id ?? "") ? -1 : 1));
    const text = JSON.stringify(canonicalise(roots));

    let h1 = 0xdeadbeef;
    let h2 = 0x41c6ce57;

    for (let i = 0; i < text.length; i++) {
        h1 = Math.imul(h1 ^ text.charCodeAt(i), 2654435761);
        h2 = Math.imul(h2 ^ text.charCodeAt(i), 1597334677);
    }

    h1 = Math.imul(h1 ^ (h1 >>> 16), 2246822507) ^ Math.imul(h2 ^ (h2 >>> 13), 3266489909);
    h2 = Math.imul(h2 ^ (h2 >>> 16), 2246822507) ^ Math.imul(h1 ^ (h1 >>> 13), 3266489909);

    return (4294967296 * (2097151 & h2) + (h1 >>> 0)).toString(16);
}

/**
 * Gets whether a value is a valid number for use in a snapshot.
 * @param value The value to check.
 * @param integer Whether the number must be a non-negative integer, rather than just a finite number.
 */
export const isSnapshotNumber = (value: unknown, integer = false): value is number =>
    typeof value === "number" && Number.isFinite(value) && (!integer || (Number.isInteger(value) && value >= 0));

/**
 * Throws an error unless the condition holds.
 * @param condition The condition to check.
 * @param message The error message.
 */
export function assertSnapshot(condition: unknown, message: string): asserts condition {
    if (!condition) {
        throw new Error(message);
    }
}
