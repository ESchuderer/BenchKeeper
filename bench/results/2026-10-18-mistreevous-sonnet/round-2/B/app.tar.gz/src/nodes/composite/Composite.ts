import Node, { NodeDetails } from "../Node";
import { NodeSnapshot, assertSnapshot } from "../../BehaviourTreeSnapshot";
import State from "../../State";
import { Agent } from "../../Agent";
import Attribute from "../../attributes/Attribute";
import { BehaviourTreeOptions } from "../../BehaviourTreeOptions";

/**
 * A composite node that wraps child nodes.
 */
export default abstract class Composite extends Node {
    /**
     * @param type The node type.
     * @param attributes The node attributes.
     * @param options The behaviour tree options.
     * @param children The child nodes.
     */
    constructor(type: string, attributes: Attribute[], options: BehaviourTreeOptions, protected children: Node[]) {
        super(type, attributes, options);
    }

    /**
     * Gets the children of this node.
     */
    getChildren = () => this.children;

    /**
     * Reset the state of the node.
     */
    reset = () => {
        // Reset the state of this node.
        this.setState(State.READY);

        // Reset the state of any child nodes.
        this.children.forEach((child) => child.reset());
    };

    /**
     * Abort the running of this node.
     * @param agent The agent.
     */
    abort = (agent: Agent) => {
        // There is nothing to do if this node is not in the running state.
        if (!this.is(State.RUNNING)) {
            return;
        }

        // Abort any child nodes.
        this.children.forEach((child) => child.abort(agent));

        // Reset the state of this node.
        this.reset();

        this.attributes.exit?.callAgentFunction(agent, false, true);
    };

    /**
     * Gets the snapshot of this node instance.
     * @returns The snapshot of this node instance.
     */
    public getSnapshot(): NodeSnapshot {
        return {
            ...super.getSnapshot(),
            children: this.children.map((child) => child.getSnapshot())
        };
    }

    /**
     * Checks that a snapshot can be restored to this node instance.
     * @param snapshot The snapshot to restore.
     * @returns A function that restores the snapshot, which will not throw as the snapshot has been checked.
     */
    public prepareRestore(snapshot: NodeSnapshot): () => void {
        const restoreNode = super.prepareRestore(snapshot);
        const children = this.children;

        assertSnapshot(
            Array.isArray(snapshot.children) && snapshot.children.length === children.length,
            `expected the snapshot of a '${this.getType()}' node to have ${children.length} children`
        );

        const restoreChildren = children.map((child, index) => child.prepareRestore(snapshot.children![index]));

        return () => {
            restoreNode();
            restoreChildren.forEach((restoreChild) => restoreChild());
        };
    }

    /**
     * Gets the details of this node instance.
     * @returns The details of this node instance.
     */
    public getDetails(): NodeDetails {
        return {
            ...super.getDetails(),
            children: this.children.map((child) => child.getDetails())
        };
    }
}
