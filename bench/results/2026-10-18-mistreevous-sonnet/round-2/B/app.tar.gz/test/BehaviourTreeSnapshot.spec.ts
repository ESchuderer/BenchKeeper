import { assert } from "chai";
import sinon, { SinonFakeTimers } from "sinon";

import { BehaviourTree, BehaviourTreeOptions, BehaviourTreeSnapshot, State } from "../src/index";
import { Agent } from "../src/Agent";
import { RootNodeDefinition } from "../src/BehaviourTreeDefinition";

import { findNode } from "./TestUtilities";

type Definition = string | RootNodeDefinition | RootNodeDefinition[];

/**
 * A tree and the agent functions that it calls, which log their names so that two trees can be compared.
 * The functions 'a', 'b' and 'c' are actions returning whatever is set for them in 'results'.
 * The function 'ok' is a condition returning the value of 'isOk'. The callbacks 'enter' and 'leave' just log.
 */
class Run {
    public readonly log: string[] = [];
    public readonly results: { [name: string]: State.SUCCEEDED | State.FAILED | undefined } = {};
    public isOk = true;
    public readonly tree: BehaviourTree;

    constructor(definition: Definition, options: BehaviourTreeOptions = {}) {
        const agent: Agent = {
            ok: () => (this.log.push("ok"), this.isOk),
            enter: () => void this.log.push("enter"),
            leave: () => void this.log.push("leave")
        };

        for (const name of ["a", "b", "c"]) {
            agent[name] = () => (this.log.push(name), this.results[name]);
        }

        this.tree = new BehaviourTree(definition, agent, options);
    }
}

/** Takes a snapshot, passing it through JSON the way that an application storing it would. */
const takeStoredSnapshot = (run: Run): BehaviourTreeSnapshot => JSON.parse(JSON.stringify(run.tree.snapshot()));

/** Creates a new run from the same definition, restored to the state of an existing run. */
const createRestoredRun = (original: Run, definition: Definition, options: BehaviourTreeOptions = {}): Run => {
    const restored = new Run(definition, options);
    Object.assign(restored.results, original.results);
    restored.isOk = original.isOk;
    restored.tree.restore(takeStoredSnapshot(original));
    return restored;
};

/** Steps a run until its tree succeeds. */
const runToCompletion = (run: Run) => {
    while (run.tree.getState() !== State.SUCCEEDED) {
        run.tree.step();
    }
};

/** Steps both runs the same number of times, asserting that they behave identically after each step. */
const assertStepsMatch = (original: Run, restored: Run, steps: number, onStep: (run: Run, step: number) => void) => {
    original.log.length = 0;
    restored.log.length = 0;

    assert.deepEqual(restored.tree.getTreeNodeDetails(), original.tree.getTreeNodeDetails());

    for (let step = 0; step < steps; step++) {
        for (const run of [original, restored]) {
            onStep(run, step);
            run.tree.step();
        }

        assert.deepEqual(restored.log, original.log, `agent calls differ after step ${step}`);
        assert.deepEqual(
            restored.tree.getTreeNodeDetails(),
            original.tree.getTreeNodeDetails(),
            `node details differ after step ${step}`
        );
    }
};

describe("A BehaviourTree snapshot", () => {
    describe("is a plain object that survives JSON serialisation unchanged", () => {
        it("for a tree that has not been stepped", () => {
            const run = new Run("root { sequence { repeat [2,3] { action [a] } lotto { action [b] action [c] } } }");
            const snapshot = run.tree.snapshot();
            assert.deepEqual(JSON.parse(JSON.stringify(snapshot)), snapshot);
        });

        it("for a tree that is part way through its execution", () => {
            const run = new Run(
                "root { sequence { retry [2,3] { action [a] } repeat [2,3] { action [b] } wait [10,20] lotto { action [c] } } }",
                { random: () => 0.5 }
            );
            run.results.a = State.FAILED;
            run.results.b = State.SUCCEEDED;
            run.tree.step();
            run.tree.step();
            run.tree.step();
            run.results.a = State.SUCCEEDED;
            run.tree.step();

            const snapshot = run.tree.snapshot();
            assert.deepEqual(JSON.parse(JSON.stringify(snapshot)), snapshot);
        });
    });

    describe("restores composite node progress", () => {
        for (const type of ["sequence", "selector", "parallel", "race", "all"]) {
            it(`for a ${type} node`, () => {
                const definition = `root { ${type} { action [a] action [b] action [c] } }`;
                const original = new Run(definition);
                original.results.a = type === "selector" ? State.FAILED : State.SUCCEEDED;
                original.tree.step();

                const restored = createRestoredRun(original, definition);

                assertStepsMatch(original, restored, 4, (run, step) => {
                    if (step === 1) {
                        run.results.b = State.SUCCEEDED;
                    }
                    if (step === 2) {
                        run.results.c = State.FAILED;
                    }
                });
            });
        }
    });

    describe("restores decorator node progress", () => {
        for (const type of ["flip", "succeed", "fail"]) {
            it(`for a ${type} node`, () => {
                const definition = `root { sequence { ${type} { action [a] } action [b] } }`;
                const original = new Run(definition);
                original.tree.step();

                const restored = createRestoredRun(original, definition);

                assertStepsMatch(original, restored, 3, (run, step) => {
                    if (step === 1) {
                        run.results.a = State.SUCCEEDED;
                    }
                });
            });
        }
    });

    describe("restores the iteration count of a repeat node", () => {
        it("with an explicit iteration count", () => {
            const definition = "root { repeat [3] { action [a] } }";
            const original = new Run(definition);
            original.results.a = State.SUCCEEDED;
            original.tree.step();
            original.tree.step();

            const restored = createRestoredRun(original, definition);

            assertStepsMatch(original, restored, 2, () => {});
            assert.strictEqual(original.tree.getState(), State.SUCCEEDED);
            assert.strictEqual(restored.tree.getState(), State.SUCCEEDED);
        });

        it("with a random iteration count that was already chosen", () => {
            const definition = "root { repeat [2,5] { action [a] } }";
            const original = new Run(definition, { random: () => 0 });
            original.results.a = State.SUCCEEDED;
            original.tree.step();

            // The restored tree would pick five iterations if it chose again, the original picked two.
            const restored = createRestoredRun(original, definition, { random: () => 0.99 });

            assertStepsMatch(original, restored, 2, () => {});
            assert.strictEqual(restored.tree.getState(), State.SUCCEEDED);
        });

        it("without an iteration count", () => {
            const definition = "root { repeat { action [a] } }";
            const original = new Run(definition);
            original.results.a = State.SUCCEEDED;
            original.tree.step();

            const restored = createRestoredRun(original, definition);

            assertStepsMatch(original, restored, 3, () => {});
        });
    });

    describe("restores the attempt count of a retry node", () => {
        it("with an explicit attempt count", () => {
            const definition = "root { retry [3] { action [a] } }";
            const original = new Run(definition);
            original.results.a = State.FAILED;
            original.tree.step();
            original.tree.step();

            const restored = createRestoredRun(original, definition);

            assertStepsMatch(original, restored, 2, () => {});
            assert.strictEqual(original.tree.getState(), State.FAILED);
            assert.strictEqual(restored.tree.getState(), State.FAILED);
        });

        it("with a random attempt count that was already chosen", () => {
            const definition = "root { retry [2,5] { action [a] } }";
            const original = new Run(definition, { random: () => 0 });
            original.results.a = State.FAILED;
            original.tree.step();

            const restored = createRestoredRun(original, definition, { random: () => 0.99 });

            assertStepsMatch(original, restored, 2, () => {});
            assert.strictEqual(restored.tree.getState(), State.FAILED);
        });
    });

    describe("restores the child picked by a lotto node", () => {
        it("rather than picking again", () => {
            const definition = "root { lotto { action [a] action [b] action [c] } }";
            const original = new Run(definition, { random: () => 0.99 });
            original.tree.step();

            const control = new Run(definition, { random: () => 0 });
            control.tree.step();
            assert.notDeepEqual(control.log, original.log, "the test needs the two random values to pick differently");

            const restored = createRestoredRun(original, definition, { random: () => 0 });

            assertStepsMatch(original, restored, 1, (run) => {
                run.results.a = run.results.b = run.results.c = State.SUCCEEDED;
            });
            assert.strictEqual(restored.tree.getState(), State.SUCCEEDED);
        });
    });

    describe("restores guards and callbacks", () => {
        it("so that a restored node is not entered again and its guard still aborts it", () => {
            const definition = "root { sequence { action [a] entry(enter) exit(leave) while(ok) action [b] } }";
            const original = new Run(definition);
            original.tree.step();

            const restored = createRestoredRun(original, definition);

            assertStepsMatch(original, restored, 3, (run, step) => {
                if (step === 1) {
                    run.isOk = false;
                }
            });
            assert.include(restored.log, "leave");
        });
    });

    describe("restores wait nodes", () => {
        let clock: SinonFakeTimers;

        beforeEach(() => {
            clock = sinon.useFakeTimers();
        });

        afterEach(() => {
            clock.restore();
        });

        it("so that they only wait for the remaining time when using the clock", () => {
            const definition = "root { wait [1000] }";
            const original = new Run(definition);
            original.tree.step();
            clock.tick(600);

            const stored = takeStoredSnapshot(original);

            // Time passes while the process is down, none of which should count towards the wait.
            clock.tick(5 * 24 * 60 * 60 * 1000);

            const restored = new Run(definition);
            restored.tree.restore(stored);

            restored.tree.step();
            assert.strictEqual(findNode(restored.tree, "wait").state, State.RUNNING);

            clock.tick(399);
            restored.tree.step();
            assert.strictEqual(findNode(restored.tree, "wait").state, State.RUNNING);

            clock.tick(1);
            restored.tree.step();
            assert.strictEqual(findNode(restored.tree, "wait").state, State.SUCCEEDED);
        });

        it("so that a snapshot taken between steps counts the time up to the snapshot", () => {
            const definition = "root { wait [1000] }";
            const original = new Run(definition);
            original.tree.step();

            // The last step was at 0ms, but 900ms had passed by the time of the snapshot.
            clock.tick(900);
            const stored = takeStoredSnapshot(original);
            clock.tick(60 * 1000);

            const restored = new Run(definition);
            restored.tree.restore(stored);

            clock.tick(99);
            restored.tree.step();
            assert.strictEqual(findNode(restored.tree, "wait").state, State.RUNNING);

            clock.tick(1);
            restored.tree.step();
            assert.strictEqual(findNode(restored.tree, "wait").state, State.SUCCEEDED);
        });

        it("so that they only wait for the remaining time when using getDeltaTime", () => {
            const definition = "root { wait [1000] }";
            let deltaTime = 0.4;
            const original = new Run(definition, { getDeltaTime: () => deltaTime });
            original.tree.step();
            original.tree.step();

            const stored = takeStoredSnapshot(original);
            clock.tick(5 * 24 * 60 * 60 * 1000);

            const restored = new Run(definition, { getDeltaTime: () => deltaTime });
            restored.tree.restore(stored);

            // 800ms had been waited, so one more step of 400ms should finish the wait.
            deltaTime = 0.1;
            restored.tree.step();
            assert.strictEqual(findNode(restored.tree, "wait").state, State.RUNNING);

            deltaTime = 0.1;
            restored.tree.step();
            assert.strictEqual(findNode(restored.tree, "wait").state, State.SUCCEEDED);
        });

        it("so that a random duration that was already chosen is kept", () => {
            const definition = "root { wait [100,1000] }";
            const original = new Run(definition, { random: () => 0 });
            original.tree.step();

            // The restored tree would pick a duration of 1000ms if it chose again, the original picked 100ms.
            const restored = createRestoredRun(original, definition, { random: () => 0.999 });
            clock.tick(100);

            original.tree.step();
            restored.tree.step();

            assert.strictEqual(findNode(original.tree, "wait").state, State.SUCCEEDED);
            assert.strictEqual(findNode(restored.tree, "wait").state, State.SUCCEEDED);
        });

        it("without a duration, which keep waiting", () => {
            const definition = "root { wait }";
            const original = new Run(definition);
            original.tree.step();

            const restored = createRestoredRun(original, definition);
            clock.tick(100000);
            restored.tree.step();

            assert.strictEqual(findNode(restored.tree, "wait").state, State.RUNNING);
        });
    });

    describe("of a finished tree", () => {
        it("restores as finished and starts a new run that makes its own random choices", () => {
            const definition = "root { sequence { repeat [2,5] { action [a] } lotto { action [b] action [c] } } }";
            const original = new Run(definition, { random: () => 0 });
            original.results.a = original.results.b = original.results.c = State.SUCCEEDED;
            runToCompletion(original);

            const restored = createRestoredRun(original, definition, { random: () => 0.99 });

            assert.strictEqual(restored.tree.getState(), State.SUCCEEDED);
            assert.deepEqual(restored.tree.getTreeNodeDetails(), original.tree.getTreeNodeDetails());

            // The next run of the restored tree should use the random function of the restored tree.
            const control = new Run(definition, { random: () => 0.99 });
            Object.assign(control.results, restored.results);
            runToCompletion(control);
            control.log.length = 0;
            restored.log.length = 0;
            control.tree.step();
            restored.tree.step();
            while (control.tree.isRunning()) {
                control.tree.step();
                restored.tree.step();
            }

            assert.deepEqual(restored.log, control.log);
            assert.strictEqual(restored.log.filter((name) => name === "a").length, 5);
        });

        it("restores as failed", () => {
            const definition = "root { action [a] }";
            const original = new Run(definition);
            original.results.a = State.FAILED;
            original.tree.step();

            const restored = createRestoredRun(original, definition);

            assert.strictEqual(restored.tree.getState(), State.FAILED);
            restored.results.a = State.SUCCEEDED;
            restored.tree.step();
            assert.strictEqual(restored.tree.getState(), State.SUCCEEDED);
        });
    });

    describe("restores action nodes that use a promise", () => {
        const createPromiseRun = (promise: () => Promise<State>) => {
            const calls: string[] = [];
            const agent: Agent = { act: () => (calls.push("act"), promise()) };
            return { calls, tree: new BehaviourTree("root { action [act] }", agent) };
        };

        it("that have settled, without calling the action function again", async () => {
            const original = createPromiseRun(() => Promise.resolve(State.SUCCEEDED));
            original.tree.step();
            await Promise.resolve();

            const restored = createPromiseRun(() => Promise.resolve(State.FAILED));
            restored.tree.restore(JSON.parse(JSON.stringify(original.tree.snapshot())));

            restored.tree.step();

            assert.deepEqual(restored.calls, []);
            assert.strictEqual(restored.tree.getState(), State.SUCCEEDED);
        });

        it("that were rejected, which still error on the next step", async () => {
            const original = createPromiseRun(() => Promise.reject(new Error("nope")));
            original.tree.step();
            await Promise.resolve();
            await Promise.resolve();

            const restored = createPromiseRun(() => Promise.resolve(State.SUCCEEDED));
            restored.tree.restore(JSON.parse(JSON.stringify(original.tree.snapshot())));

            assert.throws(
                () => restored.tree.step(),
                Error,
                "action function 'act' promise rejected with 'Error: nope'"
            );
        });

        it("that are pending, as not yet started so that the action function is called again", async () => {
            const original = createPromiseRun(() => new Promise(() => {}));
            original.tree.step();

            const snapshot = JSON.parse(JSON.stringify(original.tree.snapshot()));
            assert.strictEqual(original.tree.getState(), State.RUNNING);

            const restored = createPromiseRun(() => Promise.resolve(State.SUCCEEDED));
            restored.tree.restore(snapshot);
            assert.strictEqual(findNode(restored.tree, "action").state, State.READY);

            restored.tree.step();
            assert.deepEqual(restored.calls, ["act"]);
            await Promise.resolve();

            restored.tree.step();
            assert.deepEqual(restored.calls, ["act"]);
            assert.strictEqual(restored.tree.getState(), State.SUCCEEDED);
        });

        it("that are pending, without changing the tree that the snapshot was taken from", async () => {
            let resolve: (state: State) => void = () => {};
            const original = createPromiseRun(() => new Promise((r) => (resolve = r)));
            original.tree.step();
            original.tree.snapshot();

            resolve(State.SUCCEEDED);
            await Promise.resolve();
            original.tree.step();

            assert.deepEqual(original.calls, ["act"]);
            assert.strictEqual(original.tree.getState(), State.SUCCEEDED);
        });

        it("that are pending and part way through a sequence, calling the entry callback again", () => {
            const calls: string[] = [];
            const agent: Agent = {
                first: () => State.SUCCEEDED,
                act: () => (calls.push("act"), new Promise(() => {})),
                enter: () => void calls.push("enter")
            };
            const definition = "root { sequence { action [first] action [act] entry(enter) } }";
            const original = new BehaviourTree(definition, agent);
            original.step();
            original.step();
            calls.length = 0;

            const restored = new BehaviourTree(definition, agent);
            restored.restore(JSON.parse(JSON.stringify(original.snapshot())));
            restored.step();

            assert.deepEqual(calls, ["enter", "act"]);
        });

        it("and ignores a promise that was pending before the restore", async () => {
            let resolve: (state: State) => void = () => {};
            const live = createPromiseRun(() => new Promise((r) => (resolve = r)));
            const settled = createPromiseRun(() => Promise.resolve(State.FAILED));
            settled.tree.step();
            await Promise.resolve();

            live.tree.step();
            live.tree.restore(settled.tree.snapshot());
            resolve(State.SUCCEEDED);
            await Promise.resolve();

            live.tree.step();
            assert.strictEqual(live.tree.getState(), State.FAILED);
        });
    });

    describe("records the definition of the tree", () => {
        const mdsl = `root {
            sequence entry(enter) while(ok, "x") {
                action [a]
                action [b, 1, "x", null, $foo]
                repeat [2,3] { branch [sub] }
            }
        }
        root [sub] { wait [10] }`;

        // The same definition as the MDSL above, leaving out the empty arguments and false flags that MDSL always includes.
        const json: RootNodeDefinition[] = [
            { id: "sub", type: "root", child: { duration: 10, type: "wait" } },
            {
                type: "root",
                child: {
                    type: "sequence",
                    children: [
                        { call: "a", type: "action" },
                        { type: "action", args: [1, "x", null, { $: "foo" }], call: "b" },
                        { type: "repeat", child: { type: "branch", ref: "sub" }, iterations: [2, 3] }
                    ],
                    entry: { call: "enter" },
                    while: { call: "ok", args: ["x"] }
                }
            }
        ];

        const definitionOf = (definition: Definition) => new Run(definition).tree.snapshot().definition;

        it("in a way that is the same for an MDSL definition and its JSON equivalent", () => {
            assert.isString(definitionOf(mdsl));
            assert.strictEqual(definitionOf(mdsl), definitionOf(json));
        });

        it("in a way that is the same for a main root node as an object or an array", () => {
            const root: RootNodeDefinition = { type: "root", child: { type: "action", call: "a" } };
            assert.strictEqual(definitionOf(root), definitionOf([root]));
            assert.strictEqual(definitionOf(root), definitionOf("root { action [a] }"));
        });

        it("so that a snapshot restores to the equivalent definition in either direction", () => {
            const fromMDSL = new Run(mdsl);
            fromMDSL.tree.step();
            const toJSON = createRestoredRun(fromMDSL, json);
            assert.deepEqual(toJSON.tree.getTreeNodeDetails(), fromMDSL.tree.getTreeNodeDetails());

            const fromJSON = new Run(json);
            fromJSON.tree.step();
            const toMDSL = createRestoredRun(fromJSON, mdsl);
            assert.deepEqual(toMDSL.tree.getTreeNodeDetails(), fromJSON.tree.getTreeNodeDetails());
        });

        it("in a way that is different for definitions that differ in a detail", () => {
            const definitions = [
                "root { repeat [3] { action [a, 1] } }",
                "root { repeat [3] { action [a, 2] } }",
                "root { repeat [4] { action [a, 1] } }",
                "root { repeat [3] { action [a, 1] entry(enter) } }",
                "root { repeat [3] { action [a, 1] while(ok) } }",
                "root { repeat [3] { action [a, 1] while(ok, true) } }",
                "root { repeat [3] { action [a, 1] until(ok) } }",
                "root { repeat [3] { action [a, 1] while(ok) } } root [sub] { wait }"
            ];
            assert.strictEqual(new Set(definitions.map(definitionOf)).size, definitions.length);
        });
    });

    describe("restore", () => {
        it("puts a tree that has moved on back to the state of the snapshot", () => {
            const definition = "root { sequence { action [a] action [b] } }";
            const run = new Run(definition);
            run.results.a = State.SUCCEEDED;
            run.tree.step();
            const stored = takeStoredSnapshot(run);
            const detailsAtSnapshot = run.tree.getTreeNodeDetails();

            run.results.b = State.SUCCEEDED;
            run.tree.step();
            assert.strictEqual(run.tree.getState(), State.SUCCEEDED);

            run.tree.restore(stored);

            assert.deepEqual(run.tree.getTreeNodeDetails(), detailsAtSnapshot);
            assert.strictEqual(run.tree.getState(), State.RUNNING);
        });

        it("does not call onNodeStateChange", () => {
            const definition = "root { sequence { action [a] action [b] } }";
            const original = new Run(definition);
            original.results.a = State.SUCCEEDED;
            original.tree.step();

            const changes: unknown[] = [];
            const restored = new Run(definition, { onNodeStateChange: (change) => changes.push(change) });
            restored.tree.restore(takeStoredSnapshot(original));

            assert.deepEqual(changes, []);
        });

        it("does not call onNodeStateChange for a tree that has already moved on, and the next step reports changes as usual", () => {
            const definition = "root { sequence { action [a] action [b] } }";
            const original = new Run(definition);
            original.results.a = State.SUCCEEDED;
            original.tree.step();
            const stored = takeStoredSnapshot(original);

            const changes: unknown[] = [];
            const restored = new Run(definition, { onNodeStateChange: (change) => changes.push(change) });
            restored.results.a = State.SUCCEEDED;
            restored.results.b = State.SUCCEEDED;
            restored.tree.step();
            restored.tree.step();
            changes.length = 0;

            restored.tree.restore(stored);
            assert.deepEqual(changes, []);

            restored.tree.step();
            assert.isAbove(changes.length, 0);
        });

        it("leaves the snapshot unchanged when either tree is stepped, and a snapshot taken straight after equals it", () => {
            const definition = "root { sequence { action [a] repeat [2] { action [b] } wait [100] } }";
            const original = new Run(definition, { getDeltaTime: () => 0.01 });
            original.results.a = State.SUCCEEDED;
            original.results.b = State.SUCCEEDED;
            original.tree.step();
            const snapshot = original.tree.snapshot();
            const json = JSON.stringify(snapshot);

            runToCompletion(original);
            assert.strictEqual(JSON.stringify(snapshot), json);

            const restored = new Run(definition, { getDeltaTime: () => 0.01 });
            restored.results.a = State.SUCCEEDED;
            restored.results.b = State.SUCCEEDED;
            restored.tree.restore(snapshot);
            assert.deepEqual(JSON.parse(JSON.stringify(restored.tree.snapshot())), JSON.parse(json));

            runToCompletion(restored);
            assert.strictEqual(JSON.stringify(snapshot), json);
        });

        describe("rejects a snapshot of another definition and leaves the tree as it was", () => {
            const original = "root { sequence { repeat [3] { action [a, 1] } wait [100] } }";
            const others = [
                ["a different argument", "root { sequence { repeat [3] { action [a, 2] } wait [100] } }"],
                ["a different iteration count", "root { sequence { repeat [4] { action [a, 1] } wait [100] } }"],
                ["a different wait duration", "root { sequence { repeat [3] { action [a, 1] } wait [200] } }"],
                ["an added guard", "root { sequence { repeat [3] { action [a, 1] while(ok) } wait [100] } }"],
                ["an added callback", "root { sequence entry(enter) { repeat [3] { action [a, 1] } wait [100] } }"],
                ["an added subtree", `${original} root [sub] { action [b] }`]
            ];

            for (const [description, definition] of others) {
                it(`that has ${description}`, () => {
                    const source = new Run(original);
                    source.results.a = State.SUCCEEDED;
                    source.tree.step();
                    const snapshot = takeStoredSnapshot(source);

                    const target = new Run(definition);
                    target.results.a = State.SUCCEEDED;
                    target.tree.step();
                    const detailsBefore = target.tree.getTreeNodeDetails();

                    assert.throws(
                        () => target.tree.restore(snapshot),
                        Error,
                        "snapshot does not match the tree's definition"
                    );
                    assert.deepEqual(target.tree.getTreeNodeDetails(), detailsBefore);
                });
            }

            it("without losing the pending promise of an action", async () => {
                const agent: Agent = { act: () => Promise.resolve(State.SUCCEEDED) };
                const target = new BehaviourTree("root { action [act] }", agent);
                target.step();

                const source = new BehaviourTree("root { action [act, 1] }", agent);
                assert.throws(() => target.restore(source.snapshot()), Error, "does not match");

                await Promise.resolve();
                target.step();
                assert.strictEqual(target.getState(), State.SUCCEEDED);
            });
        });

        describe("rejects something that is not a snapshot and leaves the tree as it was", () => {
            const definition = "root { sequence { action [a] action [b] } }";
            const { root, definition: definitionId } = new Run(definition).tree.snapshot();
            const notSnapshots: [string, any][] = [
                ["null", null],
                ["undefined", undefined],
                ["a string", "nope"],
                ["a number", 5],
                ["a boolean", true],
                ["an array", []],
                ["an array containing a snapshot", [{ version: 1, definition: definitionId, root }]],
                ["an empty object", {}],
                ["an object with only a version", { version: 1 }],
                ["an object with no definition", { version: 1, root }],
                ["an object with no root", { version: 1, definition: definitionId }],
                ["an object with a definition that is not a string", { version: 1, definition: 5, root }]
            ];

            for (const [description, notSnapshot] of notSnapshots) {
                it(`when it is ${description}`, () => {
                    const target = new Run(definition);
                    target.results.a = State.SUCCEEDED;
                    target.tree.step();
                    const detailsBefore = target.tree.getTreeNodeDetails();

                    assert.throws(() => target.tree.restore(notSnapshot), Error);
                    assert.deepEqual(target.tree.getTreeNodeDetails(), detailsBefore);
                });
            }
        });

        describe("rejects an invalid snapshot and leaves the tree as it was", () => {
            const definition =
                "root { sequence { repeat [3] { action [a] } lotto { action [b] action [c] } wait [100] } }";

            const invalidSnapshots: [string, (snapshot: any) => any][] = [
                ["is not an object", () => "nope"],
                ["is null", () => null],
                ["has an unsupported version", (s) => ({ ...s, version: 2 })],
                ["has no root", (s) => ({ version: s.version })],
                ["has a root with the wrong node type", (s) => ({ ...s, root: { ...s.root, type: "sequence" } })],
                ["has a node with a different name", (s) => (s.root.children[0].children[0].name = "REPEAT 4x") && s],
                ["has a node with an invalid state", (s) => (s.root.children[0].state = "nope") && s],
                ["has a node with a missing id", (s) => delete s.root.children[0].id && s],
                ["has the wrong number of children", (s) => s.root.children[0].children.pop() && s],
                ["has a sequence node with no children", (s) => delete s.root.children[0].children && s],
                [
                    "has a repeat node with a negative iteration count",
                    (s) => (s.root.children[0].children[0].currentIterationCount = -1) && s
                ],
                [
                    "has a repeat node with a missing target iteration count",
                    (s) => delete s.root.children[0].children[0].targetIterationCount && s
                ],
                [
                    "has a lotto node with an out of range selected child",
                    (s) => (s.root.children[0].children[1].selectedChildIndex = 2) && s
                ],
                [
                    "has a wait node with a non numeric waited duration",
                    (s) => (s.root.children[0].children[2].waitedDuration = "1") && s
                ]
            ];

            for (const [description, corrupt] of invalidSnapshots) {
                it(`when it ${description}`, () => {
                    const original = new Run(definition, { random: () => 0.5 });
                    original.results.a = State.SUCCEEDED;
                    original.tree.step();

                    const snapshot = corrupt(takeStoredSnapshot(original));

                    const target = createRestoredRun(original, definition);
                    target.results.a = State.SUCCEEDED;
                    target.tree.step();
                    const detailsBefore = target.tree.getTreeNodeDetails();

                    assert.throws(() => target.tree.restore(snapshot), Error, "error restoring tree: ");
                    assert.deepEqual(target.tree.getTreeNodeDetails(), detailsBefore);
                });
            }
        });
    });
});
