import State from "./State";
import Lookup from "./Lookup";
import { NodeDetails } from "./nodes/Node";
import Root from "./nodes/decorator/Root";
import { Agent, GlobalFunction } from "./Agent";
import { BehaviourTreeOptions } from "./BehaviourTreeOptions";
import { convertMDSLToJSON } from "./mdsl/MDSLDefinitionParser";
import { RootNodeDefinition } from "./BehaviourTreeDefinition";
import { validateDefinition, validateJSONDefinition } from "./BehaviourTreeDefinitionValidator";
import buildRootNode from "./BehaviourTreeBuilder";
import { createDefinitionFingerprint } from "./BehaviourTreeDefinitionFingerprint";
import { isNullOrUndefined } from "./BehaviourTreeDefinitionUtilities";
import { SNAPSHOT_VERSION, TreeSnapshot, createInvalidSnapshotError, isObject } from "./BehaviourTreeSnapshot";

/**
 * A representation of a behaviour tree.
 */
export class BehaviourTree {
    /**
     * The main root tree node.
     */
    private readonly _rootNode: Root;

    /**
     * The fingerprint of the definition that the tree was built from, which identifies the trees that a snapshot of this tree can be restored to.
     */
    private readonly _definitionFingerprint: string;

    /**
     * What is currently changing the state of the tree nodes, if anything, in which case the tree state cannot be captured or replaced.
     */
    private _activity: "stepped" | "reset" | null = null;

    /**
     * Creates a new instance of the BehaviourTree class.
     * @param definition The behaviour tree definition as either an MDSL string, root node definition object or array of root node definition objects.
     * @param agent The agent instance that this behaviour tree is modelling behaviour for.
     * @param options The behaviour tree options object.
     */
    constructor(
        definition: string | RootNodeDefinition | RootNodeDefinition[],
        private agent: Agent,
        private options: BehaviourTreeOptions = {}
    ) {
        // The tree definition must be defined.
        if (isNullOrUndefined(definition)) {
            throw new Error("tree definition not defined");
        }

        // The agent must be defined and not null.
        if (typeof agent !== "object" || agent === null) {
            throw new Error("the agent must be an object and not null");
        }

        // We should validate the definition before we try to build the tree nodes.
        const { succeeded, errorMessage, json } = validateDefinition(definition);

        // Did our validation fail without error?
        if (!succeeded) {
            throw new Error(`invalid definition: ${errorMessage}`);
        }

        // Double check that we did actually get our json definition as part of our definition validtion.
        if (!json) {
            throw new Error(
                "expected json definition to be returned as part of successful definition validation response"
            );
        }

        try {
            // Create the populated tree of behaviour tree nodes and get the root node.
            this._rootNode = buildRootNode(json, options);

            // The fingerprint has to be taken now, as it includes any globally registered subtrees that the tree was built with.
            this._definitionFingerprint = createDefinitionFingerprint(json);
        } catch (exception) {
            // There was an issue in trying build and populate the behaviour tree.
            throw new Error(`error building tree: ${(exception as Error).message}`);
        }
    }

    /**
     * Gets whether the tree is in the RUNNING state.
     * @returns true if the tree is in the RUNNING state, otherwise false.
     */
    public isRunning(): boolean {
        return this._rootNode.getState() === State.RUNNING;
    }

    /**
     * Gets the current tree state of SUCCEEDED, FAILED, READY or RUNNING.
     * @returns The current tree state.
     */
    public getState(): State {
        return this._rootNode.getState();
    }

    /**
     * Step the tree.
     * Carries out a node update that traverses the tree from the root node outwards to any child nodes, skipping those that are already in a resolved state of SUCCEEDED or FAILED.
     * After being updated, leaf nodes will have a state of SUCCEEDED, FAILED or RUNNING. Leaf nodes that are left in the RUNNING state as part of a tree step will be revisited each
     * subsequent step until they move into a resolved state of either SUCCEEDED or FAILED, after which execution will move through the tree to the next node with a state of READY.
     *
     * Calling this method when the tree is already in a resolved state of SUCCEEDED or FAILED will cause it to be reset before tree traversal begins.
     */
    public step(): void {
        const previousActivity = this._activity;
        this._activity = "stepped";

        try {
            // If the root node has already been stepped to completion then we need to reset it.
            if (this._rootNode.getState() === State.SUCCEEDED || this._rootNode.getState() === State.FAILED) {
                this._rootNode.reset();
            }

            this._rootNode.update(this.agent);
        } catch (exception) {
            throw new Error(`error stepping tree: ${(exception as Error).message}`);
        } finally {
            this._activity = previousActivity;
        }
    }

    /**
     * Resets the tree from the root node outwards to each nested node, giving each a state of READY.
     */
    public reset(): void {
        const previousActivity = this._activity;
        this._activity = "reset";

        try {
            this._rootNode.reset();
        } finally {
            this._activity = previousActivity;
        }
    }

    /**
     * Gets a snapshot of the execution state of the tree, made up only of plain objects, arrays, strings, numbers, booleans and nulls so that
     * it is unchanged by a round trip through JSON. It can be restored to a tree built from the same definition, to carry on from where this one is.
     *
     * The snapshot has the state of every node, the progress of any composite, repeat, retry, lotto and wait nodes, and any random choices that were made.
     * The time that a running wait node has waited for so far is as it is now, rather than as it was at the last step of the tree.
     * It also identifies the definition of the tree, so that it can only be restored to a tree built from the same definition.
     *
     * The promise returned by an action node function cannot be captured while it is pending, so such a node is saved as not yet started, and a restored
     * tree will call the action function again on its next step.
     * @returns A snapshot of the execution state of the tree.
     * @throws If called as part of a step of the tree.
     */
    public snapshot(): TreeSnapshot {
        this.assertNotInUse("take a snapshot of");

        return {
            version: SNAPSHOT_VERSION,
            definition: this._definitionFingerprint,
            root: this._rootNode.getSnapshot()
        };
    }

    /**
     * Restores the execution state of the tree from a snapshot, from which point the tree will behave as the tree that the snapshot was taken from would have.
     * The tree must have been built from the same definition as the tree that the snapshot was taken from, where an MDSL definition and its equivalent JSON definition are the same.
     *
     * A running wait node will wait only for the time that it had left when the snapshot was taken, no matter how much time has passed since.
     * Restoring is not a state change, so the 'onNodeStateChange' option is not called, and the next step of the tree will report changes as usual.
     * Nodes that were running before are not aborted so no exit callbacks are called.
     * @param snapshot The snapshot to restore, as returned by the 'snapshot' function.
     * @throws If the snapshot is not a valid snapshot of a tree of the same definition as this tree, in which case the tree is left as it was, or if called as part of a step of the tree.
     */
    public restore(snapshot: TreeSnapshot): void {
        this.assertNotInUse("restore");

        if (!isObject(snapshot)) {
            throw createInvalidSnapshotError("", "expected an object");
        }

        if (snapshot.version !== SNAPSHOT_VERSION) {
            throw createInvalidSnapshotError("", `unsupported version '${snapshot.version}'`);
        }

        if (typeof snapshot.definition !== "string") {
            throw createInvalidSnapshotError("", `invalid definition '${snapshot.definition}'`);
        }

        // A snapshot of another definition may pass the checks of the nodes below, but would still leave the tree in a state that it could never have been in.
        if (snapshot.definition !== this._definitionFingerprint) {
            throw new Error(
                "snapshot does not match the tree's definition, as it was taken from a tree built from a different definition"
            );
        }

        // Check all of the snapshot before changing anything, so that a problem with the snapshot cannot leave us with a half restored tree.
        this._rootNode.validateSnapshot(snapshot.root, "root");

        // Restoring only changes the nodes, and calls nothing that is not part of the tree, so a problem in the application cannot leave the tree part restored.
        this._rootNode.restoreSnapshot(snapshot.root);
    }

    /**
     * Gets the details of every node in the tree, starting from the root.
     * @returns The details of every node in the tree, starting from the root.
     */
    public getTreeNodeDetails(): NodeDetails {
        return this._rootNode.getDetails();
    }

    /**
     * Throws an error if the tree nodes are in the middle of being stepped or reset, as the state of the tree is not whole.
     * @param action A description of what is being attempted, for use in the error message.
     */
    private assertNotInUse(action: string): void {
        if (this._activity) {
            throw new Error(`cannot ${action} the tree while it is being ${this._activity}`);
        }
    }

    /**
     * Registers the action/condition/guard/callback function or subtree with the given name.
     * @param name The name of the function or subtree to register.
     * @param value The function or subtree definition to register.
     */
    static register(name: string, value: GlobalFunction | string | RootNodeDefinition) {
        // Are we going to register a action/condition/guard/callback function?
        if (typeof value === "function") {
            Lookup.setFunc(name, value);
            return;
        }

        // We are not registering an action/condition/guard/callback function, so we must be registering a subtree.
        if (typeof value === "string") {
            let rootNodeDefinitions: RootNodeDefinition[];

            // We will assume that any string passed in will be a mdsl definition.
            try {
                rootNodeDefinitions = convertMDSLToJSON(value);
            } catch (exception) {
                throw new Error(`error registering definition, invalid MDSL: ${(exception as Error).message}`);
            }

            // This function should only ever be called with a definition containing a single unnamed root node.
            if (rootNodeDefinitions.length != 1 || typeof rootNodeDefinitions[0].id !== "undefined") {
                throw new Error("error registering definition: expected a single unnamed root node");
            }

            try {
                // We should validate the subtree as we don't want invalid subtrees available via the lookup.
                const { succeeded, errorMessage } = validateJSONDefinition(rootNodeDefinitions[0]);

                // Did our validation fail without error?
                if (!succeeded) {
                    throw new Error(errorMessage);
                }
            } catch (exception) {
                throw new Error(`error registering definition: ${(exception as Error).message}`);
            }

            // Everything seems hunky-dory, register the subtree.
            Lookup.setSubtree(name, rootNodeDefinitions[0]);
        } else if (typeof value === "object" && !Array.isArray(value)) {
            // We will assume that any object passed in is a root node definition.

            try {
                // We should validate the subtree as we don't want invalid subtrees available via the lookup.
                const { succeeded, errorMessage } = validateJSONDefinition(value);

                // Did our validation fail without error?
                if (!succeeded) {
                    throw new Error(errorMessage);
                }
            } catch (exception) {
                throw new Error(`error registering definition: ${(exception as Error).message}`);
            }

            // Everything seems hunky-dory, register the subtree.
            Lookup.setSubtree(name, value);
        } else {
            throw new Error("unexpected value, expected string mdsl definition, root node json definition or function");
        }
    }

    /**
     * Unregisters the registered action/condition/guard/callback function or subtree with the given name.
     * @param name The name of the registered action/condition/guard/callback function or subtree to unregister.
     */
    static unregister(name: string): void {
        Lookup.remove(name);
    }

    /**
     * Unregister all registered action/condition/guard/callback functions and subtrees.
     */
    static unregisterAll(): void {
        Lookup.empty();
    }
}
