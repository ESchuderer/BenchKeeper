import { AnyNodeDefinition, RootNodeDefinition } from "./BehaviourTreeDefinition";
import { MAIN_ROOT_NODE_KEY, RootNodeDefinitionMap, createRootNodeDefinitionMap } from "./BehaviourTreeBuilder";
import { isInteger } from "./BehaviourTreeDefinitionUtilities";

/**
 * Creates a fingerprint of a tree definition, which is the same for any two definitions that build the same tree, and for no others.
 * An MDSL definition and its equivalent JSON definition will have the same fingerprint, as will definitions that differ only in the order
 * of their root nodes, in properties that the tree builder ignores, or in properties that are optional in JSON but that MDSL always defines.
 *
 * Branch nodes are replaced by the tree that they reference, as they are when a tree is built, so this should be called when the tree is built
 * for the fingerprint to account for any globally registered subtrees that were used.
 * @param definition The root node definitions, which have been validated, of which there must be a main root node.
 * @returns The fingerprint of the definition.
 */
export function createDefinitionFingerprint(definition: RootNodeDefinition[]): string {
    const rootNodeDefinitionMap = createRootNodeDefinitionMap(definition);

    return hash(stringify(getCanonicalForm(rootNodeDefinitionMap[MAIN_ROOT_NODE_KEY], rootNodeDefinitionMap)));
}

/**
 * Gets a plain representation of a node definition, and of the nodes beneath it, that has only what is used to build the tree, in a fixed form.
 * @param definition The node definition.
 * @param rootNodeDefinitionMap The mapping of root node identifers to root node definitions, including globally registered subtree root node definitions.
 */
function getCanonicalForm(definition: AnyNodeDefinition, rootNodeDefinitionMap: RootNodeDefinitionMap): unknown {
    // A branch is the node that it references, and nothing else. The attributes of the branch node, and those of the root node, are not used.
    if (definition.type === "branch") {
        return getCanonicalForm(rootNodeDefinitionMap[definition.ref].child, rootNodeDefinitionMap);
    }

    const canonicalChild = (child: AnyNodeDefinition) => getCanonicalForm(child, rootNodeDefinitionMap);

    const node: { [key: string]: unknown } = { type: definition.type };

    for (const name of ["while", "until"] as const) {
        const guard = definition[name];

        if (guard) {
            node[name] = { call: guard.call, args: guard.args ?? [], succeedOnAbort: !!guard.succeedOnAbort };
        }
    }

    for (const name of ["entry", "step", "exit"] as const) {
        const callback = definition[name];

        if (callback) {
            node[name] = { call: callback.call, args: callback.args ?? [] };
        }
    }

    switch (definition.type) {
        case "root":
        case "flip":
        case "succeed":
        case "fail":
            node.child = canonicalChild(definition.child);
            break;

        case "repeat":
            node.iterations = getCount(definition.iterations);
            node.child = canonicalChild(definition.child);
            break;

        case "retry":
            node.attempts = getCount(definition.attempts);
            node.child = canonicalChild(definition.child);
            break;

        case "sequence":
        case "selector":
        case "parallel":
        case "race":
        case "all":
            node.children = definition.children.map(canonicalChild);
            break;

        case "lotto":
            // A child without a weight has a weight of one, as it does when the node picks a child.
            node.weights = definition.children.map((_, index) => definition.weights?.[index] || 1);
            node.children = definition.children.map(canonicalChild);
            break;

        case "action":
        case "condition":
            node.call = definition.call;
            node.args = definition.args ?? [];
            break;

        case "wait":
            node.duration = getCount(definition.duration);
            break;
    }

    return node;
}

/**
 * Gets a count, such as that of repeat iterations, retry attempts or a wait duration, as it is used to build a node.
 * @param value The count, which is a single integer, an array of a minimum and maximum, or not defined.
 * @returns The count, or null if there is no count.
 */
function getCount(value: number | [number, number] | undefined): number | [number, number] | null {
    if (Array.isArray(value)) {
        return [value[0], value[1]];
    }

    return isInteger(value) ? (value as number) : null;
}

/**
 * Gets a string for a value made of plain objects, arrays, strings, numbers, booleans and nulls, in which the properties of every object are in order.
 * @param value The value.
 */
function stringify(value: unknown): string {
    return JSON.stringify(value, (_key, item) =>
        item !== null && typeof item === "object" && !Array.isArray(item)
            ? Object.fromEntries(Object.entries(item).sort(([a], [b]) => (a < b ? -1 : a > b ? 1 : 0)))
            : item
    );
}

/**
 * Gets a 53 bit hash of a string, as a 14 character hexadecimal string. This is cyrb53 by bryc, which is not cryptographic but
 * is evenly distributed, so that two definitions that differ in any way do not have the same fingerprint by chance.
 * @param value The string to hash.
 */
function hash(value: string): string {
    let h1 = 0xdeadbeef;
    let h2 = 0x41c6ce57;

    for (let index = 0; index < value.length; index++) {
        const code = value.charCodeAt(index);
        h1 = Math.imul(h1 ^ code, 2654435761);
        h2 = Math.imul(h2 ^ code, 1597334677);
    }

    h1 = Math.imul(h1 ^ (h1 >>> 16), 2246822507) ^ Math.imul(h2 ^ (h2 >>> 13), 3266489909);
    h2 = Math.imul(h2 ^ (h2 >>> 16), 2246822507) ^ Math.imul(h1 ^ (h1 >>> 13), 3266489909);

    return (4294967296 * (2097151 & h2) + (h1 >>> 0)).toString(16).padStart(14, "0");
}
