import State, { AnyState, CompleteState } from "./State";

/**
 * The result of the promise returned by an action node function that has settled but not yet been handled by the node.
 */
export type ActionPromiseResultSnapshot =
    | {
          /**
           * The promise was resolved.
           */
          isResolved: true;
          /**
           * The state that the promise resolved with, or null if it resolved with something that is not a valid state.
           */
          value: CompleteState | null;
      }
    | {
          /**
           * The promise was rejected.
           */
          isResolved: false;
          /**
           * The rejection reason, as a string.
           */
          value: string;
      };

/**
 * A snapshot of a node with a type that has no state of its own other than the node state, and perhaps the state of child nodes.
 */
type BasicNodeSnapshot<TType extends string> = {
    /**
     * The node type.
     */
    type: TType;
    /**
     * The node state.
     */
    state: AnyState;
};

/**
 * A snapshot of a node that wraps child nodes.
 */
interface ParentNodeSnapshot<TType extends string> extends BasicNodeSnapshot<TType> {
    /**
     * The snapshots of the child nodes, in the order that they are defined.
     */
    children: NodeSnapshot[];
}

/**
 * A snapshot of a lotto node.
 */
export interface LottoNodeSnapshot extends ParentNodeSnapshot<"lotto"> {
    /**
     * The index of the child node that was picked, or null if no child has been picked.
     */
    selectedChild: number | null;
}

/**
 * A snapshot of a repeat node.
 */
export interface RepeatNodeSnapshot extends ParentNodeSnapshot<"repeat"> {
    /**
     * The number of iterations completed.
     */
    iterationCount: number;
    /**
     * The number of iterations to make, or null if there is no limit.
     * If the number was picked at random then this is the number that was picked.
     */
    targetIterationCount: number | null;
}

/**
 * A snapshot of a retry node.
 */
export interface RetryNodeSnapshot extends ParentNodeSnapshot<"retry"> {
    /**
     * The number of attempts completed.
     */
    attemptCount: number;
    /**
     * The number of attempts to make, or null if there is no limit.
     * If the number was picked at random then this is the number that was picked.
     */
    targetAttemptCount: number | null;
}

/**
 * A snapshot of a wait node.
 */
export type WaitNodeSnapshot = BasicNodeSnapshot<"wait"> & {
    /**
     * The duration in milliseconds that the node waits for, or null if it waits indefinitely or is not running.
     * If the duration was picked at random then this is the duration that was picked.
     */
    totalDuration: number | null;
    /**
     * The duration in milliseconds that the node has waited for so far, or 0 if it is not running.
     */
    waitedDuration: number;
};

/**
 * A snapshot of an action node.
 */
export type ActionNodeSnapshot = BasicNodeSnapshot<"action"> & {
    /**
     * The result of the promise returned by the action function, defined only if it has settled but the node has not yet handled the result.
     */
    promiseResult?: ActionPromiseResultSnapshot;
};

/**
 * A snapshot of the state of a node in a behaviour tree.
 */
export type NodeSnapshot =
    | ParentNodeSnapshot<"root" | "sequence" | "selector" | "parallel" | "race" | "all" | "flip" | "succeed" | "fail">
    | LottoNodeSnapshot
    | RepeatNodeSnapshot
    | RetryNodeSnapshot
    | WaitNodeSnapshot
    | ActionNodeSnapshot
    | BasicNodeSnapshot<"condition">;

/**
 * A snapshot of the execution state of a behaviour tree, made up only of plain objects, arrays, strings, numbers, booleans and nulls.
 * This will be unchanged by a round trip through JSON.stringify and JSON.parse.
 */
export type TreeSnapshot = {
    /**
     * The version of the snapshot format.
     */
    version: 1;
    /**
     * Identifies the definition of the tree that the snapshot was taken from, so that it is only restored to a tree built from the same definition.
     * An MDSL definition and its equivalent JSON definition have the same identifier.
     */
    definition: string;
    /**
     * The snapshot of the root node, which contains the snapshots of every other node in the tree.
     */
    root: NodeSnapshot;
};

/**
 * The version of the snapshot format that is currently produced and understood.
 */
export const SNAPSHOT_VERSION = 1;

/**
 * Creates the error to throw for an invalid snapshot.
 * @param path The path of the invalid part of the snapshot, or an empty string if it is the snapshot itself.
 * @param message A description of what is invalid.
 */
export function createInvalidSnapshotError(path: string, message: string): Error {
    return new Error(`invalid snapshot: ${path ? `${path}: ` : ""}${message}`);
}

/**
 * Gets whether a value is an object that is not null or an array.
 */
export function isObject(value: unknown): value is { [key: string]: unknown } {
    return typeof value === "object" && value !== null && !Array.isArray(value);
}

/**
 * Gets whether a value is a valid node state.
 */
export function isState(value: unknown): value is AnyState {
    return value === State.READY || value === State.RUNNING || value === State.SUCCEEDED || value === State.FAILED;
}

/**
 * Gets whether a value is a non-negative integer.
 */
export function isCount(value: unknown): value is number {
    return typeof value === "number" && Number.isInteger(value) && value >= 0;
}

/**
 * Gets whether a value is a number that is not NaN or infinite.
 */
export function isFiniteNumber(value: unknown): value is number {
    return typeof value === "number" && Number.isFinite(value);
}

/**
 * Throws an invalid snapshot error if the specified property of a node snapshot does not pass a check.
 * @param snapshot The node snapshot.
 * @param path The path of the node snapshot.
 * @param property The name of the property to check.
 * @param isValid The check for the property value.
 */
export function validateProperty(
    snapshot: { [key: string]: unknown },
    path: string,
    property: string,
    isValid: (value: unknown) => boolean
): void {
    if (!isValid(snapshot[property])) {
        throw createInvalidSnapshotError(path, `invalid ${property} '${snapshot[property]}'`);
    }
}
