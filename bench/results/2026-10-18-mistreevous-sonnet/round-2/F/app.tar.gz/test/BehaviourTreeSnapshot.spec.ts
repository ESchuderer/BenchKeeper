import { assert } from "chai";
import sinon, { SinonFakeTimers } from "sinon";

import { BehaviourTree, NodeSnapshot, State, TreeSnapshot } from "../src/index";
import { RootNodeDefinition } from "../src/BehaviourTreeDefinition";

import {
    assertPlain,
    createRandom,
    getNodeStates,
    Scenario,
    SnapshotHarness,
    START_TIME,
    throughJSON
} from "./SnapshotTestUtilities";

const { RUNNING, SUCCEEDED, FAILED, READY } = State;

const assertDeepEqual = (actual: unknown, expected: unknown, message: string) =>
    assert.deepEqual(actual, expected, message);

/**
 * Every node type that has no state of its own other than that of its children and its own state.
 */
const compositeScenario: Scenario = {
    definition: `root {
        sequence {
            action [Setup]
            selector {
                condition [IsReady]
                action [Work]
            }
            parallel {
                action [A]
                action [B]
            }
            race {
                action [C]
                action [D]
            }
            all {
                action [E]
                action [F]
            }
        }
    }`,
    steps: 16,
    functions: {
        Setup: (step) => (step < 2 ? RUNNING : SUCCEEDED),
        IsReady: (step) => step >= 4,
        Work: (step) => (step < 5 ? undefined : SUCCEEDED),
        A: (step) => (step < 6 ? RUNNING : SUCCEEDED),
        B: (step) => (step < 8 ? undefined : SUCCEEDED),
        C: (step) => (step < 9 ? RUNNING : FAILED),
        D: (step) => (step < 10 ? RUNNING : SUCCEEDED),
        E: (step) => (step < 11 ? undefined : SUCCEEDED),
        F: (step) => (step < 12 ? RUNNING : FAILED)
    }
};

const guardScenario: Scenario = {
    definition: `root {
        sequence {
            action [Work] while(IsOk) entry(OnEntry) step(OnStep) exit(OnExit)
            wait [200] until(IsDone)
            action [Last]
        }
    }`,
    steps: 14,
    functions: {
        Work: (step) => (step < 6 ? RUNNING : SUCCEEDED),
        IsOk: (step) => step < 3 || step > 8,
        IsDone: (step) => step > 11,
        OnEntry: () => undefined,
        OnStep: () => undefined,
        OnExit: () => undefined,
        Last: () => SUCCEEDED
    },
    clockAdvance: 25
};

const scenarios: { [name: string]: Scenario } = {
    "sequence, selector, parallel, race and all nodes": compositeScenario,

    "a sequence node that is not the first child to run": {
        definition: "root { sequence { condition [Yes] action [Work] condition [Yes] } }",
        steps: 8,
        functions: { Yes: () => true, Work: (step) => (step % 3 === 2 ? SUCCEEDED : RUNNING) }
    },

    "a selector node": {
        definition: "root { selector { condition [No] action [Work] action [Other] } }",
        steps: 8,
        functions: { No: () => false, Work: (step) => (step % 4 === 3 ? FAILED : RUNNING), Other: () => SUCCEEDED }
    },

    "flip, succeed and fail nodes": {
        definition: `root {
            sequence {
                flip { action [A] }
                succeed { action [B] }
                selector {
                    fail { action [C] }
                    action [D]
                }
            }
        }`,
        steps: 12,
        functions: {
            A: (step) => (step < 2 ? RUNNING : FAILED),
            B: (step) => (step < 4 ? RUNNING : FAILED),
            C: (step) => (step < 6 ? RUNNING : SUCCEEDED),
            D: (step) => (step < 8 ? RUNNING : SUCCEEDED)
        }
    },

    "a repeat node": {
        definition: "root { repeat [3] { sequence { action [Work] condition [Yes] } } }",
        steps: 12,
        functions: { Work: (step) => (step % 2 ? SUCCEEDED : RUNNING), Yes: () => true }
    },

    "a repeat node with a random number of iterations": {
        definition: "root { repeat [2, 5] { action [Work] } }",
        steps: 14,
        random: [0.99, 0, 0.5, 0.2],
        functions: { Work: (step) => (step % 2 ? SUCCEEDED : RUNNING) }
    },

    "a retry node": {
        definition: "root { retry [3] { action [Work] } }",
        steps: 12,
        functions: { Work: (step) => (step % 2 ? FAILED : RUNNING) }
    },

    "a retry node with a random number of attempts": {
        definition: "root { retry [2, 5] { action [Work] } }",
        steps: 14,
        random: [0.99, 0, 0.5, 0.2],
        functions: { Work: (step) => (step % 2 ? FAILED : RUNNING) }
    },

    "a retry node that eventually succeeds": {
        definition: "root { retry [4] { sequence { action [Work] condition [Ok] } } }",
        steps: 12,
        functions: { Work: (step) => (step % 2 ? FAILED : RUNNING), Ok: () => true }
    },

    "a lotto node": {
        definition: "root { lotto [1, 2, 3] { action [A] action [B] action [C] } }",
        steps: 12,
        random: [0.99, 0, 0.5],
        functions: {
            A: (step) => (step % 3 === 2 ? SUCCEEDED : RUNNING),
            B: (step) => (step % 3 === 2 ? FAILED : RUNNING),
            C: (step) => (step % 3 === 2 ? SUCCEEDED : RUNNING)
        }
    },

    "a wait node that uses the clock": {
        definition: "root { sequence { action [Before] wait [1000] action [After] } }",
        steps: 14,
        clockAdvance: 300,
        functions: { Before: (step) => (step < 2 ? RUNNING : SUCCEEDED), After: () => SUCCEEDED }
    },

    "a wait node that uses a random duration": {
        definition: "root { wait [500, 2500] }",
        steps: 14,
        random: [0.7, 0.1, 0.9],
        clockAdvance: 400,
        functions: {}
    },

    "a wait node that uses the 'getDeltaTime' option": {
        definition: "root { sequence { wait [1000] wait [500, 1500] } }",
        steps: 14,
        random: [0.5],
        deltaTimes: [0.1, 0.2, 0.3, 0.4, 0.5, 0.1, 0.1, 0.6, 0.2, 0.3, 0.9, 0.1, 0.1, 0.1],
        functions: {}
    },

    "a wait node that waits indefinitely until it is aborted": {
        definition: "root { wait while(Keep) }",
        steps: 8,
        functions: { Keep: (step) => step < 4 }
    },

    "nodes that are running at the same time in parallel and race nodes": {
        definition: `root {
            race {
                wait [900]
                parallel {
                    repeat [2] { action [Work] }
                    wait [200, 600]
                }
            }
        }`,
        steps: 12,
        clockAdvance: 150,
        random: [0.6],
        functions: { Work: (step) => (step % 2 ? SUCCEEDED : RUNNING) }
    },

    "guards and callbacks": guardScenario,

    "a long running workflow": {
        definition: `root {
            sequence {
                action [Implement]
                retry [3] {
                    sequence {
                        action [RunCI]
                        wait [1000, 2000]
                        condition [CIPassed]
                    }
                }
                repeat [1, 3] {
                    sequence {
                        action [AwaitReview]
                        lotto {
                            action [Notify]
                            action [Remind]
                        }
                    }
                }
                action [AwaitApproval]
            }
        }`,
        steps: 40,
        random: [0.3, 0.8, 0.5, 0.1, 0.9],
        clockAdvance: 450,
        functions: {
            Implement: (step) => (step < 2 ? RUNNING : SUCCEEDED),
            RunCI: (step) => (step % 2 ? SUCCEEDED : RUNNING),
            CIPassed: (step) => step > 12,
            AwaitReview: (step) => (step % 3 ? RUNNING : SUCCEEDED),
            Notify: () => SUCCEEDED,
            Remind: () => SUCCEEDED,
            AwaitApproval: (step) => (step % 5 === 4 ? SUCCEEDED : RUNNING)
        }
    }
};

describe("A BehaviourTree instance", () => {
    let clock: SinonFakeTimers;

    beforeEach(() => {
        clock = sinon.useFakeTimers({ now: START_TIME, toFake: ["Date"] });
    });

    afterEach(() => {
        clock.restore();
    });

    describe("has a 'reset' function that", () => {
        it("will cause a 'snapshot' call made from a callback as part of the reset to error", () => {
            const errors: string[] = [];
            const tree: BehaviourTree = new BehaviourTree(
                "root { sequence { action [Work] action [Work] } }",
                { Work: () => State.SUCCEEDED },
                {
                    onNodeStateChange: () => {
                        try {
                            tree.snapshot();
                        } catch (error) {
                            errors.push((error as Error).message);
                        }
                    }
                }
            );
            tree.step();
            errors.length = 0;

            tree.reset();

            assert.isAbove(errors.length, 0);
            assert.deepEqual(new Set(errors), new Set(["cannot take a snapshot of the tree while it is being reset"]));
        });
    });

    describe("has a 'snapshot' function that", () => {
        it("returns a versioned snapshot of the state of every node in the tree, in the order of the tree", () => {
            const tree = new BehaviourTree("root { sequence { action [Work] condition [Check] wait [100] } }", {
                Work: () => State.SUCCEEDED,
                Check: () => true
            });

            const { definition } = tree.snapshot();
            assert.isString(definition);

            assert.deepEqual(tree.snapshot(), {
                version: 1,
                definition,
                root: {
                    type: "root",
                    state: READY,
                    children: [
                        {
                            type: "sequence",
                            state: READY,
                            children: [
                                { type: "action", state: READY },
                                { type: "condition", state: READY },
                                { type: "wait", state: READY, totalDuration: null, waitedDuration: 0 }
                            ]
                        }
                    ]
                }
            });

            tree.step();

            assert.deepEqual(tree.snapshot(), {
                version: 1,
                definition,
                root: {
                    type: "root",
                    state: RUNNING,
                    children: [
                        {
                            type: "sequence",
                            state: RUNNING,
                            children: [
                                { type: "action", state: SUCCEEDED },
                                { type: "condition", state: SUCCEEDED },
                                { type: "wait", state: RUNNING, totalDuration: 100, waitedDuration: 0 }
                            ]
                        }
                    ]
                }
            });
        });

        it("returns an object that is unchanged by a round trip through JSON, however far the tree has got", () => {
            const harness = new SnapshotHarness(compositeScenario, clock);

            const { tree, step } = harness.create();

            for (let index = 0; index < compositeScenario.steps; index++) {
                const snapshot = tree.snapshot();

                assertPlain(snapshot);
                assert.deepEqual(throughJSON(snapshot), snapshot);

                step.current = index;
                tree.step();
            }
        });

        it("returns a new object each time, that has no effect on the tree if changed", () => {
            const tree = new BehaviourTree("root { wait [1000] }", {});
            tree.step();

            const first = tree.snapshot();
            const second = tree.snapshot();

            assert.notStrictEqual(first, second);
            assert.deepEqual(first, second);

            first.root.state = SUCCEEDED;
            (first.root as any).children[0].state = FAILED;

            assert.deepEqual(tree.snapshot(), second);
            assert.strictEqual(tree.getState(), RUNNING);
        });

        it("does not change the tree", () => {
            const harness = new SnapshotHarness(compositeScenario, clock);

            const withSnapshots = harness.create();
            const without = harness.create();

            for (let index = 0; index < compositeScenario.steps; index++) {
                withSnapshots.step.current = index;
                without.step.current = index;

                withSnapshots.tree.snapshot();
                withSnapshots.tree.step();
                without.tree.step();

                assert.deepEqual(getNodeStates(withSnapshots.tree), getNodeStates(without.tree));
            }

            assert.deepEqual(withSnapshots.log, without.log);
        });

        it("has a type that can be imported from the package", () => {
            const tree = new BehaviourTree("root { action [Work] }", { Work: () => State.SUCCEEDED });
            const snapshot: TreeSnapshot = tree.snapshot();
            const root: NodeSnapshot = snapshot.root;

            assert.strictEqual(root.type, "root");
        });

        it("will error if called as part of a step of the tree", () => {
            const tree: BehaviourTree = new BehaviourTree("root { action [Work] }", {
                Work: () => tree.snapshot() as any
            });

            assert.throws(
                () => tree.step(),
                Error,
                "error stepping tree: action function 'Work' threw: Error: cannot take a snapshot of the tree while it is being stepped"
            );
        });

        describe("will save an action that is waiting for a promise to settle as not yet started, so that", () => {
            const definition = "root { sequence { action [Work] action [Next] } }";

            it("snapshot does not error, and the action is READY while the nodes above it are RUNNING", () => {
                const tree = new BehaviourTree(definition, {
                    Work: () => new Promise<any>(() => {}),
                    Next: () => State.SUCCEEDED
                });

                tree.step();
                const snapshot = tree.snapshot();

                assertPlain(snapshot);
                assert.deepEqual(throughJSON(snapshot), snapshot);
                const sequence = (snapshot.root as any).children[0];
                assert.strictEqual(snapshot.root.state, RUNNING);
                assert.strictEqual(sequence.state, RUNNING);
                assert.deepEqual(sequence.children, [
                    { type: "action", state: READY },
                    { type: "action", state: READY }
                ]);
            });

            it("a restored tree calls the action function again on its next step", async () => {
                const calls: string[] = [];
                const create = (work: () => Promise<State.SUCCEEDED>) =>
                    new BehaviourTree(definition, {
                        Work: () => (calls.push("Work"), work()),
                        Next: () => (calls.push("Next"), State.SUCCEEDED)
                    });

                const original = create(() => new Promise<State.SUCCEEDED>(() => {}));
                original.step();
                const snapshot = throughJSON(original.snapshot());
                calls.length = 0;

                const restored = create(() => Promise.resolve(State.SUCCEEDED));
                restored.restore(snapshot);
                assert.deepEqual(calls, []);
                assert.strictEqual(restored.getState(), RUNNING);

                restored.step();
                assert.deepEqual(calls, ["Work"]);
                assert.strictEqual(restored.getState(), RUNNING);

                await Promise.resolve();
                restored.step();
                assert.deepEqual(calls, ["Work", "Next"]);
                assert.strictEqual(restored.getState(), SUCCEEDED);
            });

            it("a promise that settles later in the tree that the snapshot was taken from has no effect on a restored tree", async () => {
                let resolve: (state: State.SUCCEEDED) => void = () => {};
                const original = new BehaviourTree("root { action [Work] }", {
                    Work: () => new Promise<State.SUCCEEDED>((r) => (resolve = r))
                });
                original.step();
                const snapshot = throughJSON(original.snapshot());

                // The promise of the original tree settling must have no effect on a tree that was restored from before that.
                const calls: string[] = [];
                const restored = new BehaviourTree("root { action [Work] }", {
                    Work: () => (calls.push("Work"), undefined)
                });
                restored.restore(snapshot);
                resolve(State.SUCCEEDED);
                await Promise.resolve();

                restored.step();
                assert.deepEqual(calls, ["Work"]);
                assert.strictEqual(restored.getState(), RUNNING);
            });

            it("a tree that is waiting on a promise of its own when it restores forgets that promise", async () => {
                let resolveLate: (state: State.SUCCEEDED) => void = () => {};
                const calls: string[] = [];
                const tree = new BehaviourTree("root { action [Work] }", {
                    Work: () => (calls.push("Work"), new Promise<State.SUCCEEDED>((resolve) => (resolveLate = resolve)))
                });
                tree.step();
                const snapshot = throughJSON(tree.snapshot());

                // Restore a snapshot of the action not yet having started into the tree that is waiting on a promise.
                tree.restore(snapshot);
                assert.strictEqual(tree.getTreeNodeDetails().children![0].state, READY);

                // The promise that is no longer waited on settles, which must not complete the action that has not started.
                resolveLate(State.SUCCEEDED);
                await Promise.resolve();
                calls.length = 0;
                tree.step();

                assert.deepEqual(calls, ["Work"]);
                assert.strictEqual(tree.getState(), RUNNING);
            });

            it("the tree that the snapshot was taken from is not changed, and still handles its promise", async () => {
                let resolve: (state: State.SUCCEEDED) => void = () => {};
                const calls: string[] = [];
                const tree = new BehaviourTree(definition, {
                    Work: () => (calls.push("Work"), new Promise<State.SUCCEEDED>((r) => (resolve = r))),
                    Next: () => (calls.push("Next"), State.SUCCEEDED)
                });
                tree.step();
                const before = getNodeStates(tree);

                tree.snapshot();
                assert.deepEqual(getNodeStates(tree), before);

                resolve(State.SUCCEEDED);
                await Promise.resolve();
                calls.length = 0;
                tree.step();

                // The action is not called again, and its promise was handled.
                assert.deepEqual(calls, ["Next"]);
                assert.strictEqual(tree.getState(), SUCCEEDED);
            });

            it("the entry callback of the action is called again by the restored tree, as the action had not started", () => {
                const calls: string[] = [];
                const create = () =>
                    new BehaviourTree("root { action [Work] entry(OnEntry) }", {
                        Work: () => new Promise<any>(() => {}),
                        OnEntry: () => void calls.push("entry")
                    });

                const original = create();
                original.step();
                const snapshot = throughJSON(original.snapshot());
                calls.length = 0;

                const restored = create();
                restored.restore(snapshot);
                restored.step();

                assert.deepEqual(calls, ["entry"]);
            });

            describe("a restored tree calls the action function again when the action is inside", () => {
                const wrappers: [string, string][] = [
                    ["a sequence node", "sequence { action [Work] }"],
                    ["a selector node", "selector { action [Work] }"],
                    ["a parallel node", "parallel { action [Work] }"],
                    ["a race node", "race { action [Work] }"],
                    ["an all node", "all { action [Work] }"],
                    ["a lotto node", "lotto { action [Work] }"],
                    ["a repeat node", "repeat [2] { action [Work] }"],
                    ["a retry node", "retry [2] { action [Work] }"],
                    ["a flip node", "flip { action [Work] }"],
                    ["a succeed node", "succeed { action [Work] }"],
                    ["a fail node", "fail { action [Work] }"],
                    ["a node with a guard", "sequence while(IsOk) { action [Work] }"]
                ];

                for (const [description, wrapped] of wrappers) {
                    it(description, async () => {
                        const calls: string[] = [];
                        const create = (work: () => Promise<State.SUCCEEDED>) =>
                            new BehaviourTree(`root { ${wrapped} }`, {
                                Work: () => (calls.push("Work"), work()),
                                IsOk: () => true
                            });

                        const original = create(() => new Promise<State.SUCCEEDED>(() => {}));
                        original.step();
                        const snapshot = throughJSON(original.snapshot());
                        calls.length = 0;

                        const restored = create(() => Promise.resolve(State.SUCCEEDED));
                        restored.restore(snapshot);
                        assert.strictEqual(restored.getState(), RUNNING);
                        assert.deepEqual(calls, []);

                        // Step until the tree is resolved, in each case the action function is called only after the restore.
                        for (let step = 0; step < 6 && restored.isRunning(); step++) {
                            restored.step();
                            await Promise.resolve();
                        }

                        assert.notStrictEqual(restored.getState(), RUNNING);
                        assert.strictEqual(calls[0], "Work");
                    });
                }
            });

            it("an action that has since been reset is saved like any other", () => {
                const tree = new BehaviourTree("root { action [Work] }", { Work: () => new Promise<any>(() => {}) });

                tree.step();
                tree.reset();

                assert.strictEqual((tree.snapshot().root as any).children[0].state, READY);
            });
        });
    });

    describe("has a 'restore' function that", () => {
        it("sets the state of every node in a tree built from the same definition", () => {
            const harness = new SnapshotHarness(compositeScenario, clock);

            const original = harness.create();

            for (let index = 0; index < compositeScenario.steps; index++) {
                original.step.current = index;
                original.tree.step();

                const restored = harness.create();
                restored.tree.restore(throughJSON(original.tree.snapshot()));

                assert.deepEqual(getNodeStates(restored.tree), getNodeStates(original.tree));
                assert.strictEqual(restored.tree.getState(), original.tree.getState());
                assert.strictEqual(restored.tree.isRunning(), original.tree.isRunning());
            }
        });

        it("makes a tree that has already made progress match the snapshot", () => {
            const harness = new SnapshotHarness(compositeScenario, clock);

            const early = harness.create();
            harness.run(early, 0, 3);
            const snapshot = throughJSON(early.tree.snapshot());
            const statesAtSnapshot = getNodeStates(early.tree);

            // A tree that has got further, and one that has finished.
            harness.run(early, 3, 7);
            early.tree.restore(snapshot);
            assert.deepEqual(getNodeStates(early.tree), statesAtSnapshot);

            const finished = harness.create();
            harness.run(finished, 0, 14);
            finished.tree.restore(snapshot);
            assert.deepEqual(getNodeStates(finished.tree), statesAtSnapshot);
            assert.deepEqual(finished.tree.snapshot(), snapshot);
        });

        it("can restore the same snapshot more than once", () => {
            const tree = new BehaviourTree("root { sequence { action [Work] wait [1000] } }", {
                Work: () => State.SUCCEEDED
            });
            tree.step();
            clock.tick(300);
            const snapshot = throughJSON(tree.snapshot());

            for (let index = 0; index < 3; index++) {
                clock.tick(5000);
                tree.restore(snapshot);
                assert.deepEqual(tree.snapshot(), snapshot);
            }
        });

        describe("does not call the 'onNodeStateChange' option, as restoring is not a state change, so that", () => {
            const definition = "root { sequence { action [Work] action [Other] } }";
            const agent = { Work: () => State.SUCCEEDED, Other: () => undefined };

            it("no node reports a change when the nodes of the tree change state", () => {
                const changes: string[] = [];
                const create = () =>
                    new BehaviourTree(definition, agent, {
                        onNodeStateChange: ({ type, previousState, state }) =>
                            changes.push(`${type} ${previousState} ${state}`)
                    });

                const original = create();
                original.step();
                const snapshot = throughJSON(original.snapshot());

                changes.length = 0;
                const restored = create();
                restored.restore(snapshot);
                assert.deepEqual(changes, []);
                assert.deepEqual(getNodeStates(restored), getNodeStates(original));

                // This includes a tree that had made progress, which is restored to an earlier state and to a finished one.
                restored.step();
                restored.step();
                changes.length = 0;
                restored.restore(snapshot);
                assert.deepEqual(changes, []);
                assert.deepEqual(getNodeStates(restored), getNodeStates(original));
            });

            it("an 'onNodeStateChange' option that throws does not stop a restore", () => {
                const source = new BehaviourTree(definition, agent);
                source.step();
                const snapshot = throughJSON(source.snapshot());

                const tree = new BehaviourTree(definition, agent, {
                    onNodeStateChange: () => {
                        throw new Error("callback failed");
                    }
                });

                tree.restore(snapshot);
                assert.deepEqual(tree.snapshot(), snapshot);
            });

            it("the next step reports changes as usual, from the restored states", () => {
                const changes: string[] = [];
                const create = (other: () => State | undefined, onChange: boolean) =>
                    new BehaviourTree(
                        definition,
                        { Work: () => State.SUCCEEDED, Other: other },
                        onChange
                            ? {
                                  onNodeStateChange: ({ type, previousState, state }) =>
                                      changes.push(`${type} ${previousState} ${state}`)
                              }
                            : {}
                    );

                // The original has its second action still running when it is snapshotted.
                const original = create(() => undefined, false);
                original.step();
                const snapshot = throughJSON(original.snapshot());

                // In the restored tree that action finishes on the next step.
                const restored = create(() => State.SUCCEEDED, true);
                restored.restore(snapshot);
                assert.deepEqual(changes, []);

                restored.step();

                assert.deepEqual(changes, [
                    `action ${RUNNING} ${SUCCEEDED}`,
                    `sequence ${RUNNING} ${SUCCEEDED}`,
                    `root ${RUNNING} ${SUCCEEDED}`
                ]);
            });
        });

        describe("will error, and leave the tree as it was, if the snapshot is of another definition", () => {
            const MISMATCH = "snapshot does not match the tree's definition";

            const definition = `root {
                sequence {
                    action [Walk, 1, "two"]
                    wait [100]
                    lotto [1, 3] {
                        action [Left] while(CanGoLeft)
                        action [Right]
                    }
                }
            }`;

            const otherDefinitions: [string, string | RootNodeDefinition | RootNodeDefinition[]][] = [
                ["has a different structure", 'root { sequence { action [Walk, 1, "two"] } }'],
                ["has a different node type", definition.replace("sequence", "selector")],
                ["has a different action", definition.replace("Walk", "Run")],
                ["has different action arguments", definition.replace('"two"', '"three"')],
                ["has different action argument types", definition.replace('"two"', "2")],
                ["has a different wait duration", definition.replace("wait [100]", "wait [101]")],
                ["has a different lotto weight", definition.replace("[1, 3]", "[1, 4]")],
                ["has a different guard", definition.replace("while(CanGoLeft)", "while(CanGoRight)")],
                ["has a guard that is not defined", definition.replace(" while(CanGoLeft)", "")],
                ["has a different callback", definition.replace("action [Right]", "action [Right] entry(OnRight)")],
                [
                    "is written in JSON with a different action",
                    { type: "root", child: { type: "action", call: "Walk" } }
                ]
            ];

            const createTree = (source: string | RootNodeDefinition | RootNodeDefinition[]) => {
                const names = ["Walk", "Run", "Left", "Right", "CanGoLeft", "CanGoRight", "OnRight", "Work"];
                const agent: { [key: string]: () => any } = {};
                const actions = ["Walk", "Run", "Left", "Right"];
                names.forEach((name) => (agent[name] = () => (actions.includes(name) ? RUNNING : true)));
                const changes: string[] = [];
                const tree = new BehaviourTree(source, agent as any, {
                    onNodeStateChange: (change) => changes.push(change.type)
                });
                return { tree, changes };
            };

            for (const [description, other] of otherDefinitions) {
                it(description, () => {
                    const { tree: source } = createTree(other);
                    source.step();
                    const snapshot = throughJSON(source.snapshot());

                    const { tree, changes } = createTree(definition);
                    tree.step();
                    const before = tree.snapshot();
                    changes.length = 0;

                    assert.throws(() => tree.restore(snapshot), Error, MISMATCH);
                    assert.deepEqual(tree.snapshot(), before);
                    assert.deepEqual(changes, []);
                });
            }

            it("because a subtree that was registered when the tree was built is not the same", () => {
                const createWithSubtree = (subtree: string) => {
                    BehaviourTree.register("Subtree", subtree);
                    try {
                        return new BehaviourTree("root { branch [Subtree] }", {
                            Work: () => RUNNING,
                            Rest: () => RUNNING
                        });
                    } finally {
                        BehaviourTree.unregisterAll();
                    }
                };

                const source = createWithSubtree("root { action [Rest] }");
                const tree = createWithSubtree("root { action [Work] }");
                source.step();
                tree.step();

                assert.throws(() => tree.restore(throughJSON(source.snapshot())), Error, MISMATCH);
                assert.doesNotThrow(() => tree.restore(throughJSON(tree.snapshot())));
            });

            it("but does not do so for a snapshot that is of the tree's own definition", () => {
                const { tree: source } = createTree(definition);
                source.step();
                const snapshot = throughJSON(source.snapshot());

                const { tree } = createTree(definition);

                assert.doesNotThrow(() => tree.restore(snapshot));
                assert.deepEqual(getNodeStates(tree), getNodeStates(source));
            });
        });

        describe("will treat definitions that are equivalent as the same definition, so that a snapshot", () => {
            const mdsl = `root {
                sequence while(IsOk, 1) entry(OnEntry) {
                    action [Work, 1, "a", true, null, $prop] until(IsDone) exit(OnExit)
                    condition [Check]
                    wait [10, 20]
                    wait
                    repeat [2] {
                        lotto [1, 2] {
                            action [A]
                            branch [Sub]
                        }
                    }
                    retry { flip { succeed { fail { branch [Sub] } } } }
                    parallel { race { action [A] } all { action [A] } }
                    selector { action [A] }
                }
            }

            root [Sub] {
                action [A] step(OnStep)
            }`;

            // The same definition as the MDSL, as someone writing JSON would, with no empty 'args' arrays or 'succeedOnAbort' false, and the sub root first.
            const json: RootNodeDefinition[] = [
                { id: "Sub", type: "root", child: { call: "A", step: { call: "OnStep" }, type: "action" } },
                {
                    child: {
                        children: [
                            {
                                type: "action",
                                call: "Work",
                                args: [1, "a", true, null, { $: "prop" }],
                                until: { call: "IsDone", succeedOnAbort: false },
                                exit: { call: "OnExit" }
                            },
                            { type: "condition", call: "Check" },
                            { type: "wait", duration: [10, 20] },
                            { type: "wait" },
                            {
                                type: "repeat",
                                iterations: 2,
                                child: {
                                    type: "lotto",
                                    weights: [1, 2],
                                    children: [
                                        { type: "action", call: "A", args: [] },
                                        { type: "branch", ref: "Sub" }
                                    ]
                                }
                            },
                            {
                                type: "retry",
                                child: {
                                    type: "flip",
                                    child: {
                                        type: "succeed",
                                        child: { type: "fail", child: { type: "branch", ref: "Sub" } }
                                    }
                                }
                            },
                            {
                                type: "parallel",
                                children: [
                                    { type: "race", children: [{ type: "action", call: "A" }] },
                                    { type: "all", children: [{ type: "action", call: "A" }] }
                                ]
                            },
                            { type: "selector", children: [{ type: "action", call: "A" }] }
                        ],
                        type: "sequence",
                        while: { call: "IsOk", args: [1] },
                        entry: { call: "OnEntry", args: [] }
                    },
                    type: "root"
                }
            ];

            const agent = () => ({
                IsOk: () => true,
                OnEntry: () => {},
                Work: () => RUNNING,
                IsDone: () => false,
                OnExit: () => {},
                Check: () => true,
                A: () => RUNNING,
                OnStep: () => {},
                prop: 1
            });

            const equivalents: [string, string | RootNodeDefinition | RootNodeDefinition[]][] = [
                ["written as JSON", json],
                ["written as MDSL with different whitespace and comments", `/* a tree */ ${mdsl.replace(/\s+/g, " ")}`],
                ["written as MDSL with the sub root first", mdsl.replace(/^(.*?)(root \[Sub\].*)$/s, "$2 $1")]
            ];

            for (const [description, other] of equivalents) {
                it(`of the MDSL definition can be restored to a tree that is ${description}, and the reverse`, () => {
                    const first = new BehaviourTree(mdsl, agent() as any);
                    const second = new BehaviourTree(other, agent() as any);
                    first.step();
                    second.step();

                    assert.strictEqual(first.snapshot().definition, second.snapshot().definition);

                    const fresh = new BehaviourTree(other, agent() as any);
                    fresh.restore(throughJSON(first.snapshot()));
                    assert.deepEqual(getNodeStates(fresh), getNodeStates(first));

                    const freshMDSL = new BehaviourTree(mdsl, agent() as any);
                    freshMDSL.restore(throughJSON(second.snapshot()));
                    assert.deepEqual(getNodeStates(freshMDSL), getNodeStates(second));
                });
            }

            it("of a JSON definition that is a single root node object can be restored to one that is an array", () => {
                const root: RootNodeDefinition = { type: "root", child: { type: "action", call: "A" } };
                const source = new BehaviourTree(root, agent() as any);
                source.step();

                const tree = new BehaviourTree([root], agent() as any);
                tree.restore(throughJSON(source.snapshot()));

                assert.deepEqual(getNodeStates(tree), getNodeStates(source));
            });

            it("of a lotto node without weights can be restored to one with a weight of one for each child", () => {
                const source = new BehaviourTree("root { lotto { action [A] action [A] } }", agent() as any);
                source.step();

                const tree = new BehaviourTree("root { lotto [1, 1] { action [A] action [A] } }", agent() as any);

                assert.doesNotThrow(() => tree.restore(throughJSON(source.snapshot())));
            });

            it("of a definition that has a root that is never branched to can be restored to one that does not", () => {
                const source = new BehaviourTree("root { action [A] } root [Unused] { action [B] }", {
                    A: () => RUNNING
                });
                source.step();

                const tree = new BehaviourTree("root { action [A] }", { A: () => RUNNING });

                assert.doesNotThrow(() => tree.restore(throughJSON(source.snapshot())));
            });
        });

        describe("will error, and leave the tree as it was, if what is restored is not a snapshot, such as", () => {
            const notSnapshots: [string, unknown][] = [
                ["null", null],
                ["undefined", undefined],
                ["a string", "snapshot"],
                ["a JSON string of a snapshot", JSON.stringify({ version: 1, definition: "a", root: {} })],
                ["a number", 1],
                ["a boolean", true],
                ["an empty array", []],
                ["an array of a snapshot", [{ version: 1, definition: "a", root: {} }]],
                ["an empty object", {}],
                ["an object with other fields", { state: RUNNING, children: [] }],
                ["a function", () => ({ version: 1 })]
            ];

            for (const [description, notSnapshot] of notSnapshots) {
                it(description, () => {
                    const changes: string[] = [];
                    const tree = new BehaviourTree("root { sequence { action [Work] action [Work] } }", {
                        Work: () => RUNNING
                    });
                    tree.step();
                    const before = tree.snapshot();

                    assert.throws(() => tree.restore(notSnapshot as any), Error);
                    assert.deepEqual(tree.snapshot(), before);
                    assert.deepEqual(changes, []);
                });
            }
        });

        describe("will error, and leave the tree as it was, if the snapshot", () => {
            const createTree = () => {
                const tree = new BehaviourTree(
                    "root { sequence { repeat [3] { action [Work] } lotto { wait [10] action [Work] } } }",
                    { Work: () => State.SUCCEEDED }
                );
                tree.step();
                return tree;
            };

            const invalidSnapshots: [string, (snapshot: any) => any, string][] = [
                ["is not an object", () => 42, "invalid snapshot: expected an object"],
                ["is null", () => null, "invalid snapshot: expected an object"],
                [
                    "has no version",
                    (s) => ({ definition: s.definition, root: s.root }),
                    "invalid snapshot: unsupported version 'undefined'"
                ],
                ["has an unknown version", (s) => ({ ...s, version: 2 }), "invalid snapshot: unsupported version '2'"],
                [
                    "has no root",
                    (s) => ({ version: s.version, definition: s.definition }),
                    "invalid snapshot: root: expected an object"
                ],
                [
                    "has no definition",
                    (s) => ({ version: s.version, root: s.root }),
                    "invalid snapshot: invalid definition 'undefined'"
                ],
                [
                    "has a definition that is not a string",
                    (s) => ({ ...s, definition: 42 }),
                    "invalid snapshot: invalid definition '42'"
                ],
                [
                    "has a root of the wrong type",
                    (s) => ({ ...s, root: { ...s.root, type: "sequence" } }),
                    "invalid snapshot: root: expected node type 'root' but got 'sequence'"
                ],
                [
                    "has a node state that is not a state",
                    (s) => ((s.root.children[0].state = "mistreevous.nope"), s),
                    "invalid snapshot: root.children[0]: invalid state 'mistreevous.nope'"
                ],
                [
                    "has a node with children missing",
                    (s) => (s.root.children[0].children.pop(), s),
                    "invalid snapshot: root.children[0]: expected 2 children but got 1"
                ],
                [
                    "has a node with children that are not an array",
                    (s) => ((s.root.children[0].children = {}), s),
                    "invalid snapshot: root.children[0]: expected an array of children"
                ],
                [
                    "has a nested node of the wrong type",
                    (s) => ((s.root.children[0].children[0].children[0].type = "condition"), s),
                    "invalid snapshot: root.children[0].children[0].children[0]: expected node type 'action' but got 'condition'"
                ],
                [
                    "has a repeat node count that is not a non-negative integer",
                    (s) => ((s.root.children[0].children[0].iterationCount = -1), s),
                    "invalid snapshot: root.children[0].children[0]: invalid iterationCount '-1'"
                ],
                [
                    "has a repeat node target that is not a count or null",
                    (s) => ((s.root.children[0].children[0].targetIterationCount = "3"), s),
                    "invalid snapshot: root.children[0].children[0]: invalid targetIterationCount '3'"
                ],
                [
                    "has a lotto node selected child that does not exist",
                    (s) => ((s.root.children[0].children[1].selectedChild = 2), s),
                    "invalid snapshot: root.children[0].children[1]: invalid selectedChild '2'"
                ],
                [
                    "has a running lotto node with no selected child",
                    (s) => ((s.root.children[0].children[1].selectedChild = null), s),
                    "invalid snapshot: root.children[0].children[1]: a running lotto node must have a selectedChild"
                ],
                [
                    "has a wait node duration that is not a number",
                    (s) => ((s.root.children[0].children[1].children[0].waitedDuration = "1"), s),
                    "invalid snapshot: root.children[0].children[1].children[0]: invalid waitedDuration '1'"
                ]
            ];

            for (const [description, change, message] of invalidSnapshots) {
                it(description, () => {
                    const tree = createTree();
                    const before = tree.snapshot();

                    // Get a snapshot with some state in the lotto node, and the wait node, so that every case has something to be wrong with.
                    const source = createTree();
                    const snapshot = throughJSON(source.snapshot()) as any;
                    snapshot.root.children[0].children[1].selectedChild = 1;
                    snapshot.root.children[0].children[1].state = RUNNING;
                    snapshot.root.children[0].children[1].children[0].state = RUNNING;
                    snapshot.root.children[0].children[1].children[0].totalDuration = 10;

                    assert.throws(() => tree.restore(change(snapshot)), Error, message);
                    assert.deepEqual(tree.snapshot(), before);
                });
            }
        });

        it("will error if called as part of a step of the tree", () => {
            const tree: BehaviourTree = new BehaviourTree("root { action [Work] }", {
                Work: () => tree.restore({ version: 1, root: { type: "root", state: READY, children: [] } } as any)
            });

            assert.throws(
                () => tree.step(),
                Error,
                "error stepping tree: action function 'Work' threw: Error: cannot restore the tree while it is being stepped"
            );
        });

        describe("gives a snapshot that is independent of the trees, so that for", () => {
            for (const [name, scenario] of Object.entries(scenarios)) {
                it(`${name}, stepping neither tree changes it and restoring it does not change it`, () => {
                    const harness = new SnapshotHarness(scenario, clock);

                    for (let snapshotAfter = 0; snapshotAfter <= scenario.steps; snapshotAfter++) {
                        clock.setSystemTime(START_TIME);

                        const original = harness.create();
                        harness.run(original, 0, snapshotAfter);

                        const snapshot = original.tree.snapshot();
                        const expected = throughJSON(snapshot);
                        const label = `snapshot after step ${snapshotAfter}`;

                        // Stepping the tree that the snapshot was taken from does not change it.
                        harness.run(original, snapshotAfter, scenario.steps);
                        assert.deepEqual(snapshot, expected, `${label}: changed by stepping the original`);

                        // Restoring it, and then taking a snapshot before any step, gives the same snapshot.
                        const restored = harness.create(original.random.position);
                        restored.step.current = snapshotAfter;
                        restored.tree.restore(snapshot);
                        assert.deepEqual(snapshot, expected, `${label}: changed by restoring it`);
                        assert.deepEqual(
                            throughJSON(restored.tree.snapshot()),
                            expected,
                            `${label}: snapshot of the restored tree`
                        );

                        // Stepping the restored tree does not change it either.
                        harness.run(restored, snapshotAfter, scenario.steps);
                        assert.deepEqual(snapshot, expected, `${label}: changed by stepping the restored tree`);
                    }
                });
            }
        });

        it("gives a snapshot that is independent of the trees when an action has a promise that has settled", async () => {
            for (const settle of [() => Promise.resolve(State.SUCCEEDED), () => Promise.reject(new Error("failed"))]) {
                const create = () =>
                    new BehaviourTree("root { sequence { action [Work] action [Next] } }", {
                        Work: settle,
                        Next: () => State.SUCCEEDED
                    });

                const original = create();
                original.step();
                await new Promise((resolve) => setTimeout(resolve, 0));

                const snapshot = original.snapshot();
                const expected = throughJSON(snapshot);
                assert.isDefined((snapshot.root as any).children[0].children[0].promiseResult);

                const restored = create();
                restored.restore(snapshot);
                assert.deepEqual(throughJSON(restored.snapshot()), expected);

                for (const tree of [original, restored]) {
                    try {
                        tree.step();
                    } catch {
                        // The rejected promise is expected to error when it is handled.
                    }
                    assert.deepEqual(snapshot, expected);
                }
            }
        });

        describe("results in a tree that behaves exactly as the tree the snapshot was taken from, for", () => {
            for (const [name, scenario] of Object.entries(scenarios)) {
                it(name, () => {
                    const harness = new SnapshotHarness(scenario, clock);

                    harness.checkRestoredTreeMatchesOriginal(assertDeepEqual);
                });
            }
        });

        describe("will keep a random choice that was already made, rather than making it again, for a", () => {
            it("lotto node", () => {
                const calls: string[] = [];
                const definition = "root { lotto { action [A] action [B] action [C] } }";
                const functions = (name: string) => () => {
                    calls.push(name);
                };

                const original = new BehaviourTree(
                    definition,
                    { A: functions("A"), B: functions("B"), C: functions("C") },
                    { random: createRandom([0.99]) }
                );
                original.step();
                const snapshot = throughJSON(original.snapshot());
                assert.deepEqual(calls, ["C"]);

                // A tree where the random function would pick a different child.
                const restored = new BehaviourTree(
                    definition,
                    { A: functions("A"), B: functions("B"), C: functions("C") },
                    { random: createRandom([0]) }
                );
                restored.restore(snapshot);
                restored.step();
                restored.step();

                assert.deepEqual(calls, ["C", "C", "C"]);
            });

            for (const [type, count] of [
                ["repeat", "iterations"],
                ["retry", "attempts"]
            ]) {
                it(`${type} node, and the ${count} made so far`, () => {
                    const calls: string[] = [];
                    const result = type === "repeat" ? State.SUCCEEDED : State.FAILED;
                    const definition = `root { ${type} [2, 5] { action [Work] } }`;
                    const create = (random: number) =>
                        new BehaviourTree(
                            definition,
                            { Work: () => (calls.push("Work"), result) },
                            { random: createRandom([random]) }
                        );

                    // This will pick 5 as the number of times to go round.
                    const original = create(0.99);
                    original.step();
                    original.step();
                    assert.strictEqual(calls.length, 2);
                    const snapshot = throughJSON(original.snapshot());

                    // This would pick 2 if it made its own choice.
                    const restored = create(0);
                    calls.length = 0;
                    restored.restore(snapshot);

                    for (let index = 0; index < 3; index++) {
                        restored.step();
                        assert.strictEqual(restored.getState(), RUNNING);
                    }

                    // 2 done so far plus 3 more makes 5.
                    restored.step();
                    assert.deepEqual(calls.length, 3);
                    assert.strictEqual(restored.getState(), type === "repeat" ? SUCCEEDED : FAILED);
                });
            }

            it("wait node", () => {
                const definition = "root { wait [1000, 3000] }";

                // This will pick a duration of 2000.
                const original = new BehaviourTree(definition, {}, { random: createRandom([0.5]) });
                original.step();
                clock.tick(100);
                const snapshot = throughJSON(original.snapshot());

                // This would pick a duration of 1000 if it made its own choice.
                const restored = new BehaviourTree(definition, {}, { random: createRandom([0]) });
                restored.restore(snapshot);
                clock.tick(1500);
                restored.step();

                assert.strictEqual(restored.getState(), RUNNING);

                // 1600ms waited so far.
                clock.tick(399);
                restored.step();

                assert.strictEqual(restored.getState(), RUNNING);

                clock.tick(1);
                restored.step();

                assert.strictEqual(restored.getState(), SUCCEEDED);
            });
        });

        describe("will make a wait node wait only for the remaining time when it uses", () => {
            it("the clock", () => {
                const original = new BehaviourTree("root { wait [1000] }", {});
                original.step();
                clock.tick(400);
                const snapshot = throughJSON(original.snapshot());

                // An hour passes before the tree is restored.
                clock.tick(60 * 60 * 1000);
                const restored = new BehaviourTree("root { wait [1000] }", {});
                restored.restore(snapshot);

                restored.step();
                assert.strictEqual(restored.getState(), RUNNING);

                clock.tick(599);
                restored.step();
                assert.strictEqual(restored.getState(), RUNNING);

                clock.tick(1);
                restored.step();
                assert.strictEqual(restored.getState(), SUCCEEDED);
            });

            it("the clock, counting time since the last step as time waited", () => {
                const original = new BehaviourTree("root { wait [1000] }", {});
                original.step();
                clock.tick(900);

                // No step was made in the 900ms, but they have passed.
                assert.strictEqual((throughJSON(original.snapshot()).root as any).children[0].waitedDuration, 900);

                const restored = new BehaviourTree("root { wait [1000] }", {});
                restored.restore(throughJSON(original.snapshot()));
                clock.tick(100);
                restored.step();

                assert.strictEqual(restored.getState(), SUCCEEDED);
            });

            it("the 'getDeltaTime' option", () => {
                let deltaTimeCalls = 0;
                const options = {
                    getDeltaTime: () => {
                        deltaTimeCalls++;
                        return 0.5;
                    }
                };

                const original = new BehaviourTree("root { wait [2000] }", {}, options);
                original.step();
                original.step();
                const snapshot = throughJSON(original.snapshot());
                assert.strictEqual((snapshot.root as any).children[0].waitedDuration, 1000);

                // A long time passes before the tree is restored, but that is not delta time.
                clock.tick(60 * 60 * 1000);
                deltaTimeCalls = 0;
                const restored = new BehaviourTree("root { wait [2000] }", {}, options);
                restored.restore(snapshot);
                assert.strictEqual(deltaTimeCalls, 0);

                restored.step();
                assert.strictEqual(restored.getState(), RUNNING);
                restored.step();
                assert.strictEqual(restored.getState(), SUCCEEDED);
                assert.strictEqual(deltaTimeCalls, 2);
            });

            it("a snapshot taken while using the clock that is restored into a tree using the 'getDeltaTime' option", () => {
                const original = new BehaviourTree("root { wait [2000] }", {});
                original.step();
                clock.tick(1500);
                const snapshot = throughJSON(original.snapshot());

                const restored = new BehaviourTree("root { wait [2000] }", {}, { getDeltaTime: () => 0.25 });
                restored.restore(snapshot);
                restored.step();
                assert.strictEqual(restored.getState(), RUNNING);
                restored.step();
                assert.strictEqual(restored.getState(), SUCCEEDED);
            });
        });

        describe("will restore a finished tree as finished, and the next step of it will start a new run that", () => {
            it("makes its random choices again", () => {
                const calls: string[] = [];
                const definition = `root { sequence {
                    lotto { action [A] action [B] }
                    repeat [1, 4] { action [C] }
                    wait [1000, 3000]
                } }`;
                const create = (random: number[]) =>
                    new BehaviourTree(
                        definition,
                        {
                            A: () => (calls.push("A"), State.SUCCEEDED),
                            B: () => (calls.push("B"), State.SUCCEEDED),
                            C: () => (calls.push("C"), State.SUCCEEDED)
                        },
                        { random: createRandom(random), getDeltaTime: () => 1 }
                    );

                // Picks A, repeats 1 time, waits for 1000ms.
                const original = create([0, 0, 0]);
                original.step();
                original.step();
                assert.strictEqual(original.getState(), SUCCEEDED);
                assert.deepEqual(calls, ["A", "C"]);
                const snapshot = throughJSON(original.snapshot());

                // Picks B, repeats 4 times, waits for 3000ms, if the choices are made again.
                calls.length = 0;
                const restored = create([0.99, 0.99, 0.99]);
                restored.restore(snapshot);

                assert.strictEqual(restored.getState(), SUCCEEDED);
                assert.isFalse(restored.isRunning());
                assert.deepEqual(calls, []);

                // The repeat node goes round 4 times and then finishes, at which point the wait node starts, and has waited for 1000ms.
                for (let index = 0; index < 5; index++) {
                    restored.step();
                }

                assert.deepEqual(calls, ["B", "C", "C", "C", "C"]);
                assert.strictEqual(restored.getState(), RUNNING);

                // It was 1000ms that was waited for the first time, but this time it is 2980ms.
                restored.step();
                assert.strictEqual(restored.getState(), RUNNING);
                restored.step();
                assert.strictEqual(restored.getState(), SUCCEEDED);
            });

            it("calls the entry callbacks of nodes again", () => {
                const calls: string[] = [];
                const definition = "root { action [Work] entry(OnEntry) }";
                const create = () =>
                    new BehaviourTree(definition, {
                        Work: () => State.FAILED,
                        OnEntry: () => calls.push("entry")
                    });

                const original = create();
                original.step();
                const snapshot = throughJSON(original.snapshot());
                assert.strictEqual(original.getState(), FAILED);

                const restored = create();
                calls.length = 0;
                restored.restore(snapshot);
                assert.strictEqual(restored.getState(), FAILED);
                assert.deepEqual(calls, []);

                restored.step();
                assert.deepEqual(calls, ["entry"]);
            });
        });

        describe("will handle an action that returned a promise", () => {
            it("that settled before the snapshot was taken, without calling the action function again", async () => {
                const definition = "root { sequence { action [Work] action [Next] } }";
                const calls: string[] = [];
                const create = () =>
                    new BehaviourTree(definition, {
                        Work: () => (calls.push("Work"), Promise.resolve(State.SUCCEEDED)),
                        Next: () => (calls.push("Next"), State.SUCCEEDED)
                    });

                const original = create();
                original.step();
                await Promise.resolve();
                const rawSnapshot = original.snapshot();
                assertPlain(rawSnapshot);
                assert.deepEqual(throughJSON(rawSnapshot), rawSnapshot);
                assert.deepEqual((rawSnapshot.root as any).children[0].children[0].promiseResult, {
                    isResolved: true,
                    value: SUCCEEDED
                });
                const snapshot = throughJSON(rawSnapshot);

                calls.length = 0;
                const restored = create();
                restored.restore(snapshot);

                assert.strictEqual(restored.getState(), RUNNING);
                restored.step();

                assert.deepEqual(calls, ["Next"]);
                assert.strictEqual(restored.getState(), SUCCEEDED);
            });

            it("that was rejected before the snapshot was taken, with the same error when stepped", async () => {
                const definition = "root { action [Work] }";
                const create = () => new BehaviourTree(definition, { Work: () => Promise.reject(new Error("oh no")) });

                const original = create();
                original.step();
                await Promise.resolve();
                const snapshot = throughJSON(original.snapshot());
                assert.throws(
                    () => original.step(),
                    Error,
                    "action function 'Work' promise rejected with 'Error: oh no'"
                );

                const restored = create();
                restored.restore(snapshot);
                assert.throws(
                    () => restored.step(),
                    Error,
                    "action function 'Work' promise rejected with 'Error: oh no'"
                );
            });

            it("without being changed by a promise that settles later for the state that was replaced", async () => {
                const definition = "root { action [Work] }";

                // A tree with a promise that will be settled after a restore.
                let resolveLate: (state: State.SUCCEEDED) => void = () => {};
                const late = new BehaviourTree(definition, {
                    Work: () => new Promise<State.SUCCEEDED>((resolve) => (resolveLate = resolve))
                });
                late.step();

                // A snapshot of a tree with a promise that already settled.
                const source = new BehaviourTree(definition, { Work: () => Promise.resolve(State.FAILED) });
                source.step();
                await Promise.resolve();
                late.restore(throughJSON(source.snapshot()));

                resolveLate(State.SUCCEEDED);
                await Promise.resolve();
                late.step();

                assert.strictEqual(late.getState(), FAILED);
            });
        });

        describe("will restore a tree with guards and callbacks, which then behave as they would have", () => {
            it("when a guard is no longer satisfied", () => {
                const harness = new SnapshotHarness(guardScenario, clock);

                harness.checkRestoredTreeMatchesOriginal(assertDeepEqual);
            });
        });

        it("will restore a tree defined using JSON", () => {
            const definition: RootNodeDefinition = {
                type: "root",
                child: {
                    type: "sequence",
                    children: [
                        { type: "repeat", iterations: [2, 4], child: { type: "action", call: "Work" } },
                        { type: "wait", duration: [100, 200] }
                    ]
                }
            };

            const harness = new SnapshotHarness(
                {
                    definition,
                    steps: 12,
                    random: [0.9, 0.1],
                    functions: { Work: (step) => (step % 2 ? State.SUCCEEDED : undefined) },
                    clockAdvance: 30
                },
                clock
            );

            harness.checkRestoredTreeMatchesOriginal(assertDeepEqual);
        });
    });
});
