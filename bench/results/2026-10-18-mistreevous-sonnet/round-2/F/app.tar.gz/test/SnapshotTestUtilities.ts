import { assert } from "chai";
import { SinonFakeTimers } from "sinon";

import { BehaviourTree, BehaviourTreeOptions, NodeDetails, TreeSnapshot } from "../src/index";
import { RootNodeDefinition } from "../src/BehaviourTreeDefinition";
import { Agent } from "../src/Agent";

export const START_TIME = 1_000_000;
const A_WEEK = 7 * 24 * 60 * 60 * 1000;

/**
 * Asserts that a value is made only of plain objects, arrays, strings, finite numbers, booleans and nulls.
 */
export const assertPlain = (value: unknown, path = "snapshot") => {
    if (value === null || typeof value === "string" || typeof value === "boolean") {
        return;
    }

    if (typeof value === "number") {
        assert.isTrue(Number.isFinite(value), `${path} is not a finite number`);
        return;
    }

    if (Array.isArray(value)) {
        value.forEach((item, index) => assertPlain(item, `${path}[${index}]`));
        return;
    }

    assert.isTrue(
        typeof value === "object" && Object.getPrototypeOf(value) === Object.prototype,
        `${path} is not a plain object`
    );

    for (const [key, item] of Object.entries(value as object)) {
        assert.notStrictEqual(item, undefined, `${path}.${key} is undefined`);
        assertPlain(item, `${path}.${key}`);
    }
};

/**
 * Round trip a value through JSON, as an application would when persisting a snapshot.
 */
export const throughJSON = <T>(value: T): T => JSON.parse(JSON.stringify(value));

/**
 * Gets the node names and states of a tree, in depth-first order.
 */
export const getNodeStates = (tree: BehaviourTree): string[] => {
    const states: string[] = [];
    const visit = (node: NodeDetails) => {
        states.push(`${node.name}:${node.state}`);
        (node.children ?? []).forEach(visit);
    };
    visit(tree.getTreeNodeDetails());
    return states;
};

/**
 * Creates a random function that returns the given values in order, repeating the last one.
 * The position in the values can be read, and set to resume a sequence part way through.
 */
export const createRandom = (values: number[], position = 0) => {
    const random = () => values[Math.min(random.position++, values.length - 1)];
    random.position = position;
    return random;
};

/**
 * A scripted run of a tree, in which the behaviour of the agent, the random numbers and the passing of time are all fixed.
 */
export type Scenario = {
    definition: string | RootNodeDefinition | RootNodeDefinition[];
    /** The number of steps in the run. */
    steps: number;
    /** The agent functions, each getting its result from the step being run. Every call is logged. */
    functions: { [name: string]: (step: number) => any };
    /** The values that the 'random' option returns, in order. The last one repeats. */
    random?: number[];
    /** The delta time in seconds for each step. If undefined then the (fake) clock is used instead of a 'getDeltaTime' option. */
    deltaTimes?: number[];
    /** The number of milliseconds to advance the (fake) clock by before each step. */
    clockAdvance?: number | ((step: number) => number);
};

type RunContext = {
    tree: BehaviourTree;
    log: string[];
    random: ReturnType<typeof createRandom>;
    deltaTimeCalls: { count: number };
    step: { current: number };
};

/**
 * A harness for checking that a restored tree behaves exactly as the tree that the snapshot was taken from.
 */
export class SnapshotHarness {
    /**
     * @param scenario The scripted run.
     * @param clock The fake clock that is used for the time, which should be set to START_TIME to begin with.
     */
    constructor(private scenario: Scenario, private clock: SinonFakeTimers) {}

    /** Creates a tree for the scenario, with an agent that logs every call made to it. */
    public create(randomPosition = 0): RunContext {
        const { scenario } = this;
        const log: string[] = [];
        const step = { current: 0 };
        const random = createRandom(scenario.random ?? [0.5], randomPosition);
        const deltaTimeCalls = { count: 0 };

        const agent: Agent = {};
        for (const [name, getResult] of Object.entries(scenario.functions)) {
            agent[name] = (...args: any[]) => {
                log.push(`${step.current}:${name}(${args.length ? "..." : ""})`);
                return getResult(step.current);
            };
        }

        const options: BehaviourTreeOptions = {
            random,
            onNodeStateChange: (change) => log.push(`${step.current}:${change.type}:${change.state}`)
        };

        if (scenario.deltaTimes) {
            options.getDeltaTime = () => {
                deltaTimeCalls.count++;
                return scenario.deltaTimes![step.current];
            };
        }

        return { tree: new BehaviourTree(scenario.definition, agent, options), log, random, deltaTimeCalls, step };
    }

    /** Steps the tree from step `from` up to (not including) step `to`, returning what was observed after each step. */
    public run(context: RunContext, from: number, to: number): string[] {
        const { scenario } = this;
        const observed: string[] = [];

        for (let step = from; step < to; step++) {
            context.step.current = step;

            this.clock.tick(
                typeof scenario.clockAdvance === "function" ? scenario.clockAdvance(step) : scenario.clockAdvance ?? 0
            );

            context.tree.step();

            observed.push(`step ${step}: ${context.tree.getState()} [${getNodeStates(context.tree).join(" ")}]`);
        }

        return observed;
    }

    /**
     * For every step of the scenario: snapshot the original tree after that step, carry on running the original to the end, then restore
     * the snapshot (after a JSON round trip, and after a week has passed) into a new tree and check that it carries on in exactly the same
     * way: the same node states, and the same calls made to the agent in the same order.
     */
    public checkRestoredTreeMatchesOriginal(
        assertDeepEqual: (actual: unknown, expected: unknown, message: string) => void
    ): void {
        for (let snapshotAfter = 0; snapshotAfter <= this.scenario.steps; snapshotAfter++) {
            this.clock.setSystemTime(START_TIME);

            // Run the original tree to the snapshot point and take the snapshot.
            const original = this.create();
            this.run(original, 0, snapshotAfter);
            const rawSnapshot = original.tree.snapshot();
            assertPlain(rawSnapshot);
            assertDeepEqual(
                throughJSON(rawSnapshot),
                rawSnapshot,
                `snapshot after step ${snapshotAfter} changed by JSON`
            );
            const snapshot: TreeSnapshot = throughJSON(rawSnapshot);
            const randomPosition = original.random.position;
            const nodeStatesAtSnapshot = getNodeStates(original.tree);
            const snapshotTime = this.clock.now;

            // Carry on with the original.
            original.log.length = 0;
            const expected = this.run(original, snapshotAfter, this.scenario.steps);
            const expectedLog = [...original.log];

            // A week passes before the snapshot is restored. The restored tree carries on from there, none of that week counts for it.
            this.clock.setSystemTime(snapshotTime + A_WEEK);

            // Restore into a brand new tree, with random numbers picking up from where the original was.
            const restored = this.create(randomPosition);
            restored.step.current = snapshotAfter;
            restored.tree.restore(snapshot);

            const label = `restored after step ${snapshotAfter}`;
            assertDeepEqual(getNodeStates(restored.tree), nodeStatesAtSnapshot, `${label}: node states`);
            assertDeepEqual(throughJSON(restored.tree.snapshot()), snapshot, `${label}: snapshot of restored tree`);
            assertDeepEqual(restored.deltaTimeCalls.count, 0, `${label}: restoring must not read the delta time`);
            assertDeepEqual(restored.log, [], `${label}: restoring must not call the agent or onNodeStateChange`);

            restored.log.length = 0;
            const actual = this.run(restored, snapshotAfter, this.scenario.steps);

            assertDeepEqual(actual, expected, `${label}: observed states`);
            assertDeepEqual(restored.log, expectedLog, `${label}: calls made`);
        }
    }
}
