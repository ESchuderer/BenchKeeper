import { RootNodeDefinition } from "./BehaviourTreeDefinition";

/**
 * Converts a value from a validated tree definition into a canonical form, so that definitions that behave identically are also identical here.
 * Object properties are put in order, and properties that are only ever written out in full by the MDSL parser, with a value that is
 * the same as the one assumed when the property is left out, are dropped.
 * @param value The value to convert.
 * @returns The value in canonical form.
 */
function canonicalise(value: unknown): unknown {
    if (Array.isArray(value)) {
        return value.map(canonicalise);
    }

    if (typeof value !== "object" || value === null) {
        return value;
    }

    const result: { [key: string]: unknown } = {};

    for (const key of Object.keys(value).sort()) {
        const property = (value as { [key: string]: unknown })[key];

        const isDefault =
            property === undefined ||
            (key === "args" && Array.isArray(property) && property.length === 0) ||
            (key === "succeedOnAbort" && property === false);

        if (!isDefault) {
            result[key] = canonicalise(property);
        }
    }

    return result;
}

/**
 * Creates a 128 bit hash of a string (cyrb128), as a string of 32 hexadecimal characters.
 * This is only used to tell definitions apart, it is not suitable for anything that needs to resist someone trying to cause a collision.
 * @param value The string to hash.
 * @returns The hash of the string.
 */
function hash(value: string): string {
    let h1 = 1779033703;
    let h2 = 3144134277;
    let h3 = 1013904242;
    let h4 = 2773480762;

    for (let index = 0; index < value.length; index++) {
        const code = value.charCodeAt(index);

        h1 = h2 ^ Math.imul(h1 ^ code, 597399067);
        h2 = h3 ^ Math.imul(h2 ^ code, 2869860233);
        h3 = h4 ^ Math.imul(h3 ^ code, 951274213);
        h4 = h1 ^ Math.imul(h4 ^ code, 2716044179);
    }

    h1 = Math.imul(h3 ^ (h1 >>> 18), 597399067);
    h2 = Math.imul(h4 ^ (h2 >>> 22), 2869860233);
    h3 = Math.imul(h1 ^ (h3 >>> 17), 951274213);
    h4 = Math.imul(h2 ^ (h4 >>> 19), 2716044179);

    return [h1 ^ h2 ^ h3 ^ h4, h2 ^ h1, h3 ^ h1, h4 ^ h1]
        .map((part) => (part >>> 0).toString(16).padStart(8, "0"))
        .join("");
}

/**
 * Gets a fingerprint of a tree definition, which is the same for an MDSL definition and its equivalent JSON definition.
 * @param rootNodeDefinitions The validated definition of the tree, as an array of root node definitions.
 * @returns The fingerprint of the definition.
 */
export function getDefinitionFingerprint(rootNodeDefinitions: RootNodeDefinition[]): string {
    // The order that the root nodes are defined in makes no difference to the tree, so the main root node goes first and the rest are ordered by id.
    const ordered = [...rootNodeDefinitions].sort(({ id: a = "" }, { id: b = "" }) => (a < b ? -1 : a > b ? 1 : 0));

    return hash(JSON.stringify(canonicalise(ordered)));
}
