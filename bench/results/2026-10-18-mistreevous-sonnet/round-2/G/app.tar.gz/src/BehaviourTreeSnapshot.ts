import { AnyState } from "./State";

/**
 * The current version of the snapshot format.
 */
export const SNAPSHOT_VERSION = 1;

/**
 * A snapshot of the execution state of a single node in a behaviour tree, and of all of its nested nodes.
 * This is a plain object that is safe to serialise as JSON.
 */
export type NodeSnapshot = {
    /**
     * The tree node identifier.
     */
    id: string;
    /**
     * The tree node type.
     */
    type: string;
    /**
     * The tree node name, which is checked when a snapshot is restored to make sure that it matches the node it is restored to.
     */
    name: string;
    /**
     * The state of the tree node.
     */
    state: AnyState;
    /**
     * The snapshots of the child nodes of this node, defined if this node is a composite or decorator node.
     */
    children?: NodeSnapshot[];
    /**
     * The number of iterations that this `repeat` node will make, including a random choice already made, or null if it is yet to start or will repeat indefinitely.
     */
    targetIterationCount?: number | null;
    /**
     * The number of iterations that this `repeat` node has completed.
     */
    currentIterationCount?: number;
    /**
     * The number of attempts that this `retry` node will make, including a random choice already made, or null if it is yet to start or will retry indefinitely.
     */
    targetAttemptCount?: number | null;
    /**
     * The number of attempts that this `retry` node has completed.
     */
    currentAttemptCount?: number;
    /**
     * The index of the child node picked by this `lotto` node as the active one, or null if it is yet to pick one.
     */
    selectedChild?: number | null;
    /**
     * The total duration in milliseconds that this `wait` node will wait for, including a random choice already made, or null if it is yet to start or will wait indefinitely.
     */
    totalDuration?: number | null;
    /**
     * The duration in milliseconds that this `wait` node has waited for, as of the time that the snapshot was taken.
     */
    waitedDuration?: number;
    /**
     * The settled result of the promise returned by the function of this `action` node, or null if there is no such result.
     * A promise that has not settled cannot be snapshotted, so an `action` node that is waiting on one is snapshotted in the `READY` state, as if it had not yet started, and will call its function again when restored.
     * A resolved value other than a finished node state, and the reason a promise was rejected, are stored as strings as they are only ever used in error messages.
     */
    updatePromiseResult?: { isResolved: boolean; value: string | null } | null;
};

/**
 * A snapshot of the execution state of a behaviour tree, as returned by `BehaviourTree.snapshot()`.
 * This is a plain object that is safe to serialise as JSON and can be passed to `BehaviourTree.restore()` of a tree built from the same definition.
 */
export type TreeSnapshot = {
    /**
     * The version of the snapshot format.
     */
    version: typeof SNAPSHOT_VERSION;
    /**
     * A fingerprint of the definition of the tree that the snapshot was taken from, which is the same for an MDSL definition and its equivalent JSON definition.
     * A snapshot can only be restored to a tree that has the same definition.
     */
    definition: string;
    /**
     * The snapshot of the root node of the tree.
     */
    root: NodeSnapshot;
};
