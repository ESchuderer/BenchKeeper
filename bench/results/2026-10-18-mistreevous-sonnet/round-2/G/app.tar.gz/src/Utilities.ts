/**
 * Create a randomly generated node uid.
 * @returns A randomly generated node uid.
 */
export function createUid(): string {
    const S4 = function () {
        return (((1 + Math.random()) * 0x10000) | 0).toString(16).substring(1);
    };
    return S4() + S4() + "-" + S4() + "-" + S4() + "-" + S4() + "-" + S4() + S4() + S4();
}

/**
 * Determines whether the passed value is an integer that is not negative.
 * @param value The value to check.
 * @returns Whether the passed value is a non-negative integer.
 */
export function isNonNegativeInteger(value: unknown): boolean {
    return typeof value === "number" && Number.isInteger(value) && value >= 0;
}
