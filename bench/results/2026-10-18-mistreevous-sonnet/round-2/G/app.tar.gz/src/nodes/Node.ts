import { BehaviourTreeOptions } from "../BehaviourTreeOptions";
import State, { AnyState } from "../State";
import { Agent } from "../Agent";
import Leaf from "./leaf/Leaf";
import Attribute from "../attributes/Attribute";
import Entry from "../attributes/callbacks/Entry";
import Exit from "../attributes/callbacks/Exit";
import Step from "../attributes/callbacks/Step";
import While from "../attributes/guards/While";
import Until from "../attributes/guards/Until";
import GuardPath from "../attributes/guards/GuardPath";
import GuardUnsatisifedException from "../attributes/guards/GuardUnsatisifedException";
import { GuardAttributeDetails } from "../attributes/guards/Guard";
import { CallbackAttributeDetails } from "../attributes/callbacks/Callback";
import { createUid } from "../Utilities";
import { NodeSnapshot } from "../BehaviourTreeSnapshot";

/**
 * Details of a tree node instance.
 */
export type NodeDetails = {
    /**
     * The tree node identifier.
     */
    id: string;
    /**
     * The tree node type.
     */
    type: string;
    /**
     * The tree node name.
     */
    name: string;
    /**
     * The current state of the tree node.
     */
    state: AnyState;
    /**
     * The array of agent or globally registered function arguments, defined if this is an action or condition node.
     */
    args?: any[];
    /**
     * The 'while' guard attribute configured for this node.
     */
    while?: GuardAttributeDetails;
    /**
     * The 'until' guard attribute configured for this node.
     */
    until?: GuardAttributeDetails;
    /**
     * The 'entry' callback attribute configured for this node.
     */
    entry?: CallbackAttributeDetails;
    /**
     * The 'step' callback attribute configured for this node.
     */
    step?: CallbackAttributeDetails;
    /**
     * The 'exit' callback attribute configured for this node.
     */
    exit?: CallbackAttributeDetails;
    /**
     * The array of the child nodes of this node, defined if this node is a composite or decorator node.
     */
    children?: NodeDetails[];
};

/**
 * A mapping of attribute names to attributes configured for a node.
 */
type Attributes = {
    /**
     * The 'entry' callback attribute configured for this node.
     */
    entry?: Entry;
    /**
     * The 'step' callback attribute configured for this node.
     */
    step?: Step;
    /**
     * The 'exit' callback attribute configured for this node.
     */
    exit?: Exit;
    /**
     * The 'while' guard attribute configured for this node.
     */
    while?: While;
    /**
     * The 'until' guard attribute configured for this node.
     */
    until?: Until;
};

/**
 * A base node.
 */
export default abstract class Node {
    /**
     * The node unique identifier.
     */
    protected uid: string;
    /**
     * The node attributes.
     */
    protected readonly attributes: Attributes;
    /**
     * The node state.
     */
    private _state: AnyState = State.READY;
    /**
     * The guard path to evaluate as part of a node update.
     */
    private _guardPath: GuardPath | undefined;

    /**
     * @param type The node type.
     * @param attributes The node attributes.
     * @param options The behaviour tree options.
     */
    constructor(private type: string, attributes: Attribute[], protected options: BehaviourTreeOptions) {
        // Create a unique identifier for this node.
        this.uid = createUid();

        // Create our attribute mapping.
        this.attributes = {
            entry: attributes.find(({ type }) => type === "entry") as Entry,
            step: attributes.find(({ type }) => type === "step") as Step,
            exit: attributes.find(({ type }) => type === "exit") as Exit,
            while: attributes.find(({ type }) => type === "while") as While,
            until: attributes.find(({ type }) => type === "until") as Until
        };
    }

    /**
     * Called when the node is being updated.
     * @param agent The agent.
     */
    protected abstract onUpdate(agent: Agent): void;

    /**
     * Gets the name of the node.
     */
    public abstract getName(): string;

    /**
     * Gets/Sets the state of the node.
     */
    getState = (): AnyState => this._state;
    setState = (value: AnyState): void => {
        // Grab the original state of this node.
        const previousState = this._state;

        // Set the new node state.
        this._state = value;

        // If the state actually changed we should handle it.
        if (previousState !== value) {
            this.onStateChanged(previousState);
        }
    };

    /**
     * Gets the unique id of the node.
     */
    getUid = () => this.uid;

    /**
     * Gets the type of the node.
     */
    getType = () => this.type;

    /**
     * Gets the node attributes.
     */
    getAttributes = () => Object.values(this.attributes).filter((attribute) => !!attribute);

    /**
     * Sets the guard path to evaluate as part of a node update.
     */
    setGuardPath = (value: GuardPath) => (this._guardPath = value);

    /**
     * Gets whether a guard path is assigned to this node.
     */
    hasGuardPath = () => !!this._guardPath;

    /**
     * Gets whether this node is in the specified state.
     * @param value The value to compare to the node state.
     */
    public is(value: AnyState): boolean {
        return this._state === value;
    }

    /**
     * Reset the state of the node.
     */
    public reset(): void {
        this.setState(State.READY);
    }

    /**
     * Abort the running of this node.
     * @param agent The agent.
     */
    public abort(agent: Agent): void {
        // There is nothing to do if this node is not in the running state.
        if (!this.is(State.RUNNING)) {
            return;
        }

        // Reset the state of this node.
        this.reset();

        this.attributes.exit?.callAgentFunction(agent, false, true);
    }

    /**
     * Update the node.
     * @param agent The agent.
     * @returns The result of the update.
     */
    public update(agent: Agent): void {
        // If this node is already in a 'SUCCEEDED' or 'FAILED' state then there is nothing to do.
        if (this.is(State.SUCCEEDED) || this.is(State.FAILED)) {
            return;
        }

        try {
            // Evaluate all of the guard path conditions for the current tree path.
            this._guardPath!.evaluate(agent);

            // If this node is in the READY state then call the ENTRY for this node if it exists.
            if (this.is(State.READY)) {
                this.attributes.entry?.callAgentFunction(agent);
            }

            this.attributes.step?.callAgentFunction(agent);

            // Do the actual update.
            this.onUpdate(agent);

            // If this node is now in a 'SUCCEEDED' or 'FAILED' state then call the EXIT for this node if it exists.
            if (this.is(State.SUCCEEDED) || this.is(State.FAILED)) {
                this.attributes.exit?.callAgentFunction(agent, this.is(State.SUCCEEDED), false);
            }
        } catch (error) {
            // If the error is a GuardUnsatisfiedException then we need to determine if this node is the source.
            if (error instanceof GuardUnsatisifedException && error.isSourceNode(this)) {
                // Abort the current node.
                this.abort(agent);

                // Any node that is the source of an abort will move to a resolved state.
                this.setState(error.guard.succeedOnAbort ? State.SUCCEEDED : State.FAILED);
            } else {
                throw error;
            }
        }
    }

    /**
     * Gets the child nodes of this node, which is only ever more than an empty array for composite and decorator nodes.
     * @returns The child nodes of this node.
     */
    protected getChildNodes(): Node[] {
        return [];
    }

    /**
     * Gets the type-specific execution state of this node that is not covered by the node state alone, for inclusion in a snapshot.
     * @returns The type-specific properties of the snapshot of this node.
     */
    protected getSnapshotData(): Partial<NodeSnapshot> {
        return {};
    }

    /**
     * Gets the problem with the type-specific part of a snapshot of this node, if there is one.
     * @param snapshot The snapshot of this node, already known to have a matching type, name, state and child count.
     * @returns A description of the problem with the snapshot, or undefined if it is valid.
     */
    protected validateSnapshotData(snapshot: NodeSnapshot): string | undefined {
        return undefined;
    }

    /**
     * Restores the type-specific execution state of this node from a snapshot that has passed validation.
     * @param snapshot The snapshot of this node.
     */
    protected restoreSnapshotData(snapshot: NodeSnapshot): void {
        return;
    }

    /**
     * Gets a snapshot of the execution state of this node and all of its nested nodes.
     * @returns A snapshot of this node.
     */
    public getSnapshot(): NodeSnapshot {
        const children = this.getChildNodes();

        return {
            id: this.uid,
            type: this.type,
            name: this.getName(),
            state: this._state,
            ...this.getSnapshotData(),
            ...(children.length ? { children: children.map((child) => child.getSnapshot()) } : {})
        };
    }

    /**
     * Gets the problem that would prevent a snapshot from being restored to this node and all of its nested nodes, if there is one.
     * @param snapshot The snapshot to validate, which may be from any untrusted source.
     * @param path The path of this node, for use in descriptions of problems.
     * @returns A description of the problem with the snapshot, or undefined if it can be restored.
     */
    public validateSnapshot(snapshot: unknown, path: string): string | undefined {
        if (typeof snapshot !== "object" || snapshot === null || Array.isArray(snapshot)) {
            return `${path}: expected a node snapshot object`;
        }

        const { id, type, name, state, children } = snapshot as Partial<NodeSnapshot>;

        if (typeof id !== "string") {
            return `${path}: expected the node id to be a string`;
        }

        if (type !== this.type) {
            return `${path}: expected a snapshot of a '${this.type}' node but got '${type}'`;
        }

        if (name !== this.getName()) {
            return `${path}: expected a snapshot of the node named '${this.getName()}' but got '${name}'`;
        }

        if (!Object.values(State).includes(state as State)) {
            return `${path}: '${state}' is not a valid node state`;
        }

        if (children !== undefined && !Array.isArray(children)) {
            return `${path}: expected the child node snapshots to be an array`;
        }

        const childNodes = this.getChildNodes();

        if (childNodes.length !== (children ?? []).length) {
            return `${path}: expected ${childNodes.length} child node snapshots but got ${(children ?? []).length}`;
        }

        const dataProblem = this.validateSnapshotData(snapshot as NodeSnapshot);

        if (dataProblem) {
            return `${path}: ${dataProblem}`;
        }

        for (let index = 0; index < childNodes.length; index++) {
            const childProblem = childNodes[index].validateSnapshot(
                children![index],
                `${path}.children[${index}] (${childNodes[index].getType()})`
            );

            if (childProblem) {
                return childProblem;
            }
        }

        return undefined;
    }

    /**
     * Restores the execution state of this node and all of its nested nodes from a snapshot that has passed validation.
     * The node state change callback is not called, as this does not represent a change that happened to this tree.
     * @param snapshot The snapshot to restore.
     */
    public restoreSnapshot(snapshot: NodeSnapshot): void {
        this.uid = snapshot.id;
        this._state = snapshot.state;
        this.restoreSnapshotData(snapshot);
        this.getChildNodes().forEach((child, index) => child.restoreSnapshot(snapshot.children![index]));
    }

    /**
     * Gets the details of this node instance.
     * @returns The details of this node instance.
     */
    public getDetails(): NodeDetails {
        return {
            id: this.uid,
            name: this.getName(),
            type: this.type,
            while: this.attributes.while?.getDetails(),
            until: this.attributes.until?.getDetails(),
            entry: this.attributes.entry?.getDetails(),
            step: this.attributes.step?.getDetails(),
            exit: this.attributes.exit?.getDetails(),
            state: this._state
        };
    }

    /**
     * Called when the state of this node changes.
     * @param previousState The previous node state.
     */
    protected onStateChanged(previousState: State): void {
        // We should call the onNodeStateChange callback if it was defined.
        this.options.onNodeStateChange?.({
            id: this.uid,
            type: this.type,
            while: this.attributes.while?.getDetails(),
            until: this.attributes.until?.getDetails(),
            entry: this.attributes.entry?.getDetails(),
            step: this.attributes.step?.getDetails(),
            exit: this.attributes.exit?.getDetails(),
            previousState,
            state: this._state
        });
    }
}
