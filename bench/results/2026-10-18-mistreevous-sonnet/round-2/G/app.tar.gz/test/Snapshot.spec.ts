import { assert } from "chai";
import sinon, { SinonFakeTimers } from "sinon";

import { BehaviourTree, State, TreeSnapshot } from "../src/index";
import { RootNodeDefinition } from "../src/BehaviourTreeDefinition";

/**
 * The state of the outside world that the agent functions of a tree under test depend on.
 * This is not part of a tree snapshot, it belongs to the application, so it is copied alongside each snapshot.
 */
type World = {
    log: string[];
    results: { [name: string]: State | undefined };
    flags: { [name: string]: boolean };
    delta: number;
    randomIndex: number;
};

/**
 * A step of a scenario, applied to the world before the tree is stepped.
 */
type Step = {
    results?: World["results"];
    flags?: World["flags"];
    /** The number of milliseconds that pass before the tree is stepped. */
    advance?: number;
};

type Scenario = {
    name: string;
    definition: string;
    timing?: "date" | "delta";
    steps: Step[];
};

const RANDOM_VALUES = [0.9, 0.1, 0.5, 0.3, 0.7];

/**
 * The amount of time that passes between taking a snapshot and restoring it, which must never be visible to the tree.
 */
const TIME_BETWEEN_SNAPSHOT_AND_RESTORE = 3 * 24 * 60 * 60 * 1000;

const createWorld = (): World => ({ log: [], results: {}, flags: {}, delta: 0, randomIndex: 0 });

const createTree = (
    definition: string | RootNodeDefinition | RootNodeDefinition[],
    world: World,
    timing: "date" | "delta" = "date",
    onNodeStateChange?: () => void
) => {
    const agent = {
        Act: (name: string) => {
            world.log.push(`act ${name}`);
            return world.results[name] as any;
        },
        Check: (name: string) => {
            world.log.push(`check ${name}`);
            return !!world.flags[name];
        },
        Enter: (name: string) => void world.log.push(`enter ${name}`),
        Step: (name: string) => void world.log.push(`step ${name}`),
        Exit: (name: string) => void world.log.push(`exit ${name}`)
    };

    // MDSL strings must be double quoted, but single quotes are much easier to read in the definitions below.
    return new BehaviourTree(typeof definition === "string" ? definition.replace(/'/g, '"') : definition, agent, {
        random: () => RANDOM_VALUES[world.randomIndex++ % RANDOM_VALUES.length],
        getDeltaTime: timing === "delta" ? () => world.delta : undefined,
        onNodeStateChange
    });
};

const applyStep = (tree: BehaviourTree, world: World, clock: SinonFakeTimers, step: Step) => {
    world.log = [];
    world.delta = (step.advance ?? 0) / 1000;
    clock.tick(step.advance ?? 0);
    Object.assign(world.results, step.results);
    Object.assign(world.flags, step.flags);
    tree.step();
};

/**
 * Runs the scenario to completion on a reference tree, taking a snapshot before the first step and after each step.
 * Every one of those snapshots is then restored into a brand new tree (after a long time has passed), and the remaining
 * steps are replayed on it. The restored tree must call the same agent functions in the same order and have the same
 * node states as the reference tree did at every point.
 */
const assertSnapshotsRestoreEquivalently = (scenario: Scenario, clock: SinonFakeTimers) => {
    const timing = scenario.timing ?? "date";
    const world = createWorld();
    const tree = createTree(scenario.definition, world, timing);

    const checkpoints: { snapshot: string; world: string; time: number }[] = [];
    const trace: { log: string[]; details: unknown; state: State }[] = [];

    const takeCheckpoint = () =>
        checkpoints.push({
            snapshot: JSON.stringify(tree.snapshot()),
            world: JSON.stringify(world),
            time: clock.now
        });

    takeCheckpoint();
    const initialDetails = tree.getTreeNodeDetails();

    for (const step of scenario.steps) {
        applyStep(tree, world, clock, step);
        trace.push({ log: world.log, details: tree.getTreeNodeDetails(), state: tree.getState() });
        takeCheckpoint();
    }

    for (let k = 0; k <= scenario.steps.length; k++) {
        clock.setSystemTime(checkpoints[k].time + TIME_BETWEEN_SNAPSHOT_AND_RESTORE);

        const restoredWorld: World = JSON.parse(checkpoints[k].world);
        const restoredTree = createTree(scenario.definition, restoredWorld, timing);
        restoredTree.restore(JSON.parse(checkpoints[k].snapshot));

        assert.deepEqual(
            restoredTree.getTreeNodeDetails(),
            k === 0 ? initialDetails : trace[k - 1].details,
            `node details after restoring the snapshot taken after step ${k}`
        );

        for (let i = k; i < scenario.steps.length; i++) {
            applyStep(restoredTree, restoredWorld, clock, scenario.steps[i]);

            const context = `step ${i + 1} after restoring the snapshot taken after step ${k}`;
            assert.deepEqual(restoredWorld.log, trace[i].log, `agent function calls for ${context}`);
            assert.deepEqual(restoredTree.getTreeNodeDetails(), trace[i].details, `node details for ${context}`);
            assert.equal(restoredTree.getState(), trace[i].state, `tree state for ${context}`);
        }
    }
};

describe("A behaviour tree snapshot", () => {
    let clock: SinonFakeTimers;

    beforeEach(() => {
        clock = sinon.useFakeTimers({ now: 1_700_000_000_000 });
    });

    afterEach(() => {
        clock.restore();
    });

    describe("is a plain object that", () => {
        it("survives being serialised to JSON and parsed again unchanged", () => {
            const world = createWorld();
            const tree = createTree("root { sequence { action [Act, 'a'] condition [Check, 'x'] wait [100] } }", world);

            for (const stepResult of [undefined, State.SUCCEEDED]) {
                world.results.a = stepResult;
                tree.step();

                const snapshot = tree.snapshot();

                assert.deepEqual(JSON.parse(JSON.stringify(snapshot)), snapshot);
            }
        });

        it("is not affected by later steps of the tree", () => {
            const world = createWorld();
            const tree = createTree("root { sequence { action [Act, 'a'] action [Act, 'b'] } }", world);

            tree.step();
            const snapshot = tree.snapshot();
            const serialised = JSON.stringify(snapshot);

            world.results.a = State.SUCCEEDED;
            tree.step();
            tree.step();

            assert.equal(JSON.stringify(snapshot), serialised);
        });

        it("is not changed by being restored", () => {
            const world = createWorld();
            const tree = createTree("root { sequence { action [Act, 'a'] action [Act, 'b'] } }", world);
            world.results.a = State.SUCCEEDED;
            tree.step();

            const snapshot = tree.snapshot();
            const serialised = JSON.stringify(snapshot);

            const restoredTree = createTree("root { sequence { action [Act, 'a'] action [Act, 'b'] } }", world);
            restoredTree.restore(snapshot);
            restoredTree.step();

            assert.equal(JSON.stringify(snapshot), serialised);
        });
    });

    describe("when restored", () => {
        const definition = "root { sequence { action [Act, 'a'] action [Act, 'b'] } }";

        it("gives the tree the state of the tree the snapshot was taken from, including the node ids", () => {
            const world = createWorld();
            const tree = createTree(definition, world);
            world.results.a = State.SUCCEEDED;
            tree.step();

            const restoredTree = createTree(definition, createWorld());
            restoredTree.restore(tree.snapshot());

            assert.deepEqual(restoredTree.getTreeNodeDetails(), tree.getTreeNodeDetails());
            assert.equal(restoredTree.getState(), State.RUNNING);
            assert.isTrue(restoredTree.isRunning());
        });

        it("replaces the state of a tree that has already been stepped", () => {
            const world = createWorld();
            const tree = createTree(definition, world);
            tree.step();
            const snapshot = tree.snapshot();

            world.results.a = State.SUCCEEDED;
            tree.step();
            tree.restore(snapshot);

            assert.deepEqual(tree.snapshot(), snapshot);

            world.log = [];
            tree.step();

            // The first node was still running at the time of the snapshot, the second was not yet reached.
            assert.deepEqual(world.log, ["act a", "act b"]);
        });

        it("does not call any agent functions", () => {
            const world = createWorld();
            const tree = createTree(definition, world);
            world.results.a = State.SUCCEEDED;
            tree.step();

            const restoredWorld = createWorld();
            createTree(definition, restoredWorld).restore(tree.snapshot());

            assert.deepEqual(restoredWorld.log, []);
        });

        it("does not call the onNodeStateChange option", () => {
            const world = createWorld();
            const tree = createTree(definition, world);
            world.results.a = State.SUCCEEDED;
            tree.step();

            const onNodeStateChange = sinon.spy();
            createTree(definition, createWorld(), "date", onNodeStateChange).restore(tree.snapshot());

            assert.isFalse(onNodeStateChange.called);
        });

        describe("calls the onNodeStateChange option for no node, and the next step reports changes as usual, when the tree it is restored to is", () => {
            const wideDefinition = `root { sequence {
                repeat [3] { retry [2] { sequence { action [Act, 'a'] condition [Check, 'x'] } } }
                lotto { action [Act, 'b'] action [Act, 'c'] }
                flip { succeed { fail { action [Act, 'd'] } } }
                parallel { action [Act, 'e'] race { action [Act, 'f'] all { action [Act, 'g'] } } }
                selector { action [Act, 'h'] wait [100] }
            } }`;

            const progress: Step[] = [
                {},
                { results: { a: State.SUCCEEDED }, flags: { x: true } },
                { results: { a: State.SUCCEEDED } },
                { results: { a: State.SUCCEEDED, b: State.RUNNING, c: State.RUNNING } }
            ];

            const trees = {
                "a new tree": [],
                "a tree that has been stepped to a different state": [{ results: { a: State.FAILED } }, {}],
                "a tree that has finished": [{ results: { a: State.FAILED } }, { results: { a: State.FAILED } }]
            };

            for (const [name, beforeRestore] of Object.entries(trees)) {
                it(name, () => {
                    const world = createWorld();
                    const reportedByOriginal: unknown[] = [];
                    const original = createTree(wideDefinition, world, "date", (...args) => {
                        reportedByOriginal.push(args);
                    });

                    for (const step of progress) {
                        applyStep(original, world, clock, step);
                    }

                    const snapshot = JSON.parse(JSON.stringify(original.snapshot()));

                    const restoredWorld = createWorld();
                    const reportedByRestored: unknown[] = [];
                    const restored = createTree(wideDefinition, restoredWorld, "date", (...args) => {
                        reportedByRestored.push(args);
                    });

                    for (const step of beforeRestore as Step[]) {
                        applyStep(restored, restoredWorld, clock, step);
                    }

                    // The agent state belongs to the application, so it is restored separately.
                    Object.assign(restoredWorld, JSON.parse(JSON.stringify(world)));
                    reportedByOriginal.length = 0;
                    reportedByRestored.length = 0;

                    restored.restore(snapshot);

                    assert.deepEqual(reportedByRestored, []);

                    const next: Step = { results: { a: State.SUCCEEDED, b: State.SUCCEEDED, e: State.RUNNING } };
                    applyStep(original, world, clock, next);
                    applyStep(restored, restoredWorld, clock, next);

                    assert.isAbove(reportedByOriginal.length, 0);
                    assert.deepEqual(reportedByRestored, reportedByOriginal);
                });
            }
        });
    });

    describe("is independent of the trees it is used with, so", () => {
        // A tree with every kind of node that has execution state of its own.
        const definition = `root { sequence {
            repeat [3] { retry [2] { sequence { action [Act, 'a'] condition [Check, 'x'] } } }
            lotto [1, 5, 3] { action [Act, 'b'] action [Act, 'c'] action [Act, 'd'] }
            wait [100]
            parallel { action [Act, 'e'] action [Act, 'f'] }
            flip { action [Act, 'g'] }
        } }`;

        const steps: Step[] = [
            {},
            { results: { a: State.RUNNING }, flags: { x: true } },
            { results: { a: State.SUCCEEDED } },
            { results: { a: State.FAILED } },
            { results: { a: State.SUCCEEDED } },
            { results: { a: State.SUCCEEDED } },
            { results: { b: State.RUNNING, c: State.RUNNING, d: State.RUNNING } },
            { results: { b: State.SUCCEEDED, c: State.SUCCEEDED, d: State.SUCCEEDED }, advance: 40 },
            { advance: 100 },
            { results: { e: State.RUNNING, f: State.SUCCEEDED } },
            { results: { e: State.FAILED, g: State.RUNNING } },
            { results: { e: State.SUCCEEDED, g: State.SUCCEEDED } },
            {}
        ];

        const toPlainSnapshot = (tree: BehaviourTree) => JSON.parse(JSON.stringify(tree.snapshot())) as TreeSnapshot;

        it("stepping the tree does not change a snapshot taken from it", () => {
            for (let k = 0; k <= steps.length; k++) {
                const world = createWorld();
                const tree = createTree(definition, world);

                for (const step of steps.slice(0, k)) {
                    applyStep(tree, world, clock, step);
                }

                const snapshot = tree.snapshot();
                const serialised = JSON.stringify(snapshot);

                for (const [i, step] of steps.slice(k).entries()) {
                    applyStep(tree, world, clock, step);
                    assert.equal(JSON.stringify(snapshot), serialised, `snapshot ${k} after ${i + 1} more steps`);
                }
            }
        });

        it("stepping a tree that a snapshot was restored to does not change the snapshot", () => {
            const world = createWorld();
            const tree = createTree(definition, world);

            for (const [k, step] of steps.entries()) {
                applyStep(tree, world, clock, step);

                const snapshot = toPlainSnapshot(tree);
                const serialised = JSON.stringify(snapshot);

                const restoredWorld: World = JSON.parse(JSON.stringify(world));
                const restoredTree = createTree(definition, restoredWorld);
                restoredTree.restore(snapshot);

                for (const [i, nextStep] of steps.slice(k + 1).entries()) {
                    applyStep(restoredTree, restoredWorld, clock, nextStep);
                    assert.equal(JSON.stringify(snapshot), serialised, `snapshot ${k} after ${i + 1} more steps`);
                }
            }
        });

        it("a snapshot taken after restoring a snapshot and before the next step equals it, however much time has passed", () => {
            const world = createWorld();
            const tree = createTree("root { sequence { action [Act, 'a'] wait [100] } }", world);
            world.results.a = State.SUCCEEDED;
            applyStep(tree, world, clock, {});
            applyStep(tree, world, clock, { advance: 30 });

            const snapshot = toPlainSnapshot(tree);
            const restoredTree = createTree("root { sequence { action [Act, 'a'] wait [100] } }", createWorld());
            restoredTree.restore(snapshot);

            clock.tick(20);

            assert.deepEqual(toPlainSnapshot(restoredTree), snapshot);
        });

        it("a snapshot taken straight after restoring a snapshot equals it", () => {
            const world = createWorld();
            const tree = createTree(definition, world);

            for (const step of steps) {
                applyStep(tree, world, clock, step);

                const snapshot = toPlainSnapshot(tree);
                const restoredTree = createTree(definition, createWorld());
                restoredTree.restore(snapshot);

                assert.deepEqual(toPlainSnapshot(restoredTree), snapshot);
            }
        });

        describe("a snapshot taken straight after restoring a snapshot equals it, for an action whose promise is", () => {
            const outcomes = {
                "still pending": () => new Promise<State>(() => undefined),
                "resolved with a finished state": () => Promise.resolve(State.SUCCEEDED),
                "resolved with an invalid value": () => Promise.resolve("nonsense" as unknown as State),
                rejected: () => Promise.reject(new Error("failed"))
            };

            for (const [name, Act] of Object.entries(outcomes)) {
                it(name, async () => {
                    const tree = new BehaviourTree("root { action [Act] }", { Act });
                    tree.step();
                    await clock.tickAsync(0);

                    const snapshot = toPlainSnapshot(tree);
                    const restoredTree = new BehaviourTree("root { action [Act] }", { Act });
                    restoredTree.restore(snapshot);

                    assert.deepEqual(toPlainSnapshot(restoredTree), snapshot);
                });
            }
        });
    });

    describe("restores a tree that then behaves exactly as the original tree would have, with", () => {
        const scenarios: Scenario[] = [
            {
                name: "a sequence node",
                definition: "root { sequence { action [Act, 'a'] action [Act, 'b'] action [Act, 'c'] } }",
                steps: [
                    {},
                    { results: { a: State.SUCCEEDED } },
                    {},
                    { results: { b: State.SUCCEEDED } },
                    { results: { c: State.SUCCEEDED } },
                    {},
                    { results: { b: State.FAILED } },
                    {}
                ]
            },
            {
                name: "a selector node",
                definition:
                    "root { selector { sequence { condition [Check, 'x'] action [Act, 'a'] } action [Act, 'b'] action [Act, 'c'] } }",
                steps: [
                    {},
                    { flags: { x: true } },
                    { results: { b: State.FAILED } },
                    { results: { c: State.FAILED } },
                    { results: { c: State.SUCCEEDED } },
                    { results: { a: State.SUCCEEDED } }
                ]
            },
            {
                name: "a parallel node",
                definition: "root { parallel { action [Act, 'a'] action [Act, 'b'] action [Act, 'c'] } }",
                steps: [
                    {},
                    { results: { a: State.SUCCEEDED } },
                    { results: { b: State.SUCCEEDED } },
                    { results: { c: State.FAILED } },
                    { results: { c: State.SUCCEEDED } },
                    { results: { a: State.RUNNING, b: State.RUNNING, c: State.RUNNING } },
                    { results: { a: State.SUCCEEDED, b: State.SUCCEEDED, c: State.SUCCEEDED } }
                ]
            },
            {
                name: "a race node",
                definition: "root { race { action [Act, 'a'] action [Act, 'b'] action [Act, 'c'] } }",
                steps: [
                    {},
                    { results: { a: State.FAILED } },
                    { results: { b: State.FAILED } },
                    { results: { c: State.SUCCEEDED } },
                    { results: { a: State.FAILED, b: State.FAILED, c: State.FAILED } }
                ]
            },
            {
                name: "an all node",
                definition: "root { all { action [Act, 'a'] action [Act, 'b'] action [Act, 'c'] } }",
                steps: [
                    {},
                    { results: { a: State.FAILED } },
                    { results: { b: State.SUCCEEDED } },
                    { results: { c: State.FAILED } },
                    { results: { a: State.FAILED, b: State.FAILED, c: State.FAILED } }
                ]
            },
            {
                name: "flip, succeed and fail nodes",
                definition:
                    "root { sequence { flip { action [Act, 'a'] } succeed { action [Act, 'b'] } fail { action [Act, 'c'] } } }",
                steps: [
                    {},
                    { results: { a: State.FAILED } },
                    { results: { b: State.FAILED } },
                    { results: { c: State.SUCCEEDED } },
                    { results: { a: State.SUCCEEDED } }
                ]
            },
            {
                name: "nested subtrees referenced by branch nodes",
                definition:
                    "root { sequence { branch [work] branch [work] } } root [work] { sequence { action [Act, 'a'] action [Act, 'b'] } }",
                steps: [
                    {},
                    { results: { a: State.SUCCEEDED } },
                    { results: { b: State.SUCCEEDED } },
                    { results: { b: State.RUNNING } },
                    { results: { b: State.SUCCEEDED } }
                ]
            },
            {
                name: "entry, step and exit callbacks and guards, which must not be called again for nodes already running",
                definition: [
                    "root {",
                    "  sequence entry(Enter, 'seq') step(Step, 'seq') exit(Exit, 'seq') {",
                    "    action [Act, 'a'] while(Check, 'go') entry(Enter, 'a') exit(Exit, 'a')",
                    "    action [Act, 'b'] until(Check, 'stop') entry(Enter, 'b') exit(Exit, 'b')",
                    "  }",
                    "}"
                ].join("\n"),
                steps: [
                    { flags: { go: true } },
                    {},
                    { results: { a: State.SUCCEEDED } },
                    {},
                    { flags: { stop: true } },
                    { flags: { stop: false } },
                    { results: { b: State.SUCCEEDED } },
                    { flags: { go: false } },
                    { flags: { go: true } }
                ]
            },
            {
                name: "a repeat node with a fixed number of iterations",
                definition: "root { repeat [3] { action [Act, 'a'] } }",
                steps: [
                    {},
                    { results: { a: State.SUCCEEDED } },
                    { results: { a: State.RUNNING } },
                    { results: { a: State.SUCCEEDED } },
                    {},
                    {},
                    {},
                    {},
                    {}
                ]
            },
            {
                name: "a repeat node with a random number of iterations, which must not be picked again",
                definition: "root { repeat [2, 5] { action [Act, 'a'] } }",
                steps: [
                    { results: { a: State.SUCCEEDED } },
                    {},
                    {},
                    { results: { a: State.RUNNING } },
                    { results: { a: State.SUCCEEDED } },
                    {},
                    {},
                    {},
                    {},
                    {},
                    {},
                    {}
                ]
            },
            {
                name: "a repeat node that never stops until its child fails",
                definition: "root { repeat { action [Act, 'a'] } }",
                steps: [
                    { results: { a: State.SUCCEEDED } },
                    {},
                    {},
                    { results: { a: State.FAILED } },
                    { results: { a: State.SUCCEEDED } },
                    {}
                ]
            },
            {
                name: "nested repeat nodes",
                definition: "root { repeat [2] { sequence { repeat [2] { action [Act, 'a'] } action [Act, 'b'] } } }",
                steps: [
                    { results: { a: State.SUCCEEDED } },
                    {},
                    {},
                    { results: { b: State.SUCCEEDED } },
                    {},
                    {},
                    {},
                    {},
                    {},
                    {}
                ]
            },
            {
                name: "a retry node with a fixed number of attempts",
                definition: "root { retry [3] { action [Act, 'a'] } }",
                steps: [
                    {},
                    { results: { a: State.FAILED } },
                    { results: { a: State.RUNNING } },
                    { results: { a: State.FAILED } },
                    {},
                    {},
                    {},
                    { results: { a: State.SUCCEEDED } },
                    {}
                ]
            },
            {
                name: "a retry node with a random number of attempts, which must not be picked again",
                definition: "root { retry [2, 5] { action [Act, 'a'] } }",
                steps: [
                    { results: { a: State.FAILED } },
                    {},
                    {},
                    { results: { a: State.RUNNING } },
                    { results: { a: State.FAILED } },
                    {},
                    {},
                    {},
                    {},
                    {},
                    {},
                    {}
                ]
            },
            {
                name: "a retry node that never stops until its child succeeds",
                definition: "root { retry { action [Act, 'a'] } }",
                steps: [
                    { results: { a: State.FAILED } },
                    {},
                    {},
                    { results: { a: State.SUCCEEDED } },
                    { results: { a: State.FAILED } },
                    {}
                ]
            },
            {
                name: "a lotto node, which must not pick its winning child again",
                definition: "root { lotto [1, 5, 3] { action [Act, 'a'] action [Act, 'b'] action [Act, 'c'] } }",
                steps: [
                    {},
                    {},
                    { results: { a: State.RUNNING, b: State.RUNNING, c: State.RUNNING } },
                    { results: { a: State.SUCCEEDED, b: State.SUCCEEDED, c: State.SUCCEEDED } },
                    { results: { a: State.RUNNING, b: State.RUNNING, c: State.RUNNING } },
                    {},
                    { results: { a: State.FAILED, b: State.FAILED, c: State.FAILED } },
                    { results: { a: State.RUNNING, b: State.RUNNING, c: State.RUNNING } },
                    { results: { a: State.SUCCEEDED, b: State.SUCCEEDED, c: State.SUCCEEDED } },
                    {}
                ]
            },
            {
                name: "a lotto node without weights",
                definition: "root { lotto { action [Act, 'a'] action [Act, 'b'] } }",
                steps: [
                    {},
                    { results: { a: State.SUCCEEDED, b: State.SUCCEEDED } },
                    { results: { a: State.RUNNING, b: State.RUNNING } },
                    { results: { a: State.FAILED, b: State.FAILED } },
                    { results: { a: State.RUNNING, b: State.RUNNING } },
                    {}
                ]
            }
        ];

        for (const scenario of scenarios) {
            it(scenario.name, () => {
                assertSnapshotsRestoreEquivalently(scenario, clock);
            });
        }
    });

    describe("restores a tree with wait nodes that then behaves exactly as the original tree would have, when timing is based on", () => {
        const waitScenarios: Omit<Scenario, "timing">[] = [
            {
                name: "a wait node with an explicit duration",
                definition: "root { sequence { action [Act, 'a'] wait [1000] action [Act, 'b'] } }",
                steps: [
                    { results: { a: State.SUCCEEDED } },
                    { advance: 400 },
                    { advance: 400 },
                    { advance: 300 },
                    { results: { b: State.SUCCEEDED } },
                    { advance: 100 },
                    { advance: 500 },
                    { advance: 500 },
                    { advance: 500 }
                ]
            },
            {
                name: "a wait node with a random duration, which must not be picked again",
                definition: "root { sequence { wait [500, 2000] action [Act, 'a'] } }",
                steps: [
                    {},
                    { advance: 300 },
                    { advance: 300 },
                    { advance: 300, results: { a: State.SUCCEEDED } },
                    { advance: 300 },
                    { advance: 300 },
                    { advance: 300 },
                    { advance: 300 },
                    { advance: 300 },
                    { advance: 300 },
                    { advance: 300 }
                ]
            },
            {
                name: "a wait node with no duration, which waits indefinitely",
                definition: "root { sequence { wait action [Act, 'a'] } }",
                steps: [{}, { advance: 5000 }, { advance: 5000 }]
            },
            {
                name: "a wait node that is aborted before it finishes waiting",
                definition: "root { race { wait [1000] action [Act, 'a'] } }",
                steps: [
                    {},
                    { advance: 400 },
                    { advance: 400, results: { a: State.SUCCEEDED } },
                    { advance: 400 },
                    { advance: 700 },
                    { advance: 700 }
                ]
            }
        ];

        for (const timing of ["date", "delta"] as const) {
            describe(timing === "date" ? "the clock" : "the getDeltaTime option", () => {
                for (const scenario of waitScenarios) {
                    it(scenario.name, () => {
                        assertSnapshotsRestoreEquivalently({ ...scenario, timing }, clock);
                    });
                }

                it("only waits for the remaining time, not counting any time that passes between the snapshot and restore", () => {
                    const definition = "root { wait [1000] }";
                    const world = createWorld();
                    const tree = createTree(definition, world, timing);

                    applyStep(tree, world, clock, {});
                    applyStep(tree, world, clock, { advance: 400 });
                    const snapshot = JSON.parse(JSON.stringify(tree.snapshot()));

                    clock.tick(TIME_BETWEEN_SNAPSHOT_AND_RESTORE);

                    const restoredWorld = createWorld();
                    const restoredTree = createTree(definition, restoredWorld, timing);
                    restoredTree.restore(snapshot);

                    applyStep(restoredTree, restoredWorld, clock, {});
                    assert.equal(restoredTree.getState(), State.RUNNING);

                    applyStep(restoredTree, restoredWorld, clock, { advance: 599 });
                    assert.equal(restoredTree.getState(), State.RUNNING);

                    applyStep(restoredTree, restoredWorld, clock, { advance: 1 });
                    assert.equal(restoredTree.getState(), State.SUCCEEDED);
                });
            });
        }

        it("survives JSON for a wait node that has waited for an infinite time", () => {
            const world = createWorld();
            const tree = createTree("root { wait [1000] }", world, "delta");
            world.delta = Infinity;
            tree.step();
            assert.equal(tree.getState(), State.SUCCEEDED);

            const snapshot = JSON.parse(JSON.stringify(tree.snapshot()));
            assert.deepEqual(snapshot, JSON.parse(JSON.stringify(snapshot)));

            const restoredTree = createTree("root { wait [1000] }", createWorld(), "delta");
            restoredTree.restore(snapshot);
            assert.equal(restoredTree.getState(), State.SUCCEEDED);
        });

        it("counts the time that passed up to the snapshot, even if the tree was not stepped in that time, when timing is based on the clock", () => {
            const definition = "root { wait [1000] }";
            const world = createWorld();
            const tree = createTree(definition, world);

            applyStep(tree, world, clock, {});
            clock.tick(600);
            const snapshot = JSON.parse(JSON.stringify(tree.snapshot()));

            clock.tick(TIME_BETWEEN_SNAPSHOT_AND_RESTORE);

            const restoredWorld = createWorld();
            const restoredTree = createTree(definition, restoredWorld);
            restoredTree.restore(snapshot);

            applyStep(restoredTree, restoredWorld, clock, { advance: 399 });
            assert.equal(restoredTree.getState(), State.RUNNING);

            applyStep(restoredTree, restoredWorld, clock, { advance: 1 });
            assert.equal(restoredTree.getState(), State.SUCCEEDED);
        });
    });

    describe("restores a tree with a promise-based action node", () => {
        const definition = "root { sequence { action [Work] action [Finish] } }";

        const createAsyncTree = (work: () => Promise<State.SUCCEEDED | State.FAILED>) => {
            const calls: string[] = [];
            const agent = {
                Work: () => {
                    calls.push("work");
                    return work();
                },
                Finish: () => {
                    calls.push("finish");
                    return State.SUCCEEDED;
                }
            };

            return { calls, tree: new BehaviourTree(definition, agent) };
        };

        const settle = async () => {
            await Promise.resolve();
            await Promise.resolve();
        };

        it("that has already resolved, which then moves to the resolved state without calling the action again", async () => {
            const original = createAsyncTree(() => Promise.resolve(State.FAILED));
            original.tree.step();
            await settle();

            const restored = createAsyncTree(() => Promise.reject(new Error("must not be called")));
            restored.tree.restore(JSON.parse(JSON.stringify(original.tree.snapshot())));

            restored.tree.step();

            assert.deepEqual(restored.calls, []);
            assert.equal(restored.tree.getState(), State.FAILED);
        });

        it("that has already rejected, which then fails to step in the same way as the original tree", async () => {
            const original = createAsyncTree(() => Promise.reject(new Error("boom")));
            original.tree.step();
            await settle();

            const restored = createAsyncTree(() => Promise.resolve(State.SUCCEEDED));
            restored.tree.restore(JSON.parse(JSON.stringify(original.tree.snapshot())));

            let originalError: Error | undefined;
            try {
                original.tree.step();
            } catch (error) {
                originalError = error as Error;
            }

            assert.isDefined(originalError);
            assert.throws(() => restored.tree.step(), Error, originalError!.message);
            assert.deepEqual(restored.calls, []);
        });

        it("that has resolved with an invalid value, which then fails to step in the same way as the original tree", async () => {
            const original = createAsyncTree(() => Promise.resolve("nonsense" as any));
            original.tree.step();
            await settle();

            const restored = createAsyncTree(() => Promise.resolve(State.SUCCEEDED));
            restored.tree.restore(JSON.parse(JSON.stringify(original.tree.snapshot())));

            assert.throws(
                () => original.tree.step(),
                Error,
                "action node promise resolved with an invalid value, expected a State.SUCCEEDED or State.FAILED value to be returned"
            );
            assert.throws(
                () => restored.tree.step(),
                Error,
                "action node promise resolved with an invalid value, expected a State.SUCCEEDED or State.FAILED value to be returned"
            );
        });

        // The first action of the sequence under the root node.
        const workNodeState = (tree: BehaviourTree) => tree.getTreeNodeDetails().children![0].children![0].state;

        it("that is still pending, which is restored as not yet started and is called again on the next step", async () => {
            const original = createAsyncTree(() => new Promise(() => undefined));
            original.tree.step();
            await settle();

            const snapshot = JSON.parse(JSON.stringify(original.tree.snapshot()));

            const restored = createAsyncTree(() => Promise.resolve(State.SUCCEEDED));
            restored.tree.restore(snapshot);
            assert.equal(restored.tree.getState(), State.RUNNING);
            assert.equal(workNodeState(restored.tree), State.READY);
            assert.deepEqual(restored.calls, []);

            restored.tree.step();
            assert.deepEqual(restored.calls, ["work"]);
            assert.equal(restored.tree.getState(), State.RUNNING);
            assert.equal(workNodeState(restored.tree), State.RUNNING);

            await settle();
            restored.tree.step();
            assert.deepEqual(restored.calls, ["work", "finish"]);
            assert.equal(restored.tree.getState(), State.SUCCEEDED);
        });

        it("that is still pending, without changing the tree that the snapshot was taken from", async () => {
            const original = createAsyncTree(() => Promise.resolve(State.SUCCEEDED));
            original.tree.step();

            original.tree.snapshot();
            assert.equal(workNodeState(original.tree), State.RUNNING);

            await settle();
            original.tree.step();

            // The promise resolved after the snapshot was taken, so the original tree carries on without calling it again.
            assert.deepEqual(original.calls, ["work", "finish"]);
            assert.equal(original.tree.getState(), State.SUCCEEDED);
        });

        it("that is still pending, which calls its entry callback again as it has not yet started", async () => {
            const entries: string[] = [];
            const createEntryTree = () =>
                new BehaviourTree("root { action [Work] entry(Entered) }", {
                    Entered: () => void entries.push("entered"),
                    Work: () => new Promise<State.SUCCEEDED>(() => undefined)
                });

            const original = createEntryTree();
            original.step();
            await settle();

            const restored = createEntryTree();
            restored.restore(JSON.parse(JSON.stringify(original.snapshot())));
            assert.deepEqual(entries, ["entered"]);

            restored.step();
            assert.deepEqual(entries, ["entered", "entered"]);
        });

        it("that is not using a promise, which stays in the running state", () => {
            const createRunningTree = () => new BehaviourTree("root { action [Work] }", { Work: () => undefined });

            const original = createRunningTree();
            original.step();

            const restored = createRunningTree();
            restored.restore(JSON.parse(JSON.stringify(original.snapshot())));

            assert.equal(restored.getTreeNodeDetails().children![0].state, State.RUNNING);
        });
    });

    describe("of a finished tree", () => {
        for (const finalState of [State.SUCCEEDED, State.FAILED]) {
            it(`restores as finished, and the next step starts a new run that makes its random choices again (${finalState})`, () => {
                const definition = "root { repeat [2, 5] { action [Act, 'a'] } }";
                const world = createWorld();
                const tree = createTree(definition, world);

                // The first random choice is for five iterations. The run succeeds once they have been made, or fails
                // as soon as the child fails.
                if (finalState === State.SUCCEEDED) {
                    world.results.a = State.SUCCEEDED;
                    for (let step = 0; step < 6; step++) {
                        tree.step();
                    }
                } else {
                    world.results.a = State.SUCCEEDED;
                    tree.step();
                    tree.step();
                    world.results.a = State.FAILED;
                    tree.step();
                }
                assert.equal(tree.getState(), finalState);

                const snapshot = JSON.parse(JSON.stringify(tree.snapshot()));
                const restoredWorld: World = JSON.parse(JSON.stringify(world));
                const restoredTree = createTree(definition, restoredWorld);
                restoredTree.restore(snapshot);

                assert.equal(restoredTree.getState(), finalState);
                assert.isFalse(restoredTree.isRunning());
                assert.deepEqual(restoredTree.getTreeNodeDetails(), tree.getTreeNodeDetails());
                assert.deepEqual(restoredWorld.log, world.log);

                const randomIndexBeforeNextRun = restoredWorld.randomIndex;
                restoredWorld.results.a = State.SUCCEEDED;

                // The next random choice is for two iterations rather than the five that the finished run had picked.
                let steps = 0;
                do {
                    restoredTree.step();
                    steps++;
                } while (restoredTree.isRunning());

                assert.equal(restoredWorld.randomIndex, randomIndexBeforeNextRun + 1);
                assert.equal(steps, 3);
                assert.equal(restoredTree.getState(), State.SUCCEEDED);
            });
        }
    });

    describe("cannot be restored if", () => {
        const definition = [
            "root {",
            "  parallel {",
            "    lotto { action [Act, 'a'] action [Act, 'b'] }",
            "    repeat [2] { retry [2] { wait [100] } }",
            "    action [Act, 'c']",
            "  }",
            "}"
        ].join("\n");

        const createSteppedTree = () => {
            const tree = createTree(definition, createWorld());
            tree.step();
            return tree;
        };

        // The nodes that are of interest in the snapshot of the tree above, by their child indices from the root node.
        const parallel = (snapshot: TreeSnapshot) => snapshot.root.children![0];
        const lotto = (snapshot: TreeSnapshot) => parallel(snapshot).children![0];
        const repeat = (snapshot: TreeSnapshot) => parallel(snapshot).children![1];
        const retry = (snapshot: TreeSnapshot) => repeat(snapshot).children![0];
        const wait = (snapshot: TreeSnapshot) => retry(snapshot).children![0];
        const action = (snapshot: TreeSnapshot) => parallel(snapshot).children![2];

        const invalidSnapshots: [string, (snapshot: TreeSnapshot) => unknown, string][] = [
            ["it is null", () => null, "error restoring snapshot: expected a snapshot object"],
            ["it is not an object", () => "snapshot", "error restoring snapshot: expected a snapshot object"],
            [
                "it has an unknown version",
                (snapshot) => ({ ...snapshot, version: 2 }),
                "error restoring snapshot: expected snapshot version 1 but got '2'"
            ],
            [
                "it has no root node",
                (snapshot) => ({ version: snapshot.version, definition: snapshot.definition }),
                "error restoring snapshot: root: expected a node snapshot object"
            ],
            [
                "a node snapshot has the wrong type",
                (snapshot) => {
                    repeat(snapshot).type = "retry";
                    return snapshot;
                },
                "root.children[0] (parallel).children[1] (repeat): expected a snapshot of a 'repeat' node but got 'retry'"
            ],
            [
                "a node snapshot has the wrong name, as it is from a different definition",
                (snapshot) => {
                    wait(snapshot).name = "WAIT 200ms";
                    return snapshot;
                },
                "expected a snapshot of the node named 'WAIT 100ms' but got 'WAIT 200ms'"
            ],
            [
                "a node snapshot has the wrong number of children",
                (snapshot) => {
                    parallel(snapshot).children!.pop();
                    return snapshot;
                },
                "root.children[0] (parallel): expected 3 child node snapshots but got 2"
            ],
            [
                "a node snapshot has children that are not an array",
                (snapshot) => {
                    (parallel(snapshot) as any).children = { length: 3, 0: lotto(snapshot) };
                    return snapshot;
                },
                "root.children[0] (parallel): expected the child node snapshots to be an array"
            ],
            [
                "a leaf node snapshot has children",
                (snapshot) => {
                    action(snapshot).children = [{ ...wait(snapshot) }];
                    return snapshot;
                },
                "root.children[0] (parallel).children[2] (action): expected 0 child node snapshots but got 1"
            ],
            [
                "a node snapshot has no id",
                (snapshot) => {
                    delete (action(snapshot) as any).id;
                    return snapshot;
                },
                "expected the node id to be a string"
            ],
            [
                "a node snapshot has an invalid state",
                (snapshot) => {
                    action(snapshot).state = "finished" as any;
                    return snapshot;
                },
                "'finished' is not a valid node state"
            ],
            [
                "a repeat node snapshot has an invalid iteration count",
                (snapshot) => {
                    repeat(snapshot).currentIterationCount = -1;
                    return snapshot;
                },
                "expected the current iteration count to be a non-negative integer"
            ],
            [
                "a repeat node snapshot has an invalid target iteration count",
                (snapshot) => {
                    repeat(snapshot).targetIterationCount = 1.5;
                    return snapshot;
                },
                "expected the target iteration count to be a non-negative integer or null"
            ],
            [
                "a retry node snapshot has an invalid attempt count",
                (snapshot) => {
                    delete retry(snapshot).currentAttemptCount;
                    return snapshot;
                },
                "expected the current attempt count to be a non-negative integer"
            ],
            [
                "a retry node snapshot has an invalid target attempt count",
                (snapshot) => {
                    retry(snapshot).targetAttemptCount = "two" as any;
                    return snapshot;
                },
                "expected the target attempt count to be a non-negative integer or null"
            ],
            [
                "a lotto node snapshot selects a child that does not exist",
                (snapshot) => {
                    lotto(snapshot).selectedChild = 2;
                    return snapshot;
                },
                "expected the selected child to be the index of a child node or null"
            ],
            [
                "a lotto node snapshot that is running has not selected a child",
                (snapshot) => {
                    lotto(snapshot).selectedChild = null;
                    return snapshot;
                },
                "expected a selected child for a lotto node that is not ready"
            ],
            [
                "a wait node snapshot has an invalid total duration",
                (snapshot) => {
                    wait(snapshot).totalDuration = -100;
                    return snapshot;
                },
                "expected the total duration to be a non-negative integer or null"
            ],
            [
                "a wait node snapshot has an invalid waited duration",
                (snapshot) => {
                    wait(snapshot).waitedDuration = "a while" as any;
                    return snapshot;
                },
                "expected the waited duration to be a number"
            ],
            [
                "an action node snapshot has an invalid update promise result",
                (snapshot) => {
                    action(snapshot).updatePromiseResult = { isResolved: "yes", value: null } as any;
                    return snapshot;
                },
                "expected the update promise result to be null or an object with an isResolved flag"
            ]
        ];

        for (const [description, corrupt, message] of invalidSnapshots) {
            it(description, () => {
                const snapshot = JSON.parse(JSON.stringify(createSteppedTree().snapshot()));

                const tree = createSteppedTree();

                assert.throws(() => tree.restore(corrupt(snapshot) as TreeSnapshot), Error, message);
            });
        }

        it("and the tree is left exactly as it was", () => {
            const snapshot = JSON.parse(JSON.stringify(createSteppedTree().snapshot()));

            // Only the very last node to be checked is invalid, so everything before it must not have been restored.
            action(snapshot).state = "finished" as any;
            lotto(snapshot).state = State.SUCCEEDED;
            wait(snapshot).waitedDuration = 90;

            const tree = createSteppedTree();
            const before = JSON.stringify(tree.snapshot());
            const detailsBefore = tree.getTreeNodeDetails();

            assert.throws(() => tree.restore(snapshot), Error, "is not a valid node state");

            assert.equal(JSON.stringify(tree.snapshot()), before);
            assert.deepEqual(tree.getTreeNodeDetails(), detailsBefore);
        });
    });

    describe("belongs to the definition of the tree it was taken from", () => {
        const mdsl = `
            root {
                sequence while(Check, 'x') {
                    action [Act, 'a']
                    repeat [2] { wait [100] }
                    retry [1, 3] { branch [sub] }
                }
            }
            root [sub] {
                lotto [1, 2] { action [Act, 1] condition [Check] }
            }
        `;

        // The same definition as above, but written out in full as the MDSL parser would.
        const jsonInFull: RootNodeDefinition[] = [
            {
                type: "root",
                child: {
                    type: "sequence",
                    while: { call: "Check", args: ["x"], succeedOnAbort: false },
                    children: [
                        { type: "action", call: "Act", args: ["a"] },
                        { type: "repeat", iterations: 2, child: { type: "wait", duration: 100 } },
                        { type: "retry", attempts: [1, 3], child: { type: "branch", ref: "sub" } }
                    ]
                }
            },
            {
                type: "root",
                id: "sub",
                child: {
                    type: "lotto",
                    weights: [1, 2],
                    children: [
                        { type: "action", call: "Act", args: [1] },
                        { type: "condition", call: "Check", args: [] }
                    ]
                }
            }
        ] as RootNodeDefinition[];

        // The same definition again, with the properties in a different order and optional properties left out.
        const jsonMinimal: RootNodeDefinition[] = [
            {
                id: "sub",
                child: {
                    weights: [1, 2],
                    children: [
                        { call: "Act", args: [1], type: "action" },
                        { call: "Check", type: "condition" }
                    ],
                    type: "lotto"
                },
                type: "root"
            },
            {
                child: {
                    children: [
                        { call: "Act", args: ["a"], type: "action" },
                        { child: { duration: 100, type: "wait" }, iterations: 2, type: "repeat" },
                        { child: { ref: "sub", type: "branch" }, attempts: [1, 3], type: "retry" }
                    ],
                    while: { call: "Check", args: ["x"] },
                    type: "sequence"
                },
                type: "root"
            }
        ] as RootNodeDefinition[];

        const createSteppedTree = (definition: string | RootNodeDefinition | RootNodeDefinition[]) => {
            const tree = createTree(definition, createWorld());
            tree.step();
            return tree;
        };

        it("by recording a definition that is the same for trees built from the same definition", () => {
            const { definition } = createSteppedTree(mdsl).snapshot();

            assert.isString(definition);
            assert.isNotEmpty(definition);
            assert.equal(createTree(mdsl, createWorld()).snapshot().definition, definition);
            assert.equal(createSteppedTree(mdsl).snapshot().definition, definition);
        });

        it("by recording a definition that survives JSON", () => {
            const snapshot = createSteppedTree(mdsl).snapshot();

            assert.equal(JSON.parse(JSON.stringify(snapshot)).definition, snapshot.definition);
        });

        describe("so an MDSL definition and its equivalent JSON definition are the same definition, as", () => {
            const definitions: [string, string | RootNodeDefinition[]][] = [
                ["MDSL", mdsl],
                [
                    "MDSL with different white space and comments",
                    `root{sequence while(Check,'x'){ /* a */ action[Act,'a'] repeat[2]{wait[100]} retry[1,3]{branch[sub]}}} root[sub]{lotto[1,2]{action[Act,1] condition[Check]}}`
                ],
                ["JSON written in full", jsonInFull],
                ["JSON with the properties in a different order and optional properties left out", jsonMinimal]
            ];

            for (const [fromName, from] of definitions) {
                for (const [toName, to] of definitions) {
                    it(`a snapshot taken from ${fromName} is restored to ${toName}`, () => {
                        const source = createSteppedTree(from);
                        const target = createTree(to, createWorld());

                        target.restore(JSON.parse(JSON.stringify(source.snapshot())));

                        assert.deepEqual(target.getTreeNodeDetails(), source.getTreeNodeDetails());
                    });
                }
            }

            it("a snapshot taken from an MDSL definition is restored to a JSON definition of a single root node", () => {
                const source = createSteppedTree("root { action [Act, 'a'] }");
                const target = createTree(
                    { type: "root", child: { type: "action", call: "Act", args: ["a"] } } as RootNodeDefinition,
                    createWorld()
                );

                target.restore(source.snapshot());

                assert.deepEqual(target.getTreeNodeDetails(), source.getTreeNodeDetails());
            });
        });

        describe("so a snapshot of another definition cannot be restored, including one that differs only in", () => {
            const differences: [string, string, string][] = [
                [
                    "the structure of the tree",
                    "root { sequence { action [Act, 'a'] action [Act, 'b'] } }",
                    "root { selector { action [Act, 'a'] action [Act, 'b'] } }"
                ],
                [
                    "an action argument",
                    "root { sequence { action [Act, 'a'] action [Act, 'b'] } }",
                    "root { sequence { action [Act, 'a'] action [Act, 'c'] } }"
                ],
                [
                    "a guard argument",
                    "root { sequence while(Check, 'x') { action [Act, 'a'] } }",
                    "root { sequence while(Check, 'y') { action [Act, 'a'] } }"
                ],
                [
                    "whether a guard succeeds when it aborts",
                    "root { sequence while(Check, 'x') { action [Act, 'a'] } }",
                    "root { sequence while(Check, 'x', true) { action [Act, 'a'] } }"
                ],
                [
                    "a callback",
                    "root { action [Act, 'a'] entry(Enter, 'x') }",
                    "root { action [Act, 'a'] exit(Enter, 'x') }"
                ],
                [
                    "the lotto weights",
                    "root { lotto [1, 2] { action [Act, 'a'] action [Act, 'b'] } }",
                    "root { lotto [2, 1] { action [Act, 'a'] action [Act, 'b'] } }"
                ],
                [
                    "the contents of a subtree",
                    "root { branch [sub] } root [sub] { action [Act, 'a'] }",
                    "root { branch [sub] } root [sub] { action [Act, 'b'] }"
                ],
                [
                    "a subtree that is not used",
                    "root { action [Act, 'a'] } root [unused] { action [Act, 'b'] }",
                    "root { action [Act, 'a'] } root [unused] { action [Act, 'c'] }"
                ]
            ];

            for (const [description, definitionA, definitionB] of differences) {
                it(description, () => {
                    for (const [from, to] of [
                        [definitionA, definitionB],
                        [definitionB, definitionA]
                    ]) {
                        const snapshot = JSON.parse(JSON.stringify(createSteppedTree(from).snapshot()));

                        // The tree is in a different state to the snapshot so that a restore could be seen to change it.
                        const target = createTree(to, createWorld());
                        const before = JSON.stringify(target.snapshot());
                        const detailsBefore = target.getTreeNodeDetails();

                        assert.throws(
                            () => target.restore(snapshot),
                            Error,
                            "error restoring snapshot: the snapshot does not match the tree's definition"
                        );

                        assert.equal(JSON.stringify(target.snapshot()), before);
                        assert.deepEqual(target.getTreeNodeDetails(), detailsBefore);
                    }
                });
            }

            it("an MDSL definition and a JSON definition that is not equivalent to it", () => {
                const snapshot = createSteppedTree(mdsl).snapshot();
                const different = JSON.parse(JSON.stringify(jsonInFull)) as RootNodeDefinition[];
                (different[0] as any).child.children[1].iterations = 3;

                assert.throws(
                    () => createTree(different, createWorld()).restore(snapshot),
                    Error,
                    "the snapshot does not match the tree's definition"
                );
            });
        });

        describe("so a snapshot that is not a snapshot of this tree cannot be restored if it is", () => {
            const validDefinition = "root { action [Act, 'a'] }";
            const validSnapshot = () => JSON.parse(JSON.stringify(createSteppedTree(validDefinition).snapshot()));

            const notSnapshots: [string, () => unknown][] = [
                ["null", () => null],
                ["undefined", () => undefined],
                ["a string", () => "snapshot"],
                ["a string of a snapshot", () => JSON.stringify(validSnapshot())],
                ["a number", () => 42],
                ["a boolean", () => true],
                ["an array", () => []],
                ["an array containing a snapshot", () => [validSnapshot()]],
                ["an object without any of the fields of a snapshot", () => ({})],
                [
                    "an object with a version and a root node but no definition",
                    () => ({ ...validSnapshot(), definition: undefined })
                ],
                [
                    "an object with a definition and a root node but no version",
                    () => ({ ...validSnapshot(), version: undefined })
                ],
                [
                    "an object with a version and a definition but no root node",
                    () => ({ ...validSnapshot(), root: undefined })
                ],
                ["an object with a definition that is not a string", () => ({ ...validSnapshot(), definition: 42 })],
                ["an object with a definition that is null", () => ({ ...validSnapshot(), definition: null })],
                ["an object with an empty definition", () => ({ ...validSnapshot(), definition: "" })],
                ["an object with a root node that is not an object", () => ({ ...validSnapshot(), root: "root" })]
            ];

            for (const [description, create] of notSnapshots) {
                it(description, () => {
                    const target = createSteppedTree(validDefinition);
                    const before = JSON.stringify(target.snapshot());

                    assert.throws(() => target.restore(create() as TreeSnapshot), Error);

                    assert.equal(JSON.stringify(target.snapshot()), before);
                });
            }

            it("an array, with a message that says that a snapshot object is expected", () => {
                assert.throws(
                    () => createTree(validDefinition, createWorld()).restore([] as any),
                    Error,
                    "error restoring snapshot: expected a snapshot object"
                );
            });
        });
    });
});
