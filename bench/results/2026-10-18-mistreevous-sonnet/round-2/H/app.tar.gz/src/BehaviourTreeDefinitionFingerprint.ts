import {
    AnyNodeDefinition,
    NodeAttributeDefinition,
    NodeGuardDefinition,
    RootNodeDefinition
} from "./BehaviourTreeDefinition";
import { MAIN_ROOT_NODE_KEY, RootNodeDefinitionMap, createRootNodeDefinitionMap } from "./BehaviourTreeBuilder";
import { isInteger } from "./BehaviourTreeDefinitionUtilities";
import { createHash } from "./Utilities";

/**
 * Describes the iterations, attempts or duration of a node in the way that the node builder reads it.
 * @param value The count or the lower and upper bounds of a count.
 * @returns The count, the bounds, or null if there is no limit.
 */
function describeCount(value: unknown): number | [number, number] | null {
    if (Array.isArray(value)) {
        return [value[0], value[1]];
    }

    return isInteger(value) ? (value as number) : null;
}

/**
 * Describes an attribute of a node, leaving out anything that is only a way of writing a default value.
 * @param attribute The attribute definition, if the node has one.
 * @returns The description of the attribute, or null if the node does not have one.
 */
function describeAttribute(attribute: NodeAttributeDefinition | NodeGuardDefinition | undefined) {
    if (!attribute) {
        return null;
    }

    return {
        call: attribute.call,
        args: attribute.args ?? [],
        succeedOnAbort: !!(attribute as NodeGuardDefinition).succeedOnAbort
    };
}

/**
 * Describes a node, and everything below it, as the tree that is built from it would behave.
 * This reads the same properties of the definition that the node builder does, so that any two definitions that
 * build the same tree have the same description, however they were written.
 * @param definition The node definition.
 * @param rootNodeDefinitionMap The mapping of root node identifers to root node definitions, including globally registered subtree root node definitions.
 * @returns The description of the node.
 */
function describeNode(definition: AnyNodeDefinition, rootNodeDefinitionMap: RootNodeDefinitionMap): unknown {
    // A branch node is replaced by the subtree that it refers to, in the same way that it is when the tree is built.
    if (definition.type === "branch") {
        return describeNode(rootNodeDefinitionMap[definition.ref].child, rootNodeDefinitionMap);
    }

    const describeChild = (child: AnyNodeDefinition) => describeNode(child, rootNodeDefinitionMap);

    const attributes = {
        while: describeAttribute(definition.while),
        until: describeAttribute(definition.until),
        entry: describeAttribute(definition.entry),
        step: describeAttribute(definition.step),
        exit: describeAttribute(definition.exit)
    };

    switch (definition.type) {
        case "root":
        case "flip":
        case "succeed":
        case "fail":
            return { type: definition.type, attributes, child: describeChild(definition.child) };

        case "repeat":
            return {
                type: definition.type,
                attributes,
                iterations: describeCount(definition.iterations),
                child: describeChild(definition.child)
            };

        case "retry":
            return {
                type: definition.type,
                attributes,
                attempts: describeCount(definition.attempts),
                child: describeChild(definition.child)
            };

        case "sequence":
        case "selector":
        case "parallel":
        case "race":
        case "all":
            return { type: definition.type, attributes, children: definition.children.map(describeChild) };

        case "lotto":
            return {
                type: definition.type,
                attributes,
                weights: definition.weights ?? null,
                children: definition.children.map(describeChild)
            };

        case "action":
        case "condition":
            return { type: definition.type, attributes, call: definition.call, args: definition.args ?? [] };

        case "wait":
            return { type: definition.type, attributes, duration: describeCount(definition.duration) };

        default:
            throw new Error(`unexpected node type '${(definition as AnyNodeDefinition).type}'`);
    }
}

/**
 * A JSON replacer that tags the values that JSON would otherwise turn into null or zero, which a definition given as an object
 * can contain, so that definitions that pass different arguments to a function are not mistaken for each other.
 * @param key The property key.
 * @param value The property value.
 * @returns The value, or a tag describing it if it cannot be represented in JSON.
 */
function tagUnserialisable(key: string, value: unknown): unknown {
    if (
        typeof value === "undefined" ||
        (typeof value === "number" && (!Number.isFinite(value) || Object.is(value, -0)))
    ) {
        return { unserialisable: String(value) === "0" ? "-0" : String(value) };
    }

    return value;
}

/**
 * Creates a hash that identifies the definition of a tree, to record in its snapshots.
 * Definitions that build the same tree have the same hash, whether they were written as MDSL or JSON, with their root nodes
 * in any order, and whether a subtree was defined with the tree or registered globally. A global subtree is only part of the
 * hash of the tree if the tree refers to it. A change to how a definition is described is a change to every hash.
 * @param definition The root node definitions, which must have been validated.
 * @returns The hash of the definition.
 */
export function createDefinitionHash(definition: RootNodeDefinition[]): string {
    const rootNodeDefinitionMap = createRootNodeDefinitionMap(definition);

    return createHash(
        JSON.stringify(
            describeNode(rootNodeDefinitionMap[MAIN_ROOT_NODE_KEY], rootNodeDefinitionMap),
            tagUnserialisable
        )
    );
}
