import State, { AnyState } from "./State";

/**
 * The current version of the behaviour tree snapshot format.
 */
export const SNAPSHOT_VERSION = 1;

/**
 * A snapshot of the execution state of a node in a behaviour tree instance, along with that of any child nodes.
 * This is a plain object that can be serialised as JSON.
 */
export type NodeSnapshot = {
    /**
     * The node unique identifier.
     */
    id: string;
    /**
     * The node type.
     */
    type: string;
    /**
     * The node name.
     */
    name: string;
    /**
     * The state of the node.
     */
    state: AnyState;
    /**
     * The snapshots of the child nodes, defined if the node is a composite or decorator node.
     */
    children?: NodeSnapshot[];
    /**
     * The number of iterations that a repeat node will make, or null if it has no limit.
     */
    targetIterationCount?: number | null;
    /**
     * The number of iterations that a repeat node has made.
     */
    currentIterationCount?: number;
    /**
     * The number of attempts that a retry node will make, or null if it has no limit.
     */
    targetAttemptCount?: number | null;
    /**
     * The number of attempts that a retry node has made.
     */
    currentAttemptCount?: number;
    /**
     * The index of the child node that a lotto node picked, or null if it has not picked one.
     */
    selectedChildIndex?: number | null;
    /**
     * The duration in milliseconds that a wait node will wait for, or null if it will wait indefinitely.
     */
    totalDuration?: number | null;
    /**
     * The duration in milliseconds that a wait node has waited for, up to the time that the snapshot was taken.
     */
    waitedDuration?: number;
    /**
     * The outcome of the promise returned by an action node's function, defined if the promise has settled but its action node has
     * not yet been updated to make use of it. The value is the string representation of the resolved value or rejection reason.
     */
    updatePromiseResult?: { isResolved: boolean; value: string };
};

/**
 * A snapshot of the execution state of a behaviour tree instance.
 * This is a plain object that can be serialised as JSON and used to restore the state of a tree built from the same definition.
 */
export type BehaviourTreeSnapshot = {
    /**
     * The version of the snapshot format.
     */
    version: typeof SNAPSHOT_VERSION;
    /**
     * A hash that identifies the definition of the tree that the snapshot was taken from. A snapshot can only be restored to a tree
     * with the same hash, which every tree built from the same definition has, whether it was written as MDSL or JSON.
     */
    definitionHash: string;
    /**
     * The snapshot of the main root node, along with that of every node below it.
     */
    root: NodeSnapshot;
};

/**
 * Asserts that a numeric property of a node snapshot is a non-negative integer, or null if that is allowed.
 * @param snapshot The node snapshot.
 * @param property The name of the property to check.
 * @param nodeType The type of the node that the snapshot is for.
 * @param isNullAllowed Whether the property is allowed to be null.
 */
export function assertCount(
    snapshot: NodeSnapshot,
    property: keyof NodeSnapshot,
    nodeType: string,
    isNullAllowed = false
): void {
    const value = snapshot[property];

    if (isNullAllowed && value === null) {
        return;
    }

    if (typeof value !== "number" || !Number.isInteger(value) || value < 0) {
        throw new Error(
            `expected ${
                isNullAllowed ? "null or " : ""
            }a non-negative integer for '${property}' of ${nodeType} node but found '${value}'`
        );
    }
}

/**
 * Asserts that a count in a node snapshot is one that the node could have, given how its definition limits the count.
 * A count that is null has not been picked yet, which is only a problem for a node that is running.
 * @param snapshot The node snapshot.
 * @param property The name of the property to check.
 * @param nodeType The type of the node that the snapshot is for.
 * @param fixedCount The fixed count that the node was defined with, or null if it was not.
 * @param isLimited Whether the node was defined with a fixed count or a minimum and maximum count.
 */
export function assertCountMatchesDefinition(
    snapshot: NodeSnapshot,
    property: keyof NodeSnapshot,
    nodeType: string,
    fixedCount: number | null,
    isLimited: boolean
): void {
    const value = snapshot[property];

    if (value === null) {
        if (isLimited && snapshot.state === State.RUNNING) {
            throw new Error(`expected '${property}' of running ${nodeType} node with a defined limit not to be null`);
        }

        return;
    }

    // Picking a count from a minimum and maximum can give any value that the random number function allows for.
    const expected = isLimited ? fixedCount ?? value : null;

    if (value !== expected) {
        throw new Error(`expected '${property}' of ${nodeType} node to be ${expected} but found '${value}'`);
    }
}

/**
 * Asserts that a numeric property of a node snapshot is a finite number.
 * @param snapshot The node snapshot.
 * @param property The name of the property to check.
 * @param nodeType The type of the node that the snapshot is for.
 */
export function assertFiniteNumber(snapshot: NodeSnapshot, property: keyof NodeSnapshot, nodeType: string): void {
    const value = snapshot[property];

    if (typeof value !== "number" || !Number.isFinite(value)) {
        throw new Error(`expected a finite number for '${property}' of ${nodeType} node but found '${value}'`);
    }
}

/**
 * Gets whether the specified value is a non-null object that is not an array.
 * @param value The value to check.
 * @returns Whether the specified value is a non-null object that is not an array.
 */
export function isPlainObject(value: unknown): value is Record<string, unknown> {
    return typeof value === "object" && value !== null && !Array.isArray(value);
}
