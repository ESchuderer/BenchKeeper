/**
 * Create a randomly generated node uid.
 * @returns A randomly generated node uid.
 */
export function createUid(): string {
    const S4 = function () {
        return (((1 + Math.random()) * 0x10000) | 0).toString(16).substring(1);
    };
    return S4() + S4() + "-" + S4() + "-" + S4() + "-" + S4() + "-" + S4() + S4() + S4();
}

/**
 * Create a 64-bit hash of a string, as 16 hexadecimal characters.
 * This is a fast hash that is used to tell definitions apart and is not suitable for anything that needs to be secure.
 * It is implemented here, rather than taken from a crypto library, so that it works in node and in browsers.
 * @param text The text to hash.
 * @returns The hash of the text.
 */
export function createHash(text: string): string {
    let h1 = 0xdeadbeef;
    let h2 = 0x41c6ce57;

    for (let index = 0; index < text.length; index++) {
        const code = text.charCodeAt(index);
        h1 = Math.imul(h1 ^ code, 2654435761);
        h2 = Math.imul(h2 ^ code, 1597334677);
    }

    h1 = Math.imul(h1 ^ (h1 >>> 16), 2246822507) ^ Math.imul(h2 ^ (h2 >>> 13), 3266489909);
    h2 = Math.imul(h2 ^ (h2 >>> 16), 2246822507) ^ Math.imul(h1 ^ (h1 >>> 13), 3266489909);

    return [h2, h1].map((value) => (value >>> 0).toString(16).padStart(8, "0")).join("");
}
