import { assert } from "chai";
import sinon, { SinonFakeTimers } from "sinon";

import { BehaviourTree, BehaviourTreeOptions, BehaviourTreeSnapshot, NodeDetails, State } from "../src/index";
import { RootNodeDefinition } from "../src/BehaviourTreeDefinition";

import { findNode } from "./TestUtilities";

/**
 * A mapping of agent function names to the behaviour that the function should have.
 * The behaviours are shared between every tree built by a test, so that a tree and its restored copy see the same world.
 */
type World = { [functionName: string]: (...args: any[]) => any };

/**
 * A behaviour tree under test, along with a log of every agent function that was called on its agent.
 */
type Fixture = {
    tree: BehaviourTree;
    calls: string[];
    events: string[];
};

/**
 * Creates a behaviour tree whose agent functions log each call and then defer to the specified world.
 */
function createFixture(
    definition: string | RootNodeDefinition,
    world: World,
    options: BehaviourTreeOptions = {}
): Fixture {
    const calls: string[] = [];
    const events: string[] = [];

    const agent: { [functionName: string]: (...args: any[]) => any } = {};

    Object.keys(world).forEach((name) => {
        agent[name] = (...args: any[]) => {
            // Callbacks are called with an extra leading argument, so log the name along with any other arguments.
            calls.push(args.length ? `${name}(${JSON.stringify(args)})` : name);
            return world[name](...args);
        };
    });

    const tree = new BehaviourTree(definition, agent, {
        ...options,
        onNodeStateChange: (change) => events.push(`${change.type}:${change.previousState}>${change.state}`)
    });

    return { tree, calls, events };
}

/**
 * Pass a snapshot through the same serialisation that an application would use to store it.
 */
function throughJSON<T>(value: T): T {
    return JSON.parse(JSON.stringify(value));
}

/**
 * Creates a fixture for the same definition and world as the specified one, restored from a stored snapshot of it.
 */
function createRestoredFixture(
    original: Fixture,
    definition: string | RootNodeDefinition,
    world: World,
    options: BehaviourTreeOptions = {}
): Fixture {
    const restored = createFixture(definition, world, options);
    restored.tree.restore(throughJSON(original.tree.snapshot()));
    return restored;
}

/**
 * Asserts that a tree and a restored copy of it are indistinguishable after each of a number of further steps.
 */
function assertSameBehaviour(original: Fixture, restored: Fixture, steps: number, onStep?: (step: number) => void) {
    // Anything that happened before the snapshot was restored does not count.
    original.calls.length = 0;
    original.events.length = 0;

    for (let step = 0; step < steps; step++) {
        onStep?.(step);

        original.tree.step();
        restored.tree.step();

        assert.deepEqual(restored.calls, original.calls, `agent calls differ after step ${step}`);
        assert.deepEqual(restored.events, original.events, `state changes differ after step ${step}`);
        assert.strictEqual(restored.tree.getState(), original.tree.getState());
        assert.deepEqual(restored.tree.getTreeNodeDetails(), original.tree.getTreeNodeDetails());
    }
}

describe("A BehaviourTree instance", () => {
    describe("has a 'snapshot' function that", () => {
        const definition = `root {
            sequence {
                action [Prepare]
                parallel {
                    action [Build]
                    sequence {
                        action [Review]
                        condition [IsApproved]
                    }
                }
                selector {
                    condition [IsMerged]
                    action [Merge]
                }
                flip { condition [IsBlocked] }
            }
        }`;

        const createWorld = (): World => ({
            Prepare: () => State.SUCCEEDED,
            Build: () => State.RUNNING,
            Review: () => State.RUNNING,
            IsApproved: () => true,
            IsMerged: () => false,
            Merge: () => State.SUCCEEDED,
            IsBlocked: () => false
        });

        it("returns an object that is unchanged by serialising it to JSON and back, whatever state the tree is in", () => {
            const { tree } = createFixture(definition, createWorld());

            const beforeFirstStep = tree.snapshot();
            assert.deepEqual(throughJSON(beforeFirstStep), beforeFirstStep);

            tree.step();

            const midRun = tree.snapshot();
            assert.deepEqual(throughJSON(midRun), midRun);
            assert.notDeepEqual(midRun, beforeFirstStep);
        });

        it("returns an object that describes the state of every node in the tree", () => {
            const { tree } = createFixture(definition, createWorld());

            tree.step();

            const flatten = (node: { type: string; state: State; children?: any[] }): string[] => [
                `${node.type}:${node.state}`,
                ...(node.children ?? []).flatMap(flatten)
            ];

            assert.deepEqual(flatten(tree.snapshot().root), flatten(tree.getTreeNodeDetails() as NodeDetails));
        });

        it("returns an object that is not affected by later steps of the tree, or changes made to it", () => {
            const { tree } = createFixture(definition, createWorld());

            tree.step();

            const snapshot = tree.snapshot();
            const original = throughJSON(snapshot);

            tree.step();
            tree.step();

            assert.deepEqual(snapshot, original);

            snapshot.root.state = State.FAILED;
            snapshot.root.children = [];

            assert.strictEqual(tree.getState(), State.RUNNING);
            assert.deepEqual(tree.snapshot().root.children?.length, 1);
        });
    });

    describe("has a 'restore' function that", () => {
        const definition = `root {
            sequence {
                action [Prepare] entry(OnEntry, "prepare") exit(OnExit, "prepare")
                parallel {
                    action [Build] entry(OnEntry, "build") exit(OnExit, "build")
                    sequence {
                        action [Review]
                        condition [IsApproved]
                    }
                }
                race {
                    action [Deploy]
                    action [TimeOut]
                }
                all {
                    action [NotifyTeam]
                    action [NotifyOwner]
                }
                selector {
                    condition [IsMerged]
                    action [Merge]
                }
                succeed { fail { flip { condition [IsBlocked] } } }
            }
        }`;

        let buildDone: boolean;
        let reviewDone: boolean;
        let deployed: boolean;
        let notified: boolean;

        const createWorld = (): World => ({
            OnEntry: () => {},
            OnExit: () => {},
            Prepare: () => State.SUCCEEDED,
            Build: () => (buildDone ? State.SUCCEEDED : State.RUNNING),
            Review: () => (reviewDone ? State.SUCCEEDED : State.RUNNING),
            IsApproved: () => true,
            Deploy: () => (deployed ? State.SUCCEEDED : State.RUNNING),
            TimeOut: () => State.RUNNING,
            NotifyTeam: () => (notified ? State.SUCCEEDED : State.RUNNING),
            NotifyOwner: () => (notified ? State.FAILED : State.RUNNING),
            IsMerged: () => false,
            Merge: () => State.SUCCEEDED,
            IsBlocked: () => false
        });

        beforeEach(() => {
            buildDone = false;
            reviewDone = false;
            deployed = false;
            notified = false;
        });

        it("gives a new tree the same node states, ids and details as the tree that the snapshot was taken from", () => {
            const world = createWorld();
            const original = createFixture(definition, world);

            original.tree.step();
            buildDone = true;
            original.tree.step();

            const restored = createRestoredFixture(original, definition, world);

            assert.deepEqual(restored.tree.getTreeNodeDetails(), original.tree.getTreeNodeDetails());
            assert.strictEqual(restored.tree.getState(), State.RUNNING);
            assert.isTrue(restored.tree.isRunning());

            // Taking a snapshot of the restored tree gives us back what we restored.
            assert.deepEqual(restored.tree.snapshot(), original.tree.snapshot());
        });

        it("makes a restored tree behave like the original for the rest of its run", () => {
            const world = createWorld();
            const original = createFixture(definition, world);

            original.tree.step();
            buildDone = true;
            original.tree.step();

            const restored = createRestoredFixture(original, definition, world);

            assertSameBehaviour(original, restored, 8, (step) => {
                reviewDone = reviewDone || step === 1;
                deployed = deployed || step === 3;
                notified = notified || step === 5;
            });

            // The run should actually have finished, otherwise the comparison above is not saying much.
            assert.strictEqual(original.tree.getState(), State.SUCCEEDED);
        });

        it("makes a restored tree behave like the original from every point in a run", () => {
            const timeline = (step: number) => {
                buildDone = step >= 1;
                reviewDone = step >= 3;
                deployed = step >= 4;
                notified = step >= 6;
            };

            for (let stepsBeforeSnapshot = 0; stepsBeforeSnapshot < 9; stepsBeforeSnapshot++) {
                const world = createWorld();
                const original = createFixture(definition, world);

                for (let step = 0; step < stepsBeforeSnapshot; step++) {
                    timeline(step);
                    original.tree.step();
                }

                const restored = createRestoredFixture(original, definition, world);

                assertSameBehaviour(original, restored, 9 - stepsBeforeSnapshot, (step) =>
                    timeline(stepsBeforeSnapshot + step)
                );
            }
        });

        it("does not call any agent functions or the 'onNodeStateChange' option", () => {
            const world = createWorld();
            const original = createFixture(definition, world);

            original.tree.step();

            const restored = createFixture(definition, world);
            restored.tree.restore(original.tree.snapshot());

            assert.deepEqual(restored.calls, []);
            assert.deepEqual(restored.events, []);
        });

        describe("whatever points in their runs the tree and the snapshot are at", () => {
            const STEPS = 9;

            const timeline = (step: number) => {
                buildDone = step >= 1;
                reviewDone = step >= 3;
                deployed = step >= 4;
                notified = step >= 6;
            };

            /**
             * Creates a tree that has been stepped the specified number of times, following the timeline.
             */
            const createSteppedFixture = (world: World, steps: number) => {
                const fixture = createFixture(definition, world);

                for (let step = 0; step < steps; step++) {
                    timeline(step);
                    fixture.tree.step();
                }

                return fixture;
            };

            /**
             * Calls the specified function for every combination of the number of steps that a tree has made
             * and the number of steps that the tree that a snapshot was taken from had made.
             */
            const forEachPairOfPoints = (
                callback: (treeSteps: number, snapshotSteps: number, world: World) => void
            ) => {
                for (let treeSteps = 0; treeSteps < STEPS; treeSteps++) {
                    for (let snapshotSteps = 0; snapshotSteps < STEPS; snapshotSteps++) {
                        callback(treeSteps, snapshotSteps, createWorld());
                    }
                }
            };

            it("does not call the 'onNodeStateChange' option or any agent functions when restoring over a tree that is in a different state", () => {
                forEachPairOfPoints((treeSteps, snapshotSteps, world) => {
                    const snapshot = createSteppedFixture(world, snapshotSteps).tree.snapshot();
                    const target = createSteppedFixture(world, treeSteps);

                    target.calls.length = 0;
                    target.events.length = 0;

                    target.tree.restore(snapshot);

                    assert.deepEqual(
                        target.events,
                        [],
                        `state changes for tree at ${treeSteps}, snapshot at ${snapshotSteps}`
                    );
                    assert.deepEqual(
                        target.calls,
                        [],
                        `agent calls for tree at ${treeSteps}, snapshot at ${snapshotSteps}`
                    );
                });
            });

            it("reports state changes as usual from the next step after restoring over a tree that is in a different state", () => {
                forEachPairOfPoints((treeSteps, snapshotSteps, world) => {
                    const snapshotSource = createSteppedFixture(world, snapshotSteps);
                    const target = createSteppedFixture(world, treeSteps);
                    const reference = createRestoredFixture(snapshotSource, definition, world);

                    target.tree.restore(snapshotSource.tree.snapshot());

                    target.calls.length = 0;
                    target.events.length = 0;

                    // The target should now behave exactly like a tree that was built and restored from the snapshot.
                    assertSameBehaviour(reference, target, STEPS - snapshotSteps, (step) =>
                        timeline(snapshotSteps + step)
                    );
                });
            });

            it("leaves the snapshot unchanged when the tree it was restored to is stepped", () => {
                forEachPairOfPoints((treeSteps, snapshotSteps, world) => {
                    const snapshot = createSteppedFixture(world, snapshotSteps).tree.snapshot();
                    const snapshotBefore = throughJSON(snapshot);

                    const target = createSteppedFixture(world, treeSteps);
                    target.tree.restore(snapshot);

                    for (let step = 0; step < STEPS; step++) {
                        timeline(snapshotSteps + step);
                        target.tree.step();

                        assert.deepEqual(
                            snapshot,
                            snapshotBefore,
                            `snapshot changed after step ${step} for tree at ${treeSteps}, snapshot at ${snapshotSteps}`
                        );
                    }
                });
            });

            it("gives a snapshot taken straight after restoring that is equal to the snapshot that was restored", () => {
                forEachPairOfPoints((treeSteps, snapshotSteps, world) => {
                    const snapshot = createSteppedFixture(world, snapshotSteps).tree.snapshot();
                    const target = createSteppedFixture(world, treeSteps);

                    target.tree.restore(snapshot);

                    assert.deepEqual(
                        throughJSON(target.tree.snapshot()),
                        throughJSON(snapshot),
                        `for tree at ${treeSteps}, snapshot at ${snapshotSteps}`
                    );
                });
            });
        });

        it("does not call 'entry' callbacks again for nodes that were already running", () => {
            const world = createWorld();
            const original = createFixture(definition, world);

            original.tree.step();

            const restored = createRestoredFixture(original, definition, world);
            restored.tree.step();

            assert.notInclude(restored.calls.join(), 'OnEntry(["build"])');
            assert.notInclude(restored.calls.join(), 'OnEntry(["prepare"])');
        });

        it("can be used on the tree that the snapshot was taken from to return it to an earlier point in its run", () => {
            const world = createWorld();
            const { tree, calls } = createFixture(definition, world);

            tree.step();

            const snapshot = tree.snapshot();
            const detailsAtSnapshot = tree.getTreeNodeDetails();

            buildDone = true;
            tree.step();
            tree.step();

            assert.notDeepEqual(tree.getTreeNodeDetails(), detailsAtSnapshot);

            calls.length = 0;
            tree.restore(snapshot);

            assert.deepEqual(tree.getTreeNodeDetails(), detailsAtSnapshot);
            assert.deepEqual(calls, []);
        });

        it("can be used on a tree that has not been stepped yet with a snapshot of one that has not been stepped yet", () => {
            const world = createWorld();
            const original = createFixture(definition, world);
            const restored = createRestoredFixture(original, definition, world);

            assert.strictEqual(restored.tree.getState(), State.READY);
            assertSameBehaviour(original, restored, 3);
        });

        describe("restores a tree that had finished", () => {
            it("as finished, in the same state", () => {
                const finishingDefinition = "root { sequence { action [Prepare] condition [IsApproved] } }";

                for (const outcome of [State.SUCCEEDED, State.FAILED]) {
                    const world = createWorld();
                    world.Prepare = () => outcome;

                    const original = createFixture(finishingDefinition, world);
                    original.tree.step();
                    assert.strictEqual(original.tree.getState(), outcome);

                    const restored = createRestoredFixture(original, finishingDefinition, world);

                    assert.strictEqual(restored.tree.getState(), outcome);
                    assert.isFalse(restored.tree.isRunning());
                    assert.deepEqual(restored.tree.getTreeNodeDetails(), original.tree.getTreeNodeDetails());
                }
            });

            it("so that the next step starts a new run", () => {
                const world = createWorld();
                world.Prepare = () => State.FAILED;

                const original = createFixture(definition, world);
                original.tree.step();

                const restored = createRestoredFixture(original, definition, world);

                world.Prepare = () => State.SUCCEEDED;

                assertSameBehaviour(original, restored, 3);

                assert.deepEqual(restored.calls.slice(0, 2), ['OnEntry(["prepare"])', "Prepare"]);
                assert.strictEqual(restored.tree.getState(), State.RUNNING);
            });
        });

        describe("will throw an error and leave the tree as it was if", () => {
            const world = createWorld();

            const createMidRunTree = () => {
                const fixture = createFixture(definition, world);
                fixture.tree.step();
                return fixture;
            };

            const assertRejected = (snapshot: any, message: string) => {
                const { tree } = createFixture(definition, world);
                const detailsBefore = tree.getTreeNodeDetails();

                assert.throws(() => tree.restore(snapshot), Error, message);
                assert.deepEqual(tree.getTreeNodeDetails(), detailsBefore);
            };

            it("the snapshot is not an object", () => {
                assertRejected(undefined, "invalid snapshot: expected an object");
                assertRejected(null, "invalid snapshot: expected an object");
                assertRejected("snapshot", "invalid snapshot: expected an object");
                assertRejected([], "invalid snapshot: expected an object");
            });

            it("the snapshot has an unsupported version", () => {
                const snapshot: any = createMidRunTree().tree.snapshot();
                snapshot.version = 2;
                assertRejected(snapshot, "invalid snapshot: unsupported version '2'");
                delete snapshot.version;
                assertRejected(snapshot, "invalid snapshot: unsupported version 'undefined'");
            });

            it("the snapshot has no root node", () => {
                const snapshot: any = createMidRunTree().tree.snapshot();
                delete snapshot.root;
                assertRejected(snapshot, "invalid snapshot: expected an object for root node");
            });

            it("a node has an unrecognised state", () => {
                const snapshot: any = createMidRunTree().tree.snapshot();
                snapshot.root.children[0].state = "mistreevous.sleeping";
                assertRejected(
                    snapshot,
                    "invalid snapshot: unrecognised state 'mistreevous.sleeping' for sequence node"
                );
            });

            it("a node has no id", () => {
                const snapshot: any = createMidRunTree().tree.snapshot();
                delete snapshot.root.children[0].id;
                assertRejected(snapshot, "invalid snapshot: expected a string id for sequence node");
            });

            it("a node is not of the type that the tree has at the same position", () => {
                const snapshot: any = createMidRunTree().tree.snapshot();
                snapshot.root.children[0].children[0].type = "condition";
                assertRejected(
                    snapshot,
                    "invalid snapshot: expected a node of type 'action' but found type 'condition'"
                );
            });

            it("a node does not have the name that the tree has at the same position", () => {
                const snapshot: any = createMidRunTree().tree.snapshot();
                snapshot.root.children[0].children[0].name = "Cook";
                assertRejected(snapshot, "invalid snapshot: expected action node 'Prepare' but found 'Cook'");
            });

            it("a node has a different number of children to the tree at the same position", () => {
                const snapshot: any = createMidRunTree().tree.snapshot();
                snapshot.root.children[0].children.pop();
                assertRejected(snapshot, "invalid snapshot: expected a child count of 6 for sequence node but found 5");
            });

            it("a node is missing its children", () => {
                const snapshot: any = createMidRunTree().tree.snapshot();
                delete snapshot.root.children[0].children;
                assertRejected(snapshot, "invalid snapshot: expected a child count of 6 for sequence node but found 0");
            });

            it("a node that is deep in the tree is not valid, without anything having been restored before it", () => {
                const original = createMidRunTree();
                const snapshot: any = original.tree.snapshot();

                // Make sure that the first node to be restored would have changed if we did not check up front.
                assert.strictEqual(snapshot.root.state, State.RUNNING);

                const selector = snapshot.root.children[0].children[4];
                assert.strictEqual(selector.type, "selector");
                selector.state = "mistreevous.sleeping";

                assertRejected(
                    snapshot,
                    "invalid snapshot: unrecognised state 'mistreevous.sleeping' for selector node"
                );
            });

            it("the snapshot is for a tree built from a different definition", () => {
                const other = createFixture("root { sequence { action [Prepare] action [Build] } }", world);
                other.tree.step();

                assertRejected(
                    other.tree.snapshot(),
                    "invalid snapshot: the snapshot does not match the tree's definition"
                );
            });
        });
    });

    describe("restoring a snapshot into an unrelated agent", () => {
        it("only needs the same definition, not the same agent or tree instance", () => {
            const definition = "root { sequence { action [Work] action [Report] } }";
            const world: World = { Work: () => State.SUCCEEDED, Report: () => State.RUNNING };

            const original = createFixture(definition, world);
            original.tree.step();

            const stored = JSON.stringify(original.tree.snapshot());

            const restoredCalls: string[] = [];
            const restored = new BehaviourTree(definition, {
                Work: () => {
                    restoredCalls.push("Work");
                    return State.SUCCEEDED;
                },
                Report: () => {
                    restoredCalls.push("Report");
                    return State.SUCCEEDED;
                }
            });

            restored.restore(JSON.parse(stored) as BehaviourTreeSnapshot);
            restored.step();

            assert.deepEqual(restoredCalls, ["Report"]);
            assert.strictEqual(restored.getState(), State.SUCCEEDED);
            assert.strictEqual(findNode(restored, "action", "Work").state, State.SUCCEEDED);
        });
    });
});

/**
 * A pseudo-random number generator that cycles through the specified values, and can report and be moved to a position in them.
 */
function createRandom(values: number[]) {
    let position = 0;

    return Object.assign(() => values[position++ % values.length], {
        position: () => position,
        seek: (newPosition: number) => {
            position = newPosition;
        }
    });
}

/**
 * Describes a tree that should behave the same after being restored from a snapshot as the tree that the snapshot was taken from.
 */
type Scenario = {
    definition: string | RootNodeDefinition;
    world: World;
    /**
     * The number of steps to take in total, whether before or after the snapshot.
     */
    steps: number;
    /**
     * The values to cycle through for the 'random' option of each tree.
     */
    randomValues?: number[];
    /**
     * Gets any extra options for a tree.
     */
    createOptions?: () => BehaviourTreeOptions;
    /**
     * Called before each step of the tree, to move the world on.
     */
    beforeStep?: (step: number) => void;
};

/**
 * Asserts that, whichever step of a run a snapshot is taken after, a tree restored from it behaves exactly as the original does.
 */
function assertSameBehaviourFromEveryStep(scenario: Scenario) {
    const { definition, world, steps, randomValues = [0], createOptions = () => ({}), beforeStep } = scenario;

    for (let stepsBeforeSnapshot = 0; stepsBeforeSnapshot <= steps; stepsBeforeSnapshot++) {
        const originalRandom = createRandom(randomValues);
        const original = createFixture(definition, world, { ...createOptions(), random: originalRandom });

        for (let step = 0; step < stepsBeforeSnapshot; step++) {
            beforeStep?.(step);
            original.tree.step();
        }

        // Restoring is not allowed to use any of the random numbers that the original tree would have used next.
        const restoredRandom = createRandom(randomValues);
        restoredRandom.seek(originalRandom.position());

        const restored = createFixture(definition, world, { ...createOptions(), random: restoredRandom });
        restored.tree.restore(throughJSON(original.tree.snapshot()));

        assert.strictEqual(restoredRandom.position(), originalRandom.position());

        assertSameBehaviour(original, restored, steps - stepsBeforeSnapshot, (step) => {
            beforeStep?.(stepsBeforeSnapshot + step);
        });

        assert.strictEqual(restoredRandom.position(), originalRandom.position());
    }
}

describe("Restoring a snapshot of a tree with a", () => {
    describe("repeat node", () => {
        it("continues counting from the number of iterations already made", () => {
            const world: World = { Work: () => State.SUCCEEDED };
            const original = createFixture("root { repeat [3] { action [Work] } }", world);

            original.tree.step();
            original.tree.step();

            const restored = createRestoredFixture(original, "root { repeat [3] { action [Work] } }", world);

            restored.tree.step();
            assert.strictEqual(restored.tree.getState(), State.RUNNING);

            restored.tree.step();
            assert.strictEqual(restored.tree.getState(), State.SUCCEEDED);

            assert.deepEqual(restored.calls, ["Work"]);
        });

        it("behaves the same as the original when the number of iterations is fixed", () => {
            let step = 0;

            assertSameBehaviourFromEveryStep({
                definition: "root { repeat [3] { sequence { action [Work] action [Approve] } } }",
                world: { Work: () => State.SUCCEEDED, Approve: () => (step % 2 ? State.SUCCEEDED : State.RUNNING) },
                steps: 9,
                beforeStep: (currentStep) => (step = currentStep)
            });
        });

        it("behaves the same as the original when there is no limit to the iterations", () => {
            assertSameBehaviourFromEveryStep({
                definition: "root { repeat { action [Work] } }",
                world: { Work: () => State.SUCCEEDED },
                steps: 4
            });
        });

        it("keeps the number of iterations that was randomly picked from a range, without picking again", () => {
            const definition = "root { repeat [2, 5] { action [Work] } }";
            const world: World = { Work: () => State.SUCCEEDED };

            const random = createRandom([0.99, 0, 0.5]);
            const original = createFixture(definition, world, { random });

            // The first random number gives us the maximum number of iterations.
            original.tree.step();
            assert.strictEqual(random.position(), 1);

            const restoredRandom = createRandom([0, 0.5, 0.99]);
            const restored = createFixture(definition, world, { random: restoredRandom });
            restored.tree.restore(throughJSON(original.tree.snapshot()));

            // The restored tree would only get to three iterations if it had picked a new number.
            for (let step = 0; step < 5; step++) {
                assert.strictEqual(restored.tree.getState(), State.RUNNING);
                restored.tree.step();
            }

            assert.strictEqual(restored.tree.getState(), State.SUCCEEDED);
            assert.strictEqual(restoredRandom.position(), 0);
        });

        it("behaves the same as the original when the number of iterations is picked from a range", () => {
            let step = 0;

            assertSameBehaviourFromEveryStep({
                definition: "root { repeat [1, 6] { action [Work] } }",
                world: { Work: () => (step % 3 === 1 ? State.RUNNING : State.SUCCEEDED) },
                randomValues: [0.99, 0, 0.5, 0.2],
                steps: 10,
                beforeStep: (currentStep) => (step = currentStep)
            });
        });

        it("picks a new number of iterations in the next run after restoring a finished tree", () => {
            const definition = "root { repeat [1, 6] { action [Work] } }";
            const world: World = { Work: () => State.SUCCEEDED };

            const originalRandom = createRandom([0, 0.99]);
            const original = createFixture(definition, world, { random: originalRandom });

            // The tree makes a single iteration.
            original.tree.step();
            original.tree.step();
            assert.strictEqual(original.tree.getState(), State.SUCCEEDED);

            const restoredRandom = createRandom([0, 0.99]);
            restoredRandom.seek(originalRandom.position());
            const restored = createFixture(definition, world, { random: restoredRandom });
            restored.tree.restore(throughJSON(original.tree.snapshot()));

            assert.strictEqual(restored.tree.getState(), State.SUCCEEDED);
            assert.strictEqual(restoredRandom.position(), originalRandom.position());

            // The next step starts a new run, picking six iterations this time.
            assertSameBehaviour(original, restored, 7);
            assert.strictEqual(restoredRandom.position(), originalRandom.position());
            assert.strictEqual(restored.calls.length, 6);
        });
    });

    describe("retry node", () => {
        it("continues counting from the number of attempts already made", () => {
            const world: World = { Work: () => State.FAILED };
            const original = createFixture("root { retry [3] { action [Work] } }", world);

            original.tree.step();
            original.tree.step();

            const restored = createRestoredFixture(original, "root { retry [3] { action [Work] } }", world);

            restored.tree.step();
            assert.strictEqual(restored.tree.getState(), State.RUNNING);

            restored.tree.step();
            assert.strictEqual(restored.tree.getState(), State.FAILED);

            assert.deepEqual(restored.calls, ["Work"]);
        });

        it("behaves the same as the original when the number of attempts is fixed", () => {
            let step = 0;

            assertSameBehaviourFromEveryStep({
                definition: "root { retry [4] { sequence { action [Work] action [Approve] } } }",
                world: { Work: () => State.SUCCEEDED, Approve: () => (step === 5 ? State.SUCCEEDED : State.FAILED) },
                steps: 8,
                beforeStep: (currentStep) => (step = currentStep)
            });
        });

        it("behaves the same as the original when there is no limit to the attempts", () => {
            assertSameBehaviourFromEveryStep({
                definition: "root { retry { action [Work] } }",
                world: { Work: () => State.FAILED },
                steps: 4
            });
        });

        it("keeps the number of attempts that was randomly picked from a range, without picking again", () => {
            const definition = "root { retry [2, 5] { action [Work] } }";
            const world: World = { Work: () => State.FAILED };

            const random = createRandom([0.99]);
            const original = createFixture(definition, world, { random });

            original.tree.step();
            assert.strictEqual(random.position(), 1);

            const restoredRandom = createRandom([0]);
            const restored = createFixture(definition, world, { random: restoredRandom });
            restored.tree.restore(throughJSON(original.tree.snapshot()));

            // The restored tree would only make two attempts if it had picked a new number.
            for (let step = 0; step < 5; step++) {
                assert.strictEqual(restored.tree.getState(), State.RUNNING);
                restored.tree.step();
            }

            assert.strictEqual(restored.tree.getState(), State.FAILED);
            assert.strictEqual(restoredRandom.position(), 0);
        });

        it("behaves the same as the original when the number of attempts is picked from a range", () => {
            let step = 0;

            assertSameBehaviourFromEveryStep({
                definition: "root { retry [1, 6] { action [Work] } }",
                world: { Work: () => (step === 4 ? State.SUCCEEDED : State.FAILED) },
                randomValues: [0.99, 0, 0.5, 0.2],
                steps: 10,
                beforeStep: (currentStep) => (step = currentStep)
            });
        });

        it("picks a new number of attempts in the next run after restoring a finished tree", () => {
            const definition = "root { retry [1, 6] { action [Work] } }";
            const world: World = { Work: () => State.FAILED };

            const originalRandom = createRandom([0, 0.99]);
            const original = createFixture(definition, world, { random: originalRandom });

            // The tree makes a single attempt.
            original.tree.step();
            original.tree.step();
            assert.strictEqual(original.tree.getState(), State.FAILED);

            const restoredRandom = createRandom([0, 0.99]);
            restoredRandom.seek(originalRandom.position());
            const restored = createFixture(definition, world, { random: restoredRandom });
            restored.tree.restore(throughJSON(original.tree.snapshot()));

            assert.strictEqual(restored.tree.getState(), State.FAILED);

            // The next step starts a new run, making six attempts this time.
            assertSameBehaviour(original, restored, 7);
            assert.strictEqual(restoredRandom.position(), originalRandom.position());
            assert.strictEqual(restored.calls.length, 6);
        });
    });

    describe("lotto node", () => {
        const definition = "root { lotto [1, 1, 1] { action [First] action [Second] action [Third] } }";

        it("keeps the child that was picked, without picking again", () => {
            const world: World = {
                First: () => State.RUNNING,
                Second: () => State.RUNNING,
                Third: () => State.RUNNING
            };

            // Find the child that each random number picks.
            const picks = [0, 0.4, 0.9].map((value) => {
                const fixture = createFixture(definition, world, { random: () => value });
                fixture.tree.step();
                return fixture.calls[0];
            });
            assert.sameMembers(picks, ["First", "Second", "Third"]);

            picks.forEach((pick, index) => {
                const original = createFixture(definition, world, { random: () => [0, 0.4, 0.9][index] });
                original.tree.step();

                // Anything the restored tree picked for itself would be a different child.
                const restoredRandom = createRandom([[0.9, 0, 0.4][index]]);
                const restored = createFixture(definition, world, { random: restoredRandom });
                restored.tree.restore(throughJSON(original.tree.snapshot()));

                restored.tree.step();
                restored.tree.step();

                assert.deepEqual(restored.calls, [pick, pick]);
                assert.strictEqual(restoredRandom.position(), 0);
            });
        });

        it("behaves the same as the original while the picked child runs and after it finishes", () => {
            let step = 0;

            for (const randomValues of [[0], [0.4], [0.9]]) {
                assertSameBehaviourFromEveryStep({
                    definition,
                    world: {
                        First: () => (step > 2 ? State.SUCCEEDED : State.RUNNING),
                        Second: () => (step > 2 ? State.FAILED : State.RUNNING),
                        Third: () => (step > 2 ? State.SUCCEEDED : State.RUNNING)
                    },
                    randomValues,
                    steps: 5,
                    beforeStep: (currentStep) => (step = currentStep)
                });
            }
        });

        it("picks again in the next run after restoring a finished tree", () => {
            const world: World = {
                First: () => State.SUCCEEDED,
                Second: () => State.SUCCEEDED,
                Third: () => State.SUCCEEDED
            };

            const originalRandom = createRandom([0, 0.9]);
            const original = createFixture(definition, world, { random: originalRandom });
            original.tree.step();
            assert.strictEqual(original.tree.getState(), State.SUCCEEDED);

            const restoredRandom = createRandom([0, 0.9]);
            restoredRandom.seek(originalRandom.position());
            const restored = createFixture(definition, world, { random: restoredRandom });
            restored.tree.restore(throughJSON(original.tree.snapshot()));

            assertSameBehaviour(original, restored, 2);
            assert.strictEqual(restoredRandom.position(), originalRandom.position());
            assert.deepEqual(restored.calls, ["Third", "First"]);
        });
    });

    describe("mix of random nodes inside a sequence that is waiting on something", () => {
        it("behaves the same as the original from every point in a run", () => {
            let step = 0;

            assertSameBehaviourFromEveryStep({
                definition: `root {
                    sequence {
                        repeat [1, 3] { lotto { action [Collect] action [Gather] } }
                        retry [2, 4] { action [WaitForApproval] }
                        repeat [2] { action [Notify] }
                    }
                }`,
                world: {
                    Collect: () => State.SUCCEEDED,
                    Gather: () => (step % 2 ? State.SUCCEEDED : State.RUNNING),
                    WaitForApproval: () => (step < 8 ? State.RUNNING : step < 10 ? State.FAILED : State.SUCCEEDED),
                    Notify: () => State.SUCCEEDED
                },
                randomValues: [0.9, 0.1, 0.6, 0.3, 0.8],
                steps: 14,
                beforeStep: (currentStep) => (step = currentStep)
            });
        });
    });
});

describe("Restoring a snapshot with an invalid property for a", () => {
    const assertRejected = (definition: string, edit: (root: any) => void, message: string) => {
        const world: World = { Work: () => State.RUNNING };
        const source = createFixture(definition, world, { random: () => 0.5 });
        source.tree.step();

        const snapshot: any = throughJSON(source.tree.snapshot());
        edit(snapshot.root);

        const { tree } = createFixture(definition, world);
        const detailsBefore = tree.getTreeNodeDetails();

        assert.throws(() => tree.restore(snapshot), Error, message);
        assert.deepEqual(tree.getTreeNodeDetails(), detailsBefore);
    };

    describe("repeat node", () => {
        const definition = "root { repeat [2, 5] { action [Work] } }";

        it("will throw an error if the iteration counts are not valid", () => {
            for (const value of [-1, 1.5, "2", undefined]) {
                assertRejected(
                    definition,
                    (root) => (root.children[0].currentIterationCount = value),
                    `invalid snapshot: expected a non-negative integer for 'currentIterationCount' of repeat node but found '${value}'`
                );
            }

            for (const value of [-1, 1.5, "2", undefined]) {
                assertRejected(
                    definition,
                    (root) => (root.children[0].targetIterationCount = value),
                    `invalid snapshot: expected null or a non-negative integer for 'targetIterationCount' of repeat node but found '${value}'`
                );
            }
        });
    });

    describe("retry node", () => {
        const definition = "root { retry [2, 5] { action [Work] } }";

        it("will throw an error if the attempt counts are not valid", () => {
            for (const value of [-1, 1.5, "2", undefined]) {
                assertRejected(
                    definition,
                    (root) => (root.children[0].currentAttemptCount = value),
                    `invalid snapshot: expected a non-negative integer for 'currentAttemptCount' of retry node but found '${value}'`
                );
            }

            for (const value of [-1, 1.5, "2", undefined]) {
                assertRejected(
                    definition,
                    (root) => (root.children[0].targetAttemptCount = value),
                    `invalid snapshot: expected null or a non-negative integer for 'targetAttemptCount' of retry node but found '${value}'`
                );
            }
        });
    });

    describe("lotto node", () => {
        const definition = "root { lotto { action [Work] action [Work] } }";

        it("will throw an error if the selected child is not valid", () => {
            for (const value of [-1, 2, 0.5, "0", undefined]) {
                assertRejected(
                    definition,
                    (root) => (root.children[0].selectedChildIndex = value),
                    "invalid snapshot: expected"
                );
            }
        });

        it("will throw an error if there is no selected child but the node has been updated", () => {
            assertRejected(
                definition,
                (root) => (root.children[0].selectedChildIndex = null),
                "invalid snapshot: expected a 'selectedChildIndex' for lotto node with a child that is not in the READY state"
            );
        });
    });
});

describe("Restoring a snapshot of a tree with a wait node", () => {
    const HOUR = 60 * 60 * 1000;

    let clock: SinonFakeTimers;

    beforeEach(() => {
        clock = sinon.useFakeTimers();
    });

    afterEach(() => {
        clock.restore();
    });

    const waitState = (fixture: Fixture) => findNode(fixture.tree, "wait").state;

    describe("that uses the clock", () => {
        const definition = "root { wait [1000] }";

        it("only waits for the time that was remaining, however long it was before the snapshot was restored", () => {
            const original = createFixture(definition, {});

            original.tree.step();
            clock.tick(400);

            const snapshot = throughJSON(original.tree.snapshot());

            // The time spent waiting to restore the snapshot, such as for a process to restart, does not count.
            clock.tick(HOUR);

            const restored = createFixture(definition, {});
            restored.tree.restore(snapshot);

            restored.tree.step();
            assert.strictEqual(waitState(restored), State.RUNNING);

            clock.tick(599);
            restored.tree.step();
            assert.strictEqual(waitState(restored), State.RUNNING);

            clock.tick(1);
            restored.tree.step();
            assert.strictEqual(waitState(restored), State.SUCCEEDED);
            assert.strictEqual(restored.tree.getState(), State.SUCCEEDED);
        });

        it("counts the time up to when the snapshot was taken, not just up to the last step of the tree", () => {
            const original = createFixture(definition, {});

            original.tree.step();
            clock.tick(700);

            const snapshot = throughJSON(original.tree.snapshot());

            clock.tick(HOUR);

            const restored = createFixture(definition, {});
            restored.tree.restore(snapshot);

            clock.tick(299);
            restored.tree.step();
            assert.strictEqual(waitState(restored), State.RUNNING);

            clock.tick(1);
            restored.tree.step();
            assert.strictEqual(waitState(restored), State.SUCCEEDED);
        });

        it("keeps waiting the same way across more than one restore", () => {
            let fixture = createFixture(definition, {});

            fixture.tree.step();

            for (let restore = 0; restore < 4; restore++) {
                clock.tick(200);

                const snapshot = throughJSON(fixture.tree.snapshot());

                clock.tick(HOUR);

                fixture = createFixture(definition, {});
                fixture.tree.restore(snapshot);
            }

            // We have waited for 800ms in total.
            clock.tick(199);
            fixture.tree.step();
            assert.strictEqual(waitState(fixture), State.RUNNING);

            clock.tick(1);
            fixture.tree.step();
            assert.strictEqual(waitState(fixture), State.SUCCEEDED);
        });

        it("only waits for the time that was remaining when it is restored to the tree it was taken from", () => {
            const { tree } = createFixture(definition, {});

            tree.step();
            clock.tick(400);

            const snapshot = tree.snapshot();

            clock.tick(900);
            tree.step();
            assert.strictEqual(tree.getState(), State.SUCCEEDED);

            clock.tick(HOUR);

            tree.restore(snapshot);
            assert.strictEqual(tree.getState(), State.RUNNING);

            tree.step();
            assert.strictEqual(tree.getState(), State.RUNNING);

            clock.tick(599);
            tree.step();
            assert.strictEqual(tree.getState(), State.RUNNING);

            clock.tick(1);
            tree.step();
            assert.strictEqual(tree.getState(), State.SUCCEEDED);
        });

        it("restores a wait that had not started as one that has not started", () => {
            const original = createFixture("root { sequence { action [Work] wait [1000] } }", {
                Work: () => State.RUNNING
            });

            original.tree.step();
            clock.tick(5000);

            const restored = createRestoredFixture(original, "root { sequence { action [Work] wait [1000] } }", {
                Work: () => State.SUCCEEDED
            });

            restored.tree.step();
            assert.strictEqual(waitState(restored), State.RUNNING);

            clock.tick(999);
            restored.tree.step();
            assert.strictEqual(waitState(restored), State.RUNNING);

            clock.tick(1);
            restored.tree.step();
            assert.strictEqual(waitState(restored), State.SUCCEEDED);
        });

        it("keeps a wait with no duration waiting indefinitely", () => {
            const original = createFixture("root { wait }", {});

            original.tree.step();
            clock.tick(HOUR);

            const snapshot = throughJSON(original.tree.snapshot());
            assert.strictEqual(snapshot.root.children![0].totalDuration, null);

            const restored = createFixture("root { wait }", {});
            restored.tree.restore(snapshot);

            for (let step = 0; step < 3; step++) {
                clock.tick(HOUR);
                restored.tree.step();

                assert.strictEqual(waitState(restored), State.RUNNING);
            }
        });

        it("behaves the same as the original from every point in a run", () => {
            assertSameBehaviourFromEveryStep({
                definition: `root {
                    sequence {
                        action [Prepare]
                        wait [1000]
                        repeat [2] { sequence { wait [400] action [Notify] } }
                    }
                }`,
                world: { Prepare: () => State.SUCCEEDED, Notify: () => State.SUCCEEDED },
                steps: 14,
                beforeStep: () => clock.tick(300)
            });
        });
    });

    describe("that uses the 'getDeltaTime' option", () => {
        const definition = "root { wait [1000] }";

        it("only waits for the time that was remaining, whatever the clock says", () => {
            const getDeltaTime = () => 0.25;
            const original = createFixture(definition, {}, { getDeltaTime });

            // This takes us to 250ms and then 500ms.
            original.tree.step();
            original.tree.step();

            const snapshot = throughJSON(original.tree.snapshot());

            clock.tick(HOUR);

            const restored = createFixture(definition, {}, { getDeltaTime });
            restored.tree.restore(snapshot);

            clock.tick(HOUR);

            restored.tree.step();
            assert.strictEqual(waitState(restored), State.RUNNING);

            restored.tree.step();
            assert.strictEqual(waitState(restored), State.SUCCEEDED);
        });

        it("does not count the time that the 'getDeltaTime' function is not asked for", () => {
            let deltaTime = 0.25;
            const original = createFixture(definition, {}, { getDeltaTime: () => deltaTime });

            original.tree.step();

            const snapshot = throughJSON(original.tree.snapshot());

            // The delta time might be much bigger by the time the tree is restored, but nothing asks for it until we step.
            deltaTime = 0.5;

            const restored = createFixture(definition, {}, { getDeltaTime: () => deltaTime });
            restored.tree.restore(snapshot);
            assert.strictEqual(waitState(restored), State.RUNNING);

            restored.tree.step();
            assert.strictEqual(waitState(restored), State.RUNNING);

            restored.tree.step();
            assert.strictEqual(waitState(restored), State.SUCCEEDED);
        });

        it("behaves the same as the original from every point in a run", () => {
            let deltaTime = 0.1;

            assertSameBehaviourFromEveryStep({
                definition: `root {
                    sequence {
                        action [Prepare]
                        wait [500]
                        repeat [2] { sequence { wait [100, 300] action [Notify] } }
                    }
                }`,
                world: { Prepare: () => State.SUCCEEDED, Notify: () => State.SUCCEEDED },
                randomValues: [0.9, 0.1],
                steps: 14,
                createOptions: () => ({ getDeltaTime: () => deltaTime }),
                beforeStep: (step) => (deltaTime = 0.05 * (step % 4))
            });
        });

        it("can be restored from a snapshot taken from a tree that uses the clock", () => {
            const original = createFixture(definition, {});

            original.tree.step();
            clock.tick(400);

            const restored = createFixture(definition, {}, { getDeltaTime: () => 0.3 });
            restored.tree.restore(throughJSON(original.tree.snapshot()));

            // 400ms plus 300ms and then another 300ms.
            restored.tree.step();
            assert.strictEqual(waitState(restored), State.RUNNING);

            restored.tree.step();
            assert.strictEqual(waitState(restored), State.SUCCEEDED);
        });

        it("can restore a snapshot taken from a tree that uses it to a tree that uses the clock", () => {
            const original = createFixture(definition, {}, { getDeltaTime: () => 0.4 });

            original.tree.step();

            const restored = createFixture(definition, {});
            restored.tree.restore(throughJSON(original.tree.snapshot()));

            clock.tick(599);
            restored.tree.step();
            assert.strictEqual(waitState(restored), State.RUNNING);

            clock.tick(1);
            restored.tree.step();
            assert.strictEqual(waitState(restored), State.SUCCEEDED);
        });

        it("has a snapshot that is unchanged by serialising it to JSON even if the delta time was not finite", () => {
            for (const deltaTime of [Infinity, -Infinity]) {
                const original = createFixture(definition, {}, { getDeltaTime: () => deltaTime });
                original.tree.step();

                const snapshot = original.tree.snapshot();
                assert.deepEqual(throughJSON(snapshot), snapshot);

                const restored = createFixture(definition, {});
                restored.tree.restore(throughJSON(snapshot));
                assert.strictEqual(restored.tree.getState(), original.tree.getState());
            }
        });
    });

    describe("that picks a random duration", () => {
        const definition = "root { wait [500, 1500] }";

        it("keeps the duration that was picked, without picking again", () => {
            // This picks a duration of 1000ms.
            const original = createFixture(definition, {}, { random: () => 0.5 });

            original.tree.step();
            clock.tick(400);

            const snapshot = throughJSON(original.tree.snapshot());

            clock.tick(HOUR);

            // A new duration picked by the restored tree would be 500ms.
            const random = createRandom([0]);
            const restored = createFixture(definition, {}, { random });
            restored.tree.restore(snapshot);

            restored.tree.step();
            assert.strictEqual(waitState(restored), State.RUNNING);

            clock.tick(599);
            restored.tree.step();
            assert.strictEqual(waitState(restored), State.RUNNING);

            clock.tick(1);
            restored.tree.step();
            assert.strictEqual(waitState(restored), State.SUCCEEDED);

            assert.strictEqual(random.position(), 0);
        });

        it("picks a new duration in the next run after restoring a finished tree", () => {
            const originalRandom = createRandom([0.5, 0]);
            const original = createFixture(definition, {}, { random: originalRandom });

            original.tree.step();
            clock.tick(1000);
            original.tree.step();
            assert.strictEqual(original.tree.getState(), State.SUCCEEDED);

            const restoredRandom = createRandom([0.5, 0]);
            restoredRandom.seek(originalRandom.position());
            const restored = createFixture(definition, {}, { random: restoredRandom });
            restored.tree.restore(throughJSON(original.tree.snapshot()));

            assert.strictEqual(restored.tree.getState(), State.SUCCEEDED);

            // The next run waits for 500ms, which is the duration that the original tree picks.
            restored.tree.step();
            assert.strictEqual(waitState(restored), State.RUNNING);

            clock.tick(499);
            restored.tree.step();
            assert.strictEqual(waitState(restored), State.RUNNING);

            clock.tick(1);
            restored.tree.step();
            assert.strictEqual(waitState(restored), State.SUCCEEDED);

            assert.strictEqual(restoredRandom.position(), originalRandom.position() + 1);
        });
    });

    describe("with an invalid snapshot", () => {
        const assertRejected = (edit: (wait: any) => void, message: string) => {
            const source = createFixture("root { wait [1000] }", {});
            source.tree.step();

            const snapshot: any = throughJSON(source.tree.snapshot());
            edit(snapshot.root.children[0]);

            const { tree } = createFixture("root { wait [1000] }", {});
            const detailsBefore = tree.getTreeNodeDetails();

            assert.throws(() => tree.restore(snapshot), Error, message);
            assert.deepEqual(tree.getTreeNodeDetails(), detailsBefore);
        };

        it("will throw an error if the total duration is not valid", () => {
            for (const value of [-1, 1.5, "1000", undefined]) {
                assertRejected(
                    (wait) => (wait.totalDuration = value),
                    `invalid snapshot: expected null or a non-negative integer for 'totalDuration' of wait node but found '${value}'`
                );
            }
        });

        it("will throw an error if the waited duration is not valid", () => {
            for (const value of ["100", null, undefined, NaN]) {
                assertRejected(
                    (wait) => (wait.waitedDuration = value),
                    `invalid snapshot: expected a finite number for 'waitedDuration' of wait node but found '${value}'`
                );
            }
        });
    });
});

describe("Taking and restoring a snapshot of a tree with a promise-based action node", () => {
    const definition = "root { sequence { action [Deploy] action [Notify] } }";

    /**
     * Gives the callbacks of a promise a chance to be called.
     */
    const settle = () => new Promise((resolve) => setImmediate(resolve));

    const createDeferred = () => {
        let resolve: (value: any) => void = () => {};
        let reject: (reason: any) => void = () => {};
        const promise = new Promise<any>((promiseResolve, promiseReject) => {
            resolve = promiseResolve;
            reject = promiseReject;
        });

        return { promise, resolve, reject };
    };

    describe("while the promise has not settled", () => {
        type Deferred = ReturnType<typeof createDeferred>;

        /**
         * Creates a world where every call to 'Deploy' returns a new promise, which are kept in the order they were made.
         */
        const createPendingWorld = (promises: Deferred[] = []): World => ({
            OnEntry: () => {},
            Deploy: () => {
                const deferred = createDeferred();
                promises.push(deferred);
                return deferred.promise;
            },
            Notify: () => State.SUCCEEDED,
            Other: () => State.RUNNING,
            Never: () => false,
            IsAllowed: () => true,
            Work: () => State.RUNNING
        });

        it("allows a snapshot to be taken, which is unchanged by serialising it to JSON", () => {
            const { tree } = createFixture(definition, createPendingWorld());

            tree.step();
            assert.strictEqual(tree.getState(), State.RUNNING);

            const snapshot = tree.snapshot();
            assert.deepEqual(throughJSON(snapshot), snapshot);
        });

        it("records the action as not yet started, and the nodes above it as running", () => {
            const { tree } = createFixture(definition, createPendingWorld());

            tree.step();

            const flatten = (node: { type: string; state: State; children?: any[] }): string[] => [
                `${node.type}:${node.state}`,
                ...(node.children ?? []).flatMap(flatten)
            ];

            assert.deepEqual(flatten(tree.snapshot().root), [
                `root:${State.RUNNING}`,
                `sequence:${State.RUNNING}`,
                `action:${State.READY}`,
                `action:${State.READY}`
            ]);
        });

        it("does not change the tree that the snapshot was taken from, which carries on waiting for its promise", async () => {
            const promises: Deferred[] = [];
            const { tree, calls } = createFixture(definition, createPendingWorld(promises));

            tree.step();

            const detailsBefore = tree.getTreeNodeDetails();
            tree.snapshot();
            assert.deepEqual(tree.getTreeNodeDetails(), detailsBefore);
            assert.strictEqual(findNode(tree, "action", "Deploy").state, State.RUNNING);

            tree.step();
            assert.deepEqual(calls, ["Deploy"]);

            promises[0].resolve(State.SUCCEEDED);
            await settle();

            tree.step();
            assert.deepEqual(calls, ["Deploy", "Notify"]);
            assert.strictEqual(tree.getState(), State.SUCCEEDED);
        });

        it("restores the action as not yet started, so that its function is called again on the next step", async () => {
            const original = createFixture(definition, createPendingWorld());
            original.tree.step();

            const restoredPromises: Deferred[] = [];
            const restored = createRestoredFixture(original, definition, createPendingWorld(restoredPromises));

            // Restoring does not call anything.
            assert.deepEqual(restored.calls, []);
            assert.deepEqual(restored.events, []);

            restored.tree.step();
            assert.deepEqual(restored.calls, ["Deploy"]);
            assert.strictEqual(restored.tree.getState(), State.RUNNING);

            // The action then waits for the promise that it was given this time, as it would on any other run.
            restored.tree.step();
            assert.deepEqual(restored.calls, ["Deploy"]);

            restoredPromises[0].resolve(State.SUCCEEDED);
            await settle();

            restored.tree.step();
            assert.deepEqual(restored.calls, ["Deploy", "Notify"]);
            assert.strictEqual(restored.tree.getState(), State.SUCCEEDED);
        });

        it("restores the action with the id that it had", () => {
            const original = createFixture(definition, createPendingWorld());
            original.tree.step();

            const restored = createRestoredFixture(original, definition, createPendingWorld());

            assert.strictEqual(
                findNode(restored.tree, "action", "Deploy").id,
                findNode(original.tree, "action", "Deploy").id
            );
        });

        it("calls the 'entry' callback of the action again, as the action is restored as not yet started", () => {
            const entryDefinition = "root { action [Deploy] entry(OnEntry, 1) }";
            const countEntryCalls = (calls: string[]) => calls.filter((call) => call.startsWith("OnEntry")).length;

            const original = createFixture(entryDefinition, createPendingWorld());
            original.tree.step();
            original.tree.step();
            assert.strictEqual(countEntryCalls(original.calls), 1);

            const restored = createRestoredFixture(original, entryDefinition, createPendingWorld());
            restored.tree.step();

            assert.strictEqual(countEntryCalls(restored.calls), 1);
            assert.strictEqual(restored.calls.filter((call) => call === "Deploy").length, 1);
        });

        it("can be restored to the tree that the snapshot was taken from, which then ignores the promise it was waiting for", async () => {
            const promises: Deferred[] = [];
            const { tree, calls } = createFixture(definition, createPendingWorld(promises));

            tree.step();
            tree.restore(throughJSON(tree.snapshot()));
            tree.step();

            assert.deepEqual(calls, ["Deploy", "Deploy"]);

            // The first promise belongs to the run that was replaced by the restore.
            promises[0].resolve(State.FAILED);
            await settle();

            tree.step();
            assert.strictEqual(tree.getState(), State.RUNNING);

            promises[1].resolve(State.SUCCEEDED);
            await settle();

            tree.step();
            assert.deepEqual(calls, ["Deploy", "Deploy", "Notify"]);
            assert.strictEqual(tree.getState(), State.SUCCEEDED);
        });

        it("restores only the pending action as not yet started, when other nodes are running or have settled", async () => {
            const parallelDefinition = `root {
                parallel {
                    action [Deploy]
                    action [Settled]
                    wait [1000]
                    sequence { action [Work] action [Notify] }
                }
            }`;

            const settled = createDeferred();

            const createParallelWorld = (): World => ({
                ...createPendingWorld(),
                Settled: () => settled.promise
            });

            const options = { getDeltaTime: () => 0.1 };

            const original = createFixture(parallelDefinition, createParallelWorld(), options);
            original.tree.step();

            settled.resolve(State.SUCCEEDED);
            await settle();

            const restored = createRestoredFixture(original, parallelDefinition, createParallelWorld(), options);
            restored.tree.step();

            // The pending action is called again and the running action is called as it would be on any step. The settled
            // action is not called again as its result is used, and the wait carries on.
            assert.deepEqual(restored.calls, ["Deploy", "Work"]);
            assert.strictEqual(findNode(restored.tree, "action", "Deploy").state, State.RUNNING);
            assert.strictEqual(findNode(restored.tree, "action", "Settled").state, State.SUCCEEDED);
            assert.strictEqual(findNode(restored.tree, "wait").state, State.RUNNING);
        });

        for (const [parent, parentDefinition] of [
            ["repeat", "root { repeat [2] { action [Deploy] } }"],
            ["retry", "root { retry [2] { action [Deploy] } }"],
            ["race", "root { race { action [Deploy] action [Other] } }"],
            ["all", "root { all { action [Deploy] action [Notify] } }"],
            ["selector", "root { selector { condition [Never] action [Deploy] } }"],
            ["lotto", "root { lotto { action [Deploy] action [Deploy] } }"],
            ["guarded sequence", "root { sequence while(IsAllowed) { action [Deploy] action [Notify] } }"]
        ]) {
            it(`restores the action below a ${parent} node as not yet started, so that the tree can carry on once it is called again`, async () => {
                const promises: Deferred[] = [];
                const options = { random: () => 0.1 };

                const original = createFixture(parentDefinition, createPendingWorld(promises), options);
                original.tree.step();
                assert.strictEqual(promises.length, 1);

                const restored = createRestoredFixture(
                    original,
                    parentDefinition,
                    createPendingWorld(promises),
                    options
                );
                restored.tree.step();

                assert.strictEqual(promises.length, 2, "expected the action function to be called again");
                assert.strictEqual(restored.tree.getState(), State.RUNNING);

                // Resolve the latest promise that the restored tree is waiting on until it has finished.
                for (let step = 0; step < 5 && restored.tree.isRunning(); step++) {
                    promises[promises.length - 1].resolve(State.SUCCEEDED);
                    await settle();
                    restored.tree.step();
                }

                assert.strictEqual(restored.tree.getState(), State.SUCCEEDED);
            });
        }
    });

    it("will allow a snapshot to be taken once the promise has settled, even before the tree is stepped again", async () => {
        const deferred = createDeferred();
        const { tree } = createFixture(definition, { Deploy: () => deferred.promise, Notify: () => State.SUCCEEDED });

        tree.step();
        deferred.resolve(State.SUCCEEDED);
        await settle();

        const snapshot = tree.snapshot();
        assert.deepEqual(throughJSON(snapshot), snapshot);
    });

    for (const outcome of [State.SUCCEEDED, State.FAILED]) {
        it(`restores a settled promise that resolved with ${outcome} so that the next step uses it`, async () => {
            const deferred = createDeferred();
            const world: World = { Deploy: () => deferred.promise, Notify: () => State.SUCCEEDED };
            const original = createFixture(definition, world);

            original.tree.step();
            deferred.resolve(outcome);
            await settle();

            const restored = createRestoredFixture(original, definition, world);

            // The action function is not called again, as the original tree would not call it.
            assertSameBehaviour(original, restored, 1);

            assert.strictEqual(findNode(restored.tree, "action", "Deploy").state, outcome);
            assert.deepEqual(restored.calls, outcome === State.SUCCEEDED ? ["Notify"] : []);
        });
    }

    it("restores a settled promise that was rejected so that the next step throws the same error", async () => {
        const deferred = createDeferred();
        const world: World = { Deploy: () => deferred.promise, Notify: () => State.SUCCEEDED };
        const original = createFixture(definition, world);

        original.tree.step();
        deferred.reject(new Error("deployment failed"));
        await settle();

        const restored = createRestoredFixture(original, definition, world);

        const message =
            "error stepping tree: action function 'Deploy' promise rejected with 'Error: deployment failed'";
        assert.throws(() => original.tree.step(), Error, message);
        assert.throws(() => restored.tree.step(), Error, message);
        assert.deepEqual(restored.calls, []);
    });

    it("restores a settled promise that resolved with an invalid value so that the next step throws the same error", async () => {
        for (const value of [undefined, "invalid", 42, { toString: undefined }]) {
            const deferred = createDeferred();
            const world: World = { Deploy: () => deferred.promise, Notify: () => State.SUCCEEDED };
            const original = createFixture(definition, world);

            original.tree.step();
            deferred.resolve(value);
            await settle();

            const restored = createRestoredFixture(original, definition, world);

            const message =
                "error stepping tree: action node promise resolved with an invalid value, expected a State.SUCCEEDED or State.FAILED value to be returned";
            assert.throws(() => original.tree.step(), Error, message);
            assert.throws(() => restored.tree.step(), Error, message);
        }
    });

    it("restores a promise that was already used as one that has been used", async () => {
        const deferred = createDeferred();
        const world: World = { Deploy: () => deferred.promise, Notify: () => State.RUNNING };
        const original = createFixture(definition, world);

        original.tree.step();
        deferred.resolve(State.SUCCEEDED);
        await settle();
        original.tree.step();

        const restored = createRestoredFixture(original, definition, world);

        assertSameBehaviour(original, restored, 3);
        assert.deepEqual(restored.calls, ["Notify", "Notify", "Notify"]);
    });

    it("calls an action that was running without a promise again on the next step, as the original would", () => {
        const world: World = { Deploy: () => State.RUNNING, Notify: () => State.SUCCEEDED };
        const original = createFixture(definition, world);

        original.tree.step();

        const restored = createRestoredFixture(original, definition, world);

        assertSameBehaviour(original, restored, 2);
        assert.deepEqual(restored.calls, ["Deploy", "Deploy"]);
    });

    describe("when an earlier promise settles after a snapshot was restored", () => {
        it("is ignored rather than used as the result of the new run of the action", async () => {
            const promises = [createDeferred(), createDeferred()];
            let calls = 0;

            const { tree } = createFixture("root { action [Deploy] }", { Deploy: () => promises[calls++].promise });

            const beforeFirstStep = tree.snapshot();

            tree.step();
            tree.restore(beforeFirstStep);
            tree.step();

            assert.strictEqual(calls, 2);

            // The promise that belongs to the first run has nothing to do with the run that the tree is now on.
            promises[0].resolve(State.SUCCEEDED);
            await settle();

            tree.step();
            assert.strictEqual(tree.getState(), State.RUNNING);

            promises[1].resolve(State.FAILED);
            await settle();

            tree.step();
            assert.strictEqual(tree.getState(), State.FAILED);
        });
    });
});

describe("Restoring a snapshot of a tree with a lotto node that was resolved by a guard before it picked a child", () => {
    for (const [guard, outcome] of [
        ["while(IsAllowed)", State.FAILED],
        ["until(IsDone)", State.FAILED]
    ] as const) {
        it(`as resolved, for a '${guard}' guard`, () => {
            const definition = `root { lotto ${guard} { action [Work] action [Work] } }`;
            const world: World = { IsAllowed: () => false, IsDone: () => true, Work: () => State.RUNNING };

            const original = createFixture(definition, world);
            original.tree.step();
            assert.strictEqual(original.tree.getState(), outcome);

            const restored = createRestoredFixture(original, definition, world);

            assert.strictEqual(restored.tree.getState(), outcome);
            assert.deepEqual(restored.tree.getTreeNodeDetails(), original.tree.getTreeNodeDetails());
            assertSameBehaviour(original, restored, 2);
        });
    }
});

describe("Restoring a snapshot that disagrees with the definition of the tree for a", () => {
    const assertRejected = (definition: string, edit: (root: any) => void, message: string, steps = 1) => {
        const world: World = { Work: () => State.RUNNING };
        const source = createFixture(definition, world, { random: () => 0.5 });

        for (let step = 0; step < steps; step++) {
            source.tree.step();
        }

        const snapshot: any = throughJSON(source.tree.snapshot());
        edit(snapshot.root);

        const { tree } = createFixture(definition, world);
        const detailsBefore = tree.getTreeNodeDetails();

        assert.throws(() => tree.restore(snapshot), Error, message);
        assert.deepEqual(tree.getTreeNodeDetails(), detailsBefore);
    };

    for (const [noun, count] of [
        ["repeat", "Iteration"],
        ["retry", "Attempt"]
    ]) {
        describe(`${noun} node`, () => {
            const target = `target${count}Count`;
            const current = `current${count}Count`;

            it("will throw an error if a fixed count does not match", () => {
                assertRejected(
                    `root { ${noun} [2] { action [Work] } }`,
                    (root) => (root.children[0][target] = 50),
                    `invalid snapshot: expected '${target}' of ${noun} node to be 2 but found '50'`
                );
            });

            it("will throw an error if there is no limit to the count but the snapshot has one", () => {
                assertRejected(
                    `root { ${noun} { action [Work] } }`,
                    (root) => (root.children[0][target] = 5),
                    `invalid snapshot: expected '${target}' of ${noun} node to be null but found '5'`
                );
            });

            it("will throw an error if the count so far is more than the target", () => {
                assertRejected(
                    `root { ${noun} [2, 5] { action [Work] } }`,
                    (root) => (root.children[0][current] = root.children[0][target] + 1),
                    `invalid snapshot: expected '${current}' of ${noun} node to be no more than '${target}' but found`
                );
            });

            it("will throw an error if the node is running but has no target for a limited count", () => {
                assertRejected(
                    `root { ${noun} [2, 5] { action [Work] } }`,
                    (root) => (root.children[0][target] = null),
                    `invalid snapshot: expected '${target}' of running ${noun} node with a defined limit not to be null`
                );
            });
        });
    }

    describe("wait node", () => {
        it("will throw an error if a fixed duration does not match", () => {
            assertRejected(
                "root { wait [1000] }",
                (root) => (root.children[0].totalDuration = 1),
                "invalid snapshot: expected 'totalDuration' of wait node to be 1000 but found '1'"
            );
        });

        it("will throw an error if there is no duration but the snapshot has one", () => {
            assertRejected(
                "root { wait }",
                (root) => (root.children[0].totalDuration = 1),
                "invalid snapshot: expected 'totalDuration' of wait node to be null but found '1'"
            );
        });

        it("will throw an error if the node is running but has no duration to wait for", () => {
            assertRejected(
                "root { wait [1000] }",
                (root) => (root.children[0].totalDuration = null),
                "invalid snapshot: expected 'totalDuration' of running wait node with a defined limit not to be null"
            );
        });
    });

    describe("action node", () => {
        it("will throw an error if a promise result is included but the node is not running", () => {
            assertRejected(
                "root { action [Work] }",
                (root) => {
                    root.children[0].state = State.READY;
                    root.state = State.READY;
                    root.children[0].updatePromiseResult = { isResolved: true, value: State.SUCCEEDED };
                },
                "invalid snapshot: unexpected 'updatePromiseResult' for action node that is not running"
            );
        });
    });

    describe("lotto node", () => {
        it("will throw an error if no child was selected but one of the children has been updated", () => {
            assertRejected(
                "root { lotto { action [Work] action [Work] } }",
                (root) => (root.children[0].selectedChildIndex = null),
                "invalid snapshot: expected a 'selectedChildIndex' for lotto node with a child that is not in the READY state"
            );
        });
    });
});

describe("Restoring a snapshot of a tree with a wait node whose delta time was not a number", () => {
    it("has a snapshot that is unchanged by serialising it to JSON", () => {
        const deltaTimes = [-Infinity, Infinity];
        const definition = "root { wait [1000] }";

        const original = createFixture(definition, {}, { getDeltaTime: () => deltaTimes.shift() ?? 0 });

        // The elapsed duration goes to negative infinity and then to infinity minus infinity, which is not a number.
        original.tree.step();
        original.tree.step();
        assert.strictEqual(original.tree.getState(), State.RUNNING);

        const snapshot = original.tree.snapshot();
        assert.deepEqual(throughJSON(snapshot), snapshot);

        const restored = createFixture(definition, {}, { getDeltaTime: () => 1 });
        restored.tree.restore(throughJSON(snapshot));
        assert.strictEqual(restored.tree.getState(), State.RUNNING);
    });
});

describe("Restoring a snapshot of a tree with", () => {
    it("guards behaves the same as the original, including when a guard stops being satisfied", () => {
        let isAllowed = true;
        let isDone = false;

        const definition = `root {
            sequence {
                action [Prepare]
                parallel {
                    sequence while(IsAllowed) {
                        action [Work] entry(OnEntry, "work") exit(OnExit, "work")
                        action [Report]
                    }
                    lotto until(IsDone) { action [Poll] action [Poll] }
                }
            }
        }`;

        const world: World = {
            IsAllowed: () => isAllowed,
            IsDone: () => isDone,
            OnEntry: () => {},
            OnExit: () => {},
            Prepare: () => State.SUCCEEDED,
            Work: () => State.RUNNING,
            Report: () => State.SUCCEEDED,
            Poll: () => State.RUNNING
        };

        for (let stoppedAt = 0; stoppedAt < 6; stoppedAt++) {
            for (const stopWith of ["while", "until"]) {
                isAllowed = true;
                isDone = false;

                assertSameBehaviourFromEveryStep({
                    definition,
                    world,
                    randomValues: [0.2, 0.8],
                    steps: 6,
                    beforeStep: (step) => {
                        isAllowed = !(stopWith === "while" && step >= stoppedAt);
                        isDone = stopWith === "until" && step >= stoppedAt;
                    }
                });
            }
        }
    });

    it("global subtrees behaves the same as the original from every point in a run", () => {
        BehaviourTree.register(
            "Celebrate",
            "root { sequence { action [Cheer] wait [500] repeat [2] { action [Cheer] } } }"
        );

        try {
            let step = 0;

            assertSameBehaviourFromEveryStep({
                definition: "root { sequence { action [Work] branch [Celebrate] branch [Celebrate] } }",
                world: { Work: () => (step > 1 ? State.SUCCEEDED : State.RUNNING), Cheer: () => State.SUCCEEDED },
                steps: 8,
                beforeStep: (currentStep) => (step = currentStep)
            });
        } finally {
            BehaviourTree.unregister("Celebrate");
        }
    });
});

describe("Restoring a snapshot into a tree with a different definition", () => {
    const definition = `root {
        sequence {
            action [Prepare, 1] entry(OnEntry, "prepare")
            wait [500]
            repeat [3] { action [Work] while(IsAllowed) }
            lotto [1, 2] { action [Left] action [Right] }
        }
    }`;

    const world: World = {
        OnEntry: () => {},
        IsAllowed: () => true,
        Prepare: () => State.SUCCEEDED,
        Work: () => State.RUNNING,
        Left: () => State.RUNNING,
        Right: () => State.RUNNING
    };

    const createMidRunFixture = (source: string | RootNodeDefinition = definition) => {
        const fixture = createFixture(source, world, { getDeltaTime: () => 0.1 });
        fixture.tree.step();
        fixture.tree.step();
        return fixture;
    };

    const assertRejected = (target: Fixture, snapshot: any, message: string | RegExp = /^invalid snapshot: /) => {
        const snapshotBefore = target.tree.snapshot();
        const detailsBefore = target.tree.getTreeNodeDetails();
        const callsBefore = [...target.calls];
        const eventsBefore = [...target.events];

        assert.throws(() => target.tree.restore(snapshot), Error, message);

        // Not even the ids of the nodes are changed.
        assert.deepEqual(target.tree.snapshot(), snapshotBefore);
        assert.deepEqual(target.tree.getTreeNodeDetails(), detailsBefore);
        assert.deepEqual(target.calls, callsBefore);
        assert.deepEqual(target.events, eventsBefore);
    };

    const MISMATCH = "the snapshot does not match the tree's definition";

    describe("records a different definition for definitions whose arguments only look the same once serialised, such as", () => {
        const hashWithArgument = (argument: any) =>
            (
                createFixture(
                    { type: "root", child: { type: "action", call: "Work", args: [argument] } },
                    world
                ).tree.snapshot() as any
            ).definitionHash;

        for (const [description, argument] of [
            ["Infinity", Infinity],
            ["NaN", NaN],
            ["undefined", undefined],
            ["negative zero", -0]
        ] as [string, any][]) {
            it(description, () => {
                const other = description === "negative zero" ? 0 : null;
                assert.notStrictEqual(hashWithArgument(argument), hashWithArgument(other));
            });
        }
    });

    describe("has a snapshot that", () => {
        it("records which definition it belongs to, in a way that survives serialisation", () => {
            const { tree } = createMidRunFixture();
            const snapshot: any = tree.snapshot();

            assert.isString(snapshot.definitionHash);
            assert.isNotEmpty(snapshot.definitionHash);
            assert.deepEqual(throughJSON(snapshot), snapshot);
        });

        it("records the same definition for any tree built from the same definition, whatever state it is in", () => {
            const first: any = createMidRunFixture().tree.snapshot();
            const second: any = createFixture(definition, world).tree.snapshot();

            assert.strictEqual(first.definitionHash, second.definitionHash);
        });

        it("records a different definition for a tree built from a different definition", () => {
            const first: any = createFixture(definition, world).tree.snapshot();
            const second: any = createFixture("root { action [Prepare] }", world).tree.snapshot();

            assert.notStrictEqual(first.definitionHash, second.definitionHash);
        });
    });

    describe("will throw an error saying that the snapshot does not match the definition, and leave the tree as it was, if the tree was built from a definition", () => {
        const variants: [string, string][] = [
            ["with an extra node", definition.replace("wait [500]", "wait [500] action [Extra]")],
            ["with a node of another type", definition.replace("repeat [3]", "retry [3]")],
            ["with a different action", definition.replace("action [Prepare, 1]", "action [Prepare2, 1]")],
            ["with different action arguments", definition.replace("action [Prepare, 1]", "action [Prepare, 2]")],
            [
                "with different action argument types",
                definition.replace("action [Prepare, 1]", 'action [Prepare, "1"]')
            ],
            ["with different nodes in the same shape", definition.replace("[Left]", "[Right]")],
            [
                "with the children in another order",
                definition.replace("action [Left] action [Right]", "action [Right] action [Left]")
            ],
            ["with a different wait duration", definition.replace("wait [500]", "wait [501]")],
            ["with a random wait duration", definition.replace("wait [500]", "wait [500, 600]")],
            ["with a different iteration count", definition.replace("repeat [3]", "repeat [4]")],
            ["with different lotto weights", definition.replace("lotto [1, 2]", "lotto [2, 1]")],
            ["with no lotto weights", definition.replace("lotto [1, 2]", "lotto")],
            ["with a different entry callback", definition.replace('"prepare"', '"unprepare"')],
            [
                "with an extra exit callback",
                definition.replace('entry(OnEntry, "prepare")', 'entry(OnEntry, "prepare") exit(OnEntry)')
            ],
            ["with a different guard", definition.replace("while(IsAllowed)", "until(IsAllowed)")],
            ["with a different guard abort outcome", definition.replace("while(IsAllowed)", "while(IsAllowed, true)")],
            ["with an extra guard", definition.replace("while(IsAllowed)", "while(IsAllowed) until(IsAllowed)")]
        ];

        for (const [description, otherDefinition] of variants) {
            it(description, () => {
                const original = createMidRunFixture();
                const other = createFixture(otherDefinition, world, { getDeltaTime: () => 0.1 });

                assertRejected(other, throughJSON(original.tree.snapshot()), MISMATCH);
            });
        }

        it("that differs only in the contents of a global subtree that it uses", () => {
            const source = "root { sequence { action [Work] branch [Celebrate] } }";

            const build = (subtree: string) => {
                BehaviourTree.register("Celebrate", subtree);
                try {
                    return createFixture(source, { Work: () => State.SUCCEEDED, Cheer: () => State.RUNNING });
                } finally {
                    BehaviourTree.unregister("Celebrate");
                }
            };

            const original = build("root { action [Cheer, 1] }");
            original.tree.step();

            const same = build("root { action [Cheer, 1] }");
            same.tree.restore(throughJSON(original.tree.snapshot()));

            const other = build("root { action [Cheer, 2] }");
            assertRejected(other, throughJSON(original.tree.snapshot()), MISMATCH);
        });

        it("that the snapshot was edited to claim to be, as the nodes are still checked against the tree", () => {
            const original = createMidRunFixture();
            const other = createFixture(definition.replace("wait [500]", "wait [501]"), world);

            const snapshot: any = throughJSON(original.tree.snapshot());
            snapshot.definitionHash = other.tree.snapshot().definitionHash;

            assertRejected(other, snapshot);
        });
    });

    describe("will restore the snapshot, as the same definition, if the tree was built from", () => {
        const equivalents: [string, string | RootNodeDefinition | RootNodeDefinition[]][] = [
            [
                "the same MDSL with other formatting and comments",
                `root { /* a */ sequence {
                action [Prepare, 1] entry(OnEntry, "prepare")
                wait [500]
                repeat [3] { action [Work] while(IsAllowed) }
                /* another comment */
                lotto [1,2] { action [Left] action [Right] } } }`
            ],
            [
                "the equivalent JSON, which leaves out the empty and default values that MDSL includes",
                {
                    type: "root",
                    child: {
                        type: "sequence",
                        children: [
                            {
                                type: "action",
                                call: "Prepare",
                                args: [1],
                                entry: { call: "OnEntry", args: ["prepare"] }
                            },
                            { type: "wait", duration: 500 },
                            {
                                type: "repeat",
                                iterations: 3,
                                child: { type: "action", call: "Work", while: { call: "IsAllowed" } }
                            },
                            {
                                type: "lotto",
                                weights: [1, 2],
                                children: [
                                    { type: "action", call: "Left" },
                                    { type: "action", call: "Right" }
                                ]
                            }
                        ]
                    }
                }
            ],
            [
                "the equivalent JSON, with the values that MDSL includes written out, and keys in another order",
                [
                    {
                        child: {
                            children: [
                                {
                                    entry: { args: ["prepare"], call: "OnEntry" },
                                    args: [1],
                                    call: "Prepare",
                                    type: "action"
                                },
                                { duration: 500, type: "wait" },
                                {
                                    child: {
                                        while: { succeedOnAbort: false, args: [], call: "IsAllowed" },
                                        args: [],
                                        call: "Work",
                                        type: "action"
                                    },
                                    iterations: 3,
                                    type: "repeat"
                                },
                                {
                                    children: [
                                        { args: [], call: "Left", type: "action" },
                                        { args: [], call: "Right", type: "action" }
                                    ],
                                    weights: [1, 2],
                                    type: "lotto"
                                }
                            ],
                            type: "sequence"
                        },
                        type: "root"
                    }
                ]
            ]
        ];

        for (const [description, otherDefinition] of equivalents) {
            it(description, () => {
                const original = createMidRunFixture();
                const restored = createFixture(otherDefinition as any, world, { getDeltaTime: () => 0.1 });

                restored.tree.restore(throughJSON(original.tree.snapshot()));

                assert.deepEqual(restored.tree.getTreeNodeDetails(), original.tree.getTreeNodeDetails());
                assertSameBehaviour(original, restored, 3);
            });
        }

        it("MDSL, from a snapshot of a tree built from the equivalent JSON, and the other way around", () => {
            const mdsl = "root { sequence { action [Work, 1, $name] wait [100, 200] } }";
            const json: RootNodeDefinition = {
                type: "root",
                child: {
                    type: "sequence",
                    children: [
                        { type: "action", call: "Work", args: [1, { $: "name" }] },
                        { type: "wait", duration: [100, 200] }
                    ]
                }
            };
            const agentWorld: World = { Work: () => State.SUCCEEDED };

            const fromMDSL = createFixture(mdsl, agentWorld);
            const fromJSON = createFixture(json, agentWorld);
            fromMDSL.tree.step();
            fromJSON.tree.step();

            assert.doesNotThrow(() => fromJSON.tree.restore(throughJSON(fromMDSL.tree.snapshot())));
            assert.doesNotThrow(() => fromMDSL.tree.restore(throughJSON(fromJSON.tree.snapshot())));
        });

        it("a definition whose named root nodes are in a different order", () => {
            const main = { type: "root", child: { type: "branch", ref: "A" } } as RootNodeDefinition;
            const a = { type: "root", id: "A", child: { type: "action", call: "Work" } } as RootNodeDefinition;
            const b = { type: "root", id: "B", child: { type: "action", call: "Work" } } as RootNodeDefinition;

            const first = createFixture([main, a, b] as any, { Work: () => State.RUNNING });
            first.tree.step();

            const second = createFixture([b, a, main] as any, { Work: () => State.RUNNING });

            assert.doesNotThrow(() => second.tree.restore(throughJSON(first.tree.snapshot())));
        });
    });

    describe("will throw an error, and leave the tree as it was, if the value is not a snapshot", () => {
        const notSnapshots: [string, any][] = [
            ["undefined", undefined],
            ["null", null],
            ["a string", "snapshot"],
            ["a JSON string of a snapshot", JSON.stringify({ version: 1 })],
            ["a number", 1],
            ["a boolean", true],
            ["an array", []],
            ["an array of a snapshot", [{ version: 1 }]],
            ["an empty object", {}],
            ["an object without the snapshot's fields", { name: "tree", state: State.RUNNING }],
            ["a function", () => {}]
        ];

        for (const [description, value] of notSnapshots) {
            it(description, () => {
                assertRejected(createMidRunFixture(), value);
            });
        }

        it("an object with only the version of a snapshot", () => {
            assertRejected(createMidRunFixture(), { version: 1 });
        });

        it("an object with the version and root of a snapshot but no definition", () => {
            const snapshot: any = throughJSON(createMidRunFixture().tree.snapshot());
            delete snapshot.definitionHash;

            assertRejected(createMidRunFixture(), snapshot);
        });

        it("an object whose definition is not a string", () => {
            for (const definitionHash of [null, 1, {}, ["a"], true]) {
                const snapshot: any = throughJSON(createMidRunFixture().tree.snapshot());
                snapshot.definitionHash = definitionHash;

                assertRejected(createMidRunFixture(), snapshot);
            }
        });
    });
});
