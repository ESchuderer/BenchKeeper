# Snapshot and restore of tree execution state

Status: done

## Request

Long-running workflows (hours/days, process restarts). Let an application persist a tree's execution
state and restore it into a tree built from the same definition. Storage and scheduling stay in the app.

## API

- `BehaviourTree#snapshot(): BehaviourTreeSnapshot` – plain JSON-safe object (no functions, class
  instances, `undefined`, `NaN`/`Infinity`). `JSON.parse(JSON.stringify(s))` deep-equals `s`.
- `BehaviourTree#restore(snapshot): void` – validates, then applies. Throws `invalid snapshot: ...`
  and leaves the tree untouched if the snapshot is malformed, is not a snapshot at all, belongs to another
  definition (`invalid snapshot: snapshot does not match the tree's definition`) or does not fit the tree.
- `BehaviourTreeSnapshot` is exported as a type from `src/index.ts`.

## Format

```
BehaviourTreeSnapshot = { version: 1, definitionFingerprint: string, root: NodeSnapshot }
NodeSnapshot          = { type, state, ...type specific }   // mirrors the node tree
```

`state` is the `State` enum string. Composite and decorator nodes carry `children: NodeSnapshot[]`
in definition order, so "which children are done/running" is just the child states. Nodes are matched
by position and checked by `type` (node ids are random per tree instance and are NOT part of the snapshot).

| node | extra state kept |
| --- | --- |
| root, sequence, selector, parallel, race, all, flip, succeed, fail | `children` only |
| condition | none |
| lotto | `selectedChild: number \| null` (index of the drawn child; null is valid unless running, as a guard can resolve a lotto before it draws) |
| repeat | `targetIterationCount: number \| null`, `currentIterationCount` |
| retry | `targetAttemptCount: number \| null`, `currentAttemptCount` |
| wait | `totalDuration: number \| null` (random choice included), `waitedDuration` (ms) |
| action | `updatePromiseResult`: settled-but-unconsumed promise result or `null`. A pending promise is saved as `state: READY` with `null` |

Not state (rebuilt from the definition): attributes/guards/callbacks, names, args, options.

## Decisions

- **Wait timing.** The snapshot stores *time already waited*, never a timestamp. With `Date`, a running
  wait stores `now - initialUpdateTime` at snapshot time; with `getDeltaTime` it stores the accumulated
  `waitedDuration`. On restore `initialUpdateTime = now - waitedDuration`, so time between snapshot and
  restore is not counted in either mode.
- **Finished tree.** States are restored verbatim; `step()` already resets a finished root, and each node
  re-draws its random choices when it next starts from READY. Nothing special needed.
- **Silent restore.** `restore` does not fire `onNodeStateChange`; the original tree already emitted those
  transitions and replaying them would double-trigger application side effects. `getTreeNodeDetails()`
  shows the restored states.
- **Promise-based actions.** A pending promise cannot be serialised, so `snapshot()` saves an action that awaits an
  unsettled promise as *not yet started*: `state: READY`, `updatePromiseResult: null`. The restored tree calls the action
  function (and the `entry` callback, as for any node starting from READY) again on its next step, so its side effects
  can happen twice; documented in the README next to the API. `snapshot()` never throws for this. A settled result not
  yet consumed by a step is kept (rejection reasons are stringified, which is all the error message uses). Long waits
  that must survive restarts should be non-promise actions returning RUNNING.
- **Stale promises.** A promise still in flight from before `restore()`/`reset()` must not overwrite the
  restored action state, so the action ignores settlements from promises it no longer tracks.
- **Atomic restore.** Validate the whole snapshot against the tree first, then apply.
- **Definition fingerprint.** Matching nodes by position and type is not enough: a snapshot of a tree that only
  differs in e.g. an action name or a wait duration fits and silently corrupts the tree. The snapshot carries
  `definitionFingerprint`, a 53-bit hash (it guards against mistakes, not forgery) of the validated JSON definition in
  canonical form: properties sorted, undefined values and the defaults the MDSL parser always writes
  (`args: []`, `succeedOnAbort: false`) left out, main root first and the named roots sorted by id. So MDSL and the
  equivalent JSON give the same fingerprint, and layout, comments and property order do not matter. Checked after the
  snapshot shape and `version` and before any node, so a mismatch is reported as such rather than as a structure error.
  Globally registered functions and subtrees are not part of the definition (documented), so a changed registered
  subtree with the same structure is not noticed.

## Tests (test-first)

Differential harness: for every step count k, snapshot a running tree, restore into a fresh tree with a
forked agent, and step both in lockstep, asserting identical node states, identical agent call log and
identical result. The restored tree gets a *different* `random`, so any re-drawn random choice shows up.
Plus explicit tests for JSON survival, validation errors, wait timing (Date and getDeltaTime, with time
passing between snapshot and restore), finished trees, promises, and no `onNodeStateChange` on restore.

## Release

Minor bump 4.3.1 -> 4.4.0, README method docs + example + Version History row, rebuilt `dist/` (tracked).
