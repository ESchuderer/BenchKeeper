import {
    NodeDefinition,
    RootNodeDefinition,
    DecoratorNodeDefinition,
    CompositeNodeDefinition,
    AnyNodeDefinition,
    BranchNodeDefinition
} from "./BehaviourTreeDefinition";

/**
 * A type guard function that returns true if the specified node satisfies the RootNodeDefinition type.
 * @param node The node.
 * @returns A value of true if the specified node satisfies the RootNodeDefinition type.
 */
export function isRootNodeDefinition(node: NodeDefinition): node is RootNodeDefinition {
    return node.type === "root";
}

/**
 * A type guard function that returns true if the specified node satisfies the BranchNodeDefinition type.
 * @param node The node.
 * @returns A value of true if the specified node satisfies the BranchNodeDefinition type.
 */
export function isBranchNodeDefinition(node: NodeDefinition): node is BranchNodeDefinition {
    return node.type === "branch";
}

/**
 * A type guard function that returns true if the specified node satisfies the NodeDefinition type.
 * @param node The node.
 * @returns A value of true if the specified node satisfies the NodeDefinition type.
 */
export function isLeafNodeDefinition(node: NodeDefinition): node is NodeDefinition {
    return ["branch", "action", "condition", "wait"].includes(node.type);
}

/**
 * A type guard function that returns true if the specified node satisfies the DecoratorNodeDefinition type.
 * @param node The node.
 * @returns A value of true if the specified node satisfies the DecoratorNodeDefinition type.
 */
export function isDecoratorNodeDefinition(node: NodeDefinition): node is DecoratorNodeDefinition {
    return ["root", "repeat", "retry", "flip", "succeed", "fail"].includes(node.type);
}

/**
 * A type guard function that returns true if the specified node satisfies the CompositeNodeDefinition type.
 * @param node The node.
 * @returns A value of true if the specified node satisfies the CompositeNodeDefinition type.
 */
export function isCompositeNodeDefinition(node: NodeDefinition): node is CompositeNodeDefinition {
    return ["sequence", "selector", "lotto", "parallel", "race", "all"].includes(node.type);
}

/**
 * Flatten a node definition into an array of all of its nested node definitions.
 * @param nodeDefinition The node definition to flatten.
 * @returns An array of all of nested node definitions.
 */
export function flattenDefinition(nodeDefinition: AnyNodeDefinition): AnyNodeDefinition[] {
    const nodes: AnyNodeDefinition[] = [];

    const processNode = (currentNodeDefinition: AnyNodeDefinition) => {
        nodes.push(currentNodeDefinition);

        if (isCompositeNodeDefinition(currentNodeDefinition)) {
            currentNodeDefinition.children.forEach(processNode);
        } else if (isDecoratorNodeDefinition(currentNodeDefinition)) {
            processNode(currentNodeDefinition.child);
        }
    };

    processNode(nodeDefinition);

    return nodes;
}

/**
 * Determines whether the passed value is an integer.
 * @param value The value to check.
 * @returns Whether the passed value is an integer.
 */
export function isInteger(value: unknown): boolean {
    return typeof value === "number" && Math.floor(value) === value;
}

/**
 * Determines whether the passed value is null or undefined.
 * @param value The value to check.
 * @returns Whether the passed value is null or undefined.
 */
export function isNullOrUndefined(value: unknown): boolean {
    return typeof value === "undefined" || value === null;
}

/**
 * Creates a copy of a definition value in a canonical form, so that definitions that mean the same thing are identical regardless of how they were written.
 * Properties are sorted by name, and properties that are undefined or have the value that the tree builder falls back to
 * (an empty 'args' array and a 'succeedOnAbort' value of false) are left out, as the MDSL parser always adds these but JSON definitions do not need to.
 * @param value The definition value.
 * @returns The canonical form of the definition value.
 */
function canonicaliseDefinitionValue(value: unknown): unknown {
    if (Array.isArray(value)) {
        return value.map(canonicaliseDefinitionValue);
    }

    if (typeof value !== "object" || value === null) {
        return value;
    }

    const canonical: { [key: string]: unknown } = {};

    for (const key of Object.keys(value).sort()) {
        const propertyValue = (value as { [key: string]: unknown })[key];

        const isUndefined = typeof propertyValue === "undefined";
        const isDefaultArgs = key === "args" && Array.isArray(propertyValue) && propertyValue.length === 0;
        const isDefaultSucceedOnAbort = key === "succeedOnAbort" && propertyValue === false;

        if (!isUndefined && !isDefaultArgs && !isDefaultSucceedOnAbort) {
            canonical[key] = canonicaliseDefinitionValue(propertyValue);
        }
    }

    return canonical;
}

/**
 * Creates a fingerprint of a tree definition, which is the same for any two definitions that mean the same thing, such as an MDSL definition
 * and the equivalent JSON definition, and which is different for definitions that do not. It does not take any globally registered subtrees or functions into account.
 * This is a 53-bit hash to guard against restoring a snapshot to the wrong tree by mistake, it is not secure against someone who is trying to forge one.
 * @param rootNodeDefinitions The validated root node definitions, as JSON.
 * @returns The fingerprint of the definition, a string of hexadecimal digits.
 */
export function createDefinitionFingerprint(rootNodeDefinitions: RootNodeDefinition[]): string {
    // The main root node is the one without an 'id', and the order in which the other root nodes are defined does not change the tree.
    const mainRootNode = rootNodeDefinitions.find(({ id }) => typeof id === "undefined");
    const subRootNodes = rootNodeDefinitions
        .filter(({ id }) => typeof id !== "undefined")
        .sort((a, b) => (a.id! < b.id! ? -1 : a.id! > b.id! ? 1 : 0));

    const serialised = JSON.stringify(canonicaliseDefinitionValue([mainRootNode, ...subRootNodes]));

    // This is the cyrb53 hash.
    let h1 = 0xdeadbeef;
    let h2 = 0x41c6ce57;

    for (let index = 0; index < serialised.length; index++) {
        const code = serialised.charCodeAt(index);
        h1 = Math.imul(h1 ^ code, 2654435761);
        h2 = Math.imul(h2 ^ code, 1597334677);
    }

    h1 = Math.imul(h1 ^ (h1 >>> 16), 2246822507) ^ Math.imul(h2 ^ (h2 >>> 13), 3266489909);
    h2 = Math.imul(h2 ^ (h2 >>> 16), 2246822507) ^ Math.imul(h1 ^ (h1 >>> 13), 3266489909);

    return (4294967296 * (2097151 & h2) + (h1 >>> 0)).toString(16).padStart(14, "0");
}
