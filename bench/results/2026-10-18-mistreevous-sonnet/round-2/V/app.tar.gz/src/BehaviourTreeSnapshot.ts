import { AnyState } from "./State";

/**
 * The snapshot of a node that holds no execution state beyond the state of the node itself and the state of its children.
 */
export type StructuralNodeSnapshot = {
    /**
     * The tree node type.
     */
    type: "root" | "sequence" | "selector" | "parallel" | "race" | "all" | "flip" | "succeed" | "fail";
    /**
     * The state of the tree node.
     */
    state: AnyState;
    /**
     * The snapshots of the child nodes, in the order in which they are defined.
     */
    children: NodeSnapshot[];
};

/**
 * The snapshot of a lotto node.
 */
export type LottoNodeSnapshot = {
    type: "lotto";
    state: AnyState;
    children: NodeSnapshot[];
    /**
     * The index of the child node that was picked, or null if no child has been picked yet.
     */
    selectedChild: number | null;
};

/**
 * The snapshot of a repeat node.
 */
export type RepeatNodeSnapshot = {
    type: "repeat";
    state: AnyState;
    children: NodeSnapshot[];
    /**
     * The number of iterations to complete, including a random choice that was made between a minimum and maximum, or null if repeating indefinitely.
     */
    targetIterationCount: number | null;
    /**
     * The number of iterations completed.
     */
    currentIterationCount: number;
};

/**
 * The snapshot of a retry node.
 */
export type RetryNodeSnapshot = {
    type: "retry";
    state: AnyState;
    children: NodeSnapshot[];
    /**
     * The number of attempts to make, including a random choice that was made between a minimum and maximum, or null if retrying indefinitely.
     */
    targetAttemptCount: number | null;
    /**
     * The number of failed attempts made.
     */
    currentAttemptCount: number;
};

/**
 * The snapshot of a wait node.
 */
export type WaitNodeSnapshot = {
    type: "wait";
    state: AnyState;
    /**
     * The total duration in milliseconds that the node will wait for, including a random choice that was made between a minimum
     * and maximum, or null if waiting indefinitely.
     */
    totalDuration: number | null;
    /**
     * The duration in milliseconds that the node has already waited for. Time that passes between taking a snapshot and
     * restoring it does not count towards this.
     */
    waitedDuration: number;
};

/**
 * The snapshot of a condition node.
 */
export type ConditionNodeSnapshot = {
    type: "condition";
    state: AnyState;
};

/**
 * The snapshot of an action node.
 */
export type ActionNodeSnapshot = {
    type: "action";
    state: AnyState;
    /**
     * The result of the promise returned by the action function, or null if the action function did not return a promise or the promise is still pending.
     * A promise that is pending cannot be saved, so the action is instead saved with a state of READY, as if it had not started, and is restored as such.
     */
    updatePromiseResult: {
        /**
         * Whether the promise was resolved rather than rejected.
         */
        isResolved: boolean;
        /**
         * The resolved state, or null if the promise resolved with an invalid state. For a rejected promise, this is the rejection reason as a string.
         */
        value: string | null;
    } | null;
};

/**
 * The snapshot of the execution state of a tree node.
 */
export type NodeSnapshot =
    | StructuralNodeSnapshot
    | LottoNodeSnapshot
    | RepeatNodeSnapshot
    | RetryNodeSnapshot
    | WaitNodeSnapshot
    | ConditionNodeSnapshot
    | ActionNodeSnapshot;

/**
 * The snapshot of the execution state of a behaviour tree.
 * This is a plain object that is unchanged by serialising it to JSON and parsing it again.
 */
export type BehaviourTreeSnapshot = {
    /**
     * The snapshot format version.
     */
    version: 1;
    /**
     * The fingerprint of the definition of the tree that the snapshot was taken from. A snapshot can only be restored to a tree with the same fingerprint,
     * which is the case for any tree built from the same definition, whether it was defined as MDSL or as the equivalent JSON.
     */
    definitionFingerprint: string;
    /**
     * The snapshot of the root node, which includes the snapshot of every nested node.
     */
    root: NodeSnapshot;
};
