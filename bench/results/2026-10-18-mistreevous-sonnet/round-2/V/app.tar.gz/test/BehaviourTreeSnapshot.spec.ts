import { assert } from "chai";
import sinon, { SinonFakeTimers } from "sinon";

import { BehaviourTree, BehaviourTreeSnapshot, State } from "../src/index";
import { Agent } from "../src/Agent";
import { BehaviourTreeOptions } from "../src/BehaviourTreeOptions";
import { RootNodeDefinition } from "../src/BehaviourTreeDefinition";
import { NodeDetails } from "../src/nodes/Node";

/**
 * A function that decides the result of an agent function based on how many times it has been called, starting at zero.
 */
type ScriptedFunction = (callNumber: number) => State | boolean | undefined;

/**
 * A scripted agent along with the log of every function call made on it.
 */
type ScriptedAgent = {
    agent: Agent;
    log: string[];
    callCounts: { [name: string]: number };
};

/**
 * Create an agent whose functions are driven by a script and which logs every call (name and arguments) that is made to it.
 * @param script The scripted functions, by name.
 * @param callCounts The initial call counts, used to fork the state of an agent that already has a history.
 */
function createScriptedAgent(
    script: { [name: string]: ScriptedFunction },
    callCounts: { [name: string]: number } = {}
): ScriptedAgent {
    const log: string[] = [];
    const agent: Agent = {};
    const counts = { ...callCounts };

    for (const [name, scriptedFunction] of Object.entries(script)) {
        agent[name] = (...args: any[]) => {
            const callNumber = counts[name] ?? 0;
            counts[name] = callNumber + 1;
            log.push(`${name}(${args.map((arg) => JSON.stringify(arg)).join(",")})`);
            return scriptedFunction(callNumber);
        };
    }

    return { agent, log, callCounts: counts };
}

/**
 * Flatten the details of every node in a tree into a comparable list of node types, names and states, ignoring the random node ids.
 */
function getNodeStates(tree: BehaviourTree): string[] {
    const states: string[] = [];

    const visit = (node: NodeDetails) => {
        states.push(`${node.type} ${node.name} ${node.state}`);
        (node.children ?? []).forEach(visit);
    };

    visit(tree.getTreeNodeDetails());

    return states;
}

/**
 * A snapshot as it would be after being persisted by an application.
 */
function persist(snapshot: BehaviourTreeSnapshot): BehaviourTreeSnapshot {
    return JSON.parse(JSON.stringify(snapshot));
}

type BehaviourComparison = {
    definition: string | RootNodeDefinition;
    script: { [name: string]: ScriptedFunction };
    /**
     * Creates the options for a tree, other than 'random' which is controlled by 'useRandom'.
     */
    createOptions?: () => BehaviourTreeOptions;
    /**
     * Whether the trees should be given a 'random' function. The restored tree continues the sequence of random numbers from
     * the point that the original tree had reached when the snapshot was taken, so any random choice that is made again by the
     * restored tree rather than restored will take a different value to the one that the original tree took.
     */
    useRandom?: boolean;
    /**
     * Called after both trees have been stepped, to advance any fake clock.
     */
    onStepped?: () => void;
    maxSteps: number;
};

/**
 * Assert that for every point in a tree's execution, a tree restored from a snapshot taken at that point carries on exactly like
 * the original tree does: the same node states, the same agent function calls in the same order, and the same result.
 * @returns The number of snapshots that were taken while the tree was running.
 */
function assertRestoredTreeBehavesLikeOriginal(comparison: BehaviourComparison): number {
    const { definition, script, maxSteps, onStepped = () => {} } = comparison;
    const createOptions = comparison.createOptions ?? (() => ({}));
    const createRandom = (counter: { drawn: number }) => () =>
        RANDOM_SEQUENCE[counter.drawn++ % RANDOM_SEQUENCE.length];
    let runningSnapshotCount = 0;

    for (let stepsBeforeSnapshot = 0; stepsBeforeSnapshot <= maxSteps; stepsBeforeSnapshot++) {
        const original = createScriptedAgent(script);
        const originalRandom = { drawn: 0 };
        const originalTree = new BehaviourTree(definition, original.agent, {
            ...createOptions(),
            ...(comparison.useRandom ? { random: createRandom(originalRandom) } : {})
        });

        for (let step = 0; step < stepsBeforeSnapshot; step++) {
            originalTree.step();
            onStepped();
        }

        // Take the snapshot, and give the restored tree an agent that has the same history as the original agent.
        const snapshot = persist(originalTree.snapshot());
        const originalLogLengthAtSnapshot = original.log.length;
        const restored = createScriptedAgent(script, original.callCounts);
        const restoredRandom = { drawn: originalRandom.drawn };
        const restoredTree = new BehaviourTree(definition, restored.agent, {
            ...createOptions(),
            ...(comparison.useRandom ? { random: createRandom(restoredRandom) } : {})
        });
        restoredTree.restore(snapshot);

        if (originalTree.isRunning()) {
            runningSnapshotCount++;
        }

        const context = `after ${stepsBeforeSnapshot} steps`;
        assert.deepEqual(getNodeStates(restoredTree), getNodeStates(originalTree), `node states ${context}`);
        assert.equal(restoredTree.getState(), originalTree.getState(), `tree state ${context}`);

        // Carry on until the original tree has finished, we are not interested in what happens when a finished tree starts again.
        for (let step = 1; step <= maxSteps; step++) {
            if (originalTree.getState() === State.SUCCEEDED || originalTree.getState() === State.FAILED) {
                break;
            }

            originalTree.step();
            restoredTree.step();
            onStepped();

            const stepContext = `${context} and ${step} more steps`;
            assert.deepEqual(getNodeStates(restoredTree), getNodeStates(originalTree), `node states ${stepContext}`);
            assert.deepEqual(
                restored.log,
                original.log.slice(originalLogLengthAtSnapshot),
                `agent function calls ${stepContext}`
            );
        }

        assert.equal(restoredTree.getState(), originalTree.getState(), `result ${context}`);
    }

    return runningSnapshotCount;
}

/**
 * A sequence of random numbers that does not repeat quickly.
 */
const RANDOM_SEQUENCE = [0, 0.99, 0.5, 0.2, 0.8, 0.1, 0.65, 0.35, 0.9, 0.05];

const RUNNING_THEN_SUCCEEDED = (stepsToRun: number): ScriptedFunction => {
    return (callNumber) => (callNumber % (stepsToRun + 1) === stepsToRun ? State.SUCCEEDED : undefined);
};

const RUNNING_THEN_FAILED = (stepsToRun: number): ScriptedFunction => {
    return (callNumber) => (callNumber % (stepsToRun + 1) === stepsToRun ? State.FAILED : undefined);
};

describe("A behaviour tree", () => {
    describe("has a snapshot() method that", () => {
        it("returns the execution state as a plain object that is unchanged by a JSON round trip", () => {
            const { agent } = createScriptedAgent({
                work: RUNNING_THEN_SUCCEEDED(3),
                check: () => true
            });
            const tree = new BehaviourTree(
                "root { sequence { condition [check] repeat [2] { wait [10, 20] } action [work] } }",
                agent
            );

            for (let step = 0; step < 3; step++) {
                const snapshot = tree.snapshot();

                assert.deepEqual(JSON.parse(JSON.stringify(snapshot)), snapshot);
                assert.deepEqual(persist(snapshot), snapshot);

                tree.step();
            }
        });

        it("returns a snapshot that is not changed by later steps of the tree", () => {
            const { agent } = createScriptedAgent({ work: RUNNING_THEN_SUCCEEDED(3) });
            const tree = new BehaviourTree("root { sequence { action [work] action [work] } }", agent);

            tree.step();

            const snapshot = tree.snapshot();
            const snapshotAtTimeOfSnapshot = JSON.stringify(snapshot);

            tree.step();
            tree.step();
            tree.step();

            assert.equal(JSON.stringify(snapshot), snapshotAtTimeOfSnapshot);
        });

        it("can be taken from a tree that has not been stepped", () => {
            const { agent } = createScriptedAgent({ work: RUNNING_THEN_SUCCEEDED(1) });
            const tree = new BehaviourTree("root { action [work] }", agent);

            const freshTree = new BehaviourTree("root { action [work] }", agent);
            freshTree.restore(persist(tree.snapshot()));

            assert.deepEqual(getNodeStates(freshTree), getNodeStates(tree));
            assert.equal(freshTree.getState(), State.READY);
        });
    });

    describe("has a restore() method that", () => {
        it("makes a tree built from the same definition behave exactly like the tree the snapshot was taken from", () => {
            const definitions: { [description: string]: string } = {
                sequence: "root { sequence { action [a] action [b] action [c] } }",
                selector: "root { selector { action [a] action [b] action [c] } }",
                parallel: "root { parallel { action [a] sequence { action [b] action [c] } action [d] } }",
                race: "root { race { sequence { action [a] action [b] } action [c] action [d] } }",
                all: "root { all { sequence { action [a] action [b] } action [c] action [d] } }",
                flip: "root { sequence { flip { action [a] } action [b] } }",
                succeed: "root { sequence { succeed { action [a] } action [b] } }",
                fail: "root { selector { fail { action [a] } action [b] } }",
                conditions: "root { sequence { condition [yes] action [a] selector { condition [no] action [b] } } }",
                callbacks:
                    "root { sequence entry(onEntry) exit(onExit) step(onStep) { action [a] entry(onEntry, 1) action [b] exit(onExit, 2) } }",
                guards: "root { sequence { action [a] while(stillGoing) action [b] until(thresholdMet) } }",
                "nested composites":
                    "root { selector { sequence { action [a] selector { action [b] action [c] } } parallel { action [c] action [d] } } }"
            };

            for (const [description, definition] of Object.entries(definitions)) {
                const runningSnapshotCount = assertRestoredTreeBehavesLikeOriginal({
                    definition,
                    script: {
                        a: RUNNING_THEN_SUCCEEDED(2),
                        b: RUNNING_THEN_FAILED(1),
                        c: RUNNING_THEN_SUCCEEDED(3),
                        d: RUNNING_THEN_SUCCEEDED(1),
                        yes: () => true,
                        no: () => false,
                        onEntry: () => undefined,
                        onExit: () => undefined,
                        onStep: () => undefined,
                        stillGoing: (callNumber) => callNumber < 5,
                        thresholdMet: (callNumber) => callNumber > 7
                    },
                    maxSteps: 12
                });

                assert.isAbove(runningSnapshotCount, 0, `${description} was never snapshotted while running`);
            }
        });

        it("makes a tree built from a subtree reference behave exactly like the tree the snapshot was taken from", () => {
            const definition = [
                {
                    type: "root",
                    child: {
                        type: "sequence",
                        children: [
                            { type: "branch", ref: "work" },
                            { type: "branch", ref: "work" }
                        ]
                    }
                },
                {
                    type: "root",
                    id: "work",
                    child: {
                        type: "sequence",
                        children: [
                            { type: "action", call: "a" },
                            { type: "action", call: "b" }
                        ]
                    }
                }
            ] as any;

            const runningSnapshotCount = assertRestoredTreeBehavesLikeOriginal({
                definition,
                script: { a: RUNNING_THEN_SUCCEEDED(1), b: RUNNING_THEN_SUCCEEDED(2) },
                maxSteps: 12
            });

            assert.isAbove(runningSnapshotCount, 0);
        });

        it("can rewind the same tree instance to an earlier snapshot", () => {
            const { agent } = createScriptedAgent({ a: RUNNING_THEN_SUCCEEDED(1), b: RUNNING_THEN_SUCCEEDED(1) });
            const tree = new BehaviourTree("root { sequence { action [a] action [b] } }", agent);

            tree.step();
            const snapshot = persist(tree.snapshot());
            const statesAtSnapshot = getNodeStates(tree);

            tree.step();
            tree.step();
            assert.notDeepEqual(getNodeStates(tree), statesAtSnapshot);

            tree.restore(snapshot);

            assert.deepEqual(getNodeStates(tree), statesAtSnapshot);
            assert.deepEqual(persist(tree.snapshot()), snapshot);
        });

        it("can restore the same snapshot more than once", () => {
            const definition = "root { sequence { action [a] action [b] } }";
            const { agent } = createScriptedAgent({ a: RUNNING_THEN_SUCCEEDED(1), b: RUNNING_THEN_SUCCEEDED(1) });
            const tree = new BehaviourTree(definition, agent);
            tree.step();
            tree.step();
            const snapshot = persist(tree.snapshot());

            const first = new BehaviourTree(definition, agent);
            const second = new BehaviourTree(definition, agent);
            first.restore(snapshot);
            second.restore(snapshot);

            assert.deepEqual(getNodeStates(first), getNodeStates(tree));
            assert.deepEqual(getNodeStates(second), getNodeStates(tree));
        });

        it("does not call the onNodeStateChange option", () => {
            const definition = "root { sequence { action [a] action [b] } }";
            const { agent } = createScriptedAgent({ a: RUNNING_THEN_SUCCEEDED(1), b: RUNNING_THEN_SUCCEEDED(1) });
            const tree = new BehaviourTree(definition, agent);
            tree.step();
            tree.step();
            const snapshot = persist(tree.snapshot());

            const changes: unknown[] = [];
            const restoredTree = new BehaviourTree(definition, agent, { onNodeStateChange: (c) => changes.push(c) });
            restoredTree.restore(snapshot);

            assert.deepEqual(changes, []);
        });

        describe("will throw an error and leave the tree untouched if", () => {
            const definition = "root { sequence { action [a] selector { action [b] action [c] } } }";

            const createTrees = () => {
                const { agent } = createScriptedAgent({
                    a: RUNNING_THEN_SUCCEEDED(1),
                    b: RUNNING_THEN_FAILED(2),
                    c: RUNNING_THEN_SUCCEEDED(2)
                });
                const source = new BehaviourTree(definition, agent);
                source.step();
                source.step();
                source.step();

                const target = new BehaviourTree(definition, agent);
                target.step();

                return { snapshot: persist(source.snapshot()), target };
            };

            const assertRestoreThrows = (mutate: (snapshot: any) => any, message: string) => {
                const { snapshot, target } = createTrees();
                const statesBefore = getNodeStates(target);
                const snapshotBefore = persist(target.snapshot());

                assert.throws(() => target.restore(mutate(snapshot)), Error, message);

                assert.deepEqual(getNodeStates(target), statesBefore);
                assert.deepEqual(persist(target.snapshot()), snapshotBefore);
            };

            it("the snapshot is not an object", () => {
                assertRestoreThrows(() => null, "invalid snapshot: expected an object");
                assertRestoreThrows(() => undefined, "invalid snapshot: expected an object");
                assertRestoreThrows(() => "snapshot", "invalid snapshot: expected an object");
                assertRestoreThrows(() => 42, "invalid snapshot: expected an object");
                assertRestoreThrows(() => true, "invalid snapshot: expected an object");
                assertRestoreThrows(() => [], "invalid snapshot: expected an object");
                assertRestoreThrows((s) => [s], "invalid snapshot: expected an object");
            });

            it("the snapshot is an object without the fields of a snapshot", () => {
                assertRestoreThrows(() => ({}), "invalid snapshot: unsupported version 'undefined'");
                assertRestoreThrows(() => ({ name: "snapshot" }), "invalid snapshot: unsupported version 'undefined'");
                assertRestoreThrows(() => ({ version: 1 }), "invalid snapshot: expected a definition fingerprint");
                assertRestoreThrows(
                    ({ definitionFingerprint, ...s }) => s,
                    "invalid snapshot: expected a definition fingerprint"
                );
                assertRestoreThrows(
                    (s) => ({ ...s, definitionFingerprint: 123 }),
                    "invalid snapshot: expected a definition fingerprint"
                );
                assertRestoreThrows(
                    (s) => ({ ...s, root: null }),
                    "invalid snapshot: expected an object for 'root' node"
                );
            });

            it("the snapshot was taken from a tree with a different definition", () => {
                const otherDefinitionSnapshot = (otherDefinition: string) => {
                    const { agent } = createScriptedAgent({
                        x: () => undefined,
                        y: () => undefined,
                        z: () => undefined
                    });
                    const other = new BehaviourTree(otherDefinition, agent);
                    other.step();
                    return persist(other.snapshot());
                };

                // The same structure, but with other actions, so every node of the snapshot would fit the tree.
                assertRestoreThrows(
                    () =>
                        otherDefinitionSnapshot("root { sequence { action [x] selector { action [y] action [z] } } }"),
                    "invalid snapshot: snapshot does not match the tree's definition"
                );
            });

            it("the snapshot version is not supported", () => {
                assertRestoreThrows((s) => ({ ...s, version: 2 }), "invalid snapshot: unsupported version '2'");
                assertRestoreThrows(({ version, ...s }) => s, "invalid snapshot: unsupported version 'undefined'");
            });

            it("the snapshot has no root node", () => {
                assertRestoreThrows(({ root, ...s }) => s, "invalid snapshot: expected an object for 'root' node");
            });

            it("a node is of a different type to the node in the tree", () => {
                assertRestoreThrows((s) => {
                    s.root.children[0].children[1].type = "sequence";
                    return s;
                }, "invalid snapshot: expected a 'selector' node but found a 'sequence' node");
            });

            it("a node has a different number of children to the node in the tree", () => {
                assertRestoreThrows((s) => {
                    s.root.children[0].children.pop();
                    return s;
                }, "invalid snapshot: expected 2 children for 'sequence' node but found 1");

                assertRestoreThrows((s) => {
                    delete s.root.children[0].children[1].children;
                    return s;
                }, "invalid snapshot: expected 2 children for 'selector' node but found 0");
            });

            it("a node has an unknown state", () => {
                assertRestoreThrows((s) => {
                    s.root.children[0].children[0].state = "mistreevous.sleeping";
                    return s;
                }, "invalid snapshot: invalid state 'mistreevous.sleeping' for 'action' node");
            });
        });
    });
});

describe("A snapshot of a tree", () => {
    describe("with a repeat node", () => {
        it("keeps the iteration counts", () => {
            const { agent } = createScriptedAgent({
                work: (callNumber) => (callNumber % 2 === 1 ? State.SUCCEEDED : undefined)
            });
            const tree = new BehaviourTree("root { repeat [3] { action [work] } }", agent);

            tree.step();
            tree.step();
            tree.step();
            tree.step();

            const repeat: any = tree.snapshot().root;

            assert.equal(repeat.children[0].type, "repeat");
            assert.equal(repeat.children[0].targetIterationCount, 3);
            assert.equal(repeat.children[0].currentIterationCount, 2);
        });

        it("restores a tree that behaves exactly like the original tree", () => {
            const definitions = [
                "root { repeat [3] { action [a] } }",
                "root { repeat { sequence { action [a] action [b] } } }",
                "root { repeat [2, 4] { action [a] } }",
                "root { sequence { repeat [1, 3] { action [a] } repeat [2, 3] { action [b] } } }",
                "root { repeat [2] { sequence { repeat [2, 3] { action [a] } action [b] } } }",
                "root { repeat [3] { selector { action [c] action [a] } } }"
            ];

            for (const definition of definitions) {
                const runningSnapshotCount = assertRestoredTreeBehavesLikeOriginal({
                    definition,
                    script: {
                        a: RUNNING_THEN_SUCCEEDED(1),
                        b: RUNNING_THEN_SUCCEEDED(2),
                        c: RUNNING_THEN_FAILED(1)
                    },
                    useRandom: true,
                    maxSteps: 25
                });

                assert.isAbove(runningSnapshotCount, 0, definition);
            }
        });

        it("keeps the random iteration count that was already chosen", () => {
            const { agent } = createScriptedAgent({ work: RUNNING_THEN_SUCCEEDED(0) });
            const tree = new BehaviourTree("root { repeat [2, 4] { action [work] } }", agent, { random: () => 0 });

            tree.step();

            const restoredTree = new BehaviourTree("root { repeat [2, 4] { action [work] } }", agent, {
                random: () => 0.99
            });
            restoredTree.restore(persist(tree.snapshot()));

            // The original tree chose two iterations, and has done one of them.
            restoredTree.step();
            assert.equal(restoredTree.getState(), State.RUNNING);
            restoredTree.step();
            assert.equal(restoredTree.getState(), State.SUCCEEDED);
        });
    });

    describe("with a retry node", () => {
        it("keeps the attempt counts", () => {
            const { agent } = createScriptedAgent({
                work: (callNumber) => (callNumber % 2 === 1 ? State.FAILED : undefined)
            });
            const tree = new BehaviourTree("root { retry [3] { action [work] } }", agent);

            tree.step();
            tree.step();
            tree.step();
            tree.step();

            const retry: any = tree.snapshot().root;

            assert.equal(retry.children[0].type, "retry");
            assert.equal(retry.children[0].targetAttemptCount, 3);
            assert.equal(retry.children[0].currentAttemptCount, 2);
        });

        it("restores a tree that behaves exactly like the original tree", () => {
            const definitions = [
                "root { retry [3] { action [a] } }",
                "root { retry { sequence { action [b] action [c] } } }",
                "root { retry [2, 4] { action [a] } }",
                "root { sequence { retry [1, 3] { action [a] } retry [2, 3] { action [b] } } }",
                "root { retry [2] { sequence { retry [2, 3] { action [a] } action [d] } } }"
            ];

            for (const definition of definitions) {
                const runningSnapshotCount = assertRestoredTreeBehavesLikeOriginal({
                    definition,
                    script: {
                        a: RUNNING_THEN_FAILED(1),
                        b: RUNNING_THEN_FAILED(2),
                        // Only succeeds on its fifth call.
                        c: (callNumber) => (callNumber === 4 ? State.SUCCEEDED : undefined),
                        d: RUNNING_THEN_FAILED(0)
                    },
                    useRandom: true,
                    maxSteps: 25
                });

                assert.isAbove(runningSnapshotCount, 0, definition);
            }
        });

        it("keeps the random attempt count that was already chosen", () => {
            const { agent } = createScriptedAgent({ work: RUNNING_THEN_FAILED(0) });
            const tree = new BehaviourTree("root { retry [2, 4] { action [work] } }", agent, { random: () => 0 });

            tree.step();

            const restoredTree = new BehaviourTree("root { retry [2, 4] { action [work] } }", agent, {
                random: () => 0.99
            });
            restoredTree.restore(persist(tree.snapshot()));

            // The original tree chose two attempts, and has made one of them.
            restoredTree.step();
            assert.equal(restoredTree.getState(), State.RUNNING);
            restoredTree.step();
            assert.equal(restoredTree.getState(), State.FAILED);
        });
    });

    describe("will not restore if the counts of", () => {
        const assertRestoreThrows = (definition: string, mutate: (decorator: any) => void, message: string) => {
            const { agent } = createScriptedAgent({ work: RUNNING_THEN_SUCCEEDED(1) });
            const tree = new BehaviourTree(definition, agent);
            tree.step();

            const snapshot: any = persist(tree.snapshot());
            mutate(snapshot.root.children[0]);

            assert.throws(() => tree.restore(snapshot), Error, message);
        };

        it("a repeat node are not valid", () => {
            const definition = "root { repeat [3] { action [work] } }";

            assertRestoreThrows(
                definition,
                (n) => (n.currentIterationCount = -1),
                "invalid snapshot: invalid current iteration count '-1' for 'repeat' node"
            );
            assertRestoreThrows(
                definition,
                (n) => (n.currentIterationCount = 0.5),
                "invalid snapshot: invalid current iteration count '0.5' for 'repeat' node"
            );
            assertRestoreThrows(
                definition,
                (n) => delete n.currentIterationCount,
                "invalid snapshot: invalid current iteration count 'undefined' for 'repeat' node"
            );
            assertRestoreThrows(
                definition,
                (n) => (n.targetIterationCount = "3"),
                "invalid snapshot: invalid target iteration count '3' for 'repeat' node"
            );
            assertRestoreThrows(
                definition,
                (n) => delete n.targetIterationCount,
                "invalid snapshot: invalid target iteration count 'undefined' for 'repeat' node"
            );
        });

        it("a retry node are not valid", () => {
            const definition = "root { retry [3] { action [work] } }";

            assertRestoreThrows(
                definition,
                (n) => (n.currentAttemptCount = -1),
                "invalid snapshot: invalid current attempt count '-1' for 'retry' node"
            );
            assertRestoreThrows(
                definition,
                (n) => (n.targetAttemptCount = 1.5),
                "invalid snapshot: invalid target attempt count '1.5' for 'retry' node"
            );
        });
    });
});

describe("A snapshot of a tree with a lotto node", () => {
    const definition = "root { lotto [1, 5, 10] { action [a] action [b] action [c] } }";

    it("keeps the child that was picked", () => {
        const { agent } = createScriptedAgent({ a: () => undefined, b: () => undefined, c: () => undefined });
        const tree = new BehaviourTree(definition, agent, { random: () => 0.99 });

        tree.step();

        const lotto: any = tree.snapshot().root;

        assert.equal(lotto.children[0].type, "lotto");
        assert.equal(lotto.children[0].selectedChild, 2);
    });

    it("keeps no picked child if the lotto node has not been updated", () => {
        const { agent } = createScriptedAgent({ a: () => undefined, b: () => undefined, c: () => undefined });
        const tree = new BehaviourTree(definition, agent);

        const lotto: any = tree.snapshot().root;

        assert.isNull(lotto.children[0].selectedChild);
    });

    it("restores a tree that behaves exactly like the original tree", () => {
        const definitions = [
            definition,
            "root { lotto { action [a] action [b] action [c] } }",
            "root { repeat [4] { lotto [3, 1] { sequence { action [a] action [b] } action [c] } } }",
            "root { sequence { lotto { action [a] action [c] } lotto { action [b] action [c] } } }"
        ];

        for (const definition of definitions) {
            const runningSnapshotCount = assertRestoredTreeBehavesLikeOriginal({
                definition,
                script: {
                    a: RUNNING_THEN_SUCCEEDED(1),
                    b: RUNNING_THEN_FAILED(2),
                    c: RUNNING_THEN_SUCCEEDED(0)
                },
                useRandom: true,
                maxSteps: 25
            });

            assert.isAbove(runningSnapshotCount, 0, definition);
        }
    });

    it("can be restored when a guard resolved the node before it picked a child", () => {
        const guardedDefinition = "root { lotto while(never) { action [a] action [b] } }";
        const { agent } = createScriptedAgent({ a: () => undefined, b: () => undefined, never: () => false });
        const tree = new BehaviourTree(guardedDefinition, agent);
        tree.step();
        assert.equal(tree.getState(), State.FAILED);

        const restoredTree = new BehaviourTree(guardedDefinition, agent);
        restoredTree.restore(persist(tree.snapshot()));

        assert.deepEqual(getNodeStates(restoredTree), getNodeStates(tree));
        assert.equal(restoredTree.getState(), State.FAILED);
    });

    it("restores the picked child rather than picking again", () => {
        const { agent, log } = createScriptedAgent({ a: () => undefined, b: () => undefined, c: () => undefined });
        const tree = new BehaviourTree(definition, agent, { random: () => 0.99 });
        tree.step();

        const restoredAgent = createScriptedAgent({ a: () => undefined, b: () => undefined, c: () => undefined });
        const restoredTree = new BehaviourTree(definition, restoredAgent.agent, { random: () => 0 });
        restoredTree.restore(persist(tree.snapshot()));
        restoredTree.step();

        assert.deepEqual(log, ["c()"]);
        assert.deepEqual(restoredAgent.log, ["c()"]);
    });

    describe("will not restore if", () => {
        const assertRestoreThrows = (mutate: (lotto: any) => void, message: string) => {
            const { agent } = createScriptedAgent({ a: () => undefined, b: () => undefined, c: () => undefined });
            const tree = new BehaviourTree(definition, agent);
            tree.step();

            const snapshot: any = persist(tree.snapshot());
            mutate(snapshot.root.children[0]);

            assert.throws(() => tree.restore(snapshot), Error, message);
        };

        it("the picked child does not exist", () => {
            assertRestoreThrows(
                (n) => (n.selectedChild = 3),
                "invalid snapshot: invalid picked child '3' for 'lotto' node"
            );
            assertRestoreThrows(
                (n) => (n.selectedChild = -1),
                "invalid snapshot: invalid picked child '-1' for 'lotto' node"
            );
            assertRestoreThrows(
                (n) => (n.selectedChild = "1"),
                "invalid snapshot: invalid picked child '1' for 'lotto' node"
            );
            assertRestoreThrows(
                (n) => delete n.selectedChild,
                "invalid snapshot: invalid picked child 'undefined' for 'lotto' node"
            );
        });

        it("there is no picked child but the node is running", () => {
            assertRestoreThrows(
                (n) => (n.selectedChild = null),
                "invalid snapshot: no picked child for running 'lotto' node"
            );
        });
    });
});

describe("A snapshot of a tree with a wait node", () => {
    const HOUR = 60 * 60 * 1000;

    let clock: SinonFakeTimers;

    beforeEach(() => {
        clock = sinon.useFakeTimers();
    });

    afterEach(() => {
        clock.restore();
    });

    it("keeps the total and waited durations", () => {
        const { agent } = createScriptedAgent({});
        const tree = new BehaviourTree("root { wait [1000] }", agent);

        tree.step();
        clock.tick(400);

        const wait: any = tree.snapshot().root;

        assert.equal(wait.children[0].type, "wait");
        assert.equal(wait.children[0].totalDuration, 1000);
        assert.equal(wait.children[0].waitedDuration, 400);
    });

    it("keeps no total duration for a wait node that waits indefinitely", () => {
        const { agent } = createScriptedAgent({});
        const tree = new BehaviourTree("root { wait }", agent);

        tree.step();
        clock.tick(400);

        const wait: any = tree.snapshot().root;

        assert.isNull(wait.children[0].totalDuration);
    });

    describe("when using the clock", () => {
        it("restores a wait node that waits only for the remaining time", () => {
            const { agent } = createScriptedAgent({});
            const tree = new BehaviourTree("root { wait [1000] }", agent);

            tree.step();
            clock.tick(400);
            tree.step();

            const snapshot = persist(tree.snapshot());

            // Hours pass before the tree is restored, none of which should count as time waited.
            clock.tick(5 * HOUR);

            const restoredTree = new BehaviourTree("root { wait [1000] }", agent);
            restoredTree.restore(snapshot);

            restoredTree.step();
            assert.equal(restoredTree.getState(), State.RUNNING);

            clock.tick(599);
            restoredTree.step();
            assert.equal(restoredTree.getState(), State.RUNNING);

            clock.tick(1);
            restoredTree.step();
            assert.equal(restoredTree.getState(), State.SUCCEEDED);
        });

        it("counts time that passed after the last step but before the snapshot was taken", () => {
            const { agent } = createScriptedAgent({});
            const tree = new BehaviourTree("root { wait [1000] }", agent);

            tree.step();
            clock.tick(400);

            // No step since the first one, but 400ms have been spent waiting by the time the snapshot is taken.
            const snapshot = persist(tree.snapshot());
            clock.tick(5 * HOUR);

            const restoredTree = new BehaviourTree("root { wait [1000] }", agent);
            restoredTree.restore(snapshot);

            clock.tick(599);
            restoredTree.step();
            assert.equal(restoredTree.getState(), State.RUNNING);

            clock.tick(1);
            restoredTree.step();
            assert.equal(restoredTree.getState(), State.SUCCEEDED);
        });

        it("restores a wait node that is part of a larger tree", () => {
            const definition = "root { sequence { action [before] wait [1000] action [after] } }";
            const first = createScriptedAgent({ before: () => State.SUCCEEDED, after: () => State.SUCCEEDED });
            const tree = new BehaviourTree(definition, first.agent);

            tree.step();
            clock.tick(900);
            const snapshot = persist(tree.snapshot());
            clock.tick(5 * HOUR);

            const second = createScriptedAgent({ before: () => State.SUCCEEDED, after: () => State.SUCCEEDED });
            const restoredTree = new BehaviourTree(definition, second.agent);
            restoredTree.restore(snapshot);

            restoredTree.step();
            assert.equal(restoredTree.getState(), State.RUNNING);
            assert.deepEqual(second.log, []);

            clock.tick(100);
            restoredTree.step();
            assert.equal(restoredTree.getState(), State.SUCCEEDED);
            assert.deepEqual(second.log, ["after()"]);
        });

        it("restores a tree that behaves exactly like the original tree", () => {
            const definitions = [
                "root { wait [450] }",
                "root { sequence { wait [250] action [a] wait [100, 900] } }",
                "root { race { wait [600] sequence { action [a] action [a] } } }",
                "root { race { wait action [a] } }",
                "root { repeat [3] { sequence { wait [100, 300] action [a] } } }"
            ];

            for (const definition of definitions) {
                const runningSnapshotCount = assertRestoredTreeBehavesLikeOriginal({
                    definition,
                    script: { a: RUNNING_THEN_SUCCEEDED(2) },
                    useRandom: true,
                    onStepped: () => clock.tick(100),
                    maxSteps: 30
                });

                assert.isAbove(runningSnapshotCount, 0, definition);
            }
        });
    });

    describe("when using the 'getDeltaTime' option", () => {
        it("restores a wait node that waits only for the remaining time", () => {
            const { agent } = createScriptedAgent({});
            const options = { getDeltaTime: () => 0.25 };
            const tree = new BehaviourTree("root { wait [1000] }", agent, options);

            tree.step();
            tree.step();

            const snapshot = persist(tree.snapshot());

            // Time passing on the clock should not matter at all.
            clock.tick(5 * HOUR);

            const restoredTree = new BehaviourTree("root { wait [1000] }", agent, options);
            restoredTree.restore(snapshot);

            // Half of the wait has already happened, two more steps of a quarter of a second each will complete it.
            restoredTree.step();
            assert.equal(restoredTree.getState(), State.RUNNING);

            restoredTree.step();
            assert.equal(restoredTree.getState(), State.SUCCEEDED);
        });

        it("restores a tree that behaves exactly like the original tree", () => {
            const definitions = [
                "root { wait [450] }",
                "root { sequence { wait [250] action [a] wait [100, 900] } }",
                "root { race { wait [600] sequence { action [a] action [a] } } }",
                "root { repeat [3] { sequence { wait [100, 300] action [a] } } }"
            ];

            for (const definition of definitions) {
                const runningSnapshotCount = assertRestoredTreeBehavesLikeOriginal({
                    definition,
                    script: { a: RUNNING_THEN_SUCCEEDED(2) },
                    createOptions: () => ({ getDeltaTime: () => 0.1 }),
                    useRandom: true,
                    onStepped: () => clock.tick(3 * HOUR),
                    maxSteps: 30
                });

                assert.isAbove(runningSnapshotCount, 0, definition);
            }
        });

        it("keeps a snapshot that is unchanged by a JSON round trip if the delta time is not finite", () => {
            const { agent } = createScriptedAgent({});
            const tree = new BehaviourTree("root { sequence { wait [1000] wait [1000] } }", agent, {
                getDeltaTime: () => Infinity
            });

            tree.step();

            const snapshot = tree.snapshot();

            assert.deepEqual(persist(snapshot), snapshot);
        });
    });

    it("keeps the random duration that was already chosen", () => {
        const { agent } = createScriptedAgent({});
        const tree = new BehaviourTree("root { wait [1000, 2000] }", agent, { random: () => 0 });

        tree.step();
        clock.tick(400);

        const snapshot = persist(tree.snapshot());

        const restoredTree = new BehaviourTree("root { wait [1000, 2000] }", agent, { random: () => 0.99 });
        restoredTree.restore(snapshot);

        clock.tick(600);
        restoredTree.step();
        assert.equal(restoredTree.getState(), State.SUCCEEDED);
    });

    describe("will not restore if", () => {
        const assertRestoreThrows = (mutate: (wait: any) => void, message: string) => {
            const { agent } = createScriptedAgent({});
            const tree = new BehaviourTree("root { wait [1000] }", agent);
            tree.step();

            const snapshot: any = persist(tree.snapshot());
            mutate(snapshot.root.children[0]);

            assert.throws(() => tree.restore(snapshot), Error, message);
        };

        it("the total duration is not valid", () => {
            assertRestoreThrows(
                (n) => (n.totalDuration = -1),
                "invalid snapshot: invalid total duration '-1' for 'wait' node"
            );
            assertRestoreThrows(
                (n) => (n.totalDuration = "1000"),
                "invalid snapshot: invalid total duration '1000' for 'wait' node"
            );
            assertRestoreThrows(
                (n) => delete n.totalDuration,
                "invalid snapshot: invalid total duration 'undefined' for 'wait' node"
            );
        });

        it("the waited duration is not valid", () => {
            assertRestoreThrows(
                (n) => (n.waitedDuration = null),
                "invalid snapshot: invalid waited duration 'null' for 'wait' node"
            );
            assertRestoreThrows(
                (n) => (n.waitedDuration = "5"),
                "invalid snapshot: invalid waited duration '5' for 'wait' node"
            );
            assertRestoreThrows(
                (n) => delete n.waitedDuration,
                "invalid snapshot: invalid waited duration 'undefined' for 'wait' node"
            );
        });
    });
});

/**
 * Create a promise that can be settled from the outside.
 */
function createDeferred<T>() {
    let resolve!: (value: T) => void;
    let reject!: (reason: unknown) => void;
    const promise = new Promise<T>((promiseResolve, promiseReject) => {
        resolve = promiseResolve;
        reject = promiseReject;
    });
    return { promise, resolve, reject };
}

/**
 * Wait for any settled promises to be handled.
 */
const settlePromises = () => new Promise((resolve) => setImmediate(resolve));

describe("A snapshot of a tree with a promise-based action node", () => {
    const definition = "root { sequence { action [work] action [after] } }";

    const createAgent = (work: () => Promise<State.SUCCEEDED | State.FAILED>) => {
        const log: string[] = [];
        const agent: Agent = {
            work: () => {
                log.push("work()");
                return work();
            },
            after: () => {
                log.push("after()");
                return State.SUCCEEDED;
            }
        };
        return { agent, log };
    };

    describe("while the promise has not settled", () => {
        it("can be taken, with the action as not yet started", () => {
            const { agent } = createAgent(() => createDeferred<State.SUCCEEDED>().promise);
            const tree = new BehaviourTree(definition, agent);

            tree.step();
            const snapshot: any = tree.snapshot();

            assert.deepEqual(persist(snapshot), snapshot);
            assert.deepEqual(snapshot.root.children[0].children[0], {
                type: "action",
                state: State.READY,
                updatePromiseResult: null
            });
            assert.equal(snapshot.root.children[0].state, State.RUNNING);
        });

        it("is taken without changing the tree, which carries on waiting for the promise", async () => {
            const deferred = createDeferred<State.SUCCEEDED>();
            const { agent, log } = createAgent(() => deferred.promise);
            const tree = new BehaviourTree(definition, agent);
            tree.step();

            tree.snapshot();

            assert.equal(getNodeStates(tree)[2], "action work mistreevous.running");
            deferred.resolve(State.SUCCEEDED);
            await settlePromises();
            tree.step();

            assert.equal(tree.getState(), State.SUCCEEDED);
            assert.deepEqual(log, ["work()", "after()"]);
        });

        it("restores a tree that calls the action function again on its next step", async () => {
            const original = createDeferred<State.SUCCEEDED>();
            const source = createAgent(() => original.promise);
            const sourceTree = new BehaviourTree(definition, source.agent);
            sourceTree.step();
            const snapshot = persist(sourceTree.snapshot());

            const again = createDeferred<State.FAILED>();
            const target = createAgent(() => again.promise);
            const targetTree = new BehaviourTree(definition, target.agent);
            targetTree.restore(snapshot);

            // The action is restored as not yet started, and has not been called by restoring.
            assert.deepEqual(getNodeStates(targetTree), [
                "root ROOT mistreevous.running",
                "sequence SEQUENCE mistreevous.running",
                "action work mistreevous.ready",
                "action after mistreevous.ready"
            ]);
            assert.deepEqual(target.log, []);

            // It is called again on the next step, and is then waiting on the new promise.
            targetTree.step();
            assert.deepEqual(target.log, ["work()"]);
            assert.equal(getNodeStates(targetTree)[2], "action work mistreevous.running");

            targetTree.step();
            assert.deepEqual(target.log, ["work()"]);

            again.resolve(State.FAILED);
            await settlePromises();
            targetTree.step();

            assert.equal(targetTree.getState(), State.FAILED);
            assert.deepEqual(target.log, ["work()"]);
        });

        it("restores a tree that calls the entry callback of the action again", () => {
            const log: string[] = [];
            const createEntryAgent = () => ({
                onEntry: () => log.push("onEntry()"),
                work: () => new Promise<State.SUCCEEDED>(() => {})
            });
            const entryDefinition = "root { action [work] entry(onEntry) }";

            const sourceTree = new BehaviourTree(entryDefinition, createEntryAgent());
            sourceTree.step();
            const snapshot = persist(sourceTree.snapshot());
            assert.deepEqual(log, ["onEntry()"]);

            const targetTree = new BehaviourTree(entryDefinition, createEntryAgent());
            targetTree.restore(snapshot);
            assert.deepEqual(log, ["onEntry()"]);

            targetTree.step();
            assert.deepEqual(log, ["onEntry()", "onEntry()"]);
        });

        it("restores a tree that does not call the actions that had already finished again", () => {
            const log: string[] = [];
            const createSequenceAgent = () => ({
                first: () => {
                    log.push("first()");
                    return State.SUCCEEDED;
                },
                work: () => {
                    log.push("work()");
                    return new Promise<State.SUCCEEDED>(() => {});
                }
            });
            const sequenceDefinition = "root { sequence { action [first] action [work] } }";

            const sourceTree = new BehaviourTree(sequenceDefinition, createSequenceAgent());
            sourceTree.step();
            const snapshot = persist(sourceTree.snapshot());
            log.length = 0;

            const targetTree = new BehaviourTree(sequenceDefinition, createSequenceAgent());
            targetTree.restore(snapshot);
            targetTree.step();

            assert.deepEqual(log, ["work()"]);
        });

        it("restores a tree that keeps the settled result of another action but calls the pending action again", async () => {
            const fast = createDeferred<State.SUCCEEDED>();
            const log: string[] = [];
            const createParallelAgent = (isRestored: boolean) => ({
                fast: () => {
                    log.push("fast()");
                    return fast.promise;
                },
                slow: () => {
                    log.push("slow()");
                    return isRestored
                        ? Promise.resolve(State.SUCCEEDED as const)
                        : new Promise<State.SUCCEEDED>(() => {});
                }
            });
            const parallelDefinition = "root { parallel { action [fast] action [slow] } }";

            const sourceTree = new BehaviourTree(parallelDefinition, createParallelAgent(false));
            sourceTree.step();
            fast.resolve(State.SUCCEEDED);
            await settlePromises();
            const snapshot = persist(sourceTree.snapshot());
            log.length = 0;

            const targetTree = new BehaviourTree(parallelDefinition, createParallelAgent(true));
            targetTree.restore(snapshot);
            targetTree.step();

            // The settled result is kept and handled, the pending action is called again.
            assert.deepEqual(log, ["slow()"]);
            assert.deepEqual(getNodeStates(targetTree).slice(2), [
                "action fast mistreevous.succeeded",
                "action slow mistreevous.running"
            ]);

            await settlePromises();
            targetTree.step();

            assert.equal(targetTree.getState(), State.SUCCEEDED);
            assert.deepEqual(log, ["slow()"]);
        });

        it("restores a tree that is not changed by the promise from before the restore settling afterwards", async () => {
            const original = createDeferred<State.SUCCEEDED>();
            const again = createDeferred<State.FAILED>();
            let calls = 0;
            const { agent, log } = createAgent(() => (calls++ === 0 ? original.promise : again.promise));
            const tree = new BehaviourTree(definition, agent);
            tree.step();
            const snapshot = persist(tree.snapshot());

            // Rewind the same tree to the snapshot, then have the promise from before the restore settle.
            tree.restore(snapshot);
            original.resolve(State.SUCCEEDED);
            await settlePromises();
            tree.step();

            assert.equal(tree.getState(), State.RUNNING);
            assert.deepEqual(log, ["work()", "work()"]);

            again.resolve(State.FAILED);
            await settlePromises();
            tree.step();

            assert.equal(tree.getState(), State.FAILED);
            assert.deepEqual(log, ["work()", "work()"]);
        });

        it("restores without calling onNodeStateChange", () => {
            const { agent } = createAgent(() => new Promise<State.SUCCEEDED>(() => {}));
            const sourceTree = new BehaviourTree(definition, agent);
            sourceTree.step();
            const snapshot = persist(sourceTree.snapshot());

            const changes: unknown[] = [];
            new BehaviourTree(definition, agent, { onNodeStateChange: (change) => changes.push(change) }).restore(
                snapshot
            );

            assert.deepEqual(changes, []);
        });
    });

    it("can be taken again once the promise has settled", async () => {
        const deferred = createDeferred<State.SUCCEEDED>();
        const { agent } = createAgent(() => deferred.promise);
        const tree = new BehaviourTree(definition, agent);

        tree.step();
        deferred.resolve(State.SUCCEEDED);
        await settlePromises();

        assert.doesNotThrow(() => tree.snapshot());
    });

    it("can be taken once the action has finished and a later node is running", async () => {
        const deferred = createDeferred<State.SUCCEEDED>();
        const { agent } = createAgent(() => deferred.promise);
        agent.after = () => undefined;
        const tree = new BehaviourTree(definition, agent);

        tree.step();
        deferred.resolve(State.SUCCEEDED);
        await settlePromises();
        tree.step();

        const snapshot = persist(tree.snapshot());
        const restoredTree = new BehaviourTree(definition, agent);
        restoredTree.restore(snapshot);

        assert.deepEqual(getNodeStates(restoredTree), getNodeStates(tree));
    });

    for (const result of [State.SUCCEEDED, State.FAILED] as const) {
        it(`keeps a result of ${result} that has not been handled by a step of the tree`, async () => {
            const deferred = createDeferred<State.SUCCEEDED | State.FAILED>();
            const first = createAgent(() => deferred.promise);
            const tree = new BehaviourTree(definition, first.agent);

            tree.step();
            deferred.resolve(result);
            await settlePromises();

            const snapshot = persist(tree.snapshot());

            const second = createAgent(() => {
                throw new Error("the action should not be called again");
            });
            const restoredTree = new BehaviourTree(definition, second.agent);
            restoredTree.restore(snapshot);
            restoredTree.step();

            assert.equal(restoredTree.getState(), result);
            assert.deepEqual(second.log, result === State.SUCCEEDED ? ["after()"] : []);
        });
    }

    it("keeps a rejection that has not been handled by a step of the tree", async () => {
        const deferred = createDeferred<State.SUCCEEDED>();
        const first = createAgent(() => deferred.promise);
        const tree = new BehaviourTree(definition, first.agent);

        tree.step();
        deferred.reject(new Error("approval service is down"));
        await settlePromises();

        const snapshot = persist(tree.snapshot());

        const second = createAgent(() => createDeferred<State.SUCCEEDED>().promise);
        const restoredTree = new BehaviourTree(definition, second.agent);
        restoredTree.restore(snapshot);

        assert.throws(
            () => restoredTree.step(),
            Error,
            "action function 'work' promise rejected with 'Error: approval service is down'"
        );
    });

    it("keeps a result that is not a valid state so that stepping the tree still errors", async () => {
        const deferred = createDeferred<any>();
        const first = createAgent(() => deferred.promise);
        const tree = new BehaviourTree(definition, first.agent);

        tree.step();
        deferred.resolve({ not: "a state" });
        await settlePromises();

        const restoredTree = new BehaviourTree(definition, first.agent);
        restoredTree.restore(persist(tree.snapshot()));

        assert.throws(
            () => restoredTree.step(),
            Error,
            "action node promise resolved with an invalid value, expected a State.SUCCEEDED or State.FAILED value to be returned"
        );
    });

    it("is not changed by a promise from before a restore settling afterwards", async () => {
        // Take a snapshot of a tree where the action has settled with a result of SUCCEEDED.
        const settled = createDeferred<State.SUCCEEDED>();
        const source = createAgent(() => settled.promise);
        const sourceTree = new BehaviourTree(definition, source.agent);
        sourceTree.step();
        settled.resolve(State.SUCCEEDED);
        await settlePromises();
        const snapshot = persist(sourceTree.snapshot());

        // Restore that snapshot to a tree where the action is still waiting on its own promise.
        const inFlight = createDeferred<State.SUCCEEDED | State.FAILED>();
        const target = createAgent(() => inFlight.promise);
        const targetTree = new BehaviourTree(definition, target.agent);
        targetTree.step();
        targetTree.restore(snapshot);

        inFlight.resolve(State.FAILED);
        await settlePromises();
        targetTree.step();

        assert.equal(targetTree.getState(), State.SUCCEEDED);
        assert.deepEqual(target.log, ["work()", "after()"]);
    });

    it("is not changed by a promise from before a restore settling afterwards when the action should run again", async () => {
        // Take a snapshot of a tree where the action is running without a promise.
        const source = createAgent(() => undefined as any);
        const sourceTree = new BehaviourTree(definition, source.agent);
        sourceTree.step();
        const snapshot = persist(sourceTree.snapshot());

        const inFlight = createDeferred<State.SUCCEEDED | State.FAILED>();
        const target = createAgent(() => inFlight.promise);
        const targetTree = new BehaviourTree(definition, target.agent);
        targetTree.step();
        targetTree.restore(snapshot);

        inFlight.resolve(State.FAILED);
        await settlePromises();
        targetTree.step();

        // The action is running again as it was in the snapshot, and has been called again.
        assert.equal(targetTree.getState(), State.RUNNING);
        assert.deepEqual(target.log, ["work()", "work()"]);
    });

    describe("will not restore if", () => {
        const assertRestoreThrows = async (mutate: (action: any) => void, message: string) => {
            const deferred = createDeferred<State.SUCCEEDED>();
            const { agent } = createAgent(() => deferred.promise);
            const tree = new BehaviourTree(definition, agent);
            tree.step();
            deferred.resolve(State.SUCCEEDED);
            await settlePromises();

            const snapshot: any = persist(tree.snapshot());
            mutate(snapshot.root.children[0].children[0]);

            assert.throws(() => tree.restore(snapshot), Error, message);
        };

        it("the promise result is not valid", async () => {
            await assertRestoreThrows(
                (n) => (n.updatePromiseResult = "settled"),
                "invalid snapshot: invalid update promise result 'settled' for 'action' node"
            );
            await assertRestoreThrows(
                (n) => (n.updatePromiseResult = { isResolved: 1, value: null }),
                "invalid snapshot: invalid update promise result '[object Object]' for 'action' node"
            );
            await assertRestoreThrows(
                (n) => (n.updatePromiseResult = { isResolved: true, value: {} }),
                "invalid snapshot: invalid update promise result '[object Object]' for 'action' node"
            );
            await assertRestoreThrows(
                (n) => delete n.updatePromiseResult,
                "invalid snapshot: invalid update promise result 'undefined' for 'action' node"
            );
        });
    });
});

describe("A snapshot of a finished tree", () => {
    const script = {
        a: RUNNING_THEN_SUCCEEDED(1),
        b: RUNNING_THEN_FAILED(0)
    };

    for (const [description, definition, finalState] of [
        ["succeeded", "root { sequence { action [a] action [a] } }", State.SUCCEEDED],
        ["failed", "root { sequence { action [a] action [b] } }", State.FAILED]
    ] as const) {
        describe(`that ${description}`, () => {
            const createFinishedTree = () => {
                const { agent, log, callCounts } = createScriptedAgent(script);
                const tree = new BehaviourTree(definition, agent);

                for (let step = 0; step < 10 && tree.getState() !== finalState; step++) {
                    tree.step();
                }

                return { tree, log, callCounts };
            };

            it("restores as finished", () => {
                const { tree } = createFinishedTree();
                const { agent } = createScriptedAgent(script);
                const restoredTree = new BehaviourTree(definition, agent);

                restoredTree.restore(persist(tree.snapshot()));

                assert.equal(restoredTree.getState(), finalState);
                assert.isFalse(restoredTree.isRunning());
                assert.deepEqual(getNodeStates(restoredTree), getNodeStates(tree));
            });

            it("starts a new run on the next step like the original tree does", () => {
                const { tree, log, callCounts } = createFinishedTree();
                const logLengthAtSnapshot = log.length;
                const snapshot = persist(tree.snapshot());

                const restored = createScriptedAgent(script, callCounts);
                const restoredTree = new BehaviourTree(definition, restored.agent);
                restoredTree.restore(snapshot);

                for (let step = 0; step < 6; step++) {
                    tree.step();
                    restoredTree.step();

                    assert.deepEqual(getNodeStates(restoredTree), getNodeStates(tree));
                }

                assert.isAbove(restored.log.length, 0);
                assert.deepEqual(restored.log, log.slice(logLengthAtSnapshot));
            });
        });
    }

    it("makes its random choices again on the next step", () => {
        const definition =
            "root { sequence { lotto { action [a] action [b] } repeat [1, 4] { action [a] } wait [100, 900] } }";

        const finish = (tree: BehaviourTree) => {
            for (let step = 0; step < 50 && tree.getState() !== State.SUCCEEDED; step++) {
                tree.step();
            }
        };

        const clock = sinon.useFakeTimers();

        try {
            const { agent } = createScriptedAgent({ a: () => State.SUCCEEDED, b: () => State.SUCCEEDED });
            const tree = new BehaviourTree(definition, agent, { random: () => 0, getDeltaTime: () => 0.05 });
            finish(tree);
            assert.equal(tree.getState(), State.SUCCEEDED);

            // The restored tree gets a random function that picks the largest values, so a new run is easy to tell apart.
            const restored = createScriptedAgent({ a: () => State.SUCCEEDED, b: () => State.SUCCEEDED });
            const randomCalls: number[] = [];
            const restoredTree = new BehaviourTree(definition, restored.agent, {
                random: () => {
                    randomCalls.push(1);
                    return 0.99;
                },
                getDeltaTime: () => 0.05
            });
            restoredTree.restore(persist(tree.snapshot()));

            // Restoring made no random choices.
            assert.deepEqual(randomCalls, []);

            restoredTree.step();

            // The lotto node picked the second child, the repeat node chose four iterations, and the wait node chose its longest duration.
            assert.deepEqual(restored.log, ["b()", "a()"]);
            finish(restoredTree);
            assert.equal(restoredTree.getState(), State.SUCCEEDED);
            assert.deepEqual(restored.log, ["b()", "a()", "a()", "a()", "a()"]);
            assert.equal(randomCalls.length, 3);
        } finally {
            clock.restore();
        }
    });
});

describe("A snapshot restored to a tree", () => {
    const DEFINITION_MISMATCH = "invalid snapshot: snapshot does not match the tree's definition";

    const script = {
        a: RUNNING_THEN_SUCCEEDED(2),
        b: RUNNING_THEN_SUCCEEDED(2),
        c: RUNNING_THEN_SUCCEEDED(2),
        yes: () => true,
        no: () => false,
        onEntry: () => undefined,
        other: () => undefined
    };

    const takeSnapshot = (definition: string | RootNodeDefinition | RootNodeDefinition[], steps = 2) => {
        const { agent } = createScriptedAgent(script);
        const tree = new BehaviourTree(definition, agent);
        for (let step = 0; step < steps; step++) {
            tree.step();
        }
        return persist(tree.snapshot());
    };

    describe("with a different definition", () => {
        const definition = "root { sequence { action [a] wait [100] action [b] } }";

        const differentDefinitions: { [description: string]: string } = {
            "an action that calls another function": "root { sequence { action [a] wait [100] action [c] } }",
            "an action with different arguments": "root { sequence { action [a, 1] wait [100] action [b] } }",
            "a wait with another duration": "root { sequence { action [a] wait [200] action [b] } }",
            "a wait with a random duration": "root { sequence { action [a] wait [100, 200] action [b] } }",
            "an extra attribute": "root { sequence { action [a] wait [100] action [b] entry(onEntry) } }",
            "another guard": "root { sequence while(no) { action [a] wait [100] action [b] } }",
            "a guard that resolves differently":
                "root { sequence while(yes, true) { action [a] wait [100] action [b] } }",
            "another condition": "root { sequence { condition [yes] wait [100] action [b] } }",
            "another node type with the same structure": "root { selector { action [a] wait [100] action [b] } }",
            "different repeat iterations": "root { sequence { repeat [2] { action [a] } wait [100] action [b] } }"
        };

        for (const [description, otherDefinition] of Object.entries(differentDefinitions)) {
            it(`is rejected when the tree has ${description}`, () => {
                const snapshot = takeSnapshot(definition);
                const { agent } = createScriptedAgent(script);
                const tree = new BehaviourTree(otherDefinition, agent);

                assert.throws(() => tree.restore(snapshot), Error, DEFINITION_MISMATCH);
            });
        }

        it("is rejected when the tree has a guard that resolves differently", () => {
            const snapshot = takeSnapshot("root { sequence while(yes) { action [a] } }");
            const { agent } = createScriptedAgent(script);
            const tree = new BehaviourTree("root { sequence while(yes) then succeed { action [a] } }", agent);

            assert.throws(() => tree.restore(snapshot), Error, DEFINITION_MISMATCH);
        });

        it("is rejected when the tree has different lotto weights", () => {
            const snapshot = takeSnapshot("root { lotto [2, 1] { action [a] action [b] } }");
            const { agent } = createScriptedAgent(script);
            const tree = new BehaviourTree("root { lotto [1, 2] { action [a] action [b] } }", agent);

            assert.throws(() => tree.restore(snapshot), Error, DEFINITION_MISMATCH);
        });

        it("is rejected when the tree is built from a different subtree", () => {
            const withSubtree = (subtreeAction: string) =>
                `root { sequence { branch [Sub] action [b] } } root [Sub] { action [${subtreeAction}] }`;
            const snapshot = takeSnapshot(withSubtree("a"));
            const { agent } = createScriptedAgent(script);
            const tree = new BehaviourTree(withSubtree("c"), agent);

            assert.throws(() => tree.restore(snapshot), Error, DEFINITION_MISMATCH);
        });

        it("is rejected when the tree has a different structure, whatever the node types in the snapshot", () => {
            const snapshot = takeSnapshot(definition);
            const { agent } = createScriptedAgent(script);
            const tree = new BehaviourTree("root { sequence { action [a] } }", agent);

            assert.throws(() => tree.restore(snapshot), Error, DEFINITION_MISMATCH);
        });

        it("leaves the tree exactly as it was", () => {
            // The clock is controlled as a snapshot holds how long a wait node has waited.
            const clock = sinon.useFakeTimers();

            try {
                const snapshot = takeSnapshot(differentDefinitions["an action that calls another function"]);

                const create = () => {
                    const scripted = createScriptedAgent(script);
                    const tree = new BehaviourTree(definition, scripted.agent);
                    tree.step();
                    return { ...scripted, tree };
                };
                const rejected = create();
                const control = create();

                assert.throws(() => rejected.tree.restore(snapshot), Error, DEFINITION_MISMATCH);

                assert.deepEqual(getNodeStates(rejected.tree), getNodeStates(control.tree));
                assert.deepEqual(persist(rejected.tree.snapshot()), persist(control.tree.snapshot()));

                // The tree carries on exactly as the tree that was not asked to restore anything.
                for (let step = 0; step < 6; step++) {
                    rejected.tree.step();
                    control.tree.step();
                    clock.tick(60);
                    assert.deepEqual(getNodeStates(rejected.tree), getNodeStates(control.tree));
                    assert.deepEqual(persist(rejected.tree.snapshot()), persist(control.tree.snapshot()));
                }
                assert.deepEqual(rejected.log, control.log);
                assert.equal(rejected.tree.getState(), State.SUCCEEDED);
            } finally {
                clock.restore();
            }
        });

        it("leaves a pending promise of the tree alone", async () => {
            const snapshot = takeSnapshot("root { sequence { action [other] action [b] } }", 1);
            const deferred = createDeferred<State.SUCCEEDED>();
            const log: string[] = [];
            const tree = new BehaviourTree("root { sequence { action [work] action [after] } }", {
                work: () => {
                    log.push("work()");
                    return deferred.promise;
                },
                after: () => {
                    log.push("after()");
                    return State.SUCCEEDED;
                }
            });
            tree.step();

            assert.throws(() => tree.restore(snapshot), Error, DEFINITION_MISMATCH);

            deferred.resolve(State.SUCCEEDED);
            await settlePromises();
            tree.step();

            assert.equal(tree.getState(), State.SUCCEEDED);
            assert.deepEqual(log, ["work()", "after()"]);
        });
    });

    describe("with an equivalent definition", () => {
        const mdsl = `root {
            sequence while(yes, 1, "text") entry(onEntry) {
                action [a, 1, true, null]
                condition [yes]
                wait [100]
                wait [10, 20]
                repeat [2, 3] {
                    lotto [1, 2] { action [b] action [c] }
                }
                retry until(no, 5) then succeed { action [c] }
                branch [Sub]
            }
        }
        root [Sub] { action [a] }`;

        // The same definition as JSON, leaving out the optional properties that the MDSL parser always adds.
        const json: RootNodeDefinition[] = [
            {
                type: "root",
                child: {
                    type: "sequence",
                    while: { call: "yes", args: [1, "text"] },
                    entry: { call: "onEntry" },
                    children: [
                        { type: "action", call: "a", args: [1, true, null] },
                        { type: "condition", call: "yes" },
                        { type: "wait", duration: 100 },
                        { type: "wait", duration: [10, 20] },
                        {
                            type: "repeat",
                            iterations: [2, 3],
                            child: {
                                type: "lotto",
                                weights: [1, 2],
                                children: [
                                    { type: "action", call: "b" },
                                    { type: "action", call: "c" }
                                ]
                            }
                        },
                        {
                            type: "retry",
                            until: { call: "no", args: [5], succeedOnAbort: true },
                            child: { type: "action", call: "c" }
                        },
                        { type: "branch", ref: "Sub" }
                    ]
                }
            },
            { type: "root", id: "Sub", child: { type: "action", call: "a" } }
        ] as RootNodeDefinition[];

        // The JSON definition with its properties defined in another order, its named root first, and the defaults spelt out.
        const reorderedJson: RootNodeDefinition[] = [
            { child: { call: "a", args: [], type: "action" }, id: "Sub", type: "root" },
            {
                child: {
                    children: [
                        { args: [1, true, null], call: "a", type: "action" },
                        { args: [], call: "yes", type: "condition" },
                        { duration: 100, type: "wait" },
                        { duration: [10, 20], type: "wait" },
                        {
                            child: {
                                children: [
                                    { args: [], call: "b", type: "action" },
                                    { args: [], call: "c", type: "action" }
                                ],
                                type: "lotto",
                                weights: [1, 2]
                            },
                            iterations: [2, 3],
                            type: "repeat"
                        },
                        {
                            child: { call: "c", type: "action" },
                            type: "retry",
                            until: { succeedOnAbort: true, args: [5], call: "no" }
                        },
                        { ref: "Sub", type: "branch" }
                    ],
                    entry: { args: [], call: "onEntry" },
                    type: "sequence",
                    while: { args: [1, "text"], call: "yes", succeedOnAbort: false }
                },
                type: "root"
            }
        ] as RootNodeDefinition[];

        const definitions: { [description: string]: string | RootNodeDefinition[] } = {
            MDSL: mdsl,
            "MDSL with other whitespace and comments": mdsl
                .replace(/\s+/g, " ")
                .replace("{ action", "{ /* first */ action"),
            JSON: json,
            "JSON with another property and root order": reorderedJson
        };

        for (const [snapshotSource, snapshotDefinition] of Object.entries(definitions)) {
            for (const [treeSource, treeDefinition] of Object.entries(definitions)) {
                it(`is accepted when a snapshot of ${snapshotSource} is restored to a tree built from ${treeSource}`, () => {
                    const snapshot = takeSnapshot(snapshotDefinition, 3);
                    const { agent } = createScriptedAgent(script);
                    const tree = new BehaviourTree(treeDefinition, agent);

                    assert.doesNotThrow(() => tree.restore(snapshot));
                    assert.equal(tree.snapshot().definitionFingerprint, snapshot.definitionFingerprint);
                    assert.equal(tree.getState(), snapshot.root.state);
                });
            }
        }

        it("is accepted when a single root node is given as an object rather than an array", () => {
            const singleRoot: RootNodeDefinition = {
                type: "root",
                child: { type: "sequence", children: [{ type: "action", call: "a" }] }
            };
            const snapshot = takeSnapshot(singleRoot);
            const { agent } = createScriptedAgent(script);

            assert.doesNotThrow(() => new BehaviourTree([singleRoot], agent).restore(snapshot));
            assert.doesNotThrow(() => new BehaviourTree("root { sequence { action [a] } }", agent).restore(snapshot));
        });
    });
});

describe("Restoring a snapshot", () => {
    const definition =
        "root { sequence { repeat [3] { sequence { action [a] wait [1000] } } lotto { action [b] action [c] } action [d] } }";

    const script = {
        a: RUNNING_THEN_SUCCEEDED(1),
        b: RUNNING_THEN_SUCCEEDED(1),
        c: RUNNING_THEN_SUCCEEDED(1),
        d: RUNNING_THEN_SUCCEEDED(1)
    };

    let clock: SinonFakeTimers;

    beforeEach(() => {
        clock = sinon.useFakeTimers();
    });

    afterEach(() => {
        clock.restore();
    });

    const stepAndTick = (tree: BehaviourTree, steps: number) => {
        for (let step = 0; step < steps; step++) {
            tree.step();
            clock.tick(400);
        }
    };

    describe("does not call the onNodeStateChange option, whatever state the tree and the snapshot are in", () => {
        for (let sourceSteps = 0; sourceSteps <= 14; sourceSteps++) {
            for (const restoredSteps of [0, 5]) {
                it(`when a snapshot after ${sourceSteps} steps is restored to a tree stepped ${restoredSteps} times`, () => {
                    const source = new BehaviourTree(definition, createScriptedAgent(script).agent);
                    stepAndTick(source, sourceSteps);
                    const snapshot = persist(source.snapshot());

                    const changes: unknown[] = [];
                    const tree = new BehaviourTree(definition, createScriptedAgent(script).agent, {
                        onNodeStateChange: (change) => changes.push(change)
                    });
                    stepAndTick(tree, restoredSteps);
                    changes.length = 0;

                    tree.restore(snapshot);

                    assert.deepEqual(changes, []);
                    assert.deepEqual(getNodeStates(tree), getNodeStates(source));
                });
            }
        }
    });

    it("leaves the next step to report the changes that it makes as usual", () => {
        const { agent } = createScriptedAgent({ a: RUNNING_THEN_SUCCEEDED(1), b: RUNNING_THEN_SUCCEEDED(1) });
        const definition = "root { sequence { action [a] action [b] } }";
        const source = new BehaviourTree(definition, agent);
        source.step();
        source.step();
        const snapshot = persist(source.snapshot());

        const changes: { type: string; previousState: State; state: State }[] = [];
        const tree = new BehaviourTree(definition, agent, {
            onNodeStateChange: ({ type, previousState, state }) => changes.push({ type, previousState, state })
        });

        tree.restore(snapshot);
        tree.step();

        assert.deepEqual(changes, [
            { type: "action", previousState: State.RUNNING, state: State.SUCCEEDED },
            { type: "sequence", previousState: State.RUNNING, state: State.SUCCEEDED },
            { type: "root", previousState: State.RUNNING, state: State.SUCCEEDED }
        ]);
    });
});

describe("A snapshot", () => {
    const definition =
        "root { sequence { repeat [2,3] { sequence { action [a] wait [500,1000] } } lotto { action [b] action [c] } retry [2] { action [d] } } }";

    const script = {
        a: RUNNING_THEN_SUCCEEDED(1),
        b: RUNNING_THEN_SUCCEEDED(1),
        c: RUNNING_THEN_SUCCEEDED(1),
        d: RUNNING_THEN_FAILED(1)
    };

    const STEPS = 20;

    let clock: SinonFakeTimers;

    beforeEach(() => {
        clock = sinon.useFakeTimers({ toFake: ["Date"] });
    });

    afterEach(() => {
        clock.restore();
    });

    const createTree = (useGetDeltaTime: boolean) => {
        const random = (() => {
            let drawn = 0;
            return () => RANDOM_SEQUENCE[drawn++ % RANDOM_SEQUENCE.length];
        })();

        return new BehaviourTree(definition, createScriptedAgent(script).agent, {
            random,
            ...(useGetDeltaTime ? { getDeltaTime: () => 0.4 } : {})
        });
    };

    const stepAndTick = (tree: BehaviourTree) => {
        tree.step();
        clock.tick(400);
    };

    for (const useGetDeltaTime of [false, true]) {
        describe(`taken from a tree using ${useGetDeltaTime ? "the 'getDeltaTime' option" : "the clock"}`, () => {
            it("is not changed by stepping the tree that it was taken from", () => {
                const tree = createTree(useGetDeltaTime);

                for (let step = 0; step < STEPS; step++) {
                    const snapshot = tree.snapshot();
                    const before = JSON.stringify(snapshot);

                    stepAndTick(tree);

                    assert.equal(JSON.stringify(snapshot), before, `after step ${step + 1}`);
                }
            });

            it("is not changed by stepping a tree that it was restored to", () => {
                const tree = createTree(useGetDeltaTime);

                for (let step = 0; step < STEPS; step++) {
                    const snapshot = tree.snapshot();
                    const before = JSON.stringify(snapshot);
                    const restored = createTree(useGetDeltaTime);

                    restored.restore(snapshot);
                    for (let restoredStep = 0; restoredStep < STEPS; restoredStep++) {
                        stepAndTick(restored);
                    }

                    assert.equal(JSON.stringify(snapshot), before, `restored after step ${step}`);

                    stepAndTick(tree);
                }
            });

            it("is equal to a snapshot taken from a tree straight after it was restored", () => {
                const tree = createTree(useGetDeltaTime);

                for (let step = 0; step < STEPS; step++) {
                    const snapshot = persist(tree.snapshot());
                    const restored = createTree(useGetDeltaTime);

                    restored.restore(snapshot);

                    assert.deepEqual(persist(restored.snapshot()), snapshot, `restored after step ${step}`);

                    stepAndTick(tree);
                }
            });
        });
    }

    describe("of a tree with a promise-based action", () => {
        const definition = "root { sequence { action [work] action [after] } }";

        const createTree = (work: () => Promise<State.SUCCEEDED | State.FAILED>) =>
            new BehaviourTree(definition, { work, after: () => State.SUCCEEDED });

        it("is not changed by the promise settling, or by the tree handling the result", async () => {
            const deferred = createDeferred<State.SUCCEEDED>();
            const tree = createTree(() => deferred.promise);
            tree.step();
            const snapshot = tree.snapshot();
            const before = JSON.stringify(snapshot);

            deferred.resolve(State.SUCCEEDED);
            await settlePromises();
            assert.equal(JSON.stringify(snapshot), before);

            tree.step();
            assert.equal(JSON.stringify(snapshot), before);
        });

        it("is not changed by stepping a tree that it was restored to, and is equal to a snapshot taken straight after", async () => {
            const deferred = createDeferred<State.SUCCEEDED>();
            const tree = createTree(() => deferred.promise);
            tree.step();
            deferred.resolve(State.SUCCEEDED);
            await settlePromises();
            const snapshot = tree.snapshot();
            const before = JSON.stringify(snapshot);

            const restored = createTree(() => deferred.promise);
            restored.restore(snapshot);
            assert.deepEqual(persist(restored.snapshot()), persist(snapshot));

            restored.step();
            restored.step();
            assert.equal(JSON.stringify(snapshot), before);
        });

        it("saved while the promise is pending is equal to a snapshot taken straight after it was restored", () => {
            const tree = createTree(() => new Promise<State.SUCCEEDED>(() => {}));
            tree.step();
            const snapshot = persist(tree.snapshot());

            const restored = createTree(() => new Promise<State.SUCCEEDED>(() => {}));
            restored.restore(snapshot);

            assert.deepEqual(persist(restored.snapshot()), snapshot);
        });
    });
});
