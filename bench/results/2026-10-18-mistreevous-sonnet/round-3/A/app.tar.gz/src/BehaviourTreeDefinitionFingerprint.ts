import { RootNodeDefinition } from "./BehaviourTreeDefinition";

/**
 * Gets a fingerprint of a tree definition, which is the same for any definitions that build the same tree and, for all practical purposes, different otherwise.
 * A definition in MDSL has the same fingerprint as the equivalent definition in JSON, so it can be used to tell whether two trees were built from the same definition.
 * @param rootNodeDefinitions The array of root node definitions, as returned from validating a definition.
 * @returns The fingerprint of the definition.
 */
export function getDefinitionFingerprint(rootNodeDefinitions: RootNodeDefinition[]): string {
    // The order of the named root nodes has no bearing on the tree that is built, only the main root node and the nodes that reference the others.
    const sortedRootNodeDefinitions = [...rootNodeDefinitions].sort((a, b) => compareStrings(a.id ?? "", b.id ?? ""));

    const canonical = stringifyCanonical(
        sortedRootNodeDefinitions.map((definition) => normaliseNodeDefinition(definition))
    );

    // Hashing twice with different seeds gives 106 bits, which makes an accidental match between different definitions vanishingly unlikely.
    return `${hash(canonical, 0)}${hash(canonical, 1)}`;
}

/**
 * The properties of a node definition that are used to build a node, by node type.
 * Any others, such as a comment added to a JSON definition, have no bearing on the tree that is built.
 */
const NODE_PROPERTIES: Record<string, string[]> = {
    root: ["id", "child"],
    repeat: ["child", "iterations"],
    retry: ["child", "attempts"],
    flip: ["child"],
    succeed: ["child"],
    fail: ["child"],
    sequence: ["children"],
    selector: ["children"],
    parallel: ["children"],
    race: ["children"],
    all: ["children"],
    lotto: ["children", "weights"],
    branch: ["ref"],
    action: ["call", "args"],
    condition: ["call", "args"],
    wait: ["duration"]
};

/**
 * Gets a copy of a node definition, and every node definition nested within it, with only the properties that are used to build the tree and with the default values filled in.
 * This is where a definition in MDSL, which always includes the defaults, and a definition in JSON, which usually doesn't, would otherwise differ.
 * @param definition The node definition.
 * @returns The normalised copy.
 */
function normaliseNodeDefinition(definition: any): any {
    const normalised: Record<string, any> = { type: definition.type };

    for (const property of NODE_PROPERTIES[definition.type] ?? []) {
        const value = definition[property];

        if (property === "child") {
            normalised.child = normaliseNodeDefinition(value);
        } else if (property === "children") {
            normalised.children = value.map(normaliseNodeDefinition);
        } else {
            normalised[property] = value;
        }
    }

    // Action and condition definitions treat missing arguments as an empty array.
    if (normalised.type === "action" || normalised.type === "condition") {
        normalised.args = normalised.args ?? [];
    }

    for (const attribute of ["entry", "exit", "step"]) {
        if (definition[attribute]) {
            normalised[attribute] = normaliseAttributeDefinition(definition[attribute]);
        }
    }

    for (const guard of ["while", "until"]) {
        if (definition[guard]) {
            normalised[guard] = {
                ...normaliseAttributeDefinition(definition[guard]),
                // Guards treat a missing value as not succeeding on abort.
                succeedOnAbort: !!definition[guard].succeedOnAbort
            };
        }
    }

    return normalised;
}

/**
 * Gets the JSON representation of a value, with the properties of every object in a consistent order and without any that are undefined.
 * @param value The value.
 * @returns The JSON representation of a value.
 */
function stringifyCanonical(value: unknown): string {
    if (Array.isArray(value)) {
        return `[${value.map((element) => stringifyCanonical(element ?? null)).join(",")}]`;
    }

    if (typeof value === "object" && value !== null) {
        const entries = Object.entries(value)
            .filter(([, propertyValue]) => propertyValue !== undefined)
            .sort(([a], [b]) => compareStrings(a, b))
            .map(([key, propertyValue]) => `${JSON.stringify(key)}:${stringifyCanonical(propertyValue)}`);

        return `{${entries.join(",")}}`;
    }

    return JSON.stringify(value) ?? "null";
}

/**
 * Compares two strings by their code units, giving the same order wherever it is run.
 */
function compareStrings(a: string, b: string): number {
    return a < b ? -1 : a > b ? 1 : 0;
}

/**
 * Gets a 53 bit hash of a string as a fixed length hexadecimal string (cyrb53).
 * @param value The string to hash.
 * @param seed The seed, with a different hash being produced for each.
 * @returns The hash.
 */
function hash(value: string, seed: number): string {
    let h1 = 0xdeadbeef ^ seed;
    let h2 = 0x41c6ce57 ^ seed;

    for (let index = 0; index < value.length; index++) {
        const code = value.charCodeAt(index);
        h1 = Math.imul(h1 ^ code, 2654435761);
        h2 = Math.imul(h2 ^ code, 1597334677);
    }

    h1 = Math.imul(h1 ^ (h1 >>> 16), 2246822507) ^ Math.imul(h2 ^ (h2 >>> 13), 3266489909);
    h2 = Math.imul(h2 ^ (h2 >>> 16), 2246822507) ^ Math.imul(h1 ^ (h1 >>> 13), 3266489909);

    return (4294967296 * (2097151 & h2) + (h1 >>> 0)).toString(16).padStart(14, "0");
}

/**
 * Gets a copy of a node attribute definition with only the properties that are used to build the tree and with the default values filled in.
 * @param definition The node attribute definition.
 * @returns The normalised copy.
 */
function normaliseAttributeDefinition(definition: any): any {
    // Attributes treat missing arguments as an empty array.
    return { call: definition.call, args: definition.args ?? [] };
}
