import { AnyState } from "./State";

/**
 * The version of the snapshot format produced by the current version of the library.
 */
export const SNAPSHOT_VERSION = 1;

/**
 * A snapshot of the execution state of a single node in a behaviour tree instance.
 * Only the properties relevant to the type of the node will be defined.
 */
export type NodeSnapshot = {
    /**
     * The tree node type.
     */
    type: string;
    /**
     * The state of the tree node.
     */
    state: AnyState;
    /**
     * The snapshots of the child nodes of this node, defined if this node is a composite or decorator node.
     */
    children?: NodeSnapshot[];
    /**
     * The number of iterations completed so far, defined if this is a repeat node.
     */
    currentIterationCount?: number;
    /**
     * The number of iterations to make, or null for infinite iterations, defined if this is a repeat node.
     */
    targetIterationCount?: number | null;
    /**
     * The number of attempts made so far, defined if this is a retry node.
     */
    currentAttemptCount?: number;
    /**
     * The number of attempts to make, or null for infinite attempts, defined if this is a retry node.
     */
    targetAttemptCount?: number | null;
    /**
     * The index of the child that was picked to be the active one, or null if there isn't one, defined if this is a lotto node.
     */
    selectedChildIndex?: number | null;
    /**
     * The duration in milliseconds that this node has waited for, defined if this is a wait node.
     */
    waitedDuration?: number;
    /**
     * The duration in milliseconds that this node will wait for, or null if it will wait indefinitely, defined if this is a wait node.
     */
    totalDuration?: number | null;
    /**
     * The settled outcome of the promise that an action node is waiting to handle, defined if this is an action node with such a promise.
     * If the promise was resolved then the value is the state that it resolved with, or null if that was not a valid state.
     * If the promise was rejected then the value is the rejection reason as a string.
     */
    settledPromise?: {
        isResolved: boolean;
        value: string | null;
    };
};

/**
 * A snapshot of the execution state of a behaviour tree instance.
 * This is a plain object that can be serialized to JSON and later restored to a tree built from the same definition.
 * An action node that is awaiting a promise that has not settled yet is recorded as not having started.
 */
export type BehaviourTreeSnapshot = {
    /**
     * The version of the snapshot format.
     */
    version: number;
    /**
     * The fingerprint of the definition of the tree that the snapshot was taken from, which is the same for an MDSL definition and its equivalent JSON definition.
     */
    definition: string;
    /**
     * The snapshot of the main root node.
     */
    root: NodeSnapshot;
};

/**
 * Gets whether a value is an integer greater than or equal to zero.
 * @param value The value to check.
 * @returns Whether the value is a non-negative integer.
 */
export function isNonNegativeInteger(value: unknown): value is number {
    return typeof value === "number" && Number.isInteger(value) && value >= 0;
}

/**
 * Gets whether a value is a finite number greater than or equal to zero.
 * @param value The value to check.
 * @returns Whether the value is a non-negative finite number.
 */
export function isNonNegativeNumber(value: unknown): value is number {
    return typeof value === "number" && Number.isFinite(value) && value >= 0;
}
