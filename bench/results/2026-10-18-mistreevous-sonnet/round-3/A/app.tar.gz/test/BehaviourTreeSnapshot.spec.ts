import { assert } from "chai";
import sinon, { SinonFakeTimers } from "sinon";

import { BehaviourTree, BehaviourTreeSnapshot, NodeDetails, State } from "../src/index";
import { Agent } from "../src/Agent";

import { findNode } from "./TestUtilities";

/**
 * Round-trip a snapshot through JSON, as an application persisting it to storage would.
 */
const throughJSON = (snapshot: BehaviourTreeSnapshot): BehaviourTreeSnapshot => JSON.parse(JSON.stringify(snapshot));

/**
 * Get the details of every node in a tree without the randomly generated node identifiers, which will differ between tree instances.
 */
const getStates = (tree: BehaviourTree): unknown => {
    const strip = ({ id, children, ...details }: NodeDetails): unknown => ({
        ...details,
        children: children?.map(strip)
    });

    return strip(tree.getTreeNodeDetails());
};

/**
 * Get a pseudo-random number that is purely a function of a seed and the number of random numbers requested before it.
 */
const randomAt = (seed: number, index: number): number => {
    let t = (seed + Math.imul(index + 1, 0x6d2b79f5)) | 0;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
};

/**
 * Create a 'random' function option whose sequence can be resumed from any point.
 */
const createRandom = (seed: number, startIndex = 0) => {
    let index = startIndex;
    return { random: () => randomAt(seed, index++), getIndex: () => index };
};

describe("A BehaviourTree instance", () => {
    let clock: SinonFakeTimers;

    beforeEach(() => {
        clock = sinon.useFakeTimers();
    });

    afterEach(() => {
        clock.restore();
    });

    describe("has a snapshot method that", () => {
        it("returns a plain object that is unchanged by a JSON round trip", () => {
            const tree = new BehaviourTree(
                `root { repeat [2,3] { sequence { lotto { action [A] action [B] } wait [100,200] action [C] } } }`,
                { A: () => State.SUCCEEDED, B: () => State.SUCCEEDED, C: () => State.RUNNING },
                { random: () => 0.5 }
            );

            // Snapshot the tree before it is stepped, while it is running and when it has finished.
            const snapshots = [tree.snapshot()];

            tree.step();
            snapshots.push(tree.snapshot());

            clock.tick(1000);
            tree.step();
            snapshots.push(tree.snapshot());

            for (const snapshot of snapshots) {
                assert.deepEqual(JSON.parse(JSON.stringify(snapshot)), snapshot);
            }
        });

        it("returns a snapshot that does not share state with the tree", () => {
            const tree = new BehaviourTree("root { sequence { action [A] action [B] } }", {
                A: () => State.SUCCEEDED,
                B: () => State.RUNNING
            });
            tree.step();

            const snapshot = tree.snapshot();
            const copy = throughJSON(snapshot);

            // A snapshot is not a live view of the tree.
            tree.reset();
            assert.deepEqual(snapshot, copy);

            // Changing a snapshot after restoring from it does not change the tree.
            tree.restore(snapshot);
            snapshot.root.state = State.FAILED;
            snapshot.root.children![0].children![1].state = State.FAILED;
            assert.deepEqual(tree.snapshot(), copy);
        });

        describe("returns a snapshot that stepping neither the tree nor a tree restored from it changes, and that a restored tree gives back", () => {
            const agent = () => ({
                A: () => State.SUCCEEDED,
                B: () => State.RUNNING,
                F: () => State.FAILED,
                Settles: () => Promise.resolve(State.SUCCEEDED),
                Invalid: () => Promise.resolve("invalid" as unknown as State.SUCCEEDED),
                Rejects: () => Promise.reject(new Error("rejected"))
            });

            const definitions: [string, string][] = [
                [
                    "repeat, lotto and wait",
                    "root { repeat [2,3] { sequence { lotto { action [A] action [B] } wait [100,200] action [A] } } }"
                ],
                [
                    "retry and selector",
                    "root { retry [2,3] { selector { action [F] sequence { wait [50] action [F] } } } }"
                ],
                [
                    "parallel, race and all",
                    "root { parallel { race { wait [100] action [B] } all { wait [50] action [A] } } }"
                ],
                ["wait without a duration", "root { sequence { action [A] wait } }"],
                ["promise that settles", "root { sequence { action [A] action [Settles] action [B] } }"],
                ["promise that resolves with an invalid value", "root { action [Invalid] }"],
                ["promise that rejects", "root { action [Rejects] }"]
            ];

            for (const [name, definition] of definitions) {
                for (const useDeltaTime of [false, true]) {
                    it(`for ${name}${useDeltaTime ? " with getDeltaTime" : ""}`, async () => {
                        const options = { random: () => 0.5, ...(useDeltaTime ? { getDeltaTime: () => 0.03 } : {}) };
                        const tree = new BehaviourTree(definition, agent(), options);
                        const restored = new BehaviourTree(definition, agent(), options);

                        for (let i = 0; i < 8; i++) {
                            try {
                                tree.step();
                            } catch {
                                // A rejected or invalid promise throws when it is handled, which is not what is being tested.
                            }
                            await Promise.resolve();
                            clock.tick(40);

                            const snapshot = tree.snapshot();
                            const copy = throughJSON(snapshot);

                            // Stepping the tree it was taken from does not change it.
                            try {
                                tree.step();
                            } catch {
                                // See above.
                            }
                            clock.tick(40);
                            assert.deepEqual(snapshot, copy, `after stepping the tree at step ${i}`);

                            // Restoring from it does not change it, and the restored tree gives it back before it is stepped.
                            restored.restore(snapshot);
                            assert.deepEqual(snapshot, copy, `after restoring at step ${i}`);
                            assert.deepEqual(
                                throughJSON(restored.snapshot()),
                                copy,
                                `snapshot after restoring at step ${i}`
                            );

                            // Stepping the restored tree does not change it.
                            try {
                                restored.step();
                            } catch {
                                // See above.
                            }
                            await Promise.resolve();
                            clock.tick(40);
                            assert.deepEqual(snapshot, copy, `after stepping the restored tree at step ${i}`);
                        }
                    });
                }
            }
        });

        it("captures the state of every node", () => {
            const tree = new BehaviourTree("root { sequence { action [A] action [B] } }", {
                A: () => State.SUCCEEDED,
                B: () => State.RUNNING
            });
            tree.step();

            const { root } = tree.snapshot();

            assert.equal(root.type, "root");
            assert.equal(root.state, State.RUNNING);
            assert.equal(root.children![0].type, "sequence");
            assert.equal(root.children![0].state, State.RUNNING);
            assert.deepEqual(
                root.children![0].children!.map(({ type, state }) => [type, state]),
                [
                    ["action", State.SUCCEEDED],
                    ["action", State.RUNNING]
                ]
            );
        });

        it("does not throw if an action node is awaiting a promise that has not settled yet, and leaves the tree alone", async () => {
            let resolve: (state: State.SUCCEEDED) => void = () => {};
            const tree = new BehaviourTree("root { action [A] }", {
                A: () => new Promise<State.SUCCEEDED>((r) => (resolve = r))
            });

            tree.step();

            assert.doesNotThrow(() => tree.snapshot());
            assert.equal(tree.getState(), State.RUNNING);
            assert.equal(findNode(tree, "action", "A").state, State.RUNNING);

            // The tree that the snapshot was taken from still gets the outcome of its promise.
            resolve(State.SUCCEEDED);
            await Promise.resolve();
            tree.step();
            assert.equal(tree.getState(), State.SUCCEEDED);
        });

        it("is the same for trees built from equivalent definitions and different for trees built from different ones", () => {
            const agent = { A: () => State.SUCCEEDED };
            const fromMDSL = new BehaviourTree("root { action [A, 1] }", agent).snapshot();
            const fromJSON = new BehaviourTree(
                { type: "root", child: { type: "action", call: "A", args: [1] } },
                agent
            );
            const other = new BehaviourTree("root { action [A, 2] }", agent).snapshot();

            assert.deepEqual(fromJSON.snapshot(), fromMDSL);
            assert.notDeepEqual(other, fromMDSL);
        });
    });

    describe("has a restore method that", () => {
        const definition = "root { sequence { action [A] repeat [3] { action [B] } } }";
        const createAgent = () => ({ A: () => State.SUCCEEDED, B: () => State.RUNNING });

        describe("throws and leaves the tree untouched if the snapshot", () => {
            const createSteppedTree = () => {
                const tree = new BehaviourTree(definition, createAgent());
                tree.step();
                return tree;
            };

            const validSnapshot = () => createSteppedTree().snapshot();

            const cases: [string, (snapshot: any) => unknown, string][] = [
                ["is not an object", () => null, "invalid snapshot: expected an object"],
                ["is a string", () => "snapshot", "invalid snapshot: expected an object"],
                ["has an unsupported version", (s) => ({ ...s, version: 99 }), "invalid snapshot: unsupported version"],
                [
                    "has no root node",
                    (s) => ({ version: s.version, definition: s.definition }),
                    "invalid snapshot: expected an object for root node"
                ],
                [
                    "has a root node of the wrong type",
                    (s) => ({ ...s, root: { ...s.root, type: "sequence" } }),
                    "invalid snapshot: expected 'root' node at depth '0' but got 'sequence'"
                ],
                [
                    "has a nested node of the wrong type",
                    (s) => {
                        s.root.children[0].children[1].type = "retry";
                        return s;
                    },
                    "invalid snapshot: expected 'repeat' node at depth '2' but got 'retry'"
                ],
                [
                    "has a node with an invalid state",
                    (s) => {
                        s.root.children[0].children[0].state = "running";
                        return s;
                    },
                    "invalid snapshot: invalid state 'running' for action node at depth '2'"
                ],
                [
                    "has a composite node with the wrong number of children",
                    (s) => {
                        s.root.children[0].children.pop();
                        return s;
                    },
                    "invalid snapshot: expected 2 children for sequence node at depth '1' but got 1"
                ],
                [
                    "has a node with no children where it should have them",
                    (s) => {
                        delete s.root.children;
                        return s;
                    },
                    "invalid snapshot: expected 1 children for root node at depth '0' but got 0"
                ],
                [
                    "has a negative repeat iteration count",
                    (s) => {
                        s.root.children[0].children[1].currentIterationCount = -1;
                        return s;
                    },
                    "invalid snapshot: expected 'currentIterationCount' to be a non-negative integer for repeat node at depth '2'"
                ],
                [
                    "has a repeat target iteration count that is not a number or null",
                    (s) => {
                        s.root.children[0].children[1].targetIterationCount = "3";
                        return s;
                    },
                    "invalid snapshot: expected 'targetIterationCount' to be a non-negative integer or null for repeat node at depth '2'"
                ]
            ];

            for (const [name, corrupt, message] of cases) {
                it(name, () => {
                    const tree = createSteppedTree();
                    const before = getStates(tree);
                    const snapshotBefore = tree.snapshot();

                    assert.throws(
                        () => tree.restore(corrupt(validSnapshot()) as BehaviourTreeSnapshot),
                        Error,
                        message
                    );

                    assert.deepEqual(getStates(tree), before);
                    assert.deepEqual(tree.snapshot(), snapshotBefore);
                });
            }

            it("has the right definition but a node with the wrong structure", () => {
                const tree = new BehaviourTree(definition, createAgent());
                const snapshot: any = tree.snapshot();
                snapshot.root.children[0].children[1] = { type: "retry", state: State.READY, children: [] };

                assert.throws(() => tree.restore(snapshot), Error, "invalid snapshot: expected 'repeat' node");
            });
        });

        describe("rejects input that is not a snapshot", () => {
            const inputs: [string, unknown][] = [
                ["null", null],
                ["undefined", undefined],
                ["a string", "snapshot"],
                [
                    "a JSON string of a snapshot",
                    JSON.stringify(new BehaviourTree(definition, createAgent()).snapshot())
                ],
                ["a number", 42],
                ["a boolean", true],
                ["a function", () => ({})],
                ["an empty array", []],
                ["an array of a snapshot", [new BehaviourTree(definition, createAgent()).snapshot()]],
                ["an empty object", {}],
                ["an object with only a version", { version: 1 }],
                ["an object with only a definition", { definition: "abc" }],
                ["an object with only a root", { root: { type: "root", state: State.READY, children: [] } }],
                ["an object with unrelated fields", { foo: "bar", state: State.READY }],
                [
                    "a node snapshot rather than a tree snapshot",
                    new BehaviourTree(definition, createAgent()).snapshot().root
                ]
            ];

            for (const [name, input] of inputs) {
                it(`${name}, leaving the tree untouched`, () => {
                    const tree = new BehaviourTree(definition, createAgent());
                    tree.step();
                    const before = getStates(tree);
                    const snapshotBefore = tree.snapshot();

                    assert.throws(() => tree.restore(input as BehaviourTreeSnapshot), Error);

                    assert.deepEqual(getStates(tree), before);
                    assert.deepEqual(tree.snapshot(), snapshotBefore);
                });
            }

            it("with a definition that is not a string", () => {
                const tree = new BehaviourTree(definition, createAgent());
                const snapshot: any = { ...tree.snapshot(), definition: 123 };

                assert.throws(() => tree.restore(snapshot), Error, "invalid snapshot");
            });
        });

        describe("given a snapshot taken from a tree built from a different definition", () => {
            const MISMATCH_MESSAGE = "does not match the tree's definition";

            const agent = () => ({
                A: () => State.SUCCEEDED,
                B: () => State.RUNNING,
                Guard: () => true,
                Check: () => true
            });

            // Pairs of definitions that have the same structure of nodes, which is the case a structural check cannot tell apart.
            const differentDefinitions: [string, string, string][] = [
                [
                    "the name of an action",
                    "root { sequence { action [A] action [B] } }",
                    "root { sequence { action [A] action [A] } }"
                ],
                ["the arguments of an action", "root { action [A, 1] }", "root { action [A, 2] }"],
                ["the type of an argument", "root { action [A, 1] }", 'root { action [A, "1"] }'],
                ["the name of a condition", "root { condition [Guard] }", "root { condition [Check] }"],
                ["the type of a composite", "root { sequence { action [A] } }", "root { selector { action [A] } }"],
                ["the type of a decorator", "root { flip { action [A] } }", "root { succeed { action [A] } }"],
                ["the duration of a wait", "root { wait [100] }", "root { wait [200] }"],
                ["the duration range of a wait", "root { wait [100, 200] }", "root { wait [100, 300] }"],
                ["a wait with and without a duration", "root { wait [100] }", "root { wait }"],
                [
                    "the iterations of a repeat",
                    "root { repeat [3] { action [B] } }",
                    "root { repeat [4] { action [B] } }"
                ],
                ["the attempts of a retry", "root { retry [3] { action [B] } }", "root { retry [4] { action [B] } }"],
                [
                    "the weights of a lotto",
                    "root { lotto [1, 2] { action [A] action [B] } }",
                    "root { lotto [2, 1] { action [A] action [B] } }"
                ],
                [
                    "the order of the children",
                    "root { sequence { action [A] action [B] } }",
                    "root { sequence { action [B] action [A] } }"
                ],
                ["a guard", "root { action [B] while(Guard) }", "root { action [B] until(Guard) }"],
                [
                    "the arguments of a guard",
                    "root { action [B] while(Guard, 1) }",
                    "root { action [B] while(Guard, 2) }"
                ],
                [
                    "whether a guard succeeds on abort",
                    "root { action [B] while(Guard) }",
                    "root { action [B] while(Guard) then succeed }"
                ],
                ["a callback", "root { action [B] entry(A) }", "root { action [B] exit(A) }"],
                ["the arguments of a callback", "root { action [B] entry(A, 1) }", "root { action [B] entry(A, 2) }"],
                [
                    "the structure",
                    "root { sequence { action [A] action [B] } }",
                    "root { sequence { action [A] repeat [3] { action [B] } } }"
                ],
                [
                    "a subtree",
                    "root { branch [S] } root [S] { action [A] }",
                    "root { branch [S] } root [S] { action [B] }"
                ],
                [
                    "the name of a subtree",
                    "root { branch [S] } root [S] { action [A] } root [T] { action [B] }",
                    "root { branch [T] } root [S] { action [A] } root [T] { action [B] }"
                ]
            ];

            for (const [name, source, target] of differentDefinitions) {
                it(`that differs in ${name} throws and leaves the tree untouched`, () => {
                    const sourceTree = new BehaviourTree(source, agent());
                    sourceTree.step();
                    const snapshot = throughJSON(sourceTree.snapshot());

                    const changes: unknown[] = [];
                    const tree = new BehaviourTree(target, agent(), { onNodeStateChange: (c) => changes.push(c) });
                    tree.step();
                    const before = getStates(tree);
                    const snapshotBefore = tree.snapshot();
                    changes.length = 0;

                    assert.throws(() => tree.restore(snapshot), Error, MISMATCH_MESSAGE);

                    assert.deepEqual(getStates(tree), before);
                    assert.deepEqual(tree.snapshot(), snapshotBefore);
                    assert.lengthOf(changes, 0);
                });
            }

            it("throws the same error for a JSON definition", () => {
                const sourceTree = new BehaviourTree({ type: "root", child: { type: "action", call: "A" } }, agent());
                const tree = new BehaviourTree({ type: "root", child: { type: "action", call: "B" } }, agent());

                assert.throws(() => tree.restore(sourceTree.snapshot()), Error, MISMATCH_MESSAGE);
            });

            it("throws before any other check of the snapshot", () => {
                const sourceTree = new BehaviourTree("root { sequence { action [A] action [B] } }", agent());
                const tree = new BehaviourTree("root { action [A] }", agent());

                assert.throws(() => tree.restore(sourceTree.snapshot()), Error, MISMATCH_MESSAGE);
            });
        });

        describe("given a snapshot taken from a tree built from an equivalent definition", () => {
            const mdsl = `
                root {
                    sequence while(Guard, 1) then succeed entry(Enter) exit(Leave, "x") {
                        action [A, 1, "x", null, true]
                        condition [Cond]
                        wait [10, 20]
                        wait
                        lotto [1, 2] {
                            action [B]
                            action [C]
                        }
                        repeat {
                            flip {
                                succeed {
                                    fail {
                                        action [D]
                                    }
                                }
                            }
                        }
                        retry [3] {
                            branch [Sub]
                        }
                        race { action [X] }
                        all { action [Y] }
                        parallel { action [Z] step(Tick) }
                    }
                }
                root [Sub] {
                    sequence { action [A] action [B] }
                }
                root [Other] {
                    action [C]
                }
            `;

            // The same definition in JSON, leaving out the properties that have default values, with the properties in a different order and the named root nodes in a different order.
            const json = [
                {
                    id: "Other",
                    child: { call: "C", type: "action" },
                    type: "root"
                },
                {
                    id: "Sub",
                    child: {
                        children: [
                            { type: "action", call: "A" },
                            { type: "action", call: "B", args: [] }
                        ],
                        type: "sequence"
                    },
                    type: "root"
                },
                {
                    type: "root",
                    child: {
                        exit: { args: ["x"], call: "Leave" },
                        entry: { call: "Enter" },
                        while: { call: "Guard", args: [1], succeedOnAbort: true },
                        type: "sequence",
                        children: [
                            { type: "action", call: "A", args: [1, "x", null, true] },
                            { type: "condition", call: "Cond" },
                            { type: "wait", duration: [10, 20] },
                            { type: "wait" },
                            {
                                type: "lotto",
                                weights: [1, 2],
                                children: [
                                    { type: "action", call: "B" },
                                    { type: "action", call: "C" }
                                ]
                            },
                            {
                                type: "repeat",
                                child: {
                                    type: "flip",
                                    child: {
                                        type: "succeed",
                                        child: { type: "fail", child: { type: "action", call: "D" } }
                                    }
                                }
                            },
                            { type: "retry", attempts: 3, child: { type: "branch", ref: "Sub" } },
                            { type: "race", children: [{ type: "action", call: "X" }] },
                            { type: "all", children: [{ type: "action", call: "Y" }] },
                            {
                                type: "parallel",
                                children: [{ type: "action", call: "Z", step: { call: "Tick" } }]
                            }
                        ]
                    }
                }
            ];

            const agent = () => ({
                A: () => State.SUCCEEDED,
                B: () => State.SUCCEEDED,
                C: () => State.SUCCEEDED,
                D: () => State.RUNNING,
                X: () => State.RUNNING,
                Y: () => State.RUNNING,
                Z: () => State.RUNNING,
                Guard: () => true,
                Cond: () => true,
                Enter: () => {},
                Leave: () => {},
                Tick: () => {}
            });

            it("restores a snapshot of a MDSL definition to a tree built from the equivalent JSON definition", () => {
                const source = new BehaviourTree(mdsl, agent());
                source.step();
                const target = new BehaviourTree(json as any, agent());

                target.restore(throughJSON(source.snapshot()));

                assert.deepEqual(getStates(target), getStates(source));
            });

            it("restores a snapshot of a JSON definition to a tree built from the equivalent MDSL definition", () => {
                const source = new BehaviourTree(json as any, agent());
                source.step();
                const target = new BehaviourTree(mdsl, agent());

                target.restore(throughJSON(source.snapshot()));

                assert.deepEqual(getStates(target), getStates(source));
            });

            it("restores a snapshot of a JSON definition of a single root node to a tree built from it in an array", () => {
                const root = { type: "root", child: { type: "action", call: "B" } };
                const source = new BehaviourTree(root as any, agent());
                source.step();
                const target = new BehaviourTree([root] as any, agent());

                target.restore(source.snapshot());

                assert.deepEqual(getStates(target), getStates(source));
                assert.equal(target.getState(), State.SUCCEEDED);
            });

            it("restores a snapshot to a tree built from a JSON definition with extra properties that are ignored when building the tree", () => {
                const source = new BehaviourTree(
                    "root { sequence while(Guard) { action [A] action [B, 1] } }",
                    agent()
                );
                source.step();
                const target = new BehaviourTree(
                    {
                        type: "root",
                        comment: "ignored",
                        child: {
                            type: "sequence",
                            while: { call: "Guard", note: "ignored" },
                            children: [
                                { type: "action", call: "A", duration: 100, description: "ignored" },
                                { type: "action", call: "B", args: [1], children: [] }
                            ]
                        }
                    } as any,
                    agent()
                );

                target.restore(source.snapshot());

                assert.deepEqual(getStates(target), getStates(source));
            });

            it("restores a snapshot to a tree built from MDSL with different whitespace", () => {
                const source = new BehaviourTree("root { sequence { action [A] action [B] } }", agent());
                source.step();
                const target = new BehaviourTree(
                    "root {\n\tsequence {\n\t\taction [A]\n\t\taction [B]\n\t}\n}",
                    agent()
                );

                target.restore(source.snapshot());

                assert.deepEqual(getStates(target), getStates(source));
            });
        });

        it("throws if a node in a snapshot is invalid for its type", () => {
            // A random value of 0.99 picks the second child, which is left running.
            const lotto = new BehaviourTree("root { lotto { action [A] action [B] } }", createAgent(), {
                random: () => 0.99
            });
            lotto.step();

            const retry = new BehaviourTree("root { retry [2] { action [B] } }", createAgent());
            retry.step();

            const wait = new BehaviourTree("root { wait [100] }", createAgent());
            wait.step();

            const edit = (tree: BehaviourTree, path: number[], values: object) => {
                const snapshot: any = tree.snapshot();
                let node = snapshot.root;
                path.forEach((index) => (node = node.children[index]));
                Object.assign(node, values);
                return snapshot;
            };

            // A running lotto must have a selected child, and it must be one of its children.
            assert.throws(
                () => lotto.restore(edit(lotto, [0], { selectedChildIndex: null })),
                Error,
                "selectedChildIndex"
            );
            assert.throws(
                () => lotto.restore(edit(lotto, [0], { selectedChildIndex: 2 })),
                Error,
                "selectedChildIndex"
            );
            assert.throws(
                () => retry.restore(edit(retry, [0], { currentAttemptCount: 1.5 })),
                Error,
                "currentAttemptCount"
            );
            assert.throws(
                () => retry.restore(edit(retry, [0], { targetAttemptCount: undefined })),
                Error,
                "targetAttemptCount"
            );
            assert.throws(() => wait.restore(edit(wait, [0], { waitedDuration: -1 })), Error, "waitedDuration");
            assert.throws(() => wait.restore(edit(wait, [0], { waitedDuration: NaN })), Error, "waitedDuration");
            assert.throws(() => wait.restore(edit(wait, [0], { totalDuration: "100" })), Error, "totalDuration");
        });

        it("restores a tree to the state of the snapshot, replacing any progress it has made", () => {
            const source = new BehaviourTree(definition, createAgent());
            source.step();
            const snapshot = throughJSON(source.snapshot());

            const target = new BehaviourTree(definition, { A: () => State.SUCCEEDED, B: () => State.FAILED });
            target.step();
            assert.equal(target.getState(), State.FAILED);

            target.restore(snapshot);

            assert.deepEqual(getStates(target), getStates(source));
            assert.deepEqual(target.snapshot(), snapshot);
        });

        it("restores a fresh tree to READY when given the snapshot of a tree that was never stepped", () => {
            const fresh = new BehaviourTree(definition, createAgent());
            const snapshot = fresh.snapshot();

            const tree = new BehaviourTree(definition, createAgent());
            tree.step();
            tree.restore(snapshot);

            assert.equal(tree.getState(), State.READY);
            assert.deepEqual(getStates(tree), getStates(fresh));
        });

        describe("does not call the onNodeStateChange option, and the next step does so as usual", () => {
            type Change = [string, State, State];

            const createObservedTree = (agent: Agent, changes: Change[]) =>
                new BehaviourTree(definition, agent, {
                    onNodeStateChange: ({ type, previousState, state }) => changes.push([type, previousState, state])
                });

            it("when restoring a fresh tree", () => {
                const source = new BehaviourTree(definition, createAgent());
                source.step();
                const snapshot = source.snapshot();

                const changes: Change[] = [];
                const tree = createObservedTree({ A: () => State.SUCCEEDED, B: () => State.SUCCEEDED }, changes);

                tree.restore(snapshot);

                assert.deepEqual(changes, []);
                assert.deepEqual(getStates(tree), getStates(source));

                // The next step reports changes from the restored states.
                tree.step();

                assert.deepEqual(changes, [["action", State.RUNNING, State.SUCCEEDED]]);
            });

            it("when restoring a tree that has made progress, including an action that was awaiting a promise", async () => {
                const promiseDefinition = "root { sequence { action [A] action [P] } }";
                const promiseAgent = () => ({ A: () => State.SUCCEEDED, P: () => Promise.resolve(State.SUCCEEDED) });

                const source = new BehaviourTree(promiseDefinition, promiseAgent());
                source.step();
                await Promise.resolve();
                const snapshot = source.snapshot();
                assert.isDefined(snapshot.root.children![0].children![1].settledPromise);

                const changes: Change[] = [];
                const tree = new BehaviourTree(
                    promiseDefinition,
                    { A: () => State.FAILED, P: () => State.FAILED },
                    {
                        onNodeStateChange: ({ type, previousState, state }) =>
                            changes.push([type, previousState, state])
                    }
                );
                tree.step();
                assert.equal(tree.getState(), State.FAILED);
                changes.length = 0;

                tree.restore(snapshot);

                assert.deepEqual(changes, []);
                assert.deepEqual(getStates(tree), getStates(source));

                tree.step();

                assert.deepEqual(changes, [
                    ["action", State.RUNNING, State.SUCCEEDED],
                    ["sequence", State.RUNNING, State.SUCCEEDED],
                    ["root", State.RUNNING, State.SUCCEEDED]
                ]);
            });

            it("when the snapshot is invalid", () => {
                const changes: Change[] = [];
                const tree = createObservedTree(createAgent(), changes);
                tree.step();
                changes.length = 0;

                assert.throws(() => tree.restore({ ...tree.snapshot(), version: 99 }), Error, "invalid snapshot");
                assert.deepEqual(changes, []);
            });
        });
    });

    describe("continues from a restored snapshot such that", () => {
        describe("a sequence, selector, parallel, race and all node", () => {
            for (const type of ["sequence", "selector", "parallel", "race", "all"]) {
                it(`(${type}) will have the same child states and call the same agent functions in the same order`, () => {
                    const createTree = (calls: string[], counts: { B: number }) =>
                        new BehaviourTree(`root { ${type} { action [A] action [B] action [C] } }`, {
                            A: () => {
                                calls.push("A");
                                return type === "selector" || type === "race" ? State.FAILED : State.SUCCEEDED;
                            },
                            B: () => {
                                calls.push("B");
                                return ++counts.B < 3 ? State.RUNNING : State.SUCCEEDED;
                            },
                            C: () => {
                                calls.push("C");
                                return State.RUNNING;
                            }
                        });

                    const callsA: string[] = [];
                    const countsA = { B: 0 };
                    const original = createTree(callsA, countsA);
                    original.step();

                    const callsAtSnapshot = callsA.length;
                    const callsB: string[] = [];
                    const restored = createTree(callsB, { ...countsA });
                    restored.restore(throughJSON(original.snapshot()));

                    assert.deepEqual(getStates(restored), getStates(original));

                    for (let i = 0; i < 4; i++) {
                        original.step();
                        restored.step();
                        assert.deepEqual(getStates(restored), getStates(original));
                    }

                    assert.deepEqual(callsB, callsA.slice(callsAtSnapshot));
                });
            }
        });

        describe("a repeat node", () => {
            it("keeps its current iteration count", () => {
                const createTree = (calls: string[]) =>
                    new BehaviourTree("root { repeat [3] { action [A] } }", {
                        A: () => {
                            calls.push("A");
                            return State.SUCCEEDED;
                        }
                    });

                const callsA: string[] = [];
                const original = createTree(callsA);
                original.step();
                original.step();
                assert.deepEqual(callsA, ["A", "A"]);

                const callsB: string[] = [];
                const restored = createTree(callsB);
                restored.restore(throughJSON(original.snapshot()));

                // Only one iteration remains.
                restored.step();
                assert.deepEqual(callsB, ["A"]);
                assert.equal(restored.getState(), State.RUNNING);
                restored.step();
                assert.equal(restored.getState(), State.SUCCEEDED);
                assert.deepEqual(callsB, ["A"]);
            });

            it("keeps the iteration count it picked at random", () => {
                const createTree = (random: () => number, calls: string[]) =>
                    new BehaviourTree(
                        "root { repeat [1,5] { action [A] } }",
                        {
                            A: () => {
                                calls.push("A");
                                return State.SUCCEEDED;
                            }
                        },
                        { random }
                    );

                // 0.9 picks 5 iterations.
                const callsA: string[] = [];
                const original = createTree(() => 0.9, callsA);
                original.step();
                const snapshot = throughJSON(original.snapshot());

                // The restored tree has a 'random' function that would pick 1 iteration, which must be ignored.
                const random = sinon.stub().returns(0);
                const callsB: string[] = [];
                const restored = createTree(random, callsB);
                restored.restore(snapshot);

                // Steps 2 to 6 call the action 4 more times and a final step completes the repeat.
                for (let i = 0; i < 5; i++) {
                    restored.step();
                }

                assert.deepEqual(callsB, ["A", "A", "A", "A"]);
                assert.equal(restored.getState(), State.SUCCEEDED);
                assert.equal(random.callCount, 0);
            });

            it("keeps its infinite iteration state", () => {
                const calls: string[] = [];
                const agent = {
                    A: () => {
                        calls.push("A");
                        return State.SUCCEEDED;
                    }
                };

                const original = new BehaviourTree("root { repeat { action [A] } }", agent);
                original.step();
                const snapshot = throughJSON(original.snapshot());

                const restored = new BehaviourTree("root { repeat { action [A] } }", agent);
                restored.restore(snapshot);
                for (let i = 0; i < 10; i++) {
                    restored.step();
                }

                assert.equal(restored.getState(), State.RUNNING);
                assert.equal(calls.length, 11);
            });
        });

        describe("a retry node", () => {
            it("keeps its current attempt count", () => {
                const createTree = (calls: string[]) =>
                    new BehaviourTree("root { retry [3] { action [A] } }", {
                        A: () => {
                            calls.push("A");
                            return State.FAILED;
                        }
                    });

                const callsA: string[] = [];
                const original = createTree(callsA);
                original.step();
                original.step();

                const callsB: string[] = [];
                const restored = createTree(callsB);
                restored.restore(throughJSON(original.snapshot()));

                restored.step();
                assert.deepEqual(callsB, ["A"]);
                assert.equal(restored.getState(), State.RUNNING);
                restored.step();
                assert.deepEqual(callsB, ["A"]);
                assert.equal(restored.getState(), State.FAILED);
            });

            it("keeps the attempt count it picked at random", () => {
                const createTree = (random: () => number, calls: string[]) =>
                    new BehaviourTree(
                        "root { retry [1,5] { action [A] } }",
                        {
                            A: () => {
                                calls.push("A");
                                return State.FAILED;
                            }
                        },
                        { random }
                    );

                const original = createTree(() => 0.9, []);
                original.step();
                const snapshot = throughJSON(original.snapshot());

                const random = sinon.stub().returns(0);
                const callsB: string[] = [];
                const restored = createTree(random, callsB);
                restored.restore(snapshot);

                for (let i = 0; i < 5; i++) {
                    restored.step();
                }

                assert.deepEqual(callsB, ["A", "A", "A", "A"]);
                assert.equal(restored.getState(), State.FAILED);
                assert.equal(random.callCount, 0);
            });
        });

        describe("a lotto node", () => {
            it("keeps the child it picked", () => {
                const createTree = (random: () => number, calls: string[]) =>
                    new BehaviourTree(
                        "root { lotto { action [A] action [B] action [C] } }",
                        {
                            A: () => (calls.push("A"), State.RUNNING),
                            B: () => (calls.push("B"), State.RUNNING),
                            C: () => (calls.push("C"), State.RUNNING)
                        },
                        { random }
                    );

                // 0.5 picks the middle child.
                const original = createTree(() => 0.5, []);
                original.step();
                const snapshot = throughJSON(original.snapshot());

                // The restored tree has a 'random' function that would pick the first child, which must be ignored.
                const random = sinon.stub().returns(0);
                const calls: string[] = [];
                const restored = createTree(random, calls);
                restored.restore(snapshot);
                restored.step();
                restored.step();

                assert.deepEqual(calls, ["B", "B"]);
                assert.equal(random.callCount, 0);
            });

            it("can be restored when a guard resolved it before it picked a child", () => {
                const definition = "root { lotto while(Never) { action [A] action [B] } }";
                const createTree = () =>
                    new BehaviourTree(definition, {
                        Never: () => false,
                        A: () => State.RUNNING,
                        B: () => State.RUNNING
                    });

                const original = createTree();
                original.step();
                assert.equal(original.getState(), State.FAILED);

                const restored = createTree();
                restored.restore(throughJSON(original.snapshot()));

                assert.equal(restored.getState(), State.FAILED);
                assert.deepEqual(getStates(restored), getStates(original));
            });
        });

        describe("a wait node", () => {
            it("only waits for the remaining time, regardless of the time that passed before the restore (Date)", () => {
                const definition = "root { wait [1000] }";

                const original = new BehaviourTree(definition, {});
                original.step();
                clock.tick(600);
                original.step();
                const snapshot = throughJSON(original.snapshot());

                // An hour passes before the tree is restored in 'another process'.
                clock.tick(60 * 60 * 1000);
                const restored = new BehaviourTree(definition, {});
                restored.restore(snapshot);

                restored.step();
                assert.equal(restored.getState(), State.RUNNING);

                clock.tick(399);
                restored.step();
                assert.equal(restored.getState(), State.RUNNING);

                clock.tick(1);
                restored.step();
                assert.equal(restored.getState(), State.SUCCEEDED);
            });

            it("counts the time that passed between the last step and the snapshot (Date)", () => {
                const definition = "root { wait [1000] }";

                const original = new BehaviourTree(definition, {});
                original.step();
                clock.tick(600);

                // The tree has not been stepped for 600ms, but is still 600ms into its wait when snapshotted.
                const snapshot = throughJSON(original.snapshot());

                clock.tick(60 * 60 * 1000);
                const restored = new BehaviourTree(definition, {});
                restored.restore(snapshot);

                clock.tick(399);
                restored.step();
                assert.equal(restored.getState(), State.RUNNING);

                clock.tick(1);
                restored.step();
                assert.equal(restored.getState(), State.SUCCEEDED);
            });

            it("does not count time that passes between the snapshot and the restore when the tree is restored in place (Date)", () => {
                const tree = new BehaviourTree("root { wait [1000] }", {});
                tree.step();
                clock.tick(300);
                const snapshot = throughJSON(tree.snapshot());

                clock.tick(5000);
                tree.restore(snapshot);

                clock.tick(699);
                tree.step();
                assert.equal(tree.getState(), State.RUNNING);

                clock.tick(1);
                tree.step();
                assert.equal(tree.getState(), State.SUCCEEDED);
            });

            it("only waits for the remaining time, regardless of the time that passed before the restore (getDeltaTime)", () => {
                const definition = "root { wait [1000] }";
                let deltaTime = 0.25;

                const original = new BehaviourTree(definition, {}, { getDeltaTime: () => deltaTime });
                original.step();
                original.step();
                const snapshot = throughJSON(original.snapshot());

                // Wall clock time passing makes no difference to a tree driven by a delta time.
                clock.tick(60 * 60 * 1000);
                const restored = new BehaviourTree(definition, {}, { getDeltaTime: () => deltaTime });
                restored.restore(snapshot);

                // 500ms of 1000ms were waited before the snapshot.
                deltaTime = 0.25;
                restored.step();
                assert.equal(restored.getState(), State.RUNNING);
                restored.step();
                assert.equal(restored.getState(), State.SUCCEEDED);
            });

            it("keeps the duration it picked at random", () => {
                const definition = "root { wait [1000, 3000] }";

                // 0.5 picks 2000ms.
                const original = new BehaviourTree(definition, {}, { random: () => 0.5 });
                original.step();
                clock.tick(1500);
                original.step();
                const snapshot = throughJSON(original.snapshot());

                const random = sinon.stub().returns(0);
                const restored = new BehaviourTree(definition, {}, { random });
                restored.restore(snapshot);

                clock.tick(499);
                restored.step();
                assert.equal(restored.getState(), State.RUNNING);

                clock.tick(1);
                restored.step();
                assert.equal(restored.getState(), State.SUCCEEDED);
                assert.equal(random.callCount, 0);
            });

            it("keeps waiting indefinitely if it has no duration", () => {
                const original = new BehaviourTree("root { wait }", {});
                original.step();
                const snapshot = throughJSON(original.snapshot());

                const restored = new BehaviourTree("root { wait }", {});
                restored.restore(snapshot);
                clock.tick(1000000);
                restored.step();

                assert.equal(restored.getState(), State.RUNNING);
            });

            it("stays succeeded if it had already finished waiting", () => {
                const original = new BehaviourTree("root { sequence { wait [100] action [A] } }", {
                    A: () => State.RUNNING
                });
                original.step();
                clock.tick(100);
                original.step();
                assert.equal(findNode(original, "wait").state, State.SUCCEEDED);

                const calls: string[] = [];
                const restored = new BehaviourTree("root { sequence { wait [100] action [A] } }", {
                    A: () => (calls.push("A"), State.RUNNING)
                });
                restored.restore(throughJSON(original.snapshot()));
                clock.tick(100000);
                restored.step();

                assert.equal(findNode(restored, "wait").state, State.SUCCEEDED);
                assert.deepEqual(calls, ["A"]);
            });
        });

        describe("an action node", () => {
            it("keeps a promise result that had settled but not been handled yet", async () => {
                const original = new BehaviourTree("root { sequence { action [A] action [B] } }", {
                    A: () => Promise.resolve(State.SUCCEEDED),
                    B: () => State.RUNNING
                });
                original.step();
                await Promise.resolve();

                const calls: string[] = [];
                const restored = new BehaviourTree("root { sequence { action [A] action [B] } }", {
                    A: () => (calls.push("A"), Promise.resolve(State.FAILED)),
                    B: () => (calls.push("B"), State.RUNNING)
                });
                restored.restore(throughJSON(original.snapshot()));
                restored.step();

                // The action is not called again, its settled result is used.
                assert.deepEqual(calls, ["B"]);
                assert.equal(findNode(restored, "action", "A").state, State.SUCCEEDED);
            });

            it("keeps a promise rejection that had settled but not been handled yet", async () => {
                const original = new BehaviourTree("root { action [A] }", { A: () => Promise.reject("oh no") });
                original.step();
                await Promise.resolve();

                const restored = new BehaviourTree("root { action [A] }", { A: () => State.SUCCEEDED });
                restored.restore(throughJSON(original.snapshot()));

                assert.throws(() => restored.step(), Error, "action function 'A' promise rejected with 'oh no'");
            });

            describe("that is awaiting a promise that has not settled when the snapshot is taken", () => {
                const definition = "root { sequence { action [Before] action [Pending] action [After] } }";

                const createAgent = (calls: string[], pending: () => Promise<State.SUCCEEDED | State.FAILED>) => ({
                    Before: () => (calls.push("Before"), State.SUCCEEDED),
                    Pending: () => (calls.push("Pending"), pending()),
                    After: () => (calls.push("After"), State.SUCCEEDED)
                });

                it("is restored as not yet started and calls its action function again on the next step", async () => {
                    const originalCalls: string[] = [];
                    const original = new BehaviourTree(
                        definition,
                        createAgent(originalCalls, () => new Promise(() => {}))
                    );
                    original.step();
                    original.step();
                    assert.deepEqual(originalCalls, ["Before", "Pending"]);

                    const calls: string[] = [];
                    const restored = new BehaviourTree(
                        definition,
                        createAgent(calls, () => new Promise(() => {}))
                    );
                    restored.restore(throughJSON(original.snapshot()));

                    assert.equal(findNode(restored, "action", "Before").state, State.SUCCEEDED);
                    assert.equal(findNode(restored, "action", "Pending").state, State.READY);
                    assert.equal(findNode(restored, "action", "After").state, State.READY);
                    assert.equal(restored.getState(), State.RUNNING);
                    assert.deepEqual(calls, []);

                    restored.step();

                    // The action that had finished is not called again, but the one that was pending is.
                    assert.deepEqual(calls, ["Pending"]);
                    assert.equal(findNode(restored, "action", "Pending").state, State.RUNNING);
                });

                it("calls its entry callback again, as it is starting again", () => {
                    const entries: string[] = [];
                    const create = () =>
                        new BehaviourTree("root { action [Pending] entry(Enter) }", {
                            Pending: () => new Promise<State.SUCCEEDED>(() => {}),
                            Enter: () => entries.push("Enter")
                        });

                    const original = create();
                    original.step();
                    assert.lengthOf(entries, 1);

                    const restored = create();
                    restored.restore(original.snapshot());
                    restored.step();

                    assert.lengthOf(entries, 2);
                });

                it("completes the restored tree with the outcome of the promise returned after the restore", async () => {
                    const original = new BehaviourTree(
                        definition,
                        createAgent([], () => new Promise(() => {}))
                    );
                    original.step();

                    const calls: string[] = [];
                    const restored = new BehaviourTree(
                        definition,
                        createAgent(calls, () => Promise.resolve(State.SUCCEEDED))
                    );
                    restored.restore(original.snapshot());

                    restored.step();
                    await Promise.resolve();
                    restored.step();

                    assert.deepEqual(calls, ["Pending", "After"]);
                    assert.equal(restored.getState(), State.SUCCEEDED);
                });

                it("is restored as not yet started in a tree that is already awaiting its own promise", async () => {
                    const resolvers: ((state: State.SUCCEEDED) => void)[] = [];
                    const calls: string[] = [];
                    const tree = new BehaviourTree(
                        definition,
                        createAgent(calls, () => new Promise((resolve) => resolvers.push(resolve)))
                    );
                    tree.step();
                    const snapshot = tree.snapshot();
                    calls.length = 0;

                    // Restoring the snapshot in place means the promise from before is no longer wanted.
                    tree.restore(snapshot);
                    tree.step();
                    assert.deepEqual(calls, ["Pending"]);

                    resolvers[0](State.SUCCEEDED);
                    await Promise.resolve();
                    tree.step();
                    assert.equal(tree.getState(), State.RUNNING);

                    resolvers[1](State.SUCCEEDED);
                    await Promise.resolve();
                    tree.step();
                    assert.deepEqual(calls, ["Pending", "After"]);
                    assert.equal(tree.getState(), State.SUCCEEDED);
                });

                it("does not affect the other nodes in the snapshot", async () => {
                    const parallel = "root { parallel { action [Pending] action [Settled] action [Running] } }";
                    const agent = (calls: string[]) => ({
                        Pending: () => (calls.push("Pending"), new Promise<State.SUCCEEDED>(() => {})),
                        Settled: () => (calls.push("Settled"), Promise.resolve(State.FAILED)),
                        Running: () => (calls.push("Running"), State.RUNNING)
                    });

                    const original = new BehaviourTree(parallel, agent([]));
                    original.step();
                    await Promise.resolve();

                    const calls: string[] = [];
                    const restored = new BehaviourTree(parallel, agent(calls));
                    restored.restore(throughJSON(original.snapshot()));

                    assert.equal(findNode(restored, "action", "Pending").state, State.READY);
                    assert.equal(findNode(restored, "action", "Running").state, State.RUNNING);

                    restored.step();

                    // The settled promise is handled without calling its action again, the pending one is called again.
                    assert.deepEqual(calls, ["Pending", "Running"]);
                    assert.equal(findNode(restored, "action", "Settled").state, State.FAILED);
                });
            });

            it("ignores a promise it was awaiting before the restore", async () => {
                const resolvers: ((state: State.SUCCEEDED) => void)[] = [];
                const tree = new BehaviourTree("root { action [A] }", {
                    A: () => new Promise<State.SUCCEEDED>((resolve) => resolvers.push(resolve))
                });

                const readySnapshot = tree.snapshot();
                tree.step();
                tree.restore(readySnapshot);
                tree.step();
                assert.lengthOf(resolvers, 2);

                // The stale promise from before the restore settles, it must not complete the action.
                resolvers[0](State.SUCCEEDED);
                await Promise.resolve();
                tree.step();
                assert.equal(tree.getState(), State.RUNNING);

                // The promise from after the restore does.
                resolvers[1](State.SUCCEEDED);
                await Promise.resolve();
                tree.step();
                assert.equal(tree.getState(), State.SUCCEEDED);
            });
        });

        describe("the tree is finished", () => {
            it("restores as finished and starts a new run with new random choices on the next step", () => {
                const createTree = (random: () => number, calls: string[]) =>
                    new BehaviourTree(
                        "root { lotto { action [A] action [B] } }",
                        {
                            A: () => (calls.push("A"), State.SUCCEEDED),
                            B: () => (calls.push("B"), State.SUCCEEDED)
                        },
                        { random }
                    );

                // The first random choice picks 'A'.
                const callsA: string[] = [];
                const original = createTree(() => 0, callsA);
                original.step();
                assert.equal(original.getState(), State.SUCCEEDED);
                const snapshot = throughJSON(original.snapshot());

                const callsB: string[] = [];
                const restored = createTree(() => 0.99, callsB);
                restored.restore(snapshot);

                assert.equal(restored.getState(), State.SUCCEEDED);
                assert.deepEqual(getStates(restored), getStates(original));
                assert.deepEqual(callsB, []);

                // The next step starts a new run that makes its own random choice.
                restored.step();
                assert.deepEqual(callsB, ["B"]);
                assert.equal(restored.getState(), State.SUCCEEDED);
            });

            it("restores as failed", () => {
                const original = new BehaviourTree("root { sequence { action [A] action [B] } }", {
                    A: () => State.FAILED
                });
                original.step();

                const restored = new BehaviourTree("root { sequence { action [A] action [B] } }", {});
                restored.restore(throughJSON(original.snapshot()));

                assert.equal(restored.getState(), State.FAILED);
                assert.deepEqual(getStates(restored), getStates(original));
            });
        });

        describe("a guard aborts a running node", () => {
            it("calls the same exit callbacks as the original tree", () => {
                const createTree = (calls: string[], state: { allowed: boolean }) =>
                    new BehaviourTree("root { sequence { action [A] exit(OnExit) while(Allowed) } }", {
                        A: () => (calls.push("A"), State.RUNNING),
                        Allowed: () => state.allowed,
                        OnExit: (result: any) => calls.push(`exit:${result.aborted}`)
                    });

                const stateA = { allowed: true };
                const original = createTree([], stateA);
                original.step();

                const callsB: string[] = [];
                const stateB = { allowed: true };
                const restored = createTree(callsB, stateB);
                restored.restore(throughJSON(original.snapshot()));

                stateB.allowed = false;
                restored.step();

                assert.deepEqual(callsB, ["exit:true"]);
                assert.equal(restored.getState(), State.FAILED);
            });
        });
    });

    describe("behaves exactly like the tree a snapshot was taken from", () => {
        const definition = `root {
            repeat [2,3] {
                sequence {
                    lotto [1,2,1] {
                        action [A] entry(Log, "entered A")
                        sequence { action [B] wait [100,300] }
                        action [Slow]
                    }
                    parallel {
                        retry [2,3] { action [Flaky] }
                        wait [300] exit(Log, "waited")
                    }
                    race {
                        action [Slow] while(Guard)
                        wait [400]
                    }
                    all {
                        succeed { action [Flaky] }
                        flip { action [Slow] }
                    }
                    selector {
                        fail { condition [Never] }
                        sequence { condition [Always] wait [250] step(Log, "stepping") }
                    }
                }
            }
        }`;

        const STEP_COUNT = 120;
        const STEP_DURATION_MS = 100;
        const RESTORE_DELAY_MS = 6 * 60 * 60 * 1000;

        type AgentState = { counts: { [name: string]: number } };

        const createAgent = (state: AgentState, log: string[]): Agent => {
            const next = (name: string) => (state.counts[name] = (state.counts[name] ?? 0) + 1);

            return {
                Log: (message: string) => log.push(message),
                A: () => (log.push("A"), State.SUCCEEDED),
                B: () => (log.push("B"), State.SUCCEEDED),
                Slow: () => (log.push("Slow"), next("Slow") % 3 === 0 ? State.SUCCEEDED : State.RUNNING),
                Flaky: () => (log.push("Flaky"), next("Flaky") % 3 === 0 ? State.SUCCEEDED : State.FAILED),
                Guard: () => (log.push("Guard"), next("Guard") % 11 !== 0),
                Never: () => (log.push("Never"), false),
                Always: () => (log.push("Always"), true)
            };
        };

        for (const timing of ["Date", "getDeltaTime"]) {
            for (const seed of [1, 2, 3]) {
                it(`when restored at every step of a run using ${timing} timing (seed ${seed})`, () => {
                    const createTree = (state: AgentState, log: string[], randomStartIndex: number) => {
                        const rng = createRandom(seed, randomStartIndex);
                        const options =
                            timing === "Date"
                                ? { random: rng.random }
                                : { random: rng.random, getDeltaTime: () => STEP_DURATION_MS / 1000 };
                        return { tree: new BehaviourTree(definition, createAgent(state, log), options), rng };
                    };

                    // Run the reference tree uninterrupted, recording what each step does along with a snapshot of the tree before it.
                    const referenceState: AgentState = { counts: {} };
                    const referenceLog: string[] = [];
                    const { tree: reference, rng: referenceRng } = createTree(referenceState, referenceLog, 0);

                    type Checkpoint = {
                        snapshot: BehaviourTreeSnapshot;
                        agentState: AgentState;
                        randomIndex: number;
                    };
                    const checkpoints: Checkpoint[] = [];
                    const expected: { calls: string[]; states: unknown; snapshot: BehaviourTreeSnapshot }[] = [];

                    for (let i = 0; i < STEP_COUNT; i++) {
                        checkpoints.push({
                            snapshot: throughJSON(reference.snapshot()),
                            agentState: JSON.parse(JSON.stringify(referenceState)),
                            randomIndex: referenceRng.getIndex()
                        });

                        const logLength = referenceLog.length;
                        clock.tick(STEP_DURATION_MS);
                        reference.step();
                        expected.push({
                            calls: referenceLog.slice(logLength),
                            states: getStates(reference),
                            snapshot: throughJSON(reference.snapshot())
                        });
                    }

                    // The run must have been interesting enough to be worth checking, and have finished at least once.
                    assert.isAbove(new Set(referenceLog).size, 8);
                    assert.isTrue(
                        expected.some(({ states }) => (states as NodeDetails).state === State.SUCCEEDED),
                        "expected the reference run to finish"
                    );

                    // Restore at each step into a new tree after a long delay, then check that it follows the reference run.
                    checkpoints.forEach(({ snapshot, agentState, randomIndex }, startStep) => {
                        const log: string[] = [];
                        const { tree } = createTree(agentState, log, randomIndex);

                        clock.tick(RESTORE_DELAY_MS);
                        tree.restore(snapshot);

                        for (let i = startStep; i < STEP_COUNT; i++) {
                            const logLength = log.length;
                            clock.tick(STEP_DURATION_MS);
                            tree.step();

                            const context = `restored at step ${startStep}, after step ${i}`;
                            assert.deepEqual(log.slice(logLength), expected[i].calls, context);
                            assert.deepEqual(getStates(tree), expected[i].states, context);
                            assert.deepEqual(throughJSON(tree.snapshot()), expected[i].snapshot, context);
                        }
                    });
                });
            }
        }
    });
});
