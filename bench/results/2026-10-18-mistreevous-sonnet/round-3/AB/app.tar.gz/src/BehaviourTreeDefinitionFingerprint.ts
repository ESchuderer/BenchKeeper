import {
    AnyNodeDefinition,
    NodeArgument,
    NodeAttributeDefinition,
    NodeGuardDefinition,
    RootNodeDefinition
} from "./BehaviourTreeDefinition";

/**
 * Gets a fingerprint of a behaviour tree definition, which is the same for any two definitions that build the same tree and, for practical purposes, different otherwise.
 * It is worked out from the validated JSON form of a definition, so an MDSL definition and its equivalent JSON definition have the same fingerprint.
 * Only what is used in building a tree counts, so the fingerprint does not depend on the order of properties, on the properties that have defaults being left out,
 * on a lone root node being in an array or not, on the order of the sub root nodes, or on anything else that is not a part of a definition, such as comments.
 * @param rootNodeDefinitions The validated root node definitions, of which exactly one is the main root node definition without an 'id'.
 * @returns The fingerprint of the definition, as a string.
 */
export function getDefinitionFingerprint(rootNodeDefinitions: RootNodeDefinition[]): string {
    // The main root node comes first, followed by the sub root nodes in order of their identifiers, as the order they were defined in has no effect.
    const sortedRootNodeDefinitions = [...rootNodeDefinitions].sort((a, b) => {
        if (a.id === b.id) {
            return 0;
        }
        if (a.id === undefined || b.id === undefined) {
            return a.id === undefined ? -1 : 1;
        }
        return a.id < b.id ? -1 : 1;
    });

    return hash(JSON.stringify(sortedRootNodeDefinitions.map(getCanonicalNode)));
}

/**
 * Gets the canonical form of a node argument.
 */
function getCanonicalArgument(argument: NodeArgument): NodeArgument {
    return typeof argument === "object" && argument !== null ? { $: argument.$ } : argument;
}

/**
 * Gets the canonical form of a callback or guard attribute, in which the default value of every optional property is explicit.
 * @param attribute The attribute definition.
 * @param isGuard Whether the attribute is a guard, which has a state to move to when aborted.
 */
function getCanonicalAttribute(attribute: NodeAttributeDefinition | NodeGuardDefinition, isGuard: boolean): object {
    return {
        call: attribute.call,
        args: (attribute.args ?? []).map(getCanonicalArgument),
        ...(isGuard ? { succeedOnAbort: !!(attribute as NodeGuardDefinition).succeedOnAbort } : {})
    };
}

/**
 * Gets the canonical form of a node, which has the same properties in the same order for any definitions that build the same node.
 * Anything that is not used to build the node is left out, as is anything that is undefined, as it is left out of the JSON.
 * @param node The node definition.
 */
function getCanonicalNode(node: AnyNodeDefinition): object {
    return {
        type: node.type,
        id: node.type === "root" ? node.id : undefined,
        while: node.while && getCanonicalAttribute(node.while, true),
        until: node.until && getCanonicalAttribute(node.until, true),
        entry: node.entry && getCanonicalAttribute(node.entry, false),
        step: node.step && getCanonicalAttribute(node.step, false),
        exit: node.exit && getCanonicalAttribute(node.exit, false),
        ref: node.type === "branch" ? node.ref : undefined,
        call: node.type === "action" || node.type === "condition" ? node.call : undefined,
        args:
            node.type === "action" || node.type === "condition"
                ? (node.args ?? []).map(getCanonicalArgument)
                : undefined,
        duration: node.type === "wait" ? node.duration : undefined,
        iterations: node.type === "repeat" ? node.iterations : undefined,
        attempts: node.type === "retry" ? node.attempts : undefined,
        weights: node.type === "lotto" ? node.weights : undefined,
        child: "child" in node ? getCanonicalNode(node.child) : undefined,
        children: "children" in node ? node.children.map(getCanonicalNode) : undefined
    };
}

/**
 * Gets a 53-bit hash of a string as a fixed length hexadecimal string (cyrb53).
 * This is not secure, it is only to identify a definition without the snapshot having to include all of it.
 * @param value The string to hash.
 */
function hash(value: string): string {
    let h1 = 0xdeadbeef;
    let h2 = 0x41c6ce57;

    for (let index = 0; index < value.length; index++) {
        const code = value.charCodeAt(index);
        h1 = Math.imul(h1 ^ code, 2654435761);
        h2 = Math.imul(h2 ^ code, 1597334677);
    }

    h1 = Math.imul(h1 ^ (h1 >>> 16), 2246822507) ^ Math.imul(h2 ^ (h2 >>> 13), 3266489909);
    h2 = Math.imul(h2 ^ (h2 >>> 16), 2246822507) ^ Math.imul(h1 ^ (h1 >>> 13), 3266489909);

    return (4294967296 * (2097151 & h2) + (h1 >>> 0)).toString(16).padStart(14, "0");
}
