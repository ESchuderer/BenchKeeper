import State, { AnyState } from "./State";

/**
 * The version of the snapshot format produced by `BehaviourTree.snapshot()`.
 */
export const SNAPSHOT_VERSION = 1;

/**
 * The properties common to the snapshot of every node.
 */
type BaseNodeSnapshot<TType extends string> = {
    /**
     * The node type.
     */
    type: TType;
    /**
     * The state of the node.
     */
    state: AnyState;
    /**
     * The snapshots of the child nodes of this node, in the order they are defined. This is empty for leaf nodes.
     */
    children: NodeSnapshot[];
};

/**
 * The snapshot of a node that keeps nothing but its state.
 */
export type SimpleNodeSnapshot = BaseNodeSnapshot<
    "root" | "sequence" | "selector" | "parallel" | "race" | "all" | "flip" | "succeed" | "fail" | "condition"
>;

/**
 * The snapshot of a repeat node.
 */
export type RepeatNodeSnapshot = BaseNodeSnapshot<"repeat"> & {
    /**
     * The number of iterations to make in total, which may have been picked at random, or null if there is no limit.
     */
    targetIterationCount: number | null;
    /**
     * The number of iterations made so far.
     */
    currentIterationCount: number;
};

/**
 * The snapshot of a retry node.
 */
export type RetryNodeSnapshot = BaseNodeSnapshot<"retry"> & {
    /**
     * The number of attempts to make in total, which may have been picked at random, or null if there is no limit.
     */
    targetAttemptCount: number | null;
    /**
     * The number of attempts made so far.
     */
    currentAttemptCount: number;
};

/**
 * The snapshot of a lotto node.
 */
export type LottoNodeSnapshot = BaseNodeSnapshot<"lotto"> & {
    /**
     * The index of the child that was picked to be the active one, or null if none has been picked.
     */
    selectedChildIndex: number | null;
};

/**
 * The snapshot of a wait node.
 */
export type WaitNodeSnapshot = BaseNodeSnapshot<"wait"> & {
    /**
     * The total duration in milliseconds to wait for, which may have been picked at random, or null if the wait is indefinite.
     */
    totalDuration: number | null;
    /**
     * The duration in milliseconds that the node has already waited for.
     */
    waitedDuration: number;
};

/**
 * The snapshot of an action node.
 */
export type ActionNodeSnapshot = BaseNodeSnapshot<"action"> & {
    /**
     * The outcome of the promise returned by the action function, if it settled but has not been handled by the tree yet, otherwise null.
     */
    promiseResult: { isResolved: boolean; value: string | null } | null;
};

/**
 * The snapshot of a node in a behaviour tree.
 */
export type NodeSnapshot =
    | SimpleNodeSnapshot
    | RepeatNodeSnapshot
    | RetryNodeSnapshot
    | LottoNodeSnapshot
    | WaitNodeSnapshot
    | ActionNodeSnapshot;

/**
 * A snapshot of the execution state of a behaviour tree.
 * This is a plain object that can be serialised as JSON, and later passed to the `restore` method of a behaviour tree built from the same definition.
 */
export type BehaviourTreeSnapshot = {
    /**
     * The version of the snapshot format.
     */
    version: typeof SNAPSHOT_VERSION;
    /**
     * The fingerprint of the definition of the tree that the snapshot was taken from, which is the same for an MDSL definition and its equivalent JSON definition.
     * A snapshot can only be restored to a tree that has the same fingerprint.
     */
    definition: string;
    /**
     * The snapshot of the root node of the tree.
     */
    root: NodeSnapshot;
};

/**
 * Creates the error thrown when a value that is being restored from is not a valid snapshot.
 * @param message The error message.
 * @param path The path to the invalid part of the snapshot.
 */
export function createInvalidSnapshotError(message: string, path?: string): Error {
    return new Error(`invalid snapshot: ${message}${path === undefined ? "" : ` at '${path}'`}`);
}

/**
 * Gets whether a value is a non-null object that is not an array.
 */
export function isObject(value: unknown): value is { [key: string]: unknown } {
    return typeof value === "object" && value !== null && !Array.isArray(value);
}

/**
 * Gets whether a value is a valid node state.
 */
export function isNodeState(value: unknown): value is AnyState {
    return value === State.READY || value === State.RUNNING || value === State.SUCCEEDED || value === State.FAILED;
}

/**
 * Asserts that a snapshot property is a non-negative integer, or optionally null.
 * @param snapshot The node snapshot.
 * @param property The name of the property to check.
 * @param path The path to the node snapshot.
 * @param isNullable Whether the property is allowed to be null.
 */
export function assertCountProperty(
    snapshot: { [key: string]: unknown },
    property: string,
    path: string,
    isNullable: boolean
): void {
    const value = snapshot[property];

    if ((isNullable && value === null) || (typeof value === "number" && Number.isInteger(value) && value >= 0)) {
        return;
    }

    throw createInvalidSnapshotError(
        `expected '${property}' to be a non-negative integer${isNullable ? " or null" : ""}`,
        path
    );
}
