import { BehaviourTreeOptions } from "../../BehaviourTreeOptions";
import { NodeDetails } from "../Node";
import State, { AnyState, CompleteState } from "../../State";
import { Agent } from "../../Agent";
import Leaf from "./Leaf";
import Lookup from "../../Lookup";
import Attribute from "../../attributes/Attribute";
import { ActionNodeSnapshot, NodeSnapshot, createInvalidSnapshotError, isObject } from "../../BehaviourTreeSnapshot";

/**
 * The type representing a resolved/rejected update promise.
 */
type UpdatePromiseResult = {
    /**
     * Whether the promise was resolved rather than rejected.
     */
    isResolved: boolean;

    /**
     * The promise resolved value or rejection reason.
     */
    value: any;
};

/**
 * An Action leaf node.
 * This represents an immediate or ongoing state of behaviour.
 */
export default class Action extends Leaf {
    /**
     * @param attributes The node attributes.
     * @param options The behaviour tree options.
     * @param actionName The action name.
     * @param actionArguments The array of action arguments.
     */
    constructor(
        attributes: Attribute[],
        options: BehaviourTreeOptions,
        private actionName: string,
        public actionArguments: any[]
    ) {
        super("action", attributes, options);
    }

    /**
     * Whether there is a pending update promise.
     */
    private isUsingUpdatePromise = false;

    /**
     * The finished state result of an update promise.
     */
    private updatePromiseResult: UpdatePromiseResult | null = null;

    /**
     * Called when the node is being updated.
     * @param agent The agent.
     */
    protected onUpdate(agent: Agent): void {
        // If the result of this action depends on an update promise then there is nothing to do until it settles.
        if (this.isUsingUpdatePromise) {
            // Are we still waiting for our update promise to settle?
            if (!this.updatePromiseResult) {
                return;
            }

            const { isResolved, value } = this.updatePromiseResult;

            // Our update promise settled, was it resolved or rejected?
            if (isResolved) {
                // Our promise resolved so check to make sure the result is a valid finished state.
                if (value !== State.SUCCEEDED && value !== State.FAILED) {
                    throw new Error(
                        "action node promise resolved with an invalid value, expected a State.SUCCEEDED or State.FAILED value to be returned"
                    );
                }

                // Set the state of this node to match the state returned by the promise.
                this.setState(value);

                return;
            } else {
                // The promise was rejected, which isn't great.
                throw new Error(`action function '${this.actionName}' promise rejected with '${value}'`);
            }
        }

        // Attempt to get the invoker for the action function.
        const actionFuncInvoker = Lookup.getFuncInvoker(agent, this.actionName);

        // The action function should be defined.
        if (actionFuncInvoker === null) {
            throw new Error(
                `cannot update action node as the action '${this.actionName}' function is not defined on the agent and has not been registered`
            );
        }

        let actionFunctionResult;

        try {
            // Call the action function, the result of which may be:
            // - The finished state of this action node.
            // - A promise to return a finished node state.
            // - Undefined if the node should remain in the running state.
            actionFunctionResult = actionFuncInvoker(this.actionArguments) as CompleteState | Promise<CompleteState>;
        } catch (error) {
            // An uncaught error was thrown.
            if (error instanceof Error) {
                throw new Error(`action function '${this.actionName}' threw: ${error.stack}`);
            } else {
                throw new Error(`action function '${this.actionName}' threw: ${error}`);
            }
        }

        if (actionFunctionResult instanceof Promise) {
            actionFunctionResult.then(
                (result) => {
                    // If 'isUpdatePromisePending' is not set then the promise was cleared as it was resolving, probably via an abort of reset.
                    if (!this.isUsingUpdatePromise) {
                        return;
                    }

                    // Set the resolved update promise result so that it can be handled on the next update of this node.
                    this.updatePromiseResult = {
                        isResolved: true,
                        value: result
                    };
                },
                (reason) => {
                    // If 'isUpdatePromisePending' is not set then the promise was cleared as it was resolving, probably via an abort or reset.
                    if (!this.isUsingUpdatePromise) {
                        return;
                    }

                    // Set the rejected update promise result so that it can be handled on the next update of this node.
                    this.updatePromiseResult = {
                        isResolved: false,
                        value: reason
                    };
                }
            );

            // This node will be in the 'RUNNING' state until the update promise resolves.
            this.setState(State.RUNNING);

            // We are now waiting for the promise returned by the use to resolve before we know what state this node is in.
            this.isUsingUpdatePromise = true;
        } else {
            // Validate the returned value.
            this.validateUpdateResult(actionFunctionResult);

            // Set the state of this node, this may be undefined, which just means that the node is still in the 'RUNNING' state.
            this.setState(actionFunctionResult || State.RUNNING);
        }
    }

    /**
     * Gets the name of the node.
     */
    getName = () => this.actionName;

    /**
     * Reset the state of the node.
     */
    reset = () => {
        // Reset the state of this node.
        this.setState(State.READY);

        // There is no longer an update promise that we care about.
        this.isUsingUpdatePromise = false;
        this.updatePromiseResult = null;
    };

    /**
     * Gets whether this action is waiting on an update promise that has not settled.
     */
    private isWaitingOnUpdatePromise(): boolean {
        return this.is(State.RUNNING) && this.isUsingUpdatePromise && !this.updatePromiseResult;
    }

    /**
     * Gets the state to record in a snapshot of this node.
     */
    protected getSnapshotState(): AnyState {
        // A promise cannot be saved, nor can we know what it will settle with. An action waiting on one is saved as not started,
        // so that a restored tree will call the action function again, rather than wait on a promise that does not exist.
        return this.isWaitingOnUpdatePromise() ? State.READY : super.getSnapshotState();
    }

    /**
     * Gets the snapshot properties specific to this type of node.
     */
    protected getSnapshotData(): object {
        // An action that is not running has no update promise that we care about, and one waiting on a promise that has not settled is saved as not started.
        if (!this.is(State.RUNNING) || !this.isUsingUpdatePromise || !this.updatePromiseResult) {
            return { promiseResult: null };
        }

        const { isResolved, value } = this.updatePromiseResult;

        // A rejection reason can be anything, but all that is done with it is to put it in an error message. A resolved value that
        // is not a finished state is an error whatever it is, so it doesn't need to be kept.
        return {
            promiseResult: {
                isResolved,
                value: isResolved ? (value === State.SUCCEEDED || value === State.FAILED ? value : null) : String(value)
            }
        };
    }

    /**
     * Validates the snapshot properties specific to this type of node.
     * @param snapshot The node snapshot.
     * @param path The path to the snapshot of this node, used in error messages.
     */
    protected validateSnapshotData(snapshot: { [key: string]: unknown }, path: string): void {
        const { promiseResult } = snapshot;

        if (
            promiseResult !== null &&
            !(
                isObject(promiseResult) &&
                typeof promiseResult.isResolved === "boolean" &&
                (promiseResult.value === null || typeof promiseResult.value === "string")
            )
        ) {
            throw createInvalidSnapshotError(
                "expected 'promiseResult' to be null or an object with a boolean 'isResolved' and a string or null 'value'",
                path
            );
        }
    }

    /**
     * Restores the execution state specific to this type of node from a validated snapshot.
     * @param snapshot The validated node snapshot.
     */
    protected restoreSnapshotData(snapshot: NodeSnapshot): void {
        const { promiseResult } = snapshot as ActionNodeSnapshot;

        // Any update promise from before the restore is no longer one that we care about.
        this.isUsingUpdatePromise = promiseResult !== null;
        this.updatePromiseResult = promiseResult && {
            isResolved: promiseResult.isResolved,
            value: promiseResult.value
        };
    }

    /**
     * Gets the details of this node instance.
     * @returns The details of this node instance.
     */
    public getDetails(): NodeDetails {
        return {
            ...super.getDetails(),
            args: this.actionArguments
        };
    }

    /**
     * Called when the state of this node changes.
     * @param previousState The previous node state.
     */
    protected onStateChanged(previousState: State): void {
        this.options.onNodeStateChange?.({
            id: this.uid,
            type: this.getType(),
            args: this.actionArguments,
            while: this.attributes.while?.getDetails(),
            until: this.attributes.until?.getDetails(),
            entry: this.attributes.entry?.getDetails(),
            step: this.attributes.step?.getDetails(),
            exit: this.attributes.exit?.getDetails(),
            previousState,
            state: this.getState()
        });
    }

    /**
     * Validate the result of an update function call.
     * @param result The result of an update function call.
     */
    private validateUpdateResult = (result: CompleteState | State.RUNNING) => {
        switch (result) {
            case State.SUCCEEDED:
            case State.FAILED:
            case State.RUNNING:
            case undefined:
                return;
            default:
                throw new Error(
                    `expected action function '${this.actionName}' to return an optional State.SUCCEEDED or State.FAILED value but returned '${result}'`
                );
        }
    };
}
