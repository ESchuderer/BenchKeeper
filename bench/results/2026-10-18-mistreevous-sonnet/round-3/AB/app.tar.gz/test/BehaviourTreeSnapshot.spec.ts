import { assert } from "chai";
import sinon, { SinonFakeTimers } from "sinon";

import { BehaviourTree, BehaviourTreeSnapshot, NodeDetails, State } from "../src/index";
import { Agent } from "../src/Agent";

/**
 * The result of calling a scripted agent function. Actions return a state or undefined, conditions return a boolean.
 */
type ScriptedResult = State | boolean | undefined;

/**
 * A mapping of agent function names to functions that decide the result of each call based on the call number (starting at 1).
 */
type Script = { [name: string]: (call: number) => ScriptedResult };

/**
 * A tree definition and the agent behaviour to run it with.
 */
type Scenario = {
    name: string;
    definition: string;
    script: Script;
    /** The number of steps to run the reference tree for. */
    steps: number;
    /** The time in milliseconds that passes before each step. */
    msPerStep: number;
    /** Node types that must be seen in the RUNNING state at some point in the run, so that a scenario cannot pass vacuously. */
    covers: string[];
};

type Event = { type: "tick"; ms: number } | { type: "step" };

/**
 * What can be observed about a tree after an event is applied.
 */
type Observation = {
    /** The agent functions called, in order, as part of the event. */
    calls: string[];
    /** The tree node details, without the randomly generated node ids. */
    details: string;
};

/**
 * Everything needed to resume a run from a point in time.
 */
type Checkpoint = {
    /** The JSON text of the snapshot, as it would be written to storage. */
    snapshot: string;
    time: number;
    /** The agent function call counts, standing in for the application state that is outside of the tree. */
    callCounts: { [name: string]: number };
    randomCalls: number;
    deltaTime: number;
    observation: Observation;
};

const CLOCK_START = 1_000_000;
const GAP_BETWEEN_SNAPSHOT_AND_RESTORE = 10_000_000;

/** A small seeded pseudo-random number generator. */
function createRandom(seed: number): () => number {
    return () => {
        seed = (seed + 0x6d2b79f5) | 0;
        let t = Math.imul(seed ^ (seed >>> 15), 1 | seed);
        t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
        return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
}

function stripIds(details: NodeDetails): any {
    const { id, children, ...rest } = details;
    return { ...rest, children: children?.map(stripIds) };
}

function getObservableDetails(tree: BehaviourTree): string {
    return JSON.stringify(stripIds(tree.getTreeNodeDetails()));
}

/**
 * Drives a tree with a scripted agent, a seeded random function and either the clock or a delta time.
 */
class Run {
    public readonly callLog: string[] = [];
    public readonly callCounts: { [name: string]: number };
    public randomCalls = 0;
    public deltaTime = 0;
    public readonly tree: BehaviourTree;
    private readonly clock: SinonFakeTimers;

    constructor(scenario: Scenario, clock: SinonFakeTimers, useDeltaTime: boolean, resumeFrom?: Checkpoint) {
        this.clock = clock;
        this.callCounts = { ...(resumeFrom?.callCounts ?? {}) };
        this.deltaTime = resumeFrom?.deltaTime ?? 0;

        // Bring the random function to the point it was at when the checkpoint was taken.
        const random = createRandom(1234);
        for (let call = 0; call < (resumeFrom?.randomCalls ?? 0); call++) {
            random();
        }
        this.randomCalls = resumeFrom?.randomCalls ?? 0;

        const agent: Agent = {};
        for (const [name, decide] of Object.entries(scenario.script)) {
            agent[name] = (...args: any[]) => {
                this.callCounts[name] = (this.callCounts[name] ?? 0) + 1;
                this.callLog.push(`${name}#${this.callCounts[name]}${args.length ? JSON.stringify(args) : ""}`);
                return decide(this.callCounts[name]);
            };
        }

        this.tree = new BehaviourTree(scenario.definition, agent, {
            random: () => {
                this.randomCalls++;
                return random();
            },
            ...(useDeltaTime ? { getDeltaTime: () => this.deltaTime } : {})
        });
    }

    public apply(event: Event): Observation {
        this.callLog.length = 0;

        if (event.type === "tick") {
            this.clock.tick(event.ms);
            this.deltaTime = event.ms / 1000;
        } else {
            this.tree.step();
        }

        return { calls: [...this.callLog], details: getObservableDetails(this.tree) };
    }
}

/**
 * Runs the scenario's reference tree, taking a snapshot before every event. Each snapshot is then restored into a new tree,
 * a long time after it was taken, and the rest of the events are replayed. The restored tree must call the same agent
 * functions in the same order and have the same node states as the reference tree did.
 */
function assertRestoredTreesBehaveLikeTheOriginal(scenario: Scenario, useDeltaTime: boolean) {
    const clock = sinon.useFakeTimers({ now: CLOCK_START });

    try {
        const events: Event[] = [];
        for (let step = 0; step < scenario.steps; step++) {
            events.push({ type: "tick", ms: scenario.msPerStep }, { type: "step" });
        }

        const reference = new Run(scenario, clock, useDeltaTime);
        const checkpoints: Checkpoint[] = [];
        const observations: Observation[] = [];
        const runningNodeTypes = new Set<string>();

        const collectRunningNodeTypes = (details: NodeDetails) => {
            if (details.state === State.RUNNING) {
                runningNodeTypes.add(details.type);
            }
            details.children?.forEach(collectRunningNodeTypes);
        };

        for (const event of events) {
            const snapshot = reference.tree.snapshot();
            checkpoints.push({
                snapshot: JSON.stringify(snapshot),
                time: Date.now(),
                callCounts: { ...reference.callCounts },
                randomCalls: reference.randomCalls,
                deltaTime: reference.deltaTime,
                observation: { calls: [], details: getObservableDetails(reference.tree) }
            });
            observations.push(reference.apply(event));
            collectRunningNodeTypes(reference.tree.getTreeNodeDetails());
        }

        for (const type of scenario.covers) {
            assert.isTrue(runningNodeTypes.has(type), `the reference run never had a running '${type}' node`);
        }

        checkpoints.forEach((checkpoint, index) => {
            clock.setSystemTime(checkpoint.time + GAP_BETWEEN_SNAPSHOT_AND_RESTORE);

            const restored = new Run(scenario, clock, useDeltaTime, checkpoint);
            restored.tree.restore(JSON.parse(checkpoint.snapshot));

            assert.equal(
                getObservableDetails(restored.tree),
                checkpoint.observation.details,
                `node states differ straight after restoring the snapshot taken before event ${index}`
            );

            for (let next = index; next < events.length; next++) {
                const observation = restored.apply(events[next]);
                assert.deepEqual(
                    observation.calls,
                    observations[next].calls,
                    `agent calls differ at event ${next} after restoring the snapshot taken before event ${index}`
                );
                assert.equal(
                    observation.details,
                    observations[next].details,
                    `node states differ at event ${next} after restoring the snapshot taken before event ${index}`
                );
            }
        });
    } finally {
        clock.restore();
    }
}

function itBehavesLikeTheOriginalWhenRestored(scenario: Scenario) {
    describe(scenario.name, () => {
        it("using the clock for wait durations", () => assertRestoredTreesBehaveLikeTheOriginal(scenario, false));
        it("using the 'getDeltaTime' option for wait durations", () =>
            assertRestoredTreesBehaveLikeTheOriginal(scenario, true));
    });
}

describe("A BehaviourTree", () => {
    describe("snapshot", () => {
        it("returns an object that is unchanged by a round trip through JSON", () => {
            const tree = new BehaviourTree(
                "root { sequence { action [Work] repeat [2,4] { wait [100, 200] } lotto { condition [A] condition [B] } } }",
                { Work: () => State.RUNNING },
                { random: () => 0.5 }
            );

            for (let step = 0; step < 3; step++) {
                tree.step();
                const snapshot = tree.snapshot();
                assert.deepEqual(JSON.parse(JSON.stringify(snapshot)), snapshot);
            }
        });

        it("returns an object that is unchanged by a round trip through JSON when the tree has not been stepped", () => {
            const snapshot = new BehaviourTree("root { action [Work] }", {}).snapshot();
            assert.deepEqual(JSON.parse(JSON.stringify(snapshot)), snapshot);
        });

        it("does not share any objects with the tree, so changing it has no effect on the tree", () => {
            const calls: string[] = [];
            const agent = { First: () => (calls.push("First"), State.SUCCEEDED), Second: () => State.RUNNING };
            const tree = new BehaviourTree("root { sequence { action [First] action [Second] } }", agent);
            tree.step();

            const snapshot = tree.snapshot();
            const untouched = JSON.stringify(snapshot);
            (snapshot.root as any).state = State.READY;
            (snapshot.root.children[0] as any).children = [];

            assert.equal(JSON.stringify(tree.snapshot()), untouched);
        });

        it("does not share any objects with the tree after a restore, so changing it has no effect on the tree", () => {
            const tree = new BehaviourTree("root { sequence { action [First] action [Second] } }", {
                First: () => State.SUCCEEDED,
                Second: () => State.RUNNING
            });
            tree.step();

            const snapshot = tree.snapshot();
            const untouched = JSON.stringify(snapshot);

            tree.restore(snapshot);
            (snapshot.root as any).state = State.READY;
            (snapshot.root.children[0] as any).state = State.READY;

            assert.equal(JSON.stringify(tree.snapshot()), untouched);
        });

        it("does not change the tree or call any agent functions", () => {
            const calls: string[] = [];
            const agent = { Work: () => (calls.push("Work"), State.RUNNING) };
            const tree = new BehaviourTree("root { action [Work] entry(Enter) }", {
                ...agent,
                Enter: () => calls.push("Enter")
            });
            tree.step();
            calls.length = 0;

            const before = getObservableDetails(tree);
            tree.snapshot();

            assert.deepEqual(calls, []);
            assert.equal(getObservableDetails(tree), before);
        });
    });

    describe("restore", () => {
        describe("sets the state of every node", () => {
            it("to that of a tree that was not stepped", () => {
                const definition = "root { sequence { action [First] action [Second] } }";
                const agent = { First: () => State.SUCCEEDED, Second: () => State.RUNNING };

                const used = new BehaviourTree(definition, agent);
                used.step();
                used.restore(new BehaviourTree(definition, agent).snapshot());

                assert.equal(used.getState(), State.READY);
                assert.equal(getObservableDetails(used), getObservableDetails(new BehaviourTree(definition, agent)));
            });

            it("to that of a running tree, in a tree that was not stepped", () => {
                const definition = "root { sequence { action [First] action [Second] } }";
                const agent = { First: () => State.SUCCEEDED, Second: () => State.RUNNING };

                const original = new BehaviourTree(definition, agent);
                original.step();

                const restored = new BehaviourTree(definition, agent);
                restored.restore(JSON.parse(JSON.stringify(original.snapshot())));

                assert.isTrue(restored.isRunning());
                assert.equal(getObservableDetails(restored), getObservableDetails(original));
            });
        });

        it("does not call any agent functions", () => {
            const calls: string[] = [];
            const agent = {
                Work: () => (calls.push("Work"), State.RUNNING),
                Enter: () => void calls.push("Enter"),
                Leave: () => void calls.push("Leave"),
                Guard: () => (calls.push("Guard"), false)
            };
            const definition = "root { sequence while(Guard) { action [Work] entry(Enter) exit(Leave) } }";

            const original = new BehaviourTree(definition, agent);
            original.step();
            calls.length = 0;

            new BehaviourTree(definition, agent).restore(original.snapshot());

            assert.deepEqual(calls, []);
        });

        it("replaces the state of a tree that has already been stepped", () => {
            const definition = "root { sequence { action [First] action [Second] } }";
            const agent = { First: () => State.SUCCEEDED, Second: () => State.RUNNING };

            const original = new BehaviourTree(definition, agent);
            original.step();
            const snapshot = original.snapshot();

            const other = new BehaviourTree(definition, { First: () => State.FAILED, Second: () => State.RUNNING });
            other.step();
            assert.equal(other.getState(), State.FAILED);

            other.restore(snapshot);

            assert.equal(getObservableDetails(other), getObservableDetails(original));
        });

        it("does not call the 'onNodeStateChange' handler, and the next step reports changes as usual", () => {
            const definition = "root { sequence { action [First] action [Second] } }";
            let secondCalls = 0;
            const agent = {
                First: () => State.SUCCEEDED,
                Second: () => (++secondCalls < 2 ? State.RUNNING : State.SUCCEEDED)
            };

            const original = new BehaviourTree(definition, agent);
            original.step();

            const changes: string[] = [];
            const restored = new BehaviourTree(definition, agent, {
                onNodeStateChange: ({ type, previousState, state }) => changes.push(`${type}:${previousState}>${state}`)
            });
            restored.restore(original.snapshot());

            assert.deepEqual(changes, []);
            assert.equal(restored.getState(), State.RUNNING);

            restored.step();

            assert.deepEqual(changes, [
                `action:${State.RUNNING}>${State.SUCCEEDED}`,
                `sequence:${State.RUNNING}>${State.SUCCEEDED}`,
                `root:${State.RUNNING}>${State.SUCCEEDED}`
            ]);
        });

        describe("restores a snapshot of a finished tree as finished", () => {
            for (const [result, finishedState] of [
                [State.SUCCEEDED, State.SUCCEEDED],
                [State.FAILED, State.FAILED]
            ]) {
                it(`(${finishedState})`, () => {
                    const calls: string[] = [];
                    const agent = { Work: () => (calls.push("Work"), result) };
                    const definition = "root { sequence { action [Work] } }";

                    const original = new BehaviourTree(definition, agent);
                    original.step();
                    assert.equal(original.getState(), finishedState);

                    const restored = new BehaviourTree(definition, agent);
                    restored.restore(JSON.parse(JSON.stringify(original.snapshot())));
                    calls.length = 0;

                    assert.equal(restored.getState(), finishedState);
                    assert.isFalse(restored.isRunning());
                    assert.equal(getObservableDetails(restored), getObservableDetails(original));

                    // Nothing should be called by looking at a finished tree, but a step starts a new run.
                    assert.deepEqual(calls, []);
                    restored.step();
                    assert.deepEqual(calls, ["Work"]);
                });
            }
        });

        it("makes new random choices when a restored finished tree is stepped", () => {
            const definition = "root { sequence { repeat [1,5] { action [Work] } wait [100,900] } }";
            let calls = 0;
            const agent = { Work: () => (calls++, State.SUCCEEDED) };

            // A random number of 0 picks the minimum of 1 iteration and 100ms.
            const original = new BehaviourTree(definition, agent, { random: () => 0 });
            const clock = sinon.useFakeTimers({ now: CLOCK_START });
            try {
                for (let step = 0; step < 10 && original.getState() !== State.SUCCEEDED; step++) {
                    original.step();
                    clock.tick(100);
                }
                assert.equal(original.getState(), State.SUCCEEDED);

                // A random number close to 1 picks the maximum of 5 iterations and 900ms.
                const restored = new BehaviourTree(definition, agent, { random: () => 0.9999 });
                restored.restore(JSON.parse(JSON.stringify(original.snapshot())));
                assert.equal(restored.getState(), State.SUCCEEDED);
                calls = 0;

                restored.step();
                assert.equal(restored.getState(), State.RUNNING);
                assert.equal(calls, 1);

                for (let step = 0; step < 10; step++) {
                    restored.step();
                }
                assert.equal(calls, 5);
                assert.equal(restored.getState(), State.RUNNING);

                clock.tick(899);
                restored.step();
                assert.equal(restored.getState(), State.RUNNING);

                clock.tick(1);
                restored.step();
                assert.equal(restored.getState(), State.SUCCEEDED);
            } finally {
                clock.restore();
            }
        });

        describe("will error and leave the tree as it was if", () => {
            const definition = "root { sequence { action [First] repeat [2] { action [Second] } } }";
            const agent = { First: () => State.SUCCEEDED, Second: () => State.RUNNING };

            const createTrees = () => {
                const source = new BehaviourTree(definition, agent);
                source.step();

                const target = new BehaviourTree(definition, agent);
                target.step();
                target.step();

                return { snapshot: JSON.parse(JSON.stringify(source.snapshot())), target };
            };

            const itWillError = (name: string, message: string, corrupt: (snapshot: any) => any) => {
                it(name, () => {
                    const { snapshot, target } = createTrees();
                    const before = JSON.stringify(target.snapshot());

                    assert.throws(() => target.restore(corrupt(snapshot)), Error, message);
                    assert.equal(JSON.stringify(target.snapshot()), before);
                });
            };

            itWillError("the snapshot is not an object", "invalid snapshot: expected an object", () => "snapshot");
            itWillError("the snapshot is null", "invalid snapshot: expected an object", () => null);
            itWillError("the snapshot is undefined", "invalid snapshot: expected an object", () => undefined);
            itWillError("the snapshot version is not supported", "invalid snapshot: unsupported version", (s) => ({
                ...s,
                version: 99
            }));
            itWillError("the snapshot version is missing", "invalid snapshot: unsupported version", (s) => ({
                root: s.root
            }));
            itWillError("the snapshot has no root node", "invalid snapshot: expected an object at '$'", (s) => ({
                version: s.version,
                definition: s.definition
            }));
            itWillError(
                "a node is of a different type",
                "invalid snapshot: expected a 'repeat' node but found a 'wait' node at '$.children[0].children[1]'",
                (s) => {
                    s.root.children[0].children[1].type = "wait";
                    return s;
                }
            );
            itWillError(
                "a node has a different number of children",
                "invalid snapshot: expected a children array of length 1 at '$.children[0].children[1]'",
                (s) => {
                    s.root.children[0].children[1].children = [];
                    return s;
                }
            );
            itWillError(
                "a node has no children array",
                "invalid snapshot: expected a children array of length 2 at '$.children[0]'",
                (s) => {
                    delete s.root.children[0].children;
                    return s;
                }
            );
            itWillError(
                "a node has an invalid state",
                "invalid snapshot: invalid state 'mistreevous.unknown' at '$.children[0].children[0]'",
                (s) => {
                    s.root.children[0].children[0].state = "mistreevous.unknown";
                    return s;
                }
            );
            itWillError(
                "a node is not an object",
                "invalid snapshot: expected an object at '$.children[0].children[0]'",
                (s) => {
                    s.root.children[0].children[0] = null;
                    return s;
                }
            );
        });
    });

    describe("records the definition the tree was built from", () => {
        it("as a string in the snapshot, whether or not the tree has been stepped", () => {
            const tree = new BehaviourTree("root { action [Work] }", { Work: () => State.RUNNING });

            const before = tree.snapshot();
            assert.isString(before.definition);
            assert.isNotEmpty(before.definition);

            tree.step();
            assert.equal(tree.snapshot().definition, before.definition);
        });

        it("so that trees built from the same definition have the same one", () => {
            const first = new BehaviourTree("root { action [Work] }", {});
            const second = new BehaviourTree("root {\n    action [Work] /* a comment */\n}", {});

            assert.equal(first.snapshot().definition, second.snapshot().definition);
        });

        it("so that trees built from different definitions have different ones", () => {
            const first = new BehaviourTree("root { action [Work] }", {});
            const second = new BehaviourTree("root { action [Rest] }", {});

            assert.notEqual(first.snapshot().definition, second.snapshot().definition);
        });
    });

    describe("restores a snapshot of the same definition", () => {
        const agent = {
            ...Object.fromEntries(["A", "Z"].map((name) => [name, () => State.SUCCEEDED])),
            ...Object.fromEntries(["C", "G", "U"].map((name) => [name, () => true])),
            ...Object.fromEntries(["E", "S", "X"].map((name) => [name, () => {}])),
            x: 5
        };

        const mdsl = `
            root {
                sequence while(G) entry(E, 1, "a", null, true, $x) {
                    action [A]
                    wait [10]
                    wait [1, 2]
                    wait
                    repeat { condition [C, 2] }
                    lotto [1] { action [A] until(U) then succeed }
                    branch [Sub]
                }
            }
            root [Sub] {
                retry [1, 2] until(U) exit(X) step(S) { action [Z] }
            }`;

        // The same definition as the MDSL above, without the properties that have defaults and in a different order.
        const json = [
            {
                id: "Sub",
                child: {
                    child: { call: "Z", type: "action" },
                    step: { call: "S" },
                    exit: { call: "X" },
                    until: { call: "U" },
                    attempts: [1, 2],
                    type: "retry"
                },
                type: "root"
            },
            {
                type: "root",
                id: undefined,
                child: {
                    children: [
                        { type: "action", call: "A", args: undefined },
                        { duration: 10, type: "wait" },
                        { type: "wait", duration: [1, 2] },
                        { type: "wait" },
                        { child: { type: "condition", call: "C", args: [2] }, type: "repeat" },
                        {
                            weights: [1],
                            type: "lotto",
                            children: [{ type: "action", call: "A", until: { call: "U", succeedOnAbort: true } }]
                        },
                        { ref: "Sub", type: "branch" }
                    ],
                    entry: { args: [1, "a", null, true, { $: "x" }], call: "E" },
                    while: { call: "G", succeedOnAbort: false },
                    type: "sequence"
                }
            }
        ] as any;

        // The snapshots are compared, which include the time waited, so the clock must not move between taking them.
        let clock: SinonFakeTimers;
        beforeEach(() => (clock = sinon.useFakeTimers({ now: CLOCK_START })));
        afterEach(() => clock.restore());

        const assertRestores = (sourceDefinition: any, targetDefinition: any) => {
            const source = new BehaviourTree(sourceDefinition, agent, { random: () => 0 });
            const target = new BehaviourTree(targetDefinition, agent, { random: () => 0 });

            for (let step = 0; step < 3; step++) {
                source.step();
            }

            assert.equal(source.snapshot().definition, target.snapshot().definition);

            target.restore(JSON.parse(JSON.stringify(source.snapshot())));
            assert.equal(getObservableDetails(target), getObservableDetails(source));
            assert.equal(JSON.stringify(target.snapshot()), JSON.stringify(source.snapshot()));
        };

        it("in a tree built from the same MDSL definition", () => assertRestores(mdsl, mdsl));
        it("in a tree built from the same JSON definition", () => assertRestores(json, json));
        it("in a tree built from the equivalent JSON definition", () => assertRestores(mdsl, json));
        it("in a tree built from the equivalent MDSL definition", () => assertRestores(json, mdsl));
        it("in a tree built from an MDSL definition that is written differently", () =>
            assertRestores(mdsl, mdsl.replace(/\s+/g, " ").replace("root [Sub]", "/* subtree */ root [Sub]")));
        it("in a tree built from a JSON definition of a single root node, not in an array", () =>
            assertRestores("root { action [A] }", { type: "root", child: { type: "action", call: "A" } }));

        it("in a tree built from a definition that is not the same object as the one it was taken from", () => {
            const copy = JSON.parse(JSON.stringify(json));
            assertRestores(json, copy);
        });

        it("even if the definition object was changed after the tree was built", () => {
            const changing = JSON.parse(JSON.stringify(json));
            const source = new BehaviourTree(changing, agent);
            source.step();

            changing[1].child.children[0].call = "Z";

            const target = new BehaviourTree(json, agent);
            target.restore(source.snapshot());
            assert.equal(getObservableDetails(target), getObservableDetails(source));
        });
    });

    describe("will error and leave the tree as it was when restoring a snapshot of a different definition", () => {
        const base = `
            root {
                sequence while(G, 1) {
                    action [A, 1] entry(E)
                    wait [100, 200]
                    repeat [2] { condition [C] }
                    lotto [1, 2] { action [A] action [B] }
                    branch [Sub]
                }
            }
            root [Sub] { action [Z] }`;

        const variants: [string, string][] = [
            ["an action with a different name", base.replace("action [A, 1]", "action [B, 1]")],
            ["an action with a different argument", base.replace("action [A, 1]", "action [A, 2]")],
            ["an action with a string argument rather than a number", base.replace("action [A, 1]", 'action [A, "1"]')],
            ["an action with an extra argument", base.replace("action [A, 1]", "action [A, 1, 1]")],
            ["an action with an agent property argument", base.replace("action [A, 1]", "action [A, $x]")],
            ["a callback with a different name", base.replace("entry(E)", "entry(F)")],
            ["a callback of a different kind", base.replace("entry(E)", "exit(E)")],
            ["a callback with an argument", base.replace("entry(E)", "entry(E, 1)")],
            ["a guard with a different name", base.replace("while(G, 1)", "while(H, 1)")],
            ["a guard with a different argument", base.replace("while(G, 1)", "while(G, 2)")],
            ["a guard of a different kind", base.replace("while(G, 1)", "until(G, 1)")],
            ["a guard with a different state when aborted", base.replace("while(G, 1)", "while(G, 1) then succeed")],
            ["a wait with a different duration", base.replace("wait [100, 200]", "wait [100, 300]")],
            ["a wait with a fixed duration", base.replace("wait [100, 200]", "wait [100]")],
            ["a wait without a duration", base.replace("wait [100, 200]", "wait")],
            ["a repeat with a different iteration count", base.replace("repeat [2]", "repeat [3]")],
            ["a repeat without an iteration count", base.replace("repeat [2]", "repeat")],
            ["a condition with a different name", base.replace("condition [C]", "condition [D]")],
            ["a lotto with different weights", base.replace("lotto [1, 2]", "lotto [2, 1]")],
            ["a lotto without weights", base.replace("lotto [1, 2]", "lotto")],
            ["a composite of a different type", base.replace("sequence", "selector")],
            ["children in a different order", base.replace("action [A] action [B]", "action [B] action [A]")],
            ["a different node type with the same structure", base.replace("repeat [2]", "retry [2]")],
            ["an extra node", base.replace("branch [Sub]", "branch [Sub] action [B]")],
            ["a subtree with a different body", base.replace("root [Sub] { action [Z] }", "root [Sub] { action [Y] }")],
            ["a subtree with a different name", base.split("Sub").join("Other")],
            ["an extra subtree", base + " root [Unused] { action [Z] }"]
        ];

        const agent = {
            ...Object.fromEntries(["A", "B", "Y", "Z"].map((name) => [name, () => State.RUNNING])),
            ...Object.fromEntries(["C", "D", "G", "H"].map((name) => [name, () => true])),
            ...Object.fromEntries(["E", "F"].map((name) => [name, () => {}])),
            x: 1
        };

        const assertRejected = (sourceDefinition: any, targetDefinition: any) => {
            const calls: string[] = [];
            const recordingAgent = new Proxy(agent, {
                get: (target: any, name: string) =>
                    typeof target[name] === "function" ? () => (calls.push(name), target[name]()) : target[name]
            });
            const stateChanges: string[] = [];

            const source = new BehaviourTree(sourceDefinition, recordingAgent);
            source.step();
            const snapshot = JSON.parse(JSON.stringify(source.snapshot()));

            const target = new BehaviourTree(targetDefinition, recordingAgent, {
                onNodeStateChange: ({ type }) => stateChanges.push(type)
            });
            target.step();
            target.step();

            const before = JSON.stringify(target.snapshot());
            const callsBefore = [...calls];
            const stateChangesBefore = [...stateChanges];

            assert.throws(() => target.restore(snapshot), Error, "does not match the tree's definition");

            assert.equal(JSON.stringify(target.snapshot()), before);
            assert.deepEqual(calls, callsBefore);
            assert.deepEqual(stateChanges, stateChangesBefore);
        };

        for (const [name, variant] of variants) {
            it(`(${name})`, () => {
                assertRejected(variant, base);
                assertRejected(base, variant);
            });
        }

        it("(a definition in JSON that differs from the MDSL definition)", () => {
            assertRejected({ type: "root", child: { type: "action", call: "A", args: [1] } }, "root { action [A, 2] }");
        });

        it("(a definition of a different tree)", () => {
            assertRejected("root { action [A] }", "root { sequence { action [A] action [B] } }");
        });

        it("(a snapshot whose definition was changed to a value that is not a definition)", () => {
            const source = new BehaviourTree(base, agent);
            const target = new BehaviourTree(base, agent);
            target.step();
            const before = JSON.stringify(target.snapshot());

            for (const definition of ["", "not a definition", "0000000000000"]) {
                const snapshot = { ...source.snapshot(), definition };
                assert.throws(() => target.restore(snapshot), Error, "does not match the tree's definition");
            }
            assert.equal(JSON.stringify(target.snapshot()), before);
        });
    });

    describe("will error and leave the tree as it was when restoring something that is not a snapshot", () => {
        const treeDefinition = "root { sequence { action [A] action [B] } }";
        const agent = { A: () => State.SUCCEEDED, B: () => State.RUNNING };

        const notSnapshots: [string, unknown][] = [
            ["null", null],
            ["undefined", undefined],
            ["a string", "snapshot"],
            ["a string of JSON of a snapshot", JSON.stringify(new BehaviourTree(treeDefinition, agent).snapshot())],
            ["a number", 1],
            ["a boolean", true],
            ["an empty array", []],
            ["an array of snapshots", [new BehaviourTree(treeDefinition, agent).snapshot()]],
            ["a function", () => new BehaviourTree(treeDefinition, agent).snapshot()],
            ["an empty object", {}],
            ["an object with other properties", { state: "mistreevous.running", children: [] }],
            ["an object with a root node but no version or definition", { root: {} }],
            [
                "a snapshot without a version",
                (() => {
                    const { version, ...rest } = new BehaviourTree(treeDefinition, agent).snapshot();
                    return rest;
                })()
            ],
            [
                "a snapshot without a definition",
                (() => {
                    const { definition, ...rest } = new BehaviourTree(treeDefinition, agent).snapshot();
                    return rest;
                })()
            ],
            [
                "a snapshot without a root",
                (() => {
                    const { root, ...rest } = new BehaviourTree(treeDefinition, agent).snapshot();
                    return rest;
                })()
            ],
            [
                "a snapshot with a definition that is not a string",
                { ...new BehaviourTree(treeDefinition, agent).snapshot(), definition: 1 }
            ],
            [
                "a snapshot with a null definition",
                { ...new BehaviourTree(treeDefinition, agent).snapshot(), definition: null }
            ]
        ];

        for (const [name, value] of notSnapshots) {
            it(`(${name})`, () => {
                const target = new BehaviourTree(treeDefinition, agent);
                target.step();
                const before = JSON.stringify(target.snapshot());

                assert.throws(() => target.restore(value as any), Error);
                assert.equal(JSON.stringify(target.snapshot()), before);
            });
        }
    });

    describe("restores the counts of a", () => {
        // The child action result that makes a repeat or retry node move on to its next iteration or attempt.
        for (const [type, countName, continuingResult] of [
            ["repeat", "iteration", State.SUCCEEDED],
            ["retry", "attempt", State.FAILED]
        ] as const) {
            describe(`${type} node`, () => {
                it(`so that the ${countName}s already made still count`, () => {
                    const definition = `root { ${type} [3] { action [Work] } }`;
                    let calls = 0;
                    const agent = { Work: () => (calls++, continuingResult) };

                    const original = new BehaviourTree(definition, agent);
                    original.step();
                    original.step();
                    assert.equal(calls, 2);

                    const restored = new BehaviourTree(definition, agent);
                    restored.restore(JSON.parse(JSON.stringify(original.snapshot())));
                    calls = 0;

                    restored.step();
                    assert.equal(calls, 1);
                    restored.step();
                    assert.equal(calls, 1);
                    assert.equal(restored.getState(), type === "repeat" ? State.SUCCEEDED : State.FAILED);
                });

                it(`so that the number of ${countName}s picked at random is not picked again`, () => {
                    const definition = `root { ${type} [2,6] { action [Work] } }`;
                    let calls = 0;
                    const agent = { Work: () => (calls++, continuingResult) };

                    // A random number close to 1 picks the maximum of 6.
                    const original = new BehaviourTree(definition, agent, { random: () => 0.99 });
                    original.step();

                    const restored = new BehaviourTree(definition, agent, {
                        random: () => {
                            throw new Error("expected no random number to be picked");
                        }
                    });
                    restored.restore(JSON.parse(JSON.stringify(original.snapshot())));
                    calls = 0;

                    for (let step = 0; step < 20 && restored.getState() === State.RUNNING; step++) {
                        restored.step();
                    }

                    // One was made before the snapshot was taken, so five remain.
                    assert.equal(calls, 5);
                });

                it("so that identical nodes in the same tree keep their own counts", () => {
                    const definition = `root { sequence { ${type} [2] { action [Work] } ${type} [3] { action [Work] } } }`;
                    const agent = { Work: () => continuingResult };

                    const original = new BehaviourTree(definition, agent);
                    for (let step = 0; step < 3; step++) {
                        original.step();
                    }

                    const restored = new BehaviourTree(definition, agent);
                    restored.restore(JSON.parse(JSON.stringify(original.snapshot())));

                    for (let step = 0; step < 5; step++) {
                        original.step();
                        restored.step();
                        assert.equal(getObservableDetails(restored), getObservableDetails(original));
                    }
                });
            });
        }

        describe("will error if", () => {
            for (const [type, countName, property] of [
                ["repeat", "iteration", "currentIterationCount"],
                ["retry", "attempt", "currentAttemptCount"]
            ]) {
                it(`a ${type} node snapshot has an invalid ${countName} count`, () => {
                    const tree = new BehaviourTree(`root { ${type} [3] { action [Work] } }`, {
                        Work: () => State.RUNNING
                    });
                    tree.step();

                    for (const invalid of [-1, 1.5, "2", null, undefined]) {
                        const snapshot = JSON.parse(JSON.stringify(tree.snapshot()));
                        snapshot.root.children[0][property] = invalid;

                        assert.throws(
                            () => tree.restore(snapshot),
                            Error,
                            `invalid snapshot: expected '${property}' to be a non-negative integer at '$.children[0]'`
                        );
                    }
                });
            }
        });
    });

    describe("restores the child picked by a lotto node", () => {
        const definition = "root { lotto { action [First] action [Second] action [Third] } }";

        it("so that it is not picked again", () => {
            const called: string[] = [];
            const agent = {
                First: () => (called.push("First"), State.RUNNING),
                Second: () => (called.push("Second"), State.RUNNING),
                Third: () => (called.push("Third"), State.RUNNING)
            };

            // A random number of 0.5 picks the second child.
            const original = new BehaviourTree(definition, agent, { random: () => 0.5 });
            original.step();
            assert.deepEqual(called, ["Second"]);

            const restored = new BehaviourTree(definition, agent, {
                random: () => {
                    throw new Error("expected no random number to be picked");
                }
            });
            restored.restore(JSON.parse(JSON.stringify(original.snapshot())));
            called.length = 0;

            restored.step();
            restored.step();
            assert.deepEqual(called, ["Second", "Second"]);
        });

        it("even if it would not be picked by the random function of the restored tree", () => {
            const called: string[] = [];
            const agent = {
                First: () => (called.push("First"), State.RUNNING),
                Second: () => (called.push("Second"), State.RUNNING),
                Third: () => (called.push("Third"), State.RUNNING)
            };

            const original = new BehaviourTree(definition, agent, { random: () => 0.99 });
            original.step();

            const restored = new BehaviourTree(definition, agent, { random: () => 0 });
            restored.restore(JSON.parse(JSON.stringify(original.snapshot())));
            called.length = 0;

            restored.step();
            assert.deepEqual(called, ["Third"]);
        });

        it("picks a child as normal for a lotto node that has not been updated yet", () => {
            const called: string[] = [];
            const agent = {
                First: () => (called.push("First"), State.RUNNING),
                Second: () => (called.push("Second"), State.RUNNING),
                Third: () => (called.push("Third"), State.RUNNING)
            };

            const restored = new BehaviourTree(definition, agent, { random: () => 0.99 });
            restored.restore(JSON.parse(JSON.stringify(new BehaviourTree(definition, agent).snapshot())));

            restored.step();
            assert.deepEqual(called, ["Third"]);
        });

        describe("and will error if", () => {
            const createSnapshot = () => {
                const tree = new BehaviourTree(definition, { Second: () => State.RUNNING }, { random: () => 0.5 });
                tree.step();
                return { tree, snapshot: JSON.parse(JSON.stringify(tree.snapshot())) };
            };

            for (const invalid of [-1, 3, 1.5, "1", undefined]) {
                it(`the selected child index is ${JSON.stringify(invalid) ?? "missing"}`, () => {
                    const { tree, snapshot } = createSnapshot();
                    snapshot.root.children[0].selectedChildIndex = invalid;

                    assert.throws(
                        () => tree.restore(snapshot),
                        Error,
                        "invalid snapshot: expected 'selectedChildIndex' to be the index of a child node or null at '$.children[0]'"
                    );
                });
            }

            it("there is no selected child but the node has been updated", () => {
                const { tree, snapshot } = createSnapshot();
                snapshot.root.children[0].selectedChildIndex = null;

                assert.throws(
                    () => tree.restore(snapshot),
                    Error,
                    "invalid snapshot: expected 'selectedChildIndex' to be the index of a child node at '$.children[0]'"
                );
            });
        });
    });

    describe("restores the time waited by a wait node", () => {
        describe("when using the clock", () => {
            let clock: SinonFakeTimers;

            beforeEach(() => {
                clock = sinon.useFakeTimers({ now: CLOCK_START });
            });

            afterEach(() => {
                clock.restore();
            });

            it("so that it waits for the time that remains", () => {
                const definition = "root { wait [1000] }";

                const original = new BehaviourTree(definition, {});
                original.step();
                clock.tick(400);
                const snapshot = JSON.parse(JSON.stringify(original.snapshot()));

                // The time between taking the snapshot and restoring it is not part of the wait.
                clock.tick(3_600_000);
                const restored = new BehaviourTree(definition, {});
                restored.restore(snapshot);

                restored.step();
                assert.equal(restored.getState(), State.RUNNING);

                clock.tick(599);
                restored.step();
                assert.equal(restored.getState(), State.RUNNING);

                clock.tick(1);
                restored.step();
                assert.equal(restored.getState(), State.SUCCEEDED);
            });

            it("including the time since the node was last updated", () => {
                const definition = "root { wait [1000] }";

                const original = new BehaviourTree(definition, {});
                original.step();
                clock.tick(900);
                const snapshot = JSON.parse(JSON.stringify(original.snapshot()));

                clock.tick(3_600_000);
                const restored = new BehaviourTree(definition, {});
                restored.restore(snapshot);

                clock.tick(99);
                restored.step();
                assert.equal(restored.getState(), State.RUNNING);

                clock.tick(1);
                restored.step();
                assert.equal(restored.getState(), State.SUCCEEDED);
            });

            it("so that it starts waiting from the time of the restore, not the time of the snapshot", () => {
                const definition = "root { wait [1000] }";

                const original = new BehaviourTree(definition, {});
                original.step();
                clock.tick(400);
                const snapshot = JSON.parse(JSON.stringify(original.snapshot()));

                // The same snapshot restored twice, at different times, waits the same time for each.
                for (const delay of [0, 5000]) {
                    clock.tick(delay);
                    const restored = new BehaviourTree(definition, {});
                    restored.restore(snapshot);

                    clock.tick(599);
                    restored.step();
                    assert.equal(restored.getState(), State.RUNNING);

                    clock.tick(1);
                    restored.step();
                    assert.equal(restored.getState(), State.SUCCEEDED);
                }
            });

            it("so that a duration picked at random is not picked again", () => {
                const definition = "root { wait [100, 900] }";

                // A random number close to 1 picks the maximum of 900ms.
                const original = new BehaviourTree(definition, {}, { random: () => 0.9999 });
                original.step();
                clock.tick(300);
                const snapshot = JSON.parse(JSON.stringify(original.snapshot()));

                const restored = new BehaviourTree(
                    definition,
                    {},
                    {
                        random: () => {
                            throw new Error("expected no random number to be picked");
                        }
                    }
                );
                restored.restore(snapshot);

                clock.tick(599);
                restored.step();
                assert.equal(restored.getState(), State.RUNNING);

                clock.tick(1);
                restored.step();
                assert.equal(restored.getState(), State.SUCCEEDED);
            });

            it("so that a wait node without a duration is still waiting indefinitely", () => {
                const original = new BehaviourTree("root { wait }", {});
                original.step();
                const snapshot = JSON.parse(JSON.stringify(original.snapshot()));

                const restored = new BehaviourTree("root { wait }", {});
                restored.restore(snapshot);

                clock.tick(10_000_000);
                restored.step();
                assert.equal(restored.getState(), State.RUNNING);
            });

            it("so that a wait node that has finished waiting has finished", () => {
                const original = new BehaviourTree("root { wait [100] }", {});
                original.step();
                clock.tick(100);
                original.step();
                assert.equal(original.getState(), State.SUCCEEDED);

                const restored = new BehaviourTree("root { wait [100] }", {});
                restored.restore(JSON.parse(JSON.stringify(original.snapshot())));

                assert.equal(restored.getState(), State.SUCCEEDED);
                assert.equal(getObservableDetails(restored), getObservableDetails(original));
            });
        });

        describe("when using the 'getDeltaTime' option", () => {
            it("so that a snapshot is unchanged by a round trip through JSON whatever the delta time", () => {
                for (const deltaTime of [Infinity, -Infinity]) {
                    const tree = new BehaviourTree("root { wait [1000] }", {}, { getDeltaTime: () => deltaTime });
                    tree.step();

                    const snapshot = tree.snapshot();
                    assert.deepEqual(JSON.parse(JSON.stringify(snapshot)), snapshot);

                    const restored = new BehaviourTree("root { wait [1000] }", {}, { getDeltaTime: () => 0 });
                    restored.restore(JSON.parse(JSON.stringify(snapshot)));
                    assert.equal(restored.getState(), tree.getState());
                }
            });

            it("so that it waits for the time that remains", () => {
                const definition = "root { wait [1000] }";
                let deltaTime = 0.4;

                const original = new BehaviourTree(definition, {}, { getDeltaTime: () => deltaTime });
                original.step();
                const snapshot = JSON.parse(JSON.stringify(original.snapshot()));

                const clock = sinon.useFakeTimers({ now: CLOCK_START });
                try {
                    // The time between taking the snapshot and restoring it is not part of the wait.
                    clock.tick(3_600_000);
                    const restored = new BehaviourTree(definition, {}, { getDeltaTime: () => deltaTime });
                    restored.restore(snapshot);

                    deltaTime = 0.5;
                    restored.step();
                    assert.equal(restored.getState(), State.RUNNING);

                    deltaTime = 0.1;
                    restored.step();
                    assert.equal(restored.getState(), State.SUCCEEDED);
                } finally {
                    clock.restore();
                }
            });

            it("so that a duration picked at random is not picked again", () => {
                const definition = "root { wait [100, 900] }";
                let deltaTime = 0.3;

                const original = new BehaviourTree(
                    definition,
                    {},
                    { getDeltaTime: () => deltaTime, random: () => 0.9999 }
                );
                original.step();

                const restored = new BehaviourTree(
                    definition,
                    {},
                    {
                        getDeltaTime: () => deltaTime,
                        random: () => {
                            throw new Error("expected no random number to be picked");
                        }
                    }
                );
                restored.restore(JSON.parse(JSON.stringify(original.snapshot())));

                deltaTime = 0.5;
                restored.step();
                assert.equal(restored.getState(), State.RUNNING);

                deltaTime = 0.1;
                restored.step();
                assert.equal(restored.getState(), State.SUCCEEDED);
            });
        });

        describe("and will error if", () => {
            const createSnapshot = () => {
                const tree = new BehaviourTree("root { wait [100, 900] }", {});
                tree.step();
                return { tree, snapshot: JSON.parse(JSON.stringify(tree.snapshot())) };
            };

            for (const invalid of [-1, 1.5, "100", undefined]) {
                it(`the total duration is ${JSON.stringify(invalid) ?? "missing"}`, () => {
                    const { tree, snapshot } = createSnapshot();
                    snapshot.root.children[0].totalDuration = invalid;

                    assert.throws(
                        () => tree.restore(snapshot),
                        Error,
                        "invalid snapshot: expected 'totalDuration' to be a non-negative integer or null at '$.children[0]'"
                    );
                });
            }

            for (const invalid of ["100", null, undefined, Infinity, NaN]) {
                it(`the waited duration is ${String(invalid)}`, () => {
                    const { tree, snapshot } = createSnapshot();
                    snapshot.root.children[0].waitedDuration = invalid;

                    // Infinity and NaN are not valid JSON, so a snapshot that was stored will have these as null.
                    assert.throws(
                        () => tree.restore(JSON.parse(JSON.stringify(snapshot))),
                        Error,
                        "invalid snapshot: expected 'waitedDuration' to be a finite number at '$.children[0]'"
                    );
                });
            }
        });
    });

    describe("handles an action node that returned a promise", () => {
        const definition = "root { action [Work] }";
        const settle = () => new Promise<void>((resolve) => setImmediate(resolve));

        it("by saving the action as not started when the promise has not settled", async () => {
            const tree = new BehaviourTree(definition, { Work: () => new Promise<State.SUCCEEDED>(() => {}) });
            tree.step();
            await settle();
            assert.equal(tree.getState(), State.RUNNING);

            const snapshot = JSON.parse(JSON.stringify(tree.snapshot()));
            assert.equal(snapshot.root.children[0].type, "action");
            assert.equal(snapshot.root.children[0].state, State.READY);
            assert.isNull(snapshot.root.children[0].promiseResult);
        });

        it("by not changing the tree when taking a snapshot while the promise has not settled", () => {
            const tree = new BehaviourTree(definition, { Work: () => new Promise<State.SUCCEEDED>(() => {}) });
            tree.step();

            const before = getObservableDetails(tree);
            tree.snapshot();

            assert.equal(getObservableDetails(tree), before);
        });

        it("by calling the action function again after a restore when the promise had not settled", async () => {
            let calls = 0;
            const agent = {
                Work: () => (++calls === 1 ? new Promise<State.SUCCEEDED>(() => {}) : Promise.resolve(State.SUCCEEDED))
            };

            const original = new BehaviourTree(definition, agent);
            original.step();
            await settle();
            assert.equal(calls, 1);

            const restored = new BehaviourTree(definition, agent);
            restored.restore(JSON.parse(JSON.stringify(original.snapshot())));
            assert.equal(calls, 1);

            restored.step();
            assert.equal(calls, 2);
            assert.equal(restored.getState(), State.RUNNING);

            await settle();
            restored.step();
            assert.equal(calls, 2);
            assert.equal(restored.getState(), State.SUCCEEDED);
        });

        it("by calling the 'entry' callback again for an action that had not settled, as it is restored as not started", () => {
            const calls: string[] = [];
            const agent = {
                Enter: () => void calls.push("Enter"),
                Work: () => (calls.push("Work"), new Promise<State.SUCCEEDED>(() => {}))
            };
            const entryDefinition = "root { action [Work] entry(Enter) }";

            const original = new BehaviourTree(entryDefinition, agent);
            original.step();
            assert.deepEqual(calls, ["Enter", "Work"]);

            const restored = new BehaviourTree(entryDefinition, agent);
            restored.restore(JSON.parse(JSON.stringify(original.snapshot())));
            restored.step();
            assert.deepEqual(calls, ["Enter", "Work", "Enter", "Work"]);
        });

        it("by ignoring the promise that had not settled if it settles after the tree restored its own snapshot", async () => {
            let calls = 0;
            let resolveFirst: (state: State.SUCCEEDED) => void = () => {};
            const agent = {
                Work: () => {
                    calls++;
                    return calls === 1
                        ? new Promise<State.SUCCEEDED>((resolve) => (resolveFirst = resolve))
                        : State.RUNNING;
                }
            };

            const tree = new BehaviourTree(definition, agent);
            tree.step();
            tree.restore(tree.snapshot());

            resolveFirst(State.SUCCEEDED);
            await settle();

            tree.step();
            assert.equal(calls, 2);
            assert.equal(tree.getState(), State.RUNNING);
        });

        for (const [name, treeDefinition] of [
            ["a sequence", "root { sequence { action [Work] action [Other] } }"],
            ["a selector", "root { selector { action [Work] action [Other] } }"],
            ["a repeat", "root { repeat [2] { action [Work] } }"],
            ["a retry", "root { retry [2] { action [Work] } }"],
            ["a flip", "root { flip { action [Work] } }"],
            ["a parallel", "root { parallel { action [Work] action [Other] } }"],
            ["a race", "root { race { action [Work] action [Other] } }"],
            ["an all", "root { all { action [Work] action [Other] } }"],
            ["a lotto", "root { lotto { action [Work] action [Other] } }"]
        ]) {
            it(`by calling the action function again when it is nested in ${name}`, () => {
                let calls = 0;
                const agent = {
                    Work: () => (++calls === 1 ? new Promise<State.SUCCEEDED>(() => {}) : State.SUCCEEDED),
                    Other: () => State.RUNNING
                };
                const options = { random: () => 0 };

                const original = new BehaviourTree(treeDefinition, agent, options);
                original.step();
                assert.equal(calls, 1);

                const restored = new BehaviourTree(treeDefinition, agent, options);
                restored.restore(JSON.parse(JSON.stringify(original.snapshot())));
                restored.step();

                assert.equal(calls, 2);
            });
        }

        for (const result of [State.SUCCEEDED, State.FAILED]) {
            it(`by keeping the result of a promise that resolved with ${result}, so that the function is not called again`, async () => {
                let calls = 0;
                const agent = { Work: () => (calls++, Promise.resolve(result)) };

                const original = new BehaviourTree(definition, agent);
                original.step();
                await settle();
                assert.equal(original.getState(), State.RUNNING);

                const snapshot = JSON.parse(JSON.stringify(original.snapshot()));
                assert.equal(calls, 1);

                const restored = new BehaviourTree(definition, agent);
                restored.restore(snapshot);
                assert.equal(restored.getState(), State.RUNNING);

                restored.step();
                assert.equal(calls, 1);
                assert.equal(restored.getState(), result);
            });
        }

        it("by keeping the reason a promise rejected, so that the tree errors in the same way", async () => {
            const agent = { Work: () => Promise.reject(new Error("the build broke")) };
            const getStepError = (tree: BehaviourTree) => {
                try {
                    tree.step();
                } catch (error) {
                    return (error as Error).message;
                }
                return "the tree did not error";
            };

            const original = new BehaviourTree(definition, agent);
            original.step();
            await settle();

            const restored = new BehaviourTree(definition, agent);
            restored.restore(JSON.parse(JSON.stringify(original.snapshot())));

            const originalError = getStepError(original);
            assert.include(originalError, "action function 'Work' promise rejected with 'Error: the build broke'");
            assert.equal(getStepError(restored), originalError);
        });

        it("by keeping a result of a promise that is not a valid state, so that the tree errors in the same way", async () => {
            const agent = { Work: () => Promise.resolve("not a state") as any };

            const original = new BehaviourTree(definition, agent);
            original.step();
            await settle();

            const restored = new BehaviourTree(definition, agent);
            restored.restore(JSON.parse(JSON.stringify(original.snapshot())));

            assert.throws(() => restored.step(), Error, "action node promise resolved with an invalid value");
        });

        it("by ignoring a promise from before a restore", async () => {
            let calls = 0;
            let resolveFirst: (state: State.SUCCEEDED) => void = () => {};
            const agent = {
                Work: () => {
                    calls++;
                    return calls === 1
                        ? new Promise<State.SUCCEEDED>((resolve) => (resolveFirst = resolve))
                        : State.RUNNING;
                }
            };

            const tree = new BehaviourTree(definition, agent);
            tree.step();
            assert.equal(calls, 1);

            tree.restore(new BehaviourTree(definition, agent).snapshot());

            resolveFirst(State.SUCCEEDED);
            await settle();

            tree.step();
            assert.equal(calls, 2);
            assert.equal(tree.getState(), State.RUNNING);
        });

        it("by not keeping the result of a promise for an action that has finished", async () => {
            const agent = { Work: () => Promise.resolve(State.SUCCEEDED) };

            const original = new BehaviourTree(definition, agent);
            original.step();
            await settle();
            original.step();
            assert.equal(original.getState(), State.SUCCEEDED);

            const snapshot = JSON.parse(JSON.stringify(original.snapshot()));
            assert.isNull(snapshot.root.children[0].promiseResult);

            const restored = new BehaviourTree(definition, agent);
            restored.restore(snapshot);
            assert.equal(getObservableDetails(restored), getObservableDetails(original));
        });

        describe("and will error when restoring if the promise result", () => {
            const createSnapshot = async () => {
                const tree = new BehaviourTree(definition, { Work: () => Promise.resolve(State.SUCCEEDED) });
                tree.step();
                await settle();
                return { tree, snapshot: JSON.parse(JSON.stringify(tree.snapshot())) };
            };

            for (const invalid of [
                "settled",
                1,
                [],
                undefined,
                {},
                { isResolved: "yes", value: null },
                { isResolved: true },
                { isResolved: true, value: 1 }
            ]) {
                it(`is ${JSON.stringify(invalid) ?? "missing"}`, async () => {
                    const { tree, snapshot } = await createSnapshot();
                    snapshot.root.children[0].promiseResult = invalid;

                    assert.throws(
                        () => tree.restore(snapshot),
                        Error,
                        "invalid snapshot: expected 'promiseResult' to be null or an object with a boolean 'isResolved' and a string or null 'value' at '$.children[0]'"
                    );
                });
            }
        });
    });

    describe("keeps a snapshot independent of the trees it was taken from and restored to", () => {
        const definitions: [string, string][] = [
            [
                "(every kind of node)",
                `root {
                    sequence {
                        repeat [2,4] { sequence { action [Work] wait [10,50] } }
                        lotto [1,2] { action [Work] action [Other] }
                        retry [2,3] { action [Doomed] }
                        parallel { action [Work] wait [100] }
                        race { action [Work] action [Other] }
                        all { action [Work] action [Other] }
                        flip { action [Other] }
                    }
                }`
            ],
            [
                "(actions with promises)",
                "root { parallel { action [Resolves] action [Rejects] action [Never] wait [50] } }"
            ],
            ["(guards)", "root { repeat { sequence { action [Other] while(Keep) wait [10] } } }"]
        ];

        for (const [name, definition] of definitions) {
            for (const useDeltaTime of [false, true]) {
                it(`${name} ${useDeltaTime ? "using the 'getDeltaTime' option" : "using the clock"}`, async () => {
                    const clock = sinon.useFakeTimers({ now: CLOCK_START });

                    try {
                        let calls = 0;
                        const agent = {
                            Work: () => (++calls % 3 === 0 ? State.SUCCEEDED : undefined),
                            Other: () => (++calls % 2 === 0 ? State.SUCCEEDED : State.RUNNING),
                            Doomed: () => State.FAILED,
                            Keep: () => ++calls % 5 !== 0,
                            Resolves: () => new Promise((resolve) => setTimeout(() => resolve(State.SUCCEEDED), 5)),
                            Rejects: () => new Promise((_, reject) => setTimeout(() => reject(new Error("no")), 7)),
                            Never: () => new Promise(() => {})
                        };
                        const options = { random: () => 0.5, getDeltaTime: useDeltaTime ? () => 0.01 : undefined };

                        const stepIgnoringErrors = (tree: BehaviourTree) => {
                            try {
                                tree.step();
                            } catch (error) {
                                // A rejected promise is an error, which is not what is being tested here.
                            }
                        };
                        const advance = async () => {
                            clock.tick(3);
                            await Promise.resolve();
                        };

                        const tree = new BehaviourTree(definition, agent, options);

                        for (let index = 0; index < 60; index++) {
                            const snapshot = tree.snapshot();
                            const snapshotJSON = JSON.stringify(snapshot);

                            // Restore into a tree that is partway through a run, and not just a new one.
                            const restored = new BehaviourTree(definition, agent, options);
                            for (let step = 0; step < index % 4; step++) {
                                stepIgnoringErrors(restored);
                            }
                            restored.restore(snapshot);

                            assert.deepEqual(
                                JSON.parse(JSON.stringify(restored.snapshot())),
                                JSON.parse(snapshotJSON),
                                `a snapshot taken straight after a restore differs (snapshot ${index})`
                            );

                            stepIgnoringErrors(tree);
                            await advance();
                            assert.equal(
                                JSON.stringify(snapshot),
                                snapshotJSON,
                                `stepping the tree changed snapshot ${index}`
                            );

                            for (let step = 0; step < 3; step++) {
                                stepIgnoringErrors(restored);
                                await advance();
                            }
                            assert.equal(
                                JSON.stringify(snapshot),
                                snapshotJSON,
                                `stepping the restored tree changed snapshot ${index}`
                            );
                        }
                    } finally {
                        clock.restore();
                    }
                });
            }
        }
    });

    describe("restores a tree that behaves like the original", () => {
        itBehavesLikeTheOriginalWhenRestored({
            name: "(sequence, selector, flip, succeed and fail nodes)",
            definition: `root {
                sequence {
                    condition [Ready]
                    selector {
                        action [Try]
                        action [Fallback]
                    }
                    flip { action [Check] }
                    succeed { action [Slow] }
                    selector {
                        fail { action [Doomed] }
                        action [Last]
                    }
                }
            }`,
            script: {
                Ready: (call) => call % 7 !== 0,
                Try: (call) => (call % 3 === 0 ? State.FAILED : call % 3 === 1 ? undefined : State.SUCCEEDED),
                Fallback: (call) => (call % 2 === 0 ? State.RUNNING : State.SUCCEEDED),
                Check: (call) => (call % 3 === 1 ? undefined : call % 2 === 0 ? State.SUCCEEDED : State.FAILED),
                Slow: (call) => (call % 3 === 0 ? State.SUCCEEDED : call % 3 === 1 ? State.RUNNING : State.FAILED),
                Doomed: (call) => (call % 2 === 1 ? State.RUNNING : call % 4 === 0 ? State.SUCCEEDED : State.FAILED),
                Last: (call) => (call % 2 === 0 ? State.FAILED : State.SUCCEEDED)
            },
            steps: 60,
            msPerStep: 100,
            covers: ["root", "sequence", "selector", "flip", "succeed", "fail", "action"]
        });

        itBehavesLikeTheOriginalWhenRestored({
            name: "(parallel, race and all nodes)",
            definition: `root {
                sequence {
                    parallel {
                        action [A]
                        action [B]
                    }
                    race {
                        action [A]
                        action [B]
                    }
                    all {
                        action [A]
                        action [B]
                    }
                }
            }`,
            script: {
                A: (call) =>
                    call % 4 === 1 || call % 4 === 2 ? State.RUNNING : call % 4 === 3 ? State.SUCCEEDED : State.FAILED,
                B: (call) => (call % 3 === 0 ? State.SUCCEEDED : call % 7 === 5 ? State.FAILED : undefined)
            },
            steps: 60,
            msPerStep: 100,
            covers: ["parallel", "race", "all"]
        });

        itBehavesLikeTheOriginalWhenRestored({
            name: "(guards and entry, step and exit callbacks)",
            definition: `root {
                sequence {
                    action [Work] while(Keep, "work") entry(Enter, 1) step(Tick) exit(Leave)
                    selector {
                        sequence until(Stop) {
                            action [Work] entry(Enter, 2) exit(Leave)
                            action [Work]
                        }
                        action [Work]
                    }
                }
            }`,
            script: {
                Keep: (call) => call % 6 !== 0,
                Stop: (call) => call % 5 === 0,
                Enter: () => undefined,
                Tick: () => undefined,
                Leave: () => undefined,
                Work: (call) => (call % 4 === 0 ? State.SUCCEEDED : call % 9 === 0 ? State.FAILED : State.RUNNING)
            },
            steps: 60,
            msPerStep: 100,
            covers: ["sequence", "selector", "action"]
        });

        itBehavesLikeTheOriginalWhenRestored({
            name: "(repeat nodes)",
            definition: `root {
                sequence {
                    repeat [3] {
                        action [Work]
                    }
                    repeat [2,5] {
                        sequence {
                            action [Work]
                            action [Other]
                        }
                    }
                    repeat [1,2] {
                        repeat [2,3] {
                            action [Other]
                        }
                    }
                }
            }`,
            script: {
                Work: (call) => (call % 3 === 0 ? State.SUCCEEDED : call % 11 === 0 ? State.FAILED : undefined),
                Other: (call) => (call % 2 === 0 ? State.SUCCEEDED : call % 13 === 0 ? State.FAILED : State.RUNNING)
            },
            steps: 80,
            msPerStep: 100,
            covers: ["repeat"]
        });

        itBehavesLikeTheOriginalWhenRestored({
            name: "(retry nodes)",
            definition: `root {
                selector {
                    retry [3] {
                        action [Work]
                    }
                    retry [2,5] {
                        sequence {
                            action [Work]
                            action [Other]
                        }
                    }
                    retry [1,2] {
                        retry [2,3] {
                            action [Other]
                        }
                    }
                }
            }`,
            script: {
                Work: (call) => (call % 4 === 0 ? State.SUCCEEDED : call % 4 === 1 ? undefined : State.FAILED),
                Other: (call) => (call % 5 === 0 ? State.SUCCEEDED : call % 2 === 0 ? State.FAILED : State.RUNNING)
            },
            steps: 80,
            msPerStep: 100,
            covers: ["retry"]
        });

        itBehavesLikeTheOriginalWhenRestored({
            name: "(repeat and retry nodes without a limit)",
            definition: `root {
                parallel {
                    repeat while(Keep) {
                        action [Work]
                    }
                    retry until(Stop) {
                        action [Other]
                    }
                }
            }`,
            script: {
                Keep: (call) => call % 9 !== 0,
                Stop: (call) => call % 8 === 0,
                Work: (call) => (call % 2 === 0 ? State.SUCCEEDED : undefined),
                Other: (call) => (call % 3 === 0 ? State.FAILED : undefined)
            },
            steps: 80,
            msPerStep: 100,
            covers: ["repeat", "retry"]
        });

        itBehavesLikeTheOriginalWhenRestored({
            name: "(lotto nodes)",
            definition: `root {
                sequence {
                    repeat [4] {
                        lotto {
                            action [A]
                            sequence {
                                action [B]
                                action [A]
                            }
                            condition [C]
                        }
                    }
                    repeat [3] {
                        lotto [1,5,2] {
                            action [B]
                            action [A]
                            action [B]
                        }
                    }
                }
            }`,
            script: {
                A: (call) => (call % 3 === 0 ? State.SUCCEEDED : call % 5 === 0 ? State.FAILED : undefined),
                B: (call) => (call % 2 === 0 ? State.SUCCEEDED : undefined),
                C: (call) => call % 4 !== 0
            },
            steps: 80,
            msPerStep: 100,
            covers: ["lotto"]
        });

        itBehavesLikeTheOriginalWhenRestored({
            name: "(wait nodes)",
            definition: `root {
                sequence {
                    wait [300]
                    action [After]
                    wait [100,500]
                    repeat [2,3] {
                        sequence {
                            wait [50,250]
                            action [After]
                        }
                    }
                    race {
                        wait [400]
                        action [Quick]
                    }
                    race {
                        wait
                        action [Quick]
                    }
                    parallel {
                        wait [200]
                        wait [100,300]
                    }
                }
            }`,
            script: {
                After: (call) => (call % 2 === 0 ? State.SUCCEEDED : State.RUNNING),
                Quick: (call) => (call % 6 === 0 ? State.SUCCEEDED : undefined)
            },
            steps: 100,
            msPerStep: 70,
            covers: ["wait", "race", "parallel"]
        });
    });
});
