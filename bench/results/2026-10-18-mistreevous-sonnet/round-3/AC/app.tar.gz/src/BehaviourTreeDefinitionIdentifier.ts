import { RootNodeDefinition } from "./BehaviourTreeDefinition";

/**
 * Gets an identifier for a tree definition, which is the same for any definitions that build the same tree.
 * An MDSL definition and its equivalent JSON definition have the same identifier, as the identifier is of the JSON definition
 * once it is normalized to not depend on key order, the order of subtrees or properties that have their default value.
 * @param definition The root node definitions of a valid tree definition, as JSON.
 * @returns An identifier for the tree definition.
 */
export function getDefinitionIdentifier(definition: RootNodeDefinition[]): string {
    // The main root node, which has no 'id', always comes first, and then the subtrees in the order of their 'id'.
    const rootNodeDefinitions = [...definition].sort((a, b) => {
        if (a.id === b.id) {
            return 0;
        }

        return typeof a.id === "undefined" ? -1 : typeof b.id === "undefined" ? 1 : a.id! < b.id! ? -1 : 1;
    });

    return hash(JSON.stringify(normalize(rootNodeDefinitions)));
}

/**
 * Creates a copy of a value that is the same for any definitions that build the same tree.
 * @param value The value to normalize.
 * @returns The normalized copy of the value.
 */
function normalize(value: unknown): unknown {
    if (Array.isArray(value)) {
        return value.map(normalize);
    }

    if (typeof value !== "object" || value === null) {
        return value;
    }

    const normalized: { [key: string]: unknown } = {};

    for (const key of Object.keys(value).sort()) {
        const property = (value as { [key: string]: unknown })[key];

        // MDSL always defines these, but they can be left out of JSON where they have the value they would otherwise default to.
        const isDefault =
            typeof property === "undefined" ||
            (key === "args" && Array.isArray(property) && property.length === 0) ||
            (key === "succeedOnAbort" && !property);

        if (!isDefault) {
            normalized[key] = key === "succeedOnAbort" ? true : normalize(property);
        }
    }

    return normalized;
}

/**
 * Gets a 53 bit hash of a string as a hex string (cyrb53), which is enough to tell tree definitions apart.
 * @param value The string to hash.
 * @returns The hash of the string.
 */
function hash(value: string): string {
    let h1 = 0xdeadbeef;
    let h2 = 0x41c6ce57;

    for (let index = 0; index < value.length; index++) {
        const code = value.charCodeAt(index);
        h1 = Math.imul(h1 ^ code, 2654435761);
        h2 = Math.imul(h2 ^ code, 1597334677);
    }

    h1 = Math.imul(h1 ^ (h1 >>> 16), 2246822507) ^ Math.imul(h2 ^ (h2 >>> 13), 3266489909);
    h2 = Math.imul(h2 ^ (h2 >>> 16), 2246822507) ^ Math.imul(h1 ^ (h1 >>> 13), 3266489909);

    return (4294967296 * (2097151 & h2) + (h1 >>> 0)).toString(16).padStart(14, "0");
}
