import { AnyState } from "./State";

/**
 * The version of the snapshot format that is produced, and the only version that can be restored.
 */
export const SNAPSHOT_VERSION = 1;

/**
 * The snapshot of a node, which holds the state of the node and the snapshots of any child nodes.
 */
type BaseNodeSnapshot<TType extends string> = {
    /**
     * The tree node type.
     */
    type: TType;
    /**
     * The state of the tree node.
     */
    state: AnyState;
    /**
     * The snapshots of the child nodes of this node, in order. Defined if this node is a composite or decorator node.
     */
    children?: NodeSnapshot[];
};

/**
 * The snapshot of a node that has no state of its own beyond its node state and the state of any children.
 */
export type StatelessNodeSnapshot = BaseNodeSnapshot<
    "root" | "sequence" | "selector" | "parallel" | "race" | "all" | "flip" | "succeed" | "fail" | "condition"
>;

/**
 * The snapshot of a repeat node.
 */
export type RepeatNodeSnapshot = BaseNodeSnapshot<"repeat"> & {
    /**
     * The number of iterations that have been completed.
     */
    currentIterationCount: number;
    /**
     * The number of iterations to make, including any random choice that was made. This is null if there is no limit.
     */
    targetIterationCount: number | null;
};

/**
 * The snapshot of a retry node.
 */
export type RetryNodeSnapshot = BaseNodeSnapshot<"retry"> & {
    /**
     * The number of attempts that have been completed.
     */
    currentAttemptCount: number;
    /**
     * The number of attempts to make, including any random choice that was made. This is null if there is no limit.
     */
    targetAttemptCount: number | null;
};

/**
 * The snapshot of a lotto node.
 */
export type LottoNodeSnapshot = BaseNodeSnapshot<"lotto"> & {
    /**
     * The index of the child node that was picked as the active one, or null if no child has been picked yet.
     */
    selectedChildIndex: number | null;
};

/**
 * The snapshot of an action node.
 */
export type ActionNodeSnapshot = BaseNodeSnapshot<"action"> & {
    /**
     * The result of a promise returned by the action function that has settled but has not been used to update the node yet, or null if
     * there is none. A promise that has not settled cannot be captured, so an action with one is snapshotted as READY, not yet started,
     * and the action function is called again after it is restored.
     */
    updatePromiseResult: {
        /**
         * Whether the promise was resolved rather than rejected.
         */
        isResolved: boolean;
        /**
         * The promise resolved value or rejection reason, as a string.
         */
        value: string;
    } | null;
};

/**
 * The snapshot of a wait node.
 */
export type WaitNodeSnapshot = BaseNodeSnapshot<"wait"> & {
    /**
     * The total duration in milliseconds to wait for, including any random choice that was made. This is null if the node waits indefinitely.
     */
    totalDuration: number | null;
    /**
     * The duration in milliseconds that the node has waited for so far, which is not affected by time passing after the snapshot was taken.
     */
    waitedDuration: number;
};

/**
 * The snapshot of any node in a behaviour tree.
 */
export type NodeSnapshot =
    | StatelessNodeSnapshot
    | RepeatNodeSnapshot
    | RetryNodeSnapshot
    | LottoNodeSnapshot
    | ActionNodeSnapshot
    | WaitNodeSnapshot;

/**
 * A snapshot of the execution state of a behaviour tree.
 * This is a plain object that is unchanged by serialization to and from JSON, so it can be stored by the application and
 * restored to a tree that was built from the same definition.
 */
export type BehaviourTreeSnapshot = {
    /**
     * The version of the snapshot format.
     */
    version: typeof SNAPSHOT_VERSION;
    /**
     * The identifier of the definition of the tree that the snapshot was taken from. A snapshot can only be restored to a tree
     * with the same definition, where an MDSL definition and its equivalent JSON definition are the same definition.
     */
    definition: string;
    /**
     * The snapshot of the root node of the tree.
     */
    root: NodeSnapshot;
};
