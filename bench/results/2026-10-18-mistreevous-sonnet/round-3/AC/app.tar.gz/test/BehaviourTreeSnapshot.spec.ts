import { assert } from "chai";
import sinon, { SinonFakeTimers } from "sinon";

import { BehaviourTree, BehaviourTreeSnapshot, State } from "../src/index";

import { findNode, withoutIds } from "./TestUtilities";

/**
 * Round trip a snapshot through JSON, as it would be if stored by an application.
 */
const roundTrip = (snapshot: BehaviourTreeSnapshot): BehaviourTreeSnapshot => JSON.parse(JSON.stringify(snapshot));

/**
 * Step the tree until the given condition is met, failing if it takes too many steps.
 */
const stepUntil = (tree: BehaviourTree, isDone: (state: State) => boolean) => {
    for (let step = 0; step < 20; step++) {
        tree.step();

        if (isDone(tree.getState())) {
            return;
        }
    }

    assert.fail("tree did not reach the expected state");
};

describe("A BehaviourTree instance", () => {
    describe("has a snapshot method that", () => {
        it("returns a plain object that is unchanged by a JSON round trip", () => {
            const tree = new BehaviourTree(
                "root { sequence { action [First] action [Second] } }",
                { First: () => State.SUCCEEDED, Second: () => State.RUNNING },
                {}
            );

            // Check a tree that has never been stepped, and one that is part way through.
            assert.deepEqual(roundTrip(tree.snapshot()), tree.snapshot());

            tree.step();

            assert.deepEqual(roundTrip(tree.snapshot()), tree.snapshot());
        });

        it("returns a new object each time, unaffected by later steps of the tree", () => {
            let result: State | undefined = State.RUNNING;
            const tree = new BehaviourTree("root { action [Work] }", { Work: () => result }, {});

            tree.step();

            const snapshot = tree.snapshot();
            const copy = roundTrip(snapshot);

            assert.notStrictEqual(tree.snapshot(), snapshot);

            result = State.SUCCEEDED;
            tree.step();

            assert.deepEqual(snapshot, copy);
        });

        it("does not call any agent functions or change the state of the tree", () => {
            const calls: string[] = [];
            const agent = {
                Work: () => {
                    calls.push("Work");
                    return State.RUNNING;
                },
                Entry: () => calls.push("Entry")
            };
            const tree = new BehaviourTree("root { action [Work] entry(Entry) }", agent, {});

            tree.step();
            calls.length = 0;
            const before = tree.getTreeNodeDetails();

            tree.snapshot();

            assert.deepEqual(calls, []);
            assert.deepEqual(tree.getTreeNodeDetails(), before);
        });
    });

    describe("has a restore method that", () => {
        describe("sets the tree to the state of the tree that the snapshot was taken from", () => {
            const definitions: { [name: string]: string } = {
                sequence: "root { sequence { action [Done] action [Busy] action [Done] } }",
                selector: "root { selector { action [Fail] action [Busy] action [Done] } }",
                parallel: "root { parallel { action [Done] action [Busy] } }",
                race: "root { race { action [Fail] action [Busy] } }",
                all: "root { all { action [Done] action [Busy] } }",
                "nested decorators": "root { flip { succeed { sequence { action [Done] action [Busy] } } } }"
            };

            const createAgent = () => ({
                Done: () => State.SUCCEEDED,
                Fail: () => State.FAILED,
                Busy: () => State.RUNNING
            });

            for (const [name, definition] of Object.entries(definitions)) {
                it(name, () => {
                    const original = new BehaviourTree(definition, createAgent(), {});
                    original.step();

                    const restored = new BehaviourTree(definition, createAgent(), {});
                    restored.restore(roundTrip(original.snapshot()));

                    assert.deepEqual(
                        withoutIds(restored.getTreeNodeDetails()),
                        withoutIds(original.getTreeNodeDetails())
                    );
                    assert.strictEqual(restored.getState(), original.getState());
                    assert.deepEqual(restored.snapshot(), original.snapshot());
                });
            }
        });

        it("continues from where the original tree was, without revisiting nodes that were already resolved", () => {
            const calls: string[] = [];
            let finished = false;
            const createAgent = () => ({
                First: () => {
                    calls.push("First");
                    return State.SUCCEEDED;
                },
                Second: () => {
                    calls.push("Second");
                    return finished ? State.SUCCEEDED : State.RUNNING;
                },
                Third: () => {
                    calls.push("Third");
                    return State.SUCCEEDED;
                }
            });
            const definition = "root { sequence { action [First] action [Second] action [Third] } }";

            const original = new BehaviourTree(definition, createAgent(), {});
            original.step();
            assert.deepEqual(calls, ["First", "Second"]);

            // Only restoring should have no effect on what gets called, just the steps that follow.
            const restored = new BehaviourTree(definition, createAgent(), {});
            restored.restore(roundTrip(original.snapshot()));
            assert.deepEqual(calls, ["First", "Second"]);

            finished = true;
            restored.step();

            assert.deepEqual(calls, ["First", "Second", "Second", "Third"]);
            assert.strictEqual(restored.getState(), State.SUCCEEDED);
        });

        it("overwrites any existing progress of the tree being restored", () => {
            const definition = "root { sequence { action [First] action [Second] } }";
            const agent = { First: () => State.SUCCEEDED, Second: () => State.RUNNING };

            const original = new BehaviourTree(definition, agent, {});
            const beforeAnyStep = original.snapshot();
            original.step();
            const afterStep = original.snapshot();

            original.restore(roundTrip(beforeAnyStep));
            assert.strictEqual(original.getState(), State.READY);
            assert.strictEqual(findNode(original, "action", "First").state, State.READY);

            original.restore(roundTrip(afterStep));
            assert.strictEqual(original.getState(), State.RUNNING);
            assert.strictEqual(findNode(original, "action", "First").state, State.SUCCEEDED);
        });

        it("does not call any agent functions, call 'random' or report node state changes", () => {
            const calls: string[] = [];
            const changes: unknown[] = [];
            const agent = {
                Work: () => State.RUNNING,
                Entry: () => calls.push("Entry"),
                Exit: () => calls.push("Exit"),
                Guard: () => {
                    calls.push("Guard");
                    return true;
                }
            };
            const definition = "root { sequence { action [Work] entry(Entry) exit(Exit) while(Guard) } }";

            const original = new BehaviourTree(definition, agent, {});
            original.step();
            const snapshot = original.snapshot();
            calls.length = 0;

            const restored = new BehaviourTree(definition, agent, {
                random: () => {
                    throw new Error("random should not be used when restoring");
                },
                onNodeStateChange: (change) => changes.push(change)
            });
            restored.restore(snapshot);

            assert.deepEqual(calls, []);
            assert.deepEqual(changes, []);

            // The restored tree should report changes relative to the restored states.
            restored.reset();

            assert.deepEqual(
                (changes as { previousState: State; state: State }[]).map(({ previousState, state }) => [
                    previousState,
                    state
                ]),
                [
                    [State.RUNNING, State.READY],
                    [State.RUNNING, State.READY],
                    [State.RUNNING, State.READY]
                ]
            );
        });

        describe("with a tree that has a bit of everything", () => {
            const definition = `root {
                sequence {
                    action [Done]
                    repeat [3] { action [Work] }
                    wait [1000]
                    lotto { action [Done] action [Done] }
                    retry [2] { action [Work] }
                    action [Pending]
                }
            }`;

            let isWorkDone: boolean;

            const createAgent = () => ({
                Done: () => State.SUCCEEDED,
                Work: () => (isWorkDone ? State.SUCCEEDED : State.RUNNING),
                Pending: () => Promise.resolve(State.SUCCEEDED)
            });

            const createTree = (onNodeStateChange?: (change: any) => void) =>
                new BehaviourTree(definition, createAgent(), {
                    random: () => 0.5,
                    getDeltaTime: () => 0.5,
                    onNodeStateChange
                });

            const describeChanges = (changes: any[]) =>
                changes.map(({ type, previousState, state }) => `${type}: ${previousState} -> ${state}`);

            beforeEach(() => {
                isWorkDone = false;
            });

            it("does not report node state changes, and the next step reports them as usual", () => {
                const originalChanges: any[] = [];
                const restoredChanges: any[] = [];

                const original = createTree((change) => originalChanges.push(change));
                original.step();

                const snapshot = roundTrip(original.snapshot());
                const restored = createTree((change) => restoredChanges.push(change));

                restored.restore(snapshot);

                assert.deepEqual(restoredChanges, []);

                // Let the work finish and step both trees, which should make the same changes from the same previous states.
                isWorkDone = true;
                originalChanges.length = 0;

                original.step();
                restored.step();

                assert.isNotEmpty(originalChanges);
                assert.deepEqual(describeChanges(restoredChanges), describeChanges(originalChanges));
            });

            it("does not change a snapshot by stepping the tree it was taken from", () => {
                const tree = createTree();
                tree.step();

                const snapshot = tree.snapshot();
                const copy = roundTrip(snapshot);

                isWorkDone = true;
                tree.step();
                tree.step();

                assert.deepEqual(snapshot, copy);
            });

            it("does not change a snapshot by stepping a tree it was restored to", () => {
                const original = createTree();
                original.step();

                const snapshot = original.snapshot();
                const copy = roundTrip(snapshot);

                const restored = createTree();
                restored.restore(snapshot);

                isWorkDone = true;
                restored.step();
                restored.step();

                assert.deepEqual(snapshot, copy);
            });

            it("gives a snapshot equal to the one that was restored when taken before any step", async () => {
                const original = createTree();

                // Check snapshots from the start through to the end of a run, including one with a settled promise that is yet to be used.
                const check = () => {
                    const snapshot = original.snapshot();
                    const restored = createTree();

                    restored.restore(snapshot);

                    assert.deepEqual(roundTrip(restored.snapshot()), roundTrip(snapshot));
                };

                check();
                original.step();
                check();

                isWorkDone = true;

                for (let step = 0; step < 6; step++) {
                    original.step();
                    check();

                    // Let the promise of the pending action settle.
                    await new Promise((resolve) => setTimeout(resolve, 0));
                    check();
                }
            });
        });

        it("does not hold on to the snapshot that was passed in", () => {
            const definition = "root { sequence { action [Work] } }";
            const original = new BehaviourTree(definition, { Work: () => State.RUNNING }, {});
            original.step();
            const snapshot = original.snapshot();

            const restored = new BehaviourTree(definition, { Work: () => State.RUNNING }, {});
            restored.restore(snapshot);
            const expected = restored.snapshot();

            snapshot.root.state = State.FAILED;
            (snapshot.root as any).children[0].state = State.FAILED;

            assert.deepEqual(restored.snapshot(), expected);
        });

        describe("restores a finished tree as finished, where the next step starts a new run", () => {
            for (const result of [State.SUCCEEDED, State.FAILED]) {
                it(`(${result})`, () => {
                    const calls: string[] = [];
                    const createAgent = () => ({
                        Work: () => {
                            calls.push("Work");
                            return result as State.SUCCEEDED | State.FAILED;
                        }
                    });
                    const definition = "root { sequence { action [Work] } }";

                    const original = new BehaviourTree(definition, createAgent(), {});
                    original.step();
                    assert.strictEqual(original.getState(), result);

                    const restored = new BehaviourTree(definition, createAgent(), {});
                    restored.restore(roundTrip(original.snapshot()));

                    assert.strictEqual(restored.getState(), result);
                    assert.isFalse(restored.isRunning());
                    assert.strictEqual(findNode(restored, "action", "Work").state, result);

                    calls.length = 0;
                    restored.step();

                    assert.deepEqual(calls, ["Work"]);
                });
            }
        });

        describe("restores the progress of a repeat node", () => {
            // An action that always succeeds, counting its calls.
            const createAgent = (calls: string[]) => ({
                Work: () => {
                    calls.push("Work");
                    return State.SUCCEEDED;
                }
            });

            it("so that only the remaining iterations are made", () => {
                const definition = "root { repeat [3] { action [Work] } }";

                const originalCalls: string[] = [];
                const original = new BehaviourTree(definition, createAgent(originalCalls), {});
                original.step();
                assert.strictEqual(originalCalls.length, 1);

                const restoredCalls: string[] = [];
                const restored = new BehaviourTree(definition, createAgent(restoredCalls), {});
                restored.restore(roundTrip(original.snapshot()));

                stepUntil(restored, (state) => state === State.SUCCEEDED);

                assert.strictEqual(restoredCalls.length, 2);
            });

            it("so that a random iteration count that was already picked is kept", () => {
                const definition = "root { repeat [2, 5] { action [Work] } }";

                // This will pick five iterations.
                const originalCalls: string[] = [];
                const original = new BehaviourTree(definition, createAgent(originalCalls), { random: () => 0.99 });
                original.step();
                original.step();

                // This would pick two iterations if it were used, which it should not be.
                const restoredCalls: string[] = [];
                const restored = new BehaviourTree(definition, createAgent(restoredCalls), { random: () => 0 });
                restored.restore(roundTrip(original.snapshot()));

                stepUntil(restored, (state) => state === State.SUCCEEDED);

                assert.strictEqual(originalCalls.length + restoredCalls.length, 5);
                assert.strictEqual(restoredCalls.length, 3);
            });

            it("so that a repeat node without an iteration count keeps repeating", () => {
                const definition = "root { repeat { action [Work] } }";

                const original = new BehaviourTree(definition, createAgent([]), {});
                original.step();

                const calls: string[] = [];
                const restored = new BehaviourTree(definition, createAgent(calls), {});
                restored.restore(roundTrip(original.snapshot()));

                for (let step = 0; step < 10; step++) {
                    restored.step();
                }

                assert.strictEqual(calls.length, 10);
                assert.isTrue(restored.isRunning());
            });

            it("so that a finished node picks a new random iteration count on the next run", () => {
                const definition = "root { repeat [1, 4] { action [Work] } }";

                const original = new BehaviourTree(definition, createAgent([]), { random: () => 0 });
                stepUntil(original, (state) => state === State.SUCCEEDED);

                const calls: string[] = [];
                const restored = new BehaviourTree(definition, createAgent(calls), { random: () => 0.99 });
                restored.restore(roundTrip(original.snapshot()));
                assert.strictEqual(restored.getState(), State.SUCCEEDED);

                stepUntil(restored, (state) => state === State.SUCCEEDED);

                assert.strictEqual(calls.length, 4);
            });
        });

        describe("restores the progress of a retry node", () => {
            const createAgent = (calls: string[]) => ({
                Work: () => {
                    calls.push("Work");
                    return State.FAILED;
                }
            });

            it("so that only the remaining attempts are made", () => {
                const definition = "root { retry [3] { action [Work] } }";

                const original = new BehaviourTree(definition, createAgent([]), {});
                original.step();

                const calls: string[] = [];
                const restored = new BehaviourTree(definition, createAgent(calls), {});
                restored.restore(roundTrip(original.snapshot()));

                stepUntil(restored, (state) => state === State.FAILED);

                assert.strictEqual(calls.length, 2);
                assert.strictEqual(restored.getState(), State.FAILED);
            });

            it("so that a random attempt count that was already picked is kept", () => {
                const definition = "root { retry [2, 5] { action [Work] } }";

                // This will pick five attempts.
                const original = new BehaviourTree(definition, createAgent([]), { random: () => 0.99 });
                original.step();
                original.step();

                // This would pick two attempts if it were used, which it should not be.
                const calls: string[] = [];
                const restored = new BehaviourTree(definition, createAgent(calls), { random: () => 0 });
                restored.restore(roundTrip(original.snapshot()));

                stepUntil(restored, (state) => state === State.FAILED);

                assert.strictEqual(calls.length, 3);
            });

            it("so that a retry node without an attempt count keeps retrying", () => {
                const definition = "root { retry { action [Work] } }";

                const original = new BehaviourTree(definition, createAgent([]), {});
                original.step();

                const calls: string[] = [];
                const restored = new BehaviourTree(definition, createAgent(calls), {});
                restored.restore(roundTrip(original.snapshot()));

                for (let step = 0; step < 10; step++) {
                    restored.step();
                }

                assert.strictEqual(calls.length, 10);
                assert.isTrue(restored.isRunning());
            });

            it("so that a finished node picks a new random attempt count on the next run", () => {
                const definition = "root { retry [1, 4] { action [Work] } }";

                const original = new BehaviourTree(definition, createAgent([]), { random: () => 0 });
                stepUntil(original, (state) => state === State.FAILED);

                const calls: string[] = [];
                const restored = new BehaviourTree(definition, createAgent(calls), { random: () => 0.99 });
                restored.restore(roundTrip(original.snapshot()));
                assert.strictEqual(restored.getState(), State.FAILED);

                stepUntil(restored, (state) => state === State.FAILED);

                assert.strictEqual(calls.length, 4);
            });
        });

        describe("restores the choice of a lotto node", () => {
            const definition = "root { lotto { action [First] action [Second] } }";

            const createAgent = (calls: string[]) => ({
                First: () => {
                    calls.push("First");
                    return State.RUNNING;
                },
                Second: () => {
                    calls.push("Second");
                    return State.RUNNING;
                }
            });

            it("so that the selected child is still the active one", () => {
                // This will pick the second child.
                const original = new BehaviourTree(definition, createAgent([]), { random: () => 0.99 });
                original.step();

                // This would pick the first child if it were used, which it should not be.
                const calls: string[] = [];
                const restored = new BehaviourTree(definition, createAgent(calls), { random: () => 0 });
                restored.restore(roundTrip(original.snapshot()));

                restored.step();
                restored.step();

                assert.deepEqual(calls, ["Second", "Second"]);
                assert.strictEqual(findNode(restored, "action", "First").state, State.READY);
                assert.strictEqual(findNode(restored, "action", "Second").state, State.RUNNING);
            });

            it("so that a finished node makes a new choice on the next run", () => {
                const finishingAgent = (calls: string[]) => ({
                    First: () => {
                        calls.push("First");
                        return State.SUCCEEDED;
                    },
                    Second: () => {
                        calls.push("Second");
                        return State.SUCCEEDED;
                    }
                });

                const original = new BehaviourTree(definition, finishingAgent([]), { random: () => 0.99 });
                original.step();
                assert.strictEqual(original.getState(), State.SUCCEEDED);

                const calls: string[] = [];
                const restored = new BehaviourTree(definition, finishingAgent(calls), { random: () => 0 });
                restored.restore(roundTrip(original.snapshot()));
                assert.strictEqual(findNode(restored, "action", "Second").state, State.SUCCEEDED);

                restored.step();

                assert.deepEqual(calls, ["First"]);
            });

            it("so that a lotto node that was resolved by a guard before making a choice is restored as resolved", () => {
                const guardedDefinition = "root { lotto while(Unsatisfied) { action [First] action [Second] } }";
                const agent = { ...createAgent([]), Unsatisfied: () => false };

                const original = new BehaviourTree(guardedDefinition, agent, {});
                original.step();
                assert.strictEqual(original.getState(), State.FAILED);

                const restored = new BehaviourTree(guardedDefinition, agent, {});
                restored.restore(roundTrip(original.snapshot()));

                assert.strictEqual(restored.getState(), State.FAILED);
                assert.deepEqual(restored.snapshot(), original.snapshot());
            });

            it("so that a lotto node that has not made a choice yet still does so on its first update", () => {
                const original = new BehaviourTree(definition, createAgent([]), {});

                const calls: string[] = [];
                const restored = new BehaviourTree(definition, createAgent(calls), { random: () => 0.99 });
                restored.restore(roundTrip(original.snapshot()));
                restored.step();

                assert.deepEqual(calls, ["Second"]);
            });
        });

        describe("restores the progress of a wait node", () => {
            const ONE_DAY = 24 * 60 * 60 * 1000;

            let clock: SinonFakeTimers;

            beforeEach(() => {
                clock = sinon.useFakeTimers();
            });

            afterEach(() => {
                clock.restore();
            });

            describe("using the clock", () => {
                it("so that only the remaining time is waited for, however long passes before restoring", () => {
                    const definition = "root { wait [1000] }";

                    const original = new BehaviourTree(definition, {}, {});
                    original.step();

                    // Take the snapshot well after the last step, as that is the time that should have been waited.
                    clock.tick(400);
                    const snapshot = roundTrip(original.snapshot());

                    clock.tick(ONE_DAY);
                    const restored = new BehaviourTree(definition, {}, {});
                    restored.restore(snapshot);

                    restored.step();
                    assert.strictEqual(restored.getState(), State.RUNNING);

                    clock.tick(599);
                    restored.step();
                    assert.strictEqual(restored.getState(), State.RUNNING);

                    clock.tick(1);
                    restored.step();
                    assert.strictEqual(restored.getState(), State.SUCCEEDED);
                });

                it("so that a random duration that was already picked is kept", () => {
                    const definition = "root { wait [100, 1000] }";

                    // This will pick a duration of 991 milliseconds.
                    const original = new BehaviourTree(definition, {}, { random: () => 0.99 });
                    original.step();
                    clock.tick(500);
                    const snapshot = roundTrip(original.snapshot());

                    // This would pick a duration of 100 milliseconds if it were used, which it should not be.
                    const restored = new BehaviourTree(definition, {}, { random: () => 0 });
                    restored.restore(snapshot);

                    clock.tick(490);
                    restored.step();
                    assert.strictEqual(restored.getState(), State.RUNNING);

                    clock.tick(1);
                    restored.step();
                    assert.strictEqual(restored.getState(), State.SUCCEEDED);
                });

                it("so that a wait node without a duration keeps waiting", () => {
                    const definition = "root { wait }";

                    const original = new BehaviourTree(definition, {}, {});
                    original.step();
                    const snapshot = roundTrip(original.snapshot());

                    const restored = new BehaviourTree(definition, {}, {});
                    restored.restore(snapshot);

                    clock.tick(ONE_DAY);
                    restored.step();

                    assert.strictEqual(restored.getState(), State.RUNNING);
                });

                it("so that a finished node picks a new random duration and starts waiting again on the next run", () => {
                    const definition = "root { wait [100, 1000] }";

                    const original = new BehaviourTree(definition, {}, { random: () => 0.99 });
                    original.step();
                    clock.tick(991);
                    original.step();
                    assert.strictEqual(original.getState(), State.SUCCEEDED);
                    const snapshot = roundTrip(original.snapshot());

                    clock.tick(ONE_DAY);
                    const restored = new BehaviourTree(definition, {}, { random: () => 0 });
                    restored.restore(snapshot);
                    assert.strictEqual(restored.getState(), State.SUCCEEDED);

                    restored.step();
                    assert.strictEqual(restored.getState(), State.RUNNING);

                    clock.tick(100);
                    restored.step();
                    assert.strictEqual(restored.getState(), State.SUCCEEDED);
                });

                it("so that it can be restored to a tree that uses 'getDeltaTime'", () => {
                    const definition = "root { wait [1000] }";

                    const original = new BehaviourTree(definition, {}, {});
                    original.step();
                    clock.tick(500);
                    const snapshot = roundTrip(original.snapshot());

                    clock.tick(ONE_DAY);
                    const restored = new BehaviourTree(definition, {}, { getDeltaTime: () => 0.25 });
                    restored.restore(snapshot);

                    restored.step();
                    assert.strictEqual(restored.getState(), State.RUNNING);

                    restored.step();
                    assert.strictEqual(restored.getState(), State.SUCCEEDED);
                });
            });

            describe("using 'getDeltaTime'", () => {
                it("so that only the remaining time is waited for, however long passes before restoring", () => {
                    const definition = "root { wait [1000] }";
                    const options = { getDeltaTime: () => 0.25 };

                    const original = new BehaviourTree(definition, {}, options);
                    original.step();
                    original.step();
                    const snapshot = roundTrip(original.snapshot());

                    clock.tick(ONE_DAY);
                    const restored = new BehaviourTree(definition, {}, options);
                    restored.restore(snapshot);

                    restored.step();
                    assert.strictEqual(restored.getState(), State.RUNNING);

                    restored.step();
                    assert.strictEqual(restored.getState(), State.SUCCEEDED);
                });

                it("so that a random duration that was already picked is kept", () => {
                    const definition = "root { wait [100, 1000] }";
                    const options = { getDeltaTime: () => 0.2 };

                    // This will pick a duration of 991 milliseconds.
                    const original = new BehaviourTree(definition, {}, { ...options, random: () => 0.99 });
                    original.step();
                    const snapshot = roundTrip(original.snapshot());

                    // This would pick a duration of 100 milliseconds if it were used, which it should not be.
                    const restored = new BehaviourTree(definition, {}, { ...options, random: () => 0 });
                    restored.restore(snapshot);

                    restored.step();
                    restored.step();
                    restored.step();
                    assert.strictEqual(restored.getState(), State.RUNNING);

                    restored.step();
                    assert.strictEqual(restored.getState(), State.SUCCEEDED);
                });

                it("so that it can be restored to a tree that uses the clock", () => {
                    const definition = "root { wait [1000] }";

                    const original = new BehaviourTree(definition, {}, { getDeltaTime: () => 0.5 });
                    original.step();
                    const snapshot = roundTrip(original.snapshot());

                    clock.tick(ONE_DAY);
                    const restored = new BehaviourTree(definition, {}, {});
                    restored.restore(snapshot);

                    restored.step();
                    assert.strictEqual(restored.getState(), State.RUNNING);

                    clock.tick(500);
                    restored.step();
                    assert.strictEqual(restored.getState(), State.SUCCEEDED);
                });
            });
        });

        describe("restores the progress of an action node that returns a promise", () => {
            const definition = "root { action [Work] }";

            // Wait for any promises that are ready to settle to do so.
            const settle = () => new Promise((resolve) => setImmediate(resolve));

            // Create an agent with an action that returns a promise which is settled by the test.
            const createAgent = () => {
                const agent = {
                    calls: 0,
                    resolve: (_value: unknown) => {},
                    reject: (_reason: unknown) => {},
                    Work: () => {
                        agent.calls += 1;
                        return new Promise<State.SUCCEEDED | State.FAILED>((resolve, reject) => {
                            agent.resolve = resolve as (value: unknown) => void;
                            agent.reject = reject;
                        });
                    }
                };

                return agent;
            };

            describe("so that a settled result that was not yet used is not lost", () => {
                for (const result of [State.SUCCEEDED, State.FAILED]) {
                    it(`(${result})`, async () => {
                        const originalAgent = createAgent();
                        const original = new BehaviourTree(definition, originalAgent, {});
                        original.step();
                        originalAgent.resolve(result);
                        await settle();
                        const snapshot = roundTrip(original.snapshot());

                        const restoredAgent = createAgent();
                        const restored = new BehaviourTree(definition, restoredAgent, {});
                        restored.restore(snapshot);
                        assert.strictEqual(restored.getState(), State.RUNNING);

                        restored.step();

                        assert.strictEqual(restored.getState(), result);
                        assert.strictEqual(restoredAgent.calls, 0);
                    });
                }

                it("(rejected)", async () => {
                    const originalAgent = createAgent();
                    const original = new BehaviourTree(definition, originalAgent, {});
                    original.step();
                    originalAgent.reject("something went wrong");
                    await settle();
                    const snapshot = roundTrip(original.snapshot());

                    const restoredAgent = createAgent();
                    const restored = new BehaviourTree(definition, restoredAgent, {});
                    restored.restore(snapshot);

                    assert.throws(
                        () => restored.step(),
                        Error,
                        "error stepping tree: action function 'Work' promise rejected with 'something went wrong'"
                    );
                    assert.strictEqual(restoredAgent.calls, 0);
                });

                it("(resolved with an invalid value)", async () => {
                    const originalAgent = createAgent();
                    const original = new BehaviourTree(definition, originalAgent, {});
                    original.step();
                    originalAgent.resolve("invalid");
                    await settle();
                    const snapshot = roundTrip(original.snapshot());

                    const restored = new BehaviourTree(definition, createAgent(), {});
                    restored.restore(snapshot);

                    assert.throws(
                        () => restored.step(),
                        Error,
                        "action node promise resolved with an invalid value, expected a State.SUCCEEDED or State.FAILED value to be returned"
                    );
                });
            });

            it("so that an action with a promise that was still pending is restored as not yet started", async () => {
                const originalAgent = createAgent();
                const original = new BehaviourTree(definition, originalAgent, {});
                original.step();
                original.step();
                assert.strictEqual(originalAgent.calls, 1);
                const snapshot = roundTrip(original.snapshot());

                // Taking the snapshot does not affect the pending promise of the original tree.
                assert.strictEqual(findNode(original, "action").state, State.RUNNING);

                const restoredAgent = createAgent();
                const restored = new BehaviourTree(definition, restoredAgent, {});
                restored.restore(snapshot);
                assert.strictEqual(findNode(restored, "action").state, State.READY);
                assert.strictEqual(restored.getState(), State.RUNNING);
                assert.strictEqual(restoredAgent.calls, 0);

                // The action function is called again on the next step.
                restored.step();
                assert.strictEqual(restoredAgent.calls, 1);
                assert.strictEqual(findNode(restored, "action").state, State.RUNNING);
                assert.strictEqual(restored.getState(), State.RUNNING);

                restoredAgent.resolve(State.SUCCEEDED);
                await settle();
                restored.step();

                assert.strictEqual(restoredAgent.calls, 1);
                assert.strictEqual(restored.getState(), State.SUCCEEDED);
            });

            it("so that the entry and exit callbacks of an action that was not yet started are called around its new run", async () => {
                const calls: string[] = [];
                const createCallbackAgent = () => ({
                    Work: () => {
                        calls.push("Work");
                        return new Promise<State.SUCCEEDED>(() => {});
                    },
                    Entry: () => calls.push("Entry"),
                    Exit: () => calls.push("Exit")
                });
                const callbackDefinition = "root { action [Work] entry(Entry) exit(Exit) }";

                const original = new BehaviourTree(callbackDefinition, createCallbackAgent(), {});
                original.step();
                assert.deepEqual(calls, ["Entry", "Work"]);

                const restored = new BehaviourTree(callbackDefinition, createCallbackAgent(), {});
                restored.restore(roundTrip(original.snapshot()));
                calls.length = 0;
                restored.step();

                assert.deepEqual(calls, ["Entry", "Work"]);
            });

            it("so that an action that is aborted after it was restored as not yet started does not call its exit callback", () => {
                const calls: string[] = [];
                let isSatisfied = true;
                const agent = {
                    Work: () => new Promise<State.SUCCEEDED>(() => {}),
                    Guard: () => isSatisfied,
                    Exit: () => calls.push("Exit")
                };
                const guardedDefinition = "root { sequence while(Guard) { action [Work] exit(Exit) } }";

                const original = new BehaviourTree(guardedDefinition, agent, {});
                original.step();

                const restored = new BehaviourTree(guardedDefinition, agent, {});
                restored.restore(roundTrip(original.snapshot()));

                isSatisfied = false;
                restored.step();

                // The action was not running as far as the restored tree is concerned, so it has nothing to exit.
                assert.deepEqual(calls, []);
                assert.strictEqual(restored.getState(), State.FAILED);
            });

            it("so that a nested action with a pending promise continues alongside its resolved siblings", async () => {
                const nestedDefinition = "root { sequence { action [Done] parallel { action [Done] action [Work] } } }";
                const createNestedAgent = () => Object.assign(createAgent(), { Done: () => State.SUCCEEDED });

                const originalAgent = createNestedAgent();
                const original = new BehaviourTree(nestedDefinition, originalAgent, {});
                for (let step = 0; step < 5 && originalAgent.calls === 0; step++) {
                    original.step();
                }
                assert.strictEqual(originalAgent.calls, 1);

                const restoredAgent = createNestedAgent();
                const restored = new BehaviourTree(nestedDefinition, restoredAgent, {});
                restored.restore(roundTrip(original.snapshot()));
                assert.strictEqual(findNode(restored, "action", "Done").state, State.SUCCEEDED);
                assert.strictEqual(findNode(restored, "action", "Work").state, State.READY);

                restored.step();
                assert.strictEqual(restoredAgent.calls, 1);

                restoredAgent.resolve(State.SUCCEEDED);
                await settle();
                restored.step();

                assert.strictEqual(restoredAgent.calls, 1);
                assert.strictEqual(restored.getState(), State.SUCCEEDED);
            });

            it("so that other actions that are running without a promise are still restored as running", () => {
                const original = new BehaviourTree("root { action [Work] }", { Work: () => State.RUNNING }, {});
                original.step();

                const restored = new BehaviourTree("root { action [Work] }", { Work: () => State.RUNNING }, {});
                restored.restore(roundTrip(original.snapshot()));

                assert.strictEqual(findNode(restored, "action").state, State.RUNNING);
            });

            it("so that a promise from before the tree was restored is ignored", async () => {
                const agent = createAgent();
                const tree = new BehaviourTree(definition, agent, {});
                const beforeAnyStep = roundTrip(tree.snapshot());

                tree.step();
                const staleResolve = agent.resolve;

                tree.restore(beforeAnyStep);
                tree.step();
                assert.strictEqual(agent.calls, 2);

                // The first promise settling should not be mistaken for the result of the second one.
                staleResolve(State.SUCCEEDED);
                await settle();
                tree.step();
                assert.strictEqual(tree.getState(), State.RUNNING);

                agent.resolve(State.FAILED);
                await settle();
                tree.step();
                assert.strictEqual(tree.getState(), State.FAILED);
            });
        });

        it("does not keep anything for a node that is ready, as it starts afresh when it is next updated", () => {
            const clock = sinon.useFakeTimers();

            try {
                const definition = `root {
                    sequence {
                        repeat [2, 4] { action [Work] }
                        retry [2, 4] { action [Work] }
                        lotto { action [Work] action [Work] }
                        wait [100, 400]
                        action [Work]
                    }
                }`;
                const createAgent = () => ({ Work: () => State.SUCCEEDED });

                const used = new BehaviourTree(definition, createAgent(), { random: () => 0.5 });
                for (let step = 0; step < 4; step++) {
                    clock.tick(100);
                    used.step();
                }
                used.reset();

                const unused = new BehaviourTree(definition, createAgent(), {});

                assert.deepEqual(used.snapshot(), unused.snapshot());
            } finally {
                clock.restore();
            }
        });

        describe("will error, leaving the tree as it was, if a node specific value is invalid for", () => {
            let clock: SinonFakeTimers;

            // A wait node snapshot depends on the clock, so it has to stand still for snapshots to be comparable.
            beforeEach(() => {
                clock = sinon.useFakeTimers();
            });

            afterEach(() => {
                clock.restore();
            });

            const cases: { [name: string]: [string, (snapshot: any) => void, string] } = {
                "a repeat node iteration count": [
                    "root { repeat [2] { action [Work] } }",
                    (snapshot) => (snapshot.root.children[0].currentIterationCount = -1),
                    "expected 'currentIterationCount' to be a non-negative integer for repeat node snapshot"
                ],
                "a repeat node target iteration count": [
                    "root { repeat [2] { action [Work] } }",
                    (snapshot) => (snapshot.root.children[0].targetIterationCount = 1.5),
                    "expected 'targetIterationCount' to be null or a non-negative integer for repeat node snapshot"
                ],
                "a retry node attempt count": [
                    "root { retry [2] { action [Work] } }",
                    (snapshot) => delete snapshot.root.children[0].currentAttemptCount,
                    "expected 'currentAttemptCount' to be a non-negative integer for retry node snapshot"
                ],
                "a retry node target attempt count": [
                    "root { retry [2] { action [Work] } }",
                    (snapshot) => (snapshot.root.children[0].targetAttemptCount = "2"),
                    "expected 'targetAttemptCount' to be null or a non-negative integer for retry node snapshot"
                ],
                "a wait node total duration": [
                    "root { wait [1000] }",
                    (snapshot) => (snapshot.root.children[0].totalDuration = -1),
                    "expected 'totalDuration' to be null or a non-negative number for wait node snapshot"
                ],
                "a wait node waited duration": [
                    "root { wait [1000] }",
                    (snapshot) => (snapshot.root.children[0].waitedDuration = null),
                    "expected 'waitedDuration' to be a number for wait node snapshot"
                ],
                "an action node promise result": [
                    "root { action [Work] }",
                    (snapshot) => (snapshot.root.children[0].updatePromiseResult = { isResolved: "yes", value: "x" }),
                    "expected 'updatePromiseResult' to be null or an object with a boolean 'isResolved' and string 'value' for action node snapshot"
                ],
                "a lotto node selected child": [
                    "root { lotto { action [Work] action [Work] } }",
                    (snapshot) => (snapshot.root.children[0].selectedChildIndex = 2),
                    "expected 'selectedChildIndex' to be null or the index of a child for lotto node snapshot"
                ]
            };

            for (const [name, [definition, corrupt, message]] of Object.entries(cases)) {
                it(name, () => {
                    const tree = new BehaviourTree(definition, { Work: () => State.RUNNING }, {});
                    tree.step();
                    const before = tree.snapshot();

                    const snapshot = roundTrip(before);
                    corrupt(snapshot);

                    assert.throws(() => tree.restore(snapshot), Error, `error restoring snapshot: ${message}`);
                    assert.deepEqual(tree.snapshot(), before);
                });
            }
        });

        describe("will error, leaving the tree as it was, if", () => {
            const definition = "root { sequence { action [Done] action [Busy] } }";
            const createTree = () =>
                new BehaviourTree(definition, { Done: () => State.SUCCEEDED, Busy: () => State.RUNNING }, {});

            const createValidSnapshot = () => {
                const tree = createTree();
                tree.step();
                return roundTrip(tree.snapshot());
            };

            const cases: { [name: string]: [(snapshot: any) => any, string] } = {
                "the snapshot is not an object": [() => "snapshot", "expected snapshot to be an object"],
                "the snapshot is null": [() => null, "expected snapshot to be an object"],
                "the snapshot has no definition": [
                    ({ version, root }) => ({ version, root }),
                    "expected snapshot to have a definition"
                ],
                "the snapshot has an unsupported version": [
                    (snapshot) => ({ ...snapshot, version: 2 }),
                    "unsupported snapshot version '2'"
                ],
                "the snapshot has no root node": [
                    ({ version, definition }) => ({ version, definition }),
                    "expected root node snapshot to be an object"
                ],
                "a node has a different type to the node in the tree": [
                    (snapshot) => {
                        snapshot.root.children[0].type = "selector";
                        return snapshot;
                    },
                    "expected snapshot of a sequence node but got selector"
                ],
                "a node has an invalid state": [
                    (snapshot) => {
                        snapshot.root.children[0].children[1].state = "invalid";
                        return snapshot;
                    },
                    "invalid node state 'invalid' for action node"
                ],
                "a node has the wrong number of children": [
                    (snapshot) => {
                        snapshot.root.children[0].children.pop();
                        return snapshot;
                    },
                    "expected 'children' array of length 2 for sequence node snapshot but got 1"
                ],
                "a node has no children defined": [
                    (snapshot) => {
                        delete snapshot.root.children;
                        return snapshot;
                    },
                    "expected 'children' array for root node snapshot"
                ]
            };

            for (const [name, [corrupt, message]] of Object.entries(cases)) {
                it(name, () => {
                    const tree = createTree();
                    tree.step();
                    const before = tree.snapshot();

                    assert.throws(
                        () => tree.restore(corrupt(createValidSnapshot())),
                        Error,
                        `error restoring snapshot: ${message}`
                    );
                    assert.deepEqual(tree.snapshot(), before);
                });
            }
        });

        describe("will error, leaving the tree as it was, if the input is not a snapshot", () => {
            const definition = "root { sequence { action [Done] action [Busy] } }";
            const createAgent = () => ({ Done: () => State.SUCCEEDED, Busy: () => State.RUNNING });

            const cases: { [name: string]: unknown } = {
                null: null,
                undefined: undefined,
                "a string": "snapshot",
                "a JSON string of a snapshot": JSON.stringify(
                    new BehaviourTree(definition, createAgent(), {}).snapshot()
                ),
                "a number": 42,
                "a boolean": true,
                "an array": [],
                "an array of a snapshot": [new BehaviourTree(definition, createAgent(), {}).snapshot()],
                "an empty object": {},
                "an object without the snapshot fields": { foo: "bar" },
                "an object with only a version": { version: 1 },
                "an object with only a root": {
                    root: new BehaviourTree(definition, createAgent(), {}).snapshot().root
                },
                "an object with a definition that is not a string": {
                    ...new BehaviourTree(definition, createAgent(), {}).snapshot(),
                    definition: 42
                }
            };

            for (const [name, input] of Object.entries(cases)) {
                it(name, () => {
                    const tree = new BehaviourTree(definition, createAgent(), {});
                    tree.step();
                    const before = tree.snapshot();
                    const detailsBefore = tree.getTreeNodeDetails();

                    assert.throws(() => tree.restore(input as BehaviourTreeSnapshot), Error);
                    assert.deepEqual(tree.snapshot(), before);
                    assert.deepEqual(tree.getTreeNodeDetails(), detailsBefore);
                });
            }
        });

        describe("checks the definition that the snapshot belongs to", () => {
            const agent = () => ({
                A: () => State.SUCCEEDED,
                B: () => State.RUNNING,
                C: () => State.RUNNING,
                G: () => true,
                E: () => {},
                X: () => {},
                S: () => {}
            });

            const snapshotOf = (definition: any) => {
                const tree = new BehaviourTree(definition, agent(), {});
                tree.step();
                return roundTrip(tree.snapshot());
            };

            describe("and will error, leaving the tree as it was, if the snapshot is of another definition that", () => {
                const mismatches: { [name: string]: [any, any] } = {
                    "calls a different function with the same structure": [
                        "root { sequence { action [A] action [B] } }",
                        "root { sequence { action [A] action [C] } }"
                    ],
                    "has different arguments": [
                        "root { sequence { action [A, 1] action [B] } }",
                        "root { sequence { action [A, 2] action [B] } }"
                    ],
                    "has different argument types": [
                        "root { sequence { action [A, 1] action [B] } }",
                        'root { sequence { action [A, "1"] action [B] } }'
                    ],
                    "has a different node type with the same structure": [
                        "root { sequence { action [A] action [B] } }",
                        "root { selector { action [A] action [B] } }"
                    ],
                    "has children in a different order": [
                        "root { sequence { action [A] action [B] } }",
                        "root { sequence { action [B] action [A] } }"
                    ],
                    "has an extra node": [
                        "root { sequence { action [A] action [B] } }",
                        "root { sequence { action [A] action [B] action [C] } }"
                    ],
                    "has a different repeat count": [
                        "root { repeat [2] { action [B] } }",
                        "root { repeat [3] { action [B] } }"
                    ],
                    "has a different wait duration": ["root { wait [100] }", "root { wait [200] }"],
                    "has a different lotto weighting": [
                        "root { lotto [1, 2] { action [B] action [B] } }",
                        "root { lotto [2, 1] { action [B] action [B] } }"
                    ],
                    "has a different attribute": ["root { action [B] entry(A) }", "root { action [B] exit(A) }"],
                    "has a different guard": ["root { action [B] while(G) }", "root { action [B] until(G) }"],
                    "has a different subtree": [
                        "root { branch [Sub] } root [Sub] { action [A] }",
                        "root { branch [Sub] } root [Sub] { action [B] }"
                    ],
                    "is a JSON definition of a different tree": [
                        { type: "root", child: { type: "action", call: "A" } },
                        { type: "root", child: { type: "action", call: "B" } }
                    ],
                    "is an MDSL definition of a different tree to a JSON definition": [
                        "root { action [A] }",
                        { type: "root", child: { type: "action", call: "B" } }
                    ]
                };

                for (const [name, [snapshotDefinition, treeDefinition]] of Object.entries(mismatches)) {
                    it(name, () => {
                        const snapshot = snapshotOf(snapshotDefinition);

                        const tree = new BehaviourTree(treeDefinition, agent(), {});
                        tree.step();
                        const before = tree.snapshot();
                        const detailsBefore = tree.getTreeNodeDetails();

                        assert.throws(
                            () => tree.restore(snapshot),
                            Error,
                            "error restoring snapshot: the snapshot does not match the tree's definition"
                        );
                        assert.deepEqual(tree.snapshot(), before);
                        assert.deepEqual(tree.getTreeNodeDetails(), detailsBefore);
                    });
                }
            });

            it("and does not call any agent functions or report node state changes when rejecting a snapshot", () => {
                const snapshot = snapshotOf("root { action [A] }");
                const calls: string[] = [];

                const tree = new BehaviourTree(
                    "root { action [B] }",
                    { A: () => calls.push("A"), B: () => calls.push("B") },
                    { onNodeStateChange: () => calls.push("change"), random: () => (calls.push("random"), 0.5) }
                );

                assert.throws(() => tree.restore(snapshot), Error);
                assert.deepEqual(calls, []);
            });

            it("and can still be stepped after rejecting a snapshot of another definition", async () => {
                const pending = new BehaviourTree(
                    "root { action [Work] }",
                    {
                        Work: () =>
                            new Promise<State.SUCCEEDED>((resolve) => setImmediate(() => resolve(State.SUCCEEDED)))
                    },
                    {}
                );
                pending.step();

                assert.throws(() => pending.restore(snapshotOf("root { action [A] }")), Error);

                // The promise that the tree is waiting on is not lost by the rejected restore.
                await new Promise((resolve) => setImmediate(resolve));
                pending.step();
                assert.strictEqual(pending.getState(), State.SUCCEEDED);
            });

            it("and restores a snapshot to a tree built with different options", () => {
                const definition = "root { sequence { action [A] action [B] } }";
                const snapshot = snapshotOf(definition);

                const tree = new BehaviourTree(definition, agent(), { random: () => 0.9 });
                tree.restore(snapshot);

                assert.deepEqual(tree.snapshot(), snapshot);
            });

            describe("and accepts the snapshot of an equivalent definition that", () => {
                const equivalents: { [name: string]: [any, any] } = {
                    "is the same MDSL": ["root { action [A] }", "root { action [A] }"],
                    "is MDSL with different whitespace and comments": [
                        "root { sequence { action [A] action [B] } }",
                        "root {\n  /* first */ sequence {\n    action [A]\n    action [B] /* second */\n  }\n}"
                    ],
                    "is the equivalent JSON": [
                        "root { sequence { action [A] action [B] } }",
                        {
                            type: "root",
                            child: {
                                type: "sequence",
                                children: [
                                    { type: "action", call: "A" },
                                    { type: "action", call: "B" }
                                ]
                            }
                        }
                    ],
                    "is the equivalent JSON with explicit empty arguments and keys in another order": [
                        "root { sequence { action [A] action [B] } }",
                        {
                            child: {
                                children: [
                                    { args: [], call: "A", type: "action" },
                                    { call: "B", type: "action", args: [] }
                                ],
                                type: "sequence"
                            },
                            type: "root"
                        }
                    ],
                    "is the equivalent JSON with arguments, attributes and guards": [
                        'root { sequence while(G, 1) entry(E) exit(X, "x") step(S, true, null) { action [A, 1, "two", false, null] } }',
                        {
                            type: "root",
                            child: {
                                type: "sequence",
                                while: { call: "G", args: [1] },
                                entry: { call: "E" },
                                exit: { call: "X", args: ["x"] },
                                step: { call: "S", args: [true, null] },
                                children: [{ type: "action", call: "A", args: [1, "two", false, null] }]
                            }
                        }
                    ],
                    "is the equivalent JSON with an explicit succeedOnAbort of false": [
                        "root { action [A] while(G) }",
                        {
                            type: "root",
                            child: { type: "action", call: "A", while: { call: "G", succeedOnAbort: false } }
                        }
                    ],
                    "is the equivalent JSON with undefined optional properties": [
                        "root { wait [100] }",
                        { type: "root", child: { type: "wait", duration: 100, while: undefined } }
                    ],
                    "is the equivalent JSON with subtrees in another order": [
                        "root { sequence { branch [One] branch [Two] } } root [One] { action [A] } root [Two] { action [B] }",
                        [
                            { type: "root", id: "Two", child: { type: "action", call: "B" } },
                            { type: "root", id: "One", child: { type: "action", call: "A" } },
                            {
                                type: "root",
                                child: {
                                    type: "sequence",
                                    children: [
                                        { type: "branch", ref: "One" },
                                        { type: "branch", ref: "Two" }
                                    ]
                                }
                            }
                        ]
                    ]
                };

                for (const [name, [snapshotDefinition, treeDefinition]] of Object.entries(equivalents)) {
                    it(`${name}, and restores it`, () => {
                        const snapshot = snapshotOf(snapshotDefinition);
                        const fromEquivalent = snapshotOf(treeDefinition);
                        assert.strictEqual(snapshot.definition, fromEquivalent.definition);

                        const tree = new BehaviourTree(treeDefinition, agent(), {});
                        tree.restore(snapshot);

                        assert.deepEqual(tree.snapshot(), snapshot);
                    });

                    it(`${name}, in the other direction`, () => {
                        const snapshot = snapshotOf(treeDefinition);

                        const tree = new BehaviourTree(snapshotDefinition, agent(), {});
                        tree.restore(snapshot);

                        assert.deepEqual(tree.snapshot(), snapshot);
                    });
                }
            });

            it("and records the same definition in snapshots taken at different times", () => {
                const tree = new BehaviourTree("root { sequence { action [A] action [B] } }", agent(), {});
                const first = tree.snapshot();
                tree.step();
                tree.step();

                assert.strictEqual(typeof first.definition, "string");
                assert.strictEqual(tree.snapshot().definition, first.definition);
            });
        });
    });
});
