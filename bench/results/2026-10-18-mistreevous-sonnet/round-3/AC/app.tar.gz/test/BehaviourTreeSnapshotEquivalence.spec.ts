import { assert } from "chai";
import sinon, { SinonFakeTimers } from "sinon";

import { BehaviourTree, BehaviourTreeSnapshot, State } from "../src/index";

import { withoutIds } from "./TestUtilities";

/**
 * The state of the world that an agent and a tree's options read from and write to. An application owns this
 * state, so it is copied rather than snapshotted, and a restored tree gets a copy taken at the same time as the snapshot.
 */
type World = {
    /** The number of times each agent function has been called. */
    calls: { [name: string]: number };
    /** The index of the next pseudo-random number to use. */
    randomIndex: number;
    /** A log of everything that happened to the agent and the tree since this was last cleared. */
    log: string[];
};

/**
 * A scenario to run, where each agent function is given the number of times it has been called, including this call.
 */
type Scenario = {
    definition: string;
    agentFunctions: { [name: string]: (callCount: number) => unknown };
    useDeltaTime?: boolean;
};

const RANDOM_NUMBERS = [0.13, 0.87, 0.42, 0.99, 0.01, 0.65, 0.31, 0.76, 0.5, 0.22];
const STEP_DURATION = 30;
const ONE_DAY = 24 * 60 * 60 * 1000;
const STEPS_BEFORE_SNAPSHOT = 22;
const STEPS_AFTER_SNAPSHOT = 22;

const createWorld = (): World => ({ calls: {}, randomIndex: 0, log: [] });

const copyWorld = (world: World): World => JSON.parse(JSON.stringify({ ...world, log: [] }));

/**
 * Create a tree, and the agent it models, where everything that either does is recorded in the world.
 */
const createTree = (scenario: Scenario, world: World): BehaviourTree => {
    const agent: { [name: string]: unknown } = {};

    for (const [name, agentFunction] of Object.entries(scenario.agentFunctions)) {
        agent[name] = (...args: unknown[]) => {
            world.calls[name] = (world.calls[name] ?? 0) + 1;
            world.log.push(`${name}(${args.join(",")}) #${world.calls[name]}`);
            return agentFunction(world.calls[name]);
        };
    }

    return new BehaviourTree(scenario.definition, agent, {
        random: () => RANDOM_NUMBERS[world.randomIndex++ % RANDOM_NUMBERS.length],
        getDeltaTime: scenario.useDeltaTime ? () => STEP_DURATION / 1000 : undefined,
        onNodeStateChange: ({ type, previousState, state }) => world.log.push(`${type}: ${previousState} -> ${state}`)
    });
};

/**
 * Step the tree, with a step duration passing before each one, and record what happened as a result of each step.
 */
const stepAndTrace = (clock: SinonFakeTimers, tree: BehaviourTree, world: World, steps: number) => {
    const trace = [];

    for (let step = 0; step < steps; step++) {
        world.log = [];
        clock.tick(STEP_DURATION);
        tree.step();

        trace.push({
            log: world.log,
            randomIndex: world.randomIndex,
            state: tree.getState(),
            details: withoutIds(tree.getTreeNodeDetails()),
            snapshot: tree.snapshot()
        });
    }

    return trace;
};

const everyThird = (state: State) => (callCount: number) => callCount % 3 === 0 ? state : undefined;
const everyOther = (state: State) => (callCount: number) => callCount % 2 === 0 ? state : undefined;

const scenarios: { [name: string]: Scenario } = {
    "sequence, selector and conditions": {
        definition: `root {
            sequence {
                action [Prepare]
                condition [Check]
                selector {
                    action [Unreliable]
                    action [Fallback]
                }
                action [Finish]
            }
        }`,
        agentFunctions: {
            Prepare: everyThird(State.SUCCEEDED),
            Check: (callCount) => callCount % 4 !== 0,
            Unreliable: (callCount) =>
                callCount % 5 === 0 ? State.SUCCEEDED : callCount % 2 ? State.FAILED : undefined,
            Fallback: everyOther(State.SUCCEEDED),
            Finish: () => State.SUCCEEDED
        }
    },
    "parallel, race and all": {
        definition: `root {
            sequence {
                parallel {
                    action [Slow]
                    action [Medium]
                }
                race {
                    action [Slow]
                    action [Medium]
                    action [Fast]
                }
                all {
                    action [Medium]
                    action [Fast]
                    sequence {
                        action [Fast]
                        action [Slow]
                    }
                }
            }
        }`,
        agentFunctions: {
            Slow: everyThird(State.SUCCEEDED),
            Medium: everyOther(State.SUCCEEDED),
            Fast: () => State.SUCCEEDED
        }
    },
    "repeat and retry with fixed and random counts": {
        definition: `root {
            sequence {
                repeat [3] { action [Work] }
                repeat [2, 5] { action [Work] }
                retry [3] { action [Flaky] }
                retry [2, 4] { action [Flaky] }
                action [Finish]
            }
        }`,
        agentFunctions: {
            Work: everyOther(State.SUCCEEDED),
            Flaky: (callCount) => (callCount % 7 === 0 ? State.SUCCEEDED : State.FAILED),
            Finish: () => State.SUCCEEDED
        }
    },
    "repeat and retry without counts, ended by other nodes": {
        definition: `root {
            sequence {
                race {
                    repeat { action [Work] }
                    wait [200]
                }
                race {
                    retry { action [Flaky] }
                    action [Quit]
                }
            }
        }`,
        agentFunctions: {
            Work: everyOther(State.SUCCEEDED),
            Flaky: (callCount) => (callCount % 9 === 0 ? State.SUCCEEDED : State.FAILED),
            Quit: everyThird(State.SUCCEEDED)
        }
    },
    "lotto with and without weights": {
        definition: `root {
            repeat [3] {
                sequence {
                    lotto {
                        action [A]
                        action [B]
                        action [C]
                    }
                    lotto [5, 1] {
                        action [A]
                        sequence {
                            action [B]
                            action [C]
                        }
                    }
                }
            }
        }`,
        agentFunctions: {
            A: everyOther(State.SUCCEEDED),
            B: everyThird(State.SUCCEEDED),
            C: (callCount) => (callCount % 2 ? undefined : State.FAILED)
        }
    },
    "wait using the clock": {
        definition: `root {
            sequence {
                wait [100]
                wait [60, 400]
                action [Work]
                wait [50, 250]
            }
        }`,
        agentFunctions: { Work: everyOther(State.SUCCEEDED) }
    },
    "wait using getDeltaTime": {
        definition: `root {
            sequence {
                wait [100]
                wait [60, 400]
                action [Work]
                wait [50, 250]
            }
        }`,
        agentFunctions: { Work: everyOther(State.SUCCEEDED) },
        useDeltaTime: true
    },
    "decorators and a branch": {
        definition: `
            root [Inner] {
                sequence {
                    action [Work]
                    flip { action [Flaky] }
                }
            }
            root {
                repeat [2] {
                    selector {
                        succeed { branch [Inner] }
                        fail { action [Work] }
                    }
                }
            }`,
        agentFunctions: {
            Work: everyOther(State.SUCCEEDED),
            Flaky: everyThird(State.FAILED)
        }
    },
    "guards and callbacks": {
        definition: `root {
            sequence {
                action [Work] entry(OnEntry, "work") step(OnStep) exit(OnExit)
                repeat [2] {
                    sequence while(StillGood) {
                        action [Work] until(Done)
                        wait [90] entry(OnEntry, "wait") exit(OnExit)
                    }
                }
                action [Work] while(Never)
            }
        }`,
        agentFunctions: {
            Work: everyThird(State.SUCCEEDED),
            StillGood: (callCount) => callCount < 12,
            Done: (callCount) => callCount % 7 === 0,
            Never: () => false,
            OnEntry: () => undefined,
            OnStep: () => undefined,
            OnExit: () => undefined
        }
    }
};

describe("A BehaviourTree instance restored from a snapshot", () => {
    let clock: SinonFakeTimers;

    beforeEach(() => {
        clock = sinon.useFakeTimers();
    });

    afterEach(() => {
        clock.restore();
    });

    for (const [name, scenario] of Object.entries(scenarios)) {
        describe(`for ${name}`, () => {
            it("behaves exactly as the tree that the snapshot was taken from, whenever it was taken", () => {
                for (let stepsBeforeSnapshot = 0; stepsBeforeSnapshot <= STEPS_BEFORE_SNAPSHOT; stepsBeforeSnapshot++) {
                    clock.setSystemTime(0);

                    // Run the original tree up to the point that the snapshot is taken.
                    const originalWorld = createWorld();
                    const original = createTree(scenario, originalWorld);
                    stepAndTrace(clock, original, originalWorld, stepsBeforeSnapshot);

                    // Some time passes after the last step, which a wait node has still waited for.
                    clock.tick(STEP_DURATION / 3);

                    const snapshot: BehaviourTreeSnapshot = JSON.parse(JSON.stringify(original.snapshot()));
                    const detailsAtSnapshot = withoutIds(original.getTreeNodeDetails());
                    const restoredWorld = copyWorld(originalWorld);
                    const randomIndexAtSnapshot = originalWorld.randomIndex;

                    // Carry on with the original tree.
                    const expected = stepAndTrace(clock, original, originalWorld, STEPS_AFTER_SNAPSHOT);

                    // Restore the snapshot some time later, none of which should count.
                    clock.tick(ONE_DAY);
                    const restored = createTree(scenario, restoredWorld);
                    restored.restore(snapshot);

                    assert.deepEqual(withoutIds(restored.getTreeNodeDetails()), detailsAtSnapshot);
                    assert.deepEqual(restoredWorld.log, []);
                    assert.strictEqual(restoredWorld.randomIndex, randomIndexAtSnapshot);

                    const actual = stepAndTrace(clock, restored, restoredWorld, STEPS_AFTER_SNAPSHOT);

                    assert.deepEqual(actual, expected, `snapshot after ${stepsBeforeSnapshot} steps`);
                }
            });
        });
    }
});
