import { BehaviourTree, NodeDetails } from "../src/index";
import { AnyNodeDefinition } from "../src/BehaviourTreeDefinition";

/**
 * Get the details for the specified node type and caption from the given behaviour tree instance, or error if it doesn't exist.
 * @param tree The behaviour tree instance.
 * @param type The type of the node to get.
 * @param name The name of the node to get.
 * @returns The details for the specified node type and caption from the given behaviour tree instance.
 */
export function findNode(tree: BehaviourTree, type: AnyNodeDefinition["type"], name?: string): NodeDetails {
    const findNodeFromDetails = (node: NodeDetails): NodeDetails | null => {
        if (node.type === type && (!name || node.name === name)) {
            return node;
        }

        return (node.children ?? []).map(findNodeFromDetails).find((childNode) => !!childNode) ?? null;
    };

    const targetNode = findNodeFromDetails(tree.getTreeNodeDetails());

    if (!targetNode) {
        throw new Error(
            name
                ? `cannot find flattened tree node with type: '${type}' caption: '${name}'`
                : `cannot find flattened tree node with type: '${type}'`
        );
    }

    return targetNode;
}

/**
 * Get a copy of the given node details with the randomly generated node ids removed, so that the details of nodes
 * from two different tree instances can be compared.
 * @param details The node details.
 * @returns A copy of the node details without ids.
 */
export function withoutIds(details: NodeDetails): object {
    const { id, children, ...rest } = details;

    return children ? { ...rest, children: children.map(withoutIds) } : rest;
}
