import { assert } from "chai";
import sinon, { SinonFakeTimers } from "sinon";

import { BehaviourTree, BehaviourTreeOptions, NodeDetails, State } from "../src/index";

/**
 * Creates an agent that logs every call. 'Work' keeps running until the agent is opened, 'Fail' always fails.
 */
const createAgent = (log: string[]) => {
    const agent = {
        open: false,
        Setup: () => (log.push("Setup"), State.SUCCEEDED),
        Teardown: () => (log.push("Teardown"), State.SUCCEEDED),
        Work: () => (log.push("Work"), agent.open ? State.SUCCEEDED : State.RUNNING),
        Fail: () => (log.push("Fail"), State.FAILED),
        IsOpen: () => agent.open
    };
    return agent;
};

/**
 * Strips the (random) node ids from tree node details so that details of two trees can be compared.
 */
const withoutIds = ({ id, children, ...details }: NodeDetails): any => ({
    ...details,
    ...(children ? { children: children.map(withoutIds) } : {})
});

/**
 * Builds a tree, steps it a number of times, and then builds a second tree from the same definition and restores it from a
 * JSON round-tripped snapshot of the first. Both trees have their own agent and call log.
 */
const forkTree = (
    definition: string,
    steps: number,
    options: (log: string[]) => BehaviourTreeOptions = () => ({}),
    restoredOptions: (log: string[]) => BehaviourTreeOptions = options
) => {
    const originalLog: string[] = [];
    const original = { agent: createAgent(originalLog), log: originalLog, tree: null as unknown as BehaviourTree };
    original.tree = new BehaviourTree(definition, original.agent, options(originalLog));
    for (let i = 0; i < steps; i++) {
        original.tree.step();
    }

    const snapshot = JSON.parse(JSON.stringify(original.tree.snapshot()));

    const restoredLog: string[] = [];
    const restored = { agent: createAgent(restoredLog), log: restoredLog, tree: null as unknown as BehaviourTree };
    restored.tree = new BehaviourTree(definition, restored.agent, restoredOptions(restoredLog));
    restored.tree.restore(snapshot);

    // Only what happens after the snapshot is of interest.
    originalLog.length = 0;

    return { original, restored, snapshot };
};

/**
 * Steps both trees and asserts that they stay in lockstep, calling the same agent functions and having the same node states.
 */
const stepBoth = (
    { original, restored }: ReturnType<typeof forkTree>,
    steps: number,
    beforeStep: (agent: ReturnType<typeof createAgent>, stepIndex: number) => void = () => {}
) => {
    for (let i = 0; i < steps; i++) {
        beforeStep(original.agent, i);
        beforeStep(restored.agent, i);
        original.tree.step();
        restored.tree.step();
        assert.deepEqual(restored.log, original.log, `agent calls differ after step ${i}`);
        assert.deepEqual(
            withoutIds(restored.tree.getTreeNodeDetails()),
            withoutIds(original.tree.getTreeNodeDetails())
        );
    }
};

describe("A behaviour tree snapshot", () => {
    let clock: SinonFakeTimers;

    beforeEach(() => {
        clock = sinon.useFakeTimers(1000);
    });

    afterEach(() => {
        clock.restore();
    });

    it("is a plain object that survives JSON serialisation unchanged", () => {
        const tree = new BehaviourTree(
            `root {
                sequence {
                    repeat [2,3] { action [Setup] }
                    retry [2,3] { action [Fail] }
                    lotto { action [Setup] action [Setup] }
                    parallel { race { all { condition [IsOpen] } } selector { flip { condition [IsOpen] } } }
                    succeed { fail { wait [100, 200] } }
                    action [Work]
                }
            }`,
            createAgent([]),
            { random: () => 0.5 }
        );
        for (let i = 0; i < 4; i++) {
            tree.step();
        }

        const snapshot = tree.snapshot();

        assert.deepEqual(JSON.parse(JSON.stringify(snapshot)), snapshot);
    });

    it("can be taken of a tree that has not been stepped", () => {
        const { restored, original } = forkTree("root { action [Work] }", 0);

        assert.deepEqual(
            withoutIds(restored.tree.getTreeNodeDetails()),
            withoutIds(original.tree.getTreeNodeDetails())
        );
        assert.strictEqual(restored.tree.getState(), State.READY);
    });

    describe("when restored", () => {
        it("sets the state of every node", () => {
            const fork = forkTree("root { sequence { action [Setup] parallel { action [Work] action [Setup] } } }", 2);

            assert.deepEqual(
                withoutIds(fork.restored.tree.getTreeNodeDetails()),
                withoutIds(fork.original.tree.getTreeNodeDetails())
            );
            assert.strictEqual(fork.restored.tree.getState(), State.RUNNING);
        });

        it("continues a sequence without calling the actions that already succeeded", () => {
            const fork = forkTree("root { sequence { action [Setup] action [Work] action [Teardown] } }", 3);

            stepBoth(fork, 2, (agent, i) => (agent.open = i === 1));

            assert.deepEqual(fork.restored.log, ["Work", "Work", "Teardown"]);
            assert.strictEqual(fork.restored.tree.getState(), State.SUCCEEDED);
        });

        it("continues a selector, race, all and parallel node with the children that were done or running", () => {
            for (const composite of ["selector", "race", "all", "parallel"]) {
                const fork = forkTree(
                    `root { ${composite} { action [Fail] action [Work] action [Setup] action [Work] } }`,
                    2
                );

                stepBoth(fork, 3, (agent, i) => (agent.open = i === 1));
            }
        });

        it("continues the iterations of a repeat node from where they were, using the random iteration count that was picked", () => {
            // The original picks 4 iterations, the restored tree's random function would have picked 1.
            const fork = forkTree(
                "root { repeat [1, 4] { action [Setup] } }",
                2,
                () => ({ random: () => 0.99 }),
                () => ({ random: () => 0 })
            );

            stepBoth(fork, 3);

            assert.deepEqual(fork.restored.log, ["Setup", "Setup"]);
            assert.strictEqual(fork.restored.tree.getState(), State.SUCCEEDED);
        });

        it("continues the attempts of a retry node from where they were, using the random attempt count that was picked", () => {
            const fork = forkTree(
                "root { retry [1, 4] { action [Fail] } }",
                2,
                () => ({ random: () => 0.99 }),
                () => ({ random: () => 0 })
            );

            stepBoth(fork, 3);

            assert.deepEqual(fork.restored.log, ["Fail", "Fail"]);
            assert.strictEqual(fork.restored.tree.getState(), State.FAILED);
        });

        it("keeps the child that a lotto node picked", () => {
            const fork = forkTree(
                "root { lotto { sequence { action [Work] action [Setup] } action [Teardown] } }",
                2,
                () => ({ random: () => 0 }),
                () => ({ random: () => 0.99 })
            );

            stepBoth(fork, 2, (agent, i) => (agent.open = i === 1));

            assert.deepEqual(fork.restored.log, ["Work", "Work", "Setup"]);
        });

        it("keeps the random duration that a wait node picked", () => {
            const fork = forkTree(
                "root { wait [100, 1000] }",
                1,
                () => ({ random: () => 0.99 }),
                () => ({ random: () => 0 })
            );

            clock.tick(500);
            stepBoth(fork, 1);
            assert.strictEqual(fork.restored.tree.getState(), State.RUNNING);

            clock.tick(500);
            stepBoth(fork, 1);
            assert.strictEqual(fork.restored.tree.getState(), State.SUCCEEDED);
        });

        it("makes a wait node wait only for the remaining time, however long the snapshot sat around", () => {
            const originalTree = new BehaviourTree("root { wait [1000] }", {});
            originalTree.step();
            clock.tick(400);
            originalTree.step();
            const snapshot = JSON.parse(JSON.stringify(originalTree.snapshot()));

            // Time passes in which the process is down.
            clock.tick(5 * 60 * 60 * 1000);

            const restoredTree = new BehaviourTree("root { wait [1000] }", {});
            restoredTree.restore(snapshot);
            restoredTree.step();
            assert.strictEqual(restoredTree.getState(), State.RUNNING);

            clock.tick(599);
            restoredTree.step();
            assert.strictEqual(restoredTree.getState(), State.RUNNING);

            clock.tick(1);
            restoredTree.step();
            assert.strictEqual(restoredTree.getState(), State.SUCCEEDED);
        });

        it("counts the time waited between the last step and the snapshot as waited", () => {
            const originalTree = new BehaviourTree("root { wait [1000] }", {});
            originalTree.step();
            clock.tick(900);
            const snapshot = JSON.parse(JSON.stringify(originalTree.snapshot()));

            clock.tick(100000);
            const restoredTree = new BehaviourTree("root { wait [1000] }", {});
            restoredTree.restore(snapshot);

            clock.tick(99);
            restoredTree.step();
            assert.strictEqual(restoredTree.getState(), State.RUNNING);

            clock.tick(1);
            restoredTree.step();
            assert.strictEqual(restoredTree.getState(), State.SUCCEEDED);
        });

        it("makes a wait node wait only for the remaining time when using 'getDeltaTime'", () => {
            const options = { getDeltaTime: () => 0.25 };
            const originalTree = new BehaviourTree("root { wait [1000] }", {}, options);
            originalTree.step();
            originalTree.step();
            const snapshot = JSON.parse(JSON.stringify(originalTree.snapshot()));

            clock.tick(100000);
            const restoredTree = new BehaviourTree("root { wait [1000] }", {}, options);
            restoredTree.restore(snapshot);

            // 500ms were waited, two more 250ms steps are left.
            restoredTree.step();
            assert.strictEqual(restoredTree.getState(), State.RUNNING);
            restoredTree.step();
            assert.strictEqual(restoredTree.getState(), State.SUCCEEDED);
        });

        it("keeps a wait node with no duration waiting", () => {
            const fork = forkTree("root { wait }", 2);

            clock.tick(100000);
            stepBoth(fork, 1);

            assert.strictEqual(fork.restored.tree.getState(), State.RUNNING);
        });

        it("restores a finished tree as finished, and the next step starts a new run that makes new random choices", () => {
            const fork = forkTree(
                "root { repeat [1, 4] { action [Setup] } }",
                5,
                () => ({ random: () => 0.99 }),
                () => ({ random: () => 0 })
            );
            assert.strictEqual(fork.restored.tree.getState(), State.SUCCEEDED);

            // The new run of the restored tree uses its own random function, which picks a single iteration.
            fork.restored.tree.step();
            fork.restored.tree.step();

            assert.deepEqual(fork.restored.log, ["Setup"]);
            assert.strictEqual(fork.restored.tree.getState(), State.SUCCEEDED);
        });

        it("restores a finished tree as finished without calling any agent functions", () => {
            const fork = forkTree("root { sequence { action [Setup] action [Fail] } }", 1);

            assert.strictEqual(fork.restored.tree.getState(), State.FAILED);
            assert.deepEqual(fork.restored.log, []);
        });

        it("replaces the state of a tree that has been stepped already", () => {
            const log: string[] = [];
            const tree = new BehaviourTree("root { sequence { action [Setup] action [Work] } }", createAgent(log));
            const fresh = tree.snapshot();
            tree.step();

            tree.restore(fresh);

            assert.strictEqual(tree.getState(), State.READY);
            assert.strictEqual(tree.getTreeNodeDetails().children![0].children![0].state, State.READY);
        });

        it("continues an action that settled its promise before the snapshot", async () => {
            const log: string[] = [];
            const definition = "root { sequence { action [Later] action [Setup] } }";
            const makeAgent = (calls: string[]) => ({
                ...createAgent(calls),
                Later: () => (calls.push("Later"), Promise.resolve(State.SUCCEEDED))
            });
            const original = new BehaviourTree(definition, makeAgent(log));
            original.step();
            await Promise.resolve();
            await Promise.resolve();

            const restoredLog: string[] = [];
            const restored = new BehaviourTree(definition, makeAgent(restoredLog));
            restored.restore(JSON.parse(JSON.stringify(original.snapshot())));
            restored.step();

            assert.deepEqual(restoredLog, ["Setup"]);
            assert.strictEqual(restored.getState(), State.SUCCEEDED);
        });

        it("can be done repeatedly from the same snapshot", () => {
            const fork = forkTree("root { sequence { action [Setup] action [Work] } }", 2);
            const again = new BehaviourTree("root { sequence { action [Setup] action [Work] } }", createAgent([]));

            again.restore(fork.snapshot);
            again.restore(fork.snapshot);

            assert.deepEqual(again.snapshot(), fork.snapshot);
        });
    });

    describe("when taken while an action is waiting on a promise", () => {
        const definition = "root { sequence { action [Later] action [Work] } }";

        const pendingTree = () => {
            const tree = new BehaviourTree(definition, { Later: () => new Promise<State.SUCCEEDED>(() => {}) });
            tree.step();
            return tree;
        };

        it("does not error, and leaves the tree as it was", () => {
            const tree = pendingTree();
            const before = withoutIds(tree.getTreeNodeDetails());

            tree.snapshot();

            assert.deepEqual(withoutIds(tree.getTreeNodeDetails()), before);
        });

        it("restores the action as not yet started, so its function is called again on the next step", () => {
            const snapshot = JSON.parse(JSON.stringify(pendingTree().snapshot()));
            const calls: string[] = [];
            const restored = new BehaviourTree(definition, {
                Later: () => (calls.push("Later"), State.SUCCEEDED),
                Work: () => (calls.push("Work"), State.SUCCEEDED)
            });

            restored.restore(snapshot);

            assert.strictEqual(restored.getTreeNodeDetails().children![0].children![0].state, State.READY);
            assert.strictEqual(restored.getState(), State.RUNNING);
            assert.deepEqual(calls, []);

            restored.step();

            assert.deepEqual(calls, ["Later", "Work"]);
            assert.strictEqual(restored.getState(), State.SUCCEEDED);
        });
    });

    describe("when restored with a snapshot of another definition", () => {
        const mdsl = "root { sequence { action [Setup] action [Work] } }";
        const stepped = (definition: any) => {
            const tree = new BehaviourTree(definition, createAgent([]));
            tree.step();
            return tree;
        };
        const message = "snapshot does not match the tree's definition";

        it("errors, even if the trees have the same shape", () => {
            const other = stepped("root { sequence { action [Setup] action [Teardown] } }");

            assert.throws(() => stepped(mdsl).restore(other.snapshot()), Error, message);
        });

        it("errors if the trees have a different shape", () => {
            const other = stepped("root { selector { action [Setup] } }");

            assert.throws(() => stepped(mdsl).restore(other.snapshot()), Error, message);
        });

        it("errors if only an argument or attribute differs", () => {
            const base = "root { sequence while(IsOpen) { action [Work, 1] } }";

            assert.throws(
                () => stepped(base).restore(stepped("root { sequence while(IsOpen) { action [Work, 2] } }").snapshot()),
                Error,
                message
            );
            assert.throws(
                () => stepped(base).restore(stepped("root { sequence until(IsOpen) { action [Work, 1] } }").snapshot()),
                Error,
                message
            );
        });

        it("leaves the tree exactly as it was", () => {
            const target = stepped(mdsl);
            const changes: string[] = [];
            const withCallback = new BehaviourTree(mdsl, createAgent([]), {
                onNodeStateChange: ({ state }) => changes.push(state)
            });
            withCallback.step();
            changes.length = 0;
            const before = withCallback.snapshot();
            const beforeDetails = withoutIds(withCallback.getTreeNodeDetails());
            const other = stepped("root { sequence { action [Setup] action [Teardown] } }").snapshot();

            assert.throws(() => withCallback.restore(other), Error, message);
            assert.throws(() => target.restore(other), Error, message);

            assert.deepEqual(withCallback.snapshot(), before);
            assert.deepEqual(withoutIds(withCallback.getTreeNodeDetails()), beforeDetails);
            assert.deepEqual(changes, []);
        });

        describe("that is equivalent", () => {
            const mdslDefinition = `root {
                sequence while(IsOpen) entry(Setup) {
                    repeat [2,3] { action [Work, 1, "x", true, null] }
                    wait [100]
                    branch [Sub]
                }
            }
            root [Sub] { selector { condition [IsOpen] flip { action [Fail] } } }`;

            // Leaves out the empty 'args' and 'succeedOnAbort: false' that the MDSL parser fills in.
            const jsonDefinition = [
                {
                    type: "root",
                    child: {
                        type: "sequence",
                        while: { call: "IsOpen" },
                        entry: { call: "Setup" },
                        children: [
                            {
                                type: "repeat",
                                iterations: [2, 3],
                                child: { type: "action", call: "Work", args: [1, "x", true, null] }
                            },
                            { type: "wait", duration: 100 },
                            { type: "branch", ref: "Sub" }
                        ]
                    }
                },
                {
                    id: "Sub",
                    type: "root",
                    child: {
                        children: [
                            { call: "IsOpen", type: "condition" },
                            { child: { call: "Fail", type: "action" }, type: "flip" }
                        ],
                        type: "selector"
                    }
                }
            ];

            it("restores from an MDSL definition to the equivalent JSON definition and back", () => {
                const fromMDSL = stepped(mdslDefinition).snapshot();
                const fromJSON = stepped(jsonDefinition).snapshot();

                assert.doesNotThrow(() => stepped(jsonDefinition).restore(fromMDSL));
                assert.doesNotThrow(() => stepped(mdslDefinition).restore(fromJSON));
            });

            it("restores a single root node object from the same definition as an array", () => {
                const root = { type: "root", child: { type: "action", call: "Work" } };

                assert.doesNotThrow(() => stepped([root]).restore(stepped(root).snapshot()));
                assert.doesNotThrow(() => stepped(root).restore(stepped("root { action [Work] }").snapshot()));
            });
        });
    });

    describe("when restored with something that is not a snapshot", () => {
        const target = () => {
            const tree = new BehaviourTree("root { action [Work] }", createAgent([]));
            tree.step();
            return tree;
        };

        [
            null,
            undefined,
            "snapshot",
            "",
            42,
            true,
            [],
            [target().snapshot()],
            {},
            { type: "root", state: State.READY }
        ].forEach((value) => {
            it(`errors for ${JSON.stringify(value)}, leaving the tree as it was`, () => {
                const tree = target();
                const before = tree.snapshot();

                assert.throws(() => tree.restore(value as any), Error);

                assert.deepEqual(tree.snapshot(), before);
            });
        });
    });

    describe("when restored with a snapshot that does not match the tree", () => {
        const tree = () => new BehaviourTree("root { sequence { action [Setup] action [Work] } }", createAgent([]));

        const tampered = (change: (snapshot: any) => void) => {
            const snapshot = JSON.parse(JSON.stringify(tree().snapshot()));
            change(snapshot);
            return snapshot;
        };

        it("errors if a node has a different type", () => {
            const snapshot = tampered((s) => (s.children[0].type = "selector"));

            assert.throws(() => tree().restore(snapshot), Error, "node type 'sequence' does not match 'selector'");
        });

        it("errors if a node has a different number of children", () => {
            const snapshot = tampered((s) => s.children[0].children.pop());

            assert.throws(() => tree().restore(snapshot), Error, "node has 2 children but snapshot has 1");
        });

        it("errors if the snapshot is not an object", () => {
            assert.throws(() => tree().restore(null as any), Error, "invalid snapshot");
            assert.throws(() => tree().restore("snapshot" as any), Error, "invalid snapshot");
        });

        it("errors if a node has an unknown state", () => {
            const snapshot = JSON.parse(JSON.stringify(tree().snapshot()));
            snapshot.state = "nonsense";

            assert.throws(() => tree().restore(snapshot), Error, "invalid snapshot state 'nonsense'");
        });

        it("leaves the tree as it was", () => {
            const target = tree();
            target.step();
            const before = target.snapshot();
            const bad = JSON.parse(JSON.stringify(before));
            bad.children[0].children[1].type = "condition";

            assert.throws(() => target.restore(bad), Error);

            assert.deepEqual(target.snapshot(), before);
        });
    });

    describe("when restored, regarding onNodeStateChange", () => {
        const definition = "root { sequence { action [Setup] action [Work] action [Teardown] } }";
        const changesOf = (changes: string[]) => ({
            onNodeStateChange: ({
                type,
                previousState,
                state
            }: {
                type: string;
                previousState: string;
                state: string;
            }) => changes.push(`${type} ${previousState}>${state}`)
        });

        it("is not called, whatever states the nodes are restored to", () => {
            const source = new BehaviourTree(definition, createAgent([]));
            source.step();
            const snapshot = JSON.parse(JSON.stringify(source.snapshot()));
            const changes: string[] = [];
            const target = new BehaviourTree(definition, createAgent([]), changesOf(changes));

            target.restore(snapshot);

            assert.deepEqual(changes, []);
            assert.strictEqual(target.getState(), State.RUNNING);
        });

        it("is called for the changes of the next step as usual", () => {
            const source = new BehaviourTree(definition, createAgent([]));
            source.step();
            const snapshot = JSON.parse(JSON.stringify(source.snapshot()));
            const changes: string[] = [];
            const agent = createAgent([]);
            agent.open = true;
            const target = new BehaviourTree(definition, agent, changesOf(changes));
            target.restore(snapshot);

            target.step();

            const { RUNNING: R, SUCCEEDED: S, READY: Y } = State;
            assert.deepEqual(changes, [`action ${R}>${S}`, `action ${Y}>${S}`, `sequence ${R}>${S}`, `root ${R}>${S}`]);
        });
    });

    describe("when taken, restored and stepped, regarding independence from the tree", () => {
        const definition = `root {
            sequence {
                action [Later]
                repeat [2,3] { action [Setup] }
                lotto { action [Setup] action [Setup] }
                wait [100, 200]
                action [Work]
            }
        }`;
        const makeAgent = () => ({ ...createAgent([]), Later: () => Promise.resolve(State.SUCCEEDED) });
        const json = (value: unknown) => JSON.parse(JSON.stringify(value));

        // Steps a tree until it is waiting, having had a settled promise result in the first action.
        const steppedTree = async () => {
            const tree = new BehaviourTree(definition, makeAgent(), { random: () => 0.5 });
            tree.step();
            await Promise.resolve();
            await Promise.resolve();
            for (let i = 0; i < 6; i++) tree.step();
            return tree;
        };

        it("leaves a snapshot unchanged when the tree it was taken from is stepped", async () => {
            const tree = await steppedTree();
            const snapshot = tree.snapshot();
            const before = json(snapshot);

            clock.tick(1000);
            tree.step();
            tree.step();
            tree.reset();
            tree.step();

            assert.deepEqual(json(snapshot), before);
        });

        it("leaves a snapshot unchanged when the tree it was restored to is stepped", async () => {
            const snapshot = (await steppedTree()).snapshot();
            const before = json(snapshot);
            const restored = new BehaviourTree(definition, makeAgent(), { random: () => 0.5 });

            restored.restore(snapshot);
            clock.tick(1000);
            restored.step();
            restored.step();
            restored.reset();
            restored.step();

            assert.deepEqual(json(snapshot), before);
        });

        it("equals the snapshot it was restored from when taken straight after the restore", async () => {
            const snapshot = json((await steppedTree()).snapshot());
            const restored = new BehaviourTree(definition, makeAgent(), { random: () => 0.5 });

            restored.restore(snapshot);

            assert.deepEqual(json(restored.snapshot()), snapshot);
        });
    });
});
