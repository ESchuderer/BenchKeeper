# Tree snapshot and restore

Status: ready-for-agent

## Goal

`BehaviourTree.snapshot()` returns the execution state as a plain JSON-safe object. `BehaviourTree.restore(snapshot)` applies it to a tree built from the same definition. The restored tree behaves as the original would have: same node states, same agent function calls in the same order, same result.

## Format

`TreeSnapshot = { version: 1; definition: string; root: NodeSnapshot }`

`definition` is the canonical JSON of the validated definition: object keys sorted, empty `args` and `succeedOnAbort: false` left out. An MDSL definition and its equivalent JSON definition give the same string.

`NodeSnapshot = { type, name, state, children?, ...per-type fields }`

| Node | Extra fields |
|---|---|
| repeat | `targetIterationCount` (number or null), `currentIterationCount` |
| retry | `targetAttemptCount` (number or null), `currentAttemptCount` |
| lotto | `selectedChild` (index or null) |
| wait | `totalDuration` (ms or null), `waitedDuration` (ms) |
| action | `promiseResult` (only while RUNNING and the promise has settled) |

Composite child progress is the children's states.

## Rules

- Wait: `waitedDuration` is the time waited at snapshot time (clock: `now - start`). Restore sets the start to `now - waitedDuration`, so time between snapshot and restore does not count. With `getDeltaTime`, `waitedDuration` is the accumulated value.
- Finished tree restores as finished. The next `step()` resets and draws new random values.
- Running action with a pending promise: `snapshot()` saves it as `READY` (not yet started). The restored tree calls the action function again on its next step. The live tree is not changed.
- `restore()` validates that the input is a snapshot (object, not an array, with `definition` and `root`), the version, that `definition` equals the tree's definition (message: the snapshot does not match the definition of the tree), then type, name, child count, state and field types, before changing anything. A mismatch throws an `Error` and leaves the tree unchanged.
- `restore()` does not call `onNodeStateChange`.
- Future `random()` results come from the `random` option, they are not part of the snapshot.

## Acceptance

- Tests in `test/` for each node type and for the tree.
- `npm test` passes.
- README documents the API with an example. Version History and package version updated.
