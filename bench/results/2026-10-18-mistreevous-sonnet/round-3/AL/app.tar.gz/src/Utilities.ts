/**
 * Create a randomly generated node uid.
 * @returns A randomly generated node uid.
 */
export function createUid(): string {
    const S4 = function () {
        return (((1 + Math.random()) * 0x10000) | 0).toString(16).substring(1);
    };
    return S4() + S4() + "-" + S4() + "-" + S4() + "-" + S4() + "-" + S4() + S4() + S4();
}

/**
 * Gets whether a value is a finite number that is not negative.
 * @param value The value to check.
 * @returns Whether the value is a finite number that is not negative.
 */
export function isNonNegativeNumber(value: unknown): value is number {
    return typeof value === "number" && isFinite(value) && value >= 0;
}

/**
 * Gets a string that is the same for every JSON definition with the same meaning, whatever its key order,
 * and whether it was converted from MDSL or written by hand, where empty 'args' and 'succeedOnAbort: false' may be left out.
 * @param definition The root node definitions of a tree.
 * @returns The canonical string of the definition.
 */
export function getCanonicalDefinition(definition: unknown): string {
    return JSON.stringify(definition, (key, value) => {
        if ((key === "args" && Array.isArray(value) && !value.length) || (key === "succeedOnAbort" && !value)) {
            return undefined;
        }

        return value && typeof value === "object" && !Array.isArray(value)
            ? Object.fromEntries(Object.entries(value).sort(([a], [b]) => (a < b ? -1 : 1)))
            : value;
    });
}
