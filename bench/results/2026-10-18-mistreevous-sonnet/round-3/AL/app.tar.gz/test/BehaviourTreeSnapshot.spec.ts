import { assert } from "chai";
import sinon, { SinonFakeTimers } from "sinon";

import { BehaviourTree, State, TreeSnapshot, NodeDetails } from "../src/index";
import { Agent } from "../src/Agent";

/**
 * Gets the snapshot of a tree after a trip through JSON.
 */
const roundTrip = (tree: BehaviourTree): TreeSnapshot => JSON.parse(JSON.stringify(tree.snapshot()));

/**
 * Gets the name and state of every node in a tree, without the instance-specific ids.
 */
const states = (tree: BehaviourTree): any => {
    const strip = ({ name, state, children }: NodeDetails): any => ({ name, state, children: children?.map(strip) });
    return strip(tree.getTreeNodeDetails());
};

/**
 * Creates an agent that logs every function call into the given array.
 * Actions return the next result queued for them, or stay running when none is left.
 */
const createAgent = (log: string[], results: { [action: string]: (State | undefined)[] } = {}): Agent => {
    const queues: { [action: string]: (State | undefined)[] } = {};
    for (const name of Object.keys(results)) {
        queues[name] = [...results[name]];
    }

    return new Proxy(
        {},
        {
            get: (_target, name: string) => () => {
                log.push(name);
                return queues[name]?.shift();
            }
        }
    ) as Agent;
};

/**
 * Steps a tree and returns the agent calls that were made.
 */
const stepAndLog = (tree: BehaviourTree, log: string[], steps: number): string[] => {
    const before = log.length;
    for (let i = 0; i < steps; i++) {
        tree.step();
    }
    return log.slice(before);
};

describe("A behaviour tree snapshot", () => {
    it("is a plain object that is unchanged by a trip through JSON", () => {
        const tree = new BehaviourTree(
            "root { sequence { repeat [2,3] { action [a] } wait [100,200] lotto { action [b] action [c] } } }",
            createAgent([])
        );

        tree.step();

        assert.deepEqual(roundTrip(tree), tree.snapshot());
    });

    it("can be taken from a tree that has not been stepped", () => {
        const tree = new BehaviourTree("root { action [a] }", createAgent([]));

        const restored = new BehaviourTree("root { action [a] }", createAgent([]));
        restored.step();
        restored.restore(roundTrip(tree));

        assert.deepEqual(states(restored), states(tree));
    });

    describe("restored into a new tree, leaves it behaving as the original tree would have", () => {
        const check = (definition: string, results: any, stepsBefore: number, stepsAfter: number, options = {}) => {
            const originalLog: string[] = [];
            const original = new BehaviourTree(definition, createAgent(originalLog, results), options);
            stepAndLog(original, originalLog, stepsBefore);
            const snapshot = roundTrip(original);

            // Queued action results are consumed by the original run, so only the remaining ones are left for the restored agent.
            const remaining: any = {};
            for (const name of Object.keys(results)) {
                remaining[name] = results[name].slice(originalLog.filter((call) => call === name).length);
            }
            const restoredAgentLog: string[] = [];
            const restoredTree = new BehaviourTree(definition, createAgent(restoredAgentLog, remaining), options);
            restoredTree.restore(snapshot);

            assert.deepEqual(states(restoredTree), states(original));

            for (let i = 0; i < stepsAfter; i++) {
                const originalCalls = stepAndLog(original, originalLog, 1);
                const restoredCalls = stepAndLog(restoredTree, restoredAgentLog, 1);
                assert.deepEqual(restoredCalls, originalCalls, `calls differ in step ${i + 1}`);
                assert.deepEqual(states(restoredTree), states(original), `states differ in step ${i + 1}`);
            }
        };

        const S = State.SUCCEEDED;
        const F = State.FAILED;

        it("(sequence)", () => {
            check(
                "root { sequence { action [a] action [b] action [c] } }",
                { a: [S], b: [undefined, S], c: [S] } as any,
                2,
                3
            );
        });

        it("(selector)", () => {
            check(
                "root { selector { action [a] action [b] action [c] } }",
                { a: [F], b: [undefined, F], c: [S] } as any,
                2,
                3
            );
        });

        it("(parallel)", () => {
            check(
                "root { parallel { action [a] action [b] action [c] } }",
                { a: [undefined, S], b: [S], c: [undefined, undefined, S] } as any,
                2,
                3
            );
        });

        it("(race)", () => {
            check(
                "root { race { action [a] action [b] } }",
                { a: [undefined, undefined, S], b: [undefined, F] } as any,
                1,
                3
            );
        });

        it("(all)", () => {
            check("root { all { action [a] action [b] } }", { a: [undefined, S], b: [F] } as any, 1, 3);
        });

        it("(repeat with a fixed count)", () => {
            check("root { repeat [3] { action [a] } }", { a: [S, S, S, S] } as any, 2, 4);
        });

        it("(infinite repeat)", () => {
            check(
                "root { repeat { sequence { action [a] action [b] } } }",
                { a: [S, S, S], b: [S, S, S] } as any,
                3,
                4
            );
        });

        it("(retry with a fixed count)", () => {
            check("root { retry [3] { action [a] } }", { a: [F, F, F, F] } as any, 2, 4);
        });

        it("(nested repeat and retry)", () => {
            check("root { repeat [2] { retry [3] { action [a] } } }", { a: [F, S, F, F, S, S] } as any, 3, 4);
        });

        it("(flip, succeed and fail)", () => {
            check(
                "root { sequence { flip { action [a] } succeed { action [b] } fail { action [c] } } }",
                { a: [F], b: [undefined, F], c: [S] } as any,
                2,
                3
            );
        });
    });

    describe("keeps random choices that were already made", () => {
        it("(repeat iteration count)", () => {
            const definition = "root { repeat [2,5] { action [a] } }";
            const results = {
                a: [
                    State.SUCCEEDED,
                    State.SUCCEEDED,
                    State.SUCCEEDED,
                    State.SUCCEEDED,
                    State.SUCCEEDED,
                    State.SUCCEEDED
                ]
            };

            // Picks 5 iterations.
            const original = new BehaviourTree(definition, createAgent([], results), { random: () => 0.99 });
            original.step();
            original.step();

            // Would pick 2 iterations if it chose again.
            const restoredLog: string[] = [];
            const restored = new BehaviourTree(definition, createAgent(restoredLog, results), { random: () => 0 });
            restored.restore(roundTrip(original));

            const calls = stepAndLog(restored, restoredLog, 3);
            assert.deepEqual(calls, ["a", "a", "a"]);
            assert.strictEqual(restored.getState(), State.RUNNING);
            restored.step();
            assert.strictEqual(restored.getState(), State.SUCCEEDED);
        });

        it("(retry attempt count)", () => {
            const definition = "root { retry [2,5] { action [a] } }";
            const results = { a: [State.FAILED, State.FAILED, State.FAILED, State.FAILED, State.FAILED, State.FAILED] };

            const original = new BehaviourTree(definition, createAgent([], results), { random: () => 0.99 });
            original.step();
            original.step();

            const restored = new BehaviourTree(definition, createAgent([], results), { random: () => 0 });
            restored.restore(roundTrip(original));

            restored.step();
            restored.step();
            assert.strictEqual(restored.getState(), State.RUNNING);
            restored.step();
            assert.strictEqual(restored.getState(), State.RUNNING);
            restored.step();
            assert.strictEqual(restored.getState(), State.FAILED);
        });

        it("(the child picked by a lotto)", () => {
            const definition = "root { lotto { action [a] action [b] action [c] } }";

            // Picks the last child.
            const original = new BehaviourTree(definition, createAgent([]), { random: () => 0.99 });
            original.step();

            // Would pick the first child if it chose again.
            const restoredLog: string[] = [];
            const restored = new BehaviourTree(definition, createAgent(restoredLog), { random: () => 0 });
            restored.restore(roundTrip(original));

            assert.deepEqual(stepAndLog(restored, restoredLog, 2), ["c", "c"]);
        });
    });

    describe("restores a wait node so that it waits only for the remaining time", () => {
        let clock: SinonFakeTimers;

        beforeEach(() => {
            clock = sinon.useFakeTimers();
        });

        afterEach(() => {
            clock.restore();
        });

        it("(clock)", () => {
            const original = new BehaviourTree("root { wait [1000] }", createAgent([]));
            original.step();
            clock.tick(300);
            original.step();

            const snapshot = roundTrip(original);

            // A long time passes between taking the snapshot and restoring it.
            clock.tick(1_000_000);

            const restored = new BehaviourTree("root { wait [1000] }", createAgent([]));
            restored.restore(snapshot);

            restored.step();
            assert.strictEqual(restored.getState(), State.RUNNING);

            clock.tick(699);
            restored.step();
            assert.strictEqual(restored.getState(), State.RUNNING);

            clock.tick(1);
            restored.step();
            assert.strictEqual(restored.getState(), State.SUCCEEDED);
        });

        it("(clock, time passing after the last step but before the snapshot)", () => {
            const original = new BehaviourTree("root { wait [1000] }", createAgent([]));
            original.step();
            clock.tick(400);

            const snapshot = roundTrip(original);
            clock.tick(1_000_000);

            const restored = new BehaviourTree("root { wait [1000] }", createAgent([]));
            restored.restore(snapshot);

            clock.tick(599);
            restored.step();
            assert.strictEqual(restored.getState(), State.RUNNING);

            clock.tick(1);
            restored.step();
            assert.strictEqual(restored.getState(), State.SUCCEEDED);
        });

        it("(getDeltaTime)", () => {
            let deltaTime = 0.1;
            const options = { getDeltaTime: () => deltaTime };

            const original = new BehaviourTree("root { wait [1000] }", createAgent([]), options);
            original.step();
            original.step();
            original.step();

            const snapshot = roundTrip(original);
            clock.tick(1_000_000);

            const restored = new BehaviourTree("root { wait [1000] }", createAgent([]), options);
            restored.restore(snapshot);

            // 300ms were waited, 600ms more is not enough.
            deltaTime = 0.1;
            for (let i = 0; i < 6; i++) {
                restored.step();
            }
            assert.strictEqual(restored.getState(), State.RUNNING);

            restored.step();
            assert.strictEqual(restored.getState(), State.SUCCEEDED);
        });

        it("(a random duration that was already picked)", () => {
            const definition = "root { wait [100,1000] }";

            // Picks a duration of 1000ms.
            const original = new BehaviourTree(definition, createAgent([]), { random: () => 0.9999 });
            original.step();
            clock.tick(500);
            original.step();

            // Would pick a duration of 100ms if it chose again.
            const restored = new BehaviourTree(definition, createAgent([]), { random: () => 0 });
            restored.restore(roundTrip(original));

            clock.tick(499);
            restored.step();
            assert.strictEqual(restored.getState(), State.RUNNING);

            clock.tick(1);
            restored.step();
            assert.strictEqual(restored.getState(), State.SUCCEEDED);
        });

        it("(a wait without a duration)", () => {
            const original = new BehaviourTree("root { wait }", createAgent([]));
            original.step();

            const restored = new BehaviourTree("root { wait }", createAgent([]));
            restored.restore(roundTrip(original));
            clock.tick(1_000_000);
            restored.step();

            assert.strictEqual(restored.getState(), State.RUNNING);
        });
    });

    describe("of a finished tree", () => {
        it("restores as finished, and the next step starts a new run with new random choices", () => {
            const definition = "root { repeat [1,3] { action [a] } }";
            const results = { a: [State.SUCCEEDED, State.SUCCEEDED, State.SUCCEEDED, State.SUCCEEDED] };

            // Picks 1 iteration.
            const original = new BehaviourTree(definition, createAgent([], results), { random: () => 0 });
            original.step();
            original.step();
            assert.strictEqual(original.getState(), State.SUCCEEDED);

            // Picks 3 iterations on a new run.
            const restoredLog: string[] = [];
            const restored = new BehaviourTree(definition, createAgent(restoredLog, results), { random: () => 0.99 });
            restored.restore(roundTrip(original));

            assert.strictEqual(restored.getState(), State.SUCCEEDED);
            assert.deepEqual(states(restored), states(original));

            restored.step();
            restored.step();
            restored.step();
            assert.strictEqual(restored.getState(), State.RUNNING);
            restored.step();
            assert.strictEqual(restored.getState(), State.SUCCEEDED);
            assert.deepEqual(restoredLog, ["a", "a", "a"]);
        });

        it("restores a failed tree as failed", () => {
            const original = new BehaviourTree("root { action [a] }", createAgent([], { a: [State.FAILED] }));
            original.step();

            const restored = new BehaviourTree("root { action [a] }", createAgent([]));
            restored.restore(roundTrip(original));

            assert.strictEqual(restored.getState(), State.FAILED);
        });
    });

    describe("when restored", () => {
        it("replaces the state of a tree that is already running", () => {
            const definition = "root { sequence { action [a] action [b] } }";
            const fresh = new BehaviourTree(definition, createAgent([]));

            const tree = new BehaviourTree(definition, createAgent([], { a: [State.SUCCEEDED] }));
            tree.step();
            tree.restore(roundTrip(fresh));

            assert.deepEqual(states(tree), states(fresh));
        });

        it("does not call the onNodeStateChange option", () => {
            const definition = "root { sequence { action [a] action [b] } }";
            const original = new BehaviourTree(definition, createAgent([], { a: [State.SUCCEEDED] }));
            original.step();

            const onNodeStateChange = sinon.spy();
            const restored = new BehaviourTree(definition, createAgent([]), { onNodeStateChange });
            restored.restore(roundTrip(original));

            sinon.assert.notCalled(onNodeStateChange);
        });

        it("errors and leaves the tree unchanged if the snapshot is for a different tree", () => {
            const original = new BehaviourTree("root { sequence { action [a] action [b] } }", createAgent([]));
            original.step();
            const snapshot = roundTrip(original);

            const mismatches = [
                "root { selector { action [a] action [b] } }",
                "root { sequence { action [a] } }",
                "root { sequence { action [a] action [c] } }"
            ];

            for (const definition of mismatches) {
                const tree = new BehaviourTree(definition, createAgent([], { a: [State.SUCCEEDED] }));
                tree.step();
                const before = states(tree);

                assert.throws(() => tree.restore(snapshot), Error, "cannot restore snapshot");
                assert.deepEqual(states(tree), before);
            }
        });

        it("errors and leaves the tree unchanged if the snapshot contains invalid values", () => {
            const definition = "root { sequence { action [a] repeat [3] { action [b] } } }";
            const original = new BehaviourTree(definition, createAgent([], { a: [State.SUCCEEDED] }));
            original.step();
            const valid = roundTrip(original) as any;

            const invalid: any[] = [
                null,
                {},
                { ...valid, version: 2 },
                { ...valid, root: null },
                { ...valid, root: { ...valid.root, state: "not a state" } },
                { ...valid, root: { ...valid.root, children: undefined } },
                {
                    ...valid,
                    root: {
                        ...valid.root,
                        children: [
                            {
                                ...valid.root.children[0],
                                children: [
                                    valid.root.children[0].children[0],
                                    { ...valid.root.children[0].children[1], currentIterationCount: "1" }
                                ]
                            }
                        ]
                    }
                }
            ];

            for (const snapshot of invalid) {
                const tree = new BehaviourTree(definition, createAgent([]));
                const before = states(tree);

                assert.throws(() => tree.restore(snapshot), Error, "cannot restore snapshot");
                assert.deepEqual(states(tree), before);
            }
        });
    });

    describe("records the definition of its tree", () => {
        const mdsl =
            'root [sub] { action [z] } root { sequence while(x, 1) entry(e) { action [a, 1, "s", null] wait [100] wait [1, 2] repeat [3] { condition [c] } lotto [1, 2] { action [d] action [e] } branch [sub] } }';
        const json = [
            { type: "root", id: "sub", child: { type: "action", call: "z" } },
            {
                type: "root",
                child: {
                    entry: { call: "e" },
                    while: { call: "x", args: [1] },
                    type: "sequence",
                    children: [
                        { type: "action", call: "a", args: [1, "s", null] },
                        { type: "wait", duration: 100 },
                        { type: "wait", duration: [1, 2] },
                        { type: "repeat", iterations: 3, child: { type: "condition", call: "c" } },
                        {
                            type: "lotto",
                            weights: [1, 2],
                            children: [
                                { type: "action", call: "d" },
                                { type: "action", call: "e" }
                            ]
                        },
                        { type: "branch", ref: "sub" }
                    ]
                }
            }
        ];

        it("so that a snapshot restores to a tree of the equivalent MDSL or JSON definition", () => {
            for (const [from, to] of [
                [mdsl, json],
                [json, mdsl],
                ["root { action [a] }", { type: "root", child: { call: "a", type: "action", args: [] } }],
                [
                    { type: "root", child: { type: "action", call: "a" } },
                    [{ child: { call: "a", type: "action" }, type: "root" }]
                ]
            ] as any[]) {
                const original = new BehaviourTree(from, createAgent([]));
                const restored = new BehaviourTree(to, createAgent([]));

                restored.restore(roundTrip(original));

                assert.deepEqual(states(restored), states(original));
            }
        });

        it("so that a snapshot is rejected by a tree of another definition, even with the same structure", () => {
            const pairs = [
                ["root { wait [100] }", "root { wait [200] }"],
                ["root { action [a, 1] }", "root { action [a, 2] }"],
                ["root { sequence { action [a] } }", "root { sequence entry(e) { action [a] } }"],
                ["root { repeat [3] { action [a] } }", "root { repeat [4] { action [a] } }"]
            ];

            for (const [from, to] of pairs) {
                const snapshot = roundTrip(new BehaviourTree(from, createAgent([])));

                const tree = new BehaviourTree(to, createAgent([]));
                tree.step();
                const control = new BehaviourTree(to, createAgent([]));
                control.step();
                const before = states(tree);

                assert.throws(() => tree.restore(snapshot), Error, /does not match.*definition/);
                assert.deepEqual(states(tree), before);

                tree.step();
                control.step();
                assert.deepEqual(states(tree), states(control));
            }
        });
    });

    describe("restore", () => {
        it("rejects input that is not a snapshot and leaves the tree unchanged", () => {
            const definition = "root { sequence { action [a] action [b] } }";
            const valid = roundTrip(new BehaviourTree(definition, createAgent([]))) as any;
            const { definition: _definition, ...withoutDefinition } = valid;

            const notSnapshots: any[] = [
                undefined,
                null,
                "snapshot",
                5,
                true,
                [],
                [valid],
                {},
                { version: 1 },
                { version: 1, definition: valid.definition },
                { version: 1, root: valid.root },
                withoutDefinition,
                { ...valid, definition: 5 },
                { ...valid, definition: null }
            ];

            for (const input of notSnapshots) {
                const tree = new BehaviourTree(definition, createAgent([], { a: [State.SUCCEEDED] }));
                tree.step();
                const before = states(tree);

                assert.throws(() => tree.restore(input), Error, "cannot restore snapshot");
                assert.deepEqual(states(tree), before);
            }
        });
    });

    describe("of a tree with an action that is waiting on a promise", () => {
        const createPromiseAgent = (promise: Promise<any>): Agent => ({ a: () => promise } as any);

        it("restores an action whose promise has not settled as not yet started", () => {
            const definition = "root { sequence { action [a] action [b] } }";
            const original = new BehaviourTree(definition, createPromiseAgent(new Promise(() => {})));
            original.step();

            const snapshot = roundTrip(original);

            assert.strictEqual(snapshot.root.children![0].children![0].state, State.READY);

            const log: string[] = [];
            const restored = new BehaviourTree(definition, createAgent(log, { a: [State.SUCCEEDED] }));
            restored.restore(snapshot);

            assert.deepEqual(stepAndLog(restored, log, 1), ["a", "b"]);
        });

        it("does not change the tree that the snapshot was taken from", async () => {
            const log: string[] = [];
            const promise = Promise.resolve(State.SUCCEEDED);
            const tree = new BehaviourTree("root { sequence { action [a] action [b] } }", {
                a: () => (log.push("a"), promise),
                b: () => (log.push("b"), State.SUCCEEDED)
            } as any);
            tree.step();
            tree.snapshot();

            assert.strictEqual(tree.getState(), State.RUNNING);

            await promise;
            tree.step();

            assert.deepEqual(log, ["a", "b"]);
            assert.strictEqual(tree.getState(), State.SUCCEEDED);
        });

        it("keeps the result of a promise that has settled", async () => {
            for (const [promise, expected] of [
                [Promise.resolve(State.SUCCEEDED), State.SUCCEEDED],
                [Promise.resolve(State.FAILED), State.FAILED]
            ] as const) {
                const tree = new BehaviourTree("root { action [a] }", createPromiseAgent(promise));
                tree.step();
                await promise;

                const calls: string[] = [];
                const restored = new BehaviourTree("root { action [a] }", { a: () => calls.push("a") } as any);
                restored.restore(roundTrip(tree));
                restored.step();

                assert.strictEqual(restored.getState(), expected);
                assert.deepEqual(calls, []);
            }
        });

        it("keeps the reason of a promise that was rejected", async () => {
            const promise = Promise.reject("it broke");
            const tree = new BehaviourTree("root { action [a] }", createPromiseAgent(promise));
            tree.step();
            await promise.catch(() => {});

            const restored = new BehaviourTree("root { action [a] }", createPromiseAgent(new Promise(() => {})));
            restored.restore(roundTrip(tree));

            assert.throws(() => restored.step(), Error, "action function 'a' promise rejected with 'it broke'");
        });

        it("can be taken once the promise has been handled", async () => {
            const promise = Promise.resolve(State.SUCCEEDED);
            const tree = new BehaviourTree("root { action [a] }", createPromiseAgent(promise));
            tree.step();
            await promise;
            tree.step();

            assert.strictEqual(tree.getState(), State.SUCCEEDED);
            assert.strictEqual(roundTrip(tree).root.state, State.SUCCEEDED);
        });
    });

    describe("regressions for restore and independence", () => {
        let clock: SinonFakeTimers;

        beforeEach(() => {
            clock = sinon.useFakeTimers();
        });

        afterEach(() => {
            clock.restore();
        });

        const definition =
            "root { sequence { repeat [2] { sequence { wait [100] lotto { action [a] action [b] } } } retry [2] { action [p] } } }";

        const createTree = (options = {}): BehaviourTree =>
            new BehaviourTree(
                definition,
                { a: () => State.SUCCEEDED, b: () => State.SUCCEEDED, p: () => Promise.resolve(State.FAILED) } as any,
                options
            );

        const run = async (tree: BehaviourTree, steps: number): Promise<BehaviourTree> => {
            for (let i = 0; i < steps; i++) {
                tree.step();
                clock.tick(60);
                await Promise.resolve();
            }
            return tree;
        };

        it("restore does not call onNodeStateChange over a tree in another state, and the next step does", async () => {
            const snapshot = roundTrip(await run(createTree(), 4));

            const onNodeStateChange = sinon.spy();
            const tree = await run(createTree({ onNodeStateChange }), 1);
            onNodeStateChange.resetHistory();

            tree.restore(snapshot);
            sinon.assert.notCalled(onNodeStateChange);

            await run(tree, 3);
            sinon.assert.called(onNodeStateChange);
        });

        it("a snapshot is not changed by stepping the tree it was taken from", async () => {
            const tree = await run(createTree(), 3);
            const snapshot = tree.snapshot();
            const before = JSON.stringify(snapshot);

            await run(tree, 4);

            assert.strictEqual(JSON.stringify(snapshot), before);
        });

        it("a snapshot is not changed by stepping a tree it was restored into", async () => {
            const snapshot = roundTrip(await run(createTree(), 3));
            const before = JSON.stringify(snapshot);

            const restored = createTree();
            restored.restore(snapshot);
            await run(restored, 4);

            assert.strictEqual(JSON.stringify(snapshot), before);
        });

        it("a snapshot taken straight after a restore equals the snapshot that was restored", async () => {
            for (let steps = 0; steps < 8; steps++) {
                const snapshot = roundTrip(await run(createTree(), steps));

                const restored = createTree();
                restored.restore(snapshot);

                assert.deepEqual(roundTrip(restored), snapshot, `after ${steps} steps`);
            }
        });
    });
});
