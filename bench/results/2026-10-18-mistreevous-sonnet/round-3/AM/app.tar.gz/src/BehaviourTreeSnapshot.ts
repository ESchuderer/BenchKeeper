import { AnyState } from "./State";

/**
 * A plain object representing the execution state of a node and its children, that can be serialised as JSON.
 * Only the properties relevant to the type of the node are defined.
 */
export type BehaviourTreeSnapshot = {
    /**
     * The tree node type.
     */
    type: string;
    /**
     * The state of the tree node.
     */
    state: AnyState;
    /**
     * The snapshots of the child nodes, defined if the node is a composite or decorator node.
     */
    children?: BehaviourTreeSnapshot[];
    /**
     * The fingerprint of the definition of the tree, defined on the snapshot of the root node only.
     */
    definition?: string;
    /**
     * The number of iterations completed, defined if the node is a repeat node.
     */
    currentIterationCount?: number;
    /**
     * The number of iterations to make, or null for no limit, defined if the node is a repeat node.
     */
    targetIterationCount?: number | null;
    /**
     * The number of attempts made, defined if the node is a retry node.
     */
    currentAttemptCount?: number;
    /**
     * The number of attempts to make, or null for no limit, defined if the node is a retry node.
     */
    targetAttemptCount?: number | null;
    /**
     * The index of the child picked to run, or null if none was picked yet, defined if the node is a lotto node.
     */
    selectedChildIndex?: number | null;
    /**
     * The duration in milliseconds to wait for, or null to wait indefinitely, defined if the node is a wait node.
     */
    totalDuration?: number | null;
    /**
     * The duration in milliseconds that has been waited for, defined if the node is a wait node.
     */
    waitedDuration?: number;
};

/**
 * Throws an error describing an invalid snapshot of the given node type.
 * @param type The type of the node with the invalid snapshot.
 * @param reason The reason that the snapshot is invalid.
 */
export function throwInvalidSnapshot(type: string, reason: string): never {
    throw new Error(`invalid snapshot: ${reason} for ${type} node`);
}

/**
 * Gets whether a value is a non-negative integer.
 */
export const isCount = (value: unknown): value is number => Number.isInteger(value) && (value as number) >= 0;

/**
 * Gets whether a value is a finite non-negative number.
 */
export const isDuration = (value: unknown): value is number =>
    typeof value === "number" && Number.isFinite(value) && value >= 0;
