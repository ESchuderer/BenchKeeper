import { assert } from "chai";
import sinon, { SinonFakeTimers } from "sinon";

import { BehaviourTree, BehaviourTreeOptions, BehaviourTreeSnapshot, NodeDetails, State } from "../src/index";

/**
 * The context shared by the agents of the reference tree and its restored copies.
 */
type Context = { step: number; log: string[] };

/**
 * Creates an agent whose functions only depend on the context step, so that a restored tree sees the same agent as the original.
 */
const createAgent = (context: Context) => ({
    work: (id: string, every: number) => {
        context.log.push(`work ${id}`);
        return context.step % every === 0 ? State.SUCCEEDED : undefined;
    },
    flaky: (id: string, every: number) => {
        context.log.push(`flaky ${id}`);
        return context.step % every === 0 ? State.SUCCEEDED : State.FAILED;
    },
    isEven: (id: string) => {
        context.log.push(`isEven ${id}`);
        return context.step % 2 === 0;
    },
    go: () => context.step < 20,
    onEntry: (...args: any[]) => context.log.push(`entry ${args[args.length - 1]}`),
    onExit: (...args: any[]) => context.log.push(`exit ${args[args.length - 1]}`)
});

const flattenStates = (details: NodeDetails): string[] => [
    `${details.type} ${details.name} ${details.state}`,
    ...(details.children ?? []).flatMap(flattenStates)
];

const definitions: Record<string, string> = {
    "sequence and selector": `root { sequence { action [work, "a", 2] selector { action [flaky, "b", 3] action [work, "c", 2] } wait [250] action [work, "d", 3] } }`,
    parallel: `root { parallel { sequence { action [work, "p1", 3] action [work, "p2", 2] } action [work, "p3", 5] } }`,
    race: `root { race { sequence { action [work, "r1", 4] action [work, "r2", 2] } action [work, "r3", 5] } }`,
    all: `root { all { sequence { action [work, "a1", 3] action [flaky, "a2", 2] } action [work, "a3", 5] } }`,
    repeat: `root { sequence { repeat [3] { sequence { action [work, "r", 2] condition [isEven, "c"] } } action [work, "after", 2] } }`,
    "random repeat": `root { repeat [2, 5] { action [work, "x", 2] } }`,
    retry: `root { sequence { retry [3] { action [flaky, "f", 4] } action [work, "after", 2] } }`,
    "random retry": `root { retry [2, 5] { action [flaky, "x", 7] } }`,
    lotto: `root { repeat [4] { lotto [1, 2, 3] { action [work, "l1", 3] sequence { action [work, "l2", 2] wait [120] } action [work, "l3", 2] } } }`,
    "lotto that a guard stopped before it picked a child": `root { repeat { selector { lotto while(isEven, "g") { action [work, "l1", 3] action [work, "l2", 2] } action [work, "fb", 2] } } }`,
    "random wait": `root { repeat [3] { sequence { action [work, "w", 2] wait [150, 450] } } }`,
    "decorators, guards and callbacks": `root { selector while(go) entry(onEntry, "sel") exit(onExit, "sel") { fail { action [work, "x", 2] } succeed { flip { action [work, "y", 3] } } } }`
};

describe("A BehaviourTree", () => {
    let clock: SinonFakeTimers;

    beforeEach(() => {
        clock = sinon.useFakeTimers();
    });

    afterEach(() => {
        clock.restore();
    });

    describe("snapshot", () => {
        it("survives JSON.stringify and JSON.parse unchanged", () => {
            const tree = new BehaviourTree(definitions["random wait"], createAgent({ step: 0, log: [] }));
            tree.step();

            const snapshot = tree.snapshot();

            assert.deepEqual(JSON.parse(JSON.stringify(snapshot)), snapshot);
            assert.strictEqual(snapshot.type, "root");
            assert.strictEqual(snapshot.state, State.RUNNING);
        });

        it("can be taken from a tree that was never stepped", () => {
            const snapshot = new BehaviourTree('root { action [work, "a", 1] }', {}).snapshot();

            assert.deepEqual(JSON.parse(JSON.stringify(snapshot)), snapshot);
            assert.strictEqual(snapshot.state, State.READY);
        });

        it("is a copy that does not change when the tree is stepped", () => {
            const context = { step: 0, log: [] };
            const tree = new BehaviourTree(definitions["repeat"], createAgent(context));
            tree.step();
            const before = JSON.stringify(tree.snapshot());
            const snapshot = tree.snapshot();

            context.step = 2;
            tree.step();

            assert.strictEqual(JSON.stringify(snapshot), before);
        });

        it("records the definition of the tree", () => {
            const snapshot = new BehaviourTree("root { wait [1] }", {}).snapshot();

            assert.isString(snapshot.definition);
            assert.strictEqual(snapshot.definition, new BehaviourTree("root { wait [1] }", {}).snapshot().definition);
            assert.notStrictEqual(
                snapshot.definition,
                new BehaviourTree("root { wait [2] }", {}).snapshot().definition
            );
        });

        it("can be taken while an action node is waiting for a promise, without changing the tree", async () => {
            let resolve: (state: State) => void = () => {};
            const tree = new BehaviourTree("root { action [wait] }", {
                wait: () => new Promise<State>((r) => (resolve = r))
            });
            tree.step();

            assert.doesNotThrow(() => tree.snapshot());
            assert.strictEqual(tree.getTreeNodeDetails().children![0].state, State.RUNNING);

            resolve(State.SUCCEEDED);
            await Promise.resolve();
            tree.step();

            assert.strictEqual(tree.getState(), State.SUCCEEDED);
        });
    });

    describe("restore", () => {
        Object.entries(definitions).forEach(([name, definition]) => {
            const timings: [string, BehaviourTreeOptions][] = [
                ["the clock", {}],
                ["getDeltaTime", { getDeltaTime: () => 0.1 }]
            ];
            timings.forEach(([timing, timingOptions]) => {
                it(`makes a tree behave as the original did at every step for '${name}' using ${timing}`, () => {
                    const random = (index: number) => ((index * 7919 + 13) % 1000) / 1000;
                    const stepCount = 30;

                    // Run the reference tree, taking a snapshot after each step.
                    const referenceContext: Context = { step: 0, log: [] };
                    let randomCalls = 0;
                    const reference = new BehaviourTree(definition, createAgent(referenceContext), {
                        ...timingOptions,
                        random: () => random(randomCalls++)
                    });
                    const trace: { log: string[]; states: string[] }[] = [];
                    const snapshots: { snapshot: string; randomCalls: number }[] = [];
                    for (let step = 1; step <= stepCount; step++) {
                        referenceContext.step = step;
                        referenceContext.log = [];
                        clock.tick(100);
                        reference.step();
                        trace.push({
                            log: referenceContext.log,
                            states: flattenStates(reference.getTreeNodeDetails())
                        });
                        snapshots.push({ snapshot: JSON.stringify(reference.snapshot()), randomCalls });
                    }

                    // Restore each snapshot, long after it was taken, and replay the remaining steps.
                    for (let taken = 1; taken < stepCount; taken++) {
                        const context: Context = { step: taken, log: [] };
                        let calls = snapshots[taken - 1].randomCalls;
                        const restored = new BehaviourTree(definition, createAgent(context), {
                            ...timingOptions,
                            random: () => random(calls++)
                        });

                        clock.tick(1000 * 60 * 60 * 24);
                        restored.restore(JSON.parse(snapshots[taken - 1].snapshot));

                        assert.deepEqual(flattenStates(restored.getTreeNodeDetails()), trace[taken - 1].states);
                        assert.strictEqual(JSON.stringify(restored.snapshot()), snapshots[taken - 1].snapshot);

                        for (let step = taken + 1; step <= stepCount; step++) {
                            context.step = step;
                            context.log = [];
                            clock.tick(100);
                            restored.step();

                            assert.deepEqual(context.log, trace[step - 1].log, `calls at step ${step} from ${taken}`);
                            assert.deepEqual(
                                flattenStates(restored.getTreeNodeDetails()),
                                trace[step - 1].states,
                                `states at step ${step} from ${taken}`
                            );
                        }
                    }
                });
            });
        });

        [
            ["repeat", 'root { repeat [1, 5] { action [work, "r", 1] } }'],
            ["retry", 'root { retry [1, 5] { action [flaky, "f", 99] } }']
        ].forEach(([type, definition]) => {
            it(`keeps the random ${type} count that was already chosen`, () => {
                const stepsToFinish = (tree: BehaviourTree, context: Context) => {
                    let steps = 0;
                    while (tree.getState() !== State.SUCCEEDED && tree.getState() !== State.FAILED) {
                        context.step += 1;
                        tree.step();
                        steps++;
                    }
                    return steps;
                };
                const context: Context = { step: 1, log: [] };
                const tree = new BehaviourTree(definition, createAgent(context), { random: () => 0.99 });
                tree.step();
                const snapshot = JSON.parse(JSON.stringify(tree.snapshot()));

                const restoredContext: Context = { step: 1, log: [] };
                const restored = new BehaviourTree(definition, createAgent(restoredContext), { random: () => 0 });
                restored.restore(snapshot);

                assert.strictEqual(stepsToFinish(restored, restoredContext), stepsToFinish(tree, context));
            });
        });

        it("makes a restored lotto node keep running the child it picked", () => {
            const definition = 'root { lotto { action [work, "a", 99] action [work, "b", 99] } }';
            const context = { step: 1, log: [] };
            const tree = new BehaviourTree(definition, createAgent(context), { random: () => 0.9 });
            tree.step();
            const snapshot = JSON.parse(JSON.stringify(tree.snapshot()));

            context.log = [];
            const restored = new BehaviourTree(definition, createAgent(context), { random: () => 0 });
            restored.restore(snapshot);
            restored.step();

            assert.deepEqual(context.log, ["work b"]);
        });

        it("makes a restored wait node wait only for the remaining time", () => {
            const tree = new BehaviourTree("root { wait [1000] }", {});
            tree.step();
            clock.tick(400);
            tree.step();
            clock.tick(300);
            const snapshot = JSON.parse(JSON.stringify(tree.snapshot()));

            clock.tick(1000 * 60 * 60 * 10);
            const restored = new BehaviourTree("root { wait [1000] }", {});
            restored.restore(snapshot);
            clock.tick(299);
            restored.step();
            assert.strictEqual(restored.getState(), State.RUNNING);

            clock.tick(1);
            restored.step();
            assert.strictEqual(restored.getState(), State.SUCCEEDED);
        });

        it("makes a restored wait node ignore the time between the snapshot and the restore with 'getDeltaTime'", () => {
            const options = { getDeltaTime: () => 0.25 };
            const tree = new BehaviourTree("root { wait [1000] }", {}, options);
            tree.step();
            tree.step();
            const snapshot = JSON.parse(JSON.stringify(tree.snapshot()));

            clock.tick(1000 * 60 * 60 * 10);
            const restored = new BehaviourTree("root { wait [1000] }", {}, options);
            restored.restore(snapshot);
            restored.step();
            assert.strictEqual(restored.getState(), State.RUNNING);
            restored.step();
            assert.strictEqual(restored.getState(), State.SUCCEEDED);
        });

        it("keeps a wait node that waits indefinitely", () => {
            const tree = new BehaviourTree("root { wait }", {});
            tree.step();
            const restored = new BehaviourTree("root { wait }", {});
            restored.restore(JSON.parse(JSON.stringify(tree.snapshot())));

            clock.tick(100000);
            restored.step();

            assert.strictEqual(restored.getState(), State.RUNNING);
        });

        [State.SUCCEEDED, State.FAILED].forEach((outcome) => {
            it(`restores a finished tree as finished and starts a new run, drawing random choices again, on the next step (${outcome})`, () => {
                const definition =
                    "root { sequence { lotto { action [work] action [work] } wait [10, 20] condition [isOutcome] } }";
                const agent = { work: () => State.SUCCEEDED, isOutcome: () => outcome === State.SUCCEEDED };
                const tree = new BehaviourTree(definition, agent, { random: () => 0.5 });
                while (tree.getState() !== outcome) {
                    clock.tick(10);
                    tree.step();
                }
                const snapshot = JSON.parse(JSON.stringify(tree.snapshot()));

                const random = sinon.stub().returns(0.5);
                const restored = new BehaviourTree(definition, agent, { random });
                restored.restore(snapshot);

                assert.strictEqual(restored.getState(), outcome);
                assert.strictEqual(random.callCount, 0);

                restored.step();

                assert.strictEqual(restored.getState(), State.RUNNING);
                assert.isAbove(random.callCount, 0);
            });
        });

        it("replaces the state of a tree that is running", () => {
            const definition = 'root { sequence { action [work, "a", 1] action [work, "b", 99] } }';
            const context = { step: 1, log: [] };
            const source = new BehaviourTree(definition, createAgent(context));
            const target = new BehaviourTree(definition, createAgent(context));
            source.step();
            target.step();
            target.step();
            context.log = [];

            target.restore(source.snapshot());

            assert.deepEqual(flattenStates(target.getTreeNodeDetails()), flattenStates(source.getTreeNodeDetails()));
        });

        it("ignores the result of a promise that was pending before the restore", async () => {
            let resolve: (state: State) => void = () => {};
            const tree = new BehaviourTree("root { action [wait] }", {
                wait: () => new Promise<State>((r) => (resolve = r))
            });
            const snapshotBefore = new BehaviourTree("root { action [wait] }", {}).snapshot();
            tree.step();

            tree.restore(snapshotBefore);
            resolve(State.SUCCEEDED);
            await Promise.resolve();
            tree.step();

            assert.strictEqual(tree.getState(), State.RUNNING);
        });

        it("does not call onNodeStateChange, and the next step reports changes as usual", () => {
            const changes: string[] = [];
            const definition = "root { sequence { wait [100] wait [100] } }";
            const source = new BehaviourTree(definition, {});
            source.step();
            const target = new BehaviourTree(
                definition,
                {},
                {
                    onNodeStateChange: (change) =>
                        changes.push(`${change.type} ${change.previousState} ${change.state}`)
                }
            );

            target.restore(source.snapshot());

            assert.deepEqual(changes, []);
            assert.strictEqual(target.getState(), State.RUNNING);

            clock.tick(100);
            target.step();

            assert.deepEqual(changes, [
                `wait ${State.RUNNING} ${State.SUCCEEDED}`,
                `wait ${State.READY} ${State.RUNNING}`
            ]);
        });

        describe("leaves the snapshot independent of the trees", () => {
            Object.entries(definitions).forEach(([name, definition]) => {
                it(`for '${name}'`, () => {
                    const context: Context = { step: 0, log: [] };
                    const tree = new BehaviourTree(definition, createAgent(context));
                    for (context.step = 1; context.step <= 3; context.step++) {
                        clock.tick(100);
                        tree.step();
                    }
                    const snapshot = tree.snapshot();
                    const json = JSON.stringify(snapshot);

                    // Stepping the tree does not change the snapshot.
                    for (; context.step <= 8; context.step++) {
                        clock.tick(100);
                        tree.step();
                    }
                    assert.strictEqual(JSON.stringify(snapshot), json);

                    // Stepping a tree that was restored from the snapshot does not change it either.
                    const restored = new BehaviourTree(definition, createAgent({ step: 3, log: [] }));
                    restored.restore(snapshot);
                    assert.deepEqual(JSON.parse(JSON.stringify(restored.snapshot())), JSON.parse(json));
                    for (let step = 4; step <= 12; step++) {
                        clock.tick(100);
                        restored.step();
                    }
                    assert.strictEqual(JSON.stringify(snapshot), json);
                });
            });
        });

        describe("throws and leaves the tree unchanged if the snapshot", () => {
            const definition =
                'root { sequence { repeat [3] { action [work, "a", 99] } lotto { action [work, "b", 99] } wait [100] } }';
            const valid = (): any => {
                const tree = new BehaviourTree(definition, createAgent({ step: 1, log: [] }));
                tree.step();
                return JSON.parse(JSON.stringify(tree.snapshot()));
            };
            const cases: Record<string, (snapshot: any) => any> = {
                "is not an object": () => null,
                "has the wrong root type": (s) => ({ ...s, type: "sequence" }),
                "has an unknown state": (s) => ({ ...s, state: "mistreevous.nope" }),
                "has the wrong number of children": (s) => {
                    s.children[0].children[0].children.pop();
                    return s;
                },
                "has a child of the wrong type": (s) => {
                    s.children[0].children[0].type = "lotto";
                    return s;
                },
                "has no children where the node needs them": (s) => {
                    delete s.children[0].children;
                    return s;
                },
                "has an invalid iteration count": (s) => {
                    s.children[0].children[0].currentIterationCount = -1;
                    return s;
                },
                "has an invalid target iteration count": (s) => {
                    s.children[0].children[0].targetIterationCount = "3";
                    return s;
                },
                "has a lotto child index that is out of range": (s) => {
                    s.children[0].children[1].selectedChildIndex = 5;
                    return s;
                },
                "has no lotto child index for a lotto that is running": (s) => {
                    s.children[0].children[1].state = State.RUNNING;
                    s.children[0].children[1].selectedChildIndex = null;
                    return s;
                },
                "has an invalid waited duration": (s) => {
                    s.children[0].children[2].waitedDuration = "soon";
                    return s;
                }
            };

            Object.entries(cases).forEach(([name, corrupt]) => {
                it(name, () => {
                    const tree = new BehaviourTree(definition, createAgent({ step: 1, log: [] }));
                    tree.step();
                    const before = JSON.stringify(tree.snapshot());

                    assert.throws(() => tree.restore(corrupt(valid())), Error, "invalid snapshot");

                    assert.strictEqual(JSON.stringify(tree.snapshot()), before);
                });
            });
        });
    });

    describe("restore and the definition", () => {
        const agent = createAgent({ step: 1, log: [] });
        const mdsl = `root {
            sequence while(go, 1) entry(onEntry) {
                action [work, "a", 2]
                condition [go]
                wait [10, 20]
                lotto [1, 2] while(go) then succeed {
                    action [work, "b", 3]
                    branch [Sub]
                }
            }
        }
        root [Sub] { action [work, "s", 1] }`;
        // The same definition as the MDSL above, written without the defaults that the MDSL parser adds, with the
        // properties in another order and with the sub root node first.
        const json = [
            { id: "Sub", type: "root", child: { call: "work", args: ["s", 1], type: "action" } },
            {
                type: "root",
                child: {
                    children: [
                        { type: "action", call: "work", args: ["a", 2] },
                        { type: "condition", call: "go" },
                        { type: "wait", duration: [10, 20] },
                        {
                            weights: [1, 2],
                            while: { call: "go", succeedOnAbort: true },
                            type: "lotto",
                            children: [
                                { type: "action", call: "work", args: ["b", 3] },
                                { type: "branch", ref: "Sub" }
                            ]
                        }
                    ],
                    entry: { call: "onEntry" },
                    while: { args: [1], call: "go" },
                    type: "sequence"
                }
            }
        ];

        const restoreBetween = (from: any, to: any) => {
            const source = new BehaviourTree(from, agent);
            const target = new BehaviourTree(to, agent);
            source.step();
            source.step();

            target.restore(JSON.parse(JSON.stringify(source.snapshot())));

            assert.deepEqual(flattenStates(target.getTreeNodeDetails()), flattenStates(source.getTreeNodeDetails()));
            assert.notStrictEqual(target.getState(), State.READY);
        };

        it("accepts a snapshot of the same definition written as MDSL and as JSON", () => {
            restoreBetween(mdsl, json);
            restoreBetween(json, mdsl);
            restoreBetween(json, json);
        });

        it("accepts a snapshot of the same definition written as a single root node object or as an array", () => {
            const object = { type: "root", child: { type: "wait", duration: 5 } };

            restoreBetween("root { wait [5] }", object);
            restoreBetween([object], object);
            restoreBetween(object, "root   {\n  wait [5] /* five */ }");
        });

        describe("throws and leaves the tree unchanged if the snapshot is of a definition that", () => {
            const shape = (head: string, guard = "", name = "work") =>
                `root { sequence ${head} { action [${name}, "a", 2] wait [100] lotto [1, 2] ${guard} { action [work, "b", 3] wait [5] } } }`;
            const cases: Record<string, [source: string, target: string]> = {
                "calls another action": [shape(""), shape("", "", "flaky")],
                "passes other action arguments": [shape(""), shape("").replace('"a", 2', '"a", 3')],
                "waits for another duration": [shape(""), shape("").replace("wait [100]", "wait [101]")],
                "has other lotto weights": [shape(""), shape("").replace("[1, 2]", "[2, 1]")],
                "has an extra guard": [shape(""), shape("", "while(go)")],
                "has another abort state for a guard": [shape("", "while(go) then succeed"), shape("", "while(go)")],
                "has an extra callback": [shape(""), shape("entry(onEntry)")],
                "has another node type with the same shape": [shape(""), shape("").replace("sequence", "selector")],
                "has another structure": [shape(""), 'root { sequence { action [work, "a", 2] wait [100] } }']
            };

            Object.entries(cases).forEach(([name, [sourceDefinition, targetDefinition]]) => {
                it(name, () => {
                    const changes: string[] = [];
                    const source = new BehaviourTree(sourceDefinition, agent);
                    const target = new BehaviourTree(targetDefinition, agent, {
                        onNodeStateChange: (change) => changes.push(change.type)
                    });
                    source.step();
                    source.step();
                    target.step();
                    const before = JSON.stringify(target.snapshot());
                    changes.length = 0;

                    assert.throws(
                        () => target.restore(JSON.parse(JSON.stringify(source.snapshot()))),
                        Error,
                        "snapshot does not match the tree's definition"
                    );

                    assert.strictEqual(JSON.stringify(target.snapshot()), before);
                    assert.deepEqual(changes, []);
                });
            });
        });

        describe("throws and leaves the tree unchanged if the value", () => {
            const tree = new BehaviourTree(mdsl, agent);
            const withoutDefinition = () => {
                const { definition, ...rest } = JSON.parse(JSON.stringify(tree.snapshot()));
                return rest;
            };
            const cases: Record<string, any> = {
                null: null,
                undefined: undefined,
                "a string": "snapshot",
                "a number": 42,
                "a boolean": true,
                "an array": [tree.snapshot()],
                "an object without the fields of a snapshot": {},
                "a snapshot without a definition": withoutDefinition(),
                "a snapshot with a definition that is not a string": { ...tree.snapshot(), definition: 5 }
            };

            Object.entries(cases).forEach(([name, value]) => {
                it(`is ${name}`, () => {
                    const target = new BehaviourTree(mdsl, agent);
                    target.step();
                    const before = JSON.stringify(target.snapshot());

                    assert.throws(() => target.restore(value), Error, /invalid snapshot/);

                    assert.strictEqual(JSON.stringify(target.snapshot()), before);
                });
            });
        });
    });

    describe("restore and an action node that was waiting for a promise when the snapshot was taken", () => {
        const createPendingTree = (calls: string[], onEntry: string[] = []) => {
            const resolvers: ((state: State) => void)[] = [];
            const tree = new BehaviourTree(
                'root { sequence { wait [100] action [first] entry(onEntry, "first") action [second] } }',
                {
                    first: () => {
                        calls.push("first");
                        return new Promise<State>((resolve) => resolvers.push(resolve));
                    },
                    second: () => {
                        calls.push("second");
                        return State.SUCCEEDED;
                    },
                    onEntry: (name: string) => onEntry.push(name)
                }
            );
            return { tree, resolvers };
        };

        it("is restored as not yet started and calls its action function again on the next step", async () => {
            const calls: string[] = [];
            const entries: string[] = [];
            const { tree, resolvers } = createPendingTree(calls, entries);
            tree.step();
            clock.tick(100);
            tree.step();
            assert.deepEqual(calls, ["first"]);

            const restoredCalls: string[] = [];
            const restoredEntries: string[] = [];
            const { tree: restored, resolvers: restoredResolvers } = createPendingTree(restoredCalls, restoredEntries);
            restored.restore(JSON.parse(JSON.stringify(tree.snapshot())));

            assert.strictEqual(restored.getTreeNodeDetails().children![0].children![1].state, State.READY);
            assert.strictEqual(restored.getTreeNodeDetails().children![0].children![0].state, State.SUCCEEDED);
            assert.deepEqual(restoredCalls, []);

            restored.step();
            assert.deepEqual(restoredCalls, ["first"]);
            assert.deepEqual(restoredEntries, ["first"]);
            restored.step();
            assert.deepEqual(restoredCalls, ["first"]);

            restoredResolvers[0](State.SUCCEEDED);
            await Promise.resolve();
            restored.step();
            assert.deepEqual(restoredCalls, ["first", "second"]);
            assert.strictEqual(restored.getState(), State.SUCCEEDED);
            assert.strictEqual(resolvers.length, 1);
        });

        it("is restored as not yet started when its promise settled before the next step", async () => {
            const calls: string[] = [];
            const { tree, resolvers } = createPendingTree(calls);
            tree.step();
            clock.tick(100);
            tree.step();
            resolvers[0](State.SUCCEEDED);
            await Promise.resolve();

            const restoredCalls: string[] = [];
            const { tree: restored } = createPendingTree(restoredCalls);
            restored.restore(tree.snapshot());
            restored.step();

            assert.deepEqual(restoredCalls, ["first"]);
            assert.strictEqual(restored.getState(), State.RUNNING);
        });

        it("ignores the result of the earlier promise when it is restored into the tree that was waiting for it", async () => {
            const resolvers: ((state: State) => void)[] = [];
            const tree = new BehaviourTree("root { action [wait] }", {
                wait: () => new Promise<State>((resolve) => resolvers.push(resolve))
            });
            tree.step();
            const snapshot = tree.snapshot();

            tree.restore(snapshot);
            tree.step();
            assert.strictEqual(resolvers.length, 2);

            resolvers[0](State.SUCCEEDED);
            await Promise.resolve();
            tree.step();
            assert.strictEqual(tree.getState(), State.RUNNING);

            resolvers[1](State.SUCCEEDED);
            await Promise.resolve();
            tree.step();
            assert.strictEqual(tree.getState(), State.SUCCEEDED);
        });

        it("keeps the other nodes of the tree as they were", () => {
            const run = (steps: number) => {
                const tree = new BehaviourTree("root { parallel { action [pending] wait [1000] } }", {
                    pending: () => new Promise<State>(() => {})
                });
                tree.step();
                clock.tick(steps);
                tree.step();
                return tree;
            };
            const source = run(600);
            const restored = new BehaviourTree("root { parallel { action [pending] wait [1000] } }", {
                pending: () => new Promise<State>(() => {})
            });

            restored.restore(source.snapshot());
            const [action, wait] = restored.getTreeNodeDetails().children![0].children!;
            assert.strictEqual(action.state, State.READY);
            assert.strictEqual(wait.state, State.RUNNING);

            clock.tick(400);
            restored.step();
            assert.strictEqual(restored.getTreeNodeDetails().children![0].children![1].state, State.SUCCEEDED);
        });
    });

    it("exports the snapshot type", () => {
        const snapshot: BehaviourTreeSnapshot = new BehaviourTree("root { wait [1] }", {}).snapshot();

        assert.isObject(snapshot);
    });
});
