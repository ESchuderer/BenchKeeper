# Snapshot and restore of tree execution state

Status: in progress (full tier)

## Goal
`BehaviourTree.snapshot()` returns the execution state as a plain object that survives `JSON.stringify` / `JSON.parse` unchanged.
`BehaviourTree.restore(snapshot)` sets a tree built from the same definition to that state. The restored tree then behaves
as the original would have: same node states, same agent function calls in the same order, same result.

## Format
`BehaviourTreeSnapshot = { version: 1; root: NodeSnapshot }`. `NodeSnapshot` mirrors the tree: `type`, `state`, `children` (composites, decorators), plus per type:

| Node | Extra fields |
|---|---|
| repeat | `targetIterationCount: number \| null`, `currentIterationCount` |
| retry | `targetAttemptCount: number \| null`, `currentAttemptCount` |
| lotto | `selectedChildIndex: number \| null` |
| wait | `totalDuration: number \| null`, `waitedDuration` (elapsed ms; with `Date`, computed at snapshot time for a RUNNING node) |
| action | `updatePromise: null \| { isResolved, value }` (settled promise only) |

No `undefined` values are emitted, so the JSON round trip is the identity.

## Decisions
- Wait with `Date`: restore sets the start time to `now - waitedDuration`, so time between snapshot and restore does not count. With `getDeltaTime`: the stored `waitedDuration` is restored, `getDeltaTime` is not called by snapshot.
- Action with a pending (unsettled) promise: the promise cannot be restored, so `snapshot()` saves the action as READY with `updatePromise: null` and the restored tree calls the action function again. Settled promises are kept (resolved state, or rejection reason as string).
- `definition` field: fingerprint of the built tree (branches expanded, defaults normalised), so MDSL and equivalent JSON match. `restore()` throws when it differs or when the input is not a snapshot.
- `restore()` validates the whole snapshot first (version, node types, child counts, states, counters). An invalid snapshot throws and leaves the tree unchanged.
- `restore()` does not call `onNodeStateChange`, entry/exit callbacks or agent functions. The next `step()` reports changes as usual.
- The `random` and `getDeltaTime` functions and agent state are owned by the application and are not part of the snapshot.
- A promise left over from before `restore()` must not overwrite restored action state (identity check in Action).

## Acceptance
- Differential tests: a restored tree and the original produce equal node states, call logs and results for every node type.
- README section with example, Version History row, version 4.4.0.
- `npm test` passes.
