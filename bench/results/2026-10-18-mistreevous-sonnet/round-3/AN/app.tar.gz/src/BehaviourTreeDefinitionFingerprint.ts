import {
    AnyNodeDefinition,
    NodeAttributeDefinition,
    NodeGuardDefinition,
    RootNodeDefinition
} from "./BehaviourTreeDefinition";
import { MAIN_ROOT_NODE_KEY, RootNodeDefinitionMap, createRootNodeDefinitionMap } from "./BehaviourTreeBuilder";
import { isInteger } from "./BehaviourTreeDefinitionUtilities";

/**
 * Gets the fingerprint of a behaviour tree definition, which is the same for definitions that build the same tree.
 * This is the case for an MDSL definition and its equivalent JSON definition. The fingerprint is based on the tree that
 * the builder would create, so branch nodes are replaced by the nested nodes of the root node that they refer to
 * (including globally registered subtrees) and any default value is treated the same as one that is not defined.
 * @param definition The root node definitions, assuming that the definition has been validated.
 * @returns The fingerprint of the definition.
 */
export function getDefinitionFingerprint(definition: RootNodeDefinition[]): string {
    const rootNodeDefinitionMap = createRootNodeDefinitionMap(definition);

    return hash(JSON.stringify(describeNode(rootNodeDefinitionMap[MAIN_ROOT_NODE_KEY], rootNodeDefinitionMap)));
}

/**
 * Creates the description of a node definition and its nested nodes, in a form that does not depend on how the definition was written.
 * @param definition The node definition.
 * @param rootNodeDefinitionMap The mapping of root node identifers to root node definitions, including globally registered subtree root node definitions.
 * @returns The description of the node definition.
 */
function describeNode(definition: AnyNodeDefinition, rootNodeDefinitionMap: RootNodeDefinitionMap): unknown {
    const describeChild = (child: AnyNodeDefinition) => describeNode(child, rootNodeDefinitionMap);

    // The builder replaces a branch node with the nested node of the root node it refers to, ignoring the attributes of both.
    if (definition.type === "branch") {
        return describeChild(rootNodeDefinitionMap[definition.ref].child);
    }

    const description: { [key: string]: unknown } = {
        type: definition.type,
        while: describeGuard(definition.while),
        until: describeGuard(definition.until),
        entry: describeAttribute(definition.entry),
        step: describeAttribute(definition.step),
        exit: describeAttribute(definition.exit)
    };

    switch (definition.type) {
        case "root":
        case "flip":
        case "succeed":
        case "fail":
            description.child = describeChild(definition.child);
            break;

        case "repeat":
            description.iterations = describeCount(definition.iterations);
            description.child = describeChild(definition.child);
            break;

        case "retry":
            description.attempts = describeCount(definition.attempts);
            description.child = describeChild(definition.child);
            break;

        case "lotto":
            description.weights = definition.weights ?? null;
            description.children = definition.children.map(describeChild);
            break;

        case "sequence":
        case "selector":
        case "parallel":
        case "race":
        case "all":
            description.children = definition.children.map(describeChild);
            break;

        case "action":
        case "condition":
            description.call = definition.call;
            description.args = describeArguments(definition.args);
            break;

        case "wait":
            description.duration = describeCount(definition.duration);
            break;

        default:
            throw new Error(`unexpected node type '${(definition as { type: string }).type}'`);
    }

    return description;
}

/**
 * Describes a node attribute definition, or undefined if there is none.
 */
function describeAttribute(attribute: NodeAttributeDefinition | undefined) {
    return attribute && { call: attribute.call, args: describeArguments(attribute.args) };
}

/**
 * Describes a node guard definition, or undefined if there is none.
 */
function describeGuard(guard: NodeGuardDefinition | undefined) {
    return guard && { ...describeAttribute(guard), succeedOnAbort: !!guard.succeedOnAbort };
}

/**
 * Describes an array of arguments, keeping apart values that JSON.stringify would serialise as null or the same number.
 */
function describeArguments(args: unknown[] | undefined) {
    return (args ?? []).map((arg) => {
        if (typeof arg === "undefined") {
            return { $undefined: true };
        }

        return typeof arg === "number" && (!isFinite(arg) || Object.is(arg, -0)) ? { $number: String(arg) } : arg;
    });
}

/**
 * Describes a count or duration that is either a single integer, a range of two integers, or not defined.
 */
function describeCount(value: unknown) {
    if (Array.isArray(value)) {
        return [value[0], value[1]];
    }

    return isInteger(value) ? value : null;
}

/**
 * Creates a 53 bit hash of a string (cyrb53), as a string of 14 hexadecimal characters.
 * @param value The string to hash.
 * @returns The hash of the string.
 */
function hash(value: string): string {
    let h1 = 0xdeadbeef;
    let h2 = 0x41c6ce57;

    for (let index = 0; index < value.length; index++) {
        const code = value.charCodeAt(index);
        h1 = Math.imul(h1 ^ code, 2654435761);
        h2 = Math.imul(h2 ^ code, 1597334677);
    }

    h1 = Math.imul(h1 ^ (h1 >>> 16), 2246822507) ^ Math.imul(h2 ^ (h2 >>> 13), 3266489909);
    h2 = Math.imul(h2 ^ (h2 >>> 16), 2246822507) ^ Math.imul(h1 ^ (h1 >>> 13), 3266489909);

    return (4294967296 * (h2 & 2097151) + (h1 >>> 0)).toString(16).padStart(14, "0");
}
