import { AnyState } from "./State";

/**
 * The version of the snapshot format produced by `BehaviourTree.snapshot()`.
 */
export const SNAPSHOT_VERSION = 1;

/**
 * The snapshot of an action node update promise that has settled.
 */
export type UpdatePromiseSnapshot = {
    /**
     * Whether the promise was resolved rather than rejected.
     */
    isResolved: boolean;
    /**
     * The state the promise resolved with, or null if it resolved with a value that is not a state.
     * The rejection reason as a string if the promise was rejected.
     */
    value: AnyState | string | null;
};

/**
 * The snapshot of the execution state of a tree node and its nested nodes.
 * Only the fields that apply to the type of the node are defined.
 */
export type NodeSnapshot = {
    /**
     * The tree node type.
     */
    type: string;
    /**
     * The state of the tree node.
     */
    state: AnyState;
    /**
     * The snapshots of the child nodes, defined if this is a composite or decorator node.
     */
    children?: NodeSnapshot[];
    /**
     * The number of iterations picked for a repeat node, or null if it iterates indefinitely.
     */
    targetIterationCount?: number | null;
    /**
     * The number of iterations a repeat node has completed.
     */
    currentIterationCount?: number;
    /**
     * The number of attempts picked for a retry node, or null if it attempts indefinitely.
     */
    targetAttemptCount?: number | null;
    /**
     * The number of attempts a retry node has completed.
     */
    currentAttemptCount?: number;
    /**
     * The index of the child picked by a lotto node, or null if it has not picked one.
     */
    selectedChildIndex?: number | null;
    /**
     * The duration in milliseconds picked for a wait node, or null if it waits indefinitely.
     */
    totalDuration?: number | null;
    /**
     * The duration in milliseconds that a wait node has waited for.
     */
    waitedDuration?: number;
    /**
     * The settled promise result of an action node, or null if it does not depend on a promise.
     */
    updatePromise?: UpdatePromiseSnapshot | null;
};

/**
 * A snapshot of the execution state of a behaviour tree.
 * This is a plain object that can be serialised using JSON and restored to a tree built from the same definition.
 */
export type BehaviourTreeSnapshot = {
    /**
     * The version of the snapshot format.
     */
    version: typeof SNAPSHOT_VERSION;
    /**
     * The fingerprint of the definition of the tree that the snapshot was taken from.
     * This is the same for an MDSL definition and its equivalent JSON definition.
     */
    definition: string;
    /**
     * The snapshot of the root node.
     */
    root: NodeSnapshot;
};
