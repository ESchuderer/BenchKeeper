/**
 * Create a randomly generated node uid.
 * @returns A randomly generated node uid.
 */
export function createUid(): string {
    const S4 = function () {
        return (((1 + Math.random()) * 0x10000) | 0).toString(16).substring(1);
    };
    return S4() + S4() + "-" + S4() + "-" + S4() + "-" + S4() + "-" + S4() + S4() + S4();
}

/**
 * Gets whether the given value is a finite number.
 * @param value The value to check.
 * @returns true if the value is a finite number, otherwise false.
 */
export function isFiniteNumber(value: unknown): value is number {
    return typeof value === "number" && isFinite(value);
}

/**
 * Gets whether the given value is an integer that is not negative.
 * @param value The value to check.
 * @returns true if the value is an integer that is not negative, otherwise false.
 */
export function isCount(value: unknown): value is number {
    return typeof value === "number" && Number.isInteger(value) && value >= 0;
}
