import { assert } from "chai";
import sinon, { SinonFakeTimers } from "sinon";

import { BehaviourTree, BehaviourTreeSnapshot, NodeDetails, State } from "../src/index";
import { RootNodeDefinition } from "../src/BehaviourTreeDefinition";

/**
 * The state of a pseudo-random number sequence that can be moved to a given position.
 */
function createRandom() {
    const values = [0.15, 0.85, 0.45, 0.65, 0.05, 0.95, 0.35, 0.55, 0.25, 0.75];
    let index = 0;

    return {
        next: () => values[index++ % values.length],
        getIndex: () => index,
        setIndex: (value: number) => (index = value)
    };
}

/**
 * Create a tree and an agent whose behaviour only depends on the agent 'tick' property, so that two trees
 * with equal state and equal ticks will make equal agent calls. Every agent call is added to the log.
 */
function createRun(definition: string, mode: "delta" | "date") {
    const log: string[] = [];
    const random = createRandom();

    const agent = {
        tick: 0,
        Work() {
            log.push(`Work@${agent.tick}`);
            return agent.tick % 3 === 2 ? State.SUCCEEDED : undefined;
        },
        Slow() {
            log.push(`Slow@${agent.tick}`);
            return agent.tick % 5 === 4 ? State.SUCCEEDED : undefined;
        },
        Fickle() {
            log.push(`Fickle@${agent.tick}`);
            return agent.tick % 3 === 2 ? State.FAILED : undefined;
        },
        Flaky() {
            log.push(`Flaky@${agent.tick}`);
            return agent.tick % 2 === 0 ? State.SUCCEEDED : State.FAILED;
        },
        Never() {
            log.push(`Never@${agent.tick}`);
            return false;
        },
        NotTick14() {
            log.push(`NotTick14@${agent.tick}`);
            return agent.tick !== 14;
        },
        AfterTick15() {
            log.push(`AfterTick15@${agent.tick}`);
            return agent.tick >= 15;
        },
        OnEntry() {
            log.push(`OnEntry@${agent.tick}`);
        },
        OnStep() {
            log.push(`OnStep@${agent.tick}`);
        },
        OnExit(result: { succeeded: boolean; aborted: boolean }) {
            log.push(`OnExit@${agent.tick}:${result.succeeded}:${result.aborted}`);
        }
    };

    const tree = new BehaviourTree(definition, agent, {
        random: random.next,
        ...(mode === "delta" ? { getDeltaTime: () => 0.15 } : {})
    });

    return { agent, log, random, tree };
}

/**
 * Get the node details without the unique node identifiers, which differ between tree instances.
 */
function getStates(tree: BehaviourTree): unknown {
    const strip = (details: NodeDetails): unknown => ({
        type: details.type,
        name: details.name,
        state: details.state,
        children: details.children?.map(strip)
    });

    return strip(tree.getTreeNodeDetails());
}

const DEFINITIONS: Record<string, string> = {
    sequence: "root { sequence { action [Flaky] action [Work] action [Slow] } }",
    "sequence with running children": "root { sequence { action [Work] action [Slow] action [Work] } }",
    selector: "root { selector { condition [Never] action [Fickle] action [Work] } }",
    parallel: "root { parallel { action [Work] action [Slow] } }",
    race: "root { race { action [Work] action [Slow] } }",
    all: "root { all { action [Work] sequence { action [Slow] action [Flaky] } } }",
    "flip, succeed and fail":
        "root { selector { fail { action [Work] } succeed { action [Slow] } flip { action [Work] } } }",
    "repeat with an explicit count": "root { repeat [3] { action [Work] } }",
    "repeat with a random count": "root { repeat [2,4] { action [Work] } }",
    "repeat without a count": "root { repeat { action [Slow] } }",
    "retry with an explicit count": "root { retry [3] { action [Fickle] } }",
    "retry with a random count": "root { retry [2,4] { action [Fickle] } }",
    lotto: "root { lotto [1,2,3] { action [Work] action [Slow] action [Fickle] } }",
    "wait with an explicit duration": "root { sequence { wait [250] action [Work] } }",
    "wait with a random duration": "root { sequence { wait [100,500] action [Work] } }",
    "wait without a duration": "root { race { wait action [Slow] } }",
    "callbacks and guards":
        "root { sequence { action [Work] entry(OnEntry) step(OnStep) exit(OnExit) action [Slow] while(NotTick14) } }",
    "guard that aborts a running repeat": "root { repeat until(AfterTick15) { action [Slow] } }",
    branch: "root { sequence { branch [Sub] action [Slow] } } root [Sub] { repeat [2] { action [Work] } }"
};

const TOTAL_TICKS = 30;

describe("A behaviour tree snapshot", () => {
    let clock: SinonFakeTimers;

    beforeEach(() => {
        clock = sinon.useFakeTimers();
    });

    afterEach(() => {
        clock.restore();
    });

    describe("when restored to a tree built from the same definition", () => {
        for (const mode of ["delta", "date"] as const) {
            describe(`(wait timing from ${mode === "delta" ? "getDeltaTime" : "the clock"})`, () => {
                for (const [name, definition] of Object.entries(DEFINITIONS)) {
                    it(`makes the tree behave like the original for: ${name}`, () => {
                        let snapshotsOfRunningTree = 0;

                        // Take the snapshot after every tick in turn, and compare the original with the restored tree.
                        for (let snapshotTick = 0; snapshotTick < TOTAL_TICKS; snapshotTick++) {
                            const original = createRun(definition, mode);

                            const step = (run: ReturnType<typeof createRun>, tick: number) => {
                                run.agent.tick = tick;
                                run.tree.step();
                            };

                            for (let tick = 0; tick <= snapshotTick; tick++) {
                                clock.tick(100);
                                step(original, tick);
                            }

                            const snapshot = original.tree.snapshot();

                            // The snapshot must be unchanged by a trip through JSON.
                            assert.deepEqual(JSON.parse(JSON.stringify(snapshot)), snapshot);

                            if (original.tree.isRunning()) {
                                snapshotsOfRunningTree++;
                            }

                            // The application owns the random function, its position is not part of the snapshot.
                            const restored = createRun(definition, mode);
                            restored.random.setIndex(original.random.getIndex());
                            restored.tree.restore(JSON.parse(JSON.stringify(snapshot)));

                            assert.deepEqual(getStates(restored.tree), getStates(original.tree));
                            assert.strictEqual(restored.tree.getState(), original.tree.getState());

                            original.log.length = 0;

                            for (let tick = snapshotTick + 1; tick < TOTAL_TICKS; tick++) {
                                clock.tick(100);
                                step(original, tick);
                                step(restored, tick);

                                assert.deepEqual(getStates(restored.tree), getStates(original.tree), `tick ${tick}`);
                                assert.strictEqual(restored.tree.getState(), original.tree.getState());
                                assert.deepEqual(restored.log, original.log, `tick ${tick}`);
                            }

                            clock.reset();
                        }

                        assert.isAbove(snapshotsOfRunningTree, 0);
                    });
                }
            });
        }
    });

    describe("is independent of the tree", () => {
        const json = (value: unknown) => JSON.parse(JSON.stringify(value));

        for (const mode of ["delta", "date"] as const) {
            for (const [name, definition] of Object.entries(DEFINITIONS)) {
                it(`when stepping the tree or a tree it was restored to (${mode}) for: ${name}`, () => {
                    for (let snapshotTick = 0; snapshotTick < TOTAL_TICKS; snapshotTick++) {
                        const original = createRun(definition, mode);

                        for (let tick = 0; tick <= snapshotTick; tick++) {
                            clock.tick(100);
                            original.agent.tick = tick;
                            original.tree.step();
                        }

                        const snapshot = original.tree.snapshot();
                        const copy = json(snapshot);

                        const restored = createRun(definition, mode);
                        restored.random.setIndex(original.random.getIndex());
                        restored.tree.restore(snapshot);

                        // A snapshot taken straight after restoring is the snapshot that was restored.
                        assert.deepEqual(json(restored.tree.snapshot()), copy, `snapshot after tick ${snapshotTick}`);

                        for (let tick = snapshotTick + 1; tick < TOTAL_TICKS; tick++) {
                            clock.tick(100);
                            original.agent.tick = tick;
                            original.tree.step();
                            restored.agent.tick = tick;
                            restored.tree.step();

                            assert.deepEqual(snapshot, copy, `snapshot after tick ${snapshotTick}, at tick ${tick}`);
                        }

                        clock.reset();
                    }
                });
            }
        }

        it("when the tree has a settled action promise", async () => {
            const definition = "root { sequence { action [Resolves] action [Rejects] } }";
            const createAgent = () => ({
                Resolves: () => Promise.resolve(State.SUCCEEDED),
                Rejects: () => Promise.reject("boom")
            });

            const original = new BehaviourTree(definition, createAgent());
            original.step();
            await Promise.resolve();

            const snapshot = original.snapshot();
            const copy = json(snapshot);

            const restored = new BehaviourTree(definition, createAgent());
            restored.restore(snapshot);

            assert.deepEqual(json(restored.snapshot()), copy);

            restored.step();
            original.step();

            assert.deepEqual(snapshot, copy);
        });
    });

    describe("of a tree that has not been stepped", () => {
        it("has every node in the READY state", () => {
            const { tree } = createRun("root { sequence { action [Work] wait [100] } }", "date");

            assert.deepEqual(JSON.parse(JSON.stringify(tree.snapshot())), tree.snapshot());
            assert.strictEqual(tree.snapshot().root.state, State.READY);
            assert.isTrue(tree.snapshot().root.children!.every((child) => child.state === State.READY));
        });
    });

    describe("of a tree that has finished", () => {
        for (const [name, definition, finalState] of [
            ["succeeded", "root { repeat [2,4] { sequence { action [Work] wait [100,500] } } }", State.SUCCEEDED],
            ["failed", "root { retry [2,4] { action [Fickle] } }", State.FAILED]
        ] as const) {
            it(`restores as ${name} and makes new random choices on the next step`, () => {
                const original = createRun(definition, "delta");

                let tick = 0;
                while (original.tree.getState() !== finalState) {
                    original.agent.tick = tick++;
                    original.tree.step();
                }

                const snapshot = JSON.parse(JSON.stringify(original.tree.snapshot()));

                const restored = createRun(definition, "delta");
                restored.random.setIndex(original.random.getIndex());
                restored.tree.restore(snapshot);

                assert.strictEqual(restored.tree.getState(), finalState);
                assert.deepEqual(getStates(restored.tree), getStates(original.tree));

                const randomIndexBeforeNextRun = restored.random.getIndex();
                original.log.length = 0;

                for (let nextTick = tick; nextTick < tick + 20; nextTick++) {
                    original.agent.tick = restored.agent.tick = nextTick;
                    original.tree.step();
                    restored.tree.step();

                    assert.deepEqual(getStates(restored.tree), getStates(original.tree));
                    assert.deepEqual(restored.log, original.log);
                }

                // The next run drew its random numbers again.
                assert.isAbove(restored.random.getIndex(), randomIndexBeforeNextRun);
                assert.strictEqual(restored.random.getIndex(), original.random.getIndex());
            });
        }
    });

    describe("of a tree with a wait node", () => {
        const definition = "root { sequence { wait [1000] action [Work] } }";

        it("restores a wait node that uses the clock with only the time remaining, whatever time passed in between", () => {
            const original = createRun(definition, "date");
            original.tree.step();
            clock.tick(400);

            const snapshot = JSON.parse(JSON.stringify(original.tree.snapshot()));

            // Time passes between taking the snapshot and restoring it.
            clock.tick(3600000);

            const restored = createRun(definition, "date");
            restored.tree.restore(snapshot);

            restored.tree.step();
            assert.strictEqual(restored.tree.getTreeNodeDetails().children![0].children![0].state, State.RUNNING);

            clock.tick(599);
            restored.tree.step();
            assert.strictEqual(restored.tree.getTreeNodeDetails().children![0].children![0].state, State.RUNNING);

            clock.tick(1);
            restored.tree.step();
            assert.strictEqual(restored.tree.getTreeNodeDetails().children![0].children![0].state, State.SUCCEEDED);
        });

        it("restores a wait node that uses getDeltaTime with only the time remaining", () => {
            let deltaTime = 0.25;

            const original = new BehaviourTree(
                definition,
                { Work: () => State.RUNNING },
                { getDeltaTime: () => deltaTime }
            );
            original.step();
            original.step();
            original.step();

            const snapshot = JSON.parse(JSON.stringify(original.snapshot()));

            // The time passes in the application, but not in the tree.
            deltaTime = 10;
            clock.tick(3600000);

            const restored = new BehaviourTree(
                definition,
                { Work: () => State.RUNNING },
                { getDeltaTime: () => deltaTime }
            );
            restored.restore(snapshot);

            const waitState = () => restored.getTreeNodeDetails().children![0].children![0].state;

            // 750ms waited before the snapshot, 250ms remaining.
            deltaTime = 0.2;
            restored.step();
            assert.strictEqual(waitState(), State.RUNNING);

            deltaTime = 0.05;
            restored.step();
            assert.strictEqual(waitState(), State.SUCCEEDED);
        });

        it("does not call getDeltaTime or the random function when taking the snapshot", () => {
            const getDeltaTime = sinon.stub().returns(0.1);
            const random = sinon.stub().returns(0.5);

            const tree = new BehaviourTree("root { wait [100,500] }", {}, { getDeltaTime, random });
            tree.step();

            getDeltaTime.resetHistory();
            random.resetHistory();

            tree.snapshot();

            assert.isFalse(getDeltaTime.called);
            assert.isFalse(random.called);
        });
    });

    describe("of a tree with actions", () => {
        it("does not call any agent function or callback when taking or restoring a snapshot", () => {
            const definition = "root { action [Work] entry(OnEntry) step(OnStep) exit(OnExit) while(NotTick14) }";
            const original = createRun(definition, "delta");
            original.tree.step();
            original.log.length = 0;

            const restored = createRun(definition, "delta");
            restored.tree.restore(original.tree.snapshot());

            assert.deepEqual(original.log, []);
            assert.deepEqual(restored.log, []);
        });

        describe("while an action promise is pending", () => {
            const createPendingAgent = () => {
                const agent = {
                    calls: 0,
                    Wait: () => {
                        agent.calls++;
                        return new Promise<State>(() => {});
                    },
                    Next: () => State.SUCCEEDED,
                    OnEntry: sinon.spy()
                };

                return agent;
            };

            const definition = "root { sequence { action [Next] action [Wait] entry(OnEntry) action [Next] } }";

            it("can be taken and saves the action as not yet started", () => {
                const tree = new BehaviourTree(definition, createPendingAgent());
                tree.step();
                assert.strictEqual(tree.getState(), State.RUNNING);

                const snapshot = tree.snapshot();

                assert.deepEqual(JSON.parse(JSON.stringify(snapshot)), snapshot);

                const [, waitSnapshot] = snapshot.root.children![0].children!;
                assert.deepEqual(waitSnapshot, { type: "action", state: State.READY, updatePromise: null });

                // The other nodes keep the state they have.
                assert.strictEqual(snapshot.root.state, State.RUNNING);
                assert.strictEqual(snapshot.root.children![0].state, State.RUNNING);
                assert.strictEqual(snapshot.root.children![0].children![0].state, State.SUCCEEDED);
            });

            it("does not change the tree that the snapshot was taken from", () => {
                const agent = createPendingAgent();
                const tree = new BehaviourTree(definition, agent);
                tree.step();

                const before = getStates(tree);
                tree.snapshot();
                tree.step();

                assert.deepEqual(getStates(tree), before);
                assert.strictEqual(agent.calls, 1);
            });

            it("restores a tree that calls the action function again on its next step", () => {
                const originalTree = new BehaviourTree(definition, createPendingAgent());
                originalTree.step();

                const restoredAgent = createPendingAgent();
                const restored = new BehaviourTree(definition, restoredAgent);
                restored.restore(JSON.parse(JSON.stringify(originalTree.snapshot())));

                assert.strictEqual(restored.getState(), State.RUNNING);
                assert.strictEqual(restoredAgent.calls, 0);

                restored.step();
                assert.strictEqual(restoredAgent.calls, 1);
                assert.strictEqual(restored.getState(), State.RUNNING);

                // The new promise is the one being waited on, so the action is not called again.
                restored.step();
                assert.strictEqual(restoredAgent.calls, 1);
            });

            it("restores a tree that finishes with the result of the new action call", async () => {
                const createAgent = (action: () => Promise<State>) => ({
                    Wait: action,
                    Next: () => State.SUCCEEDED,
                    OnEntry: () => {}
                });

                const originalTree = new BehaviourTree(
                    definition,
                    createAgent(() => new Promise<State>(() => {}))
                );
                originalTree.step();

                const restored = new BehaviourTree(
                    definition,
                    createAgent(() => Promise.resolve(State.SUCCEEDED))
                );
                restored.restore(originalTree.snapshot());

                restored.step();
                await Promise.resolve();
                restored.step();

                assert.strictEqual(restored.getState(), State.SUCCEEDED);
            });

            it("ignores the pending promise settling after the snapshot was restored to the same tree", async () => {
                let resolveOriginal: (state: State) => void = () => {};
                let calls = 0;

                const tree = new BehaviourTree("root { action [Wait] }", {
                    Wait: () => {
                        calls++;
                        return calls === 1
                            ? new Promise<State>((resolve) => (resolveOriginal = resolve))
                            : new Promise<State>(() => {});
                    }
                });
                tree.step();

                tree.restore(tree.snapshot());

                resolveOriginal(State.SUCCEEDED);
                await Promise.resolve();

                tree.step();
                assert.strictEqual(calls, 2);
                assert.strictEqual(tree.getState(), State.RUNNING);
            });

            it("calls the entry callback of the action again when it starts again", () => {
                const originalTree = new BehaviourTree(definition, createPendingAgent());
                originalTree.step();

                const restoredAgent = createPendingAgent();
                const restored = new BehaviourTree(definition, restoredAgent);
                restored.restore(originalTree.snapshot());
                assert.strictEqual(restoredAgent.OnEntry.callCount, 0);

                restored.step();
                assert.strictEqual(restoredAgent.OnEntry.callCount, 1);
            });

            it("saves every pending action of a tree that has several", () => {
                const parallel = "root { parallel { action [Wait] action [Wait] action [Next] } }";
                const tree = new BehaviourTree(parallel, createPendingAgent());
                tree.step();

                const restoredAgent = createPendingAgent();
                const restored = new BehaviourTree(parallel, restoredAgent);
                restored.restore(tree.snapshot());
                restored.step();

                assert.strictEqual(restoredAgent.calls, 2);
                assert.deepEqual(
                    restored.getTreeNodeDetails().children![0].children!.map((child) => child.state),
                    [State.RUNNING, State.RUNNING, State.SUCCEEDED]
                );
            });
        });

        it("keeps the result of a settled action promise", async () => {
            let calls = 0;
            const createAgent = () => ({
                Wait: () => {
                    calls++;
                    return Promise.resolve(State.FAILED);
                }
            });

            const original = new BehaviourTree("root { action [Wait] }", createAgent());
            original.step();
            await Promise.resolve();

            const snapshot = JSON.parse(JSON.stringify(original.snapshot()));
            assert.deepEqual(snapshot, JSON.parse(JSON.stringify(original.snapshot())));

            const restored = new BehaviourTree("root { action [Wait] }", createAgent());
            restored.restore(snapshot);
            restored.step();

            assert.strictEqual(restored.getState(), State.FAILED);
            assert.strictEqual(calls, 1);
        });

        it("keeps the failure of a rejected action promise", async () => {
            const createAgent = () => ({ Wait: () => Promise.reject("boom") });

            const original = new BehaviourTree("root { action [Wait] }", createAgent());
            original.step();
            await Promise.resolve();
            await Promise.resolve();

            const restored = new BehaviourTree("root { action [Wait] }", createAgent());
            restored.restore(JSON.parse(JSON.stringify(original.snapshot())));

            assert.throws(
                () => restored.step(),
                Error,
                "error stepping tree: action function 'Wait' promise rejected with 'boom'"
            );
        });

        it("is not changed by a promise that settles after the snapshot was restored", async () => {
            let resolveStalePromise: (state: State) => void = () => {};

            const staleTree = new BehaviourTree("root { action [Wait] }", {
                Wait: () => new Promise<State>((resolve) => (resolveStalePromise = resolve))
            });
            staleTree.step();

            const settledSource = new BehaviourTree("root { action [Wait] }", {
                Wait: () => Promise.resolve(State.FAILED)
            });
            settledSource.step();
            await Promise.resolve();

            staleTree.restore(settledSource.snapshot());

            resolveStalePromise(State.SUCCEEDED);
            await Promise.resolve();

            staleTree.step();
            assert.strictEqual(staleTree.getState(), State.FAILED);
        });
    });

    describe("definition", () => {
        const MATCH_MESSAGE = "snapshot does not match the tree's definition";

        const agent = () => ({ A: () => State.RUNNING, B: () => State.RUNNING, W: () => true, E: () => {} });

        const build = (definition: string | RootNodeDefinition | RootNodeDefinition[]) =>
            new BehaviourTree(definition, agent());

        const stepped = (definition: string | RootNodeDefinition | RootNodeDefinition[]) => {
            const tree = build(definition);
            tree.step();
            return tree;
        };

        it("is recorded in the snapshot as a string that survives JSON", () => {
            const snapshot = stepped("root { action [A] }").snapshot();

            assert.isString(snapshot.definition);
            assert.isNotEmpty(snapshot.definition);
            assert.deepEqual(JSON.parse(JSON.stringify(snapshot)), snapshot);
        });

        it("is the same for two trees built from the same definition", () => {
            const definition = "root { sequence { action [A] wait [100,200] } }";

            assert.strictEqual(stepped(definition).snapshot().definition, stepped(definition).snapshot().definition);
        });

        describe("is the same for equivalent definitions", () => {
            const cases: [
                string,
                string | RootNodeDefinition | RootNodeDefinition[],
                string | RootNodeDefinition | RootNodeDefinition[]
            ][] = [
                [
                    "MDSL with different white space and JSON",
                    "root {\n  sequence {\n    action [A]\n    wait\n  }\n}",
                    {
                        type: "root",
                        child: { type: "sequence", children: [{ type: "action", call: "A" }, { type: "wait" }] }
                    }
                ],
                [
                    "MDSL and JSON with arguments, guards, callbacks and different key order",
                    'root { sequence while(W, 1) then succeed until(W) { action [A, 1, "x", null, true, 2.5] entry(E, 3) step(E) exit(E) } }',
                    {
                        child: {
                            children: [
                                {
                                    exit: { args: [], call: "E" },
                                    step: { call: "E", args: [] },
                                    entry: { call: "E", args: [3] },
                                    args: [1, "x", null, true, 2.5],
                                    call: "A",
                                    type: "action"
                                }
                            ],
                            until: { call: "W" },
                            while: { call: "W", args: [1], succeedOnAbort: true },
                            type: "sequence"
                        },
                        type: "root"
                    }
                ],
                [
                    "MDSL and JSON with counts, durations, weights and decorators",
                    "root { sequence { repeat [2,4] { retry [3] { flip { wait [10] } } } lotto [1,2] { succeed { wait [1,5] } fail { action [A] } } repeat { action [B] } } }",
                    {
                        type: "root",
                        child: {
                            type: "sequence",
                            children: [
                                {
                                    type: "repeat",
                                    iterations: [2, 4],
                                    child: {
                                        type: "retry",
                                        attempts: 3,
                                        child: { type: "flip", child: { type: "wait", duration: 10 } }
                                    }
                                },
                                {
                                    type: "lotto",
                                    weights: [1, 2],
                                    children: [
                                        { type: "succeed", child: { type: "wait", duration: [1, 5] } },
                                        { type: "fail", child: { type: "action", call: "A" } }
                                    ]
                                },
                                { type: "repeat", child: { type: "action", call: "B" } }
                            ]
                        }
                    }
                ],
                [
                    "MDSL and JSON with a branch to a named root node, whatever the order of the root nodes",
                    "root { sequence { branch [Sub] action [B] } } root [Sub] { action [A] }",
                    [
                        { type: "root", id: "Sub", child: { type: "action", call: "A" } },
                        {
                            type: "root",
                            child: {
                                type: "sequence",
                                children: [
                                    { type: "branch", ref: "Sub" },
                                    { type: "action", call: "B" }
                                ]
                            }
                        }
                    ]
                ]
            ];

            for (const [name, first, second] of cases) {
                it(name, () => {
                    const snapshot = stepped(first).snapshot();
                    const other = build(second);

                    other.restore(JSON.parse(JSON.stringify(snapshot)));

                    assert.deepEqual(other.snapshot(), snapshot);
                    assert.deepEqual(stepped(second).snapshot().definition, snapshot.definition);
                });
            }

            it("when the JSON is an array of one root node definition rather than the root node definition", () => {
                const snapshot = stepped("root { action [A] }").snapshot();
                const other = build([{ type: "root", child: { type: "action", call: "A" } }]);

                other.restore(snapshot);

                assert.strictEqual(other.getState(), State.RUNNING);
            });
        });

        describe("will make restore error and leave the tree unchanged if the snapshot is of a different definition", () => {
            const cases: [string, string, string][] = [
                ["an action with a different name", "root { action [A] }", "root { action [B] }"],
                ["an action with different arguments", "root { action [A, 1] }", "root { action [A, 2] }"],
                ["an action with and without arguments", "root { action [A, 1] }", "root { action [A] }"],
                ["a node of a different type", "root { sequence { action [A] } }", "root { selector { action [A] } }"],
                [
                    "a different number of children",
                    "root { sequence { action [A] action [A] } }",
                    "root { sequence { action [A] } }"
                ],
                [
                    "children in a different order",
                    "root { sequence { action [A] action [B] } }",
                    "root { sequence { action [B] action [A] } }"
                ],
                [
                    "a different repeat count",
                    "root { repeat [3] { action [A] } }",
                    "root { repeat [4] { action [A] } }"
                ],
                [
                    "a repeat count and a range",
                    "root { repeat [3] { action [A] } }",
                    "root { repeat [3,4] { action [A] } }"
                ],
                ["a different retry count", "root { retry [3] { action [A] } }", "root { retry { action [A] } }"],
                ["a different wait duration", "root { wait [100] }", "root { wait [200] }"],
                [
                    "different lotto weights",
                    "root { lotto [1,2] { action [A] action [B] } }",
                    "root { lotto [2,1] { action [A] action [B] } }"
                ],
                ["a different guard", "root { action [A] while(W) }", "root { action [A] until(W) }"],
                [
                    "a different guard abort result",
                    "root { action [A] while(W) then succeed }",
                    "root { action [A] while(W) }"
                ],
                ["a different callback", "root { action [A] entry(E) }", "root { action [A] exit(E) }"],
                ["a missing callback", "root { action [A] entry(E) }", "root { action [A] }"],
                [
                    "a different branch target",
                    "root { branch [X] } root [X] { action [A] }",
                    "root { branch [X] } root [X] { action [B] }"
                ]
            ];

            for (const [name, source, target] of cases) {
                it(name, () => {
                    const snapshot = JSON.parse(JSON.stringify(stepped(source).snapshot()));

                    const tree = stepped(target);
                    const before = getStates(tree);
                    const beforeSnapshot = tree.snapshot();

                    assert.throws(() => tree.restore(snapshot), Error, MATCH_MESSAGE);

                    assert.deepEqual(getStates(tree), before);
                    assert.deepEqual(tree.snapshot(), beforeSnapshot);
                });
            }

            it("and calls neither onNodeStateChange nor an agent function", () => {
                const snapshot = stepped("root { action [A] }").snapshot();
                const onNodeStateChange = sinon.spy();
                const functions = { B: sinon.spy() };

                const tree = new BehaviourTree("root { action [B] }", functions, { onNodeStateChange });

                assert.throws(() => tree.restore(snapshot), Error, MATCH_MESSAGE);
                assert.isFalse(onNodeStateChange.called);
                assert.isFalse(functions.B.called);
            });

            it("and the tree can still be stepped and restored from its own snapshot", () => {
                const tree = stepped("root { sequence { action [A] action [B] } }");
                const own = tree.snapshot();

                assert.throws(() => tree.restore(stepped("root { action [A] }").snapshot()), Error, MATCH_MESSAGE);

                tree.step();
                tree.restore(own);
                assert.deepEqual(tree.snapshot(), own);
            });

            it("when a global subtree that a branch refers to is registered differently", () => {
                const definition = "root { branch [Shared] }";

                try {
                    BehaviourTree.register("Shared", "root { action [A] }");
                    const snapshot = stepped(definition).snapshot();

                    BehaviourTree.register("Shared", "root { action [B] }");
                    const tree = stepped(definition);

                    assert.throws(() => tree.restore(snapshot), Error, MATCH_MESSAGE);
                } finally {
                    BehaviourTree.unregisterAll();
                }
            });
        });

        it("is different for JSON definitions whose action arguments are not equal once serialised", () => {
            const action = (arg: any): RootNodeDefinition => ({
                type: "root",
                child: { type: "action", call: "A", args: [arg] }
            });

            const fingerprints = [null, undefined, NaN, Infinity, -Infinity, 0, -0, "NaN"].map(
                (arg) => stepped(action(arg)).snapshot().definition
            );

            assert.strictEqual(new Set(fingerprints).size, fingerprints.length);
        });

        it("is not changed by a global subtree that the definition does not refer to", () => {
            try {
                const snapshot = stepped("root { action [A] }").snapshot();

                BehaviourTree.register("Unrelated", "root { action [B] }");
                const tree = stepped("root { action [A] }");

                tree.restore(snapshot);
                assert.deepEqual(tree.snapshot(), snapshot);
            } finally {
                BehaviourTree.unregisterAll();
            }
        });
    });

    describe("restore of something that is not a snapshot", () => {
        const valid = () => stepped("root { sequence { action [A] wait [100] } }").snapshot();
        const agent = () => ({ A: () => State.RUNNING });
        const stepped = (definition: string) => {
            const tree = new BehaviourTree(definition, agent());
            tree.step();
            return tree;
        };

        const cases: [string, () => unknown][] = [
            ["null", () => null],
            ["undefined", () => undefined],
            ["a string", () => "snapshot"],
            ["a JSON string of a snapshot", () => JSON.stringify(valid())],
            ["a number", () => 1],
            ["a boolean", () => true],
            ["an empty array", () => []],
            ["an array of snapshots", () => [valid()]],
            ["an empty object", () => ({})],
            ["an object with other fields", () => ({ foo: "bar" })],
            ["a function", () => () => {}],
            ["a snapshot without a version", () => ({ ...valid(), version: undefined })],
            ["a snapshot without a definition", () => ({ ...valid(), definition: undefined })],
            ["a snapshot with a definition that is not a string", () => ({ ...valid(), definition: 5 })],
            ["a snapshot with an empty definition", () => ({ ...valid(), definition: "" })],
            ["a snapshot without a root", () => ({ ...valid(), root: undefined })],
            ["a snapshot with a root that is not an object", () => ({ ...valid(), root: "root" })],
            ["a snapshot with a null root", () => ({ ...valid(), root: null })]
        ];

        for (const [name, create] of cases) {
            it(`throws an error and leaves the tree unchanged for ${name}`, () => {
                const tree = stepped("root { sequence { action [A] wait [100] } }");
                const before = getStates(tree);
                const beforeSnapshot = tree.snapshot();

                assert.throws(() => tree.restore(create() as BehaviourTreeSnapshot), Error);

                assert.deepEqual(getStates(tree), before);
                assert.deepEqual(tree.snapshot(), beforeSnapshot);
            });
        }

        it("does not report it as a definition mismatch", () => {
            const tree = stepped("root { action [A] }");

            for (const value of [null, "x", 1, [], {}]) {
                assert.throws(() => tree.restore(value as any), Error, "error restoring snapshot: expected a snapshot");
            }
        });
    });

    describe("when restored", () => {
        const definition = "root { sequence { action [Work] action [Slow] } }";

        it("replaces the state of a tree that was already running", () => {
            const original = createRun(definition, "delta");
            original.agent.tick = 2;
            original.tree.step();
            original.agent.tick = 3;
            original.tree.step();

            const other = createRun(definition, "delta");
            other.agent.tick = 0;
            other.tree.step();

            other.tree.restore(original.tree.snapshot());

            assert.deepEqual(getStates(other.tree), getStates(original.tree));
        });

        it("does not call onNodeStateChange, and the next step reports its changes as usual", () => {
            const original = createRun(definition, "delta");
            original.agent.tick = 0;
            original.tree.step();

            const changes: string[] = [];
            const run = createRun(definition, "delta");
            const tree = new BehaviourTree(definition, run.agent, {
                onNodeStateChange: (change) => changes.push(`${change.type}:${change.previousState}:${change.state}`)
            });

            tree.restore(original.tree.snapshot());

            assert.deepEqual(changes, []);

            // The first action is running, and finishes on tick 2 which moves the sequence on to the second action.
            run.agent.tick = 2;
            tree.step();

            assert.deepEqual(changes.sort(), [
                `action:${State.READY}:${State.RUNNING}`,
                `action:${State.RUNNING}:${State.SUCCEEDED}`
            ]);
        });

        describe("will error and leave the tree unchanged if the snapshot", () => {
            const createStartedTree = () => {
                const run = createRun(
                    "root { sequence { lotto { action [Work] action [Slow] } wait [100] } }",
                    "delta"
                );
                run.tree.step();
                return run.tree;
            };

            const cases: [string, (snapshot: any) => void, string][] = [
                ["is not an object", () => {}, "expected a snapshot object"],
                [
                    "has an unsupported version",
                    (snapshot) => (snapshot.version = 2),
                    "unsupported snapshot version '2'"
                ],
                ["has no root node", (snapshot) => delete snapshot.root, "expected a node snapshot object"],
                [
                    "has a node of a different type",
                    (snapshot) => (snapshot.root.children[0].type = "selector"),
                    "expected a node of type 'sequence' but the snapshot has 'selector'"
                ],
                [
                    "has a different number of child nodes",
                    (snapshot) => snapshot.root.children[0].children[0].children.pop(),
                    "expected 2 child nodes for 'lotto' node but the snapshot has 1"
                ],
                [
                    "has a node state that is not valid",
                    (snapshot) => (snapshot.root.children[0].children[0].children[1].state = "unknown"),
                    "invalid state 'unknown'"
                ],
                [
                    "has a lotto node child index that is not valid",
                    (snapshot) => (snapshot.root.children[0].children[0].selectedChildIndex = 2),
                    "invalid selected child index '2' for 'lotto' node"
                ],
                [
                    "has a wait node duration that is not valid",
                    (snapshot) => (snapshot.root.children[0].children[1].waitedDuration = "soon"),
                    "invalid waited duration 'soon' for 'wait' node"
                ]
            ];

            for (const [name, corrupt, message] of cases) {
                it(name, () => {
                    const source = createStartedTree();
                    const snapshot = JSON.parse(JSON.stringify(source.snapshot()));
                    corrupt(snapshot);

                    const target = createStartedTree();
                    const before = getStates(target);
                    const beforeSnapshot = target.snapshot();

                    assert.throws(
                        () => target.restore(name === "is not an object" ? (null as any) : snapshot),
                        Error,
                        `error restoring snapshot: ${message}`
                    );

                    assert.deepEqual(getStates(target), before);
                    assert.deepEqual(target.snapshot(), beforeSnapshot);
                });
            }
        });

        describe("will error and leave the tree unchanged if the snapshot has a node state that the tree could not have reached", () => {
            const cases: [string, string, (snapshot: any) => void, string][] = [
                [
                    "a lotto node that is not READY has no selected child",
                    "root { lotto { action [Work] action [Slow] } }",
                    (snapshot) => {
                        snapshot.root.children[0].state = State.RUNNING;
                        snapshot.root.children[0].selectedChildIndex = null;
                    },
                    "expected a selected child for 'lotto' node that is not in the READY state"
                ],
                [
                    "an action node that is not RUNNING has an update promise",
                    "root { action [Work] }",
                    (snapshot) => {
                        snapshot.root.children[0].state = State.READY;
                        snapshot.root.children[0].updatePromise = { isResolved: true, value: null };
                    },
                    "expected 'action' node with an update promise to be in the RUNNING state"
                ],
                [
                    "a repeat node has completed more iterations than its target",
                    "root { repeat [2] { action [Work] } }",
                    (snapshot) => (snapshot.root.children[0].currentIterationCount = 3),
                    "current iteration count '3' is above the target of '2' for 'repeat' node"
                ],
                [
                    "a retry node has made more attempts than its target",
                    "root { retry [2] { action [Work] } }",
                    (snapshot) => (snapshot.root.children[0].currentAttemptCount = 3),
                    "current attempt count '3' is above the target of '2' for 'retry' node"
                ],
                [
                    "a wait node has a negative total duration",
                    "root { wait [100] }",
                    (snapshot) => (snapshot.root.children[0].totalDuration = -5),
                    "invalid total duration '-5' for 'wait' node"
                ]
            ];

            for (const [name, definition, corrupt, message] of cases) {
                it(name, () => {
                    const tree = createRun(definition, "delta").tree;
                    tree.step();
                    const snapshot = JSON.parse(JSON.stringify(tree.snapshot()));
                    const before = getStates(tree);
                    corrupt(snapshot);

                    assert.throws(() => tree.restore(snapshot), Error, `error restoring snapshot: ${message}`);
                    assert.deepEqual(getStates(tree), before);
                });
            }
        });
    });
});

// Compile time check that the snapshot type is exported.
export type _SnapshotTypeIsExported = BehaviourTreeSnapshot;
