import {
    NodeDefinition,
    RootNodeDefinition,
    DecoratorNodeDefinition,
    CompositeNodeDefinition,
    AnyNodeDefinition,
    BranchNodeDefinition
} from "./BehaviourTreeDefinition";

/**
 * A type guard function that returns true if the specified node satisfies the RootNodeDefinition type.
 * @param node The node.
 * @returns A value of true if the specified node satisfies the RootNodeDefinition type.
 */
export function isRootNodeDefinition(node: NodeDefinition): node is RootNodeDefinition {
    return node.type === "root";
}

/**
 * A type guard function that returns true if the specified node satisfies the BranchNodeDefinition type.
 * @param node The node.
 * @returns A value of true if the specified node satisfies the BranchNodeDefinition type.
 */
export function isBranchNodeDefinition(node: NodeDefinition): node is BranchNodeDefinition {
    return node.type === "branch";
}

/**
 * A type guard function that returns true if the specified node satisfies the NodeDefinition type.
 * @param node The node.
 * @returns A value of true if the specified node satisfies the NodeDefinition type.
 */
export function isLeafNodeDefinition(node: NodeDefinition): node is NodeDefinition {
    return ["branch", "action", "condition", "wait"].includes(node.type);
}

/**
 * A type guard function that returns true if the specified node satisfies the DecoratorNodeDefinition type.
 * @param node The node.
 * @returns A value of true if the specified node satisfies the DecoratorNodeDefinition type.
 */
export function isDecoratorNodeDefinition(node: NodeDefinition): node is DecoratorNodeDefinition {
    return ["root", "repeat", "retry", "flip", "succeed", "fail"].includes(node.type);
}

/**
 * A type guard function that returns true if the specified node satisfies the CompositeNodeDefinition type.
 * @param node The node.
 * @returns A value of true if the specified node satisfies the CompositeNodeDefinition type.
 */
export function isCompositeNodeDefinition(node: NodeDefinition): node is CompositeNodeDefinition {
    return ["sequence", "selector", "lotto", "parallel", "race", "all"].includes(node.type);
}

/**
 * Flatten a node definition into an array of all of its nested node definitions.
 * @param nodeDefinition The node definition to flatten.
 * @returns An array of all of nested node definitions.
 */
export function flattenDefinition(nodeDefinition: AnyNodeDefinition): AnyNodeDefinition[] {
    const nodes: AnyNodeDefinition[] = [];

    const processNode = (currentNodeDefinition: AnyNodeDefinition) => {
        nodes.push(currentNodeDefinition);

        if (isCompositeNodeDefinition(currentNodeDefinition)) {
            currentNodeDefinition.children.forEach(processNode);
        } else if (isDecoratorNodeDefinition(currentNodeDefinition)) {
            processNode(currentNodeDefinition.child);
        }
    };

    processNode(nodeDefinition);

    return nodes;
}

/**
 * Determines whether the passed value is an integer.
 * @param value The value to check.
 * @returns Whether the passed value is an integer.
 */
export function isInteger(value: unknown): boolean {
    return typeof value === "number" && Math.floor(value) === value;
}

/**
 * Determines whether the passed value is null or undefined.
 * @param value The value to check.
 * @returns Whether the passed value is null or undefined.
 */
export function isNullOrUndefined(value: unknown): boolean {
    return typeof value === "undefined" || value === null;
}

/**
 * Gets an identifier for a definition, which is the same for equivalent definitions, whether they were written as MDSL or JSON.
 * @param definition The definition as an array of root node definitions.
 * @returns An identifier for the definition.
 */
export function getDefinitionId(definition: RootNodeDefinition[]): string {
    // Property order, root node order and omitted defaults must not matter. The defaults are the ones that the builder applies.
    const roots = [...definition].sort((a, b) => ((a.id ?? "") < (b.id ?? "") ? -1 : 1));
    const canonical = JSON.stringify(roots, (key, value) => {
        if (typeof value !== "object" || value === null || Array.isArray(value)) {
            return value;
        }

        const normalised = { ...value };

        if (typeof value.call === "string") {
            normalised.args ??= [];
        }

        if (key === "while" || key === "until") {
            normalised.succeedOnAbort = !!value.succeedOnAbort;
        }

        return Object.fromEntries(Object.entries(normalised).sort(([a], [b]) => (a < b ? -1 : 1)));
    });

    // shortcut: a 53-bit cyrb53 hash rather than the definition itself, so that snapshots stay small and need no crypto
    // library in the browser. Collisions are possible but very unlikely for a mistake rather than an attack.
    let h1 = 0xdeadbeef;
    let h2 = 0x41c6ce57;
    for (let i = 0; i < canonical.length; i++) {
        const code = canonical.charCodeAt(i);
        h1 = Math.imul(h1 ^ code, 2654435761);
        h2 = Math.imul(h2 ^ code, 1597334677);
    }
    h1 = Math.imul(h1 ^ (h1 >>> 16), 2246822507) ^ Math.imul(h2 ^ (h2 >>> 13), 3266489909);
    h2 = Math.imul(h2 ^ (h2 >>> 16), 2246822507) ^ Math.imul(h1 ^ (h1 >>> 13), 3266489909);

    return (4294967296 * (2097151 & h2) + (h1 >>> 0)).toString(16);
}
