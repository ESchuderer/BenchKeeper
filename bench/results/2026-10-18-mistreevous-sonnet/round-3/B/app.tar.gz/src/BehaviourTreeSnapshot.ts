import { AnyState } from "./State";

/**
 * A snapshot of the execution state of a single node. Properties other than 'type', 'name', 'state' and 'children'
 * are only present for the node types that have state of their own, and only when there is a value for them.
 */
export type NodeSnapshot = {
    /**
     * The node type.
     */
    type: string;
    /**
     * The node name. Together with the type and children this is used to check that a snapshot is restored to a tree built from the same definition.
     */
    name: string;
    /**
     * The state of the node.
     */
    state: AnyState;
    /**
     * The snapshots of the child nodes, defined if the node is a composite or decorator node.
     */
    children?: NodeSnapshot[];
    /**
     * The index of the child picked by a 'lotto' node.
     */
    selectedChild?: number;
    /**
     * The target number of iterations or attempts of a 'repeat' or 'retry' node, or null if they are unbounded.
     */
    targetCount?: number | null;
    /**
     * The number of iterations or attempts made so far by a 'repeat' or 'retry' node.
     */
    currentCount?: number;
    /**
     * The total duration in milliseconds that a 'wait' node will wait for, or null if it will wait indefinitely.
     */
    totalDuration?: number | null;
    /**
     * The duration in milliseconds that a 'wait' node has waited for.
     */
    waitedDuration?: number;
    /**
     * The outcome of the promise returned by an 'action' node function, if it has settled but was not handled by a step yet.
     * The value is a state if the promise resolved, or the stringified reason if it was rejected.
     */
    settledResult?: { isResolved: boolean; value: string };
};

/**
 * A snapshot of the execution state of a behaviour tree. This is a plain object that can be serialised to and from JSON.
 */
export type BehaviourTreeSnapshot = {
    /**
     * The snapshot format version.
     */
    version: 1;
    /**
     * An identifier of the definition that the tree was built from, which a snapshot can only be restored to a tree of.
     */
    definition: string;
    /**
     * The snapshot of the root node.
     */
    root: NodeSnapshot;
};
