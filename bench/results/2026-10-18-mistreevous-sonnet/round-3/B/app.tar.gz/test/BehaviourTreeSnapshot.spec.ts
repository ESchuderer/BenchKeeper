import { assert } from "chai";
import sinon, { SinonFakeTimers } from "sinon";

import { BehaviourTree, State } from "../src/index";
import type { BehaviourTreeSnapshot, NodeDetails } from "../src/index";

const HOUR = 60 * 60 * 1000;

/** Pass a value through JSON, as a store would. */
const roundTrip = <T>(value: T): T => JSON.parse(JSON.stringify(value));

/** Deep equality, but only slow when it fails, as this is called for thousands of big objects. */
const assertSame = (actual: unknown, expected: unknown, message: string) => {
    if (JSON.stringify(actual) !== JSON.stringify(expected)) {
        assert.deepEqual(actual, expected, message);
    }
};

/** Node ids are random per tree instance, so they are not comparable across trees. */
const withoutIds = (node: NodeDetails): any => ({ ...node, id: undefined, children: node.children?.map(withoutIds) });

/** A deterministic 'random' function that can be started at any position in its sequence. */
const createRandom = (start = 0) => {
    const random = { count: start, next: () => (Math.abs(Math.sin(random.count++ + 1) * 10000) % 1) as number };
    return random;
};

/** The definition used to compare a restored tree to the tree that the snapshot was taken from. */
const definition = `root {
    sequence entry(onEntry) exit(onExit) {
        repeat [2] { action [a1] }
        parallel {
            sequence { wait [200] action [a2] }
            retry [3] { action [a3] }
        }
        race {
            sequence { wait [100, 400] action [a4] }
            action [a5] while(canGo)
        }
        all {
            repeat [1, 3] { action [a6] }
            flip { condition [check1] }
        }
        selector {
            sequence { condition [check2] action [a7] }
            lotto [3, 3, 1] {
                sequence { wait [150] action [a8] }
                sequence { wait [250] succeed { action [a9] } }
                fail { action [a10] }
            }
        }
        retry [1, 2] { action [a11] step(onStep) }
    }
}`;

const OUTCOMES = [
    undefined,
    State.SUCCEEDED,
    State.SUCCEEDED,
    undefined,
    State.SUCCEEDED,
    State.SUCCEEDED,
    State.SUCCEEDED,
    State.SUCCEEDED,
    undefined,
    State.SUCCEEDED,
    State.FAILED,
    State.SUCCEEDED
];

/**
 * Creates a tree for the comparison definition along with an agent that records its calls. The outcome of each agent
 * function depends only on the step number, so a tree restored at step N sees what the original saw from step N.
 */
const createRun = (mode: "date" | "delta", clock: SinonFakeTimers, tick = 0, randomStart = 0) => {
    const calls: string[] = [];
    const changes: string[] = [];
    const random = createRandom(randomStart);
    const context = { tick };

    const agent: any = {
        onEntry: () => calls.push("onEntry"),
        onExit: (success: boolean, aborted: boolean) => calls.push(`onExit ${success} ${aborted}`),
        onStep: () => calls.push("onStep"),
        canGo: () => (calls.push("canGo"), context.tick % 11 !== 0),
        check1: () => (calls.push("check1"), context.tick % 4 !== 0),
        check2: () => (calls.push("check2"), context.tick % 5 < 2)
    };
    for (let id = 1; id <= 11; id++) {
        agent[`a${id}`] = () => {
            calls.push(`a${id}`);
            // a5 is guarded and slow to finish so that the race it is in is usually decided by the wait.
            if (id === 5) return context.tick % 5 === 0 ? State.FAILED : State.RUNNING;
            return OUTCOMES[(context.tick + 3 * id) % OUTCOMES.length];
        };
    }

    const tree = new BehaviourTree(definition, agent, {
        random: random.next,
        onNodeStateChange: ({ type, previousState, state }) => changes.push(`${type} ${previousState} ${state}`),
        ...(mode === "delta" ? { getDeltaTime: () => 0.1 } : {})
    });

    /** Observe the tree, which is everything that restoring a snapshot has to reproduce. */
    const observe = () => ({
        calls: calls.splice(0),
        changes: changes.splice(0),
        state: tree.getState(),
        details: withoutIds(tree.getTreeNodeDetails()),
        randomCalls: random.count
    });

    const step = () => {
        context.tick++;
        tree.step();
        const observed = observe();
        clock.tick(100);
        return { ...observed, snapshot: tree.snapshot() };
    };

    return { tree, random, observe, step };
};

describe("A BehaviourTree", () => {
    let clock: SinonFakeTimers;

    beforeEach(() => {
        clock = sinon.useFakeTimers();
    });

    afterEach(() => {
        clock.restore();
    });

    describe("snapshot and restore", () => {
        (["date", "delta"] as const).forEach((mode) => {
            it(`will restore a tree that then behaves exactly as the original tree would have (${mode} time)`, function () {
                this.timeout(30000);

                const original = createRun(mode, clock);

                const history = [
                    { ...original.observe(), snapshot: original.tree.snapshot() },
                    ...Array.from({ length: 150 }, () => original.step())
                ];

                // Make sure that the run actually went through the interesting states, otherwise this proves little.
                const seen = new Set<string>();
                const collect = (node: any) => {
                    seen.add(`${node.type} ${node.state}`);
                    node.children?.forEach(collect);
                };
                history.forEach(({ snapshot }) => collect(snapshot.root));
                [
                    "root mistreevous.succeeded",
                    "root mistreevous.failed",
                    "repeat mistreevous.running",
                    "retry mistreevous.running",
                    "wait mistreevous.running",
                    "wait mistreevous.succeeded",
                    "lotto mistreevous.running",
                    "parallel mistreevous.running",
                    "race mistreevous.running",
                    "all mistreevous.running",
                    "flip mistreevous.succeeded"
                ].forEach((expected) => assert.include([...seen].sort(), expected, [...seen].sort().join("|")));

                for (let at = 0; at < history.length - 1; at++) {
                    // The snapshot has to survive being stored.
                    assert.deepEqual(roundTrip(history[at].snapshot), history[at].snapshot);

                    // Restore after plenty of time has passed, a new process would have a fresh agent and tick count.
                    clock.tick(HOUR);
                    const restored = createRun(mode, clock, at, history[at].randomCalls);
                    restored.tree.restore(roundTrip(history[at].snapshot));

                    // Restoring is not execution, it should not call agent functions, fire events or make random choices.
                    const { snapshot: _, ...expectedAtRestore } = history[at];
                    assert.deepEqual(restored.observe(), { ...expectedAtRestore, calls: [], changes: [] });

                    for (let next = at + 1; next < history.length; next++) {
                        const { snapshot, ...observed } = restored.step();
                        const { snapshot: expectedSnapshot, ...expected } = history[next];

                        assertSame(observed, expected, `step ${next} after restoring at step ${at}`);
                        assertSame(snapshot, expectedSnapshot, `step ${next} after restoring at step ${at}`);
                    }
                }
            });
        });

        it("will take a snapshot that is plain JSON for a tree that has not been stepped", () => {
            const tree = new BehaviourTree("root { action [a] }", {});
            const snapshot: BehaviourTreeSnapshot = tree.snapshot();

            assert.deepEqual(roundTrip(snapshot), snapshot);
            assert.isString(JSON.stringify(snapshot));
        });

        it("will take a snapshot that does not change when the tree is stepped afterwards", () => {
            const tree = new BehaviourTree("root { action [a] }", { a: () => State.RUNNING });
            const snapshot = tree.snapshot();
            const before = JSON.stringify(snapshot);

            tree.step();

            assert.equal(JSON.stringify(snapshot), before);
        });

        it("will not call onNodeStateChange when restoring, and will report changes as usual on the next step", () => {
            const changes: string[] = [];
            const definition = "root { sequence { action [a] action [a] } }";
            const agent = { a: () => State.SUCCEEDED };
            const original = new BehaviourTree(definition, agent);
            original.step();
            const restored = new BehaviourTree(definition, agent, {
                onNodeStateChange: ({ type }) => changes.push(type)
            });

            restored.restore(roundTrip(original.snapshot()));
            assert.isEmpty(changes);

            restored.step();
            assert.isNotEmpty(changes);
        });

        it("will keep a snapshot independent of the trees it was taken from and restored to", () => {
            const definition =
                "root { sequence { repeat [2, 3] { action [a] } wait [100] lotto { action [b] action [c] } } }";
            const agent = { a: () => State.SUCCEEDED, b: () => State.RUNNING, c: () => State.RUNNING };
            const original = new BehaviourTree(definition, agent);
            const restored = new BehaviourTree(definition, agent);

            for (let step = 0; step < 6; step++) {
                const snapshot = original.snapshot();
                const before = JSON.stringify(snapshot);

                original.step();
                assert.equal(JSON.stringify(snapshot), before, `original stepped, step ${step}`);

                restored.restore(snapshot);
                assert.deepEqual(roundTrip(restored.snapshot()), roundTrip(snapshot), `restored, step ${step}`);

                restored.step();
                assert.equal(JSON.stringify(snapshot), before, `restored stepped, step ${step}`);
                clock.tick(60);
            }
        });

        it("will replace the state of a tree that is already running", () => {
            const agent = { a: () => State.RUNNING };
            const fresh = new BehaviourTree("root { sequence { action [a] action [a] } }", agent);
            const tree = new BehaviourTree("root { sequence { action [a] action [a] } }", agent);
            tree.step();

            tree.restore(fresh.snapshot());

            assert.deepEqual(withoutIds(tree.getTreeNodeDetails()), withoutIds(fresh.getTreeNodeDetails()));
        });

        describe("will keep", () => {
            it("the random iteration count of a repeat node", () => {
                const definition = "root { repeat [1, 5] { action [a] } }";
                const agent = { a: () => State.SUCCEEDED };
                const original = new BehaviourTree(definition, agent, { random: () => 0.99 });
                original.step();
                original.step();

                const restored = new BehaviourTree(definition, agent, { random: () => 0 });
                restored.restore(roundTrip(original.snapshot()));

                // 5 iterations were picked, 2 are done, so there are 3 more steps and then one to find we are done.
                for (let step = 0; step < 3; step++) {
                    restored.step();
                    assert.strictEqual(restored.getState(), State.RUNNING);
                }
                restored.step();
                assert.strictEqual(restored.getState(), State.SUCCEEDED);
            });

            it("the random attempt count of a retry node", () => {
                const definition = "root { retry [1, 5] { action [a] } }";
                const agent = { a: () => State.FAILED };
                const original = new BehaviourTree(definition, agent, { random: () => 0.99 });
                original.step();
                original.step();

                const restored = new BehaviourTree(definition, agent, { random: () => 0 });
                restored.restore(roundTrip(original.snapshot()));

                for (let step = 0; step < 3; step++) {
                    restored.step();
                    assert.strictEqual(restored.getState(), State.RUNNING);
                }
                restored.step();
                assert.strictEqual(restored.getState(), State.FAILED);
            });

            it("the child that a lotto node picked", () => {
                const definition = "root { lotto { action [a] action [b] action [c] } }";
                const calls: string[] = [];
                const createAgent = () => ({
                    a: () => (calls.push("a"), State.RUNNING),
                    b: () => (calls.push("b"), State.RUNNING),
                    c: () => (calls.push("c"), State.RUNNING)
                });
                const original = new BehaviourTree(definition, createAgent(), { random: () => 0.9 });
                original.step();
                assert.deepEqual(calls.splice(0), ["c"]);

                const restored = new BehaviourTree(definition, createAgent(), { random: () => 0 });
                restored.restore(roundTrip(original.snapshot()));
                restored.step();

                assert.deepEqual(calls, ["c"]);
            });

            it("the random duration of a wait node", () => {
                const definition = "root { wait [1000, 2000] }";
                const original = new BehaviourTree(definition, {}, { random: () => 0.5 });
                original.step();
                clock.tick(1000);

                const restored = new BehaviourTree(definition, {}, { random: () => 0 });
                restored.restore(roundTrip(original.snapshot()));
                restored.step();
                assert.strictEqual(restored.getState(), State.RUNNING);

                clock.tick(499);
                restored.step();
                assert.strictEqual(restored.getState(), State.RUNNING);

                clock.tick(1);
                restored.step();
                assert.strictEqual(restored.getState(), State.SUCCEEDED);
            });
        });

        describe("will make a restored wait node only wait for the remaining time", () => {
            it("when using the clock", () => {
                const definition = "root { wait [1000] }";
                const original = new BehaviourTree(definition, {});
                original.step();
                clock.tick(300);
                const snapshot = roundTrip(original.snapshot());

                // The time that passes before restoring does not count.
                clock.tick(HOUR);
                const restored = new BehaviourTree(definition, {});
                restored.restore(snapshot);

                restored.step();
                assert.strictEqual(restored.getState(), State.RUNNING);

                clock.tick(699);
                restored.step();
                assert.strictEqual(restored.getState(), State.RUNNING);

                clock.tick(1);
                restored.step();
                assert.strictEqual(restored.getState(), State.SUCCEEDED);
            });

            it("when using the 'getDeltaTime' option", () => {
                const definition = "root { wait [1000] }";
                let originalDelta = 0.3;
                const original = new BehaviourTree(definition, {}, { getDeltaTime: () => originalDelta });
                original.step();
                // Time passing without steps does not count, so a delta of 0.2 here makes no difference.
                originalDelta = 0.2;
                const snapshot = roundTrip(original.snapshot());

                let restoredDelta = 0.4;
                const restored = new BehaviourTree(definition, {}, { getDeltaTime: () => restoredDelta });
                restored.restore(snapshot);

                restored.step();
                assert.strictEqual(restored.getState(), State.RUNNING);

                restoredDelta = 0.3;
                restored.step();
                assert.strictEqual(restored.getState(), State.SUCCEEDED);
            });
        });

        describe("will restore a finished tree as finished", () => {
            ["SUCCEEDED", "FAILED"].forEach((name) => {
                it(`(${name}) and start a new run, with new random choices, on the next step`, () => {
                    const definition = "root { repeat [1, 5] { action [a] } }";
                    const calls: number[] = [];
                    const agent = {
                        a: () => (calls.push(1), name === "SUCCEEDED" ? State.SUCCEEDED : State.FAILED)
                    };
                    const original = new BehaviourTree(definition, agent, { random: () => 0 });
                    while (original.isRunning() || original.getState() === State.READY) {
                        original.step();
                    }
                    const finishedState = original.getState();
                    assert.strictEqual(finishedState, name === "SUCCEEDED" ? State.SUCCEEDED : State.FAILED);
                    calls.length = 0;

                    let randomCalls = 0;
                    const restored = new BehaviourTree(definition, agent, {
                        random: () => (randomCalls++, 0.99)
                    });
                    restored.restore(roundTrip(original.snapshot()));

                    assert.strictEqual(restored.getState(), finishedState);
                    assert.strictEqual(randomCalls, 0);
                    assert.isEmpty(calls);

                    restored.step();

                    assert.strictEqual(randomCalls, 1);
                    assert.lengthOf(calls, 1);
                });
            });
        });

        describe("will restore a promise-based action", () => {
            const definition = "root { action [a] }";

            it("that has settled but has not been handled by a step yet", async () => {
                let calls = 0;
                const agent = { a: () => (calls++, Promise.resolve(State.FAILED)) };
                const original = new BehaviourTree(definition, agent);
                original.step();
                await Promise.resolve();

                const restored = new BehaviourTree(definition, agent);
                restored.restore(roundTrip(original.snapshot()));
                restored.step();

                assert.strictEqual(restored.getState(), State.FAILED);
                assert.strictEqual(calls, 1);
            });

            it("that was rejected", async () => {
                const agent = { a: () => Promise.reject("it broke") };
                const original = new BehaviourTree(definition, agent);
                original.step();
                await Promise.resolve();

                const restored = new BehaviourTree(definition, agent);
                restored.restore(roundTrip(original.snapshot()));

                assert.throws(() => restored.step(), Error, "promise rejected with 'it broke'");
            });
        });

        describe("will snapshot an action that is still waiting for its promise as not yet started", () => {
            it("so that a restored tree calls the action function again on its next step", () => {
                const definition = "root { sequence { action [first] action [slow] action [last] } }";
                const calls: string[] = [];
                const createAgent = () => ({
                    first: () => (calls.push("first"), State.SUCCEEDED),
                    slow: () => (calls.push("slow"), new Promise<State>(() => {})),
                    last: () => (calls.push("last"), State.SUCCEEDED)
                });
                const original = new BehaviourTree(definition, createAgent());
                original.step();
                original.step();
                assert.deepEqual(calls, ["first", "slow"]);
                calls.length = 0;

                const restored = new BehaviourTree(definition, createAgent());
                restored.restore(roundTrip(original.snapshot()));

                assert.isEmpty(calls);
                assert.strictEqual(restored.getState(), State.RUNNING);
                restored.step();
                assert.deepEqual(calls, ["slow"]);
                assert.strictEqual(restored.getState(), State.RUNNING);
            });

            it("without changing the tree that the snapshot was taken from", async () => {
                let resolve: (state: State) => void = () => {};
                const tree = new BehaviourTree("root { action [slow] }", {
                    slow: () => new Promise<State>((r) => (resolve = r))
                });
                tree.step();

                tree.snapshot();

                assert.strictEqual(tree.getState(), State.RUNNING);
                resolve(State.SUCCEEDED);
                await Promise.resolve();
                tree.step();
                assert.strictEqual(tree.getState(), State.SUCCEEDED);
            });
        });

        describe("will treat an MDSL definition and its equivalent JSON definition as the same definition", () => {
            const mdsl = `root {
                sequence while(g) entry(e, 1) {
                    repeat [2] { action [a, "x", 2] }
                    branch [sub]
                }
            }
            root [sub] { lotto [1, 2] { wait [100] condition [c] } }`;

            // Properties in a different order, root nodes in a different order and defaults left out are all equivalent.
            const json = [
                {
                    id: "sub",
                    child: {
                        children: [
                            { duration: 100, type: "wait" },
                            { call: "c", type: "condition" }
                        ],
                        weights: [1, 2],
                        type: "lotto"
                    },
                    type: "root"
                },
                {
                    child: {
                        type: "sequence",
                        children: [
                            { type: "repeat", iterations: 2, child: { type: "action", call: "a", args: ["x", 2] } },
                            { type: "branch", ref: "sub" }
                        ],
                        entry: { call: "e", args: [1] },
                        while: { call: "g" }
                    },
                    type: "root"
                }
            ];

            const agent = { a: () => State.RUNNING, c: () => true, e: () => {}, g: () => true };

            [
                ["MDSL", "JSON", mdsl, json],
                ["JSON", "MDSL", json, mdsl]
            ].forEach(([from, to, original, restored]: any[]) => {
                it(`when a snapshot of a ${from} tree is restored to a ${to} tree`, () => {
                    const tree = new BehaviourTree(original, agent);
                    tree.step();
                    tree.step();

                    const target = new BehaviourTree(restored, agent);
                    target.restore(roundTrip(tree.snapshot()));

                    assertSame(
                        withoutIds(target.getTreeNodeDetails()),
                        withoutIds(tree.getTreeNodeDetails()),
                        "details"
                    );
                });
            });
        });

        describe("will error and leave the tree unchanged when restoring", () => {
            const definition = "root { sequence { repeat [3] { action [a] } wait [100] } }";
            const agent = { a: () => State.SUCCEEDED };

            const expectRestoreToFail = (snapshot: any, message: string) => {
                const tree = new BehaviourTree(definition, agent);
                tree.step();
                const before = withoutIds(tree.getTreeNodeDetails());
                const beforeSnapshot = tree.snapshot();

                assert.throws(() => tree.restore(snapshot), Error, message);

                assert.deepEqual(withoutIds(tree.getTreeNodeDetails()), before);
                assert.deepEqual(tree.snapshot(), beforeSnapshot);
            };

            const valid = (): any => {
                const tree = new BehaviourTree(definition, agent);
                tree.step();
                return roundTrip(tree.snapshot());
            };

            [
                null,
                undefined,
                5,
                "snapshot",
                [],
                [valid()],
                {},
                { version: 1 },
                { version: 1, definition: "x" }
            ].forEach((snapshot) => {
                it(`something that is not a snapshot (${JSON.stringify(snapshot)})`, () => {
                    expectRestoreToFail(snapshot, "invalid snapshot");
                });
            });

            it("a snapshot without the definition it belongs to", () => {
                const { definition, ...snapshot } = valid();

                expectRestoreToFail(snapshot, "invalid snapshot");
            });

            it("a snapshot with an unsupported version", () => {
                expectRestoreToFail({ ...valid(), version: 2 }, "unsupported snapshot version");
            });

            it("a snapshot taken from a tree with a different definition", () => {
                const other = new BehaviourTree("root { sequence { repeat [3] { action [b] } wait [100] } }", {});

                expectRestoreToFail(other.snapshot(), "snapshot does not match the tree's definition");
            });

            [
                ["action arguments", "root { sequence { repeat [3] { action [a, 1] } wait [100] } }"],
                ["a guard", "root { sequence { repeat [3] { action [a] while(g) } wait [100] } }"],
                ["a callback", "root { sequence { repeat [3] { action [a] entry(e) } wait [100] } }"],
                ["a registered subtree name", "root { sequence { repeat [3] { branch [a] } wait [100] } }"]
            ].forEach(([name, other]) => {
                it(`a snapshot taken from a tree that only differs in ${name}`, () => {
                    // The node types, names and shape are all the same as the tree being restored to.
                    BehaviourTree.register("a", "root { action [a] }");
                    try {
                        expectRestoreToFail(
                            new BehaviourTree(other, {}).snapshot(),
                            "does not match the tree's definition"
                        );
                    } finally {
                        BehaviourTree.unregisterAll();
                    }
                });
            });

            it("a snapshot taken from a tree with different parameters", () => {
                const other = new BehaviourTree("root { sequence { repeat [4] { action [a] } wait [100] } }", {});

                expectRestoreToFail(other.snapshot(), "snapshot does not match the tree");
            });

            it("a snapshot taken from a tree with a different shape", () => {
                const other = new BehaviourTree("root { sequence { repeat [3] { action [a] } } }", {});

                expectRestoreToFail(other.snapshot(), "snapshot does not match the tree");
            });

            it("a snapshot with a node state that does not exist", () => {
                const snapshot = valid();
                snapshot.root.children[0].children[1].state = "bad";

                expectRestoreToFail(snapshot, "invalid snapshot");
            });

            it("a snapshot with invalid state for a node, even when the nodes before it were fine", () => {
                const snapshot = valid();
                snapshot.root.children[0].children[0].currentCount = "lots";

                expectRestoreToFail(snapshot, "invalid snapshot");
            });

            it("a snapshot with a wait node that has an invalid waited duration", () => {
                const snapshot = valid();
                delete snapshot.root.children[0].children[1].waitedDuration;

                expectRestoreToFail(snapshot, "invalid snapshot");
            });

            it("a snapshot with a lotto node that has picked a child that does not exist", () => {
                const lotto = "root { lotto { action [a] action [a] } }";
                const original = new BehaviourTree(lotto, agent);
                original.step();
                const snapshot: any = roundTrip(original.snapshot());
                snapshot.root.children[0].selectedChild = 2;

                const tree = new BehaviourTree(lotto, agent);
                assert.throws(() => tree.restore(snapshot), Error, "invalid snapshot");
            });
        });
    });
});
