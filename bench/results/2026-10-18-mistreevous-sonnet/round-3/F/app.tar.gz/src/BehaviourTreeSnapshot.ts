import { AnyState } from "./State";

/**
 * The version of the snapshot format that is produced by, and can be restored to, a behaviour tree.
 */
export const SNAPSHOT_VERSION = 1;

/**
 * The execution state of a single node in a behaviour tree.
 */
export type NodeSnapshot = {
    /**
     * The tree node type.
     */
    type: string;
    /**
     * The tree node name.
     */
    name: string;
    /**
     * The state of the tree node.
     */
    state: AnyState;
    /**
     * The snapshots of the child nodes in definition order, defined if this node is a composite or decorator node.
     */
    children?: NodeSnapshot[];
    /**
     * The index of the child node that was picked at random to run, or null if none has been picked, defined if this is a lotto node.
     */
    selectedChildIndex?: number | null;
    /**
     * The total duration in milliseconds that the node will wait for, or null if it will wait indefinitely, defined if this is a wait node.
     */
    totalDuration?: number | null;
    /**
     * The duration in milliseconds that the node has waited for, defined if this is a wait node.
     */
    waitedDuration?: number;
    /**
     * The outcome of the promise returned by the action function if it has settled but not yet been handled by the node, otherwise null,
     * defined if this is an action node. A promise that has not settled cannot be saved, so an action that is waiting on one is
     * saved in the READY state as if it had not started, and will call its action function again after being restored.
     * The value is the outcome converted to a string.
     */
    updatePromiseResult?: { isResolved: boolean; value: string } | null;
    /**
     * The number of iterations that have been completed, defined if this is a repeat node.
     */
    currentIterationCount?: number;
    /**
     * The number of iterations to complete, or null if there is no limit, defined if this is a repeat node.
     */
    targetIterationCount?: number | null;
    /**
     * The number of attempts that have failed, defined if this is a retry node.
     */
    currentAttemptCount?: number;
    /**
     * The number of attempts to make, or null if there is no limit, defined if this is a retry node.
     */
    targetAttemptCount?: number | null;
};

/**
 * The execution state of a behaviour tree, as a plain object that can be passed through JSON.stringify and JSON.parse unchanged.
 * A snapshot should be treated as opaque, it is only intended to be stored and later passed to the restore method of a
 * behaviour tree that was built from the same definition as the tree that the snapshot was taken from.
 */
export type BehaviourTreeSnapshot = {
    /**
     * The version of the snapshot format.
     */
    version: typeof SNAPSHOT_VERSION;
    /**
     * The identifier of the definition of the tree that the snapshot was taken from, which is the same for an MDSL definition and
     * the equivalent JSON definition. A snapshot can only be restored to a tree that has the same definition.
     */
    definition: string;
    /**
     * The snapshot of the root node, which contains the snapshots of every other node in the tree.
     */
    root: NodeSnapshot;
};
