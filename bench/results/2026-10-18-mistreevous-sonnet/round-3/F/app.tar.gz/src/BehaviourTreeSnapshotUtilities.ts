import State from "./State";
import { RootNodeDefinition } from "./BehaviourTreeDefinition";

/**
 * Gets whether the specified value is an object that is not null or an array.
 * @param value The value to check.
 * @returns Whether the specified value is an object that is not null or an array.
 */
export function isObject(value: unknown): value is { [key: string]: unknown } {
    return typeof value === "object" && value !== null && !Array.isArray(value);
}

/**
 * Gets whether the specified value is a node state.
 * @param value The value to check.
 * @returns Whether the specified value is a node state.
 */
export function isState(value: unknown): value is State {
    return Object.values(State).includes(value as State);
}

/**
 * Gets whether the specified value is a non-negative integer.
 * @param value The value to check.
 * @returns Whether the specified value is a non-negative integer.
 */
export function isCount(value: unknown): value is number {
    return Number.isInteger(value) && (value as number) >= 0;
}

/**
 * Gets whether the specified value is a finite number.
 * @param value The value to check.
 * @returns Whether the specified value is a finite number.
 */
export function isFiniteNumber(value: unknown): value is number {
    return typeof value === "number" && Number.isFinite(value);
}

/**
 * Gets whether a value could be the count or duration that was picked for a node that is configured with either
 * a fixed value or a minimum and maximum value to pick between, or neither if the node is not limited.
 * @param value The value from a snapshot.
 * @param fixed The fixed value that the node is configured with, otherwise null.
 * @param min The minimum value that the node is configured with, otherwise null.
 * @param max The maximum value that the node is configured with, otherwise null.
 * @param isRequired Whether the node is in a state where it will have picked a value if it is able to.
 * @returns Whether the value could be the count or duration that was picked.
 */
export function isPossiblePickedValue(
    value: unknown,
    fixed: number | null,
    min: number | null,
    max: number | null,
    isRequired: boolean
): boolean {
    const isLimited = fixed !== null || (min !== null && max !== null);

    // A node that has not been updated has not picked a value, and one that is not limited never will.
    if (value === null) {
        return !isLimited || !isRequired;
    }

    if (!isCount(value)) {
        return false;
    }

    if (fixed !== null) {
        return value === fixed;
    }

    return min !== null && max !== null && value >= min && value <= max;
}

/**
 * Converts a value to a string without throwing an error if it cannot be converted.
 * @param value The value to convert.
 * @returns The value as a string.
 */
export function toSafeString(value: unknown): string {
    try {
        return String(value);
    } catch {
        return Object.prototype.toString.call(value);
    }
}

/**
 * Throws an error if a property of a node snapshot is not valid.
 * @param nodeName The name of the node that the snapshot is for.
 * @param property The name of the snapshot property.
 * @param value The value of the snapshot property.
 * @param isValid A function that determines whether the value is valid.
 */
export function assertValidProperty(
    nodeName: string,
    property: string,
    value: unknown,
    isValid: (value: unknown) => boolean
): void {
    if (!isValid(value)) {
        throw new Error(
            `expected snapshot of '${nodeName}' node to have a valid ${property} but got '${toSafeString(value)}'`
        );
    }
}

/**
 * Gets a canonical form of a value from a tree definition, which is the same for definitions that build the same tree.
 * This means that properties are sorted, undefined properties are dropped and the empty arguments and false 'succeedOnAbort'
 * flags that are the default for nodes and attributes, and are always present in a definition converted from MDSL, are dropped.
 * @param value The value to convert.
 * @returns The canonical form of the value.
 */
function toCanonicalDefinitionValue(value: unknown): unknown {
    if (Array.isArray(value)) {
        return value.map(toCanonicalDefinitionValue);
    }

    if (!isObject(value)) {
        return value;
    }

    const canonical: { [key: string]: unknown } = {};

    for (const key of Object.keys(value).sort()) {
        const property = value[key];

        const isDefault =
            typeof property === "undefined" ||
            (key === "args" && Array.isArray(property) && property.length === 0) ||
            (key === "succeedOnAbort" && property === false);

        if (!isDefault) {
            canonical[key] = toCanonicalDefinitionValue(property);
        }
    }

    return canonical;
}

/**
 * Gets a 53-bit hash of a string.
 * @param text The string to hash.
 * @param seed The seed, which results in a different hash of the same string.
 * @returns The hash of the string.
 */
function hashString(text: string, seed: number): number {
    let h1 = 0xdeadbeef ^ seed;
    let h2 = 0x41c6ce57 ^ seed;

    for (let index = 0; index < text.length; index++) {
        const code = text.charCodeAt(index);
        h1 = Math.imul(h1 ^ code, 2654435761);
        h2 = Math.imul(h2 ^ code, 1597334677);
    }

    h1 = Math.imul(h1 ^ (h1 >>> 16), 2246822507) ^ Math.imul(h2 ^ (h2 >>> 13), 3266489909);
    h2 = Math.imul(h2 ^ (h2 >>> 16), 2246822507) ^ Math.imul(h1 ^ (h1 >>> 13), 3266489909);

    return 4294967296 * (2097151 & h2) + (h1 >>> 0);
}

/**
 * Gets an identifier for a tree definition, which is the same for any two definitions that build the same tree, whether they
 * were written as MDSL or JSON. It is intended to detect a snapshot being restored to a tree of another definition by mistake,
 * and is not a means of protecting against a snapshot that was tampered with.
 * @param rootNodeDefinitions The root node definitions of the tree, as JSON.
 * @returns The identifier of the tree definition.
 */
export function getDefinitionId(rootNodeDefinitions: RootNodeDefinition[]): string {
    // The order of the root nodes does not matter, but the main root node has no identifier so always comes first.
    // The identifiers are compared as code units rather than with localeCompare, as the result must not depend on the locale.
    const sortedRootNodeDefinitions = [...rootNodeDefinitions].sort((a, b) => {
        const [idA, idB] = [a.id ?? "", b.id ?? ""];
        return idA < idB ? -1 : idA > idB ? 1 : 0;
    });

    const canonical = JSON.stringify(toCanonicalDefinitionValue(sortedRootNodeDefinitions));

    // Two hashes of the definition with different seeds are used, as a single 53-bit hash is more likely to collide than is comfortable.
    return [hashString(canonical, 0), hashString(canonical, 1)]
        .map((hash) => hash.toString(16).padStart(14, "0"))
        .join("");
}
