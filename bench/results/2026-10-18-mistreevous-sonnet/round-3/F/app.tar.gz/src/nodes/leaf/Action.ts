import { BehaviourTreeOptions } from "../../BehaviourTreeOptions";
import { NodeDetails } from "../Node";
import State, { CompleteState } from "../../State";
import { Agent } from "../../Agent";
import Leaf from "./Leaf";
import Lookup from "../../Lookup";
import Attribute from "../../attributes/Attribute";
import { NodeSnapshot } from "../../BehaviourTreeSnapshot";
import { assertValidProperty, isObject, toSafeString } from "../../BehaviourTreeSnapshotUtilities";

/**
 * The type representing a resolved/rejected update promise.
 */
type UpdatePromiseResult = {
    /**
     * Whether the promise was resolved rather than rejected.
     */
    isResolved: boolean;

    /**
     * The promise resolved value or rejection reason.
     */
    value: any;
};

/**
 * An Action leaf node.
 * This represents an immediate or ongoing state of behaviour.
 */
export default class Action extends Leaf {
    /**
     * @param attributes The node attributes.
     * @param options The behaviour tree options.
     * @param actionName The action name.
     * @param actionArguments The array of action arguments.
     */
    constructor(
        attributes: Attribute[],
        options: BehaviourTreeOptions,
        private actionName: string,
        public actionArguments: any[]
    ) {
        super("action", attributes, options);
    }

    /**
     * Whether there is a pending update promise.
     */
    private isUsingUpdatePromise = false;

    /**
     * The update promise that this node is waiting on, used to ignore the result of any promise from before a reset or abort.
     */
    private updatePromise: Promise<CompleteState> | null = null;

    /**
     * The finished state result of an update promise.
     */
    private updatePromiseResult: UpdatePromiseResult | null = null;

    /**
     * Called when the node is being updated.
     * @param agent The agent.
     */
    protected onUpdate(agent: Agent): void {
        // If the result of this action depends on an update promise then there is nothing to do until it settles.
        if (this.isUsingUpdatePromise) {
            // Are we still waiting for our update promise to settle?
            if (!this.updatePromiseResult) {
                return;
            }

            const { isResolved, value } = this.updatePromiseResult;

            // Our update promise settled, was it resolved or rejected?
            if (isResolved) {
                // Our promise resolved so check to make sure the result is a valid finished state.
                if (value !== State.SUCCEEDED && value !== State.FAILED) {
                    throw new Error(
                        "action node promise resolved with an invalid value, expected a State.SUCCEEDED or State.FAILED value to be returned"
                    );
                }

                // Set the state of this node to match the state returned by the promise.
                this.setState(value);

                return;
            } else {
                // The promise was rejected, which isn't great.
                throw new Error(`action function '${this.actionName}' promise rejected with '${value}'`);
            }
        }

        // Attempt to get the invoker for the action function.
        const actionFuncInvoker = Lookup.getFuncInvoker(agent, this.actionName);

        // The action function should be defined.
        if (actionFuncInvoker === null) {
            throw new Error(
                `cannot update action node as the action '${this.actionName}' function is not defined on the agent and has not been registered`
            );
        }

        let actionFunctionResult;

        try {
            // Call the action function, the result of which may be:
            // - The finished state of this action node.
            // - A promise to return a finished node state.
            // - Undefined if the node should remain in the running state.
            actionFunctionResult = actionFuncInvoker(this.actionArguments) as CompleteState | Promise<CompleteState>;
        } catch (error) {
            // An uncaught error was thrown.
            if (error instanceof Error) {
                throw new Error(`action function '${this.actionName}' threw: ${error.stack}`);
            } else {
                throw new Error(`action function '${this.actionName}' threw: ${error}`);
            }
        }

        if (actionFunctionResult instanceof Promise) {
            actionFunctionResult.then(
                (result) => {
                    // If this is not the promise we are waiting on then it was cleared as it was resolving, probably via an abort or reset.
                    if (this.updatePromise !== actionFunctionResult) {
                        return;
                    }

                    // Set the resolved update promise result so that it can be handled on the next update of this node.
                    this.updatePromiseResult = {
                        isResolved: true,
                        value: result
                    };
                },
                (reason) => {
                    // If this is not the promise we are waiting on then it was cleared as it was rejecting, probably via an abort or reset.
                    if (this.updatePromise !== actionFunctionResult) {
                        return;
                    }

                    // Set the rejected update promise result so that it can be handled on the next update of this node.
                    this.updatePromiseResult = {
                        isResolved: false,
                        value: reason
                    };
                }
            );

            // This node will be in the 'RUNNING' state until the update promise resolves.
            this.setState(State.RUNNING);

            // We are now waiting for the promise returned by the use to resolve before we know what state this node is in.
            this.isUsingUpdatePromise = true;
            this.updatePromise = actionFunctionResult;
        } else {
            // Validate the returned value.
            this.validateUpdateResult(actionFunctionResult);

            // Set the state of this node, this may be undefined, which just means that the node is still in the 'RUNNING' state.
            this.setState(actionFunctionResult || State.RUNNING);
        }
    }

    /**
     * Gets the name of the node.
     */
    getName = () => this.actionName;

    /**
     * Reset the state of the node.
     */
    reset = () => {
        // Reset the state of this node.
        this.setState(State.READY);

        // There is no longer an update promise that we care about.
        this.isUsingUpdatePromise = false;
        this.updatePromise = null;
        this.updatePromiseResult = null;
    };

    /**
     * Gets the snapshot of this node instance, which holds all of the execution state needed to later restore this node.
     * @returns The snapshot of this node instance.
     */
    public getSnapshot(): NodeSnapshot {
        // A promise that has not settled cannot be saved, so a node that is waiting on one is saved as if it had not started.
        const isWaitingOnPendingPromise = this.isUsingUpdatePromise && this.updatePromiseResult === null;

        return {
            ...super.getSnapshot(),
            state: isWaitingOnPendingPromise ? State.READY : this.getState(),
            updatePromiseResult: this.updatePromiseResult
                ? {
                      isResolved: this.updatePromiseResult.isResolved,
                      value: toSafeString(this.updatePromiseResult.value)
                  }
                : null
        };
    }

    /**
     * Validates a snapshot against this node instance without changing it.
     * @param snapshot The snapshot of this node instance.
     * @returns A function that restores this node instance to the state described by the snapshot.
     */
    public prepareRestore(snapshot: NodeSnapshot): () => void {
        const restoreNode = super.prepareRestore(snapshot);

        assertValidProperty(
            this.getName(),
            "updatePromiseResult",
            snapshot.updatePromiseResult,
            (value) =>
                value === null ||
                (isObject(value) && typeof value.isResolved === "boolean" && typeof value.value === "string")
        );

        return () => {
            restoreNode();

            // The promise that this node may have been waiting on cannot be restored, and any that it is waiting on now is no longer of interest.
            // If the promise had not settled then the node was saved as READY and will start again on the next update.
            this.updatePromise = null;
            this.updatePromiseResult = snapshot.updatePromiseResult
                ? { isResolved: snapshot.updatePromiseResult.isResolved, value: snapshot.updatePromiseResult.value }
                : null;
            this.isUsingUpdatePromise = this.updatePromiseResult !== null;
        };
    }

    /**
     * Gets the details of this node instance.
     * @returns The details of this node instance.
     */
    public getDetails(): NodeDetails {
        return {
            ...super.getDetails(),
            args: this.actionArguments
        };
    }

    /**
     * Called when the state of this node changes.
     * @param previousState The previous node state.
     */
    protected onStateChanged(previousState: State): void {
        this.options.onNodeStateChange?.({
            id: this.uid,
            type: this.getType(),
            args: this.actionArguments,
            while: this.attributes.while?.getDetails(),
            until: this.attributes.until?.getDetails(),
            entry: this.attributes.entry?.getDetails(),
            step: this.attributes.step?.getDetails(),
            exit: this.attributes.exit?.getDetails(),
            previousState,
            state: this.getState()
        });
    }

    /**
     * Validate the result of an update function call.
     * @param result The result of an update function call.
     */
    private validateUpdateResult = (result: CompleteState | State.RUNNING) => {
        switch (result) {
            case State.SUCCEEDED:
            case State.FAILED:
            case State.RUNNING:
            case undefined:
                return;
            default:
                throw new Error(
                    `expected action function '${this.actionName}' to return an optional State.SUCCEEDED or State.FAILED value but returned '${result}'`
                );
        }
    };
}
