import Leaf from "./Leaf";
import State from "../../State";
import Attribute from "../../attributes/Attribute";
import { Agent } from "../../Agent";
import { BehaviourTreeOptions } from "../../BehaviourTreeOptions";
import { NodeSnapshot } from "../../BehaviourTreeSnapshot";
import { assertValidProperty, isFiniteNumber, isPossiblePickedValue } from "../../BehaviourTreeSnapshotUtilities";

/**
 * A WAIT node.
 * The state of this node will change to SUCCEEDED after a duration of time
 */
export default class Wait extends Leaf {
    /**
     * @param attributes The node attributes.
     * @param options The behaviour tree options.
     * @param duration The duration that this node will wait to succeed in milliseconds.
     * @param durationMin The minimum possible duration in milliseconds that this node will wait to succeed.
     * @param durationMax The maximum possible duration in milliseconds that this node will wait to succeed.
     */
    constructor(
        attributes: Attribute[],
        options: BehaviourTreeOptions,
        private duration: number | null,
        private durationMin: number | null,
        private durationMax: number | null
    ) {
        super("wait", attributes, options);
    }

    /**
     * The time in milliseconds at which this node was first updated.
     */
    private initialUpdateTime: number = 0;

    /**
     * The total duration in milliseconds that this node will be waiting for.
     */
    private totalDuration: number | null = null;

    /**
     * The duration in milliseconds that this node has been waiting for.
     */
    private waitedDuration: number = 0;

    /**
     * Called when the node is being updated.
     * @param agent The agent.
     */
    protected onUpdate(agent: Agent): void {
        // If this node is in the READY state then we need to set the initial update time.
        if (this.is(State.READY)) {
            // Set the initial update time.
            this.initialUpdateTime = new Date().getTime();

            // Set the initial waited duration.
            this.waitedDuration = 0;

            // Are we dealing with an explicit duration or will we be randomly picking a duration between the min and max duration.
            if (this.duration !== null) {
                this.totalDuration = this.duration;
            } else if (this.durationMin !== null && this.durationMax !== null) {
                // We will be picking a random duration between a min and max duration, if the optional 'random' behaviour tree
                // function option is defined then we will be using that, otherwise we will fall back to using Math.random.
                const random = typeof this.options.random === "function" ? this.options.random : Math.random;

                // Pick a random duration between a min and max duration.
                this.totalDuration = Math.floor(
                    random() * (this.durationMax - this.durationMin + 1) + this.durationMin
                );
            } else {
                this.totalDuration = null;
            }

            // The node is now running until we finish waiting.
            this.setState(State.RUNNING);
        }

        // If we have no total duration then this wait node will wait indefinitely until it is aborted.
        if (this.totalDuration === null) {
            return;
        }

        // If we have a 'getDeltaTime' function defined as part of our options then we will use it to figure out how long we have waited for.
        if (typeof this.options.getDeltaTime === "function") {
            // Get the delta time.
            const deltaTime = this.options.getDeltaTime();

            // Our delta time must be a valid number and cannot be NaN.
            if (typeof deltaTime !== "number" || isNaN(deltaTime)) {
                throw new Error("The delta time must be a valid number and not NaN.");
            }

            // Update the amount of time that this node has been waiting for based on the delta time.
            this.waitedDuration += deltaTime * 1000;
        } else {
            // We are not using a delta time, so we will just work out hom much time has passed since the first update.
            this.waitedDuration = new Date().getTime() - this.initialUpdateTime;
        }

        // Have we waited long enough?
        if (this.waitedDuration >= this.totalDuration) {
            // We have finished waiting!
            this.setState(State.SUCCEEDED);
        }
    }

    /**
     * Gets the snapshot of this node instance, which holds all of the execution state needed to later restore this node.
     * @returns The snapshot of this node instance.
     */
    public getSnapshot(): NodeSnapshot {
        let waitedDuration = this.waitedDuration;

        // When using the clock the waited duration is only brought up to date as part of a node update, but the time since
        // the last update has also been waited for and would be taken into account the next time that the node is updated.
        if (this.is(State.RUNNING) && this.totalDuration !== null && typeof this.options.getDeltaTime !== "function") {
            waitedDuration = new Date().getTime() - this.initialUpdateTime;
        }

        return {
            ...super.getSnapshot(),
            totalDuration: this.totalDuration,
            // A duration that is infinite cannot be saved as JSON, but one that is as large as possible has the same effect.
            waitedDuration: Math.max(-Number.MAX_VALUE, Math.min(Number.MAX_VALUE, waitedDuration))
        };
    }

    /**
     * Validates a snapshot against this node instance without changing it.
     * @param snapshot The snapshot of this node instance.
     * @returns A function that restores this node instance to the state described by the snapshot.
     */
    public prepareRestore(snapshot: NodeSnapshot): () => void {
        const restoreNode = super.prepareRestore(snapshot);

        assertValidProperty(this.getName(), "totalDuration", snapshot.totalDuration, (value) =>
            isPossiblePickedValue(
                value,
                this.duration,
                this.durationMin,
                this.durationMax,
                snapshot.state === State.RUNNING
            )
        );
        assertValidProperty(this.getName(), "waitedDuration", snapshot.waitedDuration, isFiniteNumber);

        return () => {
            restoreNode();
            this.totalDuration = snapshot.totalDuration!;
            this.waitedDuration = snapshot.waitedDuration!;

            // Any time that has passed since the snapshot was taken is not time waited, so the node is treated as if it
            // was first updated the duration that it had waited for ago, which is what is used when waiting using the clock.
            this.initialUpdateTime = new Date().getTime() - this.waitedDuration;
        };
    }

    /**
     * Gets the name of the node.
     */
    getName = () => {
        if (this.duration !== null) {
            return `WAIT ${this.duration}ms`;
        } else if (this.durationMin !== null && this.durationMax !== null) {
            return `WAIT ${this.durationMin}ms-${this.durationMax}ms`;
        } else {
            return "WAIT";
        }
    };
}
