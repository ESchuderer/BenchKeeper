import { assert } from "chai";
import sinon, { SinonFakeTimers } from "sinon";

import { BehaviourTree, BehaviourTreeSnapshot, NodeDetails, State } from "../src/index";
import { Agent } from "../src/Agent";
import { RootNodeDefinition } from "../src/BehaviourTreeDefinition";

type Definition = string | RootNodeDefinition | RootNodeDefinition[];

/**
 * Flattens the node details of a tree into an array of [name, state] pairs, ignoring the instance-specific node ids.
 */
function getNodeStates(tree: BehaviourTree): [string, string][] {
    const states: [string, string][] = [];

    const visit = (node: NodeDetails) => {
        states.push([node.name, node.state]);
        (node.children ?? []).forEach(visit);
    };

    visit(tree.getTreeNodeDetails());

    return states;
}

/**
 * Takes a snapshot of a tree and passes it through JSON, as it would be if it was saved and loaded from storage.
 */
function saveAndLoad(tree: BehaviourTree): BehaviourTreeSnapshot {
    return JSON.parse(JSON.stringify(tree.snapshot()));
}

/**
 * Creates an agent that records the name of every function that is called and has actions that run until told to finish.
 */
function createAgent(): { calls: string[]; results: { [name: string]: State | undefined } } & Agent {
    const calls: string[] = [];
    const results: { [name: string]: State | undefined } = {};

    const createFunction = (name: string) => () => {
        calls.push(name);
        return results[name];
    };

    return {
        calls,
        results,
        A: createFunction("A"),
        B: createFunction("B"),
        C: createFunction("C"),
        D: createFunction("D")
    };
}

describe("A BehaviourTree", () => {
    beforeEach(() => BehaviourTree.unregisterAll());

    describe("has a snapshot method that", () => {
        it("returns a versioned snapshot that is unchanged by passing it through JSON", () => {
            const agent = createAgent();
            agent.results.A = State.SUCCEEDED;
            const tree = new BehaviourTree("root { sequence { action [A] action [B] } }", agent);

            for (const stepCount of [0, 1, 2]) {
                if (stepCount > 0) {
                    tree.step();
                }

                const snapshot = tree.snapshot();

                assert.strictEqual(snapshot.version, 1);
                assert.deepStrictEqual(JSON.parse(JSON.stringify(snapshot)), snapshot);
            }
        });

        it("describes every node in the tree", () => {
            const agent = createAgent();
            agent.results.A = State.SUCCEEDED;
            const tree = new BehaviourTree("root { sequence { action [A] action [B] } }", agent);

            tree.step();

            const { root } = tree.snapshot();

            assert.deepStrictEqual(
                [root.type, root.name, root.state],
                ["root", "ROOT", State.RUNNING],
                "the root node snapshot should describe the root node"
            );

            const [sequence] = root.children!;
            assert.deepStrictEqual(
                [sequence.type, sequence.name, sequence.state],
                ["sequence", "SEQUENCE", State.RUNNING]
            );

            const [actionA, actionB] = sequence.children!;
            assert.deepStrictEqual([actionA.type, actionA.name, actionA.state], ["action", "A", State.SUCCEEDED]);
            assert.deepStrictEqual([actionB.type, actionB.name, actionB.state], ["action", "B", State.RUNNING]);
        });

        it("does not call any agent functions or change the state of the tree", () => {
            const agent = createAgent();
            const tree = new BehaviourTree("root { sequence { action [A] action [B] } }", agent);

            tree.step();
            const statesBefore = getNodeStates(tree);
            const callsBefore = [...agent.calls];

            tree.snapshot();

            assert.deepStrictEqual(getNodeStates(tree), statesBefore);
            assert.deepStrictEqual(agent.calls, callsBefore);
        });
    });

    describe("keeps the progress of", () => {
        // An agent for which each action either always succeeds or always fails, so only the node under test affects the outcome.
        const createCountingAgent = (result: State) => {
            const calls: string[] = [];
            return { calls, A: () => (calls.push("A"), result) };
        };

        const restoreInNewTree = (definition: string, tree: BehaviourTree, agent: Agent, random?: () => number) => {
            const restoredTree = new BehaviourTree(definition, agent, { random });
            restoredTree.restore(saveAndLoad(tree));
            return restoredTree;
        };

        for (const [nodeName, nodeType, result] of [
            ["a repeat node", "repeat", State.SUCCEEDED],
            ["a retry node", "retry", State.FAILED]
        ] as const) {
            const finalState = nodeType === "repeat" ? State.SUCCEEDED : State.FAILED;
            const [count, target] =
                nodeType === "repeat"
                    ? ["currentIterationCount", "targetIterationCount"]
                    : ["currentAttemptCount", "targetAttemptCount"];

            describe(nodeName, () => {
                it("including the number of iterations or attempts made so far", () => {
                    const definition = `root { ${nodeType} [4] { action [A] } }`;
                    const agent = createCountingAgent(result);
                    const tree = new BehaviourTree(definition, agent);

                    tree.step();
                    tree.step();

                    const snapshot = tree.snapshot().root.children![0];
                    assert.strictEqual((snapshot as any)[count], 2);
                    assert.strictEqual((snapshot as any)[target], 4);

                    const restoredAgent = createCountingAgent(result);
                    const restoredTree = restoreInNewTree(definition, tree, restoredAgent);

                    restoredTree.step();
                    restoredTree.step();
                    assert.strictEqual(restoredTree.getState(), State.RUNNING);
                    restoredTree.step();

                    assert.deepStrictEqual(restoredAgent.calls, ["A", "A"]);
                    assert.strictEqual(restoredTree.getState(), finalState);
                });

                it("including a target number of iterations or attempts that was picked at random", () => {
                    const definition = `root { ${nodeType} [2, 5] { action [A] } }`;
                    const agent = createCountingAgent(result);
                    const tree = new BehaviourTree(definition, agent, { random: () => 0.99 });

                    tree.step();
                    assert.strictEqual((tree.snapshot().root.children![0] as any)[target], 5);

                    // The random function of the restored tree would pick 2, but the target was already picked as 5.
                    const restoredAgent = createCountingAgent(result);
                    const restoredTree = restoreInNewTree(definition, tree, restoredAgent, () => 0);

                    for (let step = 0; step < 4; step++) {
                        restoredTree.step();
                        assert.strictEqual(restoredTree.getState(), State.RUNNING);
                    }
                    restoredTree.step();

                    assert.strictEqual(restoredAgent.calls.length, 4);
                    assert.strictEqual(restoredTree.getState(), finalState);
                });

                it("that has no limit on the number of iterations or attempts", () => {
                    const definition = `root { ${nodeType} { action [A] } }`;
                    const tree = new BehaviourTree(definition, createCountingAgent(result));
                    tree.step();
                    tree.step();

                    const snapshot = tree.snapshot().root.children![0] as any;
                    assert.strictEqual(snapshot[count], 2);
                    assert.strictEqual(snapshot[target], null);

                    const restoredAgent = createCountingAgent(result);
                    const restoredTree = restoreInNewTree(definition, tree, restoredAgent);
                    for (let step = 0; step < 10; step++) {
                        restoredTree.step();
                    }

                    assert.strictEqual(restoredAgent.calls.length, 10);
                    assert.strictEqual(restoredTree.getState(), State.RUNNING);
                });

                it("that finished, picking a new target at random for the next run", () => {
                    const definition = `root { ${nodeType} [2, 5] { action [A] } }`;
                    const tree = new BehaviourTree(definition, createCountingAgent(result), { random: () => 0.99 });
                    while (tree.getState() !== finalState) {
                        tree.step();
                    }

                    const restoredAgent = createCountingAgent(result);
                    const restoredTree = restoreInNewTree(definition, tree, restoredAgent, () => 0);
                    assert.strictEqual(restoredTree.getState(), finalState);

                    // The next run picks a target of 2 rather than the 5 picked for the run that finished.
                    restoredTree.step();
                    restoredTree.step();
                    restoredTree.step();

                    assert.strictEqual(restoredAgent.calls.length, 2);
                    assert.strictEqual(restoredTree.getState(), finalState);
                });

                it("and throws an error and leaves the tree unchanged if the snapshot has counts that are not possible for the definition", () => {
                    for (const [definitionArguments, state, targetValue, countValue, invalidProperty] of [
                        ["[3]", State.READY, 4, 0, target],
                        ["[3]", State.RUNNING, null, 0, target],
                        ["[2, 5]", State.RUNNING, 6, 0, target],
                        ["[2, 5]", State.RUNNING, 1, 0, target],
                        ["[2, 5]", State.RUNNING, null, 0, target],
                        ["", State.RUNNING, 3, 0, target],
                        ["[3]", State.RUNNING, 3, 4, count]
                    ] as [string, State, number | null, number, string][]) {
                        const tree = new BehaviourTree(
                            `root { ${nodeType} ${definitionArguments} { action [A] } }`,
                            createCountingAgent(result)
                        );
                        const statesBefore = getNodeStates(tree);
                        const snapshot = saveAndLoad(tree);
                        const nodeSnapshot = snapshot.root.children![0] as any;
                        nodeSnapshot.state = state;
                        nodeSnapshot[target] = targetValue;
                        nodeSnapshot[count] = countValue;

                        assert.throws(
                            () => tree.restore(snapshot),
                            Error,
                            `error restoring tree: expected snapshot of '${nodeSnapshot.name}' node to have a valid ${invalidProperty} but got '${nodeSnapshot[invalidProperty]}'`
                        );
                        assert.deepStrictEqual(getNodeStates(tree), statesBefore);
                    }
                });

                it("and restores an unbounded node that has made any number of iterations or attempts", () => {
                    const tree = new BehaviourTree(`root { ${nodeType} { action [A] } }`, createCountingAgent(result));
                    const snapshot = saveAndLoad(tree);
                    Object.assign(snapshot.root.children![0], { state: State.RUNNING, [count]: 1000, [target]: null });

                    tree.restore(snapshot);

                    assert.strictEqual(tree.snapshot().root.children![0][count as "currentIterationCount"], 1000);
                });

                it("and throws an error and leaves the tree unchanged if the snapshot has invalid counts", () => {
                    const definition = `root { ${nodeType} [2, 5] { action [A] } }`;
                    const tree = new BehaviourTree(definition, createCountingAgent(result));
                    const statesBefore = getNodeStates(tree);

                    for (const [property, value] of [
                        [count, -1],
                        [count, 1.5],
                        [count, "1"],
                        [count, undefined],
                        [target, -1],
                        [target, 2.5],
                        [target, undefined]
                    ]) {
                        const snapshot = saveAndLoad(tree);
                        (snapshot.root.children![0] as any)[property as string] = value;

                        assert.throws(
                            () => tree.restore(snapshot),
                            Error,
                            `error restoring tree: expected snapshot of '${nodeType.toUpperCase()} 2x-5x' node to have a valid ${property} but got '${value}'`
                        );
                        assert.deepStrictEqual(getNodeStates(tree), statesBefore);
                    }
                });
            });
        }
    });

    describe("keeps the child picked by a lotto node", () => {
        const definition = "root { lotto [1, 1, 1] { action [A] action [B] action [C] } }";

        it("so that the same child continues to run in a restored tree whatever it would pick at random", () => {
            for (const [randomInOriginal, randomInRestored] of [
                [0, 0.99],
                [0.99, 0],
                [0.5, 0.99]
            ]) {
                const agent = createAgent();
                const tree = new BehaviourTree(definition, agent, { random: () => randomInOriginal });
                tree.step();
                assert.lengthOf(agent.calls, 1);
                const pickedChildName = agent.calls[0];

                const restoredAgent = createAgent();
                const restoredTree = new BehaviourTree(definition, restoredAgent, { random: () => randomInRestored });
                restoredTree.restore(saveAndLoad(tree));
                restoredTree.step();
                restoredTree.step();

                assert.deepStrictEqual(restoredAgent.calls, [pickedChildName, pickedChildName]);
                assert.deepStrictEqual(
                    getNodeStates(restoredTree),
                    getNodeStates(tree).map(([name, state]) =>
                        name === pickedChildName ? [name, State.RUNNING] : [name, state]
                    )
                );
            }
        });

        it("which is the index of the picked child, or null if no child has been picked", () => {
            const tree = new BehaviourTree(definition, createAgent(), { random: () => 0 });
            assert.strictEqual(tree.snapshot().root.children![0].selectedChildIndex, null);

            tree.step();
            assert.strictEqual(tree.snapshot().root.children![0].selectedChildIndex, 0);
        });

        it("and picks a child again when the next run starts after a restored tree had finished", () => {
            const agent = createAgent();
            agent.results.A = State.SUCCEEDED;
            agent.results.B = State.SUCCEEDED;
            agent.results.C = State.SUCCEEDED;
            const tree = new BehaviourTree(definition, agent, { random: () => 0 });
            tree.step();
            assert.strictEqual(tree.getState(), State.SUCCEEDED);
            assert.deepStrictEqual(agent.calls, ["A"]);

            const restoredAgent = createAgent();
            restoredAgent.results.C = State.SUCCEEDED;
            const restoredTree = new BehaviourTree(definition, restoredAgent, { random: () => 0.99 });
            restoredTree.restore(saveAndLoad(tree));
            assert.strictEqual(restoredTree.getState(), State.SUCCEEDED);

            restoredTree.step();

            assert.deepStrictEqual(restoredAgent.calls, ["C"]);
        });

        it("and throws an error and leaves the tree unchanged if a running lotto node has no child picked", () => {
            const tree = new BehaviourTree(definition, createAgent());
            const statesBefore = getNodeStates(tree);
            const snapshot = saveAndLoad(tree);
            snapshot.root.children![0].state = State.RUNNING;

            assert.throws(
                () => tree.restore(snapshot),
                Error,
                "error restoring tree: expected snapshot of 'LOTTO [1,1,1]' node to have a valid selectedChildIndex but got 'null'"
            );
            assert.deepStrictEqual(getNodeStates(tree), statesBefore);
        });

        it("and throws an error and leaves the tree unchanged if the snapshot has an invalid child index", () => {
            const tree = new BehaviourTree(definition, createAgent());
            const statesBefore = getNodeStates(tree);

            for (const value of [-1, 3, 1.5, "1", undefined]) {
                const snapshot = saveAndLoad(tree);
                snapshot.root.state = State.RUNNING;
                snapshot.root.children![0].selectedChildIndex = value as number;

                assert.throws(
                    () => tree.restore(snapshot),
                    Error,
                    `error restoring tree: expected snapshot of 'LOTTO [1,1,1]' node to have a valid selectedChildIndex but got '${value}'`
                );
                assert.deepStrictEqual(getNodeStates(tree), statesBefore);
            }
        });
    });

    describe("keeps how long a wait node has waited", () => {
        const HOUR = 60 * 60 * 1000;

        let clock: SinonFakeTimers;

        beforeEach(() => (clock = sinon.useFakeTimers()));
        afterEach(() => clock.restore());

        const getWaitState = (tree: BehaviourTree) => getNodeStates(tree).find(([name]) => name.startsWith("WAIT"))![1];

        describe("using the clock", () => {
            const definition = "root { wait [1000] }";

            it("so that a restored tree only waits for the time that was remaining", () => {
                const tree = new BehaviourTree(definition, {});
                tree.step();
                clock.tick(400);
                tree.step();
                const snapshot = saveAndLoad(tree);

                // A long time passes before the tree is restored, none of which should count as time waited.
                clock.tick(5 * 24 * HOUR);
                const restoredTree = new BehaviourTree(definition, {});
                restoredTree.restore(snapshot);

                restoredTree.step();
                assert.strictEqual(getWaitState(restoredTree), State.RUNNING);

                clock.tick(599);
                restoredTree.step();
                assert.strictEqual(getWaitState(restoredTree), State.RUNNING);

                clock.tick(1);
                restoredTree.step();
                assert.strictEqual(getWaitState(restoredTree), State.SUCCEEDED);
                assert.strictEqual(restoredTree.getState(), State.SUCCEEDED);
            });

            it("including time that passed since the tree was last stepped", () => {
                const tree = new BehaviourTree(definition, {});
                tree.step();

                // The tree is not stepped again before the snapshot is taken, but the original tree would have waited for this time.
                clock.tick(400);
                const snapshot = saveAndLoad(tree);

                clock.tick(HOUR);
                const restoredTree = new BehaviourTree(definition, {});
                restoredTree.restore(snapshot);

                clock.tick(599);
                restoredTree.step();
                assert.strictEqual(getWaitState(restoredTree), State.RUNNING);

                clock.tick(1);
                restoredTree.step();
                assert.strictEqual(getWaitState(restoredTree), State.SUCCEEDED);
            });

            it("so that a restored tree that is not stepped for a time is not affected by the restore itself", () => {
                const tree = new BehaviourTree(definition, {});
                tree.step();
                clock.tick(400);
                const snapshot = saveAndLoad(tree);

                const restoredTree = new BehaviourTree(definition, {});
                clock.tick(HOUR);
                restoredTree.restore(snapshot);
                clock.tick(600);
                restoredTree.step();

                assert.strictEqual(getWaitState(restoredTree), State.SUCCEEDED);
            });

            it("and when restoring the snapshot to the tree it was taken from", () => {
                const tree = new BehaviourTree(definition, {});
                tree.step();
                clock.tick(400);
                const snapshot = saveAndLoad(tree);

                clock.tick(HOUR);
                tree.restore(snapshot);
                clock.tick(599);
                tree.step();
                assert.strictEqual(getWaitState(tree), State.RUNNING);

                clock.tick(1);
                tree.step();
                assert.strictEqual(getWaitState(tree), State.SUCCEEDED);
            });
        });

        describe("using the getDeltaTime option", () => {
            const definition = "root { wait [1000] }";

            it("so that a restored tree only waits for the time that was remaining", () => {
                const tree = new BehaviourTree(definition, {}, { getDeltaTime: () => 0.25 });
                tree.step();
                tree.step();
                const snapshot = saveAndLoad(tree);

                // Time passing on the clock is not time waited when using getDeltaTime.
                clock.tick(5 * 24 * HOUR);
                const restoredTree = new BehaviourTree(definition, {}, { getDeltaTime: () => 0.25 });
                restoredTree.restore(snapshot);

                restoredTree.step();
                assert.strictEqual(getWaitState(restoredTree), State.RUNNING);

                restoredTree.step();
                assert.strictEqual(getWaitState(restoredTree), State.SUCCEEDED);
            });

            it("whatever the delta times used after the restore", () => {
                const tree = new BehaviourTree(definition, {}, { getDeltaTime: () => 0.4 });
                tree.step();
                const snapshot = saveAndLoad(tree);

                let deltaTime = 0.3;
                const restoredTree = new BehaviourTree(definition, {}, { getDeltaTime: () => deltaTime });
                restoredTree.restore(snapshot);

                restoredTree.step();
                assert.strictEqual(getWaitState(restoredTree), State.RUNNING);

                deltaTime = 0.3;
                restoredTree.step();
                assert.strictEqual(getWaitState(restoredTree), State.SUCCEEDED);
            });
        });

        it("and the random duration it picked, whatever the random function of a restored tree would pick", () => {
            const definition = "root { wait [100, 900] }";
            const tree = new BehaviourTree(definition, {}, { random: () => 0.9999 });
            tree.step();
            assert.strictEqual(tree.snapshot().root.children![0].totalDuration, 900);
            clock.tick(500);
            const snapshot = saveAndLoad(tree);

            const restoredTree = new BehaviourTree(definition, {}, { random: () => 0 });
            restoredTree.restore(snapshot);

            restoredTree.step();
            assert.strictEqual(getWaitState(restoredTree), State.RUNNING);

            clock.tick(399);
            restoredTree.step();
            assert.strictEqual(getWaitState(restoredTree), State.RUNNING);

            clock.tick(1);
            restoredTree.step();
            assert.strictEqual(getWaitState(restoredTree), State.SUCCEEDED);
        });

        it("and keeps waiting indefinitely if there was no duration", () => {
            const definition = "root { wait }";
            const tree = new BehaviourTree(definition, {});
            tree.step();
            const snapshot = saveAndLoad(tree);

            const restoredTree = new BehaviourTree(definition, {});
            restoredTree.restore(snapshot);
            clock.tick(100 * 24 * HOUR);
            restoredTree.step();

            assert.strictEqual(getWaitState(restoredTree), State.RUNNING);
        });

        it("and picks a new random duration for the next run after a restored tree had finished", () => {
            const definition = "root { wait [100, 900] }";
            const tree = new BehaviourTree(definition, {}, { random: () => 0.9999 });
            tree.step();
            clock.tick(900);
            tree.step();
            assert.strictEqual(tree.getState(), State.SUCCEEDED);

            const restoredTree = new BehaviourTree(definition, {}, { random: () => 0 });
            restoredTree.restore(saveAndLoad(tree));
            assert.strictEqual(restoredTree.getState(), State.SUCCEEDED);

            restoredTree.step();
            assert.strictEqual(restoredTree.getState(), State.RUNNING);
            clock.tick(100);
            restoredTree.step();
            assert.strictEqual(restoredTree.getState(), State.SUCCEEDED);
        });

        it("and throws an error and leaves the tree unchanged if the snapshot has a total duration that is not possible for the definition", () => {
            for (const [definitionArguments, state, totalDuration] of [
                ["[1000]", State.READY, 999],
                ["[1000]", State.RUNNING, null],
                ["[100, 900]", State.RUNNING, 901],
                ["[100, 900]", State.RUNNING, 99],
                ["[100, 900]", State.RUNNING, null],
                ["", State.RUNNING, 5]
            ] as [string, State, number | null][]) {
                const tree = new BehaviourTree(`root { wait ${definitionArguments} }`, {});
                const statesBefore = getNodeStates(tree);
                const snapshot = saveAndLoad(tree);
                snapshot.root.children![0].state = state;
                snapshot.root.children![0].totalDuration = totalDuration;

                assert.throws(
                    () => tree.restore(snapshot),
                    Error,
                    `to have a valid totalDuration but got '${totalDuration}'`
                );
                assert.deepStrictEqual(getNodeStates(tree), statesBefore);
            }
        });

        it("and can be saved as JSON when an infinite time has been waited", () => {
            const definition = "root { wait [1000] }";
            const tree = new BehaviourTree(definition, {}, { getDeltaTime: () => Infinity });
            tree.step();

            const snapshot = tree.snapshot();
            assert.deepStrictEqual(JSON.parse(JSON.stringify(snapshot)), snapshot);

            const restoredTree = new BehaviourTree(definition, {});
            restoredTree.restore(snapshot);
            assert.strictEqual(restoredTree.getState(), State.SUCCEEDED);
        });

        it("and throws an error and leaves the tree unchanged if the snapshot has invalid durations", () => {
            const tree = new BehaviourTree("root { wait [100, 900] }", {});
            const statesBefore = getNodeStates(tree);

            for (const [property, value] of [
                ["totalDuration", -1],
                ["totalDuration", 1.5],
                ["totalDuration", "100"],
                ["totalDuration", undefined],
                ["waitedDuration", null],
                ["waitedDuration", "100"],
                ["waitedDuration", undefined]
            ]) {
                const snapshot = saveAndLoad(tree);
                (snapshot.root.children![0] as any)[property as string] = value;

                assert.throws(
                    () => tree.restore(snapshot),
                    Error,
                    `error restoring tree: expected snapshot of 'WAIT 100ms-900ms' node to have a valid ${property} but got '${value}'`
                );
                assert.deepStrictEqual(getNodeStates(tree), statesBefore);
            }
        });
    });

    describe("keeps the outcome of a promise returned by an action", () => {
        const definition = "root { action [doAction] }";

        const settle = () => new Promise((resolve) => setTimeout(resolve, 0));

        const createPromiseAgent = (promise?: Promise<unknown>) => {
            const calls: string[] = [];
            return { calls, doAction: () => (calls.push("doAction"), promise) };
        };

        const getActionState = (tree: BehaviourTree) => getNodeStates(tree)[1][1];

        for (const result of [State.SUCCEEDED, State.FAILED]) {
            it(`so that a promise that resolved to ${result} is not waited for or called again in a restored tree`, async () => {
                const agent = createPromiseAgent(Promise.resolve(result));
                const tree = new BehaviourTree(definition, agent);
                tree.step();
                await settle();

                // The tree is not stepped after the promise has settled, so the node is still running.
                const snapshot = saveAndLoad(tree);
                assert.strictEqual(getActionState(tree), State.RUNNING);

                const restoredAgent = createPromiseAgent();
                const restoredTree = new BehaviourTree(definition, restoredAgent);
                restoredTree.restore(snapshot);
                restoredTree.step();

                assert.strictEqual(getActionState(restoredTree), result);
                assert.deepStrictEqual(restoredAgent.calls, []);
            });
        }

        it("so that a promise that was rejected still causes an error to be thrown in a restored tree", async () => {
            const tree = new BehaviourTree(definition, createPromiseAgent(Promise.reject(new Error("some-error"))));
            tree.step();
            await settle();
            const snapshot = saveAndLoad(tree);

            const restoredAgent = createPromiseAgent();
            const restoredTree = new BehaviourTree(definition, restoredAgent);
            restoredTree.restore(snapshot);

            assert.throws(
                () => restoredTree.step(),
                Error,
                "error stepping tree: action function 'doAction' promise rejected with 'Error: some-error'"
            );
            assert.deepStrictEqual(restoredAgent.calls, []);
        });

        it("so that a promise that resolved with an invalid value still causes an error to be thrown in a restored tree", async () => {
            const tree = new BehaviourTree(definition, createPromiseAgent(Promise.resolve({ not: "a state" })));
            tree.step();
            await settle();

            const restoredTree = new BehaviourTree(definition, createPromiseAgent());
            restoredTree.restore(saveAndLoad(tree));

            assert.throws(
                () => restoredTree.step(),
                Error,
                "error stepping tree: action node promise resolved with an invalid value, expected a State.SUCCEEDED or State.FAILED value to be returned"
            );
        });

        describe("so that an action whose promise has not settled is saved as not yet started and", () => {
            const entryDefinition = "root { action [doAction] entry(onEntry) }";

            it("is restored as READY with its action function called again on the next step", async () => {
                const tree = new BehaviourTree(definition, createPromiseAgent(new Promise(() => {})));
                tree.step();
                const snapshot = saveAndLoad(tree);
                assert.strictEqual(snapshot.root.children![0].state, State.READY);
                assert.strictEqual(snapshot.root.children![0].updatePromiseResult, null);

                // A pending promise cannot be saved, so the restored tree has to start the action again.
                const restoredAgent = createPromiseAgent(Promise.resolve(State.SUCCEEDED));
                const restoredTree = new BehaviourTree(definition, restoredAgent);
                restoredTree.restore(snapshot);
                assert.strictEqual(getActionState(restoredTree), State.READY);
                assert.deepStrictEqual(restoredAgent.calls, []);

                restoredTree.step();
                assert.deepStrictEqual(restoredAgent.calls, ["doAction"]);
                assert.strictEqual(getActionState(restoredTree), State.RUNNING);

                await settle();
                restoredTree.step();
                assert.strictEqual(getActionState(restoredTree), State.SUCCEEDED);
                assert.deepStrictEqual(restoredAgent.calls, ["doAction"]);
            });

            it("calls its entry callback again, as it does for any action that is starting", () => {
                const calls: string[] = [];
                const createEntryAgent = (promise?: Promise<unknown>) => ({
                    doAction: () => (calls.push("doAction"), promise),
                    onEntry: () => calls.push("onEntry")
                });

                const tree = new BehaviourTree(entryDefinition, createEntryAgent(new Promise(() => {})));
                tree.step();
                assert.deepStrictEqual(calls, ["onEntry", "doAction"]);
                calls.length = 0;

                const restoredTree = new BehaviourTree(entryDefinition, createEntryAgent());
                restoredTree.restore(saveAndLoad(tree));
                assert.deepStrictEqual(calls, []);

                restoredTree.step();
                assert.deepStrictEqual(calls, ["onEntry", "doAction"]);
            });

            it("is only saved this way by the snapshot, the tree it was taken from carries on waiting for the promise", async () => {
                let resolve: (value: State) => void = () => {};
                const agent = createPromiseAgent(new Promise<State>((r) => (resolve = r)));
                const tree = new BehaviourTree(definition, agent);
                tree.step();

                tree.snapshot();
                assert.strictEqual(getActionState(tree), State.RUNNING);

                resolve(State.SUCCEEDED);
                await settle();
                tree.step();
                assert.strictEqual(getActionState(tree), State.SUCCEEDED);
                assert.deepStrictEqual(agent.calls, ["doAction"]);
            });

            it("is not confused with an action that is running without a promise, which is restored as RUNNING without starting again", () => {
                const calls: string[] = [];
                const createEntryAgent = () => ({
                    doAction: () => void calls.push("doAction"),
                    onEntry: () => calls.push("onEntry")
                });

                const tree = new BehaviourTree(entryDefinition, createEntryAgent());
                tree.step();
                const snapshot = saveAndLoad(tree);
                assert.strictEqual(snapshot.root.children![0].state, State.RUNNING);
                calls.length = 0;

                const restoredTree = new BehaviourTree(entryDefinition, createEntryAgent());
                restoredTree.restore(snapshot);
                assert.strictEqual(getActionState(restoredTree), State.RUNNING);

                restoredTree.step();
                assert.deepStrictEqual(calls, ["doAction"]);
            });

            it("is saved as READY when its tree is nested in running composite nodes, which stay RUNNING", () => {
                const nestedDefinition = "root { sequence { action [A] action [doAction] } }";
                const agent = { A: () => State.SUCCEEDED, doAction: () => new Promise(() => {}) };
                const tree = new BehaviourTree(nestedDefinition, agent);
                tree.step();

                const restoredTree = new BehaviourTree(nestedDefinition, agent);
                restoredTree.restore(saveAndLoad(tree));

                assert.deepStrictEqual(getNodeStates(restoredTree), [
                    ["ROOT", State.RUNNING],
                    ["SEQUENCE", State.RUNNING],
                    ["A", State.SUCCEEDED],
                    ["doAction", State.READY]
                ]);
            });
        });

        it("so that a promise from before a restore to the same tree cannot settle the action that is started again", async () => {
            const resolvers: ((value: State) => void)[] = [];
            const calls: string[] = [];
            const agent = {
                doAction: () => {
                    calls.push("doAction");
                    return new Promise<State>((resolve) => resolvers.push(resolve));
                }
            };
            const tree = new BehaviourTree(definition, agent);
            tree.step();
            const snapshot = saveAndLoad(tree);

            tree.restore(snapshot);
            tree.step();
            assert.strictEqual(resolvers.length, 2);

            resolvers[0](State.SUCCEEDED);
            await settle();
            tree.step();
            assert.strictEqual(getActionState(tree), State.RUNNING);

            resolvers[1](State.FAILED);
            await settle();
            tree.step();
            assert.strictEqual(getActionState(tree), State.FAILED);
        });

        it("so that a snapshot can still be taken when the promise was rejected with something that cannot be converted to a string", async () => {
            const tree = new BehaviourTree(definition, createPromiseAgent(Promise.reject(Object.create(null))));
            tree.step();
            await settle();

            const snapshot = tree.snapshot();

            assert.isTrue(snapshot.root.children![0].updatePromiseResult!.isResolved === false);
            assert.deepStrictEqual(JSON.parse(JSON.stringify(snapshot)), snapshot);
        });

        it("and throws an error and leaves the tree unchanged if the snapshot has an invalid outcome", () => {
            const tree = new BehaviourTree(definition, createPromiseAgent());
            const statesBefore = getNodeStates(tree);

            for (const value of [
                undefined,
                1,
                "settled",
                { isResolved: true },
                { isResolved: "yes", value: "x" },
                { value: "x" }
            ]) {
                const snapshot = saveAndLoad(tree);
                snapshot.root.children![0].updatePromiseResult = value as any;

                assert.throws(
                    () => tree.restore(snapshot),
                    Error,
                    "error restoring tree: expected snapshot of 'doAction' node to have a valid updatePromiseResult but got"
                );
                assert.deepStrictEqual(getNodeStates(tree), statesBefore);
            }
        });
    });

    describe("is independent of the trees it is taken from and restored to so that", () => {
        let clock: SinonFakeTimers;

        beforeEach(() => (clock = sinon.useFakeTimers()));
        afterEach(() => clock.restore());

        const settle = () => clock.tickAsync(0);

        const createIndependenceTree = (definition: Definition, results: { [name: string]: unknown }) => {
            const agent = {
                A: () => results.A as State | undefined,
                B: () => results.B as State | undefined,
                P: () => results.P as Promise<State>
            };

            return new BehaviourTree(definition, agent, { getDeltaTime: () => 0.1, random: () => 0.5 });
        };

        for (const [description, definition, results] of [
            ["repeat", "root { repeat [2,6] { action [A] } }", { A: State.SUCCEEDED }],
            ["retry", "root { retry [2,6] { action [A] } }", { A: State.FAILED }],
            ["lotto", "root { lotto [1,2,3] { action [A] action [B] action [A] } }", {}],
            ["wait", "root { sequence { wait [500,1500] action [A] } }", { A: State.SUCCEEDED }],
            ["action", "root { sequence { action [P] action [A] } }", { P: Promise.resolve(State.SUCCEEDED) }]
        ] as [string, Definition, { [name: string]: unknown }][]) {
            describe(description, () => {
                const stepAndTakeSnapshot = async () => {
                    const tree = createIndependenceTree(definition, results);
                    tree.step();
                    await settle();
                    return { tree, snapshot: tree.snapshot() };
                };

                it("stepping the tree does not change a snapshot taken from it", async () => {
                    const { tree, snapshot } = await stepAndTakeSnapshot();
                    const expected = JSON.parse(JSON.stringify(snapshot));

                    for (let step = 0; step < 4; step++) {
                        tree.step();
                        await settle();
                        clock.tick(100);
                    }

                    assert.deepStrictEqual(snapshot, expected);
                });

                it("stepping a restored tree does not change the snapshot that it was restored from", async () => {
                    const { snapshot } = await stepAndTakeSnapshot();
                    const expected = JSON.parse(JSON.stringify(snapshot));

                    const restoredTree = createIndependenceTree(definition, results);
                    restoredTree.restore(snapshot);

                    for (let step = 0; step < 4; step++) {
                        restoredTree.step();
                        await settle();
                        clock.tick(100);
                    }

                    assert.deepStrictEqual(snapshot, expected);
                });

                it("a snapshot taken after a restore and before any step equals the snapshot that was restored", async () => {
                    const { snapshot } = await stepAndTakeSnapshot();

                    const restoredTree = createIndependenceTree(definition, results);
                    restoredTree.restore(JSON.parse(JSON.stringify(snapshot)));

                    assert.deepStrictEqual(
                        JSON.parse(JSON.stringify(restoredTree.snapshot())),
                        JSON.parse(JSON.stringify(snapshot))
                    );
                });
            });
        }
    });

    describe("keeps which definition a snapshot belongs to", () => {
        const definition = "root { sequence { action [A, 1] wait [100] repeat [3] { action [B] } } }";

        const createTree = (treeDefinition: Definition) => {
            const agent = createAgent();
            agent.results.A = State.SUCCEEDED;
            const tree = new BehaviourTree(treeDefinition, agent);
            tree.step();
            return tree;
        };

        const getNodeStatesAfterFailedRestore = (treeDefinition: string, snapshot: BehaviourTreeSnapshot) => {
            const tree = createTree(treeDefinition);
            const statesBefore = getNodeStates(tree);

            assert.throws(
                () => tree.restore(snapshot),
                Error,
                "error restoring tree: snapshot does not match the tree's definition"
            );

            assert.deepStrictEqual(getNodeStates(tree), statesBefore);
        };

        it("as a string that is unchanged by passing it through JSON", () => {
            const snapshot = createTree(definition).snapshot();

            assert.isString(snapshot.definition);
            assert.isNotEmpty(snapshot.definition);
            assert.deepStrictEqual(JSON.parse(JSON.stringify(snapshot)), snapshot);
        });

        it("that is the same for every tree and every snapshot of the same definition", () => {
            const tree = createTree(definition);
            const before = tree.snapshot().definition;
            tree.step();

            assert.strictEqual(tree.snapshot().definition, before);
            assert.strictEqual(new BehaviourTree(definition, createAgent()).snapshot().definition, before);
        });

        it("that stays the same between versions and environments, as snapshots are saved and restored by different processes", () => {
            const tree = new BehaviourTree(
                "root { sequence { action [A, 1] branch [a] branch [B] } } root [B] { action [X] } root [a] { action [Y] }",
                createAgent()
            );

            assert.strictEqual(tree.snapshot().definition, "1ebd4c2d478f381e7f44edbbc09a");
        });

        it("so that a snapshot is rejected by a tree of a different definition that has nodes of the same types and names", () => {
            const differentDefinitions = [
                "root { sequence { action [A, 2] wait [100] repeat [3] { action [B] } } }",
                "root { sequence { action [A, 1] wait [101] repeat [3] { action [B] } } }",
                "root { sequence { action [A, 1] wait [100] repeat [4] { action [B] } } }",
                "root { sequence { action [A, 1] wait [100] repeat [3] { action [B] entry(onEntry) } } }",
                "root { sequence { action [A, 1] wait [100] repeat [3] { action [B] } } } root [other] { action [C] }",
                `root { sequence { action [A, "1"] wait [100] repeat [3] { action [B] } } }`
            ];
            const snapshot = JSON.parse(JSON.stringify(createTree(definition).snapshot()));

            for (const differentDefinition of differentDefinitions) {
                getNodeStatesAfterFailedRestore(differentDefinition, snapshot);
            }
        });

        it("so that a snapshot is rejected by a tree of a different definition that has different nodes", () => {
            const snapshot = createTree(definition).snapshot();

            getNodeStatesAfterFailedRestore("root { selector { action [A] action [B] } }", snapshot);
            getNodeStatesAfterFailedRestore("root { action [A] }", snapshot);
        });

        it("so that a snapshot is restored by a tree of the same definition", () => {
            const snapshot = JSON.parse(JSON.stringify(createTree(definition).snapshot()));
            const restoredTree = new BehaviourTree(definition, createAgent());

            restoredTree.restore(snapshot);

            assert.deepStrictEqual(getNodeStates(restoredTree), getNodeStates(createTree(definition)));
        });

        describe("so that an MDSL definition and its equivalent JSON definition are the same definition, including when the JSON", () => {
            const mdsl = `root {
                sequence while(isOk) entry(onEntry, 1, "a", null, true, $x) {
                    action [A, 1]
                    condition [ok]
                    wait [100]
                    repeat [3] { action [B] }
                    lotto [1, 2] { action [C] action [D] }
                }
            }
            root [sub] { action [E] }`;

            const json: RootNodeDefinition[] = [
                {
                    type: "root",
                    child: {
                        type: "sequence",
                        while: { call: "isOk" },
                        entry: { call: "onEntry", args: [1, "a", null, true, { $: "x" }] },
                        children: [
                            { type: "action", call: "A", args: [1] },
                            { type: "condition", call: "ok" },
                            { type: "wait", duration: 100 },
                            { type: "repeat", iterations: 3, child: { type: "action", call: "B" } },
                            {
                                type: "lotto",
                                weights: [1, 2],
                                children: [
                                    { type: "action", call: "C" },
                                    { type: "action", call: "D" }
                                ]
                            }
                        ]
                    }
                } as RootNodeDefinition,
                { type: "root", id: "sub", child: { type: "action", call: "E" } }
            ];

            const check = (a: Definition, b: Definition) => {
                const snapshot = JSON.parse(JSON.stringify(new BehaviourTree(a, createAgent()).snapshot()));
                const restoredTree = new BehaviourTree(b, createAgent());

                assert.strictEqual(snapshot.definition, restoredTree.snapshot().definition);
                restoredTree.restore(snapshot);
            };

            it("omits empty arguments and false flags", () => {
                check(mdsl, json);
                check(json, mdsl);
            });

            it("has its properties in a different order", () => {
                const reordered: RootNodeDefinition[] = JSON.parse(JSON.stringify(json), (_, value) =>
                    value && typeof value === "object" && !Array.isArray(value)
                        ? Object.fromEntries(Object.entries(value).reverse())
                        : value
                );

                check(mdsl, reordered);
                check(reordered, json);
            });

            it("has its root nodes in a different order", () => {
                check(mdsl, [...json].reverse());
            });

            it("has the single main root node as an object", () => {
                check("root { action [A] }", { type: "root", child: { type: "action", call: "A" } });
            });

            it("has explicit empty arguments and a false succeedOnAbort", () => {
                check("root { action [A] while(x) }", {
                    type: "root",
                    child: {
                        type: "action",
                        call: "A",
                        args: [],
                        while: { call: "x", args: [], succeedOnAbort: false }
                    }
                } as RootNodeDefinition);
            });
        });

        it("so that a JSON definition that differs from an MDSL definition is a different definition", () => {
            const snapshot = new BehaviourTree("root { action [A, 1] }", createAgent()).snapshot();
            const restoredTree = new BehaviourTree(
                { type: "root", child: { type: "action", call: "A", args: [2] } },
                createAgent()
            );

            assert.throws(
                () => restoredTree.restore(snapshot),
                Error,
                "error restoring tree: snapshot does not match the tree's definition"
            );
        });
    });

    describe("has a restore method that", () => {
        it("gives a tree built from the same definition the same node states as the tree that was snapshotted", () => {
            const definition = `root {
                sequence {
                    action [A]
                    selector {
                        condition [isFalse]
                        action [B]
                    }
                    action [D]
                }
            }`;

            const agent = { ...createAgent(), isFalse: () => false };
            agent.results.A = State.SUCCEEDED;
            const tree = new BehaviourTree(definition, agent);

            tree.step();

            const restoredTree = new BehaviourTree(definition, { ...createAgent(), isFalse: () => false });
            restoredTree.restore(saveAndLoad(tree));

            assert.deepStrictEqual(getNodeStates(restoredTree), getNodeStates(tree));
            assert.strictEqual(restoredTree.getState(), State.RUNNING);
            assert.isTrue(restoredTree.isRunning());
        });

        it("resumes a restored tree where it left off without calling the agent functions of nodes that had already finished", () => {
            const definition = "root { sequence { action [A] action [B] action [C] } }";

            const agent = createAgent();
            agent.results.A = State.SUCCEEDED;
            const tree = new BehaviourTree(definition, agent);
            tree.step();
            assert.deepStrictEqual(agent.calls, ["A", "B"]);

            const restoredAgent = createAgent();
            restoredAgent.results.B = State.SUCCEEDED;
            restoredAgent.results.C = State.SUCCEEDED;
            const restoredTree = new BehaviourTree(definition, restoredAgent);
            restoredTree.restore(saveAndLoad(tree));

            restoredTree.step();

            assert.deepStrictEqual(restoredAgent.calls, ["B", "C"]);
            assert.strictEqual(restoredTree.getState(), State.SUCCEEDED);
        });

        for (const [description, definition, setUp, expectedCalls] of [
            ["a selector", "root { selector { action [A] action [B] action [C] } }", { A: State.FAILED }, ["B"]],
            [
                "a parallel",
                "root { parallel { action [A] action [B] action [C] } }",
                { A: State.SUCCEEDED },
                ["B", "C"]
            ],
            ["a race", "root { race { action [A] action [B] action [C] } }", { A: State.FAILED }, ["B", "C"]],
            ["an all", "root { all { action [A] action [B] action [C] } }", { A: State.SUCCEEDED }, ["B", "C"]],
            [
                "decorators",
                "root { flip { succeed { fail { sequence { action [A] action [B] } } } } }",
                { A: State.SUCCEEDED },
                ["B"]
            ]
        ] as [string, string, { [name: string]: State }, string[]][]) {
            it(`restores the state of the children of ${description} that are finished and running`, () => {
                const agent = createAgent();
                Object.assign(agent.results, setUp);
                const tree = new BehaviourTree(definition, agent);
                tree.step();

                const restoredAgent = createAgent();
                const restoredTree = new BehaviourTree(definition, restoredAgent);
                restoredTree.restore(saveAndLoad(tree));

                assert.deepStrictEqual(getNodeStates(restoredTree), getNodeStates(tree));

                restoredTree.step();

                assert.deepStrictEqual(restoredAgent.calls, expectedCalls);
            });
        }

        it("restores a finished tree as finished and starts a new run on the next step", () => {
            const definition = "root { sequence { action [A] action [B] } }";

            const agent = createAgent();
            agent.results.A = State.SUCCEEDED;
            agent.results.B = State.SUCCEEDED;
            const tree = new BehaviourTree(definition, agent);
            tree.step();
            assert.strictEqual(tree.getState(), State.SUCCEEDED);

            const restoredAgent = createAgent();
            restoredAgent.results.A = State.SUCCEEDED;
            const restoredTree = new BehaviourTree(definition, restoredAgent);
            restoredTree.restore(saveAndLoad(tree));

            assert.strictEqual(restoredTree.getState(), State.SUCCEEDED);
            assert.deepStrictEqual(getNodeStates(restoredTree), getNodeStates(tree));

            restoredTree.step();

            assert.deepStrictEqual(restoredAgent.calls, ["A", "B"]);
            assert.strictEqual(restoredTree.getState(), State.RUNNING);
        });

        it("restores a tree that has not been stepped", () => {
            const definition = "root { action [A] }";
            const tree = new BehaviourTree(definition, createAgent());

            const restoredAgent = createAgent();
            const restoredTree = new BehaviourTree(definition, restoredAgent);
            restoredTree.step();
            restoredTree.restore(saveAndLoad(tree));

            assert.strictEqual(restoredTree.getState(), State.READY);
            assert.deepStrictEqual(getNodeStates(restoredTree), getNodeStates(tree));
        });

        it("replaces the progress of a tree that has already been stepped, including when restoring to its own snapshot", () => {
            const agent = createAgent();
            agent.results.A = State.SUCCEEDED;
            const tree = new BehaviourTree("root { sequence { action [A] action [B] action [C] } }", agent);

            tree.step();
            const snapshot = saveAndLoad(tree);
            const statesAtSnapshot = getNodeStates(tree);

            agent.results.B = State.SUCCEEDED;
            agent.results.C = State.SUCCEEDED;
            tree.step();
            assert.strictEqual(tree.getState(), State.SUCCEEDED);

            tree.restore(snapshot);

            assert.deepStrictEqual(getNodeStates(tree), statesAtSnapshot);
        });

        it("does not call any agent functions, including exit callbacks of nodes that were running", () => {
            const definition = "root { sequence { action [A] exit(onExit) } }";

            const agent = { ...createAgent(), onExit: sinon.stub() };
            const tree = new BehaviourTree(definition, agent);
            tree.step();
            const snapshotOfRunningTree = saveAndLoad(tree);
            agent.calls.length = 0;
            agent.onExit.resetHistory();

            tree.restore(snapshotOfRunningTree);
            new BehaviourTree(definition, agent).restore(snapshotOfRunningTree);

            assert.deepStrictEqual(agent.calls, []);
            sinon.assert.notCalled(agent.onExit);
        });

        it("does not call the onNodeStateChange handler, and the next step reports state changes as usual", () => {
            const definition = "root { sequence { action [A] action [B] } }";

            const agent = createAgent();
            agent.results.A = State.SUCCEEDED;
            const tree = new BehaviourTree(definition, agent);
            tree.step();

            const changes: [string, State, State][] = [];
            const restoredAgent = createAgent();
            restoredAgent.results.B = State.SUCCEEDED;
            const restoredTree = new BehaviourTree(definition, restoredAgent, {
                onNodeStateChange: ({ type, previousState, state }) => changes.push([type, previousState, state])
            });
            restoredTree.restore(saveAndLoad(tree));

            assert.deepStrictEqual(changes, []);

            restoredTree.step();

            assert.sameDeepMembers(changes, [
                ["action", State.RUNNING, State.SUCCEEDED],
                ["sequence", State.RUNNING, State.SUCCEEDED],
                ["root", State.RUNNING, State.SUCCEEDED]
            ]);
        });

        describe("throws an error and leaves the tree unchanged if", () => {
            const definition = "root { sequence { action [A] action [B] } }";

            const createRunningTree = () => {
                const agent = createAgent();
                agent.results.A = State.SUCCEEDED;
                const tree = new BehaviourTree(definition, agent);
                tree.step();
                return { agent, tree };
            };

            const expectRestoreToThrow = (snapshot: unknown, message: string) => {
                const { tree } = createRunningTree();
                const statesBefore = getNodeStates(tree);

                assert.throws(() => tree.restore(snapshot as BehaviourTreeSnapshot), Error, message);

                assert.deepStrictEqual(getNodeStates(tree), statesBefore);
            };

            /**
             * Creates a snapshot of a tree that is different to the one under test but claims to be of the same definition,
             * so that it gets as far as the checks of the individual nodes.
             */
            const createSnapshotOfOtherTree = (otherDefinition: string): BehaviourTreeSnapshot => ({
                ...saveAndLoad(new BehaviourTree(otherDefinition, createAgent())),
                definition: new BehaviourTree(definition, createAgent()).snapshot().definition
            });

            it("the snapshot is not an object", () => {
                for (const snapshot of [undefined, null, "snapshot", 42, []]) {
                    expectRestoreToThrow(snapshot, "error restoring tree: expected snapshot to be an object");
                }
            });

            it("the snapshot is an object that does not have the fields of a snapshot", () => {
                const snapshot = createSnapshotOfOtherTree(definition);

                expectRestoreToThrow({}, "error restoring tree: unsupported snapshot version 'undefined'");
                expectRestoreToThrow(
                    { name: "not a snapshot", children: [] },
                    "error restoring tree: unsupported snapshot version 'undefined'"
                );
                expectRestoreToThrow(
                    { version: 1, root: snapshot.root },
                    "error restoring tree: expected snapshot to have a definition"
                );
                expectRestoreToThrow(
                    { ...snapshot, definition: 42 },
                    "error restoring tree: expected snapshot to have a definition"
                );
                expectRestoreToThrow(
                    { ...snapshot, definition: null },
                    "error restoring tree: expected snapshot to have a definition"
                );
            });

            it("the snapshot version is not supported", () => {
                const snapshot = createSnapshotOfOtherTree(definition);
                expectRestoreToThrow(
                    { ...snapshot, version: 2 },
                    "error restoring tree: unsupported snapshot version '2'"
                );
                expectRestoreToThrow(
                    { root: snapshot.root },
                    "error restoring tree: unsupported snapshot version 'undefined'"
                );
            });

            it("the snapshot has no root node", () => {
                const { definition: snapshotDefinition } = createSnapshotOfOtherTree(definition);

                expectRestoreToThrow(
                    { version: 1, definition: snapshotDefinition },
                    "error restoring tree: expected snapshot to have a root node"
                );
            });

            it("a node in the snapshot is of a different type to the node in the tree", () => {
                expectRestoreToThrow(
                    createSnapshotOfOtherTree("root { selector { action [A] action [B] } }"),
                    "error restoring tree: expected snapshot of 'SEQUENCE' node of type 'sequence' but got 'SELECTOR' node of type 'selector'"
                );
            });

            it("a node in the snapshot has a different name to the node in the tree", () => {
                expectRestoreToThrow(
                    createSnapshotOfOtherTree("root { sequence { action [A] action [C] } }"),
                    "error restoring tree: expected snapshot of 'B' node of type 'action' but got 'C' node of type 'action'"
                );
            });

            it("a node in the snapshot has a different number of children to the node in the tree", () => {
                expectRestoreToThrow(
                    createSnapshotOfOtherTree("root { sequence { action [A] } }"),
                    "error restoring tree: expected snapshot of 'SEQUENCE' node to have 2 children but got 1"
                );
            });

            it("a node in the snapshot has an invalid state", () => {
                const snapshot = createSnapshotOfOtherTree(definition);
                snapshot.root.children![0].children![1].state = "not-a-state" as State.READY;

                expectRestoreToThrow(
                    snapshot,
                    "error restoring tree: expected snapshot of 'B' node to have a valid state but got 'not-a-state'"
                );
            });
        });
    });
});
