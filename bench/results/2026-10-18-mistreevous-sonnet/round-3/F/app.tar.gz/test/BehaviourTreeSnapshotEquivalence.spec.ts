import { assert } from "chai";
import sinon, { SinonFakeTimers } from "sinon";

import { BehaviourTree, BehaviourTreeSnapshot, NodeDetails, State } from "../src/index";
import { Agent } from "../src/Agent";

const STEP_COUNT = 90;

/**
 * Trees that between them use every node type, attribute and source of randomness.
 */
const DEFINITIONS: { [description: string]: string } = {
    "sequences, selectors, repeats, retries, a lotto and waits": `root {
        repeat {
            sequence {
                repeat [2, 3] {
                    selector {
                        sequence {
                            condition [ok]
                            action [A] entry(onEntry, "A") exit(onExit, "A")
                        }
                        action [B] step(onStep, "B")
                    }
                }
                retry [2, 4] {
                    sequence {
                        action [B]
                        action [C]
                    }
                }
                lotto [2, 1, 1] {
                    action [A]
                    sequence {
                        action [B]
                        wait [20, 60]
                    }
                    action [C]
                }
                wait [50]
            }
        }
    }`,
    "parallels, races and alls with guards, flips, succeeds and fails": `root {
        all {
            race {
                action [A] while(notBlocked) exit(onExit, "race A")
                wait [100, 200]
            }
            parallel {
                action [B]
                sequence {
                    action [C] until(isFinished)
                    flip { condition [ok] }
                }
            }
            succeed { fail { sequence { wait [40] action [A] } } }
        }
    }`,
    "a tree that finishes and starts new runs": `root {
        sequence {
            wait [30, 70]
            lotto {
                action [A]
                action [B]
            }
            repeat [1, 3] { action [B] }
            retry [1, 3] { action [C] }
        }
    }`
};

/**
 * Creates an agent with functions that are deterministic functions of the agent tick and log each call.
 */
function createAgent() {
    const log: string[] = [];
    const agent = { tick: 0 } as { tick: number; log: string[] } & Agent;

    const logged =
        (name: string, result: (tick: number) => any) =>
        (...args: any[]) => {
            log.push(`${agent.tick}: ${name}(${JSON.stringify(args)})`);
            return result(agent.tick);
        };

    agent.log = log;
    agent.A = logged("A", (tick) => (tick % 3 === 0 ? State.SUCCEEDED : undefined));
    agent.B = logged("B", (tick) => (tick % 4 === 1 ? State.FAILED : State.SUCCEEDED));
    agent.C = logged("C", (tick) => (tick % 7 === 0 ? State.FAILED : tick % 5 === 0 ? State.SUCCEEDED : undefined));
    agent.ok = logged("ok", (tick) => tick % 2 === 0);
    agent.notBlocked = logged("notBlocked", (tick) => tick % 11 !== 10);
    agent.isFinished = logged("isFinished", (tick) => tick % 13 === 12);
    agent.onEntry = logged("onEntry", () => undefined);
    agent.onExit = logged("onExit", () => undefined);
    agent.onStep = logged("onStep", () => undefined);

    return agent;
}

/**
 * Creates a function that returns a repeatable sequence of pseudo-random numbers, starting from the specified position in the sequence.
 */
function createRandom(startPosition: number) {
    const random = () => {
        const x = Math.sin(++random.position * 12.9898) * 43758.5453;
        return x - Math.floor(x);
    };
    random.position = startPosition;

    return random;
}

/**
 * Gets the duration in milliseconds that passes after the specified step.
 */
const getElapsedTime = (step: number) => 10 + ((step * 7) % 25);

/**
 * Gets the states of every node in the tree as a string, ignoring the instance-specific node ids.
 */
function getNodeStates(tree: BehaviourTree): string {
    const visit = (node: NodeDetails): string =>
        `${node.name}:${node.state.replace("mistreevous.", "")}${
            node.children ? `(${node.children.map(visit).join(",")})` : ""
        }`;

    return visit(tree.getTreeNodeDetails());
}

/**
 * The state of a tree at a point between steps.
 */
type TreePoint = {
    /** The tree snapshot after it has been passed through JSON. */
    snapshot: BehaviourTreeSnapshot;
    /** The position in the random number sequence. */
    randomPosition: number;
    /** The number of agent function calls made so far. */
    callCount: number;
    /** The states of every node in the tree. */
    nodeStates: string;
};

describe("A restored BehaviourTree", () => {
    let clock: SinonFakeTimers;

    beforeEach(() => {
        BehaviourTree.unregisterAll();
        clock = sinon.useFakeTimers(0);
    });

    afterEach(() => clock.restore());

    for (const [clockDescription, useDeltaTime] of [
        ["the clock", false],
        ["the getDeltaTime option", true]
    ] as const) {
        for (const [description, definition] of Object.entries(DEFINITIONS)) {
            it(`behaves exactly as the tree it was snapshotted from when restored at any step of ${description}, using ${clockDescription}`, () => {
                let elapsedTime = 0;
                const options = (random: () => number) => ({
                    random,
                    getDeltaTime: useDeltaTime ? () => elapsedTime / 1000 : undefined
                });

                // Run a tree without ever restoring it, taking note of how things are before every step.
                const agent = createAgent();
                const random = createRandom(0);
                const tree = new BehaviourTree(definition, agent, options(random));
                const points: TreePoint[] = [];
                const treeStatesAfterSteps: string[] = [];
                const treeResultsAfterSteps: State[] = [];

                for (let step = 0; step < STEP_COUNT; step++) {
                    points.push({
                        snapshot: JSON.parse(JSON.stringify(tree.snapshot())),
                        randomPosition: random.position,
                        callCount: agent.log.length,
                        nodeStates: getNodeStates(tree)
                    });

                    agent.tick = step;
                    elapsedTime = getElapsedTime(step);
                    tree.step();
                    clock.tick(elapsedTime);

                    treeStatesAfterSteps.push(getNodeStates(tree));
                    treeResultsAfterSteps.push(tree.getState());
                }

                // Make sure that the run was interesting enough to be worth comparing against.
                assert.isAbove(agent.log.length, 50, "the run should call plenty of agent functions");
                assert.isAbove(
                    new Set(treeStatesAfterSteps).size,
                    10,
                    "the run should pass through plenty of tree states"
                );

                // Now restore a new tree at every point and make sure that it carries on in the same way as the one that was not restored.
                points.forEach((point, firstStep) => {
                    // A lot of time passes before the tree is restored.
                    clock.setSystemTime(1_000_000_000_000 + firstStep * 86_400_000);

                    const restoredAgent = createAgent();
                    const restoredRandom = createRandom(point.randomPosition);
                    const restoredTree = new BehaviourTree(definition, restoredAgent, options(restoredRandom));

                    restoredTree.restore(point.snapshot);

                    const context = `restored before step ${firstStep}`;
                    assert.strictEqual(getNodeStates(restoredTree), point.nodeStates, context);
                    assert.deepStrictEqual(restoredTree.snapshot(), point.snapshot, context);
                    assert.deepStrictEqual(restoredAgent.log, [], context);

                    for (let step = firstStep; step < STEP_COUNT; step++) {
                        restoredAgent.tick = step;
                        elapsedTime = getElapsedTime(step);
                        restoredTree.step();
                        clock.tick(elapsedTime);

                        assert.strictEqual(
                            getNodeStates(restoredTree),
                            treeStatesAfterSteps[step],
                            `${context}, after step ${step}`
                        );
                        assert.strictEqual(
                            restoredTree.getState(),
                            treeResultsAfterSteps[step],
                            `${context}, after step ${step}`
                        );
                    }

                    assert.deepStrictEqual(restoredAgent.log, agent.log.slice(point.callCount), context);
                    assert.strictEqual(restoredRandom.position, random.position, context);
                });
            });
        }
    }
});
