import {
    NodeDefinition,
    RootNodeDefinition,
    DecoratorNodeDefinition,
    CompositeNodeDefinition,
    AnyNodeDefinition,
    BranchNodeDefinition
} from "./BehaviourTreeDefinition";

/**
 * A type guard function that returns true if the specified node satisfies the RootNodeDefinition type.
 * @param node The node.
 * @returns A value of true if the specified node satisfies the RootNodeDefinition type.
 */
export function isRootNodeDefinition(node: NodeDefinition): node is RootNodeDefinition {
    return node.type === "root";
}

/**
 * A type guard function that returns true if the specified node satisfies the BranchNodeDefinition type.
 * @param node The node.
 * @returns A value of true if the specified node satisfies the BranchNodeDefinition type.
 */
export function isBranchNodeDefinition(node: NodeDefinition): node is BranchNodeDefinition {
    return node.type === "branch";
}

/**
 * A type guard function that returns true if the specified node satisfies the NodeDefinition type.
 * @param node The node.
 * @returns A value of true if the specified node satisfies the NodeDefinition type.
 */
export function isLeafNodeDefinition(node: NodeDefinition): node is NodeDefinition {
    return ["branch", "action", "condition", "wait"].includes(node.type);
}

/**
 * A type guard function that returns true if the specified node satisfies the DecoratorNodeDefinition type.
 * @param node The node.
 * @returns A value of true if the specified node satisfies the DecoratorNodeDefinition type.
 */
export function isDecoratorNodeDefinition(node: NodeDefinition): node is DecoratorNodeDefinition {
    return ["root", "repeat", "retry", "flip", "succeed", "fail"].includes(node.type);
}

/**
 * A type guard function that returns true if the specified node satisfies the CompositeNodeDefinition type.
 * @param node The node.
 * @returns A value of true if the specified node satisfies the CompositeNodeDefinition type.
 */
export function isCompositeNodeDefinition(node: NodeDefinition): node is CompositeNodeDefinition {
    return ["sequence", "selector", "lotto", "parallel", "race", "all"].includes(node.type);
}

/**
 * Flatten a node definition into an array of all of its nested node definitions.
 * @param nodeDefinition The node definition to flatten.
 * @returns An array of all of nested node definitions.
 */
export function flattenDefinition(nodeDefinition: AnyNodeDefinition): AnyNodeDefinition[] {
    const nodes: AnyNodeDefinition[] = [];

    const processNode = (currentNodeDefinition: AnyNodeDefinition) => {
        nodes.push(currentNodeDefinition);

        if (isCompositeNodeDefinition(currentNodeDefinition)) {
            currentNodeDefinition.children.forEach(processNode);
        } else if (isDecoratorNodeDefinition(currentNodeDefinition)) {
            processNode(currentNodeDefinition.child);
        }
    };

    processNode(nodeDefinition);

    return nodes;
}

/**
 * Determines whether the passed value is an integer.
 * @param value The value to check.
 * @returns Whether the passed value is an integer.
 */
export function isInteger(value: unknown): boolean {
    return typeof value === "number" && Math.floor(value) === value;
}

/**
 * Determines whether the passed value is null or undefined.
 * @param value The value to check.
 * @returns Whether the passed value is null or undefined.
 */
export function isNullOrUndefined(value: unknown): boolean {
    return typeof value === "undefined" || value === null;
}

/**
 * Gets a copy of a value ready to be serialised, in which the same definition is always written the same way:
 * object properties are in alphabetical order, undefined properties are left out, and so are the properties
 * that only restate a default ('args' of [] and 'succeedOnAbort' of false, which MDSL always writes in full).
 * @param value The value to canonicalise.
 * @returns The canonical value.
 */
function canonicalise(value: unknown): unknown {
    if (Array.isArray(value)) {
        return value.map(canonicalise);
    }

    if (typeof value !== "object" || value === null) {
        return value;
    }

    const canonical: { [key: string]: unknown } = {};

    for (const key of Object.keys(value).sort()) {
        const property = (value as { [key: string]: unknown })[key];

        const isDefault =
            property === undefined ||
            (key === "args" && Array.isArray(property) && property.length === 0) ||
            (key === "succeedOnAbort" && property === false);

        if (!isDefault) {
            canonical[key] = canonicalise(property);
        }
    }

    return canonical;
}

/**
 * Gets an identifier for a behaviour tree definition, to tell whether two trees were built from the same definition.
 * The identifier of an MDSL definition is the same as that of the equivalent JSON definition. It is a hash, meant to
 * catch a snapshot being restored into the wrong tree by mistake, and not to withstand someone trying to forge one.
 * @param rootNodeDefinitions The root node definitions of the tree, as returned by definition validation.
 * @returns The identifier of the definition.
 */
export function getDefinitionIdentifier(rootNodeDefinitions: RootNodeDefinition[]): string {
    // The order that root nodes are written in makes no difference to the tree, the main root node has no id and so is first.
    const sorted = [...rootNodeDefinitions].sort((a, b) => {
        const [idA, idB] = [a.id ?? "", b.id ?? ""];
        return idA < idB ? -1 : idA > idB ? 1 : 0;
    });

    const serialised = JSON.stringify(canonicalise(sorted));

    // A 53 bit hash (cyrb53) of the serialised definition.
    let h1 = 0xdeadbeef;
    let h2 = 0x41c6ce57;

    for (let index = 0; index < serialised.length; index++) {
        const code = serialised.charCodeAt(index);
        h1 = Math.imul(h1 ^ code, 2654435761);
        h2 = Math.imul(h2 ^ code, 1597334677);
    }

    h1 = Math.imul(h1 ^ (h1 >>> 16), 2246822507) ^ Math.imul(h2 ^ (h2 >>> 13), 3266489909);
    h2 = Math.imul(h2 ^ (h2 >>> 16), 2246822507) ^ Math.imul(h1 ^ (h1 >>> 13), 3266489909);

    return (4294967296 * (2097151 & h2) + (h1 >>> 0)).toString(16).padStart(14, "0");
}
