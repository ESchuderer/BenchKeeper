import { assert } from "chai";
import sinon, { SinonFakeTimers } from "sinon";

import { BehaviourTree, State } from "../src/index";
import type { BehaviourTreeSnapshot } from "../src/index";
import { BehaviourTreeOptions } from "../src/BehaviourTreeOptions";
import { NodeDetails } from "../src/nodes/Node";

/**
 * Round trip a value through JSON, as an application persisting a snapshot would.
 */
const throughJSON = <T>(value: T): T => JSON.parse(JSON.stringify(value));

/**
 * Strip the randomly generated node ids from node details so that details of different tree instances can be compared.
 */
const withoutIds = (details: NodeDetails): any => {
    const { id, children, ...rest } = details;
    return { ...rest, children: children?.map(withoutIds) };
};

/**
 * Restore a snapshot of the original tree into the restored tree and then step both trees in lockstep,
 * asserting that they have identical node states after the restore and after every step.
 */
const assertRestoredTreeMatchesOriginal = (original: BehaviourTree, restored: BehaviourTree, steps: number) => {
    restored.restore(throughJSON(original.snapshot()));

    assert.deepEqual(withoutIds(restored.getTreeNodeDetails()), withoutIds(original.getTreeNodeDetails()));

    for (let step = 0; step < steps; step++) {
        original.step();
        restored.step();

        assert.deepEqual(withoutIds(restored.getTreeNodeDetails()), withoutIds(original.getTreeNodeDetails()));
    }
};

describe("A BehaviourTree", () => {
    describe("snapshot", () => {
        it("returns a plain object that is unchanged by a JSON round trip", () => {
            const tree = new BehaviourTree(
                "root { sequence { action [First] action [Second] } }",
                { First: () => State.SUCCEEDED, Second: () => State.RUNNING },
                {}
            );

            const readySnapshot = tree.snapshot();
            assert.deepEqual(throughJSON(readySnapshot), readySnapshot);

            tree.step();

            const runningSnapshot = tree.snapshot();
            assert.deepEqual(throughJSON(runningSnapshot), runningSnapshot);
        });

        it("does not change the tree", () => {
            const tree = new BehaviourTree("root { action [Work] }", { Work: () => State.RUNNING }, {});
            tree.step();

            const before = withoutIds(tree.getTreeNodeDetails());
            tree.snapshot();

            assert.deepEqual(withoutIds(tree.getTreeNodeDetails()), before);
        });

        describe("records the definition of the tree, which", () => {
            const agent = { Work: () => State.RUNNING };

            const definitionOf = (definition: any) => new BehaviourTree(definition, agent, {}).snapshot().definition;

            it("is a string that is the same for any tree built from the same definition", () => {
                const first = new BehaviourTree("root { action [Work, 1] }", agent, {});
                const second = new BehaviourTree("root { action [Work, 1] }", agent, {});
                second.step();

                assert.isString(first.snapshot().definition);
                assert.strictEqual(second.snapshot().definition, first.snapshot().definition);
            });

            it("is calculated the same way by every version, so that saved snapshots can still be restored", () => {
                assert.strictEqual(
                    definitionOf("root { sequence { action [Implement] wait [60000] action [Merge] } }"),
                    "1ae9a6b81970e8"
                );
            });

            it("is not changed by the formatting of an MDSL definition", () => {
                assert.strictEqual(
                    definitionOf("root {\n  /* comment */ action [ Work , 1 ]\n}"),
                    definitionOf("root { action [Work, 1] }")
                );
            });

            it("is the same for an equivalent JSON definition", () => {
                const mdsl = `
                    root { sequence while(Allowed) then succeed entry(Entered) {
                        action [Work, "a", 1, true, null]
                        repeat [2, 3] { wait [10] }
                        branch [Sub]
                    } }
                    root [Sub] { action [Work] }
                `;

                // The same definition as JSON, leaving out the optional properties that MDSL always writes, with the
                // properties in a different order and with the sub root node before the main root node.
                const json = [
                    { type: "root", id: "Sub", child: { type: "action", call: "Work" } },
                    {
                        type: "root",
                        child: {
                            entry: { call: "Entered" },
                            children: [
                                { call: "Work", type: "action", args: ["a", 1, true, null] },
                                { type: "repeat", iterations: [2, 3], child: { type: "wait", duration: 10 } },
                                { type: "branch", ref: "Sub" }
                            ],
                            type: "sequence",
                            while: { call: "Allowed", succeedOnAbort: true }
                        }
                    }
                ];

                assert.strictEqual(definitionOf(json), definitionOf(mdsl));
            });

            it("is the same for a single JSON root node definition and an array of one", () => {
                const root = { type: "root", child: { type: "action", call: "Work" } };

                assert.strictEqual(definitionOf(root), definitionOf([root]));
            });

            it("is different for definitions that differ in anything other than formatting", () => {
                const definitions = [
                    "root { action [Work, 1] }",
                    "root { action [Work, 2] }",
                    "root { action [Work, 1, 2] }",
                    'root { action [Work, "1"] }',
                    "root { action [Work, 1] entry(Entered) }",
                    "root { action [Work, 1] entry(Other) }",
                    "root { action [Work, 1] entry(Other, 1) }",
                    "root { action [Work, 1] exit(Other) }",
                    "root { action [Work, 1] while(Other) }",
                    "root { action [Work, 1] while(Other) then succeed }",
                    "root { action [Work, 1] until(Other) }",
                    "root { sequence { action [Work, 1] } }",
                    "root { repeat [3] { action [Work, 1] } }",
                    "root { repeat [4] { action [Work, 1] } }",
                    "root [Sub] { action [Work, 1] } root { branch [Sub] }",
                    "root [Other] { action [Work, 1] } root { branch [Other] }"
                ];

                const identifiers = definitions.map(definitionOf);

                assert.strictEqual(new Set(identifiers).size, definitions.length);
            });
        });
    });

    describe("restore", () => {
        it("sets the node states of a tree built from the same definition and resumes from them", () => {
            const definition = "root { sequence { action [First] action [Second] action [Third] } }";

            const originalCalls: string[] = [];
            let secondCalls = 0;
            const original = new BehaviourTree(
                definition,
                {
                    First: () => (originalCalls.push("First"), State.SUCCEEDED),
                    Second: () => (originalCalls.push("Second"), ++secondCalls < 3 ? State.RUNNING : State.SUCCEEDED),
                    Third: () => (originalCalls.push("Third"), State.SUCCEEDED)
                },
                {}
            );
            original.step();
            assert.deepEqual(originalCalls, ["First", "Second"]);

            const snapshot: BehaviourTreeSnapshot = throughJSON(original.snapshot());

            const restoredCalls: string[] = [];
            let restoredSecondCalls = secondCalls;
            const restored = new BehaviourTree(
                definition,
                {
                    First: () => (restoredCalls.push("First"), State.SUCCEEDED),
                    Second: () => (
                        restoredCalls.push("Second"), ++restoredSecondCalls < 3 ? State.RUNNING : State.SUCCEEDED
                    ),
                    Third: () => (restoredCalls.push("Third"), State.SUCCEEDED)
                },
                {}
            );
            restored.restore(snapshot);

            assert.deepEqual(withoutIds(restored.getTreeNodeDetails()), withoutIds(original.getTreeNodeDetails()));

            for (let step = 0; step < 2; step++) {
                original.step();
                restored.step();
                assert.deepEqual(withoutIds(restored.getTreeNodeDetails()), withoutIds(original.getTreeNodeDetails()));
            }

            assert.deepEqual(restoredCalls, ["Second", "Second", "Third"]);
            assert.deepEqual(originalCalls.slice(2), restoredCalls);
            assert.strictEqual(restored.getState(), State.SUCCEEDED);
        });

        it("accepts a snapshot of a tree built from an equivalent definition written as MDSL or as JSON", () => {
            const mdsl = "root { sequence { action [First] repeat [3] { action [Second, 1] while(Allowed) } } }";
            const json = {
                type: "root",
                child: {
                    type: "sequence",
                    children: [
                        { type: "action", call: "First" },
                        {
                            type: "repeat",
                            iterations: 3,
                            child: { type: "action", call: "Second", args: [1], while: { call: "Allowed" } }
                        }
                    ]
                }
            };
            const agent = { First: () => State.SUCCEEDED, Second: () => State.RUNNING, Allowed: () => true };

            const fromMDSL = new BehaviourTree(mdsl, agent, {});
            const fromJSON = new BehaviourTree(json as any, agent, {});
            fromMDSL.step();

            fromJSON.restore(throughJSON(fromMDSL.snapshot()));
            assert.deepEqual(withoutIds(fromJSON.getTreeNodeDetails()), withoutIds(fromMDSL.getTreeNodeDetails()));

            fromJSON.step();
            const restoredToMDSL = new BehaviourTree(mdsl, agent, {});
            restoredToMDSL.restore(throughJSON(fromJSON.snapshot()));
            assert.deepEqual(
                withoutIds(restoredToMDSL.getTreeNodeDetails()),
                withoutIds(fromJSON.getTreeNodeDetails())
            );
        });

        describe("a snapshot taken at any step of a tree using every node type", () => {
            const definition = `
                root [Sub] {
                    sequence {
                        action [Task, "sub1", 1, true]
                        action [Task, "sub2", 2, true]
                    }
                }

                root step(Tick) {
                    sequence {
                        race {
                            wait [2500]
                            repeat [3] { action [Task, "race", 2, true] }
                        }
                        selector {
                            flip { action [Task, "flip", 1, true] }
                            retry [2, 4] { action [Task, "retry", 2, false] }
                            action [Task, "unused", 1, true]
                        }
                        all {
                            lotto [1, 3] {
                                action [Task, "lotto1", 2, true]
                                action [Task, "lotto2", 3, true]
                            }
                            succeed { action [Task, "succeed", 3, false] }
                            wait [1000, 3000]
                        }
                        succeed {
                            parallel {
                                branch [Sub]
                                fail { action [Task, "fail", 2, true] }
                                action [Task, "guarded", 9, true] while(Allowed)
                            }
                        }
                        repeat [1, 2] {
                            selector {
                                condition [Never]
                                action [Task, "last", 1, true] entry(Entered) exit(Exited)
                            }
                        }
                    }
                }
            `;

            type World = { counters: { [key: string]: number }; randomCalls: number; log: string[] };

            const createTree = (world: World, timing: BehaviourTreeOptions = { getDeltaTime: () => 0.5 }) => {
                const agent = {
                    Task: (name: string, steps: number, succeeds: boolean) => {
                        world.log.push(name);
                        world.counters[name] = (world.counters[name] ?? 0) + 1;
                        if (world.counters[name] < steps) {
                            return undefined;
                        }
                        world.counters[name] = 0;
                        return succeeds ? State.SUCCEEDED : State.FAILED;
                    },
                    Tick: () => {
                        world.counters.tick = (world.counters.tick ?? 0) + 1;
                    },
                    Allowed: () => (world.counters.tick ?? 0) < 15,
                    Never: () => false,
                    Entered: () => void world.log.push("entered"),
                    Exited: (result: { succeeded: boolean; aborted: boolean }) =>
                        void world.log.push(`exited ${result.succeeded} ${result.aborted}`)
                };

                return new BehaviourTree(definition, agent, {
                    ...timing,
                    random: () => {
                        world.randomCalls++;
                        return (world.randomCalls * 0.37) % 1;
                    }
                });
            };

            const newWorld = (): World => ({ counters: {}, randomCalls: 0, log: [] });

            const STEPS = 50;

            for (let snapshotStep = 0; snapshotStep <= STEPS; snapshotStep += 1) {
                it(`(after ${snapshotStep} steps)`, () => {
                    const originalWorld = newWorld();
                    const original = createTree(originalWorld);

                    for (let step = 0; step < snapshotStep; step++) {
                        original.step();
                    }

                    // The application is responsible for the state of the agent, which is not part of the snapshot.
                    const restoredWorld: World = { ...throughJSON(originalWorld), log: [] };
                    const restored = createTree(restoredWorld);
                    restored.restore(throughJSON(original.snapshot()));

                    originalWorld.log.length = 0;

                    for (let step = snapshotStep; step < STEPS; step++) {
                        assert.deepEqual(
                            withoutIds(restored.getTreeNodeDetails()),
                            withoutIds(original.getTreeNodeDetails())
                        );
                        assert.deepEqual(restored.snapshot(), original.snapshot());

                        original.step();
                        restored.step();

                        assert.deepEqual(restoredWorld.log, originalWorld.log, `agent calls differ at step ${step}`);
                        assert.strictEqual(restoredWorld.randomCalls, originalWorld.randomCalls);
                    }
                });
            }

            describe("is independent of the tree, so that it", () => {
                const timings: { [description: string]: BehaviourTreeOptions } = {
                    "using the 'getDeltaTime' function option": { getDeltaTime: () => 0.5 },
                    "using the clock": {}
                };

                for (const [description, timing] of Object.entries(timings)) {
                    describe(description, () => {
                        let clock: SinonFakeTimers;

                        beforeEach(() => {
                            clock = sinon.useFakeTimers();
                        });

                        afterEach(() => {
                            clock.restore();
                        });

                        // Step the tree that the snapshot is taken from, with time passing between each step.
                        const stepTree = (tree: BehaviourTree, steps: number) => {
                            for (let step = 0; step < steps; step++) {
                                tree.step();
                                clock.tick(400);
                            }
                        };

                        for (let snapshotStep = 0; snapshotStep <= STEPS; snapshotStep += 1) {
                            it(`is not changed by stepping the tree it was taken from or a tree it was restored into (after ${snapshotStep} steps)`, () => {
                                const world = newWorld();
                                const original = createTree(world, timing);
                                stepTree(original, snapshotStep);

                                const snapshot = original.snapshot();
                                const expected = throughJSON(snapshot);

                                const restoredWorld: World = { ...throughJSON(world), log: [] };
                                const restored = createTree(restoredWorld, timing);

                                for (let step = 0; step < 5; step++) {
                                    stepTree(original, 1);
                                    assert.deepEqual(
                                        snapshot,
                                        expected,
                                        `changed by stepping the original (step ${step})`
                                    );
                                }

                                restored.restore(snapshot);

                                for (let step = 0; step < 5; step++) {
                                    stepTree(restored, 1);
                                    assert.deepEqual(
                                        snapshot,
                                        expected,
                                        `changed by stepping the restored (step ${step})`
                                    );
                                }
                            });

                            it(`equals a snapshot taken right after it is restored (after ${snapshotStep} steps)`, () => {
                                const world = newWorld();
                                const original = createTree(world, timing);
                                stepTree(original, snapshotStep);

                                const snapshot = original.snapshot();

                                const restored = createTree({ ...throughJSON(world), log: [] }, timing);
                                restored.restore(snapshot);

                                assert.deepEqual(throughJSON(restored.snapshot()), throughJSON(snapshot));

                                // Restoring it back into the tree that it was taken from also has no effect on the snapshot.
                                original.restore(snapshot);
                                assert.deepEqual(throughJSON(original.snapshot()), throughJSON(snapshot));

                                // The same goes for a tree that has already made progress of its own.
                                stepTree(original, 7);
                                original.restore(snapshot);
                                assert.deepEqual(throughJSON(original.snapshot()), throughJSON(snapshot));
                            });
                        }
                    });
                }
            });
        });

        describe("will error and leave the tree unchanged if", () => {
            const definition = "root { sequence { action [First] repeat [3] { action [Second] } } }";
            const agent = { First: () => State.SUCCEEDED, Second: () => State.SUCCEEDED };

            const createSteppedTree = () => {
                const tree = new BehaviourTree(definition, agent, {});
                tree.step();
                return tree;
            };

            const assertRestoreErrors = (mutate: (snapshot: any) => void, message: string) => {
                const source = createSteppedTree();
                const snapshot = throughJSON(source.snapshot());
                mutate(snapshot);

                // The target is in a different state to the snapshot, so that a partial restore would be noticeable.
                const target = new BehaviourTree(definition, agent, {});
                const before = target.snapshot();

                assert.throws(() => target.restore(snapshot), Error, message);
                assert.deepEqual(target.snapshot(), before);
            };

            it("the snapshot version is not supported", () => {
                assertRestoreErrors(
                    (snapshot) => (snapshot.version = 2),
                    "error restoring tree: expected a snapshot with a version of 1"
                );
            });

            it("the snapshot is not an object", () => {
                const tree = createSteppedTree();

                assert.throws(
                    () => tree.restore(null as any),
                    Error,
                    "error restoring tree: expected a snapshot with a version of 1"
                );
                assert.throws(
                    () => tree.restore("snapshot" as any),
                    Error,
                    "error restoring tree: expected a snapshot with a version of 1"
                );
            });

            describe("the value is not a snapshot, such as", () => {
                const target = new BehaviourTree(definition, agent, {});
                target.step();

                const notSnapshots: [string, any][] = [
                    ["null", null],
                    ["undefined", undefined],
                    ["a string", "snapshot"],
                    ["a number", 1],
                    ["a boolean", true],
                    ["an array", []],
                    ["an array of a snapshot", [createSteppedTree().snapshot()]],
                    ["an object without the fields of a snapshot", {}],
                    ["an object with only a version", { version: 1 }],
                    ["an object with only a version and a root", { version: 1, root: target.snapshot().root }],
                    ["an object with only a version and a definition", { version: 1, definition: "x" }],
                    ["an object with a definition that is not a string", { ...target.snapshot(), definition: 1 }],
                    ["an object with a root that is not an object", { ...target.snapshot(), root: "root" }],
                    ["an object with a null root", { ...target.snapshot(), root: null }]
                ];

                for (const [description, value] of notSnapshots) {
                    it(description, () => {
                        const tree = new BehaviourTree(definition, agent, {});
                        const before = tree.snapshot();

                        assert.throws(() => tree.restore(value), Error);
                        assert.deepEqual(tree.snapshot(), before);
                    });
                }
            });

            describe("the snapshot is of a tree with a different definition", () => {
                const message = "error restoring tree: the snapshot does not match the tree's definition";

                const sourceAgent = { ...agent, Entered: () => {}, Allowed: () => true };

                const assertRestoreRejected = (sourceDefinition: string) => {
                    const source = new BehaviourTree(sourceDefinition, sourceAgent, {});
                    source.step();
                    const snapshot = throughJSON(source.snapshot());

                    // The target is in a different state to the snapshot, so that a partial restore would be noticeable.
                    const target = new BehaviourTree(definition, agent, {});
                    const before = target.snapshot();
                    const detailsBefore = withoutIds(target.getTreeNodeDetails());

                    assert.throws(() => target.restore(snapshot), Error, message);
                    assert.deepEqual(target.snapshot(), before);
                    assert.deepEqual(withoutIds(target.getTreeNodeDetails()), detailsBefore);
                };

                it("that has a different structure", () => {
                    assertRestoreRejected("root { sequence { action [First] action [Second] } }");
                });

                it("that has the same structure but different action arguments", () => {
                    assertRestoreRejected(definition.replace("action [First]", "action [First, 1]"));
                });

                it("that has the same structure but a different callback", () => {
                    assertRestoreRejected(definition.replace("action [First]", "action [First] entry(Entered)"));
                });

                it("that has the same structure but a different guard", () => {
                    assertRestoreRejected(definition.replace("action [Second]", "action [Second] while(Allowed)"));
                });

                it("even when the definition recorded in the snapshot is edited", () => {
                    const source = createSteppedTree();
                    const snapshot = throughJSON(source.snapshot());
                    snapshot.definition = "";

                    const target = new BehaviourTree(definition, agent, {});
                    assert.throws(() => target.restore(snapshot), Error, message);
                });
            });

            it("a node in the snapshot is of a different type to the node in the tree", () => {
                assertRestoreErrors(
                    (snapshot) => (snapshot.root.children[0].children[1].type = "retry"),
                    "error restoring tree: expected 'repeat' node 'REPEAT 3x' at 'root.children[0].children[1]' but the snapshot has 'retry' node 'REPEAT 3x'"
                );
            });

            it("a node in the snapshot is named differently to the node in the tree", () => {
                assertRestoreErrors(
                    (snapshot) => (snapshot.root.children[0].children[0].name = "Other"),
                    "error restoring tree: expected 'action' node 'First' at 'root.children[0].children[0]' but the snapshot has 'action' node 'Other'"
                );
            });

            it("a node in the snapshot has a different number of children to the node in the tree", () => {
                assertRestoreErrors(
                    (snapshot) => snapshot.root.children[0].children.pop(),
                    "error restoring tree: expected 2 child snapshots at 'root.children[0].children'"
                );
            });

            it("a node in the snapshot has no children when the node in the tree does", () => {
                assertRestoreErrors(
                    (snapshot) => delete snapshot.root.children[0].children,
                    "error restoring tree: expected 2 child snapshots at 'root.children[0].children'"
                );
            });

            it("a node in the snapshot has an unknown state", () => {
                assertRestoreErrors(
                    (snapshot) => (snapshot.root.children[0].children[0].state = "finished"),
                    "error restoring tree: unexpected node state 'finished' at 'root.children[0].children[0]'"
                );
            });

            it("a node in the snapshot is not an object", () => {
                assertRestoreErrors(
                    (snapshot) => (snapshot.root.children[0].children[1] = null),
                    "error restoring tree: expected an object at 'root.children[0].children[1]'"
                );
            });

            it("the progress of a repeat node in the snapshot is not valid", () => {
                assertRestoreErrors(
                    (snapshot) => (snapshot.root.children[0].children[1].currentIterationCount = -1),
                    "error restoring tree: expected 'currentIterationCount' to be a non-negative integer at 'root.children[0].children[1]'"
                );
                assertRestoreErrors(
                    (snapshot) => delete snapshot.root.children[0].children[1].targetIterationCount,
                    "error restoring tree: expected 'targetIterationCount' to be a non-negative integer or null at 'root.children[0].children[1]'"
                );
            });

            it("the progress of a retry node in the snapshot is not valid", () => {
                const retryDefinition = "root { retry [3] { action [First] } }";
                const source = new BehaviourTree(retryDefinition, { First: () => State.FAILED }, {});
                source.step();

                const snapshot = throughJSON(source.snapshot());
                snapshot.root.children![0].currentAttemptCount = 1.5;

                assert.throws(
                    () => new BehaviourTree(retryDefinition, agent, {}).restore(snapshot),
                    Error,
                    "error restoring tree: expected 'currentAttemptCount' to be a non-negative integer at 'root.children[0]'"
                );

                snapshot.root.children![0].currentAttemptCount = 1;
                snapshot.root.children![0].targetAttemptCount = NaN;

                assert.throws(
                    () => new BehaviourTree(retryDefinition, agent, {}).restore(snapshot),
                    Error,
                    "error restoring tree: expected 'targetAttemptCount' to be a non-negative integer or null at 'root.children[0]'"
                );
            });

            it("the progress of a wait node in the snapshot is not valid", () => {
                const waitDefinition = "root { wait [1000] }";
                const source = new BehaviourTree(waitDefinition, {}, {});
                source.step();

                const snapshot = throughJSON(source.snapshot());
                snapshot.root.children![0].waitedDuration = "a while" as any;

                assert.throws(
                    () => new BehaviourTree(waitDefinition, {}, {}).restore(snapshot),
                    Error,
                    "error restoring tree: expected 'waitedDuration' to be a number at 'root.children[0]'"
                );

                snapshot.root.children![0].waitedDuration = 0;
                snapshot.root.children![0].totalDuration = -5;

                assert.throws(
                    () => new BehaviourTree(waitDefinition, {}, {}).restore(snapshot),
                    Error,
                    "error restoring tree: expected 'totalDuration' to be a non-negative number or null at 'root.children[0]'"
                );
            });

            it("the selected child of a lotto node in the snapshot is not valid", () => {
                const lottoDefinition = "root { lotto { action [First] action [Second] } }";
                const source = new BehaviourTree(
                    lottoDefinition,
                    { First: () => undefined, Second: () => undefined },
                    {}
                );
                source.step();

                const snapshot = throughJSON(source.snapshot());
                snapshot.root.children![0].selectedChildIndex = 2;

                assert.throws(
                    () => new BehaviourTree(lottoDefinition, agent, {}).restore(snapshot),
                    Error,
                    "error restoring tree: expected 'selectedChildIndex' to be the index of a child at 'root.children[0]'"
                );

                delete snapshot.root.children![0].selectedChildIndex;

                assert.throws(
                    () => new BehaviourTree(lottoDefinition, agent, {}).restore(snapshot),
                    Error,
                    "error restoring tree: expected 'selectedChildIndex' to be the index of a child at 'root.children[0]'"
                );
            });
        });

        describe("does not call the 'onNodeStateChange' option, as restoring is not a state change", () => {
            const definition = "root { sequence { action [First] action [Second] } }";

            const createAgent = (calls: string[]) => ({
                First: () => (calls.push("First"), State.SUCCEEDED),
                Second: () => (calls.push("Second"), undefined)
            });

            it("when restoring, which also does not call any agent functions", () => {
                const calls: string[] = [];
                const agent = createAgent(calls);

                const source = new BehaviourTree(definition, agent, {});
                source.step();
                calls.length = 0;

                const changes: string[] = [];
                const target = new BehaviourTree(definition, agent, {
                    onNodeStateChange: ({ type, previousState, state }) =>
                        changes.push(`${type} ${previousState} -> ${state}`)
                });
                target.restore(source.snapshot());

                assert.deepEqual(changes, []);
                assert.deepEqual(calls, []);
                assert.strictEqual(target.getState(), State.RUNNING);
            });

            it("but reports the changes made by the next step as usual", () => {
                let secondResult: State.SUCCEEDED | undefined = undefined;
                const agent = {
                    First: () => State.SUCCEEDED,
                    Second: () => secondResult
                };

                const source = new BehaviourTree(definition, agent, {});
                source.step();

                const changes: string[] = [];
                const target = new BehaviourTree(definition, agent, {
                    onNodeStateChange: ({ type, previousState, state }) =>
                        changes.push(`${type} ${previousState} -> ${state}`)
                });
                target.restore(source.snapshot());

                secondResult = State.SUCCEEDED;
                target.step();

                assert.sameMembers(changes, [
                    "action mistreevous.running -> mistreevous.succeeded",
                    "sequence mistreevous.running -> mistreevous.succeeded",
                    "root mistreevous.running -> mistreevous.succeeded"
                ]);
            });
        });

        describe("an action node that returns a promise", () => {
            const createDeferred = () => {
                let resolve!: (state: State.SUCCEEDED | State.FAILED) => void;
                const promise = new Promise<State.SUCCEEDED | State.FAILED>((res) => (resolve = res));
                return { promise, resolve };
            };

            const settle = () => new Promise((resolve) => setImmediate(resolve));

            describe("that is still pending when the snapshot is taken", () => {
                const definition = "root { sequence { action [First] action [Wait] } }";

                const createAgent = (calls: string[], deferreds = [createDeferred()]) => ({
                    First: () => (calls.push("First"), State.SUCCEEDED),
                    Wait: () => (
                        calls.push("Wait"),
                        deferreds[Math.min(calls.filter((c) => c === "Wait").length, deferreds.length) - 1].promise
                    )
                });

                it("is saved in a snapshot as an action that has not started", () => {
                    const tree = new BehaviourTree(definition, createAgent([]), {});
                    tree.step();

                    const snapshot = throughJSON(tree.snapshot());

                    assert.strictEqual(snapshot.root.state, State.RUNNING);
                    assert.strictEqual(snapshot.root.children![0].state, State.RUNNING);
                    assert.strictEqual(snapshot.root.children![0].children![0].state, State.SUCCEEDED);
                    assert.strictEqual(snapshot.root.children![0].children![1].state, State.READY);
                });

                it("is started again by the next step of a restored tree, which then carries on as normal", async () => {
                    const calls: string[] = [];
                    const tree = new BehaviourTree(definition, createAgent(calls), {});
                    tree.step();

                    const restoredCalls: string[] = [];
                    const restoredDeferred = createDeferred();
                    const restored = new BehaviourTree(definition, createAgent(restoredCalls, [restoredDeferred]), {});
                    restored.restore(throughJSON(tree.snapshot()));

                    // The action function is not called by the restore.
                    assert.deepEqual(restoredCalls, []);
                    assert.strictEqual(restored.getState(), State.RUNNING);

                    restored.step();
                    assert.deepEqual(restoredCalls, ["Wait"]);
                    assert.strictEqual(restored.getState(), State.RUNNING);

                    // The action is waiting for the new promise and is not called again until then.
                    restored.step();
                    assert.deepEqual(restoredCalls, ["Wait"]);

                    restoredDeferred.resolve(State.SUCCEEDED);
                    await settle();
                    restored.step();

                    assert.strictEqual(restored.getState(), State.SUCCEEDED);
                    assert.deepEqual(restoredCalls, ["Wait"]);
                });

                it("does not change the tree that the snapshot was taken from", async () => {
                    const deferred = createDeferred();
                    const calls: string[] = [];
                    const tree = new BehaviourTree(definition, createAgent(calls, [deferred]), {});
                    tree.step();

                    tree.snapshot();

                    tree.step();
                    assert.deepEqual(calls, ["First", "Wait"]);

                    deferred.resolve(State.FAILED);
                    await settle();
                    tree.step();
                    assert.strictEqual(tree.getState(), State.FAILED);
                });

                it("is also not started when restored into the tree that the snapshot was taken from", async () => {
                    const first = createDeferred();
                    const second = createDeferred();
                    const calls: string[] = [];
                    const tree = new BehaviourTree(definition, createAgent(calls, [first, second]), {});
                    tree.step();

                    tree.restore(tree.snapshot());
                    tree.step();
                    assert.deepEqual(calls, ["First", "Wait", "Wait"]);

                    // The result of the promise from before the restore is of no interest to the tree now.
                    first.resolve(State.SUCCEEDED);
                    await settle();
                    tree.step();
                    assert.strictEqual(tree.getState(), State.RUNNING);

                    second.resolve(State.SUCCEEDED);
                    await settle();
                    tree.step();
                    assert.strictEqual(tree.getState(), State.SUCCEEDED);
                });

                it("is also not started if the promise settled but the tree has not been stepped since", async () => {
                    const deferred = createDeferred();
                    const tree = new BehaviourTree(definition, createAgent([], [deferred]), {});
                    tree.step();
                    deferred.resolve(State.SUCCEEDED);
                    await settle();

                    const calls: string[] = [];
                    const restored = new BehaviourTree(definition, createAgent(calls), {});
                    restored.restore(throughJSON(tree.snapshot()));
                    restored.step();

                    assert.deepEqual(calls, ["Wait"]);
                    assert.strictEqual(restored.getState(), State.RUNNING);
                });

                it("does not affect the progress of the nodes around it", () => {
                    const calls: string[] = [];
                    const agent = {
                        Once: () => (calls.push("Once"), State.SUCCEEDED),
                        Wait: () => (calls.push("Wait"), createDeferred().promise),
                        Work: () => (calls.push("Work"), State.RUNNING)
                    };
                    const parallel = "root { parallel { action [Wait] sequence { action [Once] action [Work] } } }";

                    const tree = new BehaviourTree(parallel, agent, {});
                    tree.step();
                    calls.length = 0;

                    const restored = new BehaviourTree(parallel, agent, {});
                    restored.restore(throughJSON(tree.snapshot()));
                    restored.step();

                    assert.sameMembers(calls, ["Wait", "Work"]);
                    assert.strictEqual(restored.getState(), State.RUNNING);
                });

                it("calls the entry callback of the action again, as for any action that has not started", () => {
                    const calls: string[] = [];
                    const agent = {
                        Entered: () => calls.push("Entered"),
                        Wait: () => (calls.push("Wait"), createDeferred().promise)
                    };

                    const tree = new BehaviourTree("root { action [Wait] entry(Entered) }", agent, {});
                    tree.step();
                    assert.deepEqual(calls, ["Entered", "Wait"]);
                    calls.length = 0;

                    const restored = new BehaviourTree("root { action [Wait] entry(Entered) }", agent, {});
                    restored.restore(throughJSON(tree.snapshot()));
                    assert.deepEqual(calls, []);

                    restored.step();
                    assert.deepEqual(calls, ["Entered", "Wait"]);
                });
            });

            it("can be snapshotted once it has finished", async () => {
                const deferred = createDeferred();
                const tree = new BehaviourTree("root { action [Wait] }", { Wait: () => deferred.promise }, {});
                tree.step();
                deferred.resolve(State.SUCCEEDED);
                await settle();
                tree.step();

                const restored = new BehaviourTree("root { action [Wait] }", { Wait: () => deferred.promise }, {});
                restored.restore(throughJSON(tree.snapshot()));

                assert.strictEqual(restored.getState(), State.SUCCEEDED);
            });

            it("ignores the result of a promise that was pending before the tree was restored", async () => {
                const first = createDeferred();
                const second = createDeferred();
                const promises = [first.promise, second.promise];
                const tree = new BehaviourTree("root { action [Wait] }", { Wait: () => promises.shift()! }, {});

                const readySnapshot = tree.snapshot();

                // The first promise is pending, then the tree is restored to its ready state and stepped again.
                tree.step();
                tree.restore(readySnapshot);
                tree.step();

                // The result of the first promise is of no interest to the tree now.
                first.resolve(State.SUCCEEDED);
                await settle();
                tree.step();
                assert.strictEqual(tree.getState(), State.RUNNING);

                second.resolve(State.FAILED);
                await settle();
                tree.step();
                assert.strictEqual(tree.getState(), State.FAILED);
            });
        });

        describe("a snapshot of a finished tree", () => {
            it("restores as finished, and the next step starts a new run that makes its random choices again", () => {
                const definition =
                    "root { sequence { repeat [1, 3] { action [Work] } lotto { action [A] action [B] } } }";
                const createAgent = (calls: string[]) => ({
                    Work: () => (calls.push("Work"), State.SUCCEEDED),
                    A: () => (calls.push("A"), State.SUCCEEDED),
                    B: () => (calls.push("B"), State.SUCCEEDED)
                });

                // Each random value is used for one choice. The first run repeats 1x and picks A, the second run repeats 3x and picks B.
                const originalRandomValues = [0, 0, 0.99, 0.99];

                const originalCalls: string[] = [];
                const original = new BehaviourTree(definition, createAgent(originalCalls), {
                    random: () => originalRandomValues.shift()!
                });

                while (original.getState() !== State.SUCCEEDED) {
                    original.step();
                }
                assert.deepEqual(originalCalls, ["Work", "A"]);

                // Restore into a tree that is part way through a run, so that stale progress could leak through.
                const restoredCalls: string[] = [];
                const restoredRandomValues = [0.5];
                const restored = new BehaviourTree(definition, createAgent(restoredCalls), {
                    random: () => restoredRandomValues.shift()!
                });
                restored.step();
                restoredCalls.length = 0;
                restoredRandomValues.push(0.99, 0.99);

                restored.restore(throughJSON(original.snapshot()));
                assert.strictEqual(restored.getState(), State.SUCCEEDED);
                assert.deepEqual(withoutIds(restored.getTreeNodeDetails()), withoutIds(original.getTreeNodeDetails()));

                originalCalls.length = 0;
                for (let step = 0; step < 4; step++) {
                    original.step();
                    restored.step();
                    assert.deepEqual(
                        withoutIds(restored.getTreeNodeDetails()),
                        withoutIds(original.getTreeNodeDetails())
                    );
                }

                assert.deepEqual(originalCalls, ["Work", "Work", "Work", "B"]);
                assert.deepEqual(restoredCalls, originalCalls);
            });
        });

        describe("preserves the progress of", () => {
            it("a repeat node with an explicit iteration count", () => {
                const definition = "root { repeat [3] { action [Work] } }";
                const originalCalls: string[] = [];
                const restoredCalls: string[] = [];

                const original = new BehaviourTree(
                    definition,
                    { Work: () => (originalCalls.push("Work"), State.SUCCEEDED) },
                    {}
                );
                const restored = new BehaviourTree(
                    definition,
                    { Work: () => (restoredCalls.push("Work"), State.SUCCEEDED) },
                    {}
                );

                original.step();
                original.step();
                originalCalls.length = 0;

                assertRestoredTreeMatchesOriginal(original, restored, 2);

                assert.deepEqual(restoredCalls, ["Work"]);
                assert.deepEqual(originalCalls, restoredCalls);
                assert.strictEqual(restored.getState(), State.SUCCEEDED);
            });

            it("a repeat node with a randomly selected iteration count, without making the random choice again", () => {
                const definition = "root { repeat [2, 5] { action [Work] } }";
                const originalCalls: string[] = [];
                const restoredCalls: string[] = [];

                // A random value of 0.99 selects the maximum of 5 iterations.
                const original = new BehaviourTree(
                    definition,
                    { Work: () => (originalCalls.push("Work"), State.SUCCEEDED) },
                    { random: () => 0.99 }
                );
                const restored = new BehaviourTree(
                    definition,
                    { Work: () => (restoredCalls.push("Work"), State.SUCCEEDED) },
                    {
                        random: () => {
                            throw new Error("random should not be called");
                        }
                    }
                );

                original.step();
                original.step();
                originalCalls.length = 0;

                assertRestoredTreeMatchesOriginal(original, restored, 4);

                assert.deepEqual(restoredCalls, ["Work", "Work", "Work"]);
                assert.deepEqual(originalCalls, restoredCalls);
                assert.strictEqual(restored.getState(), State.SUCCEEDED);
            });

            it("a lotto node, keeping the child that was picked without making the random choice again", () => {
                const definition = "root { lotto { action [A] action [B] action [C] } }";
                const originalCalls: string[] = [];
                const restoredCalls: string[] = [];

                const createAgent = (calls: string[]) => ({
                    A: () => (calls.push("A"), undefined),
                    B: () => (calls.push("B"), undefined),
                    C: () => (calls.push("C"), undefined)
                });

                // A random value of 0.5 picks the middle child, a random value of 0 would pick the first.
                const original = new BehaviourTree(definition, createAgent(originalCalls), { random: () => 0.5 });
                const restored = new BehaviourTree(definition, createAgent(restoredCalls), { random: () => 0 });

                original.step();
                originalCalls.length = 0;

                assertRestoredTreeMatchesOriginal(original, restored, 2);

                assert.deepEqual(originalCalls, ["B", "B"]);
                assert.deepEqual(restoredCalls, originalCalls);
            });

            describe("a wait node, which only waits for the time that remains", () => {
                const HOUR = 60 * 60 * 1000;
                let clock: SinonFakeTimers;

                beforeEach(() => {
                    clock = sinon.useFakeTimers();
                });

                afterEach(() => {
                    clock.restore();
                });

                it("when using the clock, not counting the time between the snapshot and the restore", () => {
                    const definition = "root { wait [3000] }";
                    const original = new BehaviourTree(definition, {}, {});
                    const restored = new BehaviourTree(definition, {}, {});

                    original.step();
                    clock.tick(1000);

                    // Time spent waiting after the last step but before the snapshot is taken still counts.
                    const snapshot = throughJSON(original.snapshot());

                    clock.tick(10 * HOUR);
                    restored.restore(snapshot);

                    restored.step();
                    assert.strictEqual(restored.getState(), State.RUNNING);

                    clock.tick(1999);
                    restored.step();
                    assert.strictEqual(restored.getState(), State.RUNNING);

                    clock.tick(1);
                    restored.step();
                    assert.strictEqual(restored.getState(), State.SUCCEEDED);
                });

                it("when using the clock, with a randomly selected duration that is not selected again", () => {
                    const definition = "root { wait [1000, 5000] }";
                    // A random value of 0.99 selects a duration of 4960ms.
                    const original = new BehaviourTree(definition, {}, { random: () => 0.99 });
                    const restored = new BehaviourTree(
                        definition,
                        {},
                        {
                            random: () => {
                                throw new Error("random should not be called");
                            }
                        }
                    );

                    original.step();
                    clock.tick(2000);
                    const snapshot = throughJSON(original.snapshot());

                    clock.tick(HOUR);
                    restored.restore(snapshot);

                    clock.tick(2959);
                    restored.step();
                    assert.strictEqual(restored.getState(), State.RUNNING);

                    clock.tick(1);
                    restored.step();
                    assert.strictEqual(restored.getState(), State.SUCCEEDED);
                });

                it("when using the 'getDeltaTime' function option", () => {
                    const definition = "root { wait [3000] }";
                    const options = { getDeltaTime: () => 1 };
                    const original = new BehaviourTree(definition, {}, options);
                    const restored = new BehaviourTree(definition, {}, options);

                    original.step();
                    original.step();
                    const snapshot = throughJSON(original.snapshot());

                    clock.tick(10 * HOUR);
                    restored.restore(snapshot);

                    restored.step();
                    assert.strictEqual(restored.getState(), State.SUCCEEDED);
                });

                it("when the clock has been set back since the wait started", () => {
                    const definition = "root { wait [3000] }";
                    const original = new BehaviourTree(definition, {}, {});
                    const restored = new BehaviourTree(definition, {}, {});

                    original.step();
                    clock.setSystemTime(-1000);

                    restored.restore(throughJSON(original.snapshot()));

                    clock.tick(3999);
                    restored.step();
                    assert.strictEqual(restored.getState(), State.RUNNING);

                    clock.tick(1);
                    restored.step();
                    assert.strictEqual(restored.getState(), State.SUCCEEDED);
                });

                it("when the 'getDeltaTime' function option is used and the time between steps varies", () => {
                    const definition = "root { wait [3000] }";
                    const deltas = [0.5, 1, 1, 0.25, 0.25];
                    const originalDeltas = [...deltas];
                    const restoredDeltas = [...deltas];
                    const original = new BehaviourTree(definition, {}, { getDeltaTime: () => originalDeltas.shift()! });
                    const restored = new BehaviourTree(definition, {}, { getDeltaTime: () => restoredDeltas.shift()! });

                    original.step();
                    original.step();
                    restoredDeltas.splice(0, 2);

                    assertRestoredTreeMatchesOriginal(original, restored, 3);

                    assert.strictEqual(restored.getState(), State.SUCCEEDED);
                });
            });

            it("a lotto node that was resolved by a guard before it picked a child", () => {
                const definition = "root { lotto while(Never) { action [A] action [B] } }";
                const agent = { A: () => undefined, B: () => undefined, Never: () => false };

                const original = new BehaviourTree(definition, agent, {});
                original.step();
                assert.strictEqual(original.getState(), State.FAILED);

                const restored = new BehaviourTree(definition, agent, {});
                restored.restore(throughJSON(original.snapshot()));

                assert.deepEqual(withoutIds(restored.getTreeNodeDetails()), withoutIds(original.getTreeNodeDetails()));
            });

            it("a retry node with an explicit attempt count", () => {
                const definition = "root { retry [3] { action [Work] } }";
                const originalCalls: string[] = [];
                const restoredCalls: string[] = [];

                const original = new BehaviourTree(
                    definition,
                    { Work: () => (originalCalls.push("Work"), State.FAILED) },
                    {}
                );
                const restored = new BehaviourTree(
                    definition,
                    { Work: () => (restoredCalls.push("Work"), State.FAILED) },
                    {}
                );

                original.step();
                original.step();
                originalCalls.length = 0;

                assertRestoredTreeMatchesOriginal(original, restored, 2);

                assert.deepEqual(restoredCalls, ["Work"]);
                assert.deepEqual(originalCalls, restoredCalls);
                assert.strictEqual(restored.getState(), State.FAILED);
            });

            it("a retry node with a randomly selected attempt count, without making the random choice again", () => {
                const definition = "root { retry [2, 5] { action [Work] } }";
                const originalCalls: string[] = [];
                const restoredCalls: string[] = [];

                const original = new BehaviourTree(
                    definition,
                    { Work: () => (originalCalls.push("Work"), State.FAILED) },
                    { random: () => 0.99 }
                );
                const restored = new BehaviourTree(
                    definition,
                    { Work: () => (restoredCalls.push("Work"), State.FAILED) },
                    {
                        random: () => {
                            throw new Error("random should not be called");
                        }
                    }
                );

                original.step();
                original.step();
                originalCalls.length = 0;

                assertRestoredTreeMatchesOriginal(original, restored, 4);

                assert.deepEqual(restoredCalls, ["Work", "Work", "Work"]);
                assert.deepEqual(originalCalls, restoredCalls);
                assert.strictEqual(restored.getState(), State.FAILED);
            });
        });
    });
});
