import State from "./State";
import Lookup from "./Lookup";
import { NodeDetails } from "./nodes/Node";
import Root from "./nodes/decorator/Root";
import { Agent, GlobalFunction } from "./Agent";
import { BehaviourTreeOptions } from "./BehaviourTreeOptions";
import { convertMDSLToJSON } from "./mdsl/MDSLDefinitionParser";
import { RootNodeDefinition } from "./BehaviourTreeDefinition";
import { validateDefinition, validateJSONDefinition } from "./BehaviourTreeDefinitionValidator";
import buildRootNode from "./BehaviourTreeBuilder";
import { isNullOrUndefined } from "./BehaviourTreeDefinitionUtilities";
import { BehaviourTreeSnapshot, SNAPSHOT_VERSION, isObject } from "./BehaviourTreeSnapshot";
import { getDefinitionHash } from "./BehaviourTreeDefinitionHash";

/**
 * A representation of a behaviour tree.
 */
export class BehaviourTree {
    /**
     * The main root tree node.
     */
    private readonly _rootNode: Root;

    /**
     * The hash of the definition that the tree was built from, which a snapshot has to match to be restored to this tree.
     */
    private readonly _definitionHash: string;

    /**
     * Creates a new instance of the BehaviourTree class.
     * @param definition The behaviour tree definition as either an MDSL string, root node definition object or array of root node definition objects.
     * @param agent The agent instance that this behaviour tree is modelling behaviour for.
     * @param options The behaviour tree options object.
     */
    constructor(
        definition: string | RootNodeDefinition | RootNodeDefinition[],
        private agent: Agent,
        private options: BehaviourTreeOptions = {}
    ) {
        // The tree definition must be defined.
        if (isNullOrUndefined(definition)) {
            throw new Error("tree definition not defined");
        }

        // The agent must be defined and not null.
        if (typeof agent !== "object" || agent === null) {
            throw new Error("the agent must be an object and not null");
        }

        // We should validate the definition before we try to build the tree nodes.
        const { succeeded, errorMessage, json } = validateDefinition(definition);

        // Did our validation fail without error?
        if (!succeeded) {
            throw new Error(`invalid definition: ${errorMessage}`);
        }

        // Double check that we did actually get our json definition as part of our definition validtion.
        if (!json) {
            throw new Error(
                "expected json definition to be returned as part of successful definition validation response"
            );
        }

        try {
            // Create the populated tree of behaviour tree nodes and get the root node.
            this._rootNode = buildRootNode(json, options);
            this._definitionHash = getDefinitionHash(json, Lookup.getSubtrees());
        } catch (exception) {
            // There was an issue in trying build and populate the behaviour tree.
            throw new Error(`error building tree: ${(exception as Error).message}`);
        }
    }

    /**
     * Gets whether the tree is in the RUNNING state.
     * @returns true if the tree is in the RUNNING state, otherwise false.
     */
    public isRunning(): boolean {
        return this._rootNode.getState() === State.RUNNING;
    }

    /**
     * Gets the current tree state of SUCCEEDED, FAILED, READY or RUNNING.
     * @returns The current tree state.
     */
    public getState(): State {
        return this._rootNode.getState();
    }

    /**
     * Step the tree.
     * Carries out a node update that traverses the tree from the root node outwards to any child nodes, skipping those that are already in a resolved state of SUCCEEDED or FAILED.
     * After being updated, leaf nodes will have a state of SUCCEEDED, FAILED or RUNNING. Leaf nodes that are left in the RUNNING state as part of a tree step will be revisited each
     * subsequent step until they move into a resolved state of either SUCCEEDED or FAILED, after which execution will move through the tree to the next node with a state of READY.
     *
     * Calling this method when the tree is already in a resolved state of SUCCEEDED or FAILED will cause it to be reset before tree traversal begins.
     */
    public step(): void {
        // If the root node has already been stepped to completion then we need to reset it.
        if (this._rootNode.getState() === State.SUCCEEDED || this._rootNode.getState() === State.FAILED) {
            this._rootNode.reset();
        }

        try {
            this._rootNode.update(this.agent);
        } catch (exception) {
            throw new Error(`error stepping tree: ${(exception as Error).message}`);
        }
    }

    /**
     * Resets the tree from the root node outwards to each nested node, giving each a state of READY.
     */
    public reset(): void {
        this._rootNode.reset();
    }

    /**
     * Gets the details of every node in the tree, starting from the root.
     * @returns The details of every node in the tree, starting from the root.
     */
    public getTreeNodeDetails(): NodeDetails {
        return this._rootNode.getDetails();
    }

    /**
     * Gets a snapshot of the execution state of the tree, which can be restored to a tree built from the same definition.
     * The snapshot is a plain object that is not changed by JSON.stringify followed by JSON.parse, so it can be stored and restored later.
     * Taking a snapshot does not change the tree or call any agent functions.
     * A promise that is still pending cannot be saved, so an action that is waiting for one is snapshotted as not yet started and the restored tree calls its action function again.
     * @returns A snapshot of the execution state of the tree.
     */
    public snapshot(): BehaviourTreeSnapshot {
        try {
            const snapshot: BehaviourTreeSnapshot = {
                version: SNAPSHOT_VERSION,
                definitionHash: this._definitionHash,
                root: this._rootNode.getSnapshot()
            };

            // Whatever we hand out must be something that can be stored and then restored, which would not be the case if a node were
            // holding a value that JSON cannot hold, such as NaN or Infinity, so make sure that it would pass the checks made on restore.
            this._rootNode.validateSnapshot(snapshot.root);

            return snapshot;
        } catch (exception) {
            throw new Error(`error creating snapshot: ${(exception as Error).message}`);
        }
    }

    /**
     * Restores a snapshot, setting the tree to the execution state of the tree that the snapshot was taken from.
     * The tree must have been built from the same definition as the tree that the snapshot was taken from, where an MDSL definition and the equivalent JSON definition are the same definition.
     * If the snapshot is not valid for this tree, which includes it not being a snapshot or being one of a tree with a different definition, then an error is thrown and the tree is left unchanged.
     * Restoring a snapshot does not call any agent functions or the 'onNodeStateChange' callback.
     * @param snapshot The snapshot to restore.
     */
    public restore(snapshot: BehaviourTreeSnapshot): void {
        try {
            if (!isObject(snapshot)) {
                throw new Error("expected an object");
            }

            if (snapshot.version !== SNAPSHOT_VERSION) {
                throw new Error(`unsupported version '${snapshot.version}'`);
            }

            if (typeof snapshot.definitionHash !== "string") {
                throw new Error("expected a definition hash that is a string");
            }

            // Check this before the nodes, as it is what tells us that the snapshot is for a different tree, rather than just not valid.
            if (snapshot.definitionHash !== this._definitionHash) {
                throw new Error("the snapshot does not match the tree's definition");
            }

            // Check the whole snapshot before restoring any of it, so that we never end up with a partially restored tree.
            this._rootNode.validateSnapshot(snapshot.root);
        } catch (exception) {
            throw new Error(`invalid snapshot: ${(exception as Error).message}`);
        }

        this._rootNode.restoreSnapshot(snapshot.root);
    }

    /**
     * Registers the action/condition/guard/callback function or subtree with the given name.
     * @param name The name of the function or subtree to register.
     * @param value The function or subtree definition to register.
     */
    static register(name: string, value: GlobalFunction | string | RootNodeDefinition) {
        // Are we going to register a action/condition/guard/callback function?
        if (typeof value === "function") {
            Lookup.setFunc(name, value);
            return;
        }

        // We are not registering an action/condition/guard/callback function, so we must be registering a subtree.
        if (typeof value === "string") {
            let rootNodeDefinitions: RootNodeDefinition[];

            // We will assume that any string passed in will be a mdsl definition.
            try {
                rootNodeDefinitions = convertMDSLToJSON(value);
            } catch (exception) {
                throw new Error(`error registering definition, invalid MDSL: ${(exception as Error).message}`);
            }

            // This function should only ever be called with a definition containing a single unnamed root node.
            if (rootNodeDefinitions.length != 1 || typeof rootNodeDefinitions[0].id !== "undefined") {
                throw new Error("error registering definition: expected a single unnamed root node");
            }

            try {
                // We should validate the subtree as we don't want invalid subtrees available via the lookup.
                const { succeeded, errorMessage } = validateJSONDefinition(rootNodeDefinitions[0]);

                // Did our validation fail without error?
                if (!succeeded) {
                    throw new Error(errorMessage);
                }
            } catch (exception) {
                throw new Error(`error registering definition: ${(exception as Error).message}`);
            }

            // Everything seems hunky-dory, register the subtree.
            Lookup.setSubtree(name, rootNodeDefinitions[0]);
        } else if (typeof value === "object" && !Array.isArray(value)) {
            // We will assume that any object passed in is a root node definition.

            try {
                // We should validate the subtree as we don't want invalid subtrees available via the lookup.
                const { succeeded, errorMessage } = validateJSONDefinition(value);

                // Did our validation fail without error?
                if (!succeeded) {
                    throw new Error(errorMessage);
                }
            } catch (exception) {
                throw new Error(`error registering definition: ${(exception as Error).message}`);
            }

            // Everything seems hunky-dory, register the subtree.
            Lookup.setSubtree(name, value);
        } else {
            throw new Error("unexpected value, expected string mdsl definition, root node json definition or function");
        }
    }

    /**
     * Unregisters the registered action/condition/guard/callback function or subtree with the given name.
     * @param name The name of the registered action/condition/guard/callback function or subtree to unregister.
     */
    static unregister(name: string): void {
        Lookup.remove(name);
    }

    /**
     * Unregister all registered action/condition/guard/callback functions and subtrees.
     */
    static unregisterAll(): void {
        Lookup.empty();
    }
}
