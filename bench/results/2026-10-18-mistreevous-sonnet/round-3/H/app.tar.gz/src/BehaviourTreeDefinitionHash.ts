import { RootNodeDefinition } from "./BehaviourTreeDefinition";
import { flattenDefinition, isBranchNodeDefinition } from "./BehaviourTreeDefinitionUtilities";
import { isObject } from "./BehaviourTreeSnapshot";

/**
 * Gets whether a property of a definition is not set, or has the value that it is given when it is left out, so that it
 * makes no difference to the tree that is built. MDSL definitions are converted to JSON with these properties always
 * set, whereas JSON definitions written by hand usually leave them out.
 * @param key The name of the property.
 * @param value The value of the property.
 */
function isUnsetOrDefault(key: string, value: unknown): boolean {
    return (
        value === undefined ||
        (key === "args" && Array.isArray(value) && value.length === 0) ||
        (key === "succeedOnAbort" && value === false)
    );
}

/**
 * Gets a copy of a definition, or part of one, that is the same as the copy of any other definition that builds the same tree,
 * by setting the properties of each object in alphabetical order and leaving out those that are unset or have their default value.
 * @param value The definition, or part of a definition.
 */
function normalise(value: unknown): unknown {
    if (Array.isArray(value)) {
        return value.map(normalise);
    }

    if (!isObject(value)) {
        return value;
    }

    return Object.fromEntries(
        Object.keys(value)
            .sort()
            .filter((key) => !isUnsetOrDefault(key, value[key]))
            .map((key) => [key, normalise(value[key])])
    );
}

/**
 * Gets a 53-bit hash of a string as a string of 14 hexadecimal digits, using cyrb53.
 * This is not a cryptographic hash. It is only used to tell definitions apart, and not to protect against anyone making them look the same.
 * @param value The string to hash.
 */
function hashString(value: string): string {
    let h1 = 0xdeadbeef;
    let h2 = 0x41c6ce57;

    for (let index = 0; index < value.length; index++) {
        const code = value.charCodeAt(index);
        h1 = Math.imul(h1 ^ code, 2654435761);
        h2 = Math.imul(h2 ^ code, 1597334677);
    }

    h1 = Math.imul(h1 ^ (h1 >>> 16), 2246822507) ^ Math.imul(h2 ^ (h2 >>> 13), 3266489909);
    h2 = Math.imul(h2 ^ (h2 >>> 16), 2246822507) ^ Math.imul(h1 ^ (h1 >>> 13), 3266489909);

    return (4294967296 * (2097151 & h2) + (h1 >>> 0)).toString(16).padStart(14, "0");
}

/**
 * Gets the root node definitions that make up a tree: the main root node, followed by every other root node that it reaches
 * through branch nodes in order of their identifiers. Root nodes in the definition take precedence over registered subtrees,
 * as they do when the tree is built.
 * @param definition The validated tree definition as an array of root node definitions.
 * @param registeredSubtrees The globally registered subtree root node definitions, by name.
 */
function getReachableRootNodes(
    definition: RootNodeDefinition[],
    registeredSubtrees: { [name: string]: RootNodeDefinition }
): RootNodeDefinition[] {
    const rootNodes = new Map<string | undefined, RootNodeDefinition>();

    Object.entries(registeredSubtrees).forEach(([name, rootNode]) => rootNodes.set(name, { ...rootNode, id: name }));
    definition.forEach((rootNode) => rootNodes.set(rootNode.id, rootNode));

    const main = rootNodes.get(undefined)!;
    const reached = new Map<string, RootNodeDefinition>();
    const pending = [main];

    for (let rootNode = pending.pop(); rootNode; rootNode = pending.pop()) {
        flattenDefinition(rootNode)
            .filter(isBranchNodeDefinition)
            .forEach(({ ref }) => {
                const referenced = rootNodes.get(ref);

                if (referenced && !reached.has(ref)) {
                    reached.set(ref, referenced);
                    pending.push(referenced);
                }
            });
    }

    return [main, ...[...reached.values()].sort(({ id: a }, { id: b }) => (a! < b! ? -1 : a! > b! ? 1 : 0))];
}

/**
 * Gets a hash of a tree definition that identifies it. A definition has the same hash as another when they differ only in
 * ways that make no difference to the tree that is built: an MDSL definition and the equivalent JSON definition, JSON definitions that
 * differ in the order of properties or root nodes, in whether there is a single root node or an array of one, or in leaving out
 * empty arguments and default values, and root nodes that are never reached. Registered subtrees that the tree uses are part of it.
 * @param definition The validated tree definition as an array of root node definitions.
 * @param registeredSubtrees The globally registered subtree root node definitions, by name.
 * @returns The hash of the definition.
 */
export function getDefinitionHash(
    definition: RootNodeDefinition[],
    registeredSubtrees: { [name: string]: RootNodeDefinition } = {}
): string {
    return hashString(JSON.stringify(normalise(getReachableRootNodes(definition, registeredSubtrees))));
}
