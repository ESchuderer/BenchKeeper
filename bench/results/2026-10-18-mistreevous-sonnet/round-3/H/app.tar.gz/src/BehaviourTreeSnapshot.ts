import State, { AnyState, CompleteState } from "./State";

/**
 * The version of the snapshot format that is produced by, and can be restored by, this version of the library.
 */
export const SNAPSHOT_VERSION = 1;

/**
 * The properties that every node snapshot has.
 */
type NodeSnapshotBase<TType extends string> = {
    /**
     * The node type.
     */
    type: TType;
    /**
     * The node name. A snapshot can only be restored to a node with the same type and name.
     */
    name: string;
    /**
     * The state of the node.
     */
    state: AnyState;
};

/**
 * The snapshot of a condition node, which has no state other than its own.
 */
export type ConditionNodeSnapshot = NodeSnapshotBase<"condition">;

/**
 * The snapshot of a node that has a single child node, and no state other than its own state and that of its child.
 */
export type SingleChildNodeSnapshot = NodeSnapshotBase<"root" | "flip" | "succeed" | "fail"> & {
    /**
     * The snapshot of the child node.
     */
    children: [NodeSnapshot];
};

/**
 * The snapshot of a composite node that has no state other than its own state and that of its children.
 */
export type CompositeNodeSnapshot = NodeSnapshotBase<"sequence" | "selector" | "parallel" | "race" | "all"> & {
    /**
     * The snapshots of the child nodes.
     */
    children: NodeSnapshot[];
};

/**
 * The snapshot of a lotto node.
 */
export type LottoNodeSnapshot = NodeSnapshotBase<"lotto"> & {
    /**
     * The snapshots of the child nodes.
     */
    children: NodeSnapshot[];
    /**
     * The index of the child node that was picked as the active child, or null if one has not been picked.
     */
    selectedChild: number | null;
};

/**
 * The snapshot of a repeat node.
 */
export type RepeatNodeSnapshot = NodeSnapshotBase<"repeat"> & {
    /**
     * The snapshot of the child node.
     */
    children: [NodeSnapshot];
    /**
     * The number of iterations completed so far.
     */
    currentIterationCount: number;
    /**
     * The number of iterations to complete, or null if the node repeats indefinitely.
     * This is the result of any random selection between a minimum and maximum number of iterations.
     */
    targetIterationCount: number | null;
};

/**
 * The snapshot of a retry node.
 */
export type RetryNodeSnapshot = NodeSnapshotBase<"retry"> & {
    /**
     * The snapshot of the child node.
     */
    children: [NodeSnapshot];
    /**
     * The number of attempts made so far.
     */
    currentAttemptCount: number;
    /**
     * The number of attempts to make, or null if the node retries indefinitely.
     * This is the result of any random selection between a minimum and maximum number of attempts.
     */
    targetAttemptCount: number | null;
};

/**
 * The snapshot of a wait node.
 */
export type WaitNodeSnapshot = NodeSnapshotBase<"wait"> & {
    /**
     * The duration in milliseconds that the node has waited for so far.
     * This is 0 unless the node is in the RUNNING state.
     */
    waitedDuration: number;
    /**
     * The duration in milliseconds that the node will wait for in total, or null if it waits indefinitely.
     * This is the result of any random selection between a minimum and maximum duration.
     * This is null unless the node is in the RUNNING state.
     */
    totalDuration: number | null;
};

/**
 * The snapshot of an action node.
 * A node that is waiting for a promise that has not resolved is snapshotted as not yet started, with a state of READY,
 * as the promise cannot be stored. Its action function is called again on the next update of the restored node.
 */
export type ActionNodeSnapshot = NodeSnapshotBase<"action"> & {
    /**
     * The finished state that a promise returned by the action function resolved with, or null if the action
     * function has not returned a promise or the promise has not resolved yet. This is the state that the node
     * will take on its next update.
     */
    resolvedState: CompleteState | null;
};

/**
 * The snapshot of a node in a behaviour tree.
 */
export type NodeSnapshot =
    | ConditionNodeSnapshot
    | SingleChildNodeSnapshot
    | CompositeNodeSnapshot
    | LottoNodeSnapshot
    | RepeatNodeSnapshot
    | RetryNodeSnapshot
    | WaitNodeSnapshot
    | ActionNodeSnapshot;

/**
 * The snapshot of the execution state of a behaviour tree.
 * This is a plain object that is not changed by JSON.stringify followed by JSON.parse, so it can be stored and restored later.
 */
export type BehaviourTreeSnapshot = {
    /**
     * The version of the snapshot format.
     */
    version: typeof SNAPSHOT_VERSION;
    /**
     * A hash that identifies the definition of the tree that the snapshot was taken from. A snapshot can only be restored to a tree with the same definition.
     * An MDSL definition and the equivalent JSON definition are the same definition.
     */
    definitionHash: string;
    /**
     * The snapshot of the root node, which contains the snapshots of every node in the tree.
     */
    root: NodeSnapshot;
};

/**
 * The properties of a node snapshot, before they have been validated, as they are not known to be correct.
 */
export type UnvalidatedNodeSnapshot = { [property: string]: unknown };

/**
 * Gets whether the value is an object that is not an array.
 * @param value The value to check.
 */
export function isObject(value: unknown): value is { [property: string]: unknown } {
    return typeof value === "object" && value !== null && !Array.isArray(value);
}

/**
 * Gets whether the value is a finished node state.
 * @param value The value to check.
 */
export function isCompleteState(value: unknown): value is CompleteState {
    return value === State.SUCCEEDED || value === State.FAILED;
}

/**
 * Gets whether the value is a non-negative integer.
 * @param value The value to check.
 */
export function isCount(value: unknown): value is number {
    return typeof value === "number" && Number.isInteger(value) && value >= 0;
}

/**
 * Gets whether the value is an integer.
 * @param value The value to check.
 */
export function isInteger(value: unknown): value is number {
    return typeof value === "number" && Number.isInteger(value);
}

/**
 * Gets whether the value is a finite number.
 * @param value The value to check.
 */
export function isFiniteNumber(value: unknown): value is number {
    return typeof value === "number" && Number.isFinite(value);
}

/**
 * Gets whether the value is a node state.
 * @param value The value to check.
 */
export function isState(value: unknown): value is AnyState {
    return Object.values(State).includes(value as State);
}
