import { assert } from "chai";

import { RootNodeDefinition } from "../src/BehaviourTreeDefinition";
import { getDefinitionHash } from "../src/BehaviourTreeDefinitionHash";
import { convertMDSLToJSON } from "../src/mdsl/MDSLDefinitionParser";

describe("The hash of a definition", () => {
    const hashOf = (mdsl: string) => getDefinitionHash(convertMDSLToJSON(mdsl));

    it("is 14 hexadecimal digits", () => {
        assert.match(hashOf("root { action [Work] }"), /^[0-9a-f]{14}$/);
    });

    it("is the same each time it is worked out", () => {
        assert.equal(hashOf("root { action [Work] }"), hashOf("root { action [Work] }"));
    });

    it("is different for definitions that differ in a single character of an argument", () => {
        assert.notEqual(hashOf('root { action [Work, "ab"] }'), hashOf('root { action [Work, "ac"] }'));
    });

    it("is different for definitions that differ in the type of an argument", () => {
        assert.notEqual(hashOf('root { action [Work, "1"] }'), hashOf("root { action [Work, 1] }"));
        assert.notEqual(hashOf("root { action [Work, null] }"), hashOf('root { action [Work, "null"] }'));
        assert.notEqual(hashOf("root { action [Work, true] }"), hashOf('root { action [Work, "true"] }'));
    });

    it("is different for definitions that differ in the arguments of a guard", () => {
        assert.notEqual(hashOf("root { action [Work] while(Ok, 1) }"), hashOf("root { action [Work] while(Ok, 2) }"));
    });

    it("is different for definitions that differ in a subtree that is used", () => {
        assert.notEqual(
            hashOf("root [Sub] { action [Work, 1] } root { branch [Sub] }"),
            hashOf("root [Sub] { action [Work, 2] } root { branch [Sub] }")
        );
    });

    it("is the same for definitions that differ only in a subtree that is never used", () => {
        assert.equal(
            hashOf("root [Unused] { action [Work, 2] } root { action [Work] }"),
            hashOf("root { action [Work] }")
        );
    });

    it("is different for definitions that differ in a registered subtree that is used", () => {
        const registered = (rootNode: string) => ({ Sub: convertMDSLToJSON(rootNode)[0] });
        const main = convertMDSLToJSON("root { branch [Sub] }");

        assert.notEqual(
            getDefinitionHash(main, registered("root { action [Work, 1] }")),
            getDefinitionHash(main, registered("root { action [Work, 2] }"))
        );
    });

    it("is the same for a subtree that is registered and for the same subtree in the definition", () => {
        const sub = convertMDSLToJSON("root { action [Work, 1] }")[0];

        assert.equal(
            getDefinitionHash(convertMDSLToJSON("root { branch [Sub] }"), { Sub: sub }),
            hashOf("root [Sub] { action [Work, 1] } root { branch [Sub] }")
        );
    });

    it("does not depend on a registered subtree that is not used, or one that the definition replaces", () => {
        const main = convertMDSLToJSON("root [Sub] { action [Work, 1] } root { branch [Sub] }");
        const other = convertMDSLToJSON("root { action [Other] }")[0];

        assert.equal(getDefinitionHash(main, { Sub: other, Unused: other }), getDefinitionHash(main));
    });

    it("is the same for the JSON definition that MDSL is converted to, however the properties are ordered", () => {
        const reordered: RootNodeDefinition[] = [
            { child: { call: "Work", type: "action", args: [] }, type: "root" } as RootNodeDefinition
        ];

        assert.equal(getDefinitionHash(reordered), hashOf("root { action [Work] }"));
    });

    it("does not change the definition that it is given", () => {
        const definition: RootNodeDefinition[] = [
            { type: "root", id: "B", child: { type: "action", call: "Work", args: [] } },
            { type: "root", child: { type: "action", call: "Work", args: [] } }
        ];
        const before = JSON.stringify(definition);

        getDefinitionHash(definition);

        assert.equal(JSON.stringify(definition), before);
    });
});
