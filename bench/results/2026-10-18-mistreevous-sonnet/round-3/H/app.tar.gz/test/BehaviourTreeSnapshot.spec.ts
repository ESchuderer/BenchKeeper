import { assert } from "chai";
import sinon, { SinonFakeTimers } from "sinon";

import { BehaviourTree, BehaviourTreeSnapshot, State } from "../src/index";
import { Agent } from "../src/Agent";
import { RootNodeDefinition } from "../src/BehaviourTreeDefinition";

import { assertRestoredTreeBehavesLikeOriginal, ScenarioWorld, withoutNodeIds } from "./TestUtilities";

/**
 * Creates an agent with a small set of functions that record their calls and base their results on the scenario world:
 *  - Work(n)   An action that is running until step n and then succeeds.
 *  - Break(n)  An action that is running until step n and then fails.
 *  - IsReady   A condition that is true from step 3 onwards.
 *  - IsOkay    A condition that is true until step 5.
 * Entry, step and exit callbacks are recorded as well.
 */
const createAgent = (log: string[], world: ScenarioWorld): Agent => ({
    Work: (until: number) => {
        log.push(`Work ${until}`);
        return world.step >= until ? State.SUCCEEDED : State.RUNNING;
    },
    Break: (until: number) => {
        log.push(`Break ${until}`);
        return world.step >= until ? State.FAILED : State.RUNNING;
    },
    IsReady: () => {
        log.push("IsReady");
        return world.step >= 3;
    },
    IsOkay: () => {
        log.push("IsOkay");
        return world.step < 5;
    },
    OnEntry: (name: string) => log.push(`entry ${name}`),
    OnStep: (name: string) => log.push(`step ${name}`),
    OnExit: (name: string, result: { succeeded: boolean; aborted: boolean }) =>
        log.push(`exit ${name} ${result.succeeded} ${result.aborted}`)
});

describe("A behaviour tree", () => {
    afterEach(() => BehaviourTree.unregisterAll());

    describe("has a snapshot() method that", () => {
        it("returns a snapshot that is unchanged by JSON.stringify and JSON.parse", () => {
            const tree = new BehaviourTree(
                "root { sequence { action [Work, 1] selector { condition [IsReady] action [Work, 9] } } }",
                createAgent([], { step: 1 })
            );
            tree.step();

            const snapshot = tree.snapshot();

            assert.deepEqual(JSON.parse(JSON.stringify(snapshot)), snapshot);
        });

        it("returns a snapshot containing only plain objects, arrays, strings, numbers, booleans and null", () => {
            const tree = new BehaviourTree(
                "root { parallel { action [Work, 1] wait [100] } }",
                createAgent([], { step: 0 })
            );
            tree.step();

            const isPlain = (value: unknown): boolean => {
                if (value === null || ["string", "number", "boolean"].includes(typeof value)) {
                    return true;
                }
                if (Array.isArray(value)) {
                    return value.every(isPlain);
                }
                return (
                    typeof value === "object" &&
                    Object.getPrototypeOf(value) === Object.prototype &&
                    Object.values(value as object).every(isPlain)
                );
            };

            assert.isTrue(isPlain(tree.snapshot()));
        });

        it("does not call any agent functions, change the state of the tree or use the 'random' function", () => {
            const log: string[] = [];
            let randomCalls = 0;
            const tree = new BehaviourTree(
                "root { sequence { action [Work, 1] lotto { action [Work, 9] action [Work, 9] } } }",
                createAgent(log, { step: 0 }),
                { random: () => (randomCalls++, 0.5) }
            );
            tree.step();
            log.length = 0;
            randomCalls = 0;
            const detailsBefore = withoutNodeIds(tree.getTreeNodeDetails());

            tree.snapshot();

            assert.deepEqual(log, []);
            assert.equal(randomCalls, 0);
            assert.deepEqual(withoutNodeIds(tree.getTreeNodeDetails()), detailsBefore);
        });

        it("returns a snapshot that does not change when the tree is stepped afterwards", () => {
            const world = { step: 0 };
            const tree = new BehaviourTree(
                "root { sequence { action [Work, 2] action [Work, 4] } }",
                createAgent([], world)
            );
            tree.step();

            const snapshot = tree.snapshot();
            const snapshotBefore = JSON.stringify(snapshot);
            world.step = 4;
            tree.step();

            assert.equal(JSON.stringify(snapshot), snapshotBefore);
        });

        describe("throws an error, rather than returning a snapshot that could not be stored and restored, if", () => {
            it("a wait node has waited for a duration that is not a finite number", () => {
                const tree = new BehaviourTree("root { wait [1000] }", {}, { getDeltaTime: () => -Infinity });
                tree.step();

                assert.throws(
                    () => tree.snapshot(),
                    Error,
                    "error creating snapshot: expected node 'ROOT > WAIT 1000ms' to have a waited duration that is a finite number but it has '-Infinity'"
                );
            });

            it("a repeat node has a target iteration count that is not a number", () => {
                const tree = new BehaviourTree(
                    "root { repeat [1, 3] { action [Work, 9] } }",
                    createAgent([], { step: 0 }),
                    {
                        random: () => NaN
                    }
                );
                tree.step();

                assert.throws(
                    () => tree.snapshot(),
                    Error,
                    "error creating snapshot: expected node 'ROOT > REPEAT 1x-3x' to have a target iteration count that is null or an integer but it has 'NaN'"
                );
            });
        });
    });

    describe("has a snapshot that is independent of the tree, so that", () => {
        const definitions: { [description: string]: string } = {
            "a sequence of actions": "root { sequence { action [Work, 2] action [Work, 4] } }",
            "wait, repeat and retry nodes":
                "root { repeat [3] { retry [2] { sequence { wait [100] action [Work, 3] } } } }",
            "a lotto node and a race":
                "root { sequence { lotto { action [Work, 2] action [Work, 2] } race { action [Work, 5] wait [300] } } }"
        };

        let clock: SinonFakeTimers;

        beforeEach(() => {
            clock = sinon.useFakeTimers();
        });

        afterEach(() => {
            clock.restore();
        });

        const stepOnce = (tree: BehaviourTree, world: ScenarioWorld) => {
            world.step++;
            clock.tick(40);
            tree.step();
        };

        Object.entries(definitions).forEach(([description, definition]) => {
            describe(`for ${description}`, () => {
                it("stepping the tree does not change the snapshot", () => {
                    const world = { step: 0 };
                    const tree = new BehaviourTree(definition, createAgent([], world), { random: () => 0.5 });
                    stepOnce(tree, world);
                    const snapshot = tree.snapshot();
                    const snapshotBefore = JSON.stringify(snapshot);

                    for (let step = 0; step < 8; step++) {
                        stepOnce(tree, world);
                        assert.equal(JSON.stringify(snapshot), snapshotBefore, `changed by step ${step}`);
                    }
                });

                it("stepping a tree that the snapshot was restored to does not change the snapshot", () => {
                    const world = { step: 0 };
                    const source = new BehaviourTree(definition, createAgent([], world), { random: () => 0.5 });
                    stepOnce(source, world);
                    const snapshot = source.snapshot();
                    const snapshotBefore = JSON.stringify(snapshot);

                    const restored = new BehaviourTree(definition, createAgent([], world), { random: () => 0.5 });
                    restored.restore(snapshot);

                    for (let step = 0; step < 8; step++) {
                        stepOnce(restored, world);
                        assert.equal(JSON.stringify(snapshot), snapshotBefore, `changed by step ${step}`);
                    }
                });

                it("a snapshot taken right after restoring it, before the tree is stepped, equals it", () => {
                    for (let stepsBeforeSnapshot = 0; stepsBeforeSnapshot < 8; stepsBeforeSnapshot++) {
                        const world = { step: 0 };
                        const source = new BehaviourTree(definition, createAgent([], world), { random: () => 0.5 });
                        for (let step = 0; step < stepsBeforeSnapshot; step++) {
                            stepOnce(source, world);
                        }
                        const snapshot = JSON.parse(JSON.stringify(source.snapshot()));

                        const restored = new BehaviourTree(definition, createAgent([], world), { random: () => 0.9 });
                        clock.tick(1000);
                        restored.restore(snapshot);
                        // Time passing between restoring and taking the snapshot must not matter either.
                        clock.tick(30);

                        assert.deepEqual(
                            JSON.parse(JSON.stringify(restored.snapshot())),
                            snapshot,
                            `after ${stepsBeforeSnapshot} steps`
                        );
                    }
                });
            });
        });

        it("a snapshot taken right after restoring it equals it when 'getDeltaTime' is used to work out the time waited", () => {
            const options = { getDeltaTime: () => 0.3 };
            const definition = "root { parallel { wait [1000] wait [5000] } }";
            const source = new BehaviourTree(definition, {}, options);
            source.step();
            source.step();
            const snapshot = JSON.parse(JSON.stringify(source.snapshot()));

            const restored = new BehaviourTree(definition, {}, options);
            restored.restore(snapshot);
            clock.tick(30);

            assert.deepEqual(JSON.parse(JSON.stringify(restored.snapshot())), snapshot);
        });
    });

    describe("has a restore() method that", () => {
        describe("sets a tree built from the same definition to the state of the snapshotted tree, such that it behaves identically from then on, for", () => {
            const definitions: { [description: string]: string } = {
                "a sequence": "root { sequence { action [Work, 1] action [Work, 3] action [Work, 5] } }",
                "a selector":
                    "root { selector { action [Break, 1] condition [IsReady] action [Break, 4] action [Work, 6] } }",
                "a parallel": "root { parallel { action [Work, 2] action [Work, 4] action [Work, 3] } }",
                "a parallel that fails":
                    "root { sequence { parallel { action [Work, 5] action [Break, 3] } action [Work, 7] } }",
                "a race": "root { race { action [Work, 5] action [Break, 3] action [Work, 4] } }",
                "an all": "root { all { action [Work, 2] action [Break, 4] action [Work, 6] } }",
                "a flip": "root { sequence { flip { action [Break, 2] } flip { action [Work, 4] } } }",
                "a succeed": "root { sequence { succeed { action [Break, 2] } action [Work, 4] } }",
                "a fail": "root { selector { fail { action [Work, 2] } action [Work, 4] } }",
                conditions: "root { sequence { condition [IsReady] condition [IsOkay] action [Work, 6] } }",
                "entry, step and exit callbacks":
                    'root { sequence { action [Work, 2] entry(OnEntry, "a") step(OnStep, "a") exit(OnExit, "a") action [Work, 4] entry(OnEntry, "b") step(OnStep, "b") exit(OnExit, "b") } }',
                guards: 'root { sequence { action [Work, 3] while(IsOkay) entry(OnEntry, "a") exit(OnExit, "a") action [Work, 9] } }',
                "nested nodes":
                    "root { sequence { parallel { sequence { action [Work, 1] action [Work, 3] } selector { action [Break, 2] action [Work, 5] } } flip { race { action [Break, 7] action [Work, 8] } } } }"
            };

            Object.entries(definitions).forEach(([description, definition]) => {
                it(description, () => {
                    // Take a snapshot at every point of a run, including before the first step and after the tree finishes.
                    for (let stepsBeforeSnapshot = 0; stepsBeforeSnapshot <= 10; stepsBeforeSnapshot++) {
                        assertRestoredTreeBehavesLikeOriginal({
                            definition,
                            createAgent,
                            stepsBeforeSnapshot,
                            stepsAfterRestore: 10
                        });
                    }
                });
            });

            it("a definition in JSON", () => {
                const definition = {
                    type: "root" as const,
                    child: {
                        type: "sequence" as const,
                        children: [
                            { type: "action" as const, call: "Work", args: [2] },
                            { type: "action" as const, call: "Work", args: [4] }
                        ]
                    }
                };

                for (let stepsBeforeSnapshot = 0; stepsBeforeSnapshot <= 5; stepsBeforeSnapshot++) {
                    assertRestoredTreeBehavesLikeOriginal({
                        definition,
                        createAgent,
                        stepsBeforeSnapshot,
                        stepsAfterRestore: 5
                    });
                }
            });
        });

        it("can restore a snapshot into the tree that it was taken from after that tree has moved on", () => {
            const log: string[] = [];
            const world = { step: 0 };
            const tree = new BehaviourTree(
                "root { sequence { action [Work, 2] action [Work, 4] } }",
                createAgent(log, world)
            );
            tree.step();
            const snapshot = JSON.parse(JSON.stringify(tree.snapshot()));
            const detailsAtSnapshot = withoutNodeIds(tree.getTreeNodeDetails());

            world.step = 5;
            tree.step();
            tree.step();
            assert.equal(tree.getState(), State.SUCCEEDED);

            tree.restore(snapshot);

            assert.deepEqual(withoutNodeIds(tree.getTreeNodeDetails()), detailsAtSnapshot);
        });

        it("can restore the same snapshot into more than one tree, which then run independently", () => {
            const world = { step: 0 };
            const definition = "root { sequence { action [Work, 2] action [Work, 4] } }";
            const first = new BehaviourTree(definition, createAgent([], world));
            first.step();
            const snapshot = first.snapshot();

            const second = new BehaviourTree(definition, createAgent([], world));
            const third = new BehaviourTree(definition, createAgent([], world));
            second.restore(snapshot);
            third.restore(snapshot);
            world.step = 2;
            second.step();

            assert.notDeepEqual(
                withoutNodeIds(second.getTreeNodeDetails()),
                withoutNodeIds(third.getTreeNodeDetails())
            );
            assert.deepEqual(withoutNodeIds(third.getTreeNodeDetails()), withoutNodeIds(first.getTreeNodeDetails()));
        });

        it("does not call 'onNodeStateChange' for the nodes that it changes the state of", () => {
            const definition = "root { sequence { action [Work, 1] action [Work, 9] } }";
            const world = { step: 0 };
            const source = new BehaviourTree(definition, createAgent([], world));
            source.step();
            world.step = 1;
            source.step();

            const changes: unknown[] = [];
            const target = new BehaviourTree(definition, createAgent([], world), {
                onNodeStateChange: (change) => changes.push(change)
            });
            target.restore(source.snapshot());

            assert.deepEqual(changes, []);
            assert.equal(target.getState(), State.RUNNING);
        });

        describe("does not call 'onNodeStateChange', and leaves the next step to report changes as usual, for", () => {
            const definitions: { [description: string]: string } = {
                "running composites and actions":
                    "root { sequence { parallel { action [Work, 2] action [Work, 9] } action [Work, 9] } }",
                "wait, repeat and retry nodes":
                    "root { repeat [3] { retry [2] { sequence { wait [100] action [Work, 9] } } } }",
                "a lotto node": "root { lotto [1, 3] { action [Work, 9] action [Break, 9] } }",
                "a race with a finished child": "root { race { action [Work, 1] action [Work, 9] } }",
                "a finished tree": "root { sequence { action [Work, 1] action [Work, 1] } }"
            };

            Object.entries(definitions).forEach(([description, definition]) => {
                it(description, () => {
                    const clock = sinon.useFakeTimers();

                    try {
                        const world = { step: 0 };
                        const sourceChanges: unknown[] = [];
                        const restoredChanges: unknown[] = [];
                        const source = new BehaviourTree(definition, createAgent([], world), {
                            random: () => 0.5,
                            onNodeStateChange: ({ id, ...change }) => sourceChanges.push(change)
                        });
                        const restored = new BehaviourTree(definition, createAgent([], world), {
                            random: () => 0.5,
                            onNodeStateChange: ({ id, ...change }) => restoredChanges.push(change)
                        });

                        source.step();
                        world.step = 1;
                        clock.tick(50);
                        source.step();
                        restored.restore(JSON.parse(JSON.stringify(source.snapshot())));

                        assert.deepEqual(restoredChanges, []);

                        // The next step reports the changes that it makes, which are the changes that the original tree makes.
                        sourceChanges.length = 0;
                        world.step = 9;
                        clock.tick(100);
                        source.step();
                        restored.step();

                        assert.isNotEmpty(sourceChanges);
                        assert.deepEqual(restoredChanges, sourceChanges);
                    } finally {
                        clock.restore();
                    }
                });
            });
        });

        describe("restores a snapshot of a finished tree as finished, and the next step starts a new run", () => {
            ["succeeds", "fails"].forEach((outcome) => {
                it(`(tree ${outcome})`, () => {
                    const definition =
                        outcome === "succeeds"
                            ? "root { sequence { action [Work, 1] action [Work, 2] } }"
                            : "root { sequence { action [Work, 1] action [Break, 2] } }";

                    const world = { step: 2 };
                    const log: string[] = [];
                    const original = new BehaviourTree(definition, createAgent(log, world));
                    original.step();
                    assert.equal(original.getState(), outcome === "succeeds" ? State.SUCCEEDED : State.FAILED);

                    const restored = new BehaviourTree(definition, createAgent(log, world));
                    restored.restore(JSON.parse(JSON.stringify(original.snapshot())));

                    assert.equal(restored.getState(), original.getState());
                    assert.isFalse(restored.isRunning());
                    assert.deepEqual(
                        withoutNodeIds(restored.getTreeNodeDetails()),
                        withoutNodeIds(original.getTreeNodeDetails())
                    );

                    // The next step should start from the beginning again.
                    log.length = 0;
                    world.step = 0;
                    restored.step();

                    assert.deepEqual(log, ["Work 1"]);
                    assert.equal(restored.getState(), State.RUNNING);
                });
            });

            it("making the same calls and state changes as the original tree does for its next run", () => {
                // The tree finishes at step 3, so snapshots taken from step 4 onwards are of a finished tree.
                for (let stepsBeforeSnapshot = 4; stepsBeforeSnapshot <= 8; stepsBeforeSnapshot++) {
                    assertRestoredTreeBehavesLikeOriginal({
                        definition: "root { sequence { action [Work, 1] action [Work, 3] } }",
                        createAgent: (log, world) => ({
                            Work: (until: number) => {
                                log.push(`Work ${until}`);
                                // Every other run is slower, so that the runs are distinguishable.
                                return world.step % 4 >= until % 4 ? State.SUCCEEDED : State.RUNNING;
                            }
                        }),
                        stepsBeforeSnapshot,
                        stepsAfterRestore: 6
                    });
                }
            });
        });

        describe("throws an error, leaving the tree unchanged, if the snapshot", () => {
            const definition = "root { sequence { action [Work, 1] repeat [2] { action [Work, 9] } } }";

            const createTreeAndSnapshot = () => {
                const world = { step: 1 };
                const source = new BehaviourTree(definition, createAgent([], world));
                source.step();
                const snapshot: any = JSON.parse(JSON.stringify(source.snapshot()));

                const target = new BehaviourTree(definition, createAgent([], world));
                return { target, snapshot };
            };

            const assertRestoreThrows = (modify: (snapshot: any) => any, message: string) => {
                const { target, snapshot } = createTreeAndSnapshot();
                const detailsBefore = withoutNodeIds(target.getTreeNodeDetails());

                assert.throws(() => target.restore(modify(snapshot)), Error, message);
                assert.deepEqual(withoutNodeIds(target.getTreeNodeDetails()), detailsBefore);
            };

            // Where the first action node is within the snapshot.
            const firstAction = (snapshot: any) => snapshot.root.children[0].children[0];

            it("is not an object", () => {
                assertRestoreThrows(() => null, "invalid snapshot: expected an object");
                assertRestoreThrows(() => "snapshot", "invalid snapshot: expected an object");
            });

            it("has an unsupported version", () => {
                assertRestoreThrows(
                    (snapshot) => ({ ...snapshot, version: 99 }),
                    "invalid snapshot: unsupported version '99'"
                );
            });

            it("has no root node", () => {
                assertRestoreThrows(
                    ({ version, definitionHash }) => ({ version, definitionHash }),
                    "invalid snapshot: expected an object for node 'ROOT'"
                );
            });

            it("is for a node of a different type", () => {
                assertRestoreThrows((snapshot) => {
                    firstAction(snapshot).type = "condition";
                    return snapshot;
                }, "invalid snapshot: expected node 'ROOT > SEQUENCE > Work' to be an action");
            });

            it("is for a node with a different name, such as from a different definition", () => {
                assertRestoreThrows((snapshot) => {
                    firstAction(snapshot).name = "Rest";
                    return snapshot;
                }, "invalid snapshot: expected node 'ROOT > SEQUENCE > Work' to be named 'Work' but it is named 'Rest'");
            });

            it("has a node with a different number of children", () => {
                assertRestoreThrows((snapshot) => {
                    snapshot.root.children[0].children.pop();
                    return snapshot;
                }, "invalid snapshot: expected node 'ROOT > SEQUENCE' to have 2 children but it has 1");
            });

            it("has a node with an invalid state", () => {
                assertRestoreThrows((snapshot) => {
                    firstAction(snapshot).state = "mistreevous.sleeping";
                    return snapshot;
                }, "invalid snapshot: expected node 'ROOT > SEQUENCE > Work' to have a valid state but it has 'mistreevous.sleeping'");
            });

            it("is for a tree with a different structure further down, without changing any of the nodes before it", () => {
                const { target, snapshot } = createTreeAndSnapshot();
                snapshot.root.children[0].children[1].children[0].name = "Rest";
                const detailsBefore = withoutNodeIds(target.getTreeNodeDetails());

                assert.throws(() => target.restore(snapshot), Error, "invalid snapshot");
                assert.deepEqual(withoutNodeIds(target.getTreeNodeDetails()), detailsBefore);
            });
        });
    });

    describe("has a snapshot that belongs to the definition of the tree, so that restore() throws an error, leaving the tree unchanged, if", () => {
        type Definition = string | RootNodeDefinition | RootNodeDefinition[];

        const mismatch = "invalid snapshot: the snapshot does not match the tree's definition";

        const takeSnapshot = (definition: Definition) => {
            const tree = new BehaviourTree(definition, createAgent([], { step: 1 }));
            tree.step();
            return JSON.parse(JSON.stringify(tree.snapshot()));
        };

        /** Restores the input to a tree stepped once, checking that it throws and that the tree is the same afterwards. */
        const assertRestoreThrows = (target: BehaviourTree, input: unknown, message: string) => {
            const detailsBefore = withoutNodeIds(target.getTreeNodeDetails());
            const snapshotBefore = JSON.stringify(target.snapshot());

            assert.throws(() => target.restore(input as BehaviourTreeSnapshot), Error, message);

            assert.deepEqual(withoutNodeIds(target.getTreeNodeDetails()), detailsBefore);
            assert.equal(JSON.stringify(target.snapshot()), snapshotBefore);
        };

        const assertRestoreMismatch = (targetDefinition: Definition, snapshotDefinition: Definition) => {
            const target = new BehaviourTree(targetDefinition, createAgent([], { step: 1 }));
            target.step();

            assertRestoreThrows(target, takeSnapshot(snapshotDefinition), mismatch);
        };

        describe("the snapshot was taken from a tree with a different definition, which", () => {
            const definition = "root { sequence { action [Work, 1] repeat [2] { action [Work, 9] } } }";

            const differentDefinitions: { [description: string]: string } = {
                "has an action with different arguments":
                    "root { sequence { action [Work, 2] repeat [2] { action [Work, 9] } } }",
                "has a different action": "root { sequence { action [Break, 1] repeat [2] { action [Work, 9] } } }",
                "has the same nodes in a different order":
                    "root { sequence { repeat [2] { action [Work, 9] } action [Work, 1] } }",
                "has a different type of composite node":
                    "root { selector { action [Work, 1] repeat [2] { action [Work, 9] } } }",
                "has a different number of iterations":
                    "root { sequence { action [Work, 1] repeat [3] { action [Work, 9] } } }",
                "has an extra node": "root { sequence { action [Work, 1] repeat [2] { action [Work, 9] } wait } }",
                "has a guard": "root { sequence { action [Work, 1] while(IsOkay) repeat [2] { action [Work, 9] } } }",
                "has a guard with different arguments":
                    "root { sequence { action [Work, 1] while(IsOkay, 1) repeat [2] { action [Work, 9] } } }",
                "has a guard that succeeds on abort":
                    "root { sequence { action [Work, 1] while(IsOkay) then succeed repeat [2] { action [Work, 9] } } }",
                "has a callback":
                    "root { sequence { action [Work, 1] entry(OnEntry, 1) repeat [2] { action [Work, 9] } } }"
            };

            Object.entries(differentDefinitions).forEach(([description, other]) => {
                it(description, () => {
                    assertRestoreMismatch(definition, other);
                    assertRestoreMismatch(other, definition);
                });
            });

            it("has different lotto weights", () => {
                assertRestoreMismatch(
                    "root { lotto [1, 2] { action [Work, 1] action [Work, 2] } }",
                    "root { lotto [2, 1] { action [Work, 1] action [Work, 2] } }"
                );
            });

            it("has a different subtree", () => {
                assertRestoreMismatch(
                    "root [Sub] { action [Work, 1] } root { branch [Sub] }",
                    "root [Sub] { action [Work, 2] } root { branch [Sub] }"
                );
            });

            it("has nodes of the same types and names in every position, so that only the definition tells them apart", () => {
                assertRestoreMismatch(
                    "root { parallel { action [Work, 1, 2] action [Work, 3] } }",
                    "root { parallel { action [Work, 1] action [Work, 3, 2] } }"
                );
            });
        });

        describe("the snapshot is not a snapshot, as it is", () => {
            const definition = "root { sequence { action [Work, 1] action [Work, 9] } }";

            const notSnapshots: { [description: string]: () => unknown } = {
                null: () => null,
                undefined: () => undefined,
                "a string": () => "snapshot",
                "a number": () => 1,
                "a boolean": () => true,
                "an array": () => [],
                "an array of snapshots": () => [takeSnapshot(definition)],
                "an object without any of the fields of a snapshot": () => ({}),
                "an object with unrelated fields": () => ({ name: "snapshot", state: "mistreevous.running" }),
                "a node snapshot rather than a snapshot": () => takeSnapshot(definition).root,
                "a snapshot without a root node": () => {
                    const { root, ...snapshot } = takeSnapshot(definition);
                    return snapshot;
                },
                "a snapshot without a version": () => {
                    const { version, ...snapshot } = takeSnapshot(definition);
                    return snapshot;
                },
                "a snapshot without a definition": () => {
                    const { definitionHash, ...snapshot } = takeSnapshot(definition);
                    return snapshot;
                },
                "a snapshot with a definition that is not a string": () => ({
                    ...takeSnapshot(definition),
                    definitionHash: 1
                }),
                "a snapshot with a definition that is null": () => ({
                    ...takeSnapshot(definition),
                    definitionHash: null
                })
            };

            Object.entries(notSnapshots).forEach(([description, createInput]) => {
                it(description, () => {
                    const target = new BehaviourTree(definition, createAgent([], { step: 1 }));
                    target.step();

                    assertRestoreThrows(target, createInput(), "invalid snapshot");
                });
            });
        });

        it("the snapshot was taken from a tree that used a registered subtree that was registered differently", () => {
            BehaviourTree.register("Sub", "root { action [Work, 1] }");
            const snapshot = takeSnapshot("root { branch [Sub] }");

            BehaviourTree.register("Sub", "root { action [Work, 2] }");
            const target = new BehaviourTree("root { branch [Sub] }", createAgent([], { step: 1 }));
            target.step();

            assertRestoreThrows(target, snapshot, mismatch);
        });

        it("the definition recorded in the snapshot is not the one that the tree has, although its nodes line up", () => {
            const definition = "root { sequence { action [Work, 1] action [Work, 9] } }";
            const snapshot = takeSnapshot(definition);
            snapshot.definitionHash = snapshot.definitionHash.replace(/.$/, (digit: string) =>
                digit === "0" ? "1" : "0"
            );
            const target = new BehaviourTree(definition, createAgent([], { step: 1 }));

            assertRestoreThrows(target, snapshot, mismatch);
        });

        it("the snapshot has an unsupported version and a definition that does not match, which is reported as the version", () => {
            const snapshot = { ...takeSnapshot("root { action [Work, 1] }"), version: 99 };
            const target = new BehaviourTree("root { action [Work, 2] }", createAgent([], { step: 1 }));

            assertRestoreThrows(target, snapshot, "invalid snapshot: unsupported version '99'");
        });

        it("the snapshot has a node that does not match and a definition that does not match, which is reported as the definition", () => {
            const target = new BehaviourTree("root { action [Work, 1] }", createAgent([], { step: 1 }));

            assertRestoreThrows(target, takeSnapshot("root { sequence { action [Break, 1] } }"), mismatch);
        });
    });

    it("has a constructor that reports a definition that cannot be hashed as an error building the tree", () => {
        const definition = { type: "root", child: { type: "action", call: "Work", args: [BigInt(1)] } };

        assert.throws(
            () => new BehaviourTree(definition as any, createAgent([], { step: 0 })),
            Error,
            "error building tree: "
        );
    });

    describe("has a snapshot that is accepted by a tree with the same definition, however it is written, such as", () => {
        type Definition = string | RootNodeDefinition | RootNodeDefinition[];

        const restoreInto = (snapshotDefinition: Definition, targetDefinition: Definition) => {
            const world = { step: 1 };
            const source = new BehaviourTree(snapshotDefinition, createAgent([], world));
            source.step();
            const target = new BehaviourTree(targetDefinition, createAgent([], world));

            target.restore(JSON.parse(JSON.stringify(source.snapshot())));

            assert.deepEqual(withoutNodeIds(target.getTreeNodeDetails()), withoutNodeIds(source.getTreeNodeDetails()));
        };

        const mdsl = `root [Cleanup] {
            action [Work, 3]
        }
        root {
            sequence {
                action [Work, 1, "a", null, true]
                condition [IsReady]
                lotto [1, 2] { wait [100, 200] branch [Cleanup] }
                repeat [2, 3] {
                    retry {
                        action [Break, 9] while(IsOkay, 1) then succeed entry(OnEntry) step(OnStep, 2) exit(OnExit)
                    }
                }
                parallel { race { wait } all { flip { action [Work, 2] } succeed { fail { wait [5] } } } }
            }
        }`;

        // The same definition as the MDSL above, written the way that it would be by hand, leaving out whatever is optional.
        const json: RootNodeDefinition[] = [
            { type: "root", id: "Cleanup", child: { type: "action", call: "Work", args: [3] } },
            {
                type: "root",
                child: {
                    type: "sequence",
                    children: [
                        { type: "action", call: "Work", args: [1, "a", null, true] },
                        { type: "condition", call: "IsReady" },
                        {
                            type: "lotto",
                            weights: [1, 2],
                            children: [
                                { type: "wait", duration: [100, 200] },
                                { type: "branch", ref: "Cleanup" }
                            ]
                        },
                        {
                            type: "repeat",
                            iterations: [2, 3],
                            child: {
                                type: "retry",
                                child: {
                                    type: "action",
                                    call: "Break",
                                    args: [9],
                                    while: { call: "IsOkay", args: [1], succeedOnAbort: true },
                                    entry: { call: "OnEntry" },
                                    step: { call: "OnStep", args: [2] },
                                    exit: { call: "OnExit" }
                                }
                            }
                        },
                        {
                            type: "parallel",
                            children: [
                                { type: "race", children: [{ type: "wait" }] },
                                {
                                    type: "all",
                                    children: [
                                        { type: "flip", child: { type: "action", call: "Work", args: [2] } },
                                        {
                                            type: "succeed",
                                            child: { type: "fail", child: { type: "wait", duration: 5 } }
                                        }
                                    ]
                                }
                            ]
                        }
                    ]
                }
            }
        ];

        it("an MDSL definition and the equivalent JSON definition", () => {
            restoreInto(mdsl, json);
            restoreInto(json, mdsl);
        });

        it("MDSL definitions with different whitespace and comments", () => {
            restoreInto(
                "root { sequence { action [Work, 1] action [Work, 3] } }",
                `/* the sequence */
                root {
                    sequence {
                        action [Work, 1] /* first */
                        action [Work, 3]
                    }
                }`
            );
        });

        it("JSON definitions with the properties in a different order", () => {
            restoreInto(
                { type: "root", child: { type: "action", call: "Work", args: [1] } },
                { child: { args: [1], call: "Work", type: "action" }, type: "root" }
            );
        });

        it("a single JSON root node and an array containing only that root node", () => {
            const root: RootNodeDefinition = { type: "root", child: { type: "action", call: "Work", args: [1] } };

            restoreInto(root, [root]);
            restoreInto([root], root);
            restoreInto("root { action [Work, 1] }", root);
        });

        it("JSON definitions with the root nodes in a different order", () => {
            const main: RootNodeDefinition = { type: "root", child: { type: "branch", ref: "A" } };
            const a: RootNodeDefinition = { type: "root", id: "A", child: { type: "branch", ref: "B" } };
            const b: RootNodeDefinition = { type: "root", id: "B", child: { type: "action", call: "Work", args: [1] } };

            restoreInto([main, a, b], [b, a, main]);
        });

        it("JSON definitions with properties that are undefined or that have their default value", () => {
            restoreInto(
                { type: "root", child: { type: "action", call: "Work", args: [1], entry: undefined } },
                { type: "root", child: { type: "action", call: "Work", args: [1], while: undefined } }
            );
            restoreInto(
                {
                    type: "root",
                    child: { type: "action", call: "Work", args: [], while: { call: "IsOkay", args: [] } }
                },
                {
                    type: "root",
                    child: { type: "action", call: "Work", while: { call: "IsOkay", succeedOnAbort: false } }
                }
            );
        });

        it("a registered subtree and the same subtree in the definition", () => {
            BehaviourTree.register("Sub", "root { action [Work, 1] }");

            restoreInto("root { branch [Sub] }", "root [Sub] { action [Work, 1] } root { branch [Sub] }");
        });

        it("trees with different options", () => {
            const world = { step: 1 };
            const definition = "root { sequence { action [Work, 2] wait [100, 200] } }";
            const source = new BehaviourTree(definition, createAgent([], world), { random: () => 0.1 });
            source.step();
            const target = new BehaviourTree(definition, createAgent([], world), { random: () => 0.9 });

            target.restore(source.snapshot());

            assert.deepEqual(withoutNodeIds(target.getTreeNodeDetails()), withoutNodeIds(source.getTreeNodeDetails()));
        });
    });

    describe("that models a long-running workflow", () => {
        const ONE_HOUR = 60 * 60 * 1000;

        const definition = `root {
            sequence {
                action [Implement]
                retry [3] {
                    sequence {
                        action [RunCI]
                        condition [DidCIPass]
                    }
                }
                race {
                    action [AwaitApproval]
                    sequence {
                        wait [${48 * ONE_HOUR}, ${72 * ONE_HOUR}]
                        action [Escalate]
                    }
                }
            }
        }`;

        // The state of the workflow is kept by the application, and is as long-lived as the stored snapshot.
        type Workflow = {
            implemented: boolean;
            ciRuns: number;
            ciPassesOnRun: number;
            approved: boolean;
            escalated: boolean;
        };

        const createAgent = (workflow: Workflow, log: string[]): Agent => ({
            Implement: () => {
                log.push("Implement");
                workflow.implemented = true;
                return State.SUCCEEDED;
            },
            RunCI: () => {
                log.push("RunCI");
                workflow.ciRuns++;
                return State.SUCCEEDED;
            },
            DidCIPass: () => workflow.ciRuns >= workflow.ciPassesOnRun,
            AwaitApproval: () => (workflow.approved ? State.SUCCEEDED : State.RUNNING),
            Escalate: () => {
                log.push("Escalate");
                workflow.escalated = true;
                return State.SUCCEEDED;
            }
        });

        let clock: SinonFakeTimers;

        beforeEach(() => {
            clock = sinon.useFakeTimers();
        });

        afterEach(() => {
            clock.restore();
        });

        // Simulates the process going away, and coming back as a new process with only the stored workflow and snapshot.
        const restart = (workflow: Workflow, storedSnapshot: string, random: () => number) => {
            const log: string[] = [];
            const tree = new BehaviourTree(definition, createAgent(workflow, log), { random });
            tree.restore(JSON.parse(storedSnapshot));
            return { tree, log };
        };

        it("carries on after the process restarts, with the retry attempts and approval wait that were left", () => {
            const workflow: Workflow = {
                implemented: false,
                ciRuns: 0,
                ciPassesOnRun: 3,
                approved: false,
                escalated: false
            };
            const log: string[] = [];
            const tree = new BehaviourTree(definition, createAgent(workflow, log), { random: () => 0 });

            // Implement, then the first CI run fails and the second one is in progress.
            tree.step();
            tree.step();
            assert.deepEqual(log, ["Implement", "RunCI", "RunCI"]);
            let stored = JSON.stringify(tree.snapshot());

            // The process restarts hours later. The third CI run passes, and then we wait for approval,
            // for the shortest possible 48 hours before escalating.
            clock.tick(5 * ONE_HOUR);
            let restarted = restart(workflow, stored, () => 0);
            restarted.tree.step();
            assert.deepEqual(restarted.log, ["RunCI"]);
            assert.isTrue(restarted.tree.isRunning());
            stored = JSON.stringify(restarted.tree.snapshot());

            // Another restart a day later, which does not count towards the 48 hours. 23 of them are spent waiting
            // and the approval has still not arrived. The random function would now pick a longer wait, but it is not asked to.
            clock.tick(24 * ONE_HOUR);
            restarted = restart(workflow, stored, () => 0.9999);
            clock.tick(23 * ONE_HOUR);
            restarted.tree.step();
            assert.deepEqual(restarted.log, []);
            assert.isFalse(workflow.escalated);
            stored = JSON.stringify(restarted.tree.snapshot());

            // Nothing happens while the process is down for a week, and then 25 of the 48 hours are left.
            clock.tick(7 * 24 * ONE_HOUR);
            restarted = restart(workflow, stored, () => 0.9999);
            clock.tick(25 * ONE_HOUR - 1);
            restarted.tree.step();
            assert.isFalse(workflow.escalated);
            clock.tick(1);
            restarted.tree.step();
            assert.deepEqual(restarted.log, ["Escalate"]);
            assert.isTrue(workflow.escalated);
            assert.strictEqual(restarted.tree.getState(), State.SUCCEEDED);
        });
    });

    it("has a snapshot type that is exported from the package", () => {
        const tree = new BehaviourTree("root { action [Work, 1] }", createAgent([], { step: 0 }));

        const snapshot: BehaviourTreeSnapshot = tree.snapshot();

        assert.equal(snapshot.version, 1);
        assert.equal(snapshot.root.type, "root");
    });
});
