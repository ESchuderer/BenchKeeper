import { assert } from "chai";

import { BehaviourTree, BehaviourTreeOptions, NodeDetails } from "../src/index";
import { AnyNodeDefinition, RootNodeDefinition } from "../src/BehaviourTreeDefinition";
import { Agent } from "../src/Agent";

/**
 * Get the details for the specified node type and caption from the given behaviour tree instance, or error if it doesn't exist.
 * @param tree The behaviour tree instance.
 * @param type The type of the node to get.
 * @param name The name of the node to get.
 * @returns The details for the specified node type and caption from the given behaviour tree instance.
 */
export function findNode(tree: BehaviourTree, type: AnyNodeDefinition["type"], name?: string): NodeDetails {
    const findNodeFromDetails = (node: NodeDetails): NodeDetails | null => {
        if (node.type === type && (!name || node.name === name)) {
            return node;
        }

        return (node.children ?? []).map(findNodeFromDetails).find((childNode) => !!childNode) ?? null;
    };

    const targetNode = findNodeFromDetails(tree.getTreeNodeDetails());

    if (!targetNode) {
        throw new Error(
            name
                ? `cannot find flattened tree node with type: '${type}' caption: '${name}'`
                : `cannot find flattened tree node with type: '${type}'`
        );
    }

    return targetNode;
}

/**
 * Get a copy of the given node details with the node identifiers removed.
 * Node identifiers are generated per tree instance, so they differ between a tree and one restored from its snapshot.
 * @param details The node details.
 * @returns A copy of the node details without identifiers.
 */
export function withoutNodeIds(details: NodeDetails): Omit<NodeDetails, "id" | "children"> & { children?: unknown[] } {
    const { id, children, ...rest } = details;
    return children ? { ...rest, children: children.map(withoutNodeIds) } : rest;
}

/**
 * A source of pseudo-random numbers that cycles through a fixed sequence and keeps track of how many it has handed out.
 */
export type RandomSource = {
    next: () => number;
    readonly position: number;
};

/**
 * Create a random source that cycles through the given values.
 * @param values The values to hand out, in order.
 * @param position The position in the sequence to start from.
 */
export function createRandomSource(values: number[], position = 0): RandomSource {
    let current = position;
    return {
        next: () => values[current++ % values.length],
        get position() {
            return current;
        }
    };
}

/**
 * The world that the agent functions of a restore scenario can base their behaviour on.
 * Agent functions must be pure functions of this, as the restored tree gets a fresh agent.
 */
export type ScenarioWorld = { step: number };

export type RestoreScenario = {
    /** The tree definition. */
    definition: string | RootNodeDefinition | RootNodeDefinition[];
    /** Creates an agent whose functions record their calls in the log and take their results from the world. */
    createAgent: (log: string[], world: ScenarioWorld) => Agent;
    /** The values that the 'random' option will cycle through. */
    random?: number[];
    /** Other behaviour tree options. */
    options?: Omit<BehaviourTreeOptions, "random">;
    /** The number of steps to take before the snapshot is taken. */
    stepsBeforeSnapshot: number;
    /** The number of steps to take after the snapshot has been restored. */
    stepsAfterRestore: number;
};

/**
 * Takes a snapshot of a tree after a number of steps, sends it through JSON, restores it to a tree built from the same definition
 * and then checks that the restored tree does exactly what the original tree does for the following steps.
 * @param scenario The restore scenario.
 */
export function assertRestoredTreeBehavesLikeOriginal(scenario: RestoreScenario): void {
    const world: ScenarioWorld = { step: 0 };

    const createTree = (randomPosition: number) => {
        const log: string[] = [];
        const random = createRandomSource(scenario.random ?? [0.5], randomPosition);
        const tree = new BehaviourTree(scenario.definition, scenario.createAgent(log, world), {
            ...scenario.options,
            random: random.next
        });
        return { tree, log, random };
    };

    const original = createTree(0);

    for (; world.step < scenario.stepsBeforeSnapshot; world.step++) {
        original.tree.step();
    }

    const snapshot = original.tree.snapshot();
    const storedSnapshot = JSON.parse(JSON.stringify(snapshot));

    assert.deepEqual(storedSnapshot, snapshot, "the snapshot should be unchanged by JSON.stringify and JSON.parse");

    const restored = createTree(original.random.position);
    restored.tree.restore(storedSnapshot);

    assert.deepEqual(
        withoutNodeIds(restored.tree.getTreeNodeDetails()),
        withoutNodeIds(original.tree.getTreeNodeDetails()),
        "the restored tree should have the node states of the original tree"
    );

    original.log.length = 0;
    restored.log.length = 0;

    for (; world.step < scenario.stepsBeforeSnapshot + scenario.stepsAfterRestore; world.step++) {
        original.tree.step();
        restored.tree.step();

        const description = `after step ${world.step} (snapshot taken after ${scenario.stepsBeforeSnapshot})`;

        assert.deepEqual(restored.log, original.log, `agent function calls differ ${description}`);
        assert.deepEqual(
            withoutNodeIds(restored.tree.getTreeNodeDetails()),
            withoutNodeIds(original.tree.getTreeNodeDetails()),
            `node states differ ${description}`
        );
        assert.equal(restored.random.position, original.random.position, `random calls differ ${description}`);
    }

    assert.deepEqual(restored.tree.snapshot(), original.tree.snapshot(), "the final snapshots should match");
}
