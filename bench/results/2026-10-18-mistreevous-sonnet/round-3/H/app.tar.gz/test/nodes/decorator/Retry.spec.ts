import { assert } from "chai";
import sinon, { SinonSandbox } from "sinon";

import { BehaviourTree, State } from "../../../src/index";
import { RootNodeDefinition } from "../../../src/BehaviourTreeDefinition";
import { Agent } from "../../../src/Agent";

import { assertRestoredTreeBehavesLikeOriginal, findNode, ScenarioWorld, withoutNodeIds } from "../../TestUtilities";

describe("A Retry node", () => {
    describe("on tree initialisation", () => {
        describe("will error if", () => {
            describe("the node does not have a single child", () => {
                it("(MDSL)", () => {
                    const definition = "root { retry {} }";
                    assert.throws(
                        () => new BehaviourTree(definition, {}),
                        Error,
                        "invalid definition: a retry node must have a single child node defined"
                    );
                });

                it("(JSON)", () => {
                    const definition = {
                        type: "root",
                        child: {
                            type: "retry"
                        }
                    } as any;
                    assert.throws(
                        () => new BehaviourTree(definition, {}),
                        Error,
                        "invalid definition: expected property 'child' to be defined for retry node at depth '1'"
                    );
                });
            });

            describe("the defined node arguments are not integers", () => {
                it("(MDSL)", () => {
                    const definition = "root { retry ['not', 'integers'] { condition [someCondition] } }";
                    assert.throws(
                        () => new BehaviourTree(definition, {}),
                        Error,
                        "invalid definition: retry node attempt counts must be integer values"
                    );
                });

                it("(JSON)", () => {
                    const definition = {
                        type: "root",
                        child: {
                            type: "retry",
                            attempts: ["not", "integers"],
                            child: {
                                type: "condition",
                                call: "someCondition"
                            }
                        }
                    } as any;
                    assert.throws(
                        () => new BehaviourTree(definition, {}),
                        Error,
                        "invalid definition: expected array containing two integer values for 'attempts' property if defined for retry node at depth '1'"
                    );
                });
            });

            describe("a negative attempts count node argument was defined", () => {
                it("(MDSL)", () => {
                    const definition = "root { retry [-1] { condition [someCondition] } }";
                    assert.throws(
                        () => new BehaviourTree(definition, {}),
                        Error,
                        "invalid definition: a retry node must have a positive number of attempts if defined"
                    );
                });

                it("(JSON)", () => {
                    const definition = {
                        type: "root",
                        child: {
                            type: "retry",
                            attempts: -1,
                            child: {
                                type: "condition",
                                call: "someCondition"
                            }
                        }
                    } as any;
                    assert.throws(
                        () => new BehaviourTree(definition, {}),
                        Error,
                        "invalid definition: expected positive attempts count for 'attempts' property if defined for retry node at depth '1'"
                    );
                });
            });

            describe("more than two node arguments are defined", () => {
                it("(MDSL)", () => {
                    const definition = "root { retry [0, 10, 20] { condition [someCondition] } }";
                    assert.throws(
                        () => new BehaviourTree(definition, {}),
                        Error,
                        "invalid definition: invalid number of retry node attempt count arguments defined"
                    );
                });

                it("(JSON)", () => {
                    const definition = {
                        type: "root",
                        child: {
                            type: "retry",
                            attempts: [0, 10, 20],
                            child: {
                                type: "condition",
                                call: "someCondition"
                            }
                        }
                    } as any;
                    assert.throws(
                        () => new BehaviourTree(definition, {}),
                        Error,
                        "invalid definition: expected array containing two integer values for 'attempts' property if defined for retry node at depth '1'"
                    );
                });
            });

            describe("a minimum iteration count node argument is defined that is greater than the maximum iteration count node argument", () => {
                it("(MDSL)", () => {
                    const definition = "root { retry [10, 5] { condition [someCondition] } }";
                    assert.throws(
                        () => new BehaviourTree(definition, {}),
                        Error,
                        "invalid definition: a retry node must not have a minimum attempt count that exceeds the maximum attempt count"
                    );
                });

                it("(JSON)", () => {
                    const definition = {
                        type: "root",
                        child: {
                            type: "retry",
                            attempts: [10, 5],
                            child: {
                                type: "condition",
                                call: "someCondition"
                            }
                        }
                    } as any;
                    assert.throws(
                        () => new BehaviourTree(definition, {}),
                        Error,
                        "invalid definition: expected minimum attempts count that does not exceed the maximum attempts count for 'attempts' property if defined for retry node at depth '1'"
                    );
                });
            });
        });
    });

    describe("when updated as part of a tree step", () => {
        let sandbox: SinonSandbox;

        beforeEach(() => {
            sandbox = sinon.createSandbox();
            sandbox.replace(globalThis.Math, "random", () => 0.5);
        });

        afterEach(() => sandbox.restore());

        describe("will move to the SUCCEEDED state if the child node moves to the SUCCEEDED state", () => {
            it("(MDSL)", () => {
                const definition = "root { retry { condition [someCondition] } }";
                const agent = { someCondition: () => true };
                const tree = new BehaviourTree(definition, agent);

                let node = findNode(tree, "retry", "RETRY");
                assert.exists(node);
                assert.strictEqual(node.state, State.READY);

                tree.step();

                node = findNode(tree, "retry", "RETRY");
                assert.strictEqual(node.state, State.SUCCEEDED);
            });

            it("(JSON)", () => {
                const definition: RootNodeDefinition = {
                    type: "root",
                    child: {
                        type: "retry",
                        child: {
                            type: "condition",
                            call: "someCondition"
                        }
                    }
                };
                const agent = { someCondition: () => true };
                const tree = new BehaviourTree(definition, agent);

                let node = findNode(tree, "retry", "RETRY");
                assert.exists(node);
                assert.strictEqual(node.state, State.READY);

                tree.step();

                node = findNode(tree, "retry", "RETRY");
                assert.strictEqual(node.state, State.SUCCEEDED);
            });
        });

        describe("will move to the RUNNING state if the child node moves to the FAILED state", () => {
            it("(MDSL)", () => {
                const definition = "root { retry { condition [someCondition] } }";
                const agent = { someCondition: () => false };
                const tree = new BehaviourTree(definition, agent);

                let node = findNode(tree, "retry", "RETRY");
                assert.exists(node);
                assert.strictEqual(node.state, State.READY);

                tree.step();

                node = findNode(tree, "retry", "RETRY");
                assert.strictEqual(node.state, State.RUNNING);
            });

            it("(JSON)", () => {
                const definition: RootNodeDefinition = {
                    type: "root",
                    child: {
                        type: "retry",
                        child: {
                            type: "condition",
                            call: "someCondition"
                        }
                    }
                };
                const agent = { someCondition: () => false };
                const tree = new BehaviourTree(definition, agent);

                let node = findNode(tree, "retry", "RETRY");
                assert.exists(node);
                assert.strictEqual(node.state, State.READY);

                tree.step();

                node = findNode(tree, "retry", "RETRY");
                assert.strictEqual(node.state, State.RUNNING);
            });
        });

        describe("and an attempt count node argument is defined will attempt to re-run the child node until the attempt count is reached", () => {
            it("(MDSL)", () => {
                const definition = "root { retry [3] { condition [someCondition] } }";
                const agent = { someCondition: () => false };
                const tree = new BehaviourTree(definition, agent);

                let node = findNode(tree, "retry", "RETRY 3x");
                assert.exists(node);
                assert.strictEqual(node.state, State.READY);

                tree.step();

                node = findNode(tree, "retry", "RETRY 3x");
                assert.strictEqual(node.state, State.RUNNING);

                tree.step();

                node = findNode(tree, "retry", "RETRY 3x");
                assert.strictEqual(node.state, State.RUNNING);

                tree.step();

                node = findNode(tree, "retry", "RETRY 3x");
                assert.strictEqual(node.state, State.RUNNING);

                tree.step();

                node = findNode(tree, "retry", "RETRY 3x");
                assert.strictEqual(node.state, State.FAILED);
            });

            it("(JSON)", () => {
                const definition: RootNodeDefinition = {
                    type: "root",
                    child: {
                        type: "retry",
                        attempts: 3,
                        child: {
                            type: "condition",
                            call: "someCondition"
                        }
                    }
                };
                const agent = { someCondition: () => false };
                const tree = new BehaviourTree(definition, agent);

                let node = findNode(tree, "retry", "RETRY 3x");
                assert.exists(node);
                assert.strictEqual(node.state, State.READY);

                tree.step();

                node = findNode(tree, "retry", "RETRY 3x");
                assert.strictEqual(node.state, State.RUNNING);

                tree.step();

                node = findNode(tree, "retry", "RETRY 3x");
                assert.strictEqual(node.state, State.RUNNING);

                tree.step();

                node = findNode(tree, "retry", "RETRY 3x");
                assert.strictEqual(node.state, State.RUNNING);

                tree.step();

                node = findNode(tree, "retry", "RETRY 3x");
                assert.strictEqual(node.state, State.FAILED);
            });
        });

        describe("and minumum and maximum attempt count node arguments are defined", () => {
            describe("and if the 'random' behaviour tree option is not defined will pick an attempt count from between the minimum and maximum bounds using Math.random", () => {
                it("(MDSL)", () => {
                    // We have spied on Math.random to always return 0.5 for the sake of this test, so our attempt count should always be 4.
                    const definition = "root { retry [2, 6] { condition [someCondition] } }";
                    const agent = { someCondition: () => false };
                    const tree = new BehaviourTree(definition, agent);

                    let node = findNode(tree, "retry", "RETRY 2x-6x");
                    assert.exists(node);
                    assert.strictEqual(node.state, State.READY);

                    tree.step();

                    node = findNode(tree, "retry", "RETRY 2x-6x");
                    assert.strictEqual(node.state, State.RUNNING);

                    tree.step();

                    node = findNode(tree, "retry", "RETRY 2x-6x");
                    assert.strictEqual(node.state, State.RUNNING);

                    tree.step();

                    node = findNode(tree, "retry", "RETRY 2x-6x");
                    assert.strictEqual(node.state, State.RUNNING);

                    tree.step();

                    node = findNode(tree, "retry", "RETRY 2x-6x");
                    assert.strictEqual(node.state, State.RUNNING);

                    tree.step();

                    node = findNode(tree, "retry", "RETRY 2x-6x");
                    assert.strictEqual(node.state, State.FAILED);
                });

                it("(JSON)", () => {
                    // We have spied on Math.random to always return 0.5 for the sake of this test, so our attempt count should always be 4.
                    const definition: RootNodeDefinition = {
                        type: "root",
                        child: {
                            type: "retry",
                            attempts: [2, 6],
                            child: {
                                type: "condition",
                                call: "someCondition"
                            }
                        }
                    };
                    const agent = { someCondition: () => false };
                    const tree = new BehaviourTree(definition, agent);

                    let node = findNode(tree, "retry", "RETRY 2x-6x");
                    assert.exists(node);
                    assert.strictEqual(node.state, State.READY);

                    tree.step();

                    node = findNode(tree, "retry", "RETRY 2x-6x");
                    assert.strictEqual(node.state, State.RUNNING);

                    tree.step();

                    node = findNode(tree, "retry", "RETRY 2x-6x");
                    assert.strictEqual(node.state, State.RUNNING);

                    tree.step();

                    node = findNode(tree, "retry", "RETRY 2x-6x");
                    assert.strictEqual(node.state, State.RUNNING);

                    tree.step();

                    node = findNode(tree, "retry", "RETRY 2x-6x");
                    assert.strictEqual(node.state, State.RUNNING);

                    tree.step();

                    node = findNode(tree, "retry", "RETRY 2x-6x");
                    assert.strictEqual(node.state, State.FAILED);
                });
            });

            describe("and if the 'random' behaviour tree option is defined will use it to pick an attempt count from between the minimum and maximum bounds", () => {
                it("(MDSL)", () => {
                    const definition = "root { retry [2, 10] { condition [someCondition] } }";
                    const agent = { someCondition: () => false };
                    const options = {
                        // Usually this would return a new pseudo-random number each time, but for the sake of this test we
                        // just want to make sure that the number we return actually has an impact on the attempt count picked.
                        // A value of 0.2 should always result in an attempt count of 3.
                        random: () => 0.2
                    };
                    const tree = new BehaviourTree(definition, agent, options);

                    let node = findNode(tree, "retry", "RETRY 2x-10x");
                    assert.exists(node);
                    assert.strictEqual(node.state, State.READY);

                    tree.step();

                    node = findNode(tree, "retry", "RETRY 2x-10x");
                    assert.strictEqual(node.state, State.RUNNING);

                    tree.step();

                    node = findNode(tree, "retry", "RETRY 2x-10x");
                    assert.strictEqual(node.state, State.RUNNING);

                    tree.step();

                    node = findNode(tree, "retry", "RETRY 2x-10x");
                    assert.strictEqual(node.state, State.RUNNING);

                    tree.step();

                    node = findNode(tree, "retry", "RETRY 2x-10x");
                    assert.strictEqual(node.state, State.FAILED);
                });

                it("(JSON)", () => {
                    const definition: RootNodeDefinition = {
                        type: "root",
                        child: {
                            type: "retry",
                            attempts: [2, 10],
                            child: {
                                type: "condition",
                                call: "someCondition"
                            }
                        }
                    };
                    const agent = { someCondition: () => false };
                    const options = {
                        // Usually this would return a new pseudo-random number each time, but for the sake of this test we
                        // just want to make sure that the number we return actually has an impact on the attempt count picked.
                        // A value of 0.2 should always result in an attempt count of 3.
                        random: () => 0.2
                    };
                    const tree = new BehaviourTree(definition, agent, options);

                    let node = findNode(tree, "retry", "RETRY 2x-10x");
                    assert.exists(node);
                    assert.strictEqual(node.state, State.READY);

                    tree.step();

                    node = findNode(tree, "retry", "RETRY 2x-10x");
                    assert.strictEqual(node.state, State.RUNNING);

                    tree.step();

                    node = findNode(tree, "retry", "RETRY 2x-10x");
                    assert.strictEqual(node.state, State.RUNNING);

                    tree.step();

                    node = findNode(tree, "retry", "RETRY 2x-10x");
                    assert.strictEqual(node.state, State.RUNNING);

                    tree.step();

                    node = findNode(tree, "retry", "RETRY 2x-10x");
                    assert.strictEqual(node.state, State.FAILED);
                });
            });
        });
    });

    describe("when a snapshot of the tree is restored", () => {
        const createAgent = (log: string[], world: ScenarioWorld) => ({
            // Fails straight away.
            Tick: () => {
                log.push("Tick");
                return State.FAILED;
            },
            // Takes a step to fail each time it is run.
            Slow: () => {
                log.push("Slow");
                return world.step % 2 === 1 ? State.FAILED : State.RUNNING;
            },
            // Succeeds on the third step.
            Flaky: () => {
                log.push("Flaky");
                return world.step === 2 ? State.SUCCEEDED : State.FAILED;
            }
        });

        const definitions: { [description: string]: string } = {
            "will carry on from the attempt that the original tree was on": "root { retry [4] { action [Tick] } }",
            "will carry on from the attempt that the original tree was on when a child takes more than one step":
                "root { retry [3] { action [Slow] } }",
            "will carry on from the attempt that the original tree was on when the child succeeds":
                "root { retry [5] { action [Flaky] } }",
            "will carry on retrying indefinitely when there are no attempts": "root { retry { action [Tick] } }",
            "will carry on from the attempt that the original tree was on when nested":
                "root { retry [2] { sequence { action [Tick] retry [3] { action [Slow] } } } }"
        };

        Object.entries(definitions).forEach(([description, definition]) => {
            it(description, () => {
                for (let stepsBeforeSnapshot = 0; stepsBeforeSnapshot <= 14; stepsBeforeSnapshot++) {
                    assertRestoredTreeBehavesLikeOriginal({
                        definition,
                        createAgent,
                        stepsBeforeSnapshot,
                        stepsAfterRestore: 14
                    });
                }
            });
        });

        describe("will use the number of attempts picked by the original tree without picking another when min and max attempts were defined", () => {
            // Each of these picks a different number of attempts from the same definition.
            [0, 0.3, 0.6, 0.99].forEach((randomValue) => {
                it(`(random value of ${randomValue})`, () => {
                    for (let stepsBeforeSnapshot = 0; stepsBeforeSnapshot <= 14; stepsBeforeSnapshot++) {
                        assertRestoredTreeBehavesLikeOriginal({
                            definition: "root { retry [2, 5] { action [Tick] } }",
                            createAgent,
                            // The next number would pick the opposite end of the range if the restored node picked again.
                            random: [randomValue, 1 - randomValue - 0.01],
                            stepsBeforeSnapshot,
                            stepsAfterRestore: 14
                        });
                    }
                });
            });
        });

        it("will restore a negative target attempt count, as a 'random' function that returns less than 0 results in", () => {
            const definition = "root { retry [2, 5] { action [Tick] } }";
            const original = new BehaviourTree(definition, createAgent([], { step: 0 }), { random: () => -1 });
            original.step();
            assert.strictEqual(original.getState(), State.FAILED);

            const restored = new BehaviourTree(definition, createAgent([], { step: 0 }));
            restored.restore(JSON.parse(JSON.stringify(original.snapshot())));

            assert.strictEqual(restored.getState(), State.FAILED);
        });

        describe("will throw an error, leaving the tree unchanged, if the snapshot", () => {
            const definition = "root { retry [3] { action [Tick] } }";

            const assertRestoreThrows = (modify: (retrySnapshot: any) => void, message: string) => {
                const source = new BehaviourTree(definition, createAgent([], { step: 0 }));
                source.step();
                const snapshot: any = JSON.parse(JSON.stringify(source.snapshot()));
                modify(snapshot.root.children[0]);

                const target = new BehaviourTree(definition, createAgent([], { step: 0 }));
                const detailsBefore = withoutNodeIds(target.getTreeNodeDetails());

                assert.throws(() => target.restore(snapshot), Error, message);
                assert.deepEqual(withoutNodeIds(target.getTreeNodeDetails()), detailsBefore);
            };

            it("has an invalid current attempt count", () => {
                [-1, 1.5, "1", null].forEach((value) =>
                    assertRestoreThrows(
                        (retry) => (retry.currentAttemptCount = value),
                        "invalid snapshot: expected node 'ROOT > RETRY 3x' to have a current attempt count that is a non-negative integer"
                    )
                );
            });

            it("has an invalid target attempt count", () => {
                [1.5, "3", undefined, NaN].forEach((value) =>
                    assertRestoreThrows(
                        (retry) => (retry.targetAttemptCount = value),
                        "invalid snapshot: expected node 'ROOT > RETRY 3x' to have a target attempt count that is null or an integer"
                    )
                );
            });
        });
    });
});
