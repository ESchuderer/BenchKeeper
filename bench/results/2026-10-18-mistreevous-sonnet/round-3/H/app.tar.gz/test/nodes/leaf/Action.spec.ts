import { assert } from "chai";
import sinon from "sinon";

import { BehaviourTree, State } from "../../../src/index";
import { RootNodeDefinition } from "../../../src/BehaviourTreeDefinition";

import { assertRestoredTreeBehavesLikeOriginal, findNode, ScenarioWorld, withoutNodeIds } from "../../TestUtilities";

describe("An Action node", () => {
    beforeEach(() => BehaviourTree.unregisterAll());

    describe("on tree initialisation", () => {
        describe("will error if no action function name is defined", () => {
            it("(MDSL)", () => {
                const definition = "root { action [] }";
                assert.throws(
                    () => new BehaviourTree(definition, {}),
                    Error,
                    "invalid definition: expected action name identifier argument"
                );
            });

            it("(JSON)", () => {
                const definition = {
                    type: "root",
                    child: {
                        type: "action"
                    }
                } as any;
                assert.throws(
                    () => new BehaviourTree(definition, {}),
                    Error,
                    "invalid definition: expected non-empty string for 'call' property of action node at depth '1'"
                );
            });
        });
    });

    describe("when updated as part of a tree step", () => {
        describe("will call the function defined by the first node argument", () => {
            describe("when the referenced function is", () => {
                describe("a registered function", () => {
                    it("(MDSL)", () => {
                        const registeredActionFunction = sinon.stub().returns(State.SUCCEEDED);
                        BehaviourTree.register("doAction", registeredActionFunction);

                        const definition = `root { action [doAction, "some-argument"] }`;
                        const agent = { mock: "agent" };
                        const tree = new BehaviourTree(definition, agent);

                        tree.step();

                        const node = findNode(tree, "action", "doAction");
                        assert.strictEqual(node.state, State.SUCCEEDED);
                        assert.isTrue(registeredActionFunction.calledWith(agent, "some-argument"));
                    });

                    it("(JSON)", () => {
                        const registeredActionFunction = sinon.stub().returns(State.SUCCEEDED);
                        BehaviourTree.register("doAction", registeredActionFunction);

                        const definition: RootNodeDefinition = {
                            type: "root",
                            child: {
                                type: "action",
                                call: "doAction",
                                args: ["some-argument"]
                            }
                        };
                        const agent = { mock: "agent" };
                        const tree = new BehaviourTree(definition, agent);

                        tree.step();

                        const node = findNode(tree, "action", "doAction");
                        assert.strictEqual(node.state, State.SUCCEEDED);
                        assert.isTrue(registeredActionFunction.calledWith(agent, "some-argument"));
                    });
                });

                describe("an agent function", () => {
                    it("(MDSL)", () => {
                        const definition = "root { action [doAction] }";
                        const agent = { doAction: () => State.SUCCEEDED };
                        const tree = new BehaviourTree(definition, agent);

                        tree.step();

                        const node = findNode(tree, "action", "doAction");
                        assert.strictEqual(node.state, State.SUCCEEDED);
                    });

                    it("(JSON)", () => {
                        const definition: RootNodeDefinition = {
                            type: "root",
                            child: {
                                type: "action",
                                call: "doAction"
                            }
                        };
                        const agent = { doAction: () => State.SUCCEEDED };
                        const tree = new BehaviourTree(definition, agent);

                        tree.step();

                        const node = findNode(tree, "action", "doAction");
                        assert.strictEqual(node.state, State.SUCCEEDED);
                    });
                });
            });

            describe("and will error if", () => {
                describe("there is no agent function or registered function that matches the action name", () => {
                    it("(MDSL)", () => {
                        const definition = "root { action [DoTheThing] }";
                        let tree: BehaviourTree;
                        assert.doesNotThrow(() => (tree = new BehaviourTree(definition, {})), Error);
                        assert.throws(
                            () => tree.step(),
                            Error,
                            "error stepping tree: cannot update action node as the action 'DoTheThing' function is not defined on the agent and has not been registered"
                        );
                    });

                    it("(JSON)", () => {
                        const definition: RootNodeDefinition = {
                            type: "root",
                            child: {
                                type: "action",
                                call: "DoTheThing"
                            }
                        };
                        let tree: BehaviourTree;
                        assert.doesNotThrow(() => (tree = new BehaviourTree(definition, {})), Error);
                        assert.throws(
                            () => tree.step(),
                            Error,
                            "error stepping tree: cannot update action node as the action 'DoTheThing' function is not defined on the agent and has not been registered"
                        );
                    });
                });

                describe("the action function", () => {
                    describe("throws an error object", () => {
                        it("(MDSL)", () => {
                            const definition = "root { action [doAction] }";
                            const agent = {
                                doAction: () => {
                                    throw new Error("some-error");
                                }
                            };
                            const tree = new BehaviourTree(definition, agent);

                            assert.throws(
                                () => tree.step(),
                                Error,
                                "error stepping tree: action function 'doAction' threw: Error: some-error"
                            );
                        });

                        it("(JSON)", () => {
                            const definition: RootNodeDefinition = {
                                type: "root",
                                child: {
                                    type: "action",
                                    call: "doAction"
                                }
                            };
                            const agent = {
                                doAction: () => {
                                    throw new Error("some-error");
                                }
                            };
                            const tree = new BehaviourTree(definition, agent);

                            assert.throws(
                                () => tree.step(),
                                Error,
                                "error stepping tree: action function 'doAction' threw: Error: some-error"
                            );
                        });
                    });

                    describe("throws something that isn't an error object", () => {
                        it("(MDSL)", () => {
                            const definition = "root { action [doAction] }";
                            const agent = {
                                doAction: () => {
                                    throw "some-error";
                                }
                            };
                            const tree = new BehaviourTree(definition, agent);

                            assert.throws(
                                () => tree.step(),
                                Error,
                                "error stepping tree: action function 'doAction' threw: some-error"
                            );
                        });

                        it("(JSON)", () => {
                            const definition: RootNodeDefinition = {
                                type: "root",
                                child: {
                                    type: "action",
                                    call: "doAction"
                                }
                            };
                            const agent = {
                                doAction: () => {
                                    throw "some-error";
                                }
                            };
                            const tree = new BehaviourTree(definition, agent);

                            assert.throws(
                                () => tree.step(),
                                Error,
                                "error stepping tree: action function 'doAction' threw: some-error"
                            );
                        });
                    });

                    describe("returns an unexpected value", () => {
                        it("(MDSL)", () => {
                            const definition = "root { action [doAction] }";
                            const agent = {
                                doAction: () => "invalid-result"
                            };
                            const tree = new BehaviourTree(definition, agent);

                            assert.throws(
                                () => tree.step(),
                                Error,
                                "error stepping tree: expected action function 'doAction' to return an optional State.SUCCEEDED or State.FAILED value but returned 'invalid-result'"
                            );
                        });

                        it("(JSON)", () => {
                            const definition: RootNodeDefinition = {
                                type: "root",
                                child: {
                                    type: "action",
                                    call: "doAction"
                                }
                            };
                            const agent = {
                                doAction: () => "invalid-result"
                            };
                            const tree = new BehaviourTree(definition, agent);

                            assert.throws(
                                () => tree.step(),
                                Error,
                                "error stepping tree: expected action function 'doAction' to return an optional State.SUCCEEDED or State.FAILED value but returned 'invalid-result'"
                            );
                        });
                    });

                    describe("returns a rejected promise", () => {
                        it("(MDSL)", (done) => {
                            const definition = "root { action [doAction] }";
                            const result: Promise<State.SUCCEEDED> = new Promise(() => {
                                throw new Error("some-error");
                            });
                            const agent = { doAction: () => result };
                            const tree = new BehaviourTree(definition, agent);

                            assert.strictEqual(findNode(tree, "action", "doAction").state, State.READY);

                            tree.step();

                            assert.strictEqual(findNode(tree, "action", "doAction").state, State.RUNNING);

                            setTimeout(() => {
                                assert.throws(
                                    () => tree.step(),
                                    Error,
                                    "error stepping tree: action function 'doAction' promise rejected with 'Error: some-error'"
                                );

                                done();
                            }, 0);
                        });

                        it("(JSON)", (done) => {
                            const definition: RootNodeDefinition = {
                                type: "root",
                                child: {
                                    type: "action",
                                    call: "doAction"
                                }
                            };
                            const result: Promise<State.SUCCEEDED> = new Promise(() => {
                                throw new Error("some-error");
                            });
                            const agent = { doAction: () => result };
                            const tree = new BehaviourTree(definition, agent);

                            assert.strictEqual(findNode(tree, "action", "doAction").state, State.READY);

                            tree.step();

                            assert.strictEqual(findNode(tree, "action", "doAction").state, State.RUNNING);

                            setTimeout(() => {
                                assert.throws(
                                    () => tree.step(),
                                    Error,
                                    "error stepping tree: action function 'doAction' promise rejected with 'Error: some-error'"
                                );

                                done();
                            }, 0);
                        });
                    });
                });
            });

            describe("and move to", () => {
                describe("the SUCCESS state if the function returns a value of State.SUCCEEDED", () => {
                    it("(MDSL)", () => {
                        const definition = "root { action [doAction] }";
                        const agent = { doAction: () => State.SUCCEEDED };
                        const tree = new BehaviourTree(definition, agent);

                        let node = findNode(tree, "action", "doAction");
                        assert.strictEqual(node.state, State.READY);

                        tree.step();

                        node = findNode(tree, "action", "doAction");
                        assert.strictEqual(node.state, State.SUCCEEDED);
                    });

                    it("(JSON)", () => {
                        const definition: RootNodeDefinition = {
                            type: "root",
                            child: {
                                type: "action",
                                call: "doAction"
                            }
                        };
                        const agent = { doAction: () => State.SUCCEEDED };
                        const tree = new BehaviourTree(definition, agent);

                        let node = findNode(tree, "action", "doAction");
                        assert.strictEqual(node.state, State.READY);

                        tree.step();

                        node = findNode(tree, "action", "doAction");
                        assert.strictEqual(node.state, State.SUCCEEDED);
                    });
                });

                describe("the FAILED state if the function returns a value of State.FAILED", () => {
                    it("(MDSL)", () => {
                        const definition = "root { action [doAction] }";
                        const agent = { doAction: () => State.FAILED };
                        const tree = new BehaviourTree(definition, agent);

                        let node = findNode(tree, "action", "doAction");
                        assert.strictEqual(node.state, State.READY);

                        tree.step();

                        node = findNode(tree, "action", "doAction");
                        assert.strictEqual(node.state, State.FAILED);
                    });

                    it("(JSON)", () => {
                        const definition: RootNodeDefinition = {
                            type: "root",
                            child: {
                                type: "action",
                                call: "doAction"
                            }
                        };
                        const agent = { doAction: () => State.FAILED };
                        const tree = new BehaviourTree(definition, agent);

                        let node = findNode(tree, "action", "doAction");
                        assert.strictEqual(node.state, State.READY);

                        tree.step();

                        node = findNode(tree, "action", "doAction");
                        assert.strictEqual(node.state, State.FAILED);
                    });
                });

                describe("the RUNNING state if", () => {
                    describe("the function returns undefined", () => {
                        it("(MDSL)", () => {
                            const definition = "root { action [doAction] }";
                            const agent = { doAction: () => State.RUNNING };
                            const tree = new BehaviourTree(definition, agent);

                            let node = findNode(tree, "action", "doAction");
                            assert.strictEqual(node.state, State.READY);

                            tree.step();

                            node = findNode(tree, "action", "doAction");
                            assert.strictEqual(node.state, State.RUNNING);
                        });

                        it("(JSON)", () => {
                            const definition: RootNodeDefinition = {
                                type: "root",
                                child: {
                                    type: "action",
                                    call: "doAction"
                                }
                            };
                            const agent = { doAction: () => State.RUNNING };
                            const tree = new BehaviourTree(definition, agent);

                            let node = findNode(tree, "action", "doAction");
                            assert.strictEqual(node.state, State.READY);

                            tree.step();

                            node = findNode(tree, "action", "doAction");
                            assert.strictEqual(node.state, State.RUNNING);
                        });
                    });

                    describe("the function returns a value of State.RUNNING", () => {
                        it("(MDSL)", () => {
                            const definition = "root { action [doAction] }";
                            const agent = { doAction: () => State.RUNNING };
                            const tree = new BehaviourTree(definition, agent);

                            let node = findNode(tree, "action", "doAction");
                            assert.strictEqual(node.state, State.READY);

                            tree.step();

                            node = findNode(tree, "action", "doAction");
                            assert.strictEqual(node.state, State.RUNNING);
                        });

                        it("(JSON)", () => {
                            const definition: RootNodeDefinition = {
                                type: "root",
                                child: {
                                    type: "action",
                                    call: "doAction"
                                }
                            };
                            const agent = { doAction: () => State.RUNNING };
                            const tree = new BehaviourTree(definition, agent);

                            let node = findNode(tree, "action", "doAction");
                            assert.strictEqual(node.state, State.READY);

                            tree.step();

                            node = findNode(tree, "action", "doAction");
                            assert.strictEqual(node.state, State.RUNNING);
                        });
                    });

                    describe("the function returns a promise to return a value of State.SUCCEEDED or State.FAILED", () => {
                        it("(MDSL)", (done) => {
                            const definition = "root { action [doAction] }";

                            const result: Promise<State.SUCCEEDED> = new Promise((resolve) => resolve(State.SUCCEEDED));
                            const agent = { doAction: () => result };
                            const tree = new BehaviourTree(definition, agent);

                            assert.strictEqual(findNode(tree, "action", "doAction").state, State.READY);

                            tree.step();

                            assert.strictEqual(findNode(tree, "action", "doAction").state, State.RUNNING);

                            setTimeout(() => {
                                tree.step();

                                assert.strictEqual(findNode(tree, "action", "doAction").state, State.SUCCEEDED);

                                done();
                            }, 0);
                        });

                        it("(JSON)", (done) => {
                            const definition: RootNodeDefinition = {
                                type: "root",
                                child: {
                                    type: "action",
                                    call: "doAction"
                                }
                            };

                            const result: Promise<State.SUCCEEDED> = new Promise((resolve) => resolve(State.SUCCEEDED));
                            const agent = { doAction: () => result };
                            const tree = new BehaviourTree(definition, agent);

                            assert.strictEqual(findNode(tree, "action", "doAction").state, State.READY);

                            tree.step();

                            assert.strictEqual(findNode(tree, "action", "doAction").state, State.RUNNING);

                            setTimeout(() => {
                                tree.step();

                                assert.strictEqual(findNode(tree, "action", "doAction").state, State.SUCCEEDED);

                                done();
                            }, 0);
                        });
                    });
                });
            });

            describe("and pass any node arguments that follow the action name identifier argument where", () => {
                describe("the argument is a", () => {
                    describe("string", () => {
                        it("(MDSL)", () => {
                            const definition = 'root { action [doAction, "hello world!"] }';
                            const agent = {
                                doAction: (arg: any) => assert.strictEqual(arg, "hello world!")
                            };
                            const tree = new BehaviourTree(definition, agent);

                            tree.step();
                        });

                        it("(JSON)", () => {
                            const definition: RootNodeDefinition = {
                                type: "root",
                                child: {
                                    type: "action",
                                    call: "doAction",
                                    args: ["hello world!"]
                                }
                            };
                            const agent = {
                                doAction: (arg: any) => assert.strictEqual(arg, "hello world!")
                            };
                            const tree = new BehaviourTree(definition, agent);

                            tree.step();
                        });
                    });

                    describe("string with escaped quotes", () => {
                        it("(MDSL)", () => {
                            const definition = 'root { action [doAction, "hello \\" world!"] }';
                            const agent = {
                                doAction: (arg: any) => assert.strictEqual(arg, 'hello " world!')
                            };
                            const tree = new BehaviourTree(definition, agent);

                            tree.step();
                        });

                        it("(JSON)", () => {
                            const definition: RootNodeDefinition = {
                                type: "root",
                                child: {
                                    type: "action",
                                    call: "doAction",
                                    args: ['hello " world!']
                                }
                            };
                            const agent = {
                                doAction: (arg: any) => assert.strictEqual(arg, 'hello " world!')
                            };
                            const tree = new BehaviourTree(definition, agent);

                            tree.step();
                        });
                    });

                    describe("number", () => {
                        it("(MDSL)", () => {
                            const definition = "root { action [doAction, 23.4567] }";
                            const agent = {
                                doAction: (arg: any) => assert.strictEqual(arg, 23.4567)
                            };
                            const tree = new BehaviourTree(definition, agent);

                            tree.step();
                        });

                        it("(JSON)", () => {
                            const definition: RootNodeDefinition = {
                                type: "root",
                                child: {
                                    type: "action",
                                    call: "doAction",
                                    args: [23.4567]
                                }
                            };
                            const agent = {
                                doAction: (arg: any) => assert.strictEqual(arg, 23.4567)
                            };
                            const tree = new BehaviourTree(definition, agent);

                            tree.step();
                        });
                    });

                    describe("boolean 'true' literal", () => {
                        it("(MDSL)", () => {
                            const definition = "root { action [doAction, true] }";
                            const agent = {
                                doAction: (arg: any) => assert.strictEqual(arg, true)
                            };
                            const tree = new BehaviourTree(definition, agent);

                            tree.step();
                        });

                        it("(JSON)", () => {
                            const definition: RootNodeDefinition = {
                                type: "root",
                                child: {
                                    type: "action",
                                    call: "doAction",
                                    args: [true]
                                }
                            };
                            const agent = {
                                doAction: (arg: any) => assert.strictEqual(arg, true)
                            };
                            const tree = new BehaviourTree(definition, agent);

                            tree.step();
                        });
                    });

                    describe("boolean 'false' literal", () => {
                        it("(MDSL)", () => {
                            const definition = "root { action [doAction, false] }";
                            const agent = {
                                doAction: (arg: any) => assert.strictEqual(arg, false)
                            };
                            const tree = new BehaviourTree(definition, agent);

                            tree.step();
                        });

                        it("(JSON)", () => {
                            const definition: RootNodeDefinition = {
                                type: "root",
                                child: {
                                    type: "action",
                                    call: "doAction",
                                    args: [false]
                                }
                            };
                            const agent = {
                                doAction: (arg: any) => assert.strictEqual(arg, false)
                            };
                            const tree = new BehaviourTree(definition, agent);

                            tree.step();
                        });
                    });

                    describe("null", () => {
                        it("(MDSL)", () => {
                            const definition = "root { action [doAction, null] }";
                            const agent = {
                                doAction: (arg: any) => assert.isNull(arg)
                            };
                            const tree = new BehaviourTree(definition, agent);

                            tree.step();
                        });

                        it("(JSON)", () => {
                            const definition: RootNodeDefinition = {
                                type: "root",
                                child: {
                                    type: "action",
                                    call: "doAction",
                                    args: [null]
                                }
                            };
                            const agent = {
                                doAction: (arg: any) => assert.isNull(arg)
                            };
                            const tree = new BehaviourTree(definition, agent);

                            tree.step();
                        });
                    });

                    describe("agent property reference", () => {
                        it("(MDSL)", () => {
                            const definition = "root { action [doAction, $someProperty] }";
                            const agent = {
                                doAction: (arg: any) => {
                                    assert.strictEqual(arg, "some-property-value");
                                },
                                someProperty: "some-property-value"
                            };
                            const tree = new BehaviourTree(definition, agent);

                            tree.step();
                        });

                        it("(JSON)", () => {
                            const definition: RootNodeDefinition = {
                                type: "root",
                                child: {
                                    type: "action",
                                    call: "doAction",
                                    args: [{ $: "someProperty" }]
                                }
                            };
                            const agent = {
                                doAction: (arg: any) => assert.strictEqual(arg, "some-property-value"),
                                someProperty: "some-property-value"
                            };
                            const tree = new BehaviourTree(definition, agent);

                            tree.step();
                        });
                    });
                });

                describe("there are multiple arguments", () => {
                    it("(MDSL)", () => {
                        const definition =
                            'root { action [doAction, 1.23, "hello world!", false, null, $someProperty] }';
                        const agent = {
                            doAction: (arg0: any, arg1: any, arg2: any, arg3: any, arg4: any) => {
                                assert.strictEqual(arg0, 1.23);
                                assert.strictEqual(arg1, "hello world!");
                                assert.strictEqual(arg2, false);
                                assert.strictEqual(arg3, null);
                                assert.strictEqual(arg4, "some-property-value");
                            },
                            someProperty: "some-property-value"
                        };
                        const tree = new BehaviourTree(definition, agent);

                        tree.step();
                    });

                    it("(JSON)", () => {
                        const definition: RootNodeDefinition = {
                            type: "root",
                            child: {
                                type: "action",
                                call: "doAction",
                                args: [1.23, "hello world!", false, null, { $: "someProperty" }]
                            }
                        };
                        const agent = {
                            doAction: (arg0: any, arg1: any, arg2: any, arg3: any, arg4: any) => {
                                assert.strictEqual(arg0, 1.23);
                                assert.strictEqual(arg1, "hello world!");
                                assert.strictEqual(arg2, false);
                                assert.strictEqual(arg3, null);
                                assert.strictEqual(arg4, "some-property-value");
                            },
                            someProperty: "some-property-value"
                        };
                        const tree = new BehaviourTree(definition, agent);

                        tree.step();
                    });
                });
            });
        });
    });

    describe("when a snapshot of the tree is restored", () => {
        /** Lets any promises that have been resolved or rejected get on with it. */
        const settlePromises = () => new Promise((resolve) => setImmediate(resolve));

        /** Creates a promise that can be resolved or rejected from outside. */
        const createDeferred = () => {
            let resolve!: (value: unknown) => void;
            let reject!: (reason: unknown) => void;
            const promise = new Promise((promiseResolve, promiseReject) => {
                resolve = promiseResolve;
                reject = promiseReject;
            });
            return { promise, resolve, reject };
        };

        const definition = "root { sequence { action [Approve] action [Finish] } }";

        describe("and the action function returns a finished state or nothing", () => {
            const createAgent = (log: string[], world: ScenarioWorld) => ({
                // Succeeds on the third step.
                Approve: (...args: unknown[]) => {
                    log.push(`Approve ${args.join(",")}`);
                    return world.step >= 2 ? State.SUCCEEDED : undefined;
                },
                Finish: () => {
                    log.push("Finish");
                    return world.step >= 4 ? State.SUCCEEDED : State.RUNNING;
                }
            });

            it("will call the action function from the next step exactly as the original tree does", () => {
                for (let stepsBeforeSnapshot = 0; stepsBeforeSnapshot <= 7; stepsBeforeSnapshot++) {
                    assertRestoredTreeBehavesLikeOriginal({
                        definition: 'root { sequence { action [Approve, 1, "two", true] action [Finish] } }',
                        createAgent,
                        stepsBeforeSnapshot,
                        stepsAfterRestore: 6
                    });
                }
            });
        });

        describe("and the action function returns a promise", () => {
            const createPromiseAgent = (approval: Promise<unknown>, log: string[]) => ({
                Approve: () => {
                    log.push("Approve");
                    return approval;
                },
                Finish: () => {
                    log.push("Finish");
                    return State.SUCCEEDED;
                }
            });

            const actionStates = (tree: BehaviourTree) =>
                tree.getTreeNodeDetails().children![0].children!.map((c) => c.state);

            describe("while the promise is still to be resolved", () => {
                it("will take a snapshot without changing the tree or calling the action function", () => {
                    const log: string[] = [];
                    const tree = new BehaviourTree(definition, createPromiseAgent(createDeferred().promise, log));
                    tree.step();
                    log.length = 0;
                    const detailsBefore = withoutNodeIds(tree.getTreeNodeDetails());

                    tree.snapshot();

                    assert.deepEqual(log, []);
                    assert.deepEqual(withoutNodeIds(tree.getTreeNodeDetails()), detailsBefore);
                    assert.deepEqual(actionStates(tree), [State.RUNNING, State.READY]);
                });

                it("will take a snapshot that records the action as not yet started, and is unchanged by JSON.stringify and JSON.parse", () => {
                    const tree = new BehaviourTree(definition, createPromiseAgent(createDeferred().promise, []));
                    tree.step();

                    const snapshot = tree.snapshot();

                    assert.deepEqual(JSON.parse(JSON.stringify(snapshot)), snapshot);
                    assert.deepEqual((snapshot.root as any).children[0].children[0], {
                        type: "action",
                        name: "Approve",
                        state: State.READY,
                        resolvedState: null
                    });
                });

                it("will let the original tree carry on with its promise after a snapshot is taken", async () => {
                    const approval = createDeferred();
                    const log: string[] = [];
                    const tree = new BehaviourTree(definition, createPromiseAgent(approval.promise, log));
                    tree.step();
                    tree.snapshot();

                    approval.resolve(State.SUCCEEDED);
                    await settlePromises();
                    tree.step();

                    assert.deepEqual(log, ["Approve", "Finish"]);
                    assert.strictEqual(tree.getState(), State.SUCCEEDED);
                });

                it("will restore the action as not yet started, and call the action function again on the next step", () => {
                    const original = new BehaviourTree(definition, createPromiseAgent(createDeferred().promise, []));
                    original.step();

                    const log: string[] = [];
                    const restored = new BehaviourTree(definition, createPromiseAgent(createDeferred().promise, log));
                    restored.restore(JSON.parse(JSON.stringify(original.snapshot())));

                    assert.deepEqual(actionStates(restored), [State.READY, State.READY]);
                    assert.deepEqual(log, []);

                    restored.step();

                    assert.deepEqual(log, ["Approve"]);
                    assert.deepEqual(actionStates(restored), [State.RUNNING, State.READY]);
                });

                [State.SUCCEEDED, State.FAILED].forEach((resolvedState) => {
                    it(`will have the restored tree follow the promise that the action function returns when it is called again (${resolvedState})`, async () => {
                        const original = new BehaviourTree(
                            definition,
                            createPromiseAgent(createDeferred().promise, [])
                        );
                        original.step();

                        const approval = createDeferred();
                        const log: string[] = [];
                        const restored = new BehaviourTree(definition, createPromiseAgent(approval.promise, log));
                        restored.restore(original.snapshot());
                        restored.step();
                        restored.step();
                        assert.deepEqual(log, ["Approve"]);
                        assert.deepEqual(actionStates(restored), [State.RUNNING, State.READY]);

                        approval.resolve(resolvedState);
                        await settlePromises();
                        restored.step();

                        assert.deepEqual(log, resolvedState === State.SUCCEEDED ? ["Approve", "Finish"] : ["Approve"]);
                        assert.deepEqual(actionStates(restored), [
                            resolvedState,
                            resolvedState === State.SUCCEEDED ? State.SUCCEEDED : State.READY
                        ]);
                    });
                });

                it("will ignore the promise that was pending when the snapshot was restored to the tree that it was taken from", async () => {
                    const first = createDeferred();
                    const log: string[] = [];
                    const tree = new BehaviourTree(definition, createPromiseAgent(first.promise, log));
                    tree.step();
                    const snapshot = tree.snapshot();
                    tree.restore(snapshot);

                    // The promise from before the restore is of no interest to the action node, as it will call the function again.
                    first.resolve(State.FAILED);
                    await settlePromises();
                    tree.step();

                    assert.deepEqual(log, ["Approve", "Approve"]);
                    assert.deepEqual(actionStates(tree), [State.RUNNING, State.READY]);
                    assert.strictEqual(tree.getState(), State.RUNNING);
                });

                it("will call the entry callback again, and the exit callback once, as the restored action starts again", async () => {
                    const log: string[] = [];
                    const approval = createDeferred();
                    const agent = {
                        ...createPromiseAgent(approval.promise, log),
                        OnEntry: () => log.push("entry"),
                        OnExit: () => log.push("exit")
                    };
                    const mdsl = "root { action [Approve] entry(OnEntry) exit(OnExit) }";
                    const original = new BehaviourTree(mdsl, agent);
                    original.step();

                    const restored = new BehaviourTree(mdsl, agent);
                    restored.restore(original.snapshot());
                    log.length = 0;
                    restored.step();
                    approval.resolve(State.SUCCEEDED);
                    await settlePromises();
                    restored.step();

                    assert.deepEqual(log, ["entry", "Approve", "exit"]);
                });

                it("will not call the exit callback if the restored action is aborted by a guard before it starts again, as it was not running", () => {
                    const log: string[] = [];
                    let isOkay = true;
                    const agent = {
                        Approve: () => (log.push("Approve"), createDeferred().promise),
                        IsOkay: () => isOkay,
                        OnEntry: () => log.push("entry"),
                        OnExit: (result: { aborted: boolean }) => log.push(`exit aborted=${result.aborted}`)
                    };
                    const mdsl = "root { action [Approve] while(IsOkay) entry(OnEntry) exit(OnExit) }";
                    const original = new BehaviourTree(mdsl, agent);
                    original.step();
                    const snapshot = original.snapshot();

                    // The original tree has been running, so it reports the abort.
                    log.length = 0;
                    isOkay = false;
                    original.step();
                    assert.deepEqual(log, ["exit aborted=true"]);

                    log.length = 0;
                    const restored = new BehaviourTree(mdsl, agent);
                    restored.restore(snapshot);
                    restored.step();

                    assert.deepEqual(log, []);
                    assert.strictEqual(restored.getState(), State.FAILED);
                });

                describe("will restore a tree that behaves as one that has had the promise from the start, apart from the action function being called again, when the action is in", () => {
                    const definitions: { [description: string]: string } = {
                        "a sequence": "root { sequence { action [Start] action [Approve] action [Finish] } }",
                        "a selector": "root { selector { action [Fail] action [Approve] action [Finish] } }",
                        "a parallel": "root { parallel { action [Approve] action [Start] } }",
                        "a race": "root { race { action [Approve] action [Never] } }",
                        "an all": "root { all { action [Approve] action [Start] } }",
                        "a lotto": "root { lotto { action [Approve] } }",
                        "a repeat": "root { repeat [2] { action [Approve] } }",
                        "a retry": "root { retry [2] { action [Approve] } }",
                        "a flip": "root { flip { action [Approve] } }",
                        "a succeed": "root { succeed { action [Approve] } }",
                        "a fail": "root { fail { action [Approve] } }",
                        "a branch with a guard": "root { sequence while(IsOkay) { action [Approve] } }"
                    };

                    Object.entries(definitions).forEach(([description, mdsl]) => {
                        it(description, async () => {
                            const createAgent = (approval: Promise<unknown>, log: string[]) => ({
                                Start: () => State.SUCCEEDED,
                                Fail: () => State.FAILED,
                                Never: () => State.RUNNING,
                                Approve: () => (log.push("Approve"), approval),
                                Finish: () => State.SUCCEEDED,
                                IsOkay: () => true
                            });
                            // A tree that has had its promise from the start, which the restored tree should be no different from.
                            const approval = createDeferred();
                            const controlLog: string[] = [];
                            const control = new BehaviourTree(mdsl, createAgent(approval.promise, controlLog));
                            control.step();
                            control.step();

                            const original = new BehaviourTree(mdsl, createAgent(createDeferred().promise, []));
                            original.step();
                            original.step();
                            const log: string[] = [];
                            const restored = new BehaviourTree(mdsl, createAgent(approval.promise, log));
                            restored.restore(JSON.parse(JSON.stringify(original.snapshot())));
                            restored.step();

                            assert.deepEqual(log, ["Approve"]);
                            assert.deepEqual(controlLog, ["Approve"]);
                            assert.deepEqual(
                                withoutNodeIds(restored.getTreeNodeDetails()),
                                withoutNodeIds(control.getTreeNodeDetails())
                            );

                            approval.resolve(State.SUCCEEDED);
                            await settlePromises();
                            control.step();
                            restored.step();

                            assert.deepEqual(log, controlLog);
                            assert.deepEqual(
                                withoutNodeIds(restored.getTreeNodeDetails()),
                                withoutNodeIds(control.getTreeNodeDetails())
                            );
                        });
                    });
                });
            });

            [State.SUCCEEDED, State.FAILED].forEach((resolvedState) => {
                it(`will resume with the state that the promise resolved with (${resolvedState}), without calling the action function again`, async () => {
                    const approval = createDeferred();
                    const original = new BehaviourTree(definition, createPromiseAgent(approval.promise, []));
                    original.step();
                    approval.resolve(resolvedState);
                    await settlePromises();

                    const log: string[] = [];
                    const restored = new BehaviourTree(definition, createPromiseAgent(approval.promise, log));
                    restored.restore(JSON.parse(JSON.stringify(original.snapshot())));
                    assert.deepEqual(actionStates(restored), [State.RUNNING, State.READY]);

                    restored.step();
                    original.step();

                    assert.deepEqual(log, resolvedState === State.SUCCEEDED ? ["Finish"] : []);
                    assert.deepEqual(actionStates(restored), actionStates(original));
                    assert.deepEqual(actionStates(restored), [
                        resolvedState,
                        resolvedState === State.SUCCEEDED ? State.SUCCEEDED : State.READY
                    ]);
                });
            });

            it("will restore a snapshot taken after the node has moved on from the promise", async () => {
                const approval = createDeferred();
                const original = new BehaviourTree(definition, createPromiseAgent(approval.promise, []));
                original.step();
                approval.resolve(State.FAILED);
                await settlePromises();
                original.step();
                assert.strictEqual(original.getState(), State.FAILED);

                const restored = new BehaviourTree(definition, createPromiseAgent(approval.promise, []));
                restored.restore(JSON.parse(JSON.stringify(original.snapshot())));

                assert.strictEqual(restored.getState(), State.FAILED);
                assert.deepEqual(
                    withoutNodeIds(restored.getTreeNodeDetails()),
                    withoutNodeIds(original.getTreeNodeDetails())
                );
            });

            it("will call the action function again on the next step if the snapshot is of a tree that was reset", async () => {
                const approval = createDeferred();
                const original = new BehaviourTree(definition, createPromiseAgent(approval.promise, []));
                original.step();
                approval.resolve(State.SUCCEEDED);
                await settlePromises();
                original.reset();

                const log: string[] = [];
                const restored = new BehaviourTree(definition, createPromiseAgent(new Promise(() => undefined), log));
                restored.restore(original.snapshot());
                restored.step();

                assert.deepEqual(log, ["Approve"]);
            });

            it("will not take a snapshot if the promise was rejected or resolved with something other than a finished state", async () => {
                const rejection = createDeferred();
                const rejected = new BehaviourTree(definition, createPromiseAgent(rejection.promise, []));
                rejected.step();
                rejection.reject("it went wrong");
                await settlePromises();

                assert.throws(
                    () => rejected.snapshot(),
                    Error,
                    "error creating snapshot: cannot snapshot action node 'Approve' as the promise that it returned was rejected or did not resolve with a finished state"
                );

                const invalid = createDeferred();
                const resolvedInvalid = new BehaviourTree(definition, createPromiseAgent(invalid.promise, []));
                resolvedInvalid.step();
                invalid.resolve(State.RUNNING);
                await settlePromises();

                assert.throws(
                    () => resolvedInvalid.snapshot(),
                    Error,
                    "error creating snapshot: cannot snapshot action node 'Approve' as the promise that it returned was rejected or did not resolve with a finished state"
                );
            });

            it("will ignore a promise from before the restore settling, rather than letting it change the restored state", async () => {
                const source = createDeferred();
                const sourceTree = new BehaviourTree(definition, createPromiseAgent(source.promise, []));
                sourceTree.step();
                source.resolve(State.FAILED);
                await settlePromises();
                const snapshot = sourceTree.snapshot();

                // The tree that is being restored to is waiting for a different promise.
                const staleDeferred = createDeferred();
                const tree = new BehaviourTree(definition, createPromiseAgent(staleDeferred.promise, []));
                tree.step();
                tree.restore(snapshot);

                staleDeferred.resolve(State.SUCCEEDED);
                await settlePromises();
                tree.step();

                assert.deepEqual(actionStates(tree), [State.FAILED, State.READY]);
                assert.strictEqual(tree.getState(), State.FAILED);
            });
        });

        describe("will throw an error, leaving the tree unchanged, if the snapshot", () => {
            const assertRestoreThrows = (modify: (actionSnapshot: any) => void, message: string) => {
                const source = new BehaviourTree(definition, {
                    Approve: () => State.RUNNING,
                    Finish: () => State.RUNNING
                });
                source.step();
                const snapshot: any = JSON.parse(JSON.stringify(source.snapshot()));
                modify(snapshot.root.children[0].children[0]);

                const target = new BehaviourTree(definition, {});
                const detailsBefore = withoutNodeIds(target.getTreeNodeDetails());

                assert.throws(() => target.restore(snapshot), Error, message);
                assert.deepEqual(withoutNodeIds(target.getTreeNodeDetails()), detailsBefore);
            };

            it("has an invalid resolved state", () => {
                [State.RUNNING, State.READY, "succeeded", 1, undefined].forEach((value) =>
                    assertRestoreThrows(
                        (action) => (action.resolvedState = value),
                        "invalid snapshot: expected node 'ROOT > SEQUENCE > Approve' to have a resolved state that is null, 'mistreevous.succeeded' or 'mistreevous.failed'"
                    )
                );
            });
        });
    });
});
