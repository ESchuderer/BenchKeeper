import { assert } from "chai";
import sinon, { SinonFakeTimers, SinonSandbox } from "sinon";

import { BehaviourTree, BehaviourTreeOptions, State } from "../../../src/index";
import { RootNodeDefinition } from "../../../src/BehaviourTreeDefinition";
import { Agent } from "../../../src/Agent";

import { assertRestoredTreeBehavesLikeOriginal, findNode, ScenarioWorld, withoutNodeIds } from "../../TestUtilities";

describe("A Wait node", () => {
    describe("on tree initialisation", () => {
        describe("will error if", () => {
            describe("the defined node arguments are not integers", () => {
                it("(MDSL)", () => {
                    const definition = "root { wait ['not', 'integers'] }";
                    assert.throws(
                        () => new BehaviourTree(definition, {}),
                        Error,
                        "invalid definition: wait node durations must be integer values"
                    );
                });

                it("(JSON)", () => {
                    const definition = {
                        type: "root",
                        child: {
                            type: "wait",
                            duration: ["not", "integers"]
                        }
                    } as any;
                    assert.throws(
                        () => new BehaviourTree(definition, {}),
                        Error,
                        "invalid definition: expected array containing two integer values for 'duration' property if defined for wait node at depth '1'"
                    );
                });
            });

            describe("a negative duration node argument was defined", () => {
                it("(MDSL)", () => {
                    const definition = "root { wait [-1] }";
                    assert.throws(
                        () => new BehaviourTree(definition, {}),
                        Error,
                        "invalid definition: a wait node must have a positive duration"
                    );
                });

                it("(JSON)", () => {
                    const definition = {
                        type: "root",
                        child: {
                            type: "wait",
                            duration: -1
                        }
                    } as any;
                    assert.throws(
                        () => new BehaviourTree(definition, {}),
                        Error,
                        "invalid definition: expected positive duration value for 'duration' property if defined for wait node at depth '1'"
                    );
                });
            });

            describe("more than two node arguments are defined", () => {
                it("(MDSL)", () => {
                    const definition = "root { wait [0, 1000, 4000] }";
                    assert.throws(
                        () => new BehaviourTree(definition, {}),
                        Error,
                        "invalid definition: invalid number of wait node duration arguments defined"
                    );
                });

                it("(JSON)", () => {
                    const definition = {
                        type: "root",
                        child: {
                            type: "wait",
                            duration: [0, 1000, 4000]
                        }
                    } as any;
                    assert.throws(
                        () => new BehaviourTree(definition, {}),
                        Error,
                        "invalid definition: expected array containing two integer values for 'duration' property if defined for wait node at depth '1'"
                    );
                });
            });

            describe("a minimum duration bound node argument is defined that is greater than the maximum duration bound node argument", () => {
                it("(MDSL)", () => {
                    const definition = "root { wait [1000, 500] }";
                    assert.throws(
                        () => new BehaviourTree(definition, {}),
                        Error,
                        "invalid definition: a wait node must not have a minimum duration that exceeds the maximum duration"
                    );
                });

                it("(JSON)", () => {
                    const definition = {
                        type: "root",
                        child: {
                            type: "wait",
                            duration: [1000, 500]
                        }
                    } as any;
                    assert.throws(
                        () => new BehaviourTree(definition, {}),
                        Error,
                        "invalid definition: expected minimum duration value that does not exceed the maximum duration value for 'duration' property if defined for wait node at depth '1'"
                    );
                });
            });
        });
    });

    describe("when updated as part of a tree step", () => {
        let clock: SinonFakeTimers;
        let sandbox: SinonSandbox;

        beforeEach(() => {
            clock = sinon.useFakeTimers();
            sandbox = sinon.createSandbox();
            sandbox.replace(globalThis.Math, "random", () => 0.5);
        });

        afterEach(() => {
            clock.restore();
            sandbox.restore();
        });

        describe("and an explicit duration was defined will move to the SUCCEEDED state if the duration has expired", () => {
            it("(MDSL)", () => {
                const definition = "root { wait [100] }";
                const tree = new BehaviourTree(definition, {});

                let node = findNode(tree, "wait");
                assert.strictEqual(node.state, State.READY);

                tree.step();

                node = findNode(tree, "wait");
                assert.strictEqual(node.state, State.RUNNING);

                clock.tick(99);

                tree.step();

                node = findNode(tree, "wait");
                assert.strictEqual(node.state, State.RUNNING);

                clock.tick(1);

                tree.step();

                node = findNode(tree, "wait");
                assert.strictEqual(node.state, State.SUCCEEDED);
            });

            it("(JSON)", () => {
                const definition: RootNodeDefinition = {
                    type: "root",
                    child: {
                        type: "wait",
                        duration: 100
                    }
                };
                const tree = new BehaviourTree(definition, {});

                let node = findNode(tree, "wait");
                assert.strictEqual(node.state, State.READY);

                tree.step();

                node = findNode(tree, "wait");
                assert.strictEqual(node.state, State.RUNNING);

                clock.tick(99);

                tree.step();

                node = findNode(tree, "wait");
                assert.strictEqual(node.state, State.RUNNING);

                clock.tick(1);

                tree.step();

                node = findNode(tree, "wait");
                assert.strictEqual(node.state, State.SUCCEEDED);
            });
        });

        describe("and min and max durations were defined", () => {
            describe("will select a random duration between the min and max durations and move to the SUCCEEDED state if the duration has expired", () => {
                it("(MDSL)", () => {
                    const definition = "root { wait [5000, 10000] }";
                    const tree = new BehaviourTree(definition, {});

                    let node = findNode(tree, "wait");
                    assert.strictEqual(node.state, State.READY);

                    tree.step();

                    node = findNode(tree, "wait");
                    assert.strictEqual(node.state, State.RUNNING);

                    // We have spied on Math.random to always return 0.5 for the sake of this test, so our actual duration 'should' be 7500ms.
                    clock.tick(7499);

                    tree.step();

                    node = findNode(tree, "wait");
                    assert.strictEqual(node.state, State.RUNNING);

                    clock.tick(1);

                    tree.step();

                    node = findNode(tree, "wait");
                    assert.strictEqual(node.state, State.SUCCEEDED);
                });

                it("(JSON)", () => {
                    const definition: RootNodeDefinition = {
                        type: "root",
                        child: {
                            type: "wait",
                            duration: [5000, 10000]
                        }
                    };
                    const tree = new BehaviourTree(definition, {});

                    let node = findNode(tree, "wait");
                    assert.strictEqual(node.state, State.READY);

                    tree.step();

                    node = findNode(tree, "wait");
                    assert.strictEqual(node.state, State.RUNNING);

                    // We have spied on Math.random to always return 0.5 for the sake of this test, so our actual duration 'should' be 7500ms.
                    clock.tick(7499);

                    tree.step();

                    node = findNode(tree, "wait");
                    assert.strictEqual(node.state, State.RUNNING);

                    clock.tick(1);

                    tree.step();

                    node = findNode(tree, "wait");
                    assert.strictEqual(node.state, State.SUCCEEDED);
                });
            });

            describe("will use the 'random' function to select the duration between the min and max durations if it was defined as a behaviour tree option and move to the SUCCEEDED state if the duration has expired", () => {
                it("(MDSL)", () => {
                    const definition = "root { wait [5000, 10000] }";
                    const options = {
                        // Usually this would return a new pseudo-random number each time, but for the sake of this test we
                        // just want to make sure that the number we return actually has an impact on which duration is picked.
                        random: () => 0.2
                    };
                    const tree = new BehaviourTree(definition, {}, options);

                    let node = findNode(tree, "wait");
                    assert.strictEqual(node.state, State.READY);

                    tree.step();

                    node = findNode(tree, "wait");
                    assert.strictEqual(node.state, State.RUNNING);

                    // Our 'random' function option will always return 0.2 for the sake of this test, so our actual duration 'should' be 6000ms.
                    clock.tick(5999);

                    tree.step();

                    node = findNode(tree, "wait");
                    assert.strictEqual(node.state, State.RUNNING);

                    clock.tick(1);

                    tree.step();

                    node = findNode(tree, "wait");
                    assert.strictEqual(node.state, State.SUCCEEDED);
                });

                it("(JSON)", () => {
                    const definition: RootNodeDefinition = {
                        type: "root",
                        child: {
                            type: "wait",
                            duration: [5000, 10000]
                        }
                    };
                    const options = {
                        // Usually this would return a new pseudo-random number each time, but for the sake of this test we
                        // just want to make sure that the number we return actually has an impact on which duration is picked.
                        random: () => 0.2
                    };
                    const tree = new BehaviourTree(definition, {}, options);

                    let node = findNode(tree, "wait");
                    assert.strictEqual(node.state, State.READY);

                    tree.step();

                    node = findNode(tree, "wait");
                    assert.strictEqual(node.state, State.RUNNING);

                    // Our 'random' function option will always return 0.2 for the sake of this test, so our actual duration 'should' be 6000ms.
                    clock.tick(5999);

                    tree.step();

                    node = findNode(tree, "wait");
                    assert.strictEqual(node.state, State.RUNNING);

                    clock.tick(1);

                    tree.step();

                    node = findNode(tree, "wait");
                    assert.strictEqual(node.state, State.SUCCEEDED);
                });
            });
        });

        describe("and an explicit duration or min and max durations were not defined will stay in the RUNNING state until aborted", () => {
            it("(MDSL)", () => {
                const definition = "root { wait while(CanWait) }";
                let canWait = true;
                const agent = { CanWait: () => canWait };
                const tree = new BehaviourTree(definition, agent);

                let node = findNode(tree, "wait");
                assert.strictEqual(node.state, State.READY);

                tree.step();

                node = findNode(tree, "wait");
                assert.strictEqual(node.state, State.RUNNING);

                clock.tick(1000000);

                tree.step();

                node = findNode(tree, "wait");
                assert.strictEqual(node.state, State.RUNNING);

                canWait = false;

                tree.step();

                node = findNode(tree, "wait");
                assert.strictEqual(node.state, State.FAILED);
            });

            it("(JSON)", () => {
                const definition: RootNodeDefinition = {
                    type: "root",
                    child: {
                        type: "wait",
                        while: {
                            call: "CanWait"
                        }
                    }
                };
                let canWait = true;
                const agent = { CanWait: () => canWait };
                const tree = new BehaviourTree(definition, agent);

                let node = findNode(tree, "wait");
                assert.strictEqual(node.state, State.READY);

                tree.step();

                node = findNode(tree, "wait");
                assert.strictEqual(node.state, State.RUNNING);

                clock.tick(1000000);

                tree.step();

                node = findNode(tree, "wait");
                assert.strictEqual(node.state, State.RUNNING);

                canWait = false;

                tree.step();

                node = findNode(tree, "wait");
                assert.strictEqual(node.state, State.FAILED);
            });
        });

        describe("will use the 'getDeltaTime' function to update the elapsed duration if it was defined as a behaviour tree option", () => {
            it("(MDSL)", () => {
                const definition = "root { wait [1000] }";
                const tree = new BehaviourTree(definition, {}, { getDeltaTime: () => 0.5 });

                let node = findNode(tree, "wait");
                assert.strictEqual(node.state, State.READY);

                tree.step();

                node = findNode(tree, "wait");
                assert.strictEqual(node.state, State.RUNNING);

                tree.step();

                node = findNode(tree, "wait");
                assert.strictEqual(node.state, State.SUCCEEDED);
            });

            it("(JSON)", () => {
                const definition: RootNodeDefinition = {
                    type: "root",
                    child: {
                        type: "wait",
                        duration: 1000
                    }
                };
                const tree = new BehaviourTree(definition, {}, { getDeltaTime: () => 0.5 });

                let node = findNode(tree, "wait");
                assert.strictEqual(node.state, State.READY);

                tree.step();

                node = findNode(tree, "wait");
                assert.strictEqual(node.state, State.RUNNING);

                tree.step();

                node = findNode(tree, "wait");
                assert.strictEqual(node.state, State.SUCCEEDED);
            });
        });
    });

    describe("when a snapshot of the tree is restored", () => {
        const ONE_DAY = 24 * 60 * 60 * 1000;

        let clock: SinonFakeTimers;

        beforeEach(() => {
            clock = sinon.useFakeTimers();
        });

        afterEach(() => {
            clock.restore();
        });

        // Takes a snapshot of the source tree, lets time pass while nothing is running and then restores it to a new tree.
        const createRestoredTree = (
            definition: string,
            source: BehaviourTree,
            options: BehaviourTreeOptions = {}
        ): BehaviourTree => {
            const snapshot = JSON.parse(JSON.stringify(source.snapshot()));
            clock.tick(ONE_DAY);
            const restored = new BehaviourTree(definition, {}, options);
            restored.restore(snapshot);
            return restored;
        };

        const stateOf = (tree: BehaviourTree) => findNode(tree, "wait").state;

        describe("and the clock is used to work out how long the node has waited for", () => {
            const definition = "root { wait [1000] }";

            it("will only wait for the remaining time, not counting the time between taking the snapshot and restoring it", () => {
                const tree = new BehaviourTree(definition, {});
                tree.step();
                clock.tick(400);
                tree.step();
                const snapshot = JSON.parse(JSON.stringify(tree.snapshot()));

                // The process goes away and comes back much later.
                clock.tick(ONE_DAY);
                const restored = new BehaviourTree(definition, {});
                restored.restore(snapshot);
                assert.strictEqual(stateOf(restored), State.RUNNING);

                restored.step();
                assert.strictEqual(stateOf(restored), State.RUNNING);

                clock.tick(599);
                restored.step();
                assert.strictEqual(stateOf(restored), State.RUNNING);

                clock.tick(1);
                restored.step();
                assert.strictEqual(stateOf(restored), State.SUCCEEDED);
            });

            it("will count the time between the last step and the snapshot being taken, as it would have been for the original tree", () => {
                const tree = new BehaviourTree(definition, {});
                tree.step();
                clock.tick(400);
                const restored = createRestoredTree(definition, tree);

                restored.step();
                assert.strictEqual(stateOf(restored), State.RUNNING);

                clock.tick(599);
                restored.step();
                assert.strictEqual(stateOf(restored), State.RUNNING);

                clock.tick(1);
                restored.step();
                assert.strictEqual(stateOf(restored), State.SUCCEEDED);
            });

            it("will be finished if the whole duration had already passed when the snapshot was taken", () => {
                const tree = new BehaviourTree(definition, {});
                tree.step();
                clock.tick(1000);
                const restored = createRestoredTree(definition, tree);

                assert.strictEqual(stateOf(restored), State.RUNNING);
                restored.step();

                assert.strictEqual(stateOf(restored), State.SUCCEEDED);
            });

            it("will only wait for the remaining time when restored to the tree that the snapshot was taken from", () => {
                const tree = new BehaviourTree(definition, {});
                tree.step();
                clock.tick(400);
                const snapshot = tree.snapshot();

                clock.tick(ONE_DAY);
                tree.restore(snapshot);

                clock.tick(599);
                tree.step();
                assert.strictEqual(stateOf(tree), State.RUNNING);

                clock.tick(1);
                tree.step();
                assert.strictEqual(stateOf(tree), State.SUCCEEDED);
            });

            it("will keep waiting for the remaining time if the snapshot is restored more than once", () => {
                const tree = new BehaviourTree(definition, {});
                tree.step();
                clock.tick(400);
                const snapshot = tree.snapshot();

                for (const downtime of [ONE_DAY, 5000, 1]) {
                    clock.tick(downtime);
                    tree.restore(snapshot);

                    clock.tick(599);
                    tree.step();
                    assert.strictEqual(stateOf(tree), State.RUNNING);
                }

                clock.tick(1);
                tree.step();
                assert.strictEqual(stateOf(tree), State.SUCCEEDED);
            });

            it("will be snapshotted as restored until it is stepped, and then with the time that has passed since it was restored", () => {
                const tree = new BehaviourTree(definition, {});
                tree.step();
                clock.tick(400);
                const snapshot = JSON.parse(JSON.stringify(tree.snapshot()));

                clock.tick(ONE_DAY);
                const restored = new BehaviourTree(definition, {});
                restored.restore(snapshot);
                clock.tick(100);
                assert.deepEqual(JSON.parse(JSON.stringify(restored.snapshot())), snapshot);

                // The time that passed after it was restored still counts towards the time waited.
                restored.step();
                const { root } = restored.snapshot() as { root: { children: { waitedDuration: number }[] } };
                assert.strictEqual(root.children[0].waitedDuration, 500);
                clock.tick(499);
                restored.step();
                assert.strictEqual(stateOf(restored), State.RUNNING);
                clock.tick(1);
                restored.step();
                assert.strictEqual(stateOf(restored), State.SUCCEEDED);
            });

            it("will use the random duration that was picked by the original tree rather than picking another", () => {
                const randomDefinition = "root { wait [1000, 5000] }";
                // Picks the shortest duration of 1000ms.
                const tree = new BehaviourTree(randomDefinition, {}, { random: () => 0 });
                tree.step();
                clock.tick(600);
                const snapshot = JSON.parse(JSON.stringify(tree.snapshot()));

                clock.tick(ONE_DAY);
                // Would pick the longest duration of 5000ms.
                const restored = new BehaviourTree(randomDefinition, {}, { random: () => 0.9999 });
                restored.restore(snapshot);

                clock.tick(399);
                restored.step();
                assert.strictEqual(stateOf(restored), State.RUNNING);

                clock.tick(1);
                restored.step();
                assert.strictEqual(stateOf(restored), State.SUCCEEDED);
            });

            it("will carry on waiting indefinitely if no duration was defined", () => {
                const tree = new BehaviourTree("root { wait }", {});
                tree.step();
                clock.tick(1000);
                const restored = createRestoredTree("root { wait }", tree);

                restored.step();

                assert.strictEqual(stateOf(restored), State.RUNNING);
            });

            it("will start waiting when first updated if the node had not been updated yet", () => {
                const tree = new BehaviourTree(definition, {});
                const restored = createRestoredTree(definition, tree);
                assert.strictEqual(stateOf(restored), State.READY);

                restored.step();
                assert.strictEqual(stateOf(restored), State.RUNNING);

                clock.tick(999);
                restored.step();
                assert.strictEqual(stateOf(restored), State.RUNNING);

                clock.tick(1);
                restored.step();
                assert.strictEqual(stateOf(restored), State.SUCCEEDED);
            });

            it("will restore a finished wait node as finished and start waiting again on the next step", () => {
                const randomDefinition = "root { wait [1000, 5000] }";
                const tree = new BehaviourTree(randomDefinition, {}, { random: () => 0 });
                tree.step();
                clock.tick(1000);
                tree.step();
                assert.strictEqual(stateOf(tree), State.SUCCEEDED);

                // The next run picks a new random duration of 5000ms.
                const restored = new BehaviourTree(randomDefinition, {}, { random: () => 0.9999 });
                restored.restore(JSON.parse(JSON.stringify(tree.snapshot())));
                assert.strictEqual(restored.getState(), State.SUCCEEDED);
                assert.strictEqual(stateOf(restored), State.SUCCEEDED);

                clock.tick(ONE_DAY);
                restored.step();
                assert.strictEqual(stateOf(restored), State.RUNNING);

                clock.tick(4999);
                restored.step();
                assert.strictEqual(stateOf(restored), State.RUNNING);

                clock.tick(1);
                restored.step();
                assert.strictEqual(stateOf(restored), State.SUCCEEDED);
            });

            it("will restore wait nodes that are running in parallel with their own progress", () => {
                const parallelDefinition = "root { parallel { wait [1000] sequence { wait [500] wait [2000] } } }";
                const tree = new BehaviourTree(parallelDefinition, {});
                tree.step();
                clock.tick(700);
                tree.step();
                clock.tick(100);
                const restored = createRestoredTree(parallelDefinition, tree);

                const waitStates = (t: BehaviourTree) =>
                    t.getTreeNodeDetails().children![0].children!.map((c) => c.state);

                restored.step();
                // 800ms have been waited so far, so the first wait node still has 200ms to go.
                assert.strictEqual(restored.getState(), State.RUNNING);
                assert.strictEqual(waitStates(restored)[0], State.RUNNING);

                clock.tick(200);
                restored.step();
                assert.strictEqual(waitStates(restored)[0], State.SUCCEEDED);
                assert.strictEqual(restored.getState(), State.RUNNING);

                // The second wait of the sequence started 100ms before the snapshot was taken and has waited for 300ms.
                clock.tick(1699);
                restored.step();
                assert.strictEqual(restored.getState(), State.RUNNING);

                clock.tick(1);
                restored.step();
                assert.strictEqual(restored.getState(), State.SUCCEEDED);
            });
        });

        describe("and the 'getDeltaTime' function is used to work out how long the node has waited for", () => {
            const definition = "root { wait [1000] }";

            it("will only wait for the remaining time, not counting the time between taking the snapshot and restoring it", () => {
                let deltaTime = 0.4;
                const tree = new BehaviourTree(definition, {}, { getDeltaTime: () => deltaTime });
                tree.step();
                const snapshot = JSON.parse(JSON.stringify(tree.snapshot()));

                // The clock moves on a lot, but this should not matter as it is not what is being used.
                clock.tick(ONE_DAY);
                const restored = new BehaviourTree(definition, {}, { getDeltaTime: () => deltaTime });
                restored.restore(snapshot);

                deltaTime = 0.5;
                restored.step();
                assert.strictEqual(stateOf(restored), State.RUNNING);

                deltaTime = 0.1;
                restored.step();
                assert.strictEqual(stateOf(restored), State.SUCCEEDED);
            });

            it("will not count time that passes between steps in the way that the clock would", () => {
                const deltaTime = 0.25;
                const tree = new BehaviourTree(definition, {}, { getDeltaTime: () => deltaTime });
                tree.step();
                tree.step();
                const restored = new BehaviourTree(definition, {}, { getDeltaTime: () => deltaTime });
                restored.restore(JSON.parse(JSON.stringify(tree.snapshot())));

                clock.tick(ONE_DAY);
                restored.step();
                assert.strictEqual(stateOf(restored), State.RUNNING);

                restored.step();
                assert.strictEqual(stateOf(restored), State.SUCCEEDED);
            });

            it("will behave as the original tree does, whenever the snapshot is taken", () => {
                const createAgent = (log: string[], world: ScenarioWorld) => ({
                    Work: (until: number) => {
                        log.push(`Work ${until}`);
                        return world.step >= until ? State.SUCCEEDED : State.RUNNING;
                    }
                });

                [
                    "root { sequence { wait [1000] action [Work, 5] wait [500] } }",
                    "root { parallel { wait [700] sequence { wait [300] wait [900] } action [Work, 4] } }",
                    "root { repeat [2] { wait [1000, 2000] } }",
                    "root { sequence { wait [1000, 5000] wait } }"
                ].forEach((scenarioDefinition) => {
                    for (let stepsBeforeSnapshot = 0; stepsBeforeSnapshot <= 14; stepsBeforeSnapshot++) {
                        assertRestoredTreeBehavesLikeOriginal({
                            definition: scenarioDefinition,
                            createAgent,
                            random: [0, 0.99, 0.5],
                            options: { getDeltaTime: () => 0.3 },
                            stepsBeforeSnapshot,
                            stepsAfterRestore: 14
                        });
                    }
                });
            });

            it("will still be able to snapshot and restore a wait node that has finished after a delta time that is not a finite number", () => {
                const tree = new BehaviourTree(definition, {}, { getDeltaTime: () => Infinity });
                tree.step();
                assert.strictEqual(stateOf(tree), State.SUCCEEDED);

                const snapshot = tree.snapshot();
                assert.deepEqual(JSON.parse(JSON.stringify(snapshot)), snapshot);

                const restored = new BehaviourTree(definition, {}, { getDeltaTime: () => 0.5 });
                restored.restore(JSON.parse(JSON.stringify(snapshot)));
                assert.strictEqual(stateOf(restored), State.SUCCEEDED);
            });
        });

        it("will restore a negative total duration, as a 'random' function that returns less than 0 results in", () => {
            const definition = "root { wait [100, 200] }";
            // A delta time that is not positive means that the node does not finish straight away.
            const options = { random: () => -1, getDeltaTime: () => -1 };
            const original = new BehaviourTree(definition, {}, options);
            original.step();
            assert.strictEqual(stateOf(original), State.RUNNING);

            const restored = new BehaviourTree(definition, {}, { getDeltaTime: () => 2 });
            restored.restore(JSON.parse(JSON.stringify(original.snapshot())));
            restored.step();

            assert.strictEqual(stateOf(restored), State.SUCCEEDED);
        });

        describe("will throw an error, leaving the tree unchanged, if the snapshot", () => {
            const definition = "root { wait [1000] }";

            const assertRestoreThrows = (modify: (waitSnapshot: any) => void, message: string) => {
                const source = new BehaviourTree(definition, {});
                source.step();
                const snapshot: any = JSON.parse(JSON.stringify(source.snapshot()));
                modify(snapshot.root.children[0]);

                const target = new BehaviourTree(definition, {});
                const detailsBefore = withoutNodeIds(target.getTreeNodeDetails());

                assert.throws(() => target.restore(snapshot), Error, message);
                assert.deepEqual(withoutNodeIds(target.getTreeNodeDetails()), detailsBefore);
            };

            it("has an invalid waited duration", () => {
                [null, "400", Infinity, NaN, undefined].forEach((value) =>
                    assertRestoreThrows(
                        (wait) => (wait.waitedDuration = value),
                        "invalid snapshot: expected node 'ROOT > WAIT 1000ms' to have a waited duration that is a finite number"
                    )
                );
            });

            it("has an invalid total duration", () => {
                ["1000", Infinity, undefined].forEach((value) =>
                    assertRestoreThrows(
                        (wait) => (wait.totalDuration = value),
                        "invalid snapshot: expected node 'ROOT > WAIT 1000ms' to have a total duration that is null or a finite number"
                    )
                );
            });
        });
    });
});
