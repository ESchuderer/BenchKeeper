# Snapshot / restore of tree execution state

Status: in-progress

## Request

Long-running workflows (hours/days of waiting, process restarts) need the execution state of a
`BehaviourTree` to be serialised and restored. Storage, events and scheduling stay in the application.

## API

- `tree.snapshot(): BehaviourTreeSnapshot` - plain JSON-safe object (no functions, class instances,
  `undefined`, `NaN`/`Infinity`). `JSON.parse(JSON.stringify(s))` deep-equals `s`.
- `tree.restore(snapshot: BehaviourTreeSnapshot): void` - sets a tree built from the *same definition*
  to that state. Afterwards it behaves as the original would have: same node states, same agent
  function calls in the same order, same result.
- Types `BehaviourTreeSnapshot` and `NodeSnapshot` are exported from the package.

## Format

```
BehaviourTreeSnapshot = { version: 1, definition: string, root: NodeSnapshot }
NodeSnapshot          = { type, state, ...type-specific, children? }   // mirrors the node tree
```

`definition` identifies the definition the tree was built from: a hash of the canonical form of the validated
JSON definition (keys sorted, empty `args` and `succeedOnAbort: false` left out, root nodes sorted), worked out once
when the tree is built. An MDSL definition and its equivalent JSON definition therefore have the same `definition`.

`children` is used for every composite and decorator (decorators have exactly one), so a snapshot has
the same shape as `getTreeNodeDetails()`. Nodes are matched to the tree by position, `type` and child
count. Every node also keeps its `id`: ids are random per instance, so without them a restored tree
would not look like the original in `getTreeNodeDetails()` or in `onNodeStateChange` events.

| Node                                          | Kept besides `state`                                                     |
| --------------------------------------------- | ------------------------------------------------------------------------ |
| every node                                    | `id`, `type`, `state`                                                    |
| root, flip, succeed, fail                     | nothing (child state is in `children`)                                   |
| sequence, selector, parallel, race, all       | nothing (which children are done/running is the children's `state`)      |
| lotto                                         | `selectedChildIndex` (index of the drawn child, or `null`)               |
| repeat                                        | `targetIterationCount` (incl. random pick), `currentIterationCount`      |
| retry                                         | `targetAttemptCount` (incl. random pick), `currentAttemptCount`          |
| wait                                          | `totalDuration` (incl. random pick), `waitedDuration`                    |
| action, condition                             | nothing                                                                  |

Not kept: definition, agent, options, registered functions/subtrees (the application supplies them
again), future `random()` output (belongs to the `random` option).

## Decisions

- **Wait timing.** `waitedDuration` is elapsed ms at snapshot time, independent of clock mode.
  `Date` mode: a running wait records `now - initialUpdateTime`; restore sets
  `initialUpdateTime = now - waitedDuration`, so time between snapshot and restore is not counted.
  `getDeltaTime` mode: `waitedDuration` is already an accumulator and is stored/restored as is.
- **Finished trees.** A finished root restores as finished; `step()` already resets a finished root
  before updating, so the next run redraws random choices through the normal READY path.
- **Restore is atomic.** The whole snapshot is validated against the tree (it is an object, version, definition,
  node types, child counts, states, numeric fields) before any node is touched; invalid snapshots throw
  `invalid snapshot: ...` and leave the tree unchanged.
- **Restore calls no agent functions** (no `exit`/abort callbacks for what it overwrites) and does not call
  `onNodeStateChange`: restoring is not a state change. The next `step()` reports changes as usual.
- **Definition check.** `restore()` throws `invalid snapshot: the snapshot does not match the tree's definition`
  for a snapshot of another definition, before looking at any node. Input that is not a snapshot (`null`, a string,
  a number, an array, an object without the snapshot's fields) throws an `Error` too. Registered subtrees are not
  part of the definition, only the `branch` ref is; a change inside one is only caught by the structure check.
- **Promise-based actions.** A pending promise cannot be serialised. An action node that is RUNNING on a promise
  (settled or not, until the tree is stepped again) is snapshotted as READY, so the restored tree calls its action
  function (and `entry` callback) again on its next step. The original tree is not changed. This is a documented
  limitation: the action must cope with being called twice. Applications that model long waits should use an
  action that returns `RUNNING` until the external event is recorded in agent state (documented in README).

## Order of work (test first)

1. API shape, JSON safety, node states for composites/decorators/leaves, finished trees.
2. `lotto`, `repeat`, `retry` random choices and counters.
3. `wait` timing for `Date` and `getDeltaTime`.
4. Validation / atomic restore, pending-promise actions.
5. README, Version History, version 4.4.0, rebuilt `dist`.
