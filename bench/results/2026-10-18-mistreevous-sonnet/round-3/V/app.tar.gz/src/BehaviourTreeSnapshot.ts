import { AnyState } from "./State";

/**
 * The version of the snapshot format that is produced and accepted by a behaviour tree.
 */
export const SNAPSHOT_VERSION = 1;

/**
 * The state shared by the snapshots of all nodes.
 */
type NodeSnapshotBase = {
    /**
     * The node unique identifier.
     */
    id: string;
    /**
     * The node type.
     */
    type: string;
    /**
     * The node state.
     */
    state: AnyState;
};

/**
 * The state shared by the snapshots of composite and decorator nodes.
 */
export type NodeSnapshotWithChildren = NodeSnapshotBase & {
    /**
     * The snapshots of the child nodes, in the order that they are defined. A decorator node has exactly one child.
     */
    children: NodeSnapshot[];
};

/**
 * The snapshot of an action or condition node.
 */
export type LeafNodeSnapshot = NodeSnapshotBase & {
    type: "action" | "condition";
};

/**
 * The snapshot of a composite or decorator node that has no state of its own other than that of its children.
 */
export type ParentNodeSnapshot = NodeSnapshotWithChildren & {
    type: "root" | "flip" | "succeed" | "fail" | "sequence" | "selector" | "parallel" | "race" | "all";
};

/**
 * The snapshot of a lotto node.
 */
export type LottoNodeSnapshot = NodeSnapshotWithChildren & {
    type: "lotto";
    /**
     * The index of the child node that was drawn to be the active one, or null if there has been no draw.
     */
    selectedChildIndex: number | null;
};

/**
 * The snapshot of a repeat node.
 */
export type RepeatNodeSnapshot = NodeSnapshotWithChildren & {
    type: "repeat";
    /**
     * The number of iterations to make, which includes any random choice, or null if there is no limit.
     */
    targetIterationCount: number | null;
    /**
     * The number of iterations that have been completed.
     */
    currentIterationCount: number;
};

/**
 * The snapshot of a retry node.
 */
export type RetryNodeSnapshot = NodeSnapshotWithChildren & {
    type: "retry";
    /**
     * The number of attempts to make, which includes any random choice, or null if there is no limit.
     */
    targetAttemptCount: number | null;
    /**
     * The number of attempts that have been completed.
     */
    currentAttemptCount: number;
};

/**
 * The snapshot of a wait node.
 */
export type WaitNodeSnapshot = NodeSnapshotBase & {
    type: "wait";
    /**
     * The duration in milliseconds that the node waits for, which includes any random choice, or null if it waits until it is aborted.
     */
    totalDuration: number | null;
    /**
     * The duration in milliseconds that the node has been waiting for.
     */
    waitedDuration: number;
};

/**
 * The snapshot of the execution state of a node, and of any nodes beneath it.
 * This is a plain object that can be serialised to JSON, it contains no functions or class instances.
 */
export type NodeSnapshot =
    | LeafNodeSnapshot
    | ParentNodeSnapshot
    | LottoNodeSnapshot
    | RepeatNodeSnapshot
    | RetryNodeSnapshot
    | WaitNodeSnapshot;

/**
 * The snapshot of the execution state of a behaviour tree.
 * This is a plain object that can be serialised to JSON, it contains no functions or class instances.
 */
export type BehaviourTreeSnapshot = {
    /**
     * The version of the snapshot format.
     */
    version: typeof SNAPSHOT_VERSION;
    /**
     * The identifier of the definition that the tree was built from, which is the same for an MDSL definition and its equivalent JSON definition.
     * A snapshot can only be restored to a tree that was built from the same definition.
     */
    definition: string;
    /**
     * The snapshot of the root node of the tree.
     */
    root: NodeSnapshot;
};
