import { RootNodeDefinition } from "./BehaviourTreeDefinition";

/**
 * Creates the error to throw for a snapshot that cannot be restored.
 * @param message The reason that the snapshot cannot be restored.
 * @returns The error to throw.
 */
export function createInvalidSnapshotError(message: string): Error {
    return new Error(`invalid snapshot: ${message}`);
}

/**
 * A type guard function that returns true if the specified value is a non-null object.
 * @param value The value.
 * @returns A value of true if the specified value is a non-null object.
 */
export function isObject(value: unknown): value is Record<string, unknown> {
    return typeof value === "object" && value !== null;
}

/**
 * Gets whether the specified value is a count, which is a non-negative integer.
 * @param value The value.
 * @returns A value of true if the specified value is a count.
 */
export function isCount(value: unknown): value is number {
    return Number.isInteger(value) && (value as number) >= 0;
}

/**
 * Gets the canonical form of a part of a definition, so that definitions that mean the same thing have the same form.
 * Object keys are put in order and the values that a definition gets when it leaves them out, which an MDSL definition
 * converted to JSON always writes out, are left out. These are an empty array of arguments and a guard that does not succeed on abort.
 * @param value The part of a definition.
 * @returns The canonical form of the part of the definition.
 */
function canonicalise(value: unknown): unknown {
    if (Array.isArray(value)) {
        return value.map(canonicalise);
    }

    if (!isObject(value)) {
        return value;
    }

    const canonical: Record<string, unknown> = {};

    for (const key of Object.keys(value).sort()) {
        const property = value[key];

        if (property === undefined) {
            continue;
        }

        if (key === "args" && Array.isArray(property) && property.length === 0) {
            continue;
        }

        if (key === "succeedOnAbort") {
            if (property) {
                canonical[key] = true;
            }
            continue;
        }

        canonical[key] = canonicalise(property);
    }

    return canonical;
}

/**
 * Creates the identifier of a definition, which a snapshot keeps to show which definition it was taken from.
 * The same identifier is created for an MDSL definition and for its equivalent JSON definition.
 * @param rootNodeDefinitions The root node definitions of the definition as JSON.
 * @returns The identifier of the definition.
 */
export function createDefinitionId(rootNodeDefinitions: RootNodeDefinition[]): string {
    // The order of the root nodes of a definition does not mean anything.
    const canonical = rootNodeDefinitions.map((rootNodeDefinition) => JSON.stringify(canonicalise(rootNodeDefinition)));
    const text = canonical.sort().join(",");

    // This is the 53 bit cyrb53 hash, which is enough to tell definitions apart and does not need anything that is only in Node.
    let h1 = 0xdeadbeef;
    let h2 = 0x41c6ce57;

    for (let index = 0; index < text.length; index++) {
        const code = text.charCodeAt(index);
        h1 = Math.imul(h1 ^ code, 2654435761);
        h2 = Math.imul(h2 ^ code, 1597334677);
    }

    h1 = Math.imul(h1 ^ (h1 >>> 16), 2246822507) ^ Math.imul(h2 ^ (h2 >>> 13), 3266489909);
    h2 = Math.imul(h2 ^ (h2 >>> 16), 2246822507) ^ Math.imul(h1 ^ (h1 >>> 13), 3266489909);

    return (4294967296 * (2097151 & h2) + (h1 >>> 0)).toString(16).padStart(14, "0");
}
