import createLotto from "lotto-draw";

import Node from "../Node";
import Composite from "./Composite";
import State from "../../State";
import { Agent } from "../../Agent";
import Attribute from "../../attributes/Attribute";
import { BehaviourTreeOptions } from "../../BehaviourTreeOptions";
import { LottoNodeSnapshot } from "../../BehaviourTreeSnapshot";
import { createInvalidSnapshotError, isCount } from "../../BehaviourTreeSnapshotUtilities";

/**
 * A LOTTO node.
 * A winning child is picked on the initial update of this node, based on ticket weighting.
 * The state of this node will match the state of the winning child.
 */
export default class Lotto extends Composite {
    /**
     * @param attributes The node attributes.
     * @param options The behaviour tree options.
     * @param weights The child node weights.
     * @param children The child nodes.
     */
    constructor(
        attributes: Attribute[],
        options: BehaviourTreeOptions,
        private weights: number[] | undefined,
        children: Node[]
    ) {
        super("lotto", attributes, options, children);
    }

    /**
     * The child node selected to be the active one.
     */
    private selectedChild: Node | undefined;

    /**
     * Called when the node is being updated.
     * @param agent The agent.
     */
    protected onUpdate(agent: Agent): void {
        // If this node is in the READY state then we need to pick a winning child node.
        if (this.is(State.READY)) {
            // Create a lotto draw with which to randomly pick a child node to become the active one.
            const lottoDraw = createLotto<Node>({
                // Hook up the optional 'random' behaviour tree function option to the one used by 'lotto-draw'.
                random: this.options.random,
                // Pass in each child node as a participant in the lotto draw with their respective ticket count.
                participants: this.children.map((child, index) => [child, this.weights?.[index] || 1])
            });

            // Randomly pick a child based on ticket weighting, this will become the active child for this composite node.
            this.selectedChild = lottoDraw.draw() || undefined;
        }

        // If something went wrong and we don't have an active child then we should throw an error.
        if (!this.selectedChild) {
            throw new Error("failed to update lotto node as it has no active child");
        }

        // If the selected child has never been updated or is running then we will need to update it now.
        if (this.selectedChild.getState() === State.READY || this.selectedChild.getState() === State.RUNNING) {
            this.selectedChild.update(agent);
        }

        // The state of the lotto node is the state of its selected child.
        this.setState(this.selectedChild.getState());
    }

    /**
     * Gets a snapshot of the execution state of this node instance.
     * @returns A snapshot of the execution state of this node instance.
     */
    public getSnapshot(): LottoNodeSnapshot {
        return {
            ...(super.getSnapshot() as LottoNodeSnapshot),
            selectedChildIndex: this.selectedChild ? this.children.indexOf(this.selectedChild) : null
        };
    }

    /**
     * Validates that a snapshot can be restored to this node instance and its children, throwing an error if it cannot.
     * @param snapshot The snapshot to validate.
     */
    public validateSnapshot(snapshot: unknown): void {
        super.validateSnapshot(snapshot);

        const { state, selectedChildIndex } = snapshot as Record<string, unknown>;

        // A lotto node that is running always has a child that was drawn. One that is not may not have drawn a child,
        // as it moves to a resolved state without drawing if it is aborted by a guard before it can be updated.
        const isDrawn = state === State.RUNNING;

        if (
            selectedChildIndex === null
                ? isDrawn
                : !isCount(selectedChildIndex) || selectedChildIndex >= this.children.length
        ) {
            throw createInvalidSnapshotError(`unexpected selected child index '${selectedChildIndex}' for lotto node`);
        }
    }

    /**
     * Restores the execution state of this node instance and its children from a snapshot that has been validated.
     * @param snapshot The snapshot to restore.
     */
    public restoreSnapshot(snapshot: LottoNodeSnapshot): void {
        super.restoreSnapshot(snapshot);

        this.selectedChild =
            snapshot.selectedChildIndex === null ? undefined : this.children[snapshot.selectedChildIndex];
    }

    /**
     * Gets the name of the node.
     */
    getName = () => (this.weights ? `LOTTO [${this.weights.join(",")}]` : "LOTTO");
}
