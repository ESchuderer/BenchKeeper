import { assert } from "chai";
import sinon, { SinonFakeTimers } from "sinon";

import {
    BehaviourTree,
    BehaviourTreeOptions,
    BehaviourTreeSnapshot,
    NodeDetails,
    State,
    convertMDSLToJSON
} from "../src/index";
import { RootNodeDefinition } from "../src/BehaviourTreeDefinition";

import { findNode } from "./TestUtilities";

/**
 * A scripted result for each successive call of an agent function, the last result being repeated once the script runs out.
 */
type Script = { [functionName: string]: any[] };

/**
 * A scenario in which a tree is stepped, snapshotted at every step and then restored into a new tree.
 */
type Scenario = {
    definition: string | RootNodeDefinition;
    script: Script;
    /** The number of steps to take. */
    steps: number;
    /** The sequence of numbers that the 'random' option cycles through. */
    random?: number[];
    /** The delta time in seconds that the 'getDeltaTime' option returns, if the option is used. */
    deltaTime?: number;
    /** The number of milliseconds that the clock moves on by after each step, if the clock is faked. */
    tickMs?: number;
};

/**
 * The part of the world that lives outside of a tree, which an application is responsible for keeping across a restart.
 */
type World = {
    /** The number of times each agent function has been called. */
    calls: { [functionName: string]: number };
    /** The names of the agent functions called, in order. */
    log: string[];
    /** The number of values taken from the 'random' option. */
    randomCount: number;
    /** The current time in milliseconds. */
    now: number;
};

const createWorld = (): World => ({ calls: {}, log: [], randomCount: 0, now: 0 });

const cloneWorld = (world: World): World => ({ ...world, calls: { ...world.calls }, log: [...world.log] });

/**
 * Creates a tree whose agent, random and delta time options are driven by the specified world.
 */
const createTree = (scenario: Scenario, world: World, useDeltaTime: boolean) => {
    const agent: { [key: string]: any } = {};

    for (const name of Object.keys(scenario.script)) {
        agent[name] = () => {
            world.log.push(name);
            const call = (world.calls[name] = (world.calls[name] ?? 0) + 1);
            return scenario.script[name][Math.min(call, scenario.script[name].length) - 1];
        };
    }

    const options: BehaviourTreeOptions = {
        random: () => {
            const values = scenario.random ?? [0.5];
            return values[world.randomCount++ % values.length];
        }
    };

    if (useDeltaTime) {
        options.getDeltaTime = () => scenario.deltaTime ?? 0.5;
    }

    return new BehaviourTree(scenario.definition, agent, options);
};

/**
 * Steps a tree until it reaches the specified state, giving up if that takes too long.
 */
const stepUntil = (tree: BehaviourTree, state: State) => {
    for (let step = 0; step < 50 && tree.getState() !== state; step++) {
        tree.step();
    }
};

/**
 * Asserts that, for every step of the scenario, a tree restored from a snapshot taken after that step
 * goes on to behave exactly as the tree that the snapshot was taken from.
 * @param scenario The scenario.
 * @param useDeltaTime Whether the trees use the 'getDeltaTime' option rather than the clock.
 * @param clock The fake clock that moves on by the scenario tick duration after each step, if the trees use the clock.
 */
const assertRestoredTreeBehavesLikeOriginal = (
    scenario: Scenario,
    useDeltaTime = false,
    clock: SinonFakeTimers | null = null
) => {
    const tick = () => clock?.tick(scenario.tickMs ?? 0);

    for (let stepsBeforeSnapshot = 0; stepsBeforeSnapshot <= scenario.steps; stepsBeforeSnapshot++) {
        const originalWorld = createWorld();
        const original = createTree(scenario, originalWorld, useDeltaTime);

        for (let step = 0; step < stepsBeforeSnapshot; step++) {
            original.step();
            tick();
        }

        // The snapshot goes through JSON, which is what would happen if it was stored.
        const snapshot: BehaviourTreeSnapshot = JSON.parse(JSON.stringify(original.snapshot()));

        const restoredWorld = cloneWorld(originalWorld);
        const restored = createTree(scenario, restoredWorld, useDeltaTime);
        restored.restore(snapshot);

        const message = `after restoring a snapshot taken after ${stepsBeforeSnapshot} steps`;

        assert.deepEqual(
            restored.getTreeNodeDetails(),
            original.getTreeNodeDetails(),
            `${message}, node details differ`
        );

        for (let step = stepsBeforeSnapshot; step < scenario.steps; step++) {
            original.step();
            restored.step();
            tick();

            assert.deepEqual(restoredWorld.log, originalWorld.log, `${message}, agent function calls differ`);
            assert.strictEqual(restored.getState(), original.getState(), `${message}, tree state differs`);
            assert.deepEqual(
                restored.getTreeNodeDetails(),
                original.getTreeNodeDetails(),
                `${message}, node details differ`
            );
        }
    }
};

describe("A BehaviourTree", () => {
    describe("snapshot", () => {
        it("returns a plain object that is unchanged by a JSON round trip", () => {
            const definition = `root {
                sequence {
                    action [Work]
                    selector {
                        condition [Check]
                        action [Fallback]
                    }
                    parallel { action [A] action [B] }
                }
            }`;
            const scenario: Scenario = {
                definition,
                script: {
                    Work: [undefined, State.SUCCEEDED],
                    Check: [false],
                    Fallback: [undefined],
                    A: [undefined],
                    B: [undefined]
                },
                steps: 3
            };

            // Check the snapshot at every stage of the run, from READY to the point where it is waiting on the fallback.
            const tree = createTree(scenario, createWorld(), false);

            for (let step = 0; step <= scenario.steps; step++) {
                const snapshot = tree.snapshot();
                assert.deepEqual(JSON.parse(JSON.stringify(snapshot)), snapshot);
                tree.step();
            }
        });

        it("contains no functions or class instances", () => {
            const tree = new BehaviourTree("root { sequence { action [Work] wait [100] } }", { Work: () => undefined });
            tree.step();

            const assertPlain = (value: unknown, path: string) => {
                assert.notStrictEqual(typeof value, "function", `${path} is a function`);
                assert.notStrictEqual(typeof value, "undefined", `${path} is undefined`);

                if (typeof value === "object" && value !== null) {
                    const prototype = Object.getPrototypeOf(value);
                    assert.isTrue(
                        prototype === Object.prototype || prototype === Array.prototype,
                        `${path} is not plain`
                    );
                    Object.entries(value).forEach(([key, child]) => assertPlain(child, `${path}.${key}`));
                }
            };

            assertPlain(tree.snapshot(), "snapshot");
        });

        it("does not change the tree", () => {
            const calls: string[] = [];
            const tree = new BehaviourTree("root { sequence { action [Work] wait [100] } }", {
                Work: () => {
                    calls.push("Work");
                    return State.SUCCEEDED;
                }
            });
            tree.step();

            const detailsBefore = tree.getTreeNodeDetails();
            tree.snapshot();

            assert.deepEqual(tree.getTreeNodeDetails(), detailsBefore);
            assert.deepEqual(calls, ["Work"]);
        });

        it("does not share anything with the tree, so changing it afterwards has no effect on the tree", () => {
            const tree = new BehaviourTree("root { sequence { action [Work] action [Next] } }", {
                Work: () => State.SUCCEEDED,
                Next: () => undefined
            });
            tree.step();

            const snapshot = tree.snapshot();
            const original = JSON.parse(JSON.stringify(snapshot));

            const root = snapshot.root as any;
            root.state = State.FAILED;
            root.children[0].state = State.FAILED;
            root.children[0].children[1].state = State.FAILED;

            assert.deepEqual(tree.snapshot(), original);
        });
    });

    describe("restore", () => {
        it("gives the nodes of a tree the states that they had when the snapshot was taken", () => {
            const definition =
                "root { sequence { action [Done] selector { condition [No] action [Busy] } action [Later] } }";
            const agent = {
                Done: () => State.SUCCEEDED,
                No: () => false,
                Busy: () => undefined,
                Later: () => undefined
            };

            const original = new BehaviourTree(definition, agent);
            original.step();

            const restored = new BehaviourTree(definition, agent);
            restored.restore(JSON.parse(JSON.stringify(original.snapshot())));

            assert.strictEqual(restored.getState(), State.RUNNING);
            assert.strictEqual(findNode(restored, "root").state, State.RUNNING);
            assert.strictEqual(findNode(restored, "sequence").state, State.RUNNING);
            assert.strictEqual(findNode(restored, "action", "Done").state, State.SUCCEEDED);
            assert.strictEqual(findNode(restored, "selector").state, State.RUNNING);
            assert.strictEqual(findNode(restored, "condition", "No").state, State.FAILED);
            assert.strictEqual(findNode(restored, "action", "Busy").state, State.RUNNING);
            assert.strictEqual(findNode(restored, "action", "Later").state, State.READY);
        });

        it("continues from where the original tree left off rather than from the start", () => {
            const definition = "root { sequence { action [First] action [Second] action [Third] } }";
            const calls: string[] = [];
            const createAgent = () => ({
                First: () => (calls.push("First"), State.SUCCEEDED),
                Second: () => (calls.push("Second"), State.SUCCEEDED),
                Third: () => (calls.push("Third"), undefined)
            });

            const original = new BehaviourTree(definition, createAgent());
            original.step();
            const snapshot = original.snapshot();

            calls.length = 0;
            const restored = new BehaviourTree(definition, createAgent());
            restored.restore(snapshot);
            restored.step();

            assert.deepEqual(calls, ["Third"]);
        });

        it("does not call any agent functions", () => {
            const calls: string[] = [];
            const track = (name: string, result?: any) => () => (calls.push(name), result);
            const definition = `root {
                sequence entry(Entry) exit(Exit) step(Step) {
                    action [Work] entry(Entry) exit(Exit) step(Step)
                    action [Next] while(Guard)
                }
            }`;
            const agent = {
                Work: track("Work", State.SUCCEEDED),
                Next: track("Next"),
                Entry: track("Entry"),
                Exit: track("Exit"),
                Step: track("Step"),
                Guard: track("Guard", true)
            };

            const original = new BehaviourTree(definition, agent);
            original.step();
            const snapshot = original.snapshot();

            // The tree being restored is part way through a run, so restoring will move running nodes back to ready.
            const restored = new BehaviourTree(definition, agent);
            restored.step();
            calls.length = 0;
            restored.restore(original.snapshot());
            restored.restore(new BehaviourTree(definition, agent).snapshot());
            restored.restore(snapshot);

            assert.deepEqual(calls, []);
        });

        it("does not call 'onNodeStateChange', as restoring a tree is not a change of state", () => {
            const definition = "root { sequence { action [Work] repeat [3] { wait [1000] } } }";
            const agent = { Work: () => State.SUCCEEDED };

            const original = new BehaviourTree(definition, agent, { getDeltaTime: () => 0.25 });
            original.step();
            original.step();

            const changes: string[] = [];
            const tree = new BehaviourTree(definition, agent, {
                getDeltaTime: () => 0.25,
                onNodeStateChange: (change) => changes.push(change.type)
            });
            tree.restore(original.snapshot());

            assert.deepEqual(changes, []);
            assert.deepEqual(tree.getTreeNodeDetails(), original.getTreeNodeDetails());
        });

        it("reports the changes made by the next step as usual, starting from the restored states", () => {
            const definition = "root { sequence { action [Work] action [Next] } }";

            const original = new BehaviourTree(definition, { Work: () => State.SUCCEEDED, Next: () => undefined });
            original.step();

            const changes: string[] = [];
            const tree = new BehaviourTree(
                definition,
                { Work: () => State.SUCCEEDED, Next: () => State.SUCCEEDED },
                {
                    onNodeStateChange: (change) =>
                        changes.push(`${change.id} ${change.type}: ${change.previousState} -> ${change.state}`)
                }
            );
            tree.restore(original.snapshot());
            tree.step();

            const { id: rootId, children } = original.getTreeNodeDetails();
            const { id: sequenceId, children: leaves } = children![0];

            // The changes are reported for the nodes that the original tree had.
            assert.deepEqual(changes, [
                `${leaves![1].id} action: ${State.RUNNING} -> ${State.SUCCEEDED}`,
                `${sequenceId} sequence: ${State.RUNNING} -> ${State.SUCCEEDED}`,
                `${rootId} root: ${State.RUNNING} -> ${State.SUCCEEDED}`
            ]);
        });

        it("gives the nodes the same ids as the nodes of the original tree", () => {
            const definition = "root { sequence { action [Work] wait [1000] } }";
            const agent = { Work: () => State.SUCCEEDED };

            const original = new BehaviourTree(definition, agent);
            original.step();

            const restored = new BehaviourTree(definition, agent);
            restored.restore(JSON.parse(JSON.stringify(original.snapshot())));

            const getIds = (details: NodeDetails): string[] => [
                details.id,
                ...(details.children ?? []).flatMap(getIds)
            ];

            assert.notDeepEqual(
                getIds(restored.getTreeNodeDetails()),
                getIds(new BehaviourTree(definition, agent).getTreeNodeDetails())
            );
            assert.deepEqual(getIds(restored.getTreeNodeDetails()), getIds(original.getTreeNodeDetails()));
            assert.deepEqual(restored.getTreeNodeDetails(), original.getTreeNodeDetails());
        });

        it("can restore a lotto node that was aborted by a guard before it drew a child", () => {
            const definition = "root { sequence { lotto while(Allowed) { action [A] action [B] } action [Next] } }";
            const agent = { Allowed: () => false, A: () => undefined, B: () => undefined, Next: () => undefined };

            const original = new BehaviourTree(definition, agent);
            original.step();
            assert.strictEqual(findNode(original, "lotto").state, State.FAILED);

            const restored = new BehaviourTree(definition, agent);
            restored.restore(JSON.parse(JSON.stringify(original.snapshot())));

            assert.deepEqual(restored.getTreeNodeDetails(), original.getTreeNodeDetails());
        });

        it("keeps a snapshot unchanged by a JSON round trip for a wait node that has waited for an infinite duration", () => {
            const definition = "root { wait [100] }";
            const tree = new BehaviourTree(definition, {}, { getDeltaTime: () => Infinity });
            tree.step();
            assert.strictEqual(tree.getState(), State.SUCCEEDED);

            const snapshot = tree.snapshot();
            assert.deepEqual(JSON.parse(JSON.stringify(snapshot)), snapshot);

            const restored = new BehaviourTree(definition, {}, { getDeltaTime: () => Infinity });
            restored.restore(JSON.parse(JSON.stringify(snapshot)));
            assert.strictEqual(restored.getState(), State.SUCCEEDED);
        });

        it("overwrites any state that the tree being restored already has", () => {
            const definition = "root { sequence { action [Work] action [Next] } }";
            const agent = { Work: () => State.SUCCEEDED, Next: () => undefined };

            const fresh = new BehaviourTree(definition, agent);
            const freshSnapshot = fresh.snapshot();

            const tree = new BehaviourTree(definition, agent);
            tree.step();
            assert.strictEqual(tree.getState(), State.RUNNING);

            tree.restore(freshSnapshot);

            assert.strictEqual(tree.getState(), State.READY);
            assert.deepEqual(tree.getTreeNodeDetails(), fresh.getTreeNodeDetails());
        });

        it("can be done more than once from the same snapshot", () => {
            const definition = "root { sequence { action [Work] action [Next] } }";
            const agent = { Work: () => State.SUCCEEDED, Next: () => undefined };

            const original = new BehaviourTree(definition, agent);
            original.step();
            const snapshot = original.snapshot();

            const tree = new BehaviourTree(definition, agent);
            tree.restore(snapshot);
            tree.step();
            tree.restore(snapshot);

            assert.deepEqual(tree.getTreeNodeDetails(), original.getTreeNodeDetails());
            assert.deepEqual(tree.snapshot(), snapshot);
        });

        it("does not change the snapshot that is passed in", () => {
            const definition = "root { sequence { action [Work] action [Next] } }";
            const agent = { Work: () => State.SUCCEEDED, Next: () => undefined };

            const original = new BehaviourTree(definition, agent);
            original.step();
            const snapshot = original.snapshot();
            const copy = JSON.parse(JSON.stringify(snapshot));

            const tree = new BehaviourTree(definition, agent);
            tree.restore(snapshot);
            tree.step();

            assert.deepEqual(snapshot, copy);
        });

        describe("will make the restored tree behave exactly as the original would have", () => {
            it("for sequence and selector nodes", () => {
                assertRestoredTreeBehavesLikeOriginal({
                    definition: `root {
                        sequence {
                            condition [Ready]
                            selector {
                                action [Fails]
                                action [Slow]
                                action [Never]
                            }
                            action [Last]
                        }
                    }`,
                    script: {
                        Ready: [true],
                        Fails: [State.FAILED],
                        Slow: [undefined, undefined, State.SUCCEEDED],
                        Never: [State.SUCCEEDED],
                        Last: [undefined, State.SUCCEEDED]
                    },
                    steps: 6
                });
            });

            it("for parallel, race and all nodes", () => {
                assertRestoredTreeBehavesLikeOriginal({
                    definition: `root {
                        sequence {
                            parallel {
                                action [P1]
                                sequence { action [P2] action [P3] }
                            }
                            race {
                                action [R1]
                                sequence { action [R2] action [R3] }
                            }
                            all {
                                action [A1]
                                sequence { action [A2] action [A3] }
                            }
                        }
                    }`,
                    script: {
                        P1: [undefined, undefined, State.SUCCEEDED],
                        P2: [State.SUCCEEDED],
                        P3: [undefined, State.SUCCEEDED],
                        R1: [undefined, undefined, undefined, State.FAILED],
                        R2: [undefined, State.SUCCEEDED],
                        R3: [undefined, undefined, State.SUCCEEDED],
                        A1: [undefined, State.FAILED],
                        A2: [State.SUCCEEDED],
                        A3: [undefined, undefined, State.SUCCEEDED]
                    },
                    steps: 12
                });
            });

            it("for flip, succeed and fail nodes", () => {
                assertRestoredTreeBehavesLikeOriginal({
                    definition: `root {
                        sequence {
                            flip { action [F] }
                            succeed { action [S] }
                            fail { action [X] }
                            action [Last]
                        }
                    }`,
                    script: {
                        F: [undefined, undefined, State.FAILED],
                        S: [undefined, State.FAILED],
                        X: [undefined, State.SUCCEEDED],
                        Last: [State.SUCCEEDED]
                    },
                    steps: 8
                });
            });

            it("for nodes with entry, step and exit callbacks and guards", () => {
                assertRestoredTreeBehavesLikeOriginal({
                    definition: `root {
                        sequence entry(OnEntry) exit(OnExit) {
                            action [Work] entry(OnEntry) step(OnStep) exit(OnExit) while(Allowed)
                            action [Next] until(Done)
                        }
                    }`,
                    script: {
                        Work: [undefined, undefined, State.SUCCEEDED],
                        Next: [undefined],
                        OnEntry: [undefined],
                        OnStep: [undefined],
                        OnExit: [undefined],
                        Allowed: [true, true, true, true, false],
                        Done: [false, false, true]
                    },
                    steps: 8
                });
            });

            it("for trees built from subtrees", () => {
                assertRestoredTreeBehavesLikeOriginal({
                    definition: `
                        root { sequence { branch [Part] branch [Part] } }
                        root [Part] { sequence { action [Step] action [Settle] } }
                    `,
                    script: { Step: [State.SUCCEEDED], Settle: [undefined, State.SUCCEEDED] },
                    steps: 6
                });
            });
        });

        describe("will keep the random choices and counters of", () => {
            it("a repeat node with a fixed number of iterations", () => {
                const definition = "root { repeat [4] { action [Work] } }";
                const calls: string[] = [];
                const agent = { Work: () => (calls.push("Work"), State.SUCCEEDED) };

                const original = new BehaviourTree(definition, agent);
                original.step();
                original.step();
                const snapshot = JSON.parse(JSON.stringify(original.snapshot()));

                const restored = new BehaviourTree(definition, agent);
                restored.restore(snapshot);

                calls.length = 0;
                stepUntil(restored, State.SUCCEEDED);

                // Two of the four iterations were made before the snapshot was taken.
                assert.strictEqual(calls.length, 2);
            });

            it("a repeat node with a random number of iterations, without making the random choice again", () => {
                const definition = "root { repeat [2, 6] { action [Work] } }";
                const calls: string[] = [];
                const agent = { Work: () => (calls.push("Work"), State.SUCCEEDED) };

                // A random value of 0.9 gives the maximum of 6 iterations.
                const original = new BehaviourTree(definition, agent, { random: () => 0.9 });
                original.step();
                const snapshot = JSON.parse(JSON.stringify(original.snapshot()));

                // The tree that this is restored to would pick the minimum of 2 iterations if it picked again.
                let randomCalls = 0;
                const restored = new BehaviourTree(definition, agent, { random: () => (randomCalls++, 0) });
                restored.restore(snapshot);

                calls.length = 0;
                stepUntil(restored, State.SUCCEEDED);

                assert.strictEqual(calls.length, 5);
                assert.strictEqual(randomCalls, 0);
            });

            it("a repeat node with a number of iterations that was not limited", () => {
                const definition = "root { repeat { action [Work] } }";
                const agent = { Work: () => State.SUCCEEDED };

                const original = new BehaviourTree(definition, agent);
                original.step();

                const restored = new BehaviourTree(definition, agent);
                restored.restore(JSON.parse(JSON.stringify(original.snapshot())));
                restored.step();

                assert.strictEqual(restored.getState(), State.RUNNING);
                assert.strictEqual(findNode(restored, "repeat").state, State.RUNNING);
            });

            it("a retry node with a fixed number of attempts", () => {
                const definition = "root { retry [4] { action [Work] } }";
                const calls: string[] = [];
                const agent = { Work: () => (calls.push("Work"), State.FAILED) };

                const original = new BehaviourTree(definition, agent);
                original.step();
                original.step();
                const snapshot = JSON.parse(JSON.stringify(original.snapshot()));

                const restored = new BehaviourTree(definition, agent);
                restored.restore(snapshot);

                calls.length = 0;
                stepUntil(restored, State.FAILED);

                // Two of the four attempts were made before the snapshot was taken.
                assert.strictEqual(calls.length, 2);
            });

            it("a retry node with a random number of attempts, without making the random choice again", () => {
                const definition = "root { retry [2, 6] { action [Work] } }";
                const calls: string[] = [];
                const agent = { Work: () => (calls.push("Work"), State.FAILED) };

                // A random value of 0.9 gives the maximum of 6 attempts.
                const original = new BehaviourTree(definition, agent, { random: () => 0.9 });
                original.step();
                const snapshot = JSON.parse(JSON.stringify(original.snapshot()));

                // The tree that this is restored to would pick the minimum of 2 attempts if it picked again.
                let randomCalls = 0;
                const restored = new BehaviourTree(definition, agent, { random: () => (randomCalls++, 0) });
                restored.restore(snapshot);

                calls.length = 0;
                stepUntil(restored, State.FAILED);

                assert.strictEqual(calls.length, 5);
                assert.strictEqual(randomCalls, 0);
            });

            it("a lotto node, without drawing again", () => {
                const definition = "root { lotto { action [A] action [B] action [C] } }";
                const calls: string[] = [];
                const createAgent = () => ({
                    A: () => (calls.push("A"), undefined),
                    B: () => (calls.push("B"), undefined),
                    C: () => (calls.push("C"), undefined)
                });

                // A random value close to 1 draws the last child.
                const original = new BehaviourTree(definition, createAgent(), { random: () => 0.99 });
                original.step();
                assert.deepEqual(calls, ["C"]);
                const snapshot = JSON.parse(JSON.stringify(original.snapshot()));

                // The tree that this is restored to would draw the first child if it drew again.
                let randomCalls = 0;
                const restored = new BehaviourTree(definition, createAgent(), { random: () => (randomCalls++, 0) });
                restored.restore(snapshot);

                calls.length = 0;
                restored.step();
                restored.step();

                assert.deepEqual(calls, ["C", "C"]);
                assert.strictEqual(randomCalls, 0);
                assert.strictEqual(findNode(restored, "lotto").state, State.RUNNING);
            });

            it("a lotto node that has not been updated yet, which draws when it is first updated", () => {
                const definition = "root { lotto { action [A] action [B] } }";
                const calls: string[] = [];
                const createAgent = () => ({
                    A: () => (calls.push("A"), undefined),
                    B: () => (calls.push("B"), undefined)
                });

                const snapshot = JSON.parse(JSON.stringify(new BehaviourTree(definition, createAgent()).snapshot()));

                const restored = new BehaviourTree(definition, createAgent(), { random: () => 0.99 });
                restored.restore(snapshot);
                restored.step();

                assert.deepEqual(calls, ["B"]);
            });

            it("weighted lotto, repeat and retry nodes nested in a larger tree", () => {
                assertRestoredTreeBehavesLikeOriginal({
                    definition: `root {
                        repeat [2, 4] {
                            sequence {
                                lotto [1, 3] {
                                    action [Heads]
                                    action [Tails]
                                }
                                retry [1, 3] {
                                    action [Flaky]
                                }
                            }
                        }
                    }`,
                    script: {
                        Heads: [undefined, State.SUCCEEDED],
                        Tails: [State.SUCCEEDED],
                        Flaky: [State.FAILED, undefined, State.FAILED, State.SUCCEEDED]
                    },
                    random: [0.9, 0.1, 0.6, 0.3, 0.8, 0.45, 0.99, 0.0],
                    steps: 24
                });
            });

            it("a finished tree, whose next run makes the random choices again", () => {
                const scenario: Scenario = {
                    definition: "root { sequence { lotto { action [A] action [B] } repeat [1, 3] { action [Work] } } }",
                    script: { A: [State.SUCCEEDED], B: [State.SUCCEEDED], Work: [State.SUCCEEDED] },
                    random: [0.9, 0.1, 0.5, 0.2, 0.7],
                    steps: 12
                };

                assertRestoredTreeBehavesLikeOriginal(scenario);
            });
        });

        describe("will make a wait node wait only for the time that remained when the snapshot was taken", () => {
            let clock: SinonFakeTimers;

            beforeEach(() => {
                clock = sinon.useFakeTimers();
            });

            afterEach(() => clock.restore());

            const HOUR = 60 * 60 * 1000;

            describe("when using the clock", () => {
                it("(restored to a new tree)", () => {
                    const definition = "root { wait [1000] }";

                    const original = new BehaviourTree(definition, {});
                    original.step();
                    clock.tick(400);
                    const snapshot = JSON.parse(JSON.stringify(original.snapshot()));

                    // A long time passes before the tree is restored, which should not count towards the wait.
                    clock.tick(HOUR);
                    const restored = new BehaviourTree(definition, {});
                    restored.restore(snapshot);

                    restored.step();
                    assert.strictEqual(restored.getState(), State.RUNNING);

                    clock.tick(599);
                    restored.step();
                    assert.strictEqual(restored.getState(), State.RUNNING);

                    clock.tick(1);
                    restored.step();
                    assert.strictEqual(restored.getState(), State.SUCCEEDED);
                });

                it("(restored to the tree that the snapshot was taken from)", () => {
                    const tree = new BehaviourTree("root { wait [1000] }", {});
                    tree.step();
                    clock.tick(400);
                    const snapshot = tree.snapshot();

                    clock.tick(HOUR);
                    tree.restore(snapshot);

                    tree.step();
                    assert.strictEqual(tree.getState(), State.RUNNING);

                    clock.tick(600);
                    tree.step();
                    assert.strictEqual(tree.getState(), State.SUCCEEDED);
                });

                it("(counting the time between the last step and the snapshot, as the tree would have)", () => {
                    const definition = "root { wait [1000] }";

                    const original = new BehaviourTree(definition, {});
                    original.step();
                    clock.tick(900);
                    const snapshot = JSON.parse(JSON.stringify(original.snapshot()));

                    clock.tick(HOUR);
                    const restored = new BehaviourTree(definition, {});
                    restored.restore(snapshot);

                    restored.step();
                    assert.strictEqual(restored.getState(), State.RUNNING);

                    clock.tick(100);
                    restored.step();
                    assert.strictEqual(restored.getState(), State.SUCCEEDED);
                });

                it("(restored more than once)", () => {
                    const tree = new BehaviourTree("root { wait [1000] }", {});
                    tree.step();
                    clock.tick(400);
                    const snapshot = tree.snapshot();

                    clock.tick(600);
                    tree.step();
                    assert.strictEqual(tree.getState(), State.SUCCEEDED);

                    for (let restore = 0; restore < 2; restore++) {
                        clock.tick(HOUR);
                        tree.restore(snapshot);

                        clock.tick(599);
                        tree.step();
                        assert.strictEqual(tree.getState(), State.RUNNING);

                        clock.tick(1);
                        tree.step();
                        assert.strictEqual(tree.getState(), State.SUCCEEDED);
                    }
                });

                it("(for a wait node with a random duration, without picking the duration again)", () => {
                    const definition = "root { wait [1000, 5000] }";

                    // A random value of 0.9 gives a duration of 4600ms.
                    const original = new BehaviourTree(definition, {}, { random: () => 0.9 });
                    original.step();
                    clock.tick(2000);
                    const snapshot = JSON.parse(JSON.stringify(original.snapshot()));

                    // The tree that this is restored to would pick a duration of 1000ms if it picked again.
                    let randomCalls = 0;
                    clock.tick(HOUR);
                    const restored = new BehaviourTree(definition, {}, { random: () => (randomCalls++, 0) });
                    restored.restore(snapshot);

                    clock.tick(2599);
                    restored.step();
                    assert.strictEqual(restored.getState(), State.RUNNING);

                    clock.tick(1);
                    restored.step();
                    assert.strictEqual(restored.getState(), State.SUCCEEDED);
                    assert.strictEqual(randomCalls, 0);
                });
            });

            describe("when using the 'getDeltaTime' option", () => {
                it("(restored to a new tree)", () => {
                    const definition = "root { wait [1000] }";
                    const options = { getDeltaTime: () => 0.25 };

                    const original = new BehaviourTree(definition, {}, options);
                    original.step();
                    original.step();
                    const snapshot = JSON.parse(JSON.stringify(original.snapshot()));

                    // The time that passes on the clock should have no effect on a tree that is told how much time has passed.
                    clock.tick(HOUR);
                    const restored = new BehaviourTree(definition, {}, options);
                    restored.restore(snapshot);

                    // 500ms were waited before the snapshot was taken, so 2 more steps of 250ms are needed.
                    restored.step();
                    assert.strictEqual(restored.getState(), State.RUNNING);

                    restored.step();
                    assert.strictEqual(restored.getState(), State.SUCCEEDED);
                });

                it("(restored to the tree that the snapshot was taken from)", () => {
                    const tree = new BehaviourTree("root { wait [1000] }", {}, { getDeltaTime: () => 0.25 });
                    tree.step();
                    tree.step();
                    const snapshot = tree.snapshot();

                    tree.step();
                    tree.step();
                    assert.strictEqual(tree.getState(), State.SUCCEEDED);

                    clock.tick(HOUR);
                    tree.restore(snapshot);
                    assert.strictEqual(tree.getState(), State.RUNNING);

                    tree.step();
                    assert.strictEqual(tree.getState(), State.RUNNING);

                    tree.step();
                    assert.strictEqual(tree.getState(), State.SUCCEEDED);
                });

                it("(for a wait node with a random duration, without picking the duration again)", () => {
                    const definition = "root { wait [1000, 5000] }";

                    // A random value of 0.9 gives a duration of 4600ms.
                    const original = new BehaviourTree(definition, {}, { random: () => 0.9, getDeltaTime: () => 1 });
                    original.step();
                    const snapshot = JSON.parse(JSON.stringify(original.snapshot()));

                    let randomCalls = 0;
                    const restored = new BehaviourTree(
                        definition,
                        {},
                        { random: () => (randomCalls++, 0), getDeltaTime: () => 1 }
                    );
                    restored.restore(snapshot);

                    // 1000ms were waited before the snapshot was taken, so 4 more steps of 1000ms are not enough.
                    for (let step = 0; step < 3; step++) {
                        restored.step();
                        assert.strictEqual(restored.getState(), State.RUNNING);
                    }

                    restored.step();
                    assert.strictEqual(restored.getState(), State.SUCCEEDED);
                    assert.strictEqual(randomCalls, 0);
                });

                it("(in the same way as the original tree for a wait node nested in a larger tree)", () => {
                    assertRestoredTreeBehavesLikeOriginal(
                        {
                            definition: "root { repeat [2] { sequence { action [Work] wait [900] action [Done] } } }",
                            script: { Work: [State.SUCCEEDED], Done: [State.SUCCEEDED] },
                            deltaTime: 0.4,
                            steps: 12
                        },
                        true
                    );
                });
            });

            it("in the same way as the original tree for a wait node nested in a larger tree when using the clock", () => {
                assertRestoredTreeBehavesLikeOriginal(
                    {
                        definition: `root {
                        repeat [2] {
                            sequence {
                                action [Work]
                                parallel { wait [900] wait [1500, 2500] }
                                action [Done]
                            }
                        }
                    }`,
                        script: { Work: [State.SUCCEEDED], Done: [State.SUCCEEDED] },
                        random: [0.2, 0.8],
                        tickMs: 400,
                        steps: 14
                    },
                    false,
                    clock
                );
            });

            it("whichever way the time was kept by the tree that the snapshot was taken from", () => {
                const definition = "root { wait [1000] }";

                // Take a snapshot from a tree using the clock, and restore it to a tree using a delta time.
                const clockTree = new BehaviourTree(definition, {});
                clockTree.step();
                clock.tick(500);
                const deltaTimeTree = new BehaviourTree(definition, {}, { getDeltaTime: () => 0.25 });
                deltaTimeTree.restore(clockTree.snapshot());

                deltaTimeTree.step();
                assert.strictEqual(deltaTimeTree.getState(), State.RUNNING);
                deltaTimeTree.step();
                assert.strictEqual(deltaTimeTree.getState(), State.SUCCEEDED);

                // Take a snapshot from a tree using a delta time, and restore it to a tree using the clock.
                const otherDeltaTimeTree = new BehaviourTree(definition, {}, { getDeltaTime: () => 0.25 });
                otherDeltaTimeTree.step();
                otherDeltaTimeTree.step();
                const otherClockTree = new BehaviourTree(definition, {});
                otherClockTree.restore(otherDeltaTimeTree.snapshot());

                clock.tick(499);
                otherClockTree.step();
                assert.strictEqual(otherClockTree.getState(), State.RUNNING);
                clock.tick(1);
                otherClockTree.step();
                assert.strictEqual(otherClockTree.getState(), State.SUCCEEDED);
            });

            it("and leave a wait node without a duration waiting until it is aborted", () => {
                const definition = "root { race { wait action [Done] } }";
                const agent = { Done: () => (clock.now > 10 * HOUR ? State.SUCCEEDED : undefined) };

                const original = new BehaviourTree(definition, agent);
                original.step();
                clock.tick(HOUR);
                const snapshot = JSON.parse(JSON.stringify(original.snapshot()));

                const restored = new BehaviourTree(definition, agent);
                restored.restore(snapshot);
                restored.step();

                assert.strictEqual(findNode(restored, "wait").state, State.RUNNING);

                clock.tick(10 * HOUR);
                restored.step();

                assert.strictEqual(restored.getState(), State.SUCCEEDED);
                assert.strictEqual(findNode(restored, "wait").state, State.READY);
            });

            it("and leave a wait node that has finished waiting finished", () => {
                const definition = "root { sequence { wait [100] action [Next] } }";
                const agent = { Next: () => undefined };

                const original = new BehaviourTree(definition, agent);
                original.step();
                clock.tick(100);
                original.step();
                assert.strictEqual(findNode(original, "wait").state, State.SUCCEEDED);
                const snapshot = JSON.parse(JSON.stringify(original.snapshot()));

                clock.tick(HOUR);
                const restored = new BehaviourTree(definition, agent);
                restored.restore(snapshot);
                restored.step();

                assert.strictEqual(findNode(restored, "wait").state, State.SUCCEEDED);
                assert.strictEqual(findNode(restored, "action", "Next").state, State.RUNNING);
            });
        });

        describe("will throw an error and leave the tree as it was if the snapshot", () => {
            const definition = `root {
                sequence {
                    lotto { action [A] action [B] }
                    repeat [3] { action [A] }
                    retry [3] { action [A] }
                    wait [1000]
                }
            }`;
            const agent = { A: () => State.SUCCEEDED, B: () => State.SUCCEEDED };

            const createValidSnapshot = (): any => {
                const tree = new BehaviourTree(definition, agent);
                tree.step();
                return JSON.parse(JSON.stringify(tree.snapshot()));
            };

            const getNode = (snapshot: any, ...path: number[]) =>
                path.reduce((node, index) => node.children[index], snapshot.root);

            const invalidSnapshots: [string, (snapshot: any) => any, string][] = [
                ["is not an object", () => "snapshot", "invalid snapshot: expected a snapshot object"],
                ["is null", () => null, "invalid snapshot: expected a snapshot object"],
                ["is undefined", () => undefined, "invalid snapshot: expected a snapshot object"],
                ["is a number", () => 42, "invalid snapshot: expected a snapshot object"],
                ["is a boolean", () => true, "invalid snapshot: expected a snapshot object"],
                ["is an array", () => [], "invalid snapshot: expected a snapshot object"],
                ["is an array of snapshots", (snapshot) => [snapshot], "invalid snapshot: expected a snapshot object"],
                ["is an empty object", () => ({}), "invalid snapshot: unsupported snapshot version 'undefined'"],
                [
                    "is an object without the fields of a snapshot",
                    () => ({ foo: "bar" }),
                    "invalid snapshot: unsupported snapshot version 'undefined'"
                ],
                [
                    "is the snapshot of a node rather than of a tree",
                    (snapshot) => snapshot.root,
                    "invalid snapshot: unsupported snapshot version 'undefined'"
                ],
                [
                    "has an unsupported version",
                    (snapshot) => ({ ...snapshot, version: 2 }),
                    "invalid snapshot: unsupported snapshot version '2'"
                ],
                [
                    "has no version",
                    ({ root }) => ({ root }),
                    "invalid snapshot: unsupported snapshot version 'undefined'"
                ],
                [
                    "has no definition",
                    ({ version, root }) => ({ version, root }),
                    "invalid snapshot: expected the snapshot to have a definition"
                ],
                [
                    "has a definition that is not a string",
                    (snapshot) => ({ ...snapshot, definition: 42 }),
                    "invalid snapshot: expected the snapshot to have a definition"
                ],
                [
                    "has a definition that is not the definition of the tree",
                    (snapshot) => ({ ...snapshot, definition: "not-the-definition" }),
                    "invalid snapshot: the snapshot does not match the tree's definition"
                ],
                [
                    "has no root",
                    ({ version, definition }) => ({ version, definition }),
                    "invalid snapshot: expected a snapshot object for root node"
                ],
                [
                    "has a node without an id",
                    (snapshot) => {
                        delete getNode(snapshot, 0, 1).id;
                        return snapshot;
                    },
                    "invalid snapshot: unexpected id 'undefined' for repeat node"
                ],
                [
                    "has a node of the wrong type",
                    (snapshot) => {
                        getNode(snapshot, 0, 3).type = "action";
                        return snapshot;
                    },
                    "invalid snapshot: expected a snapshot of a wait node but found 'action'"
                ],
                [
                    "has a node with an unknown state",
                    (snapshot) => {
                        getNode(snapshot, 0, 1).state = "mistreevous.unknown";
                        return snapshot;
                    },
                    "invalid snapshot: unexpected state 'mistreevous.unknown' for repeat node"
                ],
                [
                    "has too few children for a node",
                    (snapshot) => {
                        getNode(snapshot, 0).children.pop();
                        return snapshot;
                    },
                    "invalid snapshot: expected the snapshot of a sequence node to have 4 children"
                ],
                [
                    "has too many children for a node",
                    (snapshot) => {
                        getNode(snapshot, 0, 1).children.push(getNode(snapshot, 0, 1, 0));
                        return snapshot;
                    },
                    "invalid snapshot: expected the snapshot of a repeat node to have 1 child"
                ],
                [
                    "has a lotto node with a selected child index that is out of range",
                    (snapshot) => {
                        getNode(snapshot, 0, 0).selectedChildIndex = 2;
                        return snapshot;
                    },
                    "invalid snapshot: unexpected selected child index '2' for lotto node"
                ],
                [
                    "has a lotto node that is running but has no selected child",
                    (snapshot) => {
                        getNode(snapshot, 0, 0).state = State.RUNNING;
                        getNode(snapshot, 0, 0).selectedChildIndex = null;
                        return snapshot;
                    },
                    "invalid snapshot: unexpected selected child index 'null' for lotto node"
                ],
                [
                    "has a repeat node with an invalid target iteration count",
                    (snapshot) => {
                        getNode(snapshot, 0, 1).targetIterationCount = "3";
                        return snapshot;
                    },
                    "invalid snapshot: unexpected target iteration count '3' for repeat node"
                ],
                [
                    "has a repeat node with an invalid current iteration count",
                    (snapshot) => {
                        getNode(snapshot, 0, 1).currentIterationCount = -1;
                        return snapshot;
                    },
                    "invalid snapshot: unexpected current iteration count '-1' for repeat node"
                ],
                [
                    "has a retry node with an invalid target attempt count",
                    (snapshot) => {
                        getNode(snapshot, 0, 2).targetAttemptCount = 1.5;
                        return snapshot;
                    },
                    "invalid snapshot: unexpected target attempt count '1.5' for retry node"
                ],
                [
                    "has a retry node with an invalid current attempt count",
                    (snapshot) => {
                        delete getNode(snapshot, 0, 2).currentAttemptCount;
                        return snapshot;
                    },
                    "invalid snapshot: unexpected current attempt count 'undefined' for retry node"
                ],
                [
                    "has a wait node with an invalid total duration",
                    (snapshot) => {
                        getNode(snapshot, 0, 3).totalDuration = -5;
                        return snapshot;
                    },
                    "invalid snapshot: unexpected total duration '-5' for wait node"
                ],
                [
                    "has a wait node with an invalid waited duration",
                    (snapshot) => {
                        getNode(snapshot, 0, 3).waitedDuration = null;
                        return snapshot;
                    },
                    "invalid snapshot: unexpected waited duration 'null' for wait node"
                ]
            ];

            for (const [description, corrupt, message] of invalidSnapshots) {
                it(description, () => {
                    const changes: string[] = [];
                    const tree = new BehaviourTree(definition, agent, {
                        onNodeStateChange: (change) => changes.push(change.type)
                    });
                    tree.step();

                    const detailsBefore = tree.getTreeNodeDetails();
                    const snapshotBefore = tree.snapshot();
                    changes.length = 0;

                    assert.throws(() => tree.restore(corrupt(createValidSnapshot())), Error, message);

                    assert.deepEqual(tree.getTreeNodeDetails(), detailsBefore);
                    assert.deepEqual(tree.snapshot(), snapshotBefore);
                    assert.deepEqual(changes, []);
                });
            }

            it("was taken from a tree with a different structure", () => {
                const other = new BehaviourTree("root { sequence { action [A] action [B] } }", agent);
                const tree = new BehaviourTree(definition, agent);

                assert.throws(
                    () => tree.restore(other.snapshot()),
                    Error,
                    "invalid snapshot: the snapshot does not match the tree's definition"
                );
            });
        });

        describe("will only restore a snapshot that was taken from a tree with the same definition", () => {
            const agent = {
                A: () => State.RUNNING,
                B: () => State.RUNNING,
                C: () => State.RUNNING,
                Allowed: () => true
            };

            const definition = `root {
                sequence {
                    action [A, 1, "two"]
                    repeat [2, 4] { action [B] }
                    lotto [1, 3] { action [A] action [B] }
                    wait [100]
                }
            }`;

            const createSteppedTree = (treeDefinition: string | RootNodeDefinition | RootNodeDefinition[]) => {
                const tree = new BehaviourTree(treeDefinition, agent);
                tree.step();
                return tree;
            };

            const assertRestores = (from: BehaviourTree, to: BehaviourTree) => {
                const snapshot = JSON.parse(JSON.stringify(from.snapshot()));

                to.restore(snapshot);

                assert.deepEqual(to.getTreeNodeDetails(), from.getTreeNodeDetails());
            };

            const differentDefinitions: [string, string][] = [
                ["the name of an action function", definition.replace("action [A, 1", "action [C, 1")],
                ["the arguments of an action", definition.replace('"two"', '"three"')],
                ["the number of arguments of an action", definition.replace('[A, 1, "two"]', "[A, 1]")],
                ["a wait duration", definition.replace("wait [100]", "wait [200]")],
                ["the iterations of a repeat node", definition.replace("repeat [2, 4]", "repeat [2, 5]")],
                ["the weights of a lotto node", definition.replace("lotto [1, 3]", "lotto [3, 1]")],
                ["a guard", definition.replace("wait [100]", "wait [100] while(Allowed)")],
                ["a callback", definition.replace("wait [100]", "wait [100] entry(A)")],
                ["the type of a node", definition.replace("sequence {", "selector {")],
                ["a node that was added", definition.replace("wait [100]", "wait [100] action [C]")],
                ["a subtree that is not used", definition + " root [Unused] { action [C] }"]
            ];

            for (const [description, otherDefinition] of differentDefinitions) {
                it(`and throws an error and leaves the tree as it was if it is different in ${description}`, () => {
                    const changes: string[] = [];
                    const tree = new BehaviourTree(definition, agent, {
                        onNodeStateChange: (change) => changes.push(change.type)
                    });
                    tree.step();
                    tree.step();

                    const detailsBefore = tree.getTreeNodeDetails();
                    const snapshotBefore = tree.snapshot();
                    changes.length = 0;

                    const otherTree = createSteppedTree(otherDefinition);

                    assert.throws(
                        () => tree.restore(otherTree.snapshot()),
                        Error,
                        "the snapshot does not match the tree's definition"
                    );
                    assert.throws(
                        () => tree.restore(JSON.parse(JSON.stringify(otherTree.snapshot()))),
                        Error,
                        "the snapshot does not match the tree's definition"
                    );

                    assert.deepEqual(tree.getTreeNodeDetails(), detailsBefore);
                    assert.deepEqual(tree.snapshot(), snapshotBefore);
                    assert.deepEqual(changes, []);
                });
            }

            it("and does not accept a snapshot of an unrelated definition even when it has the same structure", () => {
                const first = createSteppedTree("root { action [A] }");
                const second = createSteppedTree("root { action [B] }");

                assert.throws(() => first.restore(second.snapshot()), Error, "does not match the tree's definition");
            });

            it("and accepts a snapshot from another tree built from the same definition", () => {
                assertRestores(createSteppedTree(definition), new BehaviourTree(definition, agent));
            });

            it("and accepts a snapshot from a tree with an agent and options that are different", () => {
                const from = createSteppedTree(definition);
                const to = new BehaviourTree(
                    definition,
                    { ...agent, Other: () => State.SUCCEEDED },
                    { random: () => 0 }
                );

                assertRestores(from, to);
            });

            it("and accepts one from the same MDSL definition with different whitespace and comments", () => {
                const reformatted = `root { /* start */ sequence { action [A,1,"two"]
                    repeat [2,4] { action [B] }   lotto [1,3] { action [A]
                    action [B] } wait [100] } }`;

                assertRestores(createSteppedTree(definition), new BehaviourTree(reformatted, agent));
            });

            describe("and counts an MDSL definition and its equivalent JSON definition as the same", () => {
                const mdsl = `root {
                    sequence while(Allowed) entry(A, 1) {
                        action [A, 1, "two"]
                        condition [B]
                        wait [100, 200]
                        repeat [3] { action [B] }
                        branch [Sub]
                    }
                }
                root [Sub] { selector { action [C] flip { action [B] } } }`;

                // The output of the MDSL converter, which has default values like empty arguments written out.
                const converted = convertMDSLToJSON(mdsl);

                // A JSON definition written by hand, with keys in a different order and defaults left out.
                const handWritten: RootNodeDefinition[] = [
                    {
                        child: {
                            children: [
                                { call: "A", type: "action", args: [1, "two"] },
                                { type: "condition", call: "B" },
                                { duration: [100, 200], type: "wait" },
                                { iterations: 3, child: { type: "action", call: "B" }, type: "repeat" },
                                { ref: "Sub", type: "branch" }
                            ],
                            entry: { args: [1], call: "A" },
                            while: { call: "Allowed", succeedOnAbort: false },
                            type: "sequence"
                        },
                        type: "root"
                    },
                    {
                        id: "Sub",
                        type: "root",
                        child: {
                            type: "selector",
                            children: [
                                { type: "action", call: "C", args: [] },
                                { type: "flip", child: { type: "action", call: "B" } }
                            ]
                        }
                    }
                ];

                const definitions: [string, string | RootNodeDefinition | RootNodeDefinition[]][] = [
                    ["MDSL", mdsl],
                    ["converted JSON", converted],
                    ["hand written JSON", handWritten],
                    ["hand written JSON with the sub root first", [handWritten[1], handWritten[0]]]
                ];

                for (const [fromName, from] of definitions) {
                    for (const [toName, to] of definitions) {
                        it(`(${fromName} to ${toName})`, () => {
                            assertRestores(createSteppedTree(from), new BehaviourTree(to, agent));
                        });
                    }
                }

                it("(a single root node written as an object rather than an array)", () => {
                    const single = "root { sequence { action [A] action [B] } }";
                    const [root] = convertMDSLToJSON(single);

                    assertRestores(createSteppedTree(single), new BehaviourTree(root, agent));
                    assertRestores(createSteppedTree(root), new BehaviourTree(single, agent));
                });

                it("(unless the JSON definition really is different)", () => {
                    const different = JSON.parse(JSON.stringify(converted));
                    different[0].child.children[1].call = "C";

                    const from = createSteppedTree(mdsl);
                    const to = new BehaviourTree(different, agent);

                    assert.throws(() => to.restore(from.snapshot()), Error, "does not match the tree's definition");
                });
            });

            it("and is not affected by the definition object being changed after the tree was built", () => {
                const json = JSON.parse(JSON.stringify(convertMDSLToJSON(definition)));
                const tree = createSteppedTree(json);
                const snapshot = tree.snapshot();

                json[0].child.children[0].call = "C";

                assert.doesNotThrow(() => tree.restore(snapshot));
                assert.deepEqual(tree.snapshot(), snapshot);
                assert.doesNotThrow(() => new BehaviourTree(definition, agent).restore(snapshot));
            });

            it("and records the definition in a snapshot that is the same for every tree built from it", () => {
                const first = createSteppedTree(definition).snapshot();
                const second = new BehaviourTree(definition, agent).snapshot();
                const other = createSteppedTree("root { action [A] }").snapshot();

                assert.strictEqual(typeof first.definition, "string");
                assert.strictEqual(first.definition, second.definition);
                assert.notStrictEqual(first.definition, other.definition);
            });
        });

        describe("will not call the action function again when a snapshot is taken of an action that has finished", () => {
            it("with a promise", async () => {
                const calls: string[] = [];
                const agent = { Work: () => (calls.push("Work"), Promise.resolve(State.SUCCEEDED)) };
                const tree = new BehaviourTree("root { sequence { action [Work] action [Next] } }", {
                    ...agent,
                    Next: () => undefined
                });

                tree.step();
                await Promise.resolve();
                tree.step();
                assert.strictEqual(findNode(tree, "action", "Work").state, State.SUCCEEDED);

                const restored = new BehaviourTree("root { sequence { action [Work] action [Next] } }", {
                    ...agent,
                    Next: () => undefined
                });
                restored.restore(JSON.parse(JSON.stringify(tree.snapshot())));
                restored.step();

                assert.deepEqual(calls, ["Work"]);
                assert.strictEqual(findNode(restored, "action", "Next").state, State.RUNNING);
            });
        });

        describe("will restore an action node that was waiting for a promise as not yet started", () => {
            const definition = "root { sequence { action [Before] action [Work] action [After] } }";

            /** Creates an agent whose Work action returns a promise that is settled by the test. */
            const createAgent = () => {
                const calls: string[] = [];
                const settle: { resolve: (state: State) => void; reject: (reason: any) => void }[] = [];

                const agent = {
                    Before: () => (calls.push("Before"), State.SUCCEEDED),
                    Work: () => (
                        calls.push("Work"), new Promise<State>((resolve, reject) => settle.push({ resolve, reject }))
                    ),
                    After: () => (calls.push("After"), undefined)
                };

                return { agent, calls, settle };
            };

            const copy = (snapshot: BehaviourTreeSnapshot): BehaviourTreeSnapshot =>
                JSON.parse(JSON.stringify(snapshot));

            it("so that its action function is called again by the next step", () => {
                const original = createAgent();
                const tree = new BehaviourTree(definition, original.agent);
                tree.step();
                assert.deepEqual(original.calls, ["Before", "Work"]);

                const snapshot = copy(tree.snapshot());

                const restored = createAgent();
                const restoredTree = new BehaviourTree(definition, restored.agent);
                restoredTree.restore(snapshot);

                assert.strictEqual(findNode(restoredTree, "action", "Work").state, State.READY);
                assert.strictEqual(findNode(restoredTree, "action", "Before").state, State.SUCCEEDED);
                assert.strictEqual(findNode(restoredTree, "sequence").state, State.RUNNING);
                assert.strictEqual(restoredTree.getState(), State.RUNNING);
                assert.deepEqual(restored.calls, []);

                restoredTree.step();

                // The work that was done before the promise is not done again, the work that the promise was for is started again.
                assert.deepEqual(restored.calls, ["Work"]);
                assert.strictEqual(findNode(restoredTree, "action", "Work").state, State.RUNNING);

                // The restored tree is now waiting for a new promise, and carries on when it settles like any other tree.
                restoredTree.step();
                assert.deepEqual(restored.calls, ["Work"]);

                restored.settle[0].resolve(State.SUCCEEDED);
                return Promise.resolve().then(() => {
                    restoredTree.step();

                    assert.deepEqual(restored.calls, ["Work", "After"]);
                    assert.strictEqual(findNode(restoredTree, "action", "After").state, State.RUNNING);
                });
            });

            it("whether or not the promise had settled by the time of the snapshot", async () => {
                for (const settleBeforeSnapshot of [false, true]) {
                    const original = createAgent();
                    const tree = new BehaviourTree(definition, original.agent);
                    tree.step();

                    if (settleBeforeSnapshot) {
                        original.settle[0].resolve(State.SUCCEEDED);
                        await Promise.resolve();
                    }

                    const restored = createAgent();
                    const restoredTree = new BehaviourTree(definition, restored.agent);
                    restoredTree.restore(copy(tree.snapshot()));
                    restoredTree.step();

                    assert.deepEqual(restored.calls, ["Work"], `settled before snapshot: ${settleBeforeSnapshot}`);
                }
            });

            it("whether the promise went on to be rejected by the time of the snapshot", async () => {
                const original = createAgent();
                const tree = new BehaviourTree(definition, original.agent);
                tree.step();
                original.settle[0].reject("failure");
                await Promise.resolve();

                const restored = createAgent();
                const restoredTree = new BehaviourTree(definition, restored.agent);
                restoredTree.restore(copy(tree.snapshot()));

                assert.doesNotThrow(() => restoredTree.step());
                assert.deepEqual(restored.calls, ["Work"]);
            });

            it("without changing the tree that the snapshot was taken from, which carries on with its promise", async () => {
                const original = createAgent();
                const tree = new BehaviourTree(definition, original.agent);
                tree.step();

                const detailsBefore = tree.getTreeNodeDetails();
                tree.snapshot();
                tree.snapshot();

                assert.deepEqual(tree.getTreeNodeDetails(), detailsBefore);

                tree.step();
                assert.deepEqual(original.calls, ["Before", "Work"]);

                original.settle[0].resolve(State.SUCCEEDED);
                await Promise.resolve();
                tree.step();

                assert.deepEqual(original.calls, ["Before", "Work", "After"]);
                assert.strictEqual(findNode(tree, "action", "Work").state, State.SUCCEEDED);
            });

            it("and will not use the result of the promise that the tree being restored was waiting for", async () => {
                const original = createAgent();
                const tree = new BehaviourTree(definition, original.agent);
                tree.step();

                const snapshot = copy(tree.snapshot());

                // The tree carries on and restores the snapshot of itself while it is waiting for a different promise.
                original.settle[0].resolve(State.SUCCEEDED);
                await Promise.resolve();
                tree.restore(snapshot);
                tree.step();

                assert.deepEqual(original.calls, ["Before", "Work", "Work"]);
                assert.strictEqual(findNode(tree, "action", "Work").state, State.RUNNING);
                assert.strictEqual(original.settle.length, 2);
            });

            it("which does not call 'onNodeStateChange' when the tree was new", () => {
                const original = createAgent();
                const tree = new BehaviourTree(definition, original.agent);
                tree.step();
                const snapshot = copy(tree.snapshot());

                const changes: string[] = [];
                const restoredTree = new BehaviourTree(definition, createAgent().agent, {
                    onNodeStateChange: (change) =>
                        changes.push(`${change.type}:${change.previousState}>${change.state}`)
                });
                restoredTree.restore(snapshot);

                assert.deepEqual(changes, []);
            });

            it("which means that its entry callback is called again, but not its exit callback", () => {
                const log: string[] = [];
                const agent = {
                    Work: () => (log.push("Work"), new Promise<State>(() => {})),
                    OnEntry: () => log.push("entry"),
                    OnExit: () => log.push("exit")
                };
                const tree = new BehaviourTree("root { action [Work] entry(OnEntry) exit(OnExit) }", agent);
                tree.step();

                const restoredTree = new BehaviourTree("root { action [Work] entry(OnEntry) exit(OnExit) }", agent);
                log.length = 0;
                restoredTree.restore(copy(tree.snapshot()));
                assert.deepEqual(log, []);

                restoredTree.step();
                assert.deepEqual(log, ["entry", "Work"]);
            });

            it("whatever the nodes around it are doing", () => {
                const containers: [string, string][] = [
                    ["parallel", "parallel { action [Other] action [Work] }"],
                    ["race", "race { action [Other] action [Work] }"],
                    ["all", "all { action [Other] action [Work] }"],
                    ["selector", "selector { condition [Never] action [Work] }"],
                    ["repeat", "repeat [3] { action [Work] }"],
                    ["retry", "retry [3] { action [Work] }"],
                    ["lotto", "lotto { action [Work] }"],
                    ["flip", "flip { action [Work] }"],
                    ["succeed", "succeed { action [Work] }"],
                    ["a branch", "branch [Sub]"]
                ];

                for (const [name, container] of containers) {
                    const create = () => {
                        const calls: string[] = [];
                        const agent = {
                            Other: () => (calls.push("Other"), undefined),
                            Never: () => false,
                            Work: () => (calls.push("Work"), new Promise<State>(() => {}))
                        };
                        const tree = new BehaviourTree(
                            `root { sequence { ${container} } } root [Sub] { action [Work] }`,
                            agent
                        );
                        return { tree, calls };
                    };

                    const original = create();
                    original.tree.step();
                    const snapshot = copy(original.tree.snapshot());

                    const restored = create();
                    restored.tree.restore(snapshot);
                    restored.tree.step();

                    // Everything that the original did in its first step, apart from what it only did because of a promise, is done again.
                    assert.deepEqual(restored.calls, original.calls.slice(-restored.calls.length), name);
                    assert.include(restored.calls, "Work", name);
                    assert.strictEqual(findNode(restored.tree, "action", "Work").state, State.RUNNING, name);
                    assert.strictEqual(restored.tree.getState(), State.RUNNING, name);
                }
            });

            it("but not an action that is running without a promise, which carries on running", () => {
                const agent = {
                    Before: () => State.SUCCEEDED,
                    Work: () => undefined,
                    After: () => undefined
                };
                const tree = new BehaviourTree(definition, agent);
                tree.step();

                const restoredTree = new BehaviourTree(definition, agent);
                restoredTree.restore(copy(tree.snapshot()));

                assert.strictEqual(findNode(restoredTree, "action", "Work").state, State.RUNNING);
            });

            it("and keeps the state of an action that had finished with a promise", async () => {
                const original = createAgent();
                const tree = new BehaviourTree(definition, original.agent);
                tree.step();
                original.settle[0].resolve(State.SUCCEEDED);
                await Promise.resolve();
                tree.step();

                const restored = createAgent();
                const restoredTree = new BehaviourTree(definition, restored.agent);
                restoredTree.restore(copy(tree.snapshot()));
                restoredTree.step();

                assert.deepEqual(restored.calls, ["After"]);
            });
        });

        describe("will forget about a promise that an action in the tree being restored was waiting for", () => {
            it("so that its result is not used", async () => {
                const definition = "root { action [Work] }";
                let resolve!: (state: State) => void;
                const calls: string[] = [];
                const tree = new BehaviourTree(definition, {
                    Work: () => (calls.push("Work"), new Promise<State>((r) => (resolve = r)))
                });

                const snapshot = tree.snapshot();
                tree.step();
                tree.restore(snapshot);

                // The result of the promise should not be used, as the action is back to not having started.
                resolve(State.SUCCEEDED);
                await Promise.resolve();
                tree.step();

                assert.deepEqual(calls, ["Work", "Work"]);
                assert.strictEqual(tree.getState(), State.RUNNING);
            });
        });

        describe("will leave a finished tree finished and have the next step start a new run", () => {
            it("for a tree that succeeded", () => {
                const definition = "root { sequence { action [Work] action [Next] } }";
                const calls: string[] = [];
                const agent = {
                    Work: () => (calls.push("Work"), State.SUCCEEDED),
                    Next: () => (calls.push("Next"), State.SUCCEEDED)
                };

                const original = new BehaviourTree(definition, agent);
                original.step();
                assert.strictEqual(original.getState(), State.SUCCEEDED);

                const restored = new BehaviourTree(definition, agent);
                restored.restore(JSON.parse(JSON.stringify(original.snapshot())));

                assert.strictEqual(restored.getState(), State.SUCCEEDED);
                assert.strictEqual(findNode(restored, "action", "Next").state, State.SUCCEEDED);

                calls.length = 0;
                restored.step();

                assert.deepEqual(calls, ["Work", "Next"]);
                assert.strictEqual(restored.getState(), State.SUCCEEDED);
            });

            it("for a tree that failed", () => {
                const definition = "root { sequence { action [Work] action [Next] } }";
                const calls: string[] = [];
                const agent = {
                    Work: () => (calls.push("Work"), State.FAILED),
                    Next: () => (calls.push("Next"), State.SUCCEEDED)
                };

                const original = new BehaviourTree(definition, agent);
                original.step();
                assert.strictEqual(original.getState(), State.FAILED);

                const restored = new BehaviourTree(definition, agent);
                restored.restore(JSON.parse(JSON.stringify(original.snapshot())));

                assert.strictEqual(restored.getState(), State.FAILED);

                calls.length = 0;
                restored.step();

                assert.deepEqual(calls, ["Work"]);
                assert.strictEqual(restored.getState(), State.FAILED);
            });
        });
    });

    describe("snapshots", () => {
        const definition = `root {
            sequence {
                lotto { action [Work] action [Other] }
                repeat [1,3] {
                    sequence {
                        wait [100,400]
                        succeed { retry [2] { action [Fail] } }
                    }
                }
                parallel { wait [500] action [Pending] }
            }
        }`;

        const createAgent = () => ({
            Work: () => State.SUCCEEDED,
            Other: () => State.SUCCEEDED,
            Fail: () => State.FAILED,
            Pending: () => new Promise<State>(() => {})
        });

        const copy = (value: unknown) => JSON.parse(JSON.stringify(value));

        for (const [name, options] of [
            ["the clock", {}],
            ["the 'getDeltaTime' option", { getDeltaTime: () => 0.05 }]
        ] as [string, BehaviourTreeOptions][]) {
            describe(`taken from a tree that uses ${name}`, () => {
                let clock: SinonFakeTimers;

                beforeEach(() => {
                    clock = sinon.useFakeTimers();
                });

                afterEach(() => clock.restore());

                it("are not changed by stepping the tree", () => {
                    const tree = new BehaviourTree(definition, createAgent(), options);

                    for (let step = 0; step < 15; step++) {
                        tree.step();
                        clock.tick(37);

                        const snapshot = tree.snapshot();
                        const before = copy(snapshot);

                        tree.step();
                        clock.tick(37);
                        tree.step();

                        assert.deepEqual(snapshot, before, `after step ${step}`);
                    }
                });

                it("are not changed by stepping a tree that they were restored to", () => {
                    const tree = new BehaviourTree(definition, createAgent(), options);

                    for (let step = 0; step < 15; step++) {
                        tree.step();
                        clock.tick(37);

                        const snapshot = tree.snapshot();
                        const before = copy(snapshot);

                        const restoredTree = new BehaviourTree(definition, createAgent(), options);
                        restoredTree.restore(snapshot);
                        restoredTree.step();
                        clock.tick(37);
                        restoredTree.step();

                        // The tree that the snapshot was taken from is restored to as well.
                        tree.restore(snapshot);
                        tree.step();

                        assert.deepEqual(snapshot, before, `after step ${step}`);
                    }
                });

                it("are equal to the snapshot that was restored, if taken straight after restoring", () => {
                    const tree = new BehaviourTree(definition, createAgent(), options);

                    for (let step = 0; step < 15; step++) {
                        tree.step();
                        clock.tick(37);

                        const snapshot = copy(tree.snapshot());

                        const restoredTree = new BehaviourTree(definition, createAgent(), options);
                        restoredTree.restore(snapshot);

                        assert.deepEqual(copy(restoredTree.snapshot()), snapshot, `after step ${step}`);
                    }
                });
            });
        }
    });
});
