import { RootNodeDefinition } from "./BehaviourTreeDefinition";

/**
 * Gets a canonical form of a value taken from a tree definition, so that definitions that mean the same thing end up identical.
 * Properties are put in a fixed order and the optional properties that MDSL always writes out are given their default values.
 * @param value The value to get the canonical form of.
 * @param key The name of the property that the value was found under.
 * @returns The canonical form of the value.
 */
function canonicalise(value: unknown, key?: string): unknown {
    if (Array.isArray(value)) {
        return value.map((item) => canonicalise(item));
    }

    if (typeof value !== "object" || value === null) {
        return value;
    }

    const properties: Record<string, unknown> = { ...value };

    // Anything that calls a function can leave out its arguments, as can a guard leave out whether it succeeds on abort.
    if (typeof properties.call === "string") {
        properties.args = properties.args ?? [];
    }

    if (key === "while" || key === "until") {
        properties.succeedOnAbort = properties.succeedOnAbort ?? false;
    }

    return Object.fromEntries(
        Object.keys(properties)
            .sort()
            .filter((name) => properties[name] !== undefined)
            .map((name) => [name, canonicalise(properties[name], name)])
    );
}

/**
 * Creates a 53-bit hash of a string (cyrb53), which is the same wherever it is calculated.
 * @param text The string to hash.
 * @returns The hash as a 14 character hexadecimal string.
 */
function hashString(text: string): string {
    let h1 = 0xdeadbeef;
    let h2 = 0x41c6ce57;

    for (let index = 0; index < text.length; index++) {
        const code = text.charCodeAt(index);
        h1 = Math.imul(h1 ^ code, 2654435761);
        h2 = Math.imul(h2 ^ code, 1597334677);
    }

    h1 = Math.imul(h1 ^ (h1 >>> 16), 2246822507) ^ Math.imul(h2 ^ (h2 >>> 13), 3266489909);
    h2 = Math.imul(h2 ^ (h2 >>> 16), 2246822507) ^ Math.imul(h1 ^ (h1 >>> 13), 3266489909);

    return (4294967296 * (2097151 & h2) + (h1 >>> 0)).toString(16).padStart(14, "0");
}

/**
 * Gets a hash that identifies a tree definition, which is the same for MDSL and the equivalent JSON.
 * The hash does not depend on the order of the root nodes or of the properties of a node, or on optional properties that are left out.
 * @param rootNodeDefinitions The root node definitions of the tree, as returned by definition validation.
 * @returns The definition hash.
 */
export function getDefinitionHash(rootNodeDefinitions: RootNodeDefinition[]): string {
    // The main root node has no id, and so comes first, which leaves the named root nodes sorted by id.
    const sorted = [...rootNodeDefinitions].sort((a, b) => {
        const [aId, bId] = [a.id ?? "", b.id ?? ""];

        return aId < bId ? -1 : aId > bId ? 1 : 0;
    });

    return hashString(JSON.stringify(canonicalise(sorted)));
}
