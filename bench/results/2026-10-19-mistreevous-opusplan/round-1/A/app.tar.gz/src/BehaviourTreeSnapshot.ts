import State, { AnyState } from "./State";

/**
 * The current version of the snapshot format.
 */
export const SNAPSHOT_VERSION = 1;

/**
 * The properties that are part of the snapshot of every node.
 */
export type BaseNodeSnapshot = {
    /**
     * The tree node identifier.
     */
    id: string;
    /**
     * The tree node type.
     */
    type: string;
    /**
     * The state of the tree node.
     */
    state: AnyState;
    /**
     * The snapshots of the child nodes of this node, defined if this node is a composite or decorator node.
     */
    children?: NodeSnapshot[];
};

/**
 * A snapshot of the execution state of a node.
 * This is plain data that can be passed through `JSON.stringify` and `JSON.parse` unchanged.
 */
export type NodeSnapshot = Omit<BaseNodeSnapshot, "type"> &
    (
        | {
              type:
                  | "root"
                  | "condition"
                  | "sequence"
                  | "selector"
                  | "parallel"
                  | "race"
                  | "all"
                  | "flip"
                  | "succeed"
                  | "fail";
          }
        | {
              type: "repeat";
              /**
               * The number of iterations to make, which is null if there is no limit.
               * If a minimum and maximum number of iterations was defined then this is the randomly picked number.
               */
              targetIterationCount: number | null;
              /**
               * The number of iterations that have been completed.
               */
              currentIterationCount: number;
          }
        | {
              type: "retry";
              /**
               * The number of attempts to make, which is null if there is no limit.
               * If a minimum and maximum number of attempts was defined then this is the randomly picked number.
               */
              targetAttemptCount: number | null;
              /**
               * The number of attempts that have been completed.
               */
              currentAttemptCount: number;
          }
        | {
              type: "action";
              /**
               * The result of the promise returned by the action function if it has settled but has not been handled yet.
               * This is null if the action function did not return a promise or if its result has been handled.
               * It is also null if the promise has not settled, as a pending promise cannot be kept. The state of the node is READY in that case,
               * so that its action function is called again when the tree is restored and stepped.
               */
              promiseResult: ActionPromiseResultSnapshot | null;
          }
        | {
              type: "wait";
              /**
               * The duration in milliseconds that the node waits for, which is null if it waits indefinitely.
               * If a minimum and maximum duration was defined then this is the randomly picked duration.
               */
              totalDuration: number | null;
              /**
               * The duration in milliseconds that the node has waited for, which is only meaningful while the node is running.
               * This includes any time that has passed since the node was last updated.
               */
              waitedDuration: number;
          }
        | {
              type: "lotto";
              /**
               * The index of the child node that was picked to be the active one, or null if none has been picked.
               */
              selectedChildIndex: number | null;
          }
    );

/**
 * The result of a promise returned by an action function that has settled.
 */
export type ActionPromiseResultSnapshot =
    | {
          /**
           * The promise resolved.
           */
          isResolved: true;
          /**
           * The state that the promise resolved with, or null if it was not a valid state.
           */
          value: State.SUCCEEDED | State.FAILED | null;
      }
    | {
          /**
           * The promise was rejected.
           */
          isResolved: false;
          /**
           * The reason that the promise was rejected, as a string.
           */
          value: string;
      };

/**
 * A snapshot of the execution state of a behaviour tree, which can be used to restore the state of a tree that was built from the same definition.
 * This is plain data that can be passed through `JSON.stringify` and `JSON.parse` unchanged.
 */
export type BehaviourTreeSnapshot = {
    /**
     * The version of the snapshot format.
     */
    version: typeof SNAPSHOT_VERSION;
    /**
     * A hash identifying the definition of the tree that the snapshot was taken from.
     * A snapshot can only be restored to a tree with the same definition, whether it was defined as MDSL or as JSON.
     */
    definitionHash: string;
    /**
     * The snapshot of the root node of the tree.
     */
    root: NodeSnapshot;
};

/**
 * The kinds of number that can be validated in a snapshot, with a description of and a check for each.
 */
const NUMBER_KINDS = {
    count: ["a non-negative integer", (value: unknown) => Number.isInteger(value) && (value as number) >= 0],
    duration: ["a non-negative number", (value: unknown) => Number.isFinite(value) && (value as number) >= 0],
    elapsed: ["a finite number", (value: unknown) => Number.isFinite(value)]
} as const;

/**
 * Checks that a snapshot property is a number of the specified kind, or null if allowed, and errors if not.
 * @param snapshot The snapshot containing the property.
 * @param property The name of the property.
 * @param type The type of the node that the snapshot is for.
 * @param kind The kind of number that the property should be.
 * @param allowNull Whether the property can be null.
 */
export function validateNumber(
    snapshot: Record<string, unknown>,
    property: string,
    type: string,
    kind: keyof typeof NUMBER_KINDS,
    allowNull: boolean
): void {
    const value = snapshot[property];
    const [description, isValid] = NUMBER_KINDS[kind];

    if ((allowNull && value === null) || isValid(value)) {
        return;
    }

    throw new Error(
        `expected ${allowNull ? "null or " : ""}${description} '${property}' for '${type}' node but got '${value}'`
    );
}

/**
 * Gets whether a value is a non-null object that is not an array.
 * @param value The value to check.
 * @returns Whether the value is a non-null object that is not an array.
 */
export function isRecord(value: unknown): value is Record<string, unknown> {
    return typeof value === "object" && value !== null && !Array.isArray(value);
}
