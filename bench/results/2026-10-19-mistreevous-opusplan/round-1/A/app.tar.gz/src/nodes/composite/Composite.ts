import Node, { NodeDetails } from "../Node";
import State from "../../State";
import { Agent } from "../../Agent";
import Attribute from "../../attributes/Attribute";
import { BehaviourTreeOptions } from "../../BehaviourTreeOptions";
import { BaseNodeSnapshot, NodeSnapshot } from "../../BehaviourTreeSnapshot";

/**
 * A composite node that wraps child nodes.
 */
export default abstract class Composite extends Node {
    /**
     * @param type The node type.
     * @param attributes The node attributes.
     * @param options The behaviour tree options.
     * @param children The child nodes.
     */
    constructor(type: string, attributes: Attribute[], options: BehaviourTreeOptions, protected children: Node[]) {
        super(type, attributes, options);
    }

    /**
     * Gets the children of this node.
     */
    getChildren = () => this.children;

    /**
     * Reset the state of the node.
     */
    reset = () => {
        // Reset the state of this node.
        this.setState(State.READY);

        // Reset the state of any child nodes.
        this.children.forEach((child) => child.reset());
    };

    /**
     * Abort the running of this node.
     * @param agent The agent.
     */
    abort = (agent: Agent) => {
        // There is nothing to do if this node is not in the running state.
        if (!this.is(State.RUNNING)) {
            return;
        }

        // Abort any child nodes.
        this.children.forEach((child) => child.abort(agent));

        // Reset the state of this node.
        this.reset();

        this.attributes.exit?.callAgentFunction(agent, false, true);
    };

    /**
     * Gets the details of this node instance.
     * @returns The details of this node instance.
     */
    public getDetails(): NodeDetails {
        return {
            ...super.getDetails(),
            children: this.children.map((child) => child.getDetails())
        };
    }

    /**
     * Gets a snapshot of the execution state of this node.
     * @returns A snapshot of the execution state of this node.
     */
    public getSnapshot(): BaseNodeSnapshot {
        return {
            ...super.getSnapshot(),
            children: this.children.map((child) => child.getSnapshot() as NodeSnapshot)
        };
    }

    /**
     * Checks that the provided value is a snapshot that can be used to restore the state of this node, and errors if not.
     * @param snapshot The value to check.
     */
    public validateSnapshot(snapshot: unknown): void {
        super.validateSnapshot(snapshot);

        const { children } = snapshot as BaseNodeSnapshot;

        if (!Array.isArray(children)) {
            throw new Error(`expected a snapshot of '${this.getType()}' node to have an array of children`);
        }

        if (children.length !== this.children.length) {
            throw new Error(
                `expected a snapshot of '${this.getType()}' node to have ${this.children.length} children but got ${
                    children.length
                }`
            );
        }

        this.children.forEach((child, index) => child.validateSnapshot(children[index]));
    }

    /**
     * Restores the execution state of this node and its children from a snapshot that has been validated.
     * @param snapshot The snapshot to restore the execution state from.
     */
    public restore(snapshot: NodeSnapshot): void {
        super.restore(snapshot);

        this.children.forEach((child, index) => child.restore(snapshot.children![index]));
    }
}
