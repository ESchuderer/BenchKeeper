import Node, { NodeDetails } from "../Node";
import State from "../../State";
import { Agent } from "../../Agent";
import Attribute from "../../attributes/Attribute";
import { BehaviourTreeOptions } from "../../BehaviourTreeOptions";
import { BaseNodeSnapshot, NodeSnapshot } from "../../BehaviourTreeSnapshot";

/**
 * A decorator node that wraps a single child node.
 */
export default abstract class Decorator extends Node {
    /**
     * @param type The node type.
     * @param attributes The node attributes.
     * @param options The behaviour tree options.
     * @param child The child node.
     */
    constructor(type: string, attributes: Attribute[], options: BehaviourTreeOptions, protected child: Node) {
        super(type, attributes, options);
    }

    /**
     * Gets the children of this node.
     */
    getChildren = () => [this.child];

    /**
     * Reset the state of the node.
     */
    reset = () => {
        // Reset the state of this node.
        this.setState(State.READY);

        // Reset the state of the child node.
        this.child.reset();
    };

    /**
     * Abort the running of this node.
     * @param agent The agent.
     */
    abort = (agent: Agent) => {
        // There is nothing to do if this node is not in the running state.
        if (!this.is(State.RUNNING)) {
            return;
        }

        // Abort the child node.
        this.child.abort(agent);

        // Reset the state of this node.
        this.reset();

        this.attributes.exit?.callAgentFunction(agent, false, true);
    };

    /**
     * Gets the details of this node instance.
     * @returns The details of this node instance.
     */
    public getDetails(): NodeDetails {
        return {
            ...super.getDetails(),
            children: [this.child.getDetails()]
        };
    }

    /**
     * Gets a snapshot of the execution state of this node.
     * @returns A snapshot of the execution state of this node.
     */
    public getSnapshot(): BaseNodeSnapshot {
        return {
            ...super.getSnapshot(),
            children: [this.child.getSnapshot() as NodeSnapshot]
        };
    }

    /**
     * Checks that the provided value is a snapshot that can be used to restore the state of this node, and errors if not.
     * @param snapshot The value to check.
     */
    public validateSnapshot(snapshot: unknown): void {
        super.validateSnapshot(snapshot);

        const { children } = snapshot as BaseNodeSnapshot;

        if (!Array.isArray(children)) {
            throw new Error(`expected a snapshot of '${this.getType()}' node to have an array of children`);
        }

        if (children.length !== 1) {
            throw new Error(
                `expected a snapshot of '${this.getType()}' node to have a single child but got ${children.length}`
            );
        }

        this.child.validateSnapshot(children[0]);
    }

    /**
     * Restores the execution state of this node and its child from a snapshot that has been validated.
     * @param snapshot The snapshot to restore the execution state from.
     */
    public restore(snapshot: NodeSnapshot): void {
        super.restore(snapshot);

        this.child.restore(snapshot.children![0]);
    }
}
