import { assert } from "chai";
import sinon, { SinonFakeTimers } from "sinon";

import { BehaviourTree, BehaviourTreeSnapshot, NodeDetails, State, convertMDSLToJSON } from "../src/index";
import { RootNodeDefinition } from "../src/BehaviourTreeDefinition";
import { BehaviourTreeOptions, NodeStateChange } from "../src/BehaviourTreeOptions";

import { findNode } from "./TestUtilities";

/** A downtime between taking a snapshot and restoring it that is long enough to expire any wait node. */
const DOWNTIME_MS = 10 * 60 * 60 * 1000;

/**
 * Passes a value through JSON serialisation, as a snapshot would be if it were persisted.
 */
const roundTrip = <T>(value: T): T => JSON.parse(JSON.stringify(value));

/**
 * Gets the states of every node in the tree, depth-first, as a list of 'type:name:state' entries.
 */
const getNodeStates = (tree: BehaviourTree): string[] => {
    const flatten = (node: NodeDetails): string[] => [
        `${node.type}:${node.name}:${node.state}`,
        ...(node.children ?? []).flatMap(flatten)
    ];

    return flatten(tree.getTreeNodeDetails());
};

/**
 * Asserts that a value is made of plain objects, arrays and primitives only.
 */
const assertIsPlainData = (value: unknown, path = "snapshot"): void => {
    if (value === null || typeof value === "string" || typeof value === "boolean") {
        return;
    }

    if (typeof value === "number") {
        assert.isTrue(Number.isFinite(value), `${path} is not a finite number`);
        return;
    }

    if (Array.isArray(value)) {
        value.forEach((item, index) => assertIsPlainData(item, `${path}[${index}]`));
        return;
    }

    assert.strictEqual(typeof value, "object", `${path} is a ${typeof value}`);
    assert.strictEqual(Object.getPrototypeOf(value), Object.prototype, `${path} is a class instance`);

    for (const [key, item] of Object.entries(value as object)) {
        assert.notStrictEqual(item, undefined, `${path}.${key} is undefined`);
        assertIsPlainData(item, `${path}.${key}`);
    }
};

/**
 * Creates a pseudo-random number function that counts its draws, so that a second one can be fast-forwarded to match.
 */
const createRandom = (drawsToSkip = 0) => {
    let seed = 12345;
    let draws = 0;

    const next = () => {
        seed = (seed * 1103515245 + 12345) % 2147483648;
        return seed / 2147483648;
    };

    for (; draws < drawsToSkip; draws++) {
        next();
    }

    return {
        random: () => {
            draws++;
            return next();
        },
        getDraws: () => draws
    };
};

/**
 * What happened during a single step of a tree that is relevant to its behaviour from there on.
 */
type StepTrace = {
    /** The agent functions that were called, in order. */
    calls: string[];
    /** The state changes that were reported, in order. */
    changes: string[];
    /** The node details after the step. */
    details: NodeDetails;
    /** The number of random numbers drawn in total by the end of the step. */
    draws: number;
    /** The error message if the step threw. */
    error?: string;
};

type Scenario = {
    /** The tree definition. */
    definition: string | RootNodeDefinition;
    /** Creates the agent, which should record every call to the log, and decide results from the context only. */
    createAgent: (log: string[], context: ScenarioContext) => any;
    /** The number of steps to take. */
    steps: number;
    /** The time that passes between each step in milliseconds. */
    stepDurationMs: number;
    /** Whether time is measured with the clock or via the 'getDeltaTime' option. */
    timing: "clock" | "delta";
};

type ScenarioContext = {
    /** The index of the step that is being taken. */
    step: number;
    /** The delta time in seconds that applies to the step that is being taken. */
    deltaTime: number;
};

/**
 * Asserts that a tree restored from a snapshot taken at any point of a scenario carries on exactly as the original did.
 * The scenario is run once to record what the original does at each step and a snapshot is taken after each of them.
 * Each snapshot is then restored into a new tree after a long downtime and the remaining steps are replayed against it.
 */
const assertRestoredTreesBehaveLikeTheOriginal = (clock: SinonFakeTimers, scenario: Scenario) => {
    const context: ScenarioContext = { step: 0, deltaTime: 0 };

    const run = (tree: BehaviourTree, log: string[], changes: string[], draws: () => number, step: number) => {
        context.step = step;
        context.deltaTime = scenario.stepDurationMs / 1000;

        if (scenario.timing === "clock") {
            clock.tick(scenario.stepDurationMs);
        }

        log.length = 0;
        changes.length = 0;

        let error: string | undefined;

        try {
            tree.step();
        } catch (exception) {
            error = (exception as Error).message;
        }

        const trace: StepTrace = {
            calls: [...log],
            changes: [...changes],
            details: tree.getTreeNodeDetails(),
            draws: draws()
        };

        if (error !== undefined) {
            trace.error = error;
        }

        return trace;
    };

    const createTree = (drawsToSkip: number) => {
        const log: string[] = [];
        const changes: string[] = [];
        const { random, getDraws } = createRandom(drawsToSkip);

        const tree = new BehaviourTree(scenario.definition, scenario.createAgent(log, context), {
            random,
            getDeltaTime: scenario.timing === "delta" ? () => context.deltaTime : undefined,
            onNodeStateChange: (change: NodeStateChange) =>
                changes.push(`${change.id}:${change.previousState}->${change.state}`)
        });

        return { tree, log, changes, getDraws };
    };

    // Run the scenario, recording each step and taking a snapshot after each of them.
    const original = createTree(0);
    const traces: StepTrace[] = [];
    const snapshots: string[] = [];

    for (let step = 1; step <= scenario.steps; step++) {
        traces.push(run(original.tree, original.log, original.changes, original.getDraws, step));
        snapshots.push(JSON.stringify(original.tree.snapshot()));
    }

    for (let snapshotIndex = 0; snapshotIndex < snapshots.length; snapshotIndex++) {
        const describeStep = `after snapshot at step ${snapshotIndex + 1}`;

        clock.tick(DOWNTIME_MS);

        const restored = createTree(traces[snapshotIndex].draws);
        restored.tree.restore(JSON.parse(snapshots[snapshotIndex]));

        assert.deepEqual(
            restored.tree.getTreeNodeDetails(),
            traces[snapshotIndex].details,
            `restored node details ${describeStep}`
        );
        assert.strictEqual(
            restored.tree.getState(),
            traces[snapshotIndex].details.state,
            `restored tree state ${describeStep}`
        );

        // Restoring must not call agent functions or report state changes.
        assert.deepEqual(restored.log, [], `agent functions called by restore ${describeStep}`);
        assert.deepEqual(restored.changes, [], `state changes reported by restore ${describeStep}`);

        for (let step = snapshotIndex + 2; step <= scenario.steps; step++) {
            const trace = run(restored.tree, restored.log, restored.changes, restored.getDraws, step);
            const expected = traces[step - 1];

            assert.deepEqual(trace.calls, expected.calls, `agent calls at step ${step} ${describeStep}`);
            assert.deepEqual(trace.changes, expected.changes, `state changes at step ${step} ${describeStep}`);
            assert.deepEqual(trace.details, expected.details, `node details at step ${step} ${describeStep}`);
            assert.strictEqual(trace.draws, expected.draws, `random draws at step ${step} ${describeStep}`);
            assert.strictEqual(trace.error, expected.error, `error at step ${step} ${describeStep}`);
        }
    }
};

/**
 * Creates an agent that records calls and gets its results from the scenario context.
 * @param results A mapping of function names to functions that get a result from the step index.
 */
const createRecordingAgent =
    (results: { [name: string]: (step: number) => any }) => (log: string[], context: ScenarioContext) =>
        Object.fromEntries(
            Object.entries(results).map(([name, getResult]) => [
                name,
                () => {
                    log.push(name);
                    return getResult(context.step);
                }
            ])
        );

describe("A behaviour tree", () => {
    let clock: SinonFakeTimers;

    beforeEach(() => {
        clock = sinon.useFakeTimers();
    });

    afterEach(() => {
        clock.restore();
    });

    describe("snapshot", () => {
        it("returns the execution state as plain data that is unchanged by JSON serialisation", () => {
            const tree = new BehaviourTree(
                "root { sequence { action [Work] selector { condition [No] action [Work] } } }",
                { Work: () => State.RUNNING, No: () => false }
            );

            assertIsPlainData(tree.snapshot());
            assert.deepEqual(roundTrip(tree.snapshot()), tree.snapshot());

            tree.step();

            assertIsPlainData(tree.snapshot());
            assert.deepEqual(roundTrip(tree.snapshot()), tree.snapshot());
        });

        it("returns a new object that does not share anything with the tree or earlier snapshots", () => {
            const tree = new BehaviourTree("root { sequence { action [Work] } }", { Work: () => State.RUNNING });

            tree.step();

            const first = tree.snapshot();
            const second = tree.snapshot();

            assert.notStrictEqual(first, second);
            assert.deepEqual(first, second);

            first.root.state = State.FAILED;
            first.root.children![0].state = State.FAILED;

            assert.deepEqual(tree.snapshot(), second);
        });

        it("does not change the tree or call any agent functions", () => {
            const log: string[] = [];
            const tree = new BehaviourTree(
                "root { sequence { action [Work] } }",
                { Work: () => (log.push("Work"), State.RUNNING) },
                { onNodeStateChange: (change) => log.push(`change:${change.state}`) }
            );

            tree.step();

            const states = getNodeStates(tree);
            const logLength = log.length;

            tree.snapshot();

            assert.deepEqual(getNodeStates(tree), states);
            assert.strictEqual(log.length, logLength);
        });

        it("contains a version and the state of every node in the tree", () => {
            const tree = new BehaviourTree("root { sequence { action [Work] condition [Yes] } }", {
                Work: () => State.RUNNING,
                Yes: () => true
            });

            tree.step();

            const snapshot = tree.snapshot();

            assert.strictEqual(snapshot.version, 1);
            assert.strictEqual(snapshot.root.type, "root");
            assert.strictEqual(snapshot.root.state, State.RUNNING);
            assert.deepEqual(
                snapshot.root.children![0].children!.map(({ type, state }) => [type, state]),
                [
                    ["action", State.RUNNING],
                    ["condition", State.READY]
                ]
            );
        });
    });

    describe("restore", () => {
        it("sets the state of every node to that of the tree that the snapshot was taken from", () => {
            const definition = "root { sequence { action [A] selector { condition [No] action [B] } action [C] } }";
            const createAgent = () => ({ A: () => State.SUCCEEDED, No: () => false, B: () => State.RUNNING });

            const original = new BehaviourTree(definition, createAgent());
            original.step();

            const restored = new BehaviourTree(definition, createAgent());
            restored.restore(roundTrip(original.snapshot()));

            assert.deepEqual(getNodeStates(restored), getNodeStates(original));
            assert.deepEqual(restored.getTreeNodeDetails(), original.getTreeNodeDetails());
            assert.strictEqual(restored.getState(), State.RUNNING);
            assert.isTrue(restored.isRunning());
        });

        it("overwrites any state that the tree already had", () => {
            const definition = "root { sequence { action [A] action [B] } }";
            const agent = { A: () => State.SUCCEEDED, B: () => State.RUNNING };
            const tree = new BehaviourTree(definition, agent);

            const beforeStepping = tree.snapshot();

            tree.step();
            assert.strictEqual(findNode(tree, "action", "B").state, State.RUNNING);

            tree.restore(beforeStepping);

            assert.deepEqual(getNodeStates(tree), getNodeStates(new BehaviourTree(definition, agent)));
            assert.strictEqual(tree.getState(), State.READY);
        });

        it("does not call agent functions or report node state changes", () => {
            const log: string[] = [];
            const definition = "root { sequence { action [Work] entry(onEntry) } }";
            const createAgent = () => ({
                Work: () => (log.push("Work"), State.RUNNING),
                onEntry: () => log.push("onEntry")
            });

            const original = new BehaviourTree(definition, createAgent());
            original.step();

            log.length = 0;

            const restored = new BehaviourTree(definition, createAgent(), {
                onNodeStateChange: (change) => log.push(`change:${change.state}`)
            });
            restored.restore(original.snapshot());

            assert.deepEqual(log, []);
        });

        it("does not call the entry callback again for nodes that were already running", () => {
            const log: string[] = [];
            const definition = "root { action [Work] entry(onEntry) }";
            const createAgent = () => ({
                Work: () => (log.push("Work"), State.RUNNING),
                onEntry: () => log.push("onEntry")
            });

            const original = new BehaviourTree(definition, createAgent());
            original.step();

            log.length = 0;

            const restored = new BehaviourTree(definition, createAgent());
            restored.restore(original.snapshot());
            restored.step();

            assert.deepEqual(log, ["Work"]);
        });

        it("does not modify the snapshot and does not keep a reference to it", () => {
            const definition = "root { sequence { action [Work] } }";
            const agent = { Work: () => State.RUNNING };

            const original = new BehaviourTree(definition, agent);
            original.step();

            const snapshot = original.snapshot();
            const copy = roundTrip(snapshot);

            const restored = new BehaviourTree(definition, agent);
            restored.restore(snapshot);

            assert.deepEqual(snapshot, copy);

            snapshot.root.state = State.FAILED;
            snapshot.root.children![0].state = State.FAILED;

            assert.deepEqual(restored.snapshot(), copy);
        });

        it("restores a finished tree as finished and the next step starts a new run", () => {
            const log: string[] = [];
            const definition = "root { sequence { action [A] action [B] } }";
            const createAgent = () => ({
                A: () => (log.push("A"), State.SUCCEEDED),
                B: () => (log.push("B"), State.SUCCEEDED)
            });

            const original = new BehaviourTree(definition, createAgent());
            original.step();
            assert.strictEqual(original.getState(), State.SUCCEEDED);

            log.length = 0;

            const restored = new BehaviourTree(definition, createAgent());
            restored.restore(roundTrip(original.snapshot()));

            assert.strictEqual(restored.getState(), State.SUCCEEDED);
            assert.deepEqual(getNodeStates(restored), getNodeStates(original));
            assert.deepEqual(log, []);

            restored.step();

            assert.deepEqual(log, ["A", "B"]);
            assert.strictEqual(restored.getState(), State.SUCCEEDED);
        });

        describe("will error and leave the tree unchanged if", () => {
            const definition = "root { sequence { action [Work] selector { condition [No] action [Work] } } }";
            const createTree = () => new BehaviourTree(definition, { Work: () => State.RUNNING, No: () => false });

            let tree: BehaviourTree;
            let snapshot: BehaviourTreeSnapshot;

            beforeEach(() => {
                const source = createTree();
                source.step();
                snapshot = roundTrip(source.snapshot());

                tree = createTree();
                tree.step();
                tree.step();
            });

            const assertRestoreErrors = (modify: (snapshot: any) => any, message: string) => {
                const before = tree.snapshot();

                assert.throws(() => tree.restore(modify(snapshot)), Error, `error restoring tree: ${message}`);
                assert.deepEqual(tree.snapshot(), before);
            };

            it("the snapshot is not an object", () => {
                assertRestoreErrors(() => "snapshot", "expected the snapshot to be an object");
                assertRestoreErrors(() => null, "expected the snapshot to be an object");
                assertRestoreErrors(() => undefined, "expected the snapshot to be an object");
            });

            it("the snapshot version is not supported", () => {
                assertRestoreErrors(
                    (s) => ({ ...s, version: 2 }),
                    "unsupported snapshot version '2', expected version '1'"
                );
                assertRestoreErrors(
                    ({ version, ...s }) => s,
                    "unsupported snapshot version 'undefined', expected version '1'"
                );
            });

            it("the snapshot has no root node", () => {
                assertRestoreErrors(({ root, ...s }) => s, "expected the snapshot to have a 'root' node object");
            });

            it("a node type does not match the type of the node in the tree", () => {
                assertRestoreErrors(
                    (s) => (s.root.children[0].children[0].type = "condition") && s,
                    "expected a snapshot of 'action' node but got 'condition'"
                );
            });

            it("a node has a different number of children to the node in the tree", () => {
                assertRestoreErrors(
                    (s) => s.root.children[0].children.pop() && s,
                    "expected a snapshot of 'sequence' node to have 2 children but got 1"
                );
                assertRestoreErrors(
                    (s) => (s.root.children = undefined) || s,
                    "expected a snapshot of 'root' node to have an array of children"
                );
            });

            it("a node state is not valid", () => {
                assertRestoreErrors(
                    (s) => (s.root.state = "running") && s,
                    "expected a valid 'state' for 'root' node but got 'running'"
                );
            });

            it("a node id is not a string", () => {
                assertRestoreErrors(
                    (s) => (s.root.children[0].id = 42) && s,
                    "expected a string 'id' for 'sequence' node but got '42'"
                );
            });

            it("a node is not an object", () => {
                assertRestoreErrors(
                    (s) => (s.root.children[0].children[1] = null) || s,
                    "expected a snapshot of 'selector' node to be an object"
                );
            });
        });
    });

    describe("snapshot and restore of the tree definition", () => {
        const definition = `root {
            sequence {
                action [Work, 1]
                repeat [2] { wait [1000] }
                branch [Sub]
            }
        }
        root [Sub] { selector { condition [No] action [Work, 2] } }`;

        const agent = {
            Work: () => State.RUNNING,
            Other: () => State.RUNNING,
            No: () => false,
            Check: () => true,
            Begin: () => {}
        };

        /**
         * Steps a tree built from the source definition, then restores a tree built from the target definition from its snapshot.
         */
        const restoreInto = (source: string | object, target: string | object) => {
            const sourceTree = new BehaviourTree(source as any, agent);
            sourceTree.step();
            const snapshot = roundTrip(sourceTree.snapshot());

            const targetTree = new BehaviourTree(target as any, agent);
            targetTree.step();
            targetTree.step();

            return { snapshot, targetTree };
        };

        const MISMATCH = "error restoring tree: the snapshot does not match the tree's definition";

        it("records the definition that the snapshot belongs to as plain data", () => {
            const tree = new BehaviourTree(definition, agent);

            assert.isString(tree.snapshot().definitionHash);
            assert.isNotEmpty(tree.snapshot().definitionHash);
            assert.strictEqual(tree.snapshot().definitionHash, roundTrip(tree.snapshot()).definitionHash);

            tree.step();

            assert.strictEqual(
                tree.snapshot().definitionHash,
                new BehaviourTree(definition, agent).snapshot().definitionHash
            );
        });

        it("identifies a definition in the same way every time, so that stored snapshots can still be restored", () => {
            assert.strictEqual(
                new BehaviourTree("root { action [Work] }", agent).snapshot().definitionHash,
                "085184e21b7b32"
            );
        });

        describe("restore will error and leave the tree unchanged for a snapshot of a tree with a definition that", () => {
            const assertMismatch = (target: string) => {
                const { snapshot, targetTree } = restoreInto(definition, target);
                const before = targetTree.snapshot();
                const detailsBefore = targetTree.getTreeNodeDetails();

                assert.throws(() => targetTree.restore(snapshot), Error, MISMATCH);
                assert.deepEqual(targetTree.snapshot(), before);
                assert.deepEqual(targetTree.getTreeNodeDetails(), detailsBefore);
            };

            it("calls a different action", () => {
                assertMismatch(definition.replace("action [Work, 1]", "action [Other, 1]"));
            });

            it("passes different action arguments", () => {
                assertMismatch(definition.replace("action [Work, 1]", "action [Work, 3]"));
            });

            it("has a different number of repeat iterations", () => {
                assertMismatch(definition.replace("repeat [2]", "repeat [3]"));
            });

            it("has a different wait duration", () => {
                assertMismatch(definition.replace("wait [1000]", "wait [2000]"));
            });

            it("has a different attribute", () => {
                assertMismatch(definition.replace("action [Work, 1]", "action [Work, 1] entry(Begin)"));
                assertMismatch(definition.replace("action [Work, 1]", "action [Work, 1] while(Check)"));
                assertMismatch(definition.replace("action [Work, 1]", "action [Work, 1] while(Check, true)"));
            });

            it("has different guard abort behaviour", () => {
                const guarded = definition.replace("action [Work, 1]", "action [Work, 1] while(Check)");

                const { snapshot, targetTree } = restoreInto(
                    guarded,
                    definition.replace("action [Work, 1]", "action [Work, 1] while(Check) then succeed")
                );
                const before = targetTree.snapshot();

                assert.throws(() => targetTree.restore(snapshot), Error, MISMATCH);
                assert.deepEqual(targetTree.snapshot(), before);
            });

            it("has a different subtree", () => {
                assertMismatch(definition.replace("action [Work, 2]", "action [Work, 4]"));
            });

            it("has a different subtree name", () => {
                assertMismatch(definition.replace(/Sub/g, "Other"));
            });

            it("has a different node of the same shape", () => {
                assertMismatch(definition.replace("selector", "sequence"));
            });

            it("has the same shape and calls but in a different order", () => {
                assertMismatch(
                    `root { sequence { repeat [2] { wait [1000] } action [Work, 1] branch [Sub] } }
                    root [Sub] { selector { condition [No] action [Work, 2] } }`
                );
            });

            it("is a completely different tree", () => {
                assertMismatch("root { action [Work] }");
            });
        });

        describe("restore accepts a snapshot of a tree with a definition that is equivalent because it", () => {
            const assertRestores = (source: string | object, target: string | object) => {
                const { snapshot, targetTree } = restoreInto(source, target);

                assert.doesNotThrow(() => targetTree.restore(snapshot));
                assert.deepEqual(targetTree.snapshot(), snapshot);
            };

            const json = convertMDSLToJSON(definition);

            it("is the same MDSL", () => {
                assertRestores(definition, definition);
            });

            it("only differs from the MDSL in whitespace and comments", () => {
                assertRestores(
                    definition,
                    `root{sequence{action[Work,1] /* the work */ repeat[2]{wait[1000]} branch[Sub]}}
                     root[Sub]{selector{condition[No]  action[Work,2]}}`
                );
            });

            it("is the JSON equivalent of the MDSL", () => {
                assertRestores(definition, json);
            });

            it("is the MDSL equivalent of the JSON", () => {
                assertRestores(json, definition);
            });

            it("is JSON that leaves out optional properties that MDSL always writes out", () => {
                const guardedMDSL = `root { sequence { action [Work] while(Check) entry(Begin) } }`;
                const guardedJSON = {
                    type: "root",
                    child: {
                        type: "sequence",
                        children: [{ type: "action", call: "Work", while: { call: "Check" }, entry: { call: "Begin" } }]
                    }
                };

                assert.deepEqual(convertMDSLToJSON(guardedMDSL), [
                    {
                        type: "root",
                        child: {
                            type: "sequence",
                            children: [
                                {
                                    type: "action",
                                    call: "Work",
                                    args: [],
                                    while: { call: "Check", args: [], succeedOnAbort: false },
                                    entry: { call: "Begin", args: [] }
                                }
                            ]
                        }
                    }
                ]);

                assertRestores(guardedMDSL, guardedJSON);
                assertRestores(guardedJSON, guardedMDSL);
            });

            it("is JSON with the properties in a different order", () => {
                const reorder = (value: any): any =>
                    Array.isArray(value)
                        ? value.map(reorder)
                        : value && typeof value === "object"
                        ? Object.fromEntries(
                              Object.entries(value)
                                  .reverse()
                                  .map(([key, item]) => [key, reorder(item)])
                          )
                        : value;

                assertRestores(json, reorder(json));
            });

            it("is JSON that is a single root node object rather than an array", () => {
                const single = { type: "root", child: { type: "action", call: "Work", args: [1] } };

                assertRestores(single, [single]);
                assertRestores([single], single);
            });

            it("is JSON with the named root nodes in a different order", () => {
                assertRestores(json, [json[1], json[0]]);
            });
        });

        describe("restore will error and leave the tree unchanged if the snapshot", () => {
            const createTree = () => new BehaviourTree(definition, agent);
            let tree: BehaviourTree;
            let snapshot: any;

            beforeEach(() => {
                const source = createTree();
                source.step();
                snapshot = roundTrip(source.snapshot());

                tree = createTree();
                tree.step();
                tree.step();
            });

            const assertRestoreErrors = (value: unknown, message: string | RegExp) => {
                const before = tree.snapshot();

                assert.throws(() => tree.restore(value as any), Error, message);
                assert.deepEqual(tree.snapshot(), before);
            };

            it("is not an object", () => {
                for (const value of [null, undefined, "snapshot", "", 42, 0, true, [], [snapshot], () => snapshot]) {
                    assertRestoreErrors(value, /error restoring tree/);
                }
            });

            it("is an object without the fields of a snapshot", () => {
                assertRestoreErrors({}, /error restoring tree/);
                assertRestoreErrors({ foo: "bar" }, /error restoring tree/);
                assertRestoreErrors({ root: snapshot.root }, /error restoring tree/);
                assertRestoreErrors({ version: snapshot.version }, /error restoring tree/);
                assertRestoreErrors({ definitionHash: snapshot.definitionHash }, /error restoring tree/);
                assertRestoreErrors(snapshot.root, /error restoring tree/);
            });

            it("has no definition", () => {
                const { definitionHash, ...withoutDefinition } = snapshot;

                assertRestoreErrors(
                    withoutDefinition,
                    /error restoring tree: expected the snapshot to have a string 'definitionHash'/
                );
            });

            it("has a definition that is not a string", () => {
                for (const value of [null, 42, {}, [], true]) {
                    assertRestoreErrors(
                        { ...snapshot, definitionHash: value },
                        /error restoring tree: expected the snapshot to have a string 'definitionHash'/
                    );
                }
            });

            it("has a definition that is not the definition of the tree", () => {
                assertRestoreErrors({ ...snapshot, definitionHash: "" }, MISMATCH);
                assertRestoreErrors({ ...snapshot, definitionHash: `${snapshot.definitionHash}0` }, MISMATCH);
            });
        });
    });

    describe("snapshot and restore will error if called while the tree is being stepped or reset", () => {
        const snapshotMessage = "cannot take a snapshot while the tree is being stepped or reset";
        const restoreMessage = "cannot restore the tree while it is being stepped or reset";

        let tree: BehaviourTree;
        let calls: (() => void)[];
        let snapshot: BehaviourTreeSnapshot;

        beforeEach(() => {
            calls = [];

            tree = new BehaviourTree(
                "root { sequence { action [Work] entry(onEntry) condition [Check] } }",
                {
                    Work: () => (calls.forEach((call) => call()), State.SUCCEEDED),
                    onEntry: () => calls.forEach((call) => call()),
                    Check: () => true
                },
                { onNodeStateChange: () => calls.forEach((call) => call()) }
            );

            snapshot = tree.snapshot();
        });

        const assertErrorsWhenCalledDuringStep = (message: string, call: () => void) => {
            const errors: string[] = [];

            calls.push(() => {
                try {
                    call();
                } catch (exception) {
                    errors.push((exception as Error).message);
                }
            });

            tree.step();

            assert.isAbove(errors.length, 0);
            errors.forEach((error) => assert.include(error, message));
        };

        it("when taking a snapshot from an agent function, callback or node state change handler", () => {
            assertErrorsWhenCalledDuringStep(snapshotMessage, () => tree.snapshot());
        });

        it("when restoring from an agent function, callback or node state change handler", () => {
            assertErrorsWhenCalledDuringStep(restoreMessage, () => tree.restore(snapshot));
        });

        it("when taking a snapshot from a node state change handler as a result of the tree being reset", () => {
            tree.step();

            assert.strictEqual(tree.getState(), State.SUCCEEDED);

            const errors: string[] = [];

            calls.push(() => {
                try {
                    tree.snapshot();
                } catch (exception) {
                    errors.push((exception as Error).message);
                }
            });

            tree.reset();

            assert.isAbove(errors.length, 0);
            errors.forEach((error) => assert.include(error, snapshotMessage));
        });

        it("but works again once the step has finished, even if it threw an error", () => {
            assert.doesNotThrow(() => tree.snapshot());

            calls.push(() => {
                throw new Error("some-error");
            });

            assert.throws(() => tree.step(), Error, "some-error");
            calls.length = 0;

            assert.doesNotThrow(() => tree.snapshot());
            assert.doesNotThrow(() => tree.restore(snapshot));
        });
    });

    describe("restore keeps the progress of", () => {
        /**
         * Creates a tree that records the calls to its agent functions, which all return the specified state.
         */
        const createTree = (definition: string, options: BehaviourTreeOptions, result: State | undefined) => {
            const calls: string[] = [];
            const call = (name: string) => () => (calls.push(name), result);
            const agent = { A: call("A"), B: call("B"), C: call("C") };

            return { tree: new BehaviourTree(definition, agent, options), calls };
        };

        /**
         * Steps the tree until it is no longer running, returning the number of steps that took.
         */
        const stepToCompletion = (tree: BehaviourTree) => {
            let steps = 0;

            do {
                tree.step();
            } while (tree.isRunning() && ++steps < 50);

            assert.isBelow(steps, 50, "the tree did not finish");

            return steps;
        };

        describe("repeat nodes", () => {
            it("with the number of iterations that have been made", () => {
                const definition = "root { repeat [3] { action [A] } }";

                const original = createTree(definition, {}, State.SUCCEEDED);
                original.tree.step();
                original.tree.step();
                assert.deepEqual(original.calls, ["A", "A"]);

                const restored = createTree(definition, {}, State.SUCCEEDED);
                restored.tree.restore(roundTrip(original.tree.snapshot()));

                restored.tree.step();
                assert.deepEqual(restored.calls, ["A"]);
                assert.strictEqual(restored.tree.getState(), State.RUNNING);

                restored.tree.step();
                assert.deepEqual(restored.calls, ["A"]);
                assert.strictEqual(restored.tree.getState(), State.SUCCEEDED);
            });

            it("with a random number of iterations that was already picked", () => {
                const definition = "root { repeat [2, 5] { action [A] } }";

                // A random value of 0.99 picks the maximum of 5 iterations.
                const original = createTree(definition, { random: () => 0.99 }, State.SUCCEEDED);
                original.tree.step();
                original.tree.step();
                original.tree.step();

                // A random value of 0 would pick the minimum of 2 iterations, but it should not be called at all.
                const random = sinon.stub().returns(0);
                const restored = createTree(definition, { random }, State.SUCCEEDED);
                restored.tree.restore(roundTrip(original.tree.snapshot()));

                stepToCompletion(restored.tree);

                assert.deepEqual(restored.calls, ["A", "A"]);
                assert.strictEqual(restored.tree.getState(), State.SUCCEEDED);
                assert.isFalse(random.called);
            });

            it("and picks a new number of iterations when a new run starts after a finished tree is restored", () => {
                const definition = "root { repeat [2, 5] { action [A] } }";

                const original = createTree(definition, { random: () => 0 }, State.SUCCEEDED);
                stepToCompletion(original.tree);
                assert.deepEqual(original.calls, ["A", "A"]);

                const restored = createTree(definition, { random: () => 0.99 }, State.SUCCEEDED);
                restored.tree.restore(roundTrip(original.tree.snapshot()));
                assert.strictEqual(restored.tree.getState(), State.SUCCEEDED);

                stepToCompletion(restored.tree);

                assert.strictEqual(restored.calls.length, 5);
            });
        });

        describe("retry nodes", () => {
            it("with the number of attempts that have been made", () => {
                const definition = "root { retry [3] { action [A] } }";

                const original = createTree(definition, {}, State.FAILED);
                original.tree.step();
                original.tree.step();
                assert.deepEqual(original.calls, ["A", "A"]);

                const restored = createTree(definition, {}, State.FAILED);
                restored.tree.restore(roundTrip(original.tree.snapshot()));

                restored.tree.step();
                assert.deepEqual(restored.calls, ["A"]);
                assert.strictEqual(restored.tree.getState(), State.RUNNING);

                restored.tree.step();
                assert.deepEqual(restored.calls, ["A"]);
                assert.strictEqual(restored.tree.getState(), State.FAILED);
            });

            it("with a random number of attempts that was already picked", () => {
                const definition = "root { retry [2, 5] { action [A] } }";

                // A random value of 0.99 picks the maximum of 5 attempts.
                const original = createTree(definition, { random: () => 0.99 }, State.FAILED);
                original.tree.step();
                original.tree.step();
                original.tree.step();

                // A random value of 0 would pick the minimum of 2 attempts, but it should not be called at all.
                const random = sinon.stub().returns(0);
                const restored = createTree(definition, { random }, State.FAILED);
                restored.tree.restore(roundTrip(original.tree.snapshot()));

                stepToCompletion(restored.tree);

                assert.deepEqual(restored.calls, ["A", "A"]);
                assert.strictEqual(restored.tree.getState(), State.FAILED);
                assert.isFalse(random.called);
            });

            it("and picks a new number of attempts when a new run starts after a finished tree is restored", () => {
                const definition = "root { retry [2, 5] { action [A] } }";

                const original = createTree(definition, { random: () => 0 }, State.FAILED);
                stepToCompletion(original.tree);
                assert.deepEqual(original.calls, ["A", "A"]);

                const restored = createTree(definition, { random: () => 0.99 }, State.FAILED);
                restored.tree.restore(roundTrip(original.tree.snapshot()));
                assert.strictEqual(restored.tree.getState(), State.FAILED);

                stepToCompletion(restored.tree);

                assert.strictEqual(restored.calls.length, 5);
            });
        });

        describe("lotto nodes", () => {
            const definition = "root { lotto { action [A] action [B] action [C] } }";

            it("with the child that was picked", () => {
                // A random value of 0.99 picks the last child.
                const original = createTree(definition, { random: () => 0.99 }, undefined);
                original.tree.step();
                assert.deepEqual(original.calls, ["C"]);

                // A random value of 0 would pick the first child, but it should not be called at all.
                const random = sinon.stub().returns(0);
                const restored = createTree(definition, { random }, undefined);
                restored.tree.restore(roundTrip(original.tree.snapshot()));

                restored.tree.step();
                restored.tree.step();

                assert.deepEqual(restored.calls, ["C", "C"]);
                assert.isFalse(random.called);
            });

            it("and picks a new child when a new run starts after a finished tree is restored", () => {
                const original = createTree(definition, { random: () => 0.99 }, State.SUCCEEDED);
                original.tree.step();
                assert.deepEqual(original.calls, ["C"]);
                assert.strictEqual(original.tree.getState(), State.SUCCEEDED);

                const restored = createTree(definition, { random: () => 0 }, State.SUCCEEDED);
                restored.tree.restore(roundTrip(original.tree.snapshot()));
                assert.strictEqual(restored.tree.getState(), State.SUCCEEDED);

                restored.tree.step();

                assert.deepEqual(restored.calls, ["A"]);
            });
        });
    });

    describe("restore keeps the progress of wait nodes", () => {
        /**
         * Steps a restored tree to find out how long it takes to succeed, stepping once per tick.
         * @returns The time in milliseconds after which the tree succeeded.
         */
        const getTimeToSucceed = (tree: BehaviourTree, tickMs: number, maxMs: number) => {
            for (let elapsed = 0; elapsed <= maxMs; elapsed += tickMs) {
                tree.step();

                if (tree.getState() === State.SUCCEEDED) {
                    return elapsed;
                }

                clock.tick(tickMs);
            }

            throw new Error("the tree did not succeed in time");
        };

        describe("when using the clock", () => {
            it("so that only the remaining time is waited, ignoring the time that passed before it was restored", () => {
                const definition = "root { wait [1000] }";

                const original = new BehaviourTree(definition, {});
                original.step();
                clock.tick(400);
                original.step();

                // The time since the last step of the original tree counts towards the wait.
                clock.tick(200);
                const snapshot = roundTrip(original.snapshot());

                clock.tick(DOWNTIME_MS);

                const restored = new BehaviourTree(definition, {});
                restored.restore(snapshot);

                // The tree has already waited for 600ms, so there are 400ms left to wait.
                restored.step();
                assert.strictEqual(restored.getState(), State.RUNNING);

                clock.tick(399);
                restored.step();
                assert.strictEqual(restored.getState(), State.RUNNING);

                clock.tick(1);
                restored.step();
                assert.strictEqual(restored.getState(), State.SUCCEEDED);
            });

            it("with a random duration that was already picked", () => {
                const definition = "root { wait [5000, 10000] }";

                // A random value of 0.5 picks a duration of 7500ms.
                const original = new BehaviourTree(definition, {}, { random: () => 0.5 });
                original.step();
                clock.tick(2500);

                const snapshot = roundTrip(original.snapshot());

                clock.tick(DOWNTIME_MS);

                // A random value of 0 would pick a duration of 5000ms, but it should not be called at all.
                const random = sinon.stub().returns(0);
                const restored = new BehaviourTree(definition, {}, { random });
                restored.restore(snapshot);

                assert.strictEqual(getTimeToSucceed(restored, 500, 10000), 5000);
                assert.isFalse(random.called);
            });

            it("that waits indefinitely", () => {
                const definition = "root { wait }";

                const original = new BehaviourTree(definition, {});
                original.step();
                clock.tick(1000);

                const snapshot = roundTrip(original.snapshot());

                clock.tick(DOWNTIME_MS);

                const restored = new BehaviourTree(definition, {});
                restored.restore(snapshot);
                restored.step();

                clock.tick(DOWNTIME_MS);
                restored.step();

                assert.strictEqual(restored.getState(), State.RUNNING);
            });

            it("that has not started waiting yet", () => {
                const definition = "root { wait [1000] }";

                const original = new BehaviourTree(definition, {});
                clock.tick(5000);

                const restored = new BehaviourTree(definition, {});
                restored.restore(roundTrip(original.snapshot()));

                assert.strictEqual(findNode(restored, "wait").state, State.READY);

                restored.step();
                assert.strictEqual(restored.getState(), State.RUNNING);

                clock.tick(1000);
                restored.step();
                assert.strictEqual(restored.getState(), State.SUCCEEDED);
            });

            it("and picks a new duration when a new run starts after a finished tree is restored", () => {
                const definition = "root { wait [5000, 10000] }";

                // A random value of 0 picks a duration of 5000ms.
                const original = new BehaviourTree(definition, {}, { random: () => 0 });
                original.step();
                clock.tick(5000);
                original.step();
                assert.strictEqual(original.getState(), State.SUCCEEDED);

                clock.tick(DOWNTIME_MS);

                // A random value of 1 would pick a duration of 10000ms (if it could be returned).
                const restored = new BehaviourTree(definition, {}, { random: () => 0.9999 });
                restored.restore(roundTrip(original.snapshot()));
                assert.strictEqual(restored.getState(), State.SUCCEEDED);

                assert.strictEqual(getTimeToSucceed(restored, 1000, 20000), 10000);
            });
        });

        describe("when using the 'getDeltaTime' option", () => {
            it("so that only the remaining time is waited, ignoring the time that passed before it was restored", () => {
                const definition = "root { wait [1000] }";

                const original = new BehaviourTree(definition, {}, { getDeltaTime: () => 0.25 });
                original.step();
                original.step();

                const snapshot = roundTrip(original.snapshot());

                clock.tick(DOWNTIME_MS);

                // The delta time function is the source of time, so it should not be called by a snapshot or restore.
                const getDeltaTime = sinon.stub().returns(0.25);
                const restored = new BehaviourTree(definition, {}, { getDeltaTime });
                restored.restore(snapshot);
                assert.isFalse(getDeltaTime.called);

                // The tree has already waited for 500ms, so there are 500ms left to wait.
                restored.step();
                assert.strictEqual(restored.getState(), State.RUNNING);

                restored.step();
                assert.strictEqual(restored.getState(), State.SUCCEEDED);
            });

            it("with a random duration that was already picked", () => {
                const definition = "root { wait [5000, 10000] }";

                // A random value of 0.5 picks a duration of 7500ms.
                const original = new BehaviourTree(definition, {}, { getDeltaTime: () => 2.5, random: () => 0.5 });
                original.step();

                const snapshot = roundTrip(original.snapshot());

                const random = sinon.stub().returns(0);
                const restored = new BehaviourTree(definition, {}, { getDeltaTime: () => 2.5, random });
                restored.restore(snapshot);

                restored.step();
                assert.strictEqual(restored.getState(), State.RUNNING);

                restored.step();
                assert.strictEqual(restored.getState(), State.SUCCEEDED);
                assert.isFalse(random.called);
            });
        });

        describe("behaves exactly like the tree it was taken from", () => {
            const definition = `root {
                sequence {
                    parallel {
                        wait [150, 450]
                        sequence { action [Slow] wait [200] }
                    }
                    race {
                        wait [1000, 1200]
                        sequence { wait [100] action [Slow] wait [100] }
                    }
                    repeat [2, 3] { wait [100, 200] }
                    wait
                }
            }`;
            const createAgent = createRecordingAgent({
                Slow: (step) => (step % 3 === 0 ? State.SUCCEEDED : undefined)
            });

            it("when using the clock", () => {
                assertRestoredTreesBehaveLikeTheOriginal(clock, {
                    definition,
                    createAgent,
                    steps: 40,
                    stepDurationMs: 70,
                    timing: "clock"
                });
            });

            it("when using the 'getDeltaTime' option", () => {
                assertRestoredTreesBehaveLikeTheOriginal(clock, {
                    definition,
                    createAgent,
                    steps: 40,
                    stepDurationMs: 70,
                    timing: "delta"
                });
            });

            it("when a tree finishes and starts new runs", () => {
                assertRestoredTreesBehaveLikeTheOriginal(clock, {
                    definition: "root { sequence { wait [100, 500] action [Slow] wait [200, 300] } }",
                    createAgent,
                    steps: 80,
                    stepDurationMs: 70,
                    timing: "clock"
                });
            });
        });
    });

    describe("snapshot and restore of action nodes that return a promise", () => {
        const definition = "root { sequence { action [Work] action [After] } }";

        /**
         * Creates a tree with a 'Work' action that returns a promise that is settled by the test.
         */
        const createTree = () => {
            const calls: string[] = [];
            let settle: { resolve: (value: any) => void; reject: (reason: any) => void } = null as any;

            const agent = {
                Work: () => {
                    calls.push("Work");
                    return new Promise((resolve, reject) => (settle = { resolve, reject }));
                },
                After: () => (calls.push("After"), State.RUNNING)
            };

            return { tree: new BehaviourTree(definition, agent), calls, settle: () => settle };
        };

        /**
         * Lets any promise handlers that are waiting to run do so.
         */
        const flushPromises = async () => {
            for (let i = 0; i < 5; i++) {
                await Promise.resolve();
            }
        };

        it("does not error when taking a snapshot while the promise is pending, and records the action as not started", () => {
            const { tree } = createTree();
            tree.step();

            let snapshot: BehaviourTreeSnapshot | undefined;
            assert.doesNotThrow(() => (snapshot = tree.snapshot()));

            assertIsPlainData(snapshot);
            assert.deepEqual(roundTrip(snapshot), snapshot);

            const [work, after] = snapshot!.root.children![0].children!;
            assert.strictEqual(work.state, State.READY);
            assert.isNull((work as any).promiseResult);
            assert.strictEqual(after.state, State.READY);
        });

        it("restores an action that had a pending promise as not started, so that its function is called again on the next step", async () => {
            const source = createTree();
            source.tree.step();
            const snapshot = roundTrip(source.tree.snapshot());

            const restored = createTree();
            restored.tree.restore(snapshot);

            assert.deepEqual(restored.calls, []);
            assert.strictEqual(findNode(restored.tree, "action", "Work").state, State.READY);

            restored.tree.step();

            assert.deepEqual(restored.calls, ["Work"]);
            assert.strictEqual(findNode(restored.tree, "action", "Work").state, State.RUNNING);
            assert.deepEqual(getNodeStates(restored.tree), getNodeStates(source.tree));

            // The new promise is handled as usual.
            restored.settle().resolve(State.SUCCEEDED);
            await flushPromises();
            restored.tree.step();

            assert.strictEqual(findNode(restored.tree, "action", "Work").state, State.SUCCEEDED);
            assert.deepEqual(restored.calls, ["Work", "After"]);
        });

        it("calls the entry callback again for an action that had a pending promise, as it is restored as not started", () => {
            const calls: string[] = [];
            const createEntryTree = () =>
                new BehaviourTree("root { action [Work] entry(OnEntry) }", {
                    OnEntry: () => calls.push("OnEntry"),
                    Work: () => (calls.push("Work"), new Promise(() => {}))
                });

            const source = createEntryTree();
            source.step();
            const snapshot = roundTrip(source.snapshot());
            calls.length = 0;

            const restored = createEntryTree();
            restored.restore(snapshot);
            restored.step();

            assert.deepEqual(calls, ["OnEntry", "Work"]);
        });

        it("does not change the tree that the snapshot was taken from, which still handles its promise", async () => {
            const { tree, calls, settle } = createTree();
            tree.step();
            const before = getNodeStates(tree);

            tree.snapshot();

            assert.deepEqual(getNodeStates(tree), before);
            assert.strictEqual(findNode(tree, "action", "Work").state, State.RUNNING);

            // The pending promise is still waited for, and settling it moves the tree on.
            tree.step();
            assert.deepEqual(calls, ["Work"]);

            settle().resolve(State.SUCCEEDED);
            await flushPromises();
            tree.step();

            assert.strictEqual(findNode(tree, "action", "Work").state, State.SUCCEEDED);
            assert.deepEqual(calls, ["Work", "After"]);
        });

        it("discards the pending promise of a tree that a snapshot with a pending promise is restored into", async () => {
            const source = createTree();
            source.tree.step();
            const snapshot = roundTrip(source.tree.snapshot());

            const live = createTree();
            live.tree.step();
            const firstSettle = live.settle();

            live.tree.restore(snapshot);

            // The promise that was pending before the restore settles, which must not change the restored tree.
            firstSettle.resolve(State.SUCCEEDED);
            await flushPromises();

            assert.strictEqual(findNode(live.tree, "action", "Work").state, State.READY);

            live.tree.step();

            assert.deepEqual(live.calls, ["Work", "Work"]);
            assert.strictEqual(findNode(live.tree, "action", "Work").state, State.RUNNING);

            // Only the promise from after the restore decides the state of the action.
            live.settle().resolve(State.FAILED);
            await flushPromises();
            live.tree.step();

            assert.strictEqual(findNode(live.tree, "action", "Work").state, State.FAILED);
        });

        it("keeps a settled promise result next to an action with a promise that is pending", async () => {
            const calls: string[] = [];
            const settles: { [name: string]: (value: State) => void } = {};
            const createParallelTree = () =>
                new BehaviourTree("root { parallel { action [Fast] action [Slow] } }", {
                    Fast: () => (calls.push("Fast"), new Promise((resolve) => (settles.Fast = resolve))),
                    Slow: () => (calls.push("Slow"), new Promise((resolve) => (settles.Slow = resolve)))
                });

            const source = createParallelTree();
            source.step();
            settles.Fast(State.SUCCEEDED);
            await flushPromises();

            const snapshot = roundTrip(source.snapshot());
            calls.length = 0;

            const restored = createParallelTree();
            restored.restore(snapshot);
            restored.step();

            // The result of the promise that settled is kept so Fast is not called again, but Slow is as it was pending.
            assert.deepEqual(calls, ["Slow"]);
            assert.strictEqual(findNode(restored, "action", "Fast").state, State.SUCCEEDED);
            assert.strictEqual(findNode(restored, "action", "Slow").state, State.RUNNING);
        });

        describe("restores an action with a pending promise as not started when it is inside of", () => {
            const definitions = {
                sequence: "sequence { action [Work] action [Other] }",
                selector: "selector { action [Work] action [Other] }",
                parallel: "parallel { action [Other] action [Work] }",
                race: "race { action [Other] action [Work] }",
                all: "all { action [Other] action [Work] }",
                lotto: "lotto { action [Work] }",
                repeat: "repeat [2] { action [Work] }",
                retry: "retry [2] { action [Work] }",
                flip: "flip { action [Work] }",
                succeed: "succeed { action [Work] }",
                fail: "fail { action [Work] }",
                "a guarded node": "sequence while(Check) { action [Work] }",
                "nested nodes": "sequence { repeat [2] { selector { action [Work] } } action [Other] }",
                "a branch": "branch [Sub]"
            };

            for (const [name, body] of Object.entries(definitions)) {
                it(`${name}, which then behaves like the original tree`, async () => {
                    const definition = `root { ${body} } root [Sub] { sequence { action [Work] } }`;

                    const createLoggedTree = () => {
                        const calls: string[] = [];
                        const agent = {
                            Work: () => (calls.push("Work"), new Promise<State>(() => {})),
                            Other: () => (calls.push("Other"), State.RUNNING),
                            Check: () => true
                        };

                        return { calls, tree: new BehaviourTree(definition, agent, { random: () => 0 }) };
                    };

                    const original = createLoggedTree();
                    original.tree.step();
                    const snapshot = roundTrip(original.tree.snapshot());
                    const expectedCalls = [...original.calls];
                    const expectedStates = getNodeStates(original.tree);
                    original.calls.length = 0;

                    const restored = createLoggedTree();
                    restored.tree.restore(snapshot);
                    assert.deepEqual(restored.calls, []);

                    restored.tree.step();

                    assert.deepEqual(restored.calls, expectedCalls);
                    assert.deepEqual(getNodeStates(restored.tree), expectedStates);
                });
            }
        });

        it("keeps the result of a promise that resolved before the snapshot, which is handled by the next step", async () => {
            const original = createTree();
            original.tree.step();
            original.settle().resolve(State.SUCCEEDED);
            await flushPromises();

            const snapshot = roundTrip(original.tree.snapshot());
            assert.strictEqual(findNode(original.tree, "action", "Work").state, State.RUNNING);

            const restored = createTree();
            restored.tree.restore(snapshot);
            assert.strictEqual(findNode(restored.tree, "action", "Work").state, State.RUNNING);

            restored.tree.step();

            // The action function should not be called again, as that would repeat what it did.
            assert.deepEqual(restored.calls, ["After"]);
            assert.strictEqual(findNode(restored.tree, "action", "Work").state, State.SUCCEEDED);
        });

        it("keeps the result of a promise that resolved with a failure", async () => {
            const original = createTree();
            original.tree.step();
            original.settle().resolve(State.FAILED);
            await flushPromises();

            const restored = createTree();
            restored.tree.restore(roundTrip(original.tree.snapshot()));
            restored.tree.step();

            assert.deepEqual(restored.calls, []);
            assert.strictEqual(findNode(restored.tree, "action", "Work").state, State.FAILED);
            assert.strictEqual(restored.tree.getState(), State.FAILED);
        });

        it("keeps the result of a promise that was rejected before the snapshot, which errors on the next step", async () => {
            const original = createTree();
            original.tree.step();
            original.settle().reject(new Error("some-error"));
            await flushPromises();

            const restored = createTree();
            restored.tree.restore(roundTrip(original.tree.snapshot()));

            const message = "error stepping tree: action function 'Work' promise rejected with 'Error: some-error'";
            assert.throws(() => original.tree.step(), Error, message);
            assert.throws(() => restored.tree.step(), Error, message);
            assert.deepEqual(restored.calls, []);
        });

        it("keeps the result of a promise that resolved with an invalid value, which errors on the next step", async () => {
            const original = createTree();
            original.tree.step();
            original.settle().resolve({ not: "a state" });
            await flushPromises();

            const restored = createTree();
            restored.tree.restore(roundTrip(original.tree.snapshot()));

            const message =
                "error stepping tree: action node promise resolved with an invalid value, expected a State.SUCCEEDED or State.FAILED value to be returned";
            assert.throws(() => original.tree.step(), Error, message);
            assert.throws(() => restored.tree.step(), Error, message);
        });

        it("does not keep a promise result that has already been handled", async () => {
            const original = createTree();
            original.tree.step();
            original.settle().resolve(State.SUCCEEDED);
            await flushPromises();
            original.tree.step();

            const snapshot = roundTrip(original.tree.snapshot());
            assert.isNull((snapshot.root.children![0].children![0] as any).promiseResult);

            const restored = createTree();
            restored.tree.restore(snapshot);
            restored.tree.step();

            assert.deepEqual(restored.calls, ["After"]);
        });

        it("does not let a promise from before a restore change the restored state", async () => {
            // Take a snapshot from a tree where the action has already failed.
            const source = createTree();
            source.tree.step();
            source.settle().resolve(State.FAILED);
            await flushPromises();
            const snapshot = roundTrip(source.tree.snapshot());

            // Restore into a tree that is still waiting for its own promise, which then resolves after the restore.
            const live = createTree();
            live.tree.step();
            live.tree.restore(snapshot);
            live.settle().resolve(State.SUCCEEDED);
            await flushPromises();

            live.tree.step();

            assert.strictEqual(findNode(live.tree, "action", "Work").state, State.FAILED);
            assert.deepEqual(live.calls, ["Work"]);
        });

        it("does not let a promise from before a restore to a state without a promise change the restored state", async () => {
            const live = createTree();
            const beforeStepping = live.tree.snapshot();
            live.tree.step();
            live.tree.restore(beforeStepping);

            live.settle().resolve(State.SUCCEEDED);
            await flushPromises();

            // The action was restored as not having started, so it should be started again by a step.
            live.tree.step();

            assert.deepEqual(live.calls, ["Work", "Work"]);
            assert.strictEqual(findNode(live.tree, "action", "Work").state, State.RUNNING);
        });
    });

    describe("restore will error and leave the tree unchanged if", () => {
        const definition =
            "root { sequence { repeat [3] { action [A] } retry [3] { action [A] } lotto { action [A] } wait [1000] action [A] } }";
        const createTree = () => new BehaviourTree(definition, { A: () => State.RUNNING });

        let tree: BehaviourTree;
        let snapshot: any;

        beforeEach(() => {
            const source = createTree();
            source.step();
            snapshot = roundTrip(source.snapshot());

            tree = createTree();
        });

        const assertRestoreErrors = (modify: (nodes: any[]) => void, message: string) => {
            const before = tree.snapshot();

            // The nodes are in the order: repeat, retry, lotto, wait, action.
            modify(snapshot.root.children[0].children);

            assert.throws(() => tree.restore(snapshot), Error, `error restoring tree: ${message}`);
            assert.deepEqual(tree.snapshot(), before);
        };

        it("a repeat node has an invalid iteration count", () => {
            assertRestoreErrors(
                (nodes) => (nodes[0].currentIterationCount = -1),
                "expected a non-negative integer 'currentIterationCount' for 'repeat' node but got '-1'"
            );
        });

        it("a repeat node has an invalid target iteration count", () => {
            assertRestoreErrors(
                (nodes) => (nodes[0].targetIterationCount = 1.5),
                "expected null or a non-negative integer 'targetIterationCount' for 'repeat' node but got '1.5'"
            );
            assertRestoreErrors(
                (nodes) => delete nodes[0].targetIterationCount,
                "expected null or a non-negative integer 'targetIterationCount' for 'repeat' node but got 'undefined'"
            );
        });

        it("a retry node has an invalid attempt count", () => {
            assertRestoreErrors(
                (nodes) => (nodes[1].currentAttemptCount = "1"),
                "expected a non-negative integer 'currentAttemptCount' for 'retry' node but got '1'"
            );
        });

        it("a retry node has an invalid target attempt count", () => {
            assertRestoreErrors(
                (nodes) => (nodes[1].targetAttemptCount = NaN),
                "expected null or a non-negative integer 'targetAttemptCount' for 'retry' node but got 'NaN'"
            );
        });

        it("a lotto node has a selected child that does not exist", () => {
            assertRestoreErrors(
                (nodes) => (nodes[2].selectedChildIndex = 1),
                "expected null or an index of one of the 1 children as 'selectedChildIndex' for 'lotto' node but got '1'"
            );
        });

        it("a wait node has an invalid total duration", () => {
            assertRestoreErrors(
                (nodes) => (nodes[3].totalDuration = -1),
                "expected null or a non-negative number 'totalDuration' for 'wait' node but got '-1'"
            );
            assertRestoreErrors(
                (nodes) => delete nodes[3].totalDuration,
                "expected null or a non-negative number 'totalDuration' for 'wait' node but got 'undefined'"
            );
        });

        it("a wait node has an invalid waited duration", () => {
            assertRestoreErrors(
                (nodes) => (nodes[3].waitedDuration = null),
                "expected a finite number 'waitedDuration' for 'wait' node but got 'null'"
            );
            assertRestoreErrors(
                (nodes) => (nodes[3].waitedDuration = "5"),
                "expected a finite number 'waitedDuration' for 'wait' node but got '5'"
            );
        });

        it("an action node has an invalid promise result", () => {
            const message = (value: unknown) =>
                `expected null or a settled promise result as 'promiseResult' for 'action' node but got '${value}'`;

            assertRestoreErrors((nodes) => (nodes[4].promiseResult = "resolved"), message("resolved"));
            assertRestoreErrors((nodes) => (nodes[4].promiseResult = {}), message("[object Object]"));
            assertRestoreErrors(
                (nodes) => (nodes[4].promiseResult = { isResolved: true, value: "mistreevous.running" }),
                message("[object Object]")
            );
            assertRestoreErrors(
                (nodes) => (nodes[4].promiseResult = { isResolved: false, value: null }),
                message("[object Object]")
            );
            assertRestoreErrors((nodes) => delete nodes[4].promiseResult, message("undefined"));
        });

        it("a later node in the snapshot is invalid, even though the earlier nodes are valid", () => {
            assertRestoreErrors(
                (nodes) => (nodes[2].children[0].state = "bad"),
                "expected a valid 'state' for 'action' node but got 'bad'"
            );
        });
    });

    describe("restore does not report state changes", () => {
        const definition = `root {
            sequence {
                action [Done]
                repeat [3] { action [Done] }
                lotto { action [Work] action [Work] }
                parallel { action [Work] wait [1000] }
            }
        }`;

        const createAgent = () => ({ Done: () => State.SUCCEEDED, Work: () => State.RUNNING });

        const createTree = (changes: string[]) =>
            new BehaviourTree(definition, createAgent(), {
                onNodeStateChange: (change) => changes.push(`${change.type}:${change.previousState}->${change.state}`)
            });

        it("into a tree that has not been stepped", () => {
            const original = createTree([]);
            original.step();

            const changes: string[] = [];
            const restored = createTree(changes);
            restored.restore(roundTrip(original.snapshot()));

            assert.deepEqual(changes, []);
        });

        it("into a tree that is in a different state, and the next step reports changes as usual", () => {
            const originalChanges: string[] = [];
            const original = createTree(originalChanges);
            original.step();

            const snapshot = roundTrip(original.snapshot());

            originalChanges.length = 0;
            original.step();

            assert.isAbove(originalChanges.length, 0);

            // Give the tree that is restored into a state that differs from the snapshot.
            const changes: string[] = [];
            const restored = createTree(changes);
            restored.step();
            restored.step();
            restored.reset();

            changes.length = 0;
            restored.restore(snapshot);

            assert.deepEqual(changes, []);

            restored.step();

            assert.deepEqual(changes, originalChanges);
        });
    });

    describe("snapshots are independent of the trees that they were taken from or restored to", () => {
        const definition = `root {
            sequence {
                action [Done]
                repeat [2, 4] { action [Work] }
                wait [100, 300]
                lotto { action [Work] action [Work] }
            }
        }`;

        const createAgent = () => ({ Done: () => State.SUCCEEDED, Work: () => State.SUCCEEDED });

        const tickAndStep = (tree: BehaviourTree) => {
            clock.tick(150);
            tree.step();
        };

        it("so stepping the tree that a snapshot was taken from does not change the snapshot", () => {
            const tree = new BehaviourTree(definition, createAgent());

            for (let step = 1; step <= 8; step++) {
                tickAndStep(tree);

                const snapshot = tree.snapshot();
                const copy = roundTrip(snapshot);

                tickAndStep(tree);
                tickAndStep(tree);

                assert.deepEqual(roundTrip(snapshot), copy, `snapshot taken after step ${step}`);
            }
        });

        it("so stepping a tree that a snapshot was restored to does not change the snapshot", () => {
            const original = new BehaviourTree(definition, createAgent());

            for (let step = 1; step <= 8; step++) {
                tickAndStep(original);

                const snapshot = original.snapshot();
                const copy = roundTrip(snapshot);

                const restored = new BehaviourTree(definition, createAgent());
                restored.restore(snapshot);

                tickAndStep(restored);
                tickAndStep(restored);
                restored.reset();
                tickAndStep(restored);

                assert.deepEqual(roundTrip(snapshot), copy, `snapshot taken after step ${step}`);
            }
        });

        it("and a snapshot taken right after a restore equals the snapshot that was restored", () => {
            const original = new BehaviourTree(definition, createAgent());

            for (let step = 1; step <= 8; step++) {
                tickAndStep(original);

                const snapshot = original.snapshot();

                const restored = new BehaviourTree(definition, createAgent());
                restored.restore(snapshot);

                assert.deepEqual(roundTrip(restored.snapshot()), roundTrip(snapshot), `after step ${step}`);
            }
        });

        it("including snapshots of actions with a settled promise", async () => {
            const createPromiseAgent = () => ({
                Resolved: () => Promise.resolve(State.FAILED),
                Rejected: () => Promise.reject("nope"),
                Invalid: () => Promise.resolve("what")
            });

            const stepIgnoringErrors = (tree: BehaviourTree) => {
                try {
                    tree.step();
                } catch {
                    // Handling a rejected or invalid promise result throws.
                }
            };

            for (const name of ["Resolved", "Rejected", "Invalid"]) {
                const definition = `root { action [${name}] }`;
                const tree = new BehaviourTree(definition, createPromiseAgent());

                tree.step();
                await Promise.resolve();

                const snapshot = tree.snapshot();
                const copy = roundTrip(snapshot);

                const restored = new BehaviourTree(definition, createPromiseAgent());
                restored.restore(snapshot);

                assert.deepEqual(roundTrip(restored.snapshot()), copy, name);

                stepIgnoringErrors(restored);
                stepIgnoringErrors(tree);

                assert.deepEqual(roundTrip(snapshot), copy, name);
            }
        });
    });

    describe("restored from a snapshot behaves exactly like the tree it was taken from", () => {
        it("for composite and decorator nodes, conditions, actions, callbacks and guards", () => {
            assertRestoredTreesBehaveLikeTheOriginal(clock, {
                definition: `root {
                    sequence {
                        action [Begin] entry(onEntry) exit(onExit)
                        parallel step(onStep) {
                            action [Slow]
                            sequence {
                                condition [Even]
                                action [Slow]
                            }
                        }
                        race {
                            action [Slow]
                            sequence { action [Never] action [Slow] }
                        }
                        all {
                            action [Fast]
                            flip { condition [Even] }
                            succeed { action [Never] }
                            fail { action [Fast] }
                        }
                        selector {
                            sequence { condition [Never] action [Fast] }
                            sequence while(Healthy) {
                                action [Slow]
                                action [Slow]
                            }
                        }
                        action [Finish]
                    }
                }`,
                createAgent: createRecordingAgent({
                    Begin: () => State.SUCCEEDED,
                    Slow: (step) => (step % 3 === 0 ? State.SUCCEEDED : undefined),
                    Fast: () => State.SUCCEEDED,
                    Never: () => State.FAILED,
                    Even: (step) => step % 2 === 0,
                    Healthy: (step) => step < 14,
                    Finish: () => State.SUCCEEDED,
                    onEntry: () => undefined,
                    onExit: () => undefined,
                    onStep: () => undefined
                }),
                steps: 24,
                stepDurationMs: 100,
                timing: "clock"
            });
        });

        it("for repeat, retry and lotto nodes, including the random choices that they make", () => {
            assertRestoredTreesBehaveLikeTheOriginal(clock, {
                definition: `root {
                    sequence {
                        repeat [2, 4] {
                            sequence {
                                retry [2, 3] { action [Flaky] }
                                lotto [1, 2, 3] {
                                    action [Slow]
                                    action [Fast]
                                    sequence { action [Slow] action [Slow] }
                                }
                            }
                        }
                        race {
                            repeat { action [Slow] }
                            retry { action [Never] }
                        }
                        repeat [2] { retry [2] { action [Flaky] } }
                    }
                }`,
                createAgent: createRecordingAgent({
                    Slow: (step) => (step % 3 === 0 ? State.SUCCEEDED : undefined),
                    Fast: () => State.SUCCEEDED,
                    Flaky: (step) => (step % 5 === 0 ? State.SUCCEEDED : State.FAILED),
                    Never: (step) => (step % 4 === 0 ? State.FAILED : undefined)
                }),
                steps: 80,
                stepDurationMs: 100,
                timing: "clock"
            });
        });

        it("for branches that reference the same subtree more than once", () => {
            assertRestoredTreesBehaveLikeTheOriginal(clock, {
                definition: `
                    root { sequence { branch [Work] branch [Work] } }
                    root [Work] { sequence { repeat [2, 3] { action [Slow] } wait [100, 300] } }
                `,
                createAgent: createRecordingAgent({ Slow: (step) => (step % 3 === 0 ? State.SUCCEEDED : undefined) }),
                steps: 50,
                stepDurationMs: 70,
                timing: "clock"
            });
        });
    });
});
