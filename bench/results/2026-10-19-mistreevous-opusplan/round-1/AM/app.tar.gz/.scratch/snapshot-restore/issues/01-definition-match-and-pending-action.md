# Reject snapshots of another definition, restore pending actions as not started

Status: resolved
Spec: ../spec.md

## Goal
Two gaps found in review of snapshot and restore, before release.

1. `restore()` accepts a snapshot of a different definition when the node types and counts match, which corrupts the tree.
2. An action with a pending promise is stored as `RUNNING`. Define it as not yet started.

## Acceptance criteria
- [x] A snapshot records the definition it was taken from. MDSL and the equivalent JSON definition are the same definition.
- [x] `restore()` throws an `Error` saying the snapshot does not match the tree's definition when the definition differs.
- [x] `restore()` throws an `Error` for `null`, a string, a number, an array, and an object without the snapshot's fields.
- [x] A rejected `restore()` leaves the tree and its `onNodeStateChange` calls unchanged.
- [x] An action with a pending promise is snapshotted as `READY`: the restored tree calls its entry callback and action function again on the next step.
- [x] README documents both next to the snapshot API. Version stays 4.4.0 (not released), Version History row extended.
