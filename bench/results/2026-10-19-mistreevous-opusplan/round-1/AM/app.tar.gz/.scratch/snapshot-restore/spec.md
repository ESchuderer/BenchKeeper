# Snapshot and restore of tree execution state

Status: resolved

## Goal
`BehaviourTree.snapshot()` returns the execution state as a JSON-safe object. `restore(snapshot)` puts a tree built from the same definition into that state. Storage and scheduling stay in the application.

## Format (version 1)
```
BehaviourTreeSnapshot = { version: 1, definition: string, root: NodeSnapshot }
NodeSnapshot = { type, state, children?, ...per-type fields }
```
`definition` identifies the tree definition: the JSON form of the definition with defaults filled in and keys sorted, so MDSL and equivalent JSON give the same value. Nodes are matched by position in the tree, not by id (ids are random per instance). Optional fields are omitted, never `undefined`.

| Node | Extra fields |
| --- | --- |
| composites, decorators | `children` |
| repeat, retry | `targetCount` (number or null), `currentCount` |
| lotto | `selectedChild` (child index or null) |
| wait | `totalDuration` (number or null), `waitedDuration` (ms waited as of the snapshot) |
| action | `promiseResult` when an update promise has settled |

## Decisions
- Wait: the snapshot stores the time waited at snapshot time. Restore sets the start time to `now - waitedDuration`, so time between snapshot and restore does not count (clock and `getDeltaTime`).
- Action with a pending promise: a promise cannot be stored. It is snapshotted as READY (not yet started): the restored tree calls its entry callback and action function again on the next step. Settled results are stored and applied without calling the function.
- `restore` throws if the snapshot is not a snapshot or its `definition` differs from the tree's.
- `restore` validates the whole snapshot before changing the tree. A failed restore leaves the tree untouched.
- `restore` calls no agent functions, callbacks or `random`. `onNodeStateChange` is not called, as restoring is not a state change. The next `step()` reports changes as usual.
- A snapshot taken right after `restore(s)`, before any step, equals `s`. A wait node reports the time it had waited at the restore until it is next stepped. A snapshot is not changed by stepping the tree it came from or the tree it was restored into.
- Finished trees restore as finished. The next `step()` resets and draws random values again.

## Acceptance criteria
- [x] Snapshot survives `JSON.parse(JSON.stringify(s))` unchanged, for every node type and tree state.
- [x] Restored tree: same node states, same agent calls in the same order, same result as the original, except for an action with a pending promise.
- [x] Repeat/retry counts, random targets, lotto choice, random wait durations and wait progress preserved.
- [x] Invalid snapshots throw and leave the tree unchanged.
- [x] `BehaviourTreeSnapshot` type exported. README section with example, version history, version 4.4.0.
