import { AnyState } from "./State";

/**
 * The execution state of a single node. Only the fields that apply to the node type are present.
 */
export type NodeSnapshot = {
    /**
     * The node type.
     */
    type: string;
    /**
     * The node state.
     */
    state: AnyState;
    /**
     * The snapshots of the child nodes, in definition order. Defined for composite and decorator nodes.
     */
    children?: NodeSnapshot[];
    /**
     * The number of iterations or attempts to make, or null for no limit. Defined for repeat and retry nodes.
     */
    targetCount?: number | null;
    /**
     * The number of iterations or attempts made so far. Defined for repeat and retry nodes.
     */
    currentCount?: number;
    /**
     * The index of the child picked by a lotto node, or null if none has been picked.
     */
    selectedChild?: number | null;
    /**
     * The duration in milliseconds that a wait node is waiting for, or null to wait indefinitely.
     */
    totalDuration?: number | null;
    /**
     * The duration in milliseconds that a wait node has waited for.
     */
    waitedDuration?: number;
    /**
     * The settled result of the update promise of an action node. A rejection reason is stored as a string.
     */
    promiseResult?: { isResolved: boolean; value: string | null };
};

/**
 * The execution state of a behaviour tree, as returned by 'snapshot' and accepted by 'restore'.
 * It contains only JSON-safe values. Nodes are identified by their position in the tree, not by id.
 */
export type BehaviourTreeSnapshot = {
    /**
     * The snapshot format version.
     */
    version: 1;
    /**
     * Identifies the definition of the tree that the snapshot was taken from. A snapshot can only be restored into a tree with the same definition.
     */
    definition: string;
    /**
     * The snapshot of the root node.
     */
    root: NodeSnapshot;
};
