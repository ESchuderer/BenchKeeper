/**
 * Create a randomly generated node uid.
 * @returns A randomly generated node uid.
 */
export function createUid(): string {
    const S4 = function () {
        return (((1 + Math.random()) * 0x10000) | 0).toString(16).substring(1);
    };
    return S4() + S4() + "-" + S4() + "-" + S4() + "-" + S4() + "-" + S4() + S4() + S4();
}

/**
 * Throws if the value is not a finite number, or null where null is allowed.
 * @param value The value to check.
 * @param name The name of the value, for the error message.
 * @param allowNull Whether null is allowed.
 */
export function expectNumber(value: unknown, name: string, allowNull = false): void {
    if (!(allowNull && value === null) && !(typeof value === "number" && Number.isFinite(value))) {
        throw new Error(`expected '${name}' to be a number${allowNull ? " or null" : ""}`);
    }
}
