import { assert } from "chai";

import sinon, { SinonFakeTimers } from "sinon";

import { BehaviourTree, State } from "../src/index";
import type { BehaviourTreeSnapshot, NodeDetails } from "../src/index";
import { Agent } from "../src/Agent";
import { BehaviourTreeOptions } from "../src/BehaviourTreeOptions";
import { findNode } from "./TestUtilities";

/**
 * Per function name, the queue of results returned by successive calls. The last result repeats.
 * The `$random` entry holds the values returned by the 'random' option, which throws when exhausted.
 */
type Script = Record<string, any[]>;

const createScript = (script: Script): Script =>
    Object.fromEntries(Object.entries(script).map(([name, queue]) => [name, [...queue]]));

function createAgent(script: Script, log: string[]): Agent {
    const agent: Agent = {};

    Object.keys(script)
        .filter((name) => name !== "$random")
        .forEach((name) => {
            agent[name] = (..._args: any[]) => {
                log.push(name);
                const queue = script[name];
                return queue.length > 1 ? queue.shift() : queue[0];
            };
        });

    return agent;
}

function createOptions(script: Script, log: string[], extra: BehaviourTreeOptions = {}): BehaviourTreeOptions {
    return {
        ...extra,
        random: () => {
            log.push("$random");
            if (!script.$random?.length) {
                throw new Error("unexpected call to random");
            }
            return script.$random.shift();
        }
    };
}

function withoutIds(details: NodeDetails): any {
    const { id, children, ...rest } = details;
    return children ? { ...rest, children: children.map(withoutIds) } : rest;
}

/**
 * Runs a tree for `before` steps, snapshots it, restores the snapshot into a second tree built from the same definition,
 * then steps both trees `after` more times and checks that they never differ in node states or in the functions called.
 */
function assertRestoredTreeMatchesOriginal(
    definition: string,
    script: Script,
    before: number,
    after: number,
    extraOptions: BehaviourTreeOptions = {}
) {
    const originalScript = createScript(script);
    const originalLog: string[] = [];
    const original = new BehaviourTree(
        definition,
        createAgent(originalScript, originalLog),
        createOptions(originalScript, originalLog, extraOptions)
    );

    for (let step = 0; step < before; step++) {
        original.step();
    }

    // The snapshot must survive storage unchanged.
    const snapshot = original.snapshot();
    assert.deepEqual(JSON.parse(JSON.stringify(snapshot)), snapshot);

    // The restored tree is given what the agent and random function would have left to return at this point.
    const restoredScript = createScript(originalScript);
    const restoredLog: string[] = [];
    const restored = new BehaviourTree(
        definition,
        createAgent(restoredScript, restoredLog),
        createOptions(restoredScript, restoredLog, extraOptions)
    );
    restored.restore(JSON.parse(JSON.stringify(snapshot)));

    assert.deepEqual(restoredLog, [], "restoring must not call agent functions or the random function");
    assert.deepEqual(withoutIds(restored.getTreeNodeDetails()), withoutIds(original.getTreeNodeDetails()));

    originalLog.length = 0;

    for (let step = 0; step < after; step++) {
        original.step();
        restored.step();

        assert.deepEqual(restoredLog, originalLog, `functions called in step ${before + step + 1}`);
        assert.deepEqual(
            withoutIds(restored.getTreeNodeDetails()),
            withoutIds(original.getTreeNodeDetails()),
            `node states after step ${before + step + 1}`
        );

        originalLog.length = 0;
        restoredLog.length = 0;
    }

    return { original, restored };
}

describe("A BehaviourTree", () => {
    describe("snapshot()", () => {
        it("returns a plain object that is unchanged by a JSON round trip, with a version and a root node snapshot", () => {
            const tree = new BehaviourTree("root { sequence { action [A] action [B] } }", { A: () => {}, B: () => {} });

            const snapshot: BehaviourTreeSnapshot = tree.snapshot();

            assert.deepEqual(JSON.parse(JSON.stringify(snapshot)), snapshot);
            assert.strictEqual(snapshot.version, 1);
            assert.strictEqual(snapshot.root.type, "root");
            assert.strictEqual(snapshot.root.state, State.READY);
        });

        it("is not changed by later steps of the tree", () => {
            const tree = new BehaviourTree("root { sequence { action [A] action [B] } }", {
                A: () => State.SUCCEEDED,
                B: () => {}
            });

            const before = JSON.stringify(tree.snapshot());
            const snapshot = tree.snapshot();
            tree.step();

            assert.strictEqual(JSON.stringify(snapshot), before);
            assert.notStrictEqual(JSON.stringify(tree.snapshot()), before);
        });
    });

    describe("a snapshot", () => {
        const definition = `root {
            sequence {
                repeat [3] { action [Work] }
                lotto { action [A] action [B] }
                wait [1000]
                action [After]
            }
        }`;
        const createDefinitionAgent = () => ({
            Work: () => State.SUCCEEDED,
            A: () => State.SUCCEEDED,
            B: () => State.SUCCEEDED,
            After: () => State.SUCCEEDED
        });
        let clock: SinonFakeTimers;

        beforeEach(() => {
            clock = sinon.useFakeTimers();
        });

        afterEach(() => {
            clock.restore();
        });

        // Three repeat iterations and the lotto take four steps, the fifth starts the wait.
        const stepToWait = (tree: BehaviourTree) => [1, 2, 3, 4, 5].forEach(() => tree.step());

        const stored = (snapshot: BehaviourTreeSnapshot) => JSON.parse(JSON.stringify(snapshot));

        it("is not changed by stepping the tree it was restored into", () => {
            const source = new BehaviourTree(definition, createDefinitionAgent());
            stepToWait(source);
            const snapshot = source.snapshot();
            const before = stored(snapshot);

            const restored = new BehaviourTree(definition, createDefinitionAgent());
            restored.restore(snapshot);
            clock.tick(2000);
            restored.step();
            restored.step();

            assert.deepEqual(stored(snapshot), before);
        });

        it("equals a snapshot taken right after restoring it, when time passes between the two", () => {
            const source = new BehaviourTree(definition, createDefinitionAgent());
            stepToWait(source);
            clock.tick(300);
            const snapshot = source.snapshot();
            assert.strictEqual(findNode(source, "wait").state, State.RUNNING);

            clock.tick(60000);
            const restored = new BehaviourTree(definition, createDefinitionAgent());
            restored.restore(snapshot);
            clock.tick(50);

            assert.deepEqual(stored(restored.snapshot()), stored(snapshot));
        });
    });

    describe("restore()", () => {
        const definition = "root { sequence { action [A] action [B] } }";
        const agent = { A: () => State.SUCCEEDED, B: () => {} };

        describe("throws and leaves the tree unchanged if the snapshot", () => {
            const cases: [string, (snapshot: any) => any][] = [
                ["is not an object", () => null],
                ["has an unsupported version", (snapshot) => ({ ...snapshot, version: 2 })],
                ["has no root", (snapshot) => ({ version: snapshot.version })],
                [
                    "has a node of the wrong type",
                    (snapshot) => {
                        snapshot.root.children[0].children[1].type = "condition";
                        return snapshot;
                    }
                ],
                [
                    "has the wrong number of children",
                    (snapshot) => {
                        snapshot.root.children[0].children.pop();
                        return snapshot;
                    }
                ],
                [
                    "has an invalid node state",
                    (snapshot) => {
                        snapshot.root.children[0].children[0].state = "mistreevous.nope";
                        snapshot.root.children[0].children[1].state = State.RUNNING;
                        return snapshot;
                    }
                ]
            ];

            cases.forEach(([name, corrupt]) => {
                it(name, () => {
                    const source = new BehaviourTree(definition, agent);
                    source.step();
                    const invalid = corrupt(JSON.parse(JSON.stringify(source.snapshot())));

                    const target = new BehaviourTree(definition, agent);
                    const before = JSON.stringify(withoutIds(target.getTreeNodeDetails()));

                    assert.throws(() => target.restore(invalid), Error, "invalid snapshot");
                    assert.strictEqual(JSON.stringify(withoutIds(target.getTreeNodeDetails())), before);
                });
            });
        });

        describe("throws and leaves a stepped tree unchanged if the snapshot", () => {
            const agent = {
                A: () => {},
                B: () => {},
                C: () => {},
                E: () => {},
                F: () => {},
                G: () => true,
                H: () => true
            };

            const mismatches: [string, string, string][] = [
                [
                    "has a different action",
                    "root { sequence { action [A] action [B] } }",
                    "root { sequence { action [A] action [C] } }"
                ],
                ["has different action arguments", "root { action [A, 1, true] }", "root { action [A, 2, true] }"],
                ["has a different wait duration", "root { wait [100] }", "root { wait [200] }"],
                [
                    "has a different repeat count",
                    "root { repeat [2] { action [A] } }",
                    "root { repeat [3] { action [A] } }"
                ],
                ["has a different guard", "root { action [A] while(G) }", "root { action [A] while(H) }"],
                ["has a different entry callback", "root { action [A] entry(E) }", "root { action [A] entry(F) }"],
                ["has no entry callback", "root { action [A] entry(E) }", "root { action [A] }"],
                ["has a different node type", "root { sequence { action [A] } }", "root { selector { action [A] } }"],
                [
                    "has a different lotto weight",
                    "root { lotto [1, 2] { action [A] action [B] } }",
                    "root { lotto [1, 3] { action [A] action [B] } }"
                ],
                [
                    "has a different subtree",
                    "root [S] { action [A] } root { branch [S] }",
                    "root [S] { action [B] } root { branch [S] }"
                ]
            ];

            mismatches.forEach(([name, sourceDefinition, targetDefinition]) => {
                it(name, () => {
                    const source = new BehaviourTree(sourceDefinition, agent);
                    const snapshot = JSON.parse(JSON.stringify(source.snapshot()));

                    const changes: string[] = [];
                    const target = new BehaviourTree(targetDefinition, agent, {
                        onNodeStateChange: ({ type, state }) => changes.push(`${type}:${state}`)
                    });
                    target.step();
                    const before = JSON.stringify(withoutIds(target.getTreeNodeDetails()));
                    changes.length = 0;

                    assert.throws(() => target.restore(snapshot), Error, /does not match the tree's definition/);
                    assert.strictEqual(JSON.stringify(withoutIds(target.getTreeNodeDetails())), before);
                    assert.deepEqual(changes, []);
                });
            });

            const notSnapshots: [string, unknown][] = [
                ["is null", null],
                ["is undefined", undefined],
                ["is a string", "snapshot"],
                ["is a number", 1],
                ["is an array", []],
                ["is an array holding a snapshot", [{ version: 1, definition: "", root: {} }]],
                ["is an object without the snapshot fields", {}],
                ["has no definition", { version: 1, root: { type: "root", state: State.READY, children: [] } }],
                ["has a definition that is not a string", { version: 1, definition: 1, root: {} }],
                ["has no root", { version: 1, definition: "" }]
            ];

            notSnapshots.forEach(([name, notSnapshot]) => {
                it(`${name}`, () => {
                    const target = new BehaviourTree("root { action [A] }", agent);
                    target.step();
                    const before = JSON.stringify(withoutIds(target.getTreeNodeDetails()));

                    assert.throws(
                        () => target.restore(notSnapshot as BehaviourTreeSnapshot),
                        Error,
                        "invalid snapshot"
                    );
                    assert.strictEqual(JSON.stringify(withoutIds(target.getTreeNodeDetails())), before);
                });
            });
        });

        describe("accepts a snapshot of the same definition written as", () => {
            const agent = { A: () => {}, B: () => {}, E: () => {}, G: () => true };

            const mdsl = `root [Sub] { action [A, 1, "x"] }
                root {
                    sequence while(G) entry(E) {
                        branch [Sub]
                        repeat [2] { wait [10] }
                        condition [G]
                        selector { action [B] action [A] }
                    }
                }`;

            // Written without the 'args' and 'succeedOnAbort' defaults, and with the sub root after the main root.
            const json = [
                {
                    type: "root",
                    child: {
                        entry: { call: "E" },
                        while: { call: "G" },
                        type: "sequence",
                        children: [
                            { type: "branch", ref: "Sub" },
                            { type: "repeat", iterations: 2, child: { duration: 10, type: "wait" } },
                            { type: "condition", call: "G" },
                            {
                                type: "selector",
                                children: [
                                    { type: "action", call: "B" },
                                    { type: "action", call: "A" }
                                ]
                            }
                        ]
                    }
                },
                { type: "root", id: "Sub", child: { type: "action", call: "A", args: [1, "x"] } }
            ];

            const cases: [string, any, any][] = [
                ["MDSL, restored into MDSL", mdsl, mdsl],
                ["MDSL, restored into JSON", mdsl, json],
                ["JSON, restored into MDSL", json, mdsl],
                ["JSON, restored into JSON", json, JSON.parse(JSON.stringify(json))]
            ];

            cases.forEach(([name, sourceDefinition, targetDefinition]) => {
                it(name, () => {
                    const source = new BehaviourTree(sourceDefinition, agent);
                    source.step();
                    const target = new BehaviourTree(targetDefinition, agent);

                    target.restore(JSON.parse(JSON.stringify(source.snapshot())));

                    assert.deepEqual(withoutIds(target.getTreeNodeDetails()), withoutIds(source.getTreeNodeDetails()));
                });
            });

            it("a JSON definition that is changed after the tree is built", () => {
                const definition = { type: "root", child: { type: "action", call: "A" } };
                const source = new BehaviourTree(definition as any, agent);
                definition.child.call = "B";

                new BehaviourTree("root { action [A] }", agent).restore(source.snapshot());
                assert.throws(() => new BehaviourTree("root { action [B] }", agent).restore(source.snapshot()));
            });
        });

        it("replaces the state of a tree that has already been stepped", () => {
            const source = new BehaviourTree(definition, agent);
            const target = new BehaviourTree(definition, agent);
            target.step();
            target.step();

            target.restore(source.snapshot());

            assert.strictEqual(target.getState(), State.READY);
            assert.deepEqual(withoutIds(target.getTreeNodeDetails()), withoutIds(source.getTreeNodeDetails()));
        });

        it("does not call agent functions, callbacks or guards", () => {
            const calls: string[] = [];
            const spy = (name: string, result?: boolean) => () => {
                calls.push(name);
                return result;
            };
            const spied = { A: spy("A"), B: spy("B"), Enter: spy("Enter"), Guard: spy("Guard", true) };
            const spiedDefinition = "root { sequence { action [A] entry(Enter) while(Guard) action [B] } }";
            const source = new BehaviourTree(spiedDefinition, spied);
            source.step();
            calls.length = 0;

            new BehaviourTree(spiedDefinition, spied).restore(source.snapshot());

            assert.deepEqual(calls, []);
        });

        it("does not call onNodeStateChange, and the next step reports changes as usual", () => {
            const source = new BehaviourTree(definition, agent);
            source.step();

            const changes: string[] = [];
            const target = new BehaviourTree(
                definition,
                { A: () => State.SUCCEEDED, B: () => State.SUCCEEDED },
                {
                    onNodeStateChange: ({ type, previousState, state }) =>
                        changes.push(`${type}:${previousState}>${state}`)
                }
            );
            target.step();
            changes.length = 0;

            target.restore(source.snapshot());
            assert.deepEqual(changes, []);

            target.step();
            assert.sameMembers(changes, [
                `action:${State.RUNNING}>${State.SUCCEEDED}`,
                `sequence:${State.RUNNING}>${State.SUCCEEDED}`,
                `root:${State.RUNNING}>${State.SUCCEEDED}`
            ]);
        });

        describe("keeps the iteration and attempt counts of repeat and retry nodes", () => {
            const cases: [string, string, Script][] = [
                ["repeat [3]", "root { repeat [3] { action [A] } }", { A: [State.SUCCEEDED] }],
                [
                    "repeat [2,5] with a random target",
                    "root { repeat [2,5] { action [A] } }",
                    { A: [State.SUCCEEDED], $random: [0.99, 0, 0.5, 0.5, 0.5, 0.5] }
                ],
                [
                    "repeat until the child fails",
                    "root { repeat { action [A] } }",
                    { A: [State.SUCCEEDED, State.SUCCEEDED, State.FAILED] }
                ],
                ["retry [3]", "root { retry [3] { action [A] } }", { A: [State.FAILED] }],
                [
                    "retry [2,4] with a random target",
                    "root { retry [2,4] { action [A] } }",
                    { A: [State.FAILED], $random: [0.99, 0, 0.5, 0.5, 0.5, 0.5] }
                ],
                [
                    "retry until the child succeeds",
                    "root { retry { action [A] } }",
                    { A: [State.FAILED, State.FAILED, State.SUCCEEDED] }
                ],
                [
                    "nested repeat and retry",
                    "root { repeat [2] { retry [2] { sequence { action [A] action [B] } } } }",
                    { A: [State.SUCCEEDED], B: [State.FAILED, undefined, State.SUCCEEDED] }
                ]
            ];

            cases.forEach(([name, definition, script]) => {
                for (let before = 0; before <= 8; before++) {
                    it(`${name}, after ${before} steps`, () => {
                        assertRestoredTreeMatchesOriginal(definition, script, before, 14);
                    });
                }
            });
        });

        describe("keeps the child picked by a lotto node", () => {
            const cases: [string, string, Script][] = [
                [
                    "lotto",
                    "root { lotto { action [A] action [B] } }",
                    {
                        A: [undefined, undefined, State.SUCCEEDED],
                        B: [undefined, State.FAILED],
                        $random: Array(30).fill([0.99, 0]).flat()
                    }
                ],
                [
                    "weighted lotto in a repeat",
                    "root { repeat [3] { lotto [5,1,1] { action [A] action [B] action [C] } } }",
                    {
                        A: [State.SUCCEEDED],
                        B: [undefined, State.SUCCEEDED],
                        C: [undefined, undefined, State.SUCCEEDED],
                        $random: Array(30).fill([0.99, 0.5, 0]).flat()
                    }
                ]
            ];

            cases.forEach(([name, definition, script]) => {
                for (let before = 0; before <= 6; before++) {
                    it(`${name}, after ${before} steps`, () => {
                        assertRestoredTreeMatchesOriginal(definition, script, before, 12);
                    });
                }
            });
        });

        describe("keeps how long a wait node has waited, excluding the time between snapshot and restore", () => {
            let clock: SinonFakeTimers;

            beforeEach(() => {
                clock = sinon.useFakeTimers();
            });

            afterEach(() => {
                clock.restore();
            });

            const definition = "root { sequence { wait [1000] action [After] } }";

            const createAfterAgent = (calls: string[]) => ({
                After: () => {
                    calls.push("After");
                    return State.SUCCEEDED;
                }
            });

            it("when using the clock", () => {
                const original = new BehaviourTree(definition, createAfterAgent([]));
                original.step();

                // Time passes after the last step, and is part of what the node has waited for.
                clock.tick(300);
                const snapshot = JSON.parse(JSON.stringify(original.snapshot()));

                // Time passes while the snapshot is stored.
                clock.tick(60000);

                const calls: string[] = [];
                const restored = new BehaviourTree(definition, createAfterAgent(calls));
                restored.restore(snapshot);

                restored.step();
                assert.strictEqual(findNode(restored, "wait").state, State.RUNNING);

                clock.tick(699);
                restored.step();
                assert.strictEqual(findNode(restored, "wait").state, State.RUNNING);
                assert.deepEqual(calls, []);

                clock.tick(1);
                restored.step();
                assert.strictEqual(findNode(restored, "wait").state, State.SUCCEEDED);
                assert.deepEqual(calls, ["After"]);
            });

            it("when restoring into the tree the snapshot was taken from", () => {
                const tree = new BehaviourTree(definition, createAfterAgent([]));
                tree.step();
                clock.tick(400);
                const snapshot = tree.snapshot();

                clock.tick(60000);
                tree.restore(snapshot);

                clock.tick(599);
                tree.step();
                assert.strictEqual(findNode(tree, "wait").state, State.RUNNING);

                clock.tick(1);
                tree.step();
                assert.strictEqual(findNode(tree, "wait").state, State.SUCCEEDED);
            });

            it("when using the 'getDeltaTime' option", () => {
                let deltaTime = 0.4;
                const original = new BehaviourTree(definition, createAfterAgent([]), { getDeltaTime: () => deltaTime });
                original.step();
                const snapshot = JSON.parse(JSON.stringify(original.snapshot()));

                clock.tick(60000);

                deltaTime = 0.3;
                const restored = new BehaviourTree(definition, createAfterAgent([]), { getDeltaTime: () => deltaTime });
                restored.restore(snapshot);

                restored.step();
                assert.strictEqual(findNode(restored, "wait").state, State.RUNNING);

                restored.step();
                assert.strictEqual(findNode(restored, "wait").state, State.SUCCEEDED);
            });

            it("when the snapshot is restored into a tree that uses the other way of measuring time", () => {
                const original = new BehaviourTree(definition, createAfterAgent([]), { getDeltaTime: () => 0.4 });
                original.step();
                const snapshot = original.snapshot();

                const restored = new BehaviourTree(definition, createAfterAgent([]));
                restored.restore(snapshot);

                clock.tick(599);
                restored.step();
                assert.strictEqual(findNode(restored, "wait").state, State.RUNNING);

                clock.tick(1);
                restored.step();
                assert.strictEqual(findNode(restored, "wait").state, State.SUCCEEDED);
            });

            it("and the random duration it picked", () => {
                const randomDefinition = "root { wait [1000, 2000] }";
                const original = new BehaviourTree(randomDefinition, {}, { random: () => 0.5 });
                original.step();
                clock.tick(400);
                const snapshot = JSON.parse(JSON.stringify(original.snapshot()));

                clock.tick(60000);

                const restored = new BehaviourTree(
                    randomDefinition,
                    {},
                    {
                        random: () => {
                            throw new Error("unexpected call to random");
                        }
                    }
                );
                restored.restore(snapshot);

                // The picked duration was 1500ms, 400ms of which has been waited.
                clock.tick(1099);
                restored.step();
                assert.strictEqual(restored.getState(), State.RUNNING);

                clock.tick(1);
                restored.step();
                assert.strictEqual(restored.getState(), State.SUCCEEDED);
            });

            it("and a wait with no duration stays running", () => {
                const original = new BehaviourTree("root { wait }", {});
                original.step();
                const snapshot = JSON.parse(JSON.stringify(original.snapshot()));

                const restored = new BehaviourTree("root { wait }", {});
                restored.restore(snapshot);

                clock.tick(60000);
                restored.step();
                assert.strictEqual(restored.getState(), State.RUNNING);
            });
        });

        describe("restores a finished tree as finished and starts a new run, with new random choices, on the next step", () => {
            const definition = "root { sequence { lotto { action [A] action [B] } repeat [2,4] { action [C] } } }";
            const script = (final: State): Script => ({
                A: [State.SUCCEEDED],
                B: [State.SUCCEEDED],
                C: [State.SUCCEEDED],
                // First run: lotto picks the last child, repeat picks 4 iterations. Second run: the first child, 2 iterations.
                $random: [0.99, 0.99, 0, 0, 0.5, 0.5],
                ...(final === State.FAILED ? { C: [State.FAILED] } : {})
            });

            [State.SUCCEEDED, State.FAILED].forEach((final) => {
                it(`(${final})`, () => {
                    const originalScript = script(final);
                    const originalLog: string[] = [];
                    const original = new BehaviourTree(
                        definition,
                        createAgent(originalScript, originalLog),
                        createOptions(originalScript, originalLog)
                    );

                    while (original.getState() !== final) {
                        original.step();
                    }
                    const snapshot = JSON.parse(JSON.stringify(original.snapshot()));

                    const restoredScript = createScript(originalScript);
                    const restoredLog: string[] = [];
                    const restored = new BehaviourTree(
                        definition,
                        createAgent(restoredScript, restoredLog),
                        createOptions(restoredScript, restoredLog)
                    );
                    restored.restore(snapshot);

                    assert.strictEqual(restored.getState(), final);
                    assert.deepEqual(restoredLog, []);

                    originalLog.length = 0;
                    original.step();
                    restored.step();

                    assert.include(restoredLog, "$random");
                    assert.deepEqual(restoredLog, originalLog);
                    assert.strictEqual(restored.getState(), original.getState());
                    assert.deepEqual(
                        withoutIds(restored.getTreeNodeDetails()),
                        withoutIds(original.getTreeNodeDetails())
                    );
                });
            });
        });

        describe("throws and leaves the tree unchanged if a node snapshot has an invalid", () => {
            const cases: [string, string, (root: any) => void][] = [
                ["repeat target", "root { repeat [2] { action [A] } }", (root) => (root.children[0].targetCount = "2")],
                ["retry count", "root { retry [2] { action [A] } }", (root) => (root.children[0].currentCount = null)],
                [
                    "lotto child",
                    "root { lotto { action [A] action [B] } }",
                    (root) => (root.children[0].selectedChild = 2)
                ],
                [
                    "lotto with no child picked while running",
                    "root { lotto { action [A] action [B] } }",
                    (root) => (root.children[0].selectedChild = null)
                ],
                ["wait duration", "root { wait [1000] }", (root) => (root.children[0].waitedDuration = "1")],
                [
                    "action promise result",
                    "root { action [A] }",
                    (root) => (root.children[0].promiseResult = { isResolved: 1 })
                ]
            ];

            cases.forEach(([name, definition, corrupt]) => {
                it(name, () => {
                    const agent = { A: () => {}, B: () => {} };
                    const source = new BehaviourTree(definition, agent);
                    source.step();
                    const invalid = JSON.parse(JSON.stringify(source.snapshot()));
                    corrupt(invalid.root);

                    const target = new BehaviourTree(definition, agent);
                    const before = JSON.stringify(withoutIds(target.getTreeNodeDetails()));

                    assert.throws(() => target.restore(invalid), Error, "invalid snapshot");
                    assert.strictEqual(JSON.stringify(withoutIds(target.getTreeNodeDetails())), before);
                });
            });
        });

        describe("handles the update promise of an action node", () => {
            const definition = "root { sequence { action [A] action [B] } }";
            const settle = () => new Promise((resolve) => setImmediate(resolve));

            const createAgent = (calls: string[], result: () => Promise<State>) => ({
                A: () => {
                    calls.push("A");
                    return result();
                },
                B: () => {
                    calls.push("B");
                    return State.SUCCEEDED;
                }
            });

            it("keeps a resolved result without calling the action function again", async () => {
                const original = new BehaviourTree(
                    definition,
                    createAgent([], () => Promise.resolve(State.SUCCEEDED))
                );
                original.step();
                await settle();
                const snapshot = JSON.parse(JSON.stringify(original.snapshot()));

                const calls: string[] = [];
                const restored = new BehaviourTree(
                    definition,
                    createAgent(calls, () => Promise.resolve(State.FAILED))
                );
                restored.restore(snapshot);
                restored.step();

                assert.deepEqual(calls, ["B"]);
                assert.strictEqual(restored.getState(), State.SUCCEEDED);
            });

            it("keeps a rejection, which throws the same error as the original", async () => {
                const reject = () => Promise.reject(new Error("boom"));
                const original = new BehaviourTree(definition, createAgent([], reject));
                original.step();
                await settle();
                const snapshot = JSON.parse(JSON.stringify(original.snapshot()));

                let expected = "";
                try {
                    original.step();
                } catch (error) {
                    expected = (error as Error).message;
                }

                const calls: string[] = [];
                const restored = new BehaviourTree(definition, createAgent(calls, reject));
                restored.restore(snapshot);

                assert.throws(() => restored.step(), Error, expected);
                assert.include(expected, "promise rejected with 'Error: boom'");
                assert.deepEqual(calls, []);
            });

            describe("restores an action whose promise is still pending as not started", () => {
                const pending = () => new Promise<State>(() => {});

                it("which calls its entry callback and action function again on the next step", () => {
                    const entryDefinition = "root { sequence { action [A] entry(Enter) action [B] } }";
                    const create = (calls: string[], result: () => Promise<State>) => ({
                        ...createAgent(calls, result),
                        Enter: () => {
                            calls.push("Enter");
                        }
                    });
                    const original = new BehaviourTree(entryDefinition, create([], pending));
                    original.step();
                    const snapshot = JSON.parse(JSON.stringify(original.snapshot()));

                    assert.strictEqual(snapshot.root.children[0].children[0].state, State.READY);
                    assert.strictEqual(snapshot.root.children[0].state, State.RUNNING);

                    const calls: string[] = [];
                    const restored = new BehaviourTree(
                        entryDefinition,
                        create(calls, () => Promise.resolve(State.SUCCEEDED))
                    );
                    restored.restore(snapshot);
                    assert.strictEqual(findNode(restored, "action", "A").state, State.READY);
                    assert.deepEqual(calls, []);

                    restored.step();
                    assert.deepEqual(calls, ["Enter", "A"]);
                    assert.strictEqual(findNode(restored, "action", "A").state, State.RUNNING);
                });

                it("which is not changed by an action that returned no result and is still running", () => {
                    const original = new BehaviourTree("root { action [A] entry(Enter) }", {
                        A: () => {},
                        Enter: () => {}
                    });
                    original.step();

                    assert.strictEqual(original.snapshot().root.children![0].state, State.RUNNING);
                });

                [
                    "sequence",
                    "selector",
                    "parallel",
                    "race",
                    "all",
                    "lotto",
                    "repeat [1]",
                    "retry [1]",
                    "succeed"
                ].forEach((parent) => {
                    it(`under a '${parent}' node, which then finishes when the new promise resolves`, async () => {
                        const parentDefinition = `root { ${parent} { action [A] } }`;
                        const original = new BehaviourTree(parentDefinition, createAgent([], pending));
                        original.step();

                        const calls: string[] = [];
                        const restored = new BehaviourTree(
                            parentDefinition,
                            createAgent(calls, () => Promise.resolve(State.SUCCEEDED))
                        );
                        restored.restore(JSON.parse(JSON.stringify(original.snapshot())));

                        restored.step();
                        assert.deepEqual(calls, ["A"]);
                        assert.strictEqual(restored.getState(), State.RUNNING);

                        await settle();
                        // A repeat node needs one more step to see that it has made all of its iterations.
                        for (let step = 0; step < 3 && restored.isRunning(); step++) {
                            restored.step();
                        }
                        assert.deepEqual(calls, ["A"]);
                        assert.strictEqual(restored.getState(), State.SUCCEEDED);
                    });
                });
            });
        });

        describe("gives a tree that behaves as the original from any point in a run", () => {
            const composite = `root {
                sequence {
                    action [Setup]
                    parallel {
                        sequence {
                            condition [Ready]
                            action [Work] entry(OnEntry) step(OnStep) exit(OnExit)
                        }
                        race {
                            action [A]
                            action [B]
                        }
                    }
                    selector {
                        fail { action [Fail1] }
                        all while(Guard) {
                            action [C]
                            action [D]
                        }
                        action [G]
                    }
                    flip { condition [Cond] }
                    succeed { action [E] }
                }
            }`;

            const script: Script = {
                Setup: [undefined, State.SUCCEEDED],
                Ready: [true],
                Work: [undefined, undefined, State.SUCCEEDED],
                OnEntry: [undefined],
                OnStep: [undefined],
                OnExit: [undefined],
                A: [undefined, undefined, undefined, State.FAILED],
                B: [undefined, undefined, undefined, undefined, State.SUCCEEDED],
                Fail1: [undefined, State.FAILED],
                Guard: [true, true, false],
                C: [undefined, State.SUCCEEDED],
                D: [undefined, undefined, State.FAILED],
                G: [State.SUCCEEDED],
                Cond: [false],
                E: [undefined, State.SUCCEEDED]
            };

            for (let before = 0; before <= 14; before++) {
                it(`after ${before} steps`, () => {
                    assertRestoredTreeMatchesOriginal(composite, script, before, 16);
                });
            }
        });
    });
});
