import { RootNodeDefinition } from "./BehaviourTreeDefinition";

/**
 * Creates a copy of a part of a definition in a canonical form, so that definitions that are equivalent have the same canonical form.
 * - Properties with an undefined value are dropped.
 * - Properties are sorted by name.
 * - Properties that hold the default value that is applied when they are missing are dropped, as the MDSL parser spells out
 *   defaults ('args' of [] and 'succeedOnAbort' of false) that a JSON definition would normally leave out.
 * @param value The part of the definition to get the canonical form of.
 * @returns The canonical form of the given part of a definition.
 */
function canonicalise(value: unknown): unknown {
    if (Array.isArray(value)) {
        return value.map(canonicalise);
    }

    if (typeof value !== "object" || value === null) {
        return value;
    }

    const canonical: { [key: string]: unknown } = {};

    for (const key of Object.keys(value).sort()) {
        const property = (value as { [key: string]: unknown })[key];

        if (property === undefined) {
            continue;
        }

        if (key === "args" && Array.isArray(property) && property.length === 0) {
            continue;
        }

        if (key === "succeedOnAbort") {
            if (property) {
                canonical[key] = true;
            }

            continue;
        }

        canonical[key] = canonicalise(property);
    }

    return canonical;
}

/**
 * Creates a 53 bit hash of a string (cyrb53), which is not cryptographically secure but has a very low chance of collisions.
 * @param text The string to hash.
 * @param seed The seed, for creating different hashes for the same string.
 * @returns The hash.
 */
function hash(text: string, seed: number): number {
    let h1 = 0xdeadbeef ^ seed;
    let h2 = 0x41c6ce57 ^ seed;

    for (let index = 0; index < text.length; index++) {
        const code = text.charCodeAt(index);
        h1 = Math.imul(h1 ^ code, 2654435761);
        h2 = Math.imul(h2 ^ code, 1597334677);
    }

    h1 = Math.imul(h1 ^ (h1 >>> 16), 2246822507) ^ Math.imul(h2 ^ (h2 >>> 13), 3266489909);
    h2 = Math.imul(h2 ^ (h2 >>> 16), 2246822507) ^ Math.imul(h1 ^ (h1 >>> 13), 3266489909);

    return 4294967296 * (2097151 & h2) + (h1 >>> 0);
}

/**
 * Creates a fingerprint of a tree definition, which is the same for equivalent definitions, such as an MDSL definition and the
 * JSON definition that it converts to, and which is different for any definitions that are not equivalent.
 * @param rootNodeDefinitions The JSON definition of the tree, as an array of root node definitions.
 * @returns The fingerprint of the definition.
 */
export function createDefinitionFingerprint(rootNodeDefinitions: RootNodeDefinition[]): string {
    // The order of the root nodes is not significant, so put the main root node (which has no 'id') first and then the rest by 'id'.
    const orderedRootNodeDefinitions = [...rootNodeDefinitions].sort(({ id: a = "" }, { id: b = "" }) =>
        a < b ? -1 : a > b ? 1 : 0
    );

    const text = JSON.stringify(canonicalise(orderedRootNodeDefinitions));

    return [hash(text, 0), hash(text, 1)].map((value) => value.toString(16).padStart(14, "0")).join("");
}
