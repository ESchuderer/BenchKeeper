import type Node from "./nodes/Node";
import { AnyState, CompleteState } from "./State";

/**
 * A serializable snapshot of the execution state of a single node in a behaviour tree.
 * Snapshots of nodes mirror the structure of the tree, and are matched up with the nodes of a tree by their position.
 */
export type NodeSnapshot = {
    /**
     * The node type.
     */
    type: string;
    /**
     * The state of the node.
     */
    state: AnyState;
    /**
     * The snapshots of the child nodes of this node, defined if this node is a composite or decorator node.
     */
    children?: NodeSnapshot[];
    /**
     * The index of the child node that was selected, defined if this is a lotto node that is not in the READY state.
     */
    selectedChildIndex?: number;
    /**
     * The number of iterations completed, defined if this is a repeat node.
     */
    currentIterationCount?: number;
    /**
     * The number of iterations to complete (selected at random if bounds were defined), or null if unlimited, defined if this is a repeat node.
     */
    targetIterationCount?: number | null;
    /**
     * The number of attempts made, defined if this is a retry node.
     */
    currentAttemptCount?: number;
    /**
     * The number of attempts to make (selected at random if bounds were defined), or null if unlimited, defined if this is a retry node.
     */
    targetAttemptCount?: number | null;
    /**
     * The duration to wait for in milliseconds (selected at random if bounds were defined), or null if the node is not running or waits indefinitely, defined if this is a wait node.
     */
    totalDuration?: number | null;
    /**
     * The time already waited in milliseconds, or 0 if the node is not running, defined if this is a wait node.
     * This is the time waited as of when the snapshot was taken, regardless of whether the clock or the 'getDeltaTime' option is used.
     */
    waitedDuration?: number;
    /**
     * The resolved state that a running action node is yet to move into, defined if the action function returned a promise that has since resolved.
     * An action node whose promise has not settled has no outcome to capture, so it is captured as not started with a state of READY.
     */
    promiseResult?: CompleteState;
};

/**
 * A serializable snapshot of the execution state of a behaviour tree.
 * This is a plain object that survives `JSON.stringify` and `JSON.parse` unchanged.
 */
export type BehaviourTreeSnapshot = {
    /**
     * The version of the snapshot format.
     */
    version: 1;
    /**
     * A fingerprint of the definition of the tree that the snapshot was taken from, which is the same for an MDSL definition and its equivalent JSON definition.
     * A snapshot can only be restored to a tree that was built from a definition with the same fingerprint.
     */
    definition: string;
    /**
     * The snapshot of the main root node of the tree.
     */
    root: NodeSnapshot;
};

/**
 * The current version of the snapshot format.
 */
export const SNAPSHOT_VERSION = 1;

/**
 * Asserts that the given snapshot value is a non-null object.
 * @param value The snapshot value to check.
 * @param path The path of the value within the snapshot, for use in error messages.
 */
export function assertIsObject(value: unknown, path: string): asserts value is { [key: string]: unknown } {
    if (typeof value !== "object" || value === null || Array.isArray(value)) {
        throw new Error(`expected '${path}' to be an object`);
    }
}

/**
 * Asserts that the given snapshot value is a non-negative integer.
 * @param value The snapshot value to check.
 * @param path The path of the value within the snapshot, for use in error messages.
 */
export function assertIsNonNegativeInteger(value: unknown, path: string): asserts value is number {
    if (!Number.isInteger(value) || (value as number) < 0) {
        throw new Error(`expected '${path}' to be a non-negative integer but it was '${value}'`);
    }
}

/**
 * Asserts that the given snapshot value is null or a non-negative integer.
 * @param value The snapshot value to check.
 * @param path The path of the value within the snapshot, for use in error messages.
 */
export function assertIsNullOrNonNegativeInteger(value: unknown, path: string): asserts value is number | null {
    if (value !== null && (!Number.isInteger(value) || (value as number) < 0)) {
        throw new Error(`expected '${path}' to be null or a non-negative integer but it was '${value}'`);
    }
}

/**
 * Asserts that the given snapshot value is a finite number.
 * @param value The snapshot value to check.
 * @param path The path of the value within the snapshot, for use in error messages.
 */
export function assertIsFiniteNumber(value: unknown, path: string): asserts value is number {
    if (typeof value !== "number" || !Number.isFinite(value)) {
        throw new Error(`expected '${path}' to be a finite number but it was '${value}'`);
    }
}

/**
 * Asserts that the child snapshots of a snapshot match up with the given child nodes, and that each of them is valid.
 * @param snapshot The snapshot of the parent node.
 * @param path The path of the snapshot of the parent node, for use in error messages.
 * @param children The child nodes of the parent node.
 */
export function assertChildSnapshotsAreValid(snapshot: { [key: string]: unknown }, path: string, children: Node[]) {
    const childrenPath = `${path}.children`;

    if (!Array.isArray(snapshot.children)) {
        throw new Error(`expected '${childrenPath}' to be an array`);
    }

    const childSnapshots: unknown[] = snapshot.children;

    if (childSnapshots.length !== children.length) {
        throw new Error(
            `expected '${childrenPath}' to have ${children.length} elements but it had ${childSnapshots.length}`
        );
    }

    children.forEach((child, index) => child.validateSnapshot(childSnapshots[index], `${childrenPath}[${index}]`));
}
