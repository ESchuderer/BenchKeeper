import Node, { NodeDetails } from "../Node";
import State from "../../State";
import { Agent } from "../../Agent";
import Attribute from "../../attributes/Attribute";
import { BehaviourTreeOptions } from "../../BehaviourTreeOptions";
import { NodeSnapshot, assertChildSnapshotsAreValid } from "../../BehaviourTreeSnapshot";

/**
 * A decorator node that wraps a single child node.
 */
export default abstract class Decorator extends Node {
    /**
     * @param type The node type.
     * @param attributes The node attributes.
     * @param options The behaviour tree options.
     * @param child The child node.
     */
    constructor(type: string, attributes: Attribute[], options: BehaviourTreeOptions, protected child: Node) {
        super(type, attributes, options);
    }

    /**
     * Gets the children of this node.
     */
    getChildren = () => [this.child];

    /**
     * Reset the state of the node.
     */
    reset = () => {
        // Reset the state of this node.
        this.setState(State.READY);

        // Reset the state of the child node.
        this.child.reset();
    };

    /**
     * Abort the running of this node.
     * @param agent The agent.
     */
    abort = (agent: Agent) => {
        // There is nothing to do if this node is not in the running state.
        if (!this.is(State.RUNNING)) {
            return;
        }

        // Abort the child node.
        this.child.abort(agent);

        // Reset the state of this node.
        this.reset();

        this.attributes.exit?.callAgentFunction(agent, false, true);
    };

    /**
     * Gets the details of this node instance.
     * @returns The details of this node instance.
     */
    public getDetails(): NodeDetails {
        return {
            ...super.getDetails(),
            children: [this.child.getDetails()]
        };
    }

    /**
     * Gets a snapshot of the execution state of this node and its children.
     * @returns A snapshot of the execution state of this node and its children.
     */
    public getSnapshot(): NodeSnapshot {
        return {
            ...super.getSnapshot(),
            children: [this.child.getSnapshot()]
        };
    }

    /**
     * Asserts that the given snapshot can be restored to this node and its children, throwing an error if it cannot.
     * @param snapshot The snapshot to validate.
     * @param path The path of the snapshot within the tree snapshot, for use in error messages.
     */
    public validateSnapshot(snapshot: unknown, path: string): asserts snapshot is NodeSnapshot {
        super.validateSnapshot(snapshot, path);

        assertChildSnapshotsAreValid(snapshot, path, [this.child]);
    }

    /**
     * Restores this node and its children to the execution state of the given snapshot, which must have been validated.
     * @param snapshot The snapshot to restore.
     */
    public restoreSnapshot(snapshot: NodeSnapshot): void {
        super.restoreSnapshot(snapshot);

        this.child.restoreSnapshot(snapshot.children![0]);
    }
}
