import { BehaviourTreeOptions } from "../../BehaviourTreeOptions";
import { NodeDetails } from "../Node";
import State, { CompleteState } from "../../State";
import { Agent } from "../../Agent";
import Leaf from "./Leaf";
import Lookup from "../../Lookup";
import Attribute from "../../attributes/Attribute";
import { NodeSnapshot } from "../../BehaviourTreeSnapshot";

/**
 * The type representing a resolved/rejected update promise.
 */
type UpdatePromiseResult = {
    /**
     * Whether the promise was resolved rather than rejected.
     */
    isResolved: boolean;

    /**
     * The promise resolved value or rejection reason.
     */
    value: any;
};

/**
 * An Action leaf node.
 * This represents an immediate or ongoing state of behaviour.
 */
export default class Action extends Leaf {
    /**
     * @param attributes The node attributes.
     * @param options The behaviour tree options.
     * @param actionName The action name.
     * @param actionArguments The array of action arguments.
     */
    constructor(
        attributes: Attribute[],
        options: BehaviourTreeOptions,
        private actionName: string,
        public actionArguments: any[]
    ) {
        super("action", attributes, options);
    }

    /**
     * Whether there is a pending update promise.
     */
    private isUsingUpdatePromise = false;

    /**
     * The finished state result of an update promise.
     */
    private updatePromiseResult: UpdatePromiseResult | null = null;

    /**
     * The generation of update promise that we care about, which changes whenever the update promise is cleared.
     * This is used to ignore a promise that settles after it was cleared, even if a newer promise has since been created.
     */
    private updatePromiseGeneration = 0;

    /**
     * Called when the node is being updated.
     * @param agent The agent.
     */
    protected onUpdate(agent: Agent): void {
        // If the result of this action depends on an update promise then there is nothing to do until it settles.
        if (this.isUsingUpdatePromise) {
            // Are we still waiting for our update promise to settle?
            if (!this.updatePromiseResult) {
                return;
            }

            const { isResolved, value } = this.updatePromiseResult;

            // Our update promise settled, was it resolved or rejected?
            if (isResolved) {
                // Our promise resolved so check to make sure the result is a valid finished state.
                if (value !== State.SUCCEEDED && value !== State.FAILED) {
                    throw new Error(
                        "action node promise resolved with an invalid value, expected a State.SUCCEEDED or State.FAILED value to be returned"
                    );
                }

                // Set the state of this node to match the state returned by the promise.
                this.setState(value);

                return;
            } else {
                // The promise was rejected, which isn't great.
                throw new Error(`action function '${this.actionName}' promise rejected with '${value}'`);
            }
        }

        // Attempt to get the invoker for the action function.
        const actionFuncInvoker = Lookup.getFuncInvoker(agent, this.actionName);

        // The action function should be defined.
        if (actionFuncInvoker === null) {
            throw new Error(
                `cannot update action node as the action '${this.actionName}' function is not defined on the agent and has not been registered`
            );
        }

        let actionFunctionResult;

        try {
            // Call the action function, the result of which may be:
            // - The finished state of this action node.
            // - A promise to return a finished node state.
            // - Undefined if the node should remain in the running state.
            actionFunctionResult = actionFuncInvoker(this.actionArguments) as CompleteState | Promise<CompleteState>;
        } catch (error) {
            // An uncaught error was thrown.
            if (error instanceof Error) {
                throw new Error(`action function '${this.actionName}' threw: ${error.stack}`);
            } else {
                throw new Error(`action function '${this.actionName}' threw: ${error}`);
            }
        }

        if (actionFunctionResult instanceof Promise) {
            const generation = this.updatePromiseGeneration;

            actionFunctionResult.then(
                (result) => {
                    // If the generation has changed then the promise was cleared as it was resolving, probably via an abort, reset or restore.
                    if (generation !== this.updatePromiseGeneration) {
                        return;
                    }

                    // Set the resolved update promise result so that it can be handled on the next update of this node.
                    this.updatePromiseResult = {
                        isResolved: true,
                        value: result
                    };
                },
                (reason) => {
                    // If the generation has changed then the promise was cleared as it was resolving, probably via an abort, reset or restore.
                    if (generation !== this.updatePromiseGeneration) {
                        return;
                    }

                    // Set the rejected update promise result so that it can be handled on the next update of this node.
                    this.updatePromiseResult = {
                        isResolved: false,
                        value: reason
                    };
                }
            );

            // This node will be in the 'RUNNING' state until the update promise resolves.
            this.setState(State.RUNNING);

            // We are now waiting for the promise returned by the use to resolve before we know what state this node is in.
            this.isUsingUpdatePromise = true;
        } else {
            // Validate the returned value.
            this.validateUpdateResult(actionFunctionResult);

            // Set the state of this node, this may be undefined, which just means that the node is still in the 'RUNNING' state.
            this.setState(actionFunctionResult || State.RUNNING);
        }
    }

    /**
     * Gets the name of the node.
     */
    getName = () => this.actionName;

    /**
     * Reset the state of the node.
     */
    reset = () => {
        // Reset the state of this node.
        this.setState(State.READY);

        // There is no longer an update promise that we care about.
        this.isUsingUpdatePromise = false;
        this.updatePromiseResult = null;
        this.updatePromiseGeneration++;
    };

    /**
     * Gets a snapshot of the execution state of this node.
     * A promise can't be captured, so a node that is waiting on a promise that has not settled is captured as one that has not started, and will call its
     * action function again after being restored. This will throw an error if the promise was rejected or resolved with an invalid value.
     * @returns A snapshot of the execution state of this node.
     */
    public getSnapshot(): NodeSnapshot {
        const snapshot = super.getSnapshot();

        // Only a running action can be waiting on an update promise.
        if (!this.is(State.RUNNING) || !this.isUsingUpdatePromise) {
            return snapshot;
        }

        const cannotCapture = (reason: string) =>
            new Error(
                `cannot capture the state of action node '${this.actionName}' as the promise returned by the function ${reason}`
            );

        // The promise is still pending, so there is no outcome to capture, and the best we can do is for the action to start again.
        if (!this.updatePromiseResult) {
            return { ...snapshot, state: State.READY };
        }

        const { isResolved, value } = this.updatePromiseResult;

        if (!isResolved) {
            throw cannotCapture("was rejected");
        }

        if (value !== State.SUCCEEDED && value !== State.FAILED) {
            throw cannotCapture("resolved with an invalid value");
        }

        snapshot.promiseResult = value;

        return snapshot;
    }

    /**
     * Asserts that the given snapshot can be restored to this node, throwing an error if it cannot.
     * @param snapshot The snapshot to validate.
     * @param path The path of the snapshot within the tree snapshot, for use in error messages.
     */
    public validateSnapshot(snapshot: unknown, path: string): asserts snapshot is NodeSnapshot {
        super.validateSnapshot(snapshot, path);

        if (snapshot.promiseResult === undefined) {
            return;
        }

        if (snapshot.state !== State.RUNNING) {
            throw new Error(`expected '${path}.promiseResult' to not be defined for a node that is not running`);
        }

        if (snapshot.promiseResult !== State.SUCCEEDED && snapshot.promiseResult !== State.FAILED) {
            throw new Error(
                `expected '${path}.promiseResult' to be a resolved node state but it was '${snapshot.promiseResult}'`
            );
        }
    }

    /**
     * Restores this node to the execution state of the given snapshot, which must have been validated.
     * @param snapshot The snapshot to restore.
     */
    public restoreSnapshot(snapshot: NodeSnapshot): void {
        // Anything we were waiting on is no longer relevant.
        this.updatePromiseGeneration++;

        if (snapshot.promiseResult === undefined) {
            this.isUsingUpdatePromise = false;
            this.updatePromiseResult = null;
        } else {
            // The promise itself is gone, but the outcome of it is all that is needed to be handled on the next update of this node.
            this.isUsingUpdatePromise = true;
            this.updatePromiseResult = { isResolved: true, value: snapshot.promiseResult };
        }

        super.restoreSnapshot(snapshot);
    }

    /**
     * Gets the details of this node instance.
     * @returns The details of this node instance.
     */
    public getDetails(): NodeDetails {
        return {
            ...super.getDetails(),
            args: this.actionArguments
        };
    }

    /**
     * Called when the state of this node changes.
     * @param previousState The previous node state.
     */
    protected onStateChanged(previousState: State): void {
        this.options.onNodeStateChange?.({
            id: this.uid,
            type: this.getType(),
            args: this.actionArguments,
            while: this.attributes.while?.getDetails(),
            until: this.attributes.until?.getDetails(),
            entry: this.attributes.entry?.getDetails(),
            step: this.attributes.step?.getDetails(),
            exit: this.attributes.exit?.getDetails(),
            previousState,
            state: this.getState()
        });
    }

    /**
     * Validate the result of an update function call.
     * @param result The result of an update function call.
     */
    private validateUpdateResult = (result: CompleteState | State.RUNNING) => {
        switch (result) {
            case State.SUCCEEDED:
            case State.FAILED:
            case State.RUNNING:
            case undefined:
                return;
            default:
                throw new Error(
                    `expected action function '${this.actionName}' to return an optional State.SUCCEEDED or State.FAILED value but returned '${result}'`
                );
        }
    };
}
