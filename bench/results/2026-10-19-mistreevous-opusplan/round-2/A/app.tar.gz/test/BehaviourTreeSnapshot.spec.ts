import { assert } from "chai";
import sinon, { SinonFakeTimers } from "sinon";

import { BehaviourTree, BehaviourTreeSnapshot, State, convertMDSLToJSON } from "../src/index";

import {
    assertRestoredTreesBehaveLikeTheOriginal,
    createAgent,
    createRandom,
    withoutIds
} from "./SnapshotTestUtilities";

describe("A BehaviourTree", () => {
    let clock: SinonFakeTimers;

    beforeEach(() => {
        clock = sinon.useFakeTimers({ now: 1_000_000, toFake: ["Date"] });
    });

    afterEach(() => {
        clock.restore();
    });

    describe("snapshot", () => {
        describe("returns a plain object that", () => {
            const definition = `root {
                sequence {
                    action [Work, 3]
                    condition [IsOdd]
                }
            }`;

            it("describes the structure of the tree and the state of each node", () => {
                const tree = new BehaviourTree(definition, { Work: () => State.RUNNING, IsOdd: () => true });

                tree.step();

                assert.deepEqual(tree.snapshot(), {
                    version: 1,
                    definition: tree.snapshot().definition,
                    root: {
                        type: "root",
                        state: State.RUNNING,
                        children: [
                            {
                                type: "sequence",
                                state: State.RUNNING,
                                children: [
                                    { type: "action", state: State.RUNNING },
                                    { type: "condition", state: State.READY }
                                ]
                            }
                        ]
                    }
                } as BehaviourTreeSnapshot);
            });

            it("is unchanged by a round trip through JSON", () => {
                const tree = new BehaviourTree(definition, { Work: () => State.RUNNING, IsOdd: () => true });

                tree.step();

                const snapshot = tree.snapshot();

                assert.deepEqual(JSON.parse(JSON.stringify(snapshot)), snapshot);
            });

            it("is independent of the tree", () => {
                const tree = new BehaviourTree(definition, { Work: () => State.RUNNING, IsOdd: () => true });

                tree.step();

                const snapshot = tree.snapshot();
                const original = JSON.stringify(snapshot);

                // Changing the snapshot must not change the tree.
                snapshot.root.state = State.FAILED;
                (snapshot.root.children as any[])[0].children[0].state = State.FAILED;

                assert.strictEqual(tree.getState(), State.RUNNING);
                assert.strictEqual(JSON.stringify(tree.snapshot()), original);
            });
        });

        it("does not call any agent functions, 'random' or 'getDeltaTime'", () => {
            const calls: string[] = [];
            const agent = { Work: () => (calls.push("Work"), State.RUNNING) };
            const tree = new BehaviourTree("root { repeat [1, 3] { wait [10, 100] } }", agent, {
                random: () => (calls.push("random"), 0.5),
                getDeltaTime: () => (calls.push("getDeltaTime"), 0.01)
            });

            tree.step();
            calls.length = 0;

            tree.snapshot();

            assert.deepEqual(calls, []);
        });
    });

    describe("restore", () => {
        it("sets the state of every node in a tree that was built from the same definition", () => {
            const definition = `root {
                sequence {
                    selector {
                        condition [IsOdd]
                        action [Work, 3]
                    }
                    action [Work, 5]
                }
            }`;
            const agent = { Work: () => State.RUNNING, IsOdd: () => false };

            const source = new BehaviourTree(definition, agent);
            source.step();

            const target = new BehaviourTree(definition, agent);
            target.restore(JSON.parse(JSON.stringify(source.snapshot())));

            assert.deepEqual(withoutIds(target.getTreeNodeDetails()), withoutIds(source.getTreeNodeDetails()));
            assert.strictEqual(target.getState(), State.RUNNING);
            assert.isTrue(target.isRunning());
        });

        it("sets a tree that has already been stepped back to the state of the snapshot", () => {
            const definition = "root { sequence { action [Work, 1] action [Work, 2] } }";
            let result: State.SUCCEEDED | State.RUNNING = State.SUCCEEDED;
            const tree = new BehaviourTree(definition, { Work: () => result });

            const beforeStep = tree.snapshot();
            tree.step();
            assert.strictEqual(tree.getState(), State.SUCCEEDED);

            tree.restore(beforeStep);

            assert.strictEqual(tree.getState(), State.READY);
            assert.deepEqual(tree.snapshot(), beforeStep);

            result = State.RUNNING;
            tree.step();
            assert.strictEqual(tree.getState(), State.RUNNING);
        });

        it("does not call any agent functions, 'random' or 'getDeltaTime'", () => {
            const calls: string[] = [];
            const definition = "root { sequence { action [Work] entry(Entered) wait [10, 100] } }";
            const options = {
                random: () => (calls.push("random"), 0.5),
                getDeltaTime: () => (calls.push("getDeltaTime"), 0.01)
            };
            const agent = {
                Work: () => (calls.push("Work"), State.SUCCEEDED),
                Entered: () => calls.push("Entered")
            };

            const source = new BehaviourTree(definition, agent, options);
            source.step();
            calls.length = 0;

            new BehaviourTree(definition, agent, options).restore(source.snapshot());

            assert.deepEqual(calls, []);
        });

        describe("does not call onNodeStateChange", () => {
            const definition = "root { sequence { action [Work] wait [100] action [Hold] } }";
            const agent = { Work: () => State.SUCCEEDED, Hold: () => State.RUNNING };

            const createChangeLog = () => {
                const changes: string[] = [];

                return {
                    changes,
                    options: {
                        onNodeStateChange: ({ type, previousState, state }: any) =>
                            changes.push(`${type}: ${previousState} -> ${state}`)
                    }
                };
            };

            it("when restoring a snapshot into a new tree", () => {
                const source = new BehaviourTree(definition, agent);
                source.step();
                assert.notStrictEqual(source.getState(), State.READY);

                const { changes, options } = createChangeLog();
                const target = new BehaviourTree(definition, agent, options);
                target.restore(JSON.parse(JSON.stringify(source.snapshot())));

                assert.deepEqual(withoutIds(target.getTreeNodeDetails()), withoutIds(source.getTreeNodeDetails()));
                assert.deepEqual(changes, []);
            });

            it("when restoring a snapshot into a tree that has already been stepped", () => {
                const { changes, options } = createChangeLog();
                const tree = new BehaviourTree(definition, agent, options);
                const beforeStep = tree.snapshot();

                tree.step();
                changes.length = 0;

                tree.restore(beforeStep);

                assert.strictEqual(tree.getState(), State.READY);
                assert.deepEqual(changes, []);
            });

            it("but still calls it for the changes of the next step", () => {
                const source = new BehaviourTree(definition, agent);
                source.step();
                const snapshot = source.snapshot();

                const { changes, options } = createChangeLog();
                const target = new BehaviourTree(definition, agent, options);
                target.restore(snapshot);
                assert.deepEqual(changes, []);

                // Let the wait node finish, which carries the sequence on to the last action.
                clock.tick(100);
                target.step();

                assert.deepEqual(changes, [
                    `wait: ${State.RUNNING} -> ${State.SUCCEEDED}`,
                    `action: ${State.READY} -> ${State.RUNNING}`
                ]);
            });

            it("and still calls it for state changes after a restore that was rejected", () => {
                const { changes, options } = createChangeLog();
                const tree = new BehaviourTree(definition, agent, options);
                const invalid = tree.snapshot();
                invalid.root.state = "invalid" as any;

                assert.throws(() => tree.restore(invalid));
                assert.deepEqual(changes, []);

                tree.step();
                assert.isAbove(changes.length, 0);
            });
        });

        describe("will error and leave the tree unchanged if the snapshot", () => {
            const definition = "root { sequence { action [Work] condition [IsOdd] } }";
            const agent = { Work: () => State.RUNNING, IsOdd: () => true };

            const createSnapshot = () => {
                const source = new BehaviourTree(definition, agent);
                source.step();
                return JSON.parse(JSON.stringify(source.snapshot()));
            };

            const assertRestoreFails = (snapshot: any, message: string) => {
                const tree = new BehaviourTree(definition, agent);
                tree.step();
                tree.step();
                const before = JSON.stringify(tree.snapshot());

                assert.throws(() => tree.restore(snapshot), Error, message);
                assert.strictEqual(JSON.stringify(tree.snapshot()), before);
            };

            it("is not defined", () => {
                assertRestoreFails(undefined, "invalid snapshot: expected 'snapshot' to be an object");
                assertRestoreFails(null, "invalid snapshot: expected 'snapshot' to be an object");
                assertRestoreFails("snapshot", "invalid snapshot: expected 'snapshot' to be an object");
            });

            it("has an unsupported version", () => {
                assertRestoreFails({ ...createSnapshot(), version: 2 }, "invalid snapshot: unsupported version '2'");
                assertRestoreFails(
                    { root: createSnapshot().root },
                    "invalid snapshot: unsupported version 'undefined'"
                );
            });

            it("has no root node", () => {
                assertRestoreFails({ version: 1 }, "invalid snapshot: expected 'root' to be an object");
            });

            it("has a node of the wrong type", () => {
                const snapshot = createSnapshot();
                snapshot.root.children[0].children[1].type = "action";

                assertRestoreFails(
                    snapshot,
                    "invalid snapshot: expected 'root.children[0].children[1]' to be a 'condition' node but it was a 'action' node"
                );
            });

            it("has a node with an invalid state", () => {
                const snapshot = createSnapshot();
                snapshot.root.children[0].state = "mistreevous.sleeping";

                assertRestoreFails(
                    snapshot,
                    "invalid snapshot: expected 'root.children[0].state' to be a valid node state but it was 'mistreevous.sleeping'"
                );
            });

            it("has a node with the wrong number of children", () => {
                const snapshot = createSnapshot();
                snapshot.root.children[0].children.pop();

                assertRestoreFails(
                    snapshot,
                    "invalid snapshot: expected 'root.children[0].children' to have 2 elements but it had 1"
                );
            });

            it("has a node with no children array", () => {
                const snapshot = createSnapshot();
                delete snapshot.root.children;

                assertRestoreFails(snapshot, "invalid snapshot: expected 'root.children' to be an array");
            });
        });
    });

    describe("a snapshot is independent of the trees that it was taken from and restored to", () => {
        const definitions: { [description: string]: string } = {
            "sequence, selector and parallel nodes": `root {
                sequence {
                    selector { condition [IsOdd] action [Work, 4] }
                    parallel { action [Work, 6] sequence { action [Work, 5] action [Work, 8] } }
                }
            }`,
            "repeat and retry nodes": `root {
                sequence {
                    repeat [2, 5] { action [Tick, 3] }
                    retry [2, 5] { action [Trip, 3] }
                }
            }`,
            "lotto nodes": `root {
                repeat [4] { lotto [1, 4, 2] { action [Tick, 2] sequence { action [Tick, 3] action [Tick, 2] } action [Trip, 4] } }
            }`,
            "wait nodes": `root { repeat [3, 5] { sequence { wait [150, 450] action [Tick, 2] wait [100] } } }`,
            "race and all nodes": `root {
                sequence {
                    race { action [Work, 6] action [Fussy, 9] }
                    all { action [Work, 10] condition [IsOdd] }
                }
            }`
        };

        for (const [description, definition] of Object.entries(definitions)) {
            for (const useDeltaTime of [false, true]) {
                it(`(${description}${useDeltaTime ? ", using 'getDeltaTime'" : ""})`, () => {
                    const createTree = (world: { step: number }) =>
                        new BehaviourTree(definition, createAgent(world, []), {
                            random: createRandom([0.1, 0.9, 0.5, 0.3, 0.7]),
                            ...(useDeltaTime ? { getDeltaTime: () => 0.1 } : {})
                        });

                    const world = { step: 0 };
                    const tree = createTree(world);
                    const restoredWorld = { step: 0 };
                    const restored = createTree(restoredWorld);

                    for (let step = 1; step <= 30; step++) {
                        clock.tick(100);
                        world.step = step;
                        tree.step();

                        // Take a snapshot between steps, then carry on stepping the tree that it was taken from.
                        clock.tick(30);
                        const snapshot = tree.snapshot();
                        const original = JSON.stringify(snapshot);

                        for (let after = 0; after < 3; after++) {
                            clock.tick(100);
                            world.step++;
                            tree.step();
                        }

                        assert.strictEqual(
                            JSON.stringify(snapshot),
                            original,
                            `stepping the tree changed the snapshot of step ${step}`
                        );

                        // Restore the snapshot into another tree, which should be left in the state that the snapshot describes.
                        restored.restore(snapshot);

                        assert.deepEqual(
                            JSON.parse(JSON.stringify(restored.snapshot())),
                            JSON.parse(original),
                            `the snapshot of step ${step} differs from a snapshot taken after restoring it`
                        );

                        restoredWorld.step = step;

                        for (let after = 0; after < 3; after++) {
                            clock.tick(100);
                            restoredWorld.step++;
                            restored.step();
                        }

                        assert.strictEqual(
                            JSON.stringify(snapshot),
                            original,
                            `stepping the restored tree changed the snapshot of step ${step}`
                        );
                    }
                });
            }
        }

        it("(an action that is waiting on a promise)", async () => {
            let resolve!: (state: State.SUCCEEDED) => void;
            const agent = { Work: () => new Promise<State.SUCCEEDED>((r) => (resolve = r)) };
            const definition = "root { sequence { action [Work] action [Work] } }";

            const tree = new BehaviourTree(definition, agent);
            tree.step();

            const pending = tree.snapshot();
            const pendingJSON = JSON.stringify(pending);

            resolve(State.SUCCEEDED);
            await Promise.resolve();

            const settled = tree.snapshot();
            const settledJSON = JSON.stringify(settled);
            assert.notStrictEqual(settledJSON, pendingJSON);

            // The tree moving on does not change the snapshots of it.
            tree.step();
            await Promise.resolve();
            assert.strictEqual(JSON.stringify(pending), pendingJSON);
            assert.strictEqual(JSON.stringify(settled), settledJSON);

            // Restoring and stepping does not change them either, and a snapshot taken straight after a restore is the same.
            const restored = new BehaviourTree(definition, agent);

            for (const [snapshot, json] of [
                [pending, pendingJSON],
                [settled, settledJSON]
            ] as const) {
                restored.restore(snapshot);
                assert.deepEqual(JSON.parse(JSON.stringify(restored.snapshot())), JSON.parse(json));

                restored.step();
                await Promise.resolve();
                restored.step();
                assert.strictEqual(JSON.stringify(snapshot), json);
            }
        });
    });

    describe("snapshot and restore of a tree definition", () => {
        const agent = {
            prop: 1,
            Work: () => State.RUNNING,
            Other: () => State.RUNNING,
            IsOdd: () => true,
            Guarded: () => true,
            Done: () => {}
        };

        const mdsl = `root {
            sequence {
                action [Work, 3]
                condition [IsOdd]
                wait [100]
            }
        }`;

        const snapshotOf = (definition: any) => {
            const tree = new BehaviourTree(definition, agent);
            tree.step();
            return JSON.parse(JSON.stringify(tree.snapshot())) as BehaviourTreeSnapshot;
        };

        /** Asserts that a snapshot is rejected, and that the rejected restore leaves the tree exactly as it was. */
        const assertRestoreRejected = (definition: any, snapshot: any, message: string | RegExp) => {
            const tree = new BehaviourTree(definition, agent);
            tree.step();
            const snapshotBefore = JSON.stringify(tree.snapshot());
            const detailsBefore = JSON.stringify(tree.getTreeNodeDetails());
            const stateChanges: string[] = [];
            const observed = new BehaviourTree(definition, agent, {
                onNodeStateChange: (change) => stateChanges.push(change.type)
            });
            observed.step();
            stateChanges.length = 0;

            assert.throws(() => tree.restore(snapshot), Error, message);
            assert.throws(() => observed.restore(snapshot), Error, message);

            assert.strictEqual(JSON.stringify(tree.snapshot()), snapshotBefore);
            assert.strictEqual(JSON.stringify(tree.getTreeNodeDetails()), detailsBefore);
            assert.deepEqual(stateChanges, [], "a rejected restore called onNodeStateChange");
        };

        const MISMATCH = /does not match the tree's definition/;

        describe("returns a snapshot that", () => {
            it("records the definition that the tree was built from", () => {
                const { definition } = snapshotOf(mdsl);

                assert.isString(definition);
                assert.isNotEmpty(definition);
            });

            it("records the same definition for trees built from the same definition", () => {
                assert.strictEqual(snapshotOf(mdsl).definition, snapshotOf(mdsl).definition);
            });

            it("records the same definition whatever the state of the tree", () => {
                const tree = new BehaviourTree(mdsl, agent);
                const before = tree.snapshot().definition;
                tree.step();

                assert.strictEqual(tree.snapshot().definition, before);
            });

            it("records different definitions for trees built from different definitions", () => {
                const definitions = [
                    mdsl,
                    mdsl.replace("[Work, 3]", "[Work, 4]"),
                    mdsl.replace("[Work, 3]", "[Other, 3]"),
                    mdsl.replace("[Work, 3]", "[Work, 3] while(Guarded)"),
                    mdsl.replace("[Work, 3]", "[Work, 3] while(Guarded) entry(Done)"),
                    mdsl.replace("[Work, 3]", "[Work, 3] until(Guarded) then succeed"),
                    mdsl.replace("[Work, 3]", "[Work, 3] until(Guarded) then fail"),
                    mdsl.replace("wait [100]", "wait [101]"),
                    mdsl.replace("wait [100]", "wait [100, 200]"),
                    mdsl.replace("sequence", "selector"),
                    mdsl.replace("condition [IsOdd]", "condition [IsOdd] condition [IsOdd]"),
                    `root { sequence { action [Work, 3] condition [IsOdd] wait [100] } } root [other] { action [Done] }`
                ].map((definition) => snapshotOf(definition).definition);

                assert.strictEqual(new Set(definitions).size, definitions.length);
            });
        });

        describe("restore will error and leave the tree unchanged if the snapshot was taken from a tree with", () => {
            it("a different structure", () => {
                assertRestoreRejected(mdsl, snapshotOf("root { action [Work, 3] }"), MISMATCH);
                assertRestoreRejected(mdsl, snapshotOf(mdsl.replace("sequence", "selector")), MISMATCH);
            });

            it("the same structure but different node details", () => {
                assertRestoreRejected(mdsl, snapshotOf(mdsl.replace("[Work, 3]", "[Other, 3]")), MISMATCH);
                assertRestoreRejected(mdsl, snapshotOf(mdsl.replace("[Work, 3]", "[Work, 4]")), MISMATCH);
                assertRestoreRejected(mdsl, snapshotOf(mdsl.replace("wait [100]", "wait [200]")), MISMATCH);
                assertRestoreRejected(
                    mdsl,
                    snapshotOf(mdsl.replace("[Work, 3]", "[Work, 3] while(Guarded)")),
                    MISMATCH
                );
            });

            it("different subtrees", () => {
                const withSubtree = (action: string) => `root { branch [sub] } root [sub] { action [${action}] }`;

                assertRestoreRejected(withSubtree("Work"), snapshotOf(withSubtree("Other")), MISMATCH);
            });

            it("a different definition even if the snapshot is otherwise valid for the tree", () => {
                const snapshot = snapshotOf(mdsl.replace("[Work, 3]", "[Other, 3]"));
                snapshot.definition = snapshotOf(mdsl).definition.replace(/./, (c) => (c === "0" ? "1" : "0"));

                assertRestoreRejected(mdsl, snapshot, MISMATCH);
            });

            it("a different definition, rather than complaining about the structure of the snapshot", () => {
                // The structure of this snapshot does not match the tree either, but the definition is what gets reported.
                const snapshot = snapshotOf("root { sequence { action [Work] action [Work] } }");

                assertRestoreRejected(mdsl, snapshot, MISMATCH);
            });

            it("a different definition that is still running a pending promise", async () => {
                const pending = { Act: () => new Promise<State.SUCCEEDED>(() => {}), Other: () => State.RUNNING };
                const tree = new BehaviourTree("root { sequence { action [Act] action [Other] } }", pending);
                tree.step();
                const before = JSON.stringify(tree.getTreeNodeDetails());

                const other = new BehaviourTree("root { sequence { action [Other] action [Act] } }", pending);
                other.step();

                assert.throws(() => tree.restore(other.snapshot()), Error, MISMATCH);
                assert.strictEqual(JSON.stringify(tree.getTreeNodeDetails()), before);
            });
        });

        describe("restore will accept a snapshot that was taken from a tree with a definition that is", () => {
            const assertRestoresTo = (sourceDefinition: any, targetDefinition: any) => {
                const source = new BehaviourTree(sourceDefinition, agent);
                source.step();
                const target = new BehaviourTree(targetDefinition, agent);

                target.restore(JSON.parse(JSON.stringify(source.snapshot())));

                assert.deepEqual(withoutIds(target.getTreeNodeDetails()), withoutIds(source.getTreeNodeDetails()));
                assert.strictEqual(target.snapshot().definition, source.snapshot().definition);
            };

            const json = [
                {
                    type: "root",
                    child: {
                        type: "sequence",
                        children: [
                            { type: "action", call: "Work", args: [3] },
                            { type: "condition", call: "IsOdd" },
                            { type: "wait", duration: 100 }
                        ]
                    }
                }
            ];

            it("the same MDSL", () => {
                assertRestoresTo(mdsl, mdsl);
            });

            it("the same MDSL with different formatting and comments", () => {
                assertRestoresTo(
                    mdsl,
                    "root{sequence{/* first */ action[Work,3] condition[IsOdd]\n\n /* last */\n wait[100]}}"
                );
            });

            it("the same JSON", () => {
                assertRestoresTo(json, json);
            });

            it("the equivalent JSON, when taken from MDSL", () => {
                assertRestoresTo(mdsl, json);
                assertRestoresTo(mdsl, convertMDSLToJSON(mdsl));
            });

            it("the equivalent MDSL, when taken from JSON", () => {
                assertRestoresTo(json, mdsl);
                assertRestoresTo(convertMDSLToJSON(mdsl), mdsl);
            });

            it("the equivalent JSON with the properties in a different order", () => {
                assertRestoresTo(mdsl, [
                    {
                        child: {
                            children: [
                                { args: [3], call: "Work", type: "action" },
                                { call: "IsOdd", type: "condition" },
                                { duration: 100, type: "wait" }
                            ],
                            type: "sequence"
                        },
                        type: "root"
                    }
                ]);
            });

            it("the equivalent JSON that is a single root node rather than an array", () => {
                assertRestoresTo(mdsl, json[0]);
                assertRestoresTo(json[0], json);
            });

            it("the equivalent JSON that spells out default values", () => {
                const explicit = "root { sequence while(Guarded) { action [Work] condition [IsOdd] wait } }";
                const implicit = {
                    type: "root",
                    child: {
                        type: "sequence",
                        while: { call: "Guarded" },
                        children: [
                            { type: "action", call: "Work" },
                            { type: "condition", call: "IsOdd" },
                            { type: "wait", duration: undefined }
                        ]
                    }
                };

                assertRestoresTo(explicit, implicit);
                assertRestoresTo(implicit, explicit);
                assertRestoresTo(explicit, {
                    ...implicit,
                    child: { ...implicit.child, while: { call: "Guarded", args: [], succeedOnAbort: false } }
                });
            });

            it("the equivalent definition with subtrees in a different order", () => {
                const a =
                    "root { sequence { branch [a] branch [b] } } root [a] { action [Work] } root [b] { wait [5] }";
                const b =
                    "root [b] { wait [5] } root [a] { action [Work] } root { sequence { branch [a] branch [b] } }";

                assertRestoresTo(a, b);
                assertRestoresTo(b, a);
            });

            it("MDSL that uses every kind of node and attribute", () => {
                const everything = `root entry(Done) {
                    sequence step(Done) {
                        selector exit(Done, 1, "a", null, true) {
                            parallel { race { all { action [Work, $prop] condition [IsOdd, false] } wait [1, 2] } }
                            lotto [1, 2] while(Guarded, 7) { flip { action [Work] } succeed { action [Work] } }
                        }
                        repeat [2, 3] until(Guarded) then succeed { fail { retry [1, 2] { action [Work] } } }
                        branch [sub]
                    }
                } root [sub] { wait }`;

                assertRestoresTo(everything, convertMDSLToJSON(everything));
                assertRestoresTo(convertMDSLToJSON(everything), everything);
            });
        });

        describe("restore will error and leave the tree unchanged if the snapshot", () => {
            const valid = () => snapshotOf(mdsl);

            it("is not an object", () => {
                for (const snapshot of [undefined, null, "snapshot", "", 42, 0, true, [], [valid()], () => valid()]) {
                    assertRestoreRejected(mdsl, snapshot, "invalid snapshot");
                }
            });

            it("is an object that is not a snapshot", () => {
                for (const snapshot of [
                    {},
                    { foo: "bar" },
                    { version: 1 },
                    { root: valid().root },
                    { definition: "x" }
                ]) {
                    assertRestoreRejected(mdsl, snapshot, "invalid snapshot");
                }
            });

            it("is missing the definition", () => {
                const { definition, ...withoutDefinition } = valid();

                assertRestoreRejected(
                    mdsl,
                    withoutDefinition,
                    "invalid snapshot: expected 'definition' to be a string"
                );
            });

            it("has a definition that is not a string", () => {
                for (const definition of [undefined, null, 42, {}, [], true]) {
                    assertRestoreRejected(
                        mdsl,
                        { ...valid(), definition },
                        "invalid snapshot: expected 'definition' to be a string"
                    );
                }
            });
        });
    });

    describe("snapshot and restore of", () => {
        // Agent functions that always give the same result, and count how many times they were called.
        const createCountingAgent = (result: State.SUCCEEDED | State.FAILED | State.RUNNING) => {
            const agent = { calls: 0, Act: () => (agent.calls++, result) };
            return agent;
        };

        describe("a repeat node", () => {
            it("keeps the iteration count and the random iteration target that was selected", () => {
                const definition = "root { repeat [1, 5] { action [Act] } }";

                // This will select an iteration target of 5.
                const sourceAgent = createCountingAgent(State.SUCCEEDED);
                const source = new BehaviourTree(definition, sourceAgent, { random: createRandom([0.99]) });
                source.step();
                source.step();

                const snapshot = JSON.parse(JSON.stringify(source.snapshot()));
                assert.strictEqual(snapshot.root.children[0].currentIterationCount, 2);
                assert.strictEqual(snapshot.root.children[0].targetIterationCount, 5);

                // This would select an iteration target of 1 if the restored tree selected a new target.
                const targetAgent = createCountingAgent(State.SUCCEEDED);
                const random = createRandom([0]);
                const target = new BehaviourTree(definition, targetAgent, { random });
                target.restore(snapshot);

                for (let step = 3; step <= 5; step++) {
                    target.step();
                    assert.strictEqual(target.getState(), State.RUNNING);
                }

                target.step();
                assert.strictEqual(target.getState(), State.SUCCEEDED);
                assert.strictEqual(targetAgent.calls, 3);
                assert.strictEqual(random.count, 0);
            });

            it("keeps the iteration count for a repeat node with a fixed number of iterations", () => {
                const definition = "root { repeat [3] { action [Act] } }";

                const source = new BehaviourTree(definition, createCountingAgent(State.SUCCEEDED));
                source.step();

                const targetAgent = createCountingAgent(State.SUCCEEDED);
                const target = new BehaviourTree(definition, targetAgent);
                target.restore(JSON.parse(JSON.stringify(source.snapshot())));

                target.step();
                target.step();
                assert.strictEqual(target.getState(), State.RUNNING);
                target.step();
                assert.strictEqual(target.getState(), State.SUCCEEDED);
                assert.strictEqual(targetAgent.calls, 2);
            });

            it("will error if the snapshot has an invalid iteration count or target", () => {
                const definition = "root { repeat [3] { action [Act] } }";
                const tree = new BehaviourTree(definition, createCountingAgent(State.SUCCEEDED));
                tree.step();
                const valid = JSON.parse(JSON.stringify(tree.snapshot()));

                const invalid = (changes: object) => ({
                    ...valid,
                    root: { ...valid.root, children: [{ ...valid.root.children[0], ...changes }] }
                });

                assert.throws(
                    () => tree.restore(invalid({ currentIterationCount: -1 })),
                    "invalid snapshot: expected 'root.children[0].currentIterationCount' to be a non-negative integer but it was '-1'"
                );
                assert.throws(
                    () => tree.restore(invalid({ currentIterationCount: undefined })),
                    "invalid snapshot: expected 'root.children[0].currentIterationCount' to be a non-negative integer but it was 'undefined'"
                );
                assert.throws(
                    () => tree.restore(invalid({ targetIterationCount: 1.5 })),
                    "invalid snapshot: expected 'root.children[0].targetIterationCount' to be null or a non-negative integer but it was '1.5'"
                );
                assert.throws(
                    () => tree.restore(invalid({ targetIterationCount: undefined })),
                    "invalid snapshot: expected 'root.children[0].targetIterationCount' to be null or a non-negative integer but it was 'undefined'"
                );
            });
        });

        describe("a retry node", () => {
            it("keeps the attempt count and the random attempt target that was selected", () => {
                const definition = "root { retry [1, 5] { action [Act] } }";

                // This will select an attempt target of 5.
                const sourceAgent = createCountingAgent(State.FAILED);
                const source = new BehaviourTree(definition, sourceAgent, { random: createRandom([0.99]) });
                source.step();
                source.step();

                const snapshot = JSON.parse(JSON.stringify(source.snapshot()));
                assert.strictEqual(snapshot.root.children[0].currentAttemptCount, 2);
                assert.strictEqual(snapshot.root.children[0].targetAttemptCount, 5);

                // This would select an attempt target of 1 if the restored tree selected a new target.
                const targetAgent = createCountingAgent(State.FAILED);
                const random = createRandom([0]);
                const target = new BehaviourTree(definition, targetAgent, { random });
                target.restore(snapshot);

                for (let step = 3; step <= 5; step++) {
                    target.step();
                    assert.strictEqual(target.getState(), State.RUNNING);
                }

                target.step();
                assert.strictEqual(target.getState(), State.FAILED);
                assert.strictEqual(targetAgent.calls, 3);
                assert.strictEqual(random.count, 0);
            });

            it("keeps the attempt count for a retry node with a fixed number of attempts", () => {
                const definition = "root { retry [3] { action [Act] } }";

                const source = new BehaviourTree(definition, createCountingAgent(State.FAILED));
                source.step();

                const targetAgent = createCountingAgent(State.FAILED);
                const target = new BehaviourTree(definition, targetAgent);
                target.restore(JSON.parse(JSON.stringify(source.snapshot())));

                target.step();
                target.step();
                assert.strictEqual(target.getState(), State.RUNNING);
                target.step();
                assert.strictEqual(target.getState(), State.FAILED);
                assert.strictEqual(targetAgent.calls, 2);
            });

            it("will error if the snapshot has an invalid attempt count or target", () => {
                const definition = "root { retry [3] { action [Act] } }";
                const tree = new BehaviourTree(definition, createCountingAgent(State.FAILED));
                tree.step();
                const valid = JSON.parse(JSON.stringify(tree.snapshot()));

                const invalid = (changes: object) => ({
                    ...valid,
                    root: { ...valid.root, children: [{ ...valid.root.children[0], ...changes }] }
                });

                assert.throws(
                    () => tree.restore(invalid({ currentAttemptCount: "1" })),
                    "invalid snapshot: expected 'root.children[0].currentAttemptCount' to be a non-negative integer but it was '1'"
                );
                assert.throws(
                    () => tree.restore(invalid({ targetAttemptCount: -3 })),
                    "invalid snapshot: expected 'root.children[0].targetAttemptCount' to be null or a non-negative integer but it was '-3'"
                );
            });
        });

        describe("a lotto node", () => {
            const definition = `root {
                lotto {
                    action [First]
                    action [Second]
                    action [Third]
                }
            }`;

            const createLottoAgent = () => {
                const agent = { calls: [] as string[] } as any;
                for (const name of ["First", "Second", "Third"]) {
                    agent[name] = () => (agent.calls.push(name), State.RUNNING);
                }
                return agent;
            };

            it("keeps the child that was selected", () => {
                // This will select the second child.
                const sourceAgent = createLottoAgent();
                const source = new BehaviourTree(definition, sourceAgent, { random: createRandom([0.5]) });
                source.step();
                assert.deepEqual(sourceAgent.calls, ["Second"]);

                const snapshot = JSON.parse(JSON.stringify(source.snapshot()));
                assert.strictEqual(snapshot.root.children[0].selectedChildIndex, 1);

                // This would select the first child if the restored tree drew again.
                const targetAgent = createLottoAgent();
                const random = createRandom([0]);
                const target = new BehaviourTree(definition, targetAgent, { random });
                target.restore(snapshot);
                target.step();
                target.step();

                assert.deepEqual(targetAgent.calls, ["Second", "Second"]);
                assert.strictEqual(random.count, 0);
            });

            it("keeps no selected child if the node has not been updated", () => {
                const tree = new BehaviourTree(definition, createLottoAgent());

                assert.notProperty(tree.snapshot().root.children![0], "selectedChildIndex");
            });

            it("will error if the snapshot has an invalid selected child", () => {
                const tree = new BehaviourTree(definition, createLottoAgent(), { random: createRandom([0.5]) });
                tree.step();
                const valid = JSON.parse(JSON.stringify(tree.snapshot()));

                const invalid = (changes: object) => ({
                    ...valid,
                    root: { ...valid.root, children: [{ ...valid.root.children[0], ...changes }] }
                });

                assert.throws(
                    () => tree.restore(invalid({ selectedChildIndex: 3 })),
                    "invalid snapshot: expected 'root.children[0].selectedChildIndex' to be an integer from 0 to 2 but it was '3'"
                );
                assert.throws(
                    () => tree.restore(invalid({ selectedChildIndex: undefined })),
                    "invalid snapshot: expected 'root.children[0].selectedChildIndex' to be an integer from 0 to 2 but it was 'undefined'"
                );
            });
        });
    });

    describe("snapshot and restore of a wait node", () => {
        const HOUR = 60 * 60 * 1000;

        describe("using the clock", () => {
            it("keeps the time that has been waited, so that only the remaining time is waited after a restore", () => {
                const definition = "root { wait [1000] }";

                const source = new BehaviourTree(definition, {});
                source.step();
                clock.tick(400);

                const snapshot = JSON.parse(JSON.stringify(source.snapshot()));
                assert.strictEqual(snapshot.root.children[0].totalDuration, 1000);
                assert.strictEqual(snapshot.root.children[0].waitedDuration, 400);

                // Whatever time passes between taking the snapshot and restoring it does not count.
                clock.tick(3 * HOUR);

                const target = new BehaviourTree(definition, {});
                target.restore(snapshot);

                target.step();
                assert.strictEqual(target.getState(), State.RUNNING);

                clock.tick(599);
                target.step();
                assert.strictEqual(target.getState(), State.RUNNING);

                clock.tick(1);
                target.step();
                assert.strictEqual(target.getState(), State.SUCCEEDED);
            });

            it("counts the time that passes between the last step and taking the snapshot", () => {
                const source = new BehaviourTree("root { wait [1000] }", {});
                source.step();
                clock.tick(900);

                const snapshot = JSON.parse(JSON.stringify(source.snapshot()));
                assert.strictEqual(snapshot.root.children[0].waitedDuration, 900);

                clock.tick(HOUR);

                const target = new BehaviourTree("root { wait [1000] }", {});
                target.restore(snapshot);

                target.step();
                assert.strictEqual(target.getState(), State.RUNNING);

                clock.tick(100);
                target.step();
                assert.strictEqual(target.getState(), State.SUCCEEDED);
            });

            it("can restore a snapshot to the tree that it was taken from", () => {
                const tree = new BehaviourTree("root { wait [1000] }", {});
                tree.step();
                clock.tick(400);

                const snapshot = tree.snapshot();

                clock.tick(500);
                tree.restore(snapshot);

                clock.tick(599);
                tree.step();
                assert.strictEqual(tree.getState(), State.RUNNING);

                clock.tick(1);
                tree.step();
                assert.strictEqual(tree.getState(), State.SUCCEEDED);
            });
        });

        describe("using 'getDeltaTime'", () => {
            it("keeps the time that has been waited, so that only the remaining time is waited after a restore", () => {
                const definition = "root { wait [1000] }";
                const options = { getDeltaTime: () => 0.1 };

                const source = new BehaviourTree(definition, {}, options);
                source.step();
                source.step();
                source.step();

                const snapshot = JSON.parse(JSON.stringify(source.snapshot()));
                assert.strictEqual(snapshot.root.children[0].totalDuration, 1000);
                assert.strictEqual(snapshot.root.children[0].waitedDuration, 300);

                clock.tick(3 * HOUR);

                const target = new BehaviourTree(definition, {}, options);
                target.restore(snapshot);

                for (let step = 0; step < 6; step++) {
                    target.step();
                    assert.strictEqual(target.getState(), State.RUNNING);
                }

                target.step();
                assert.strictEqual(target.getState(), State.SUCCEEDED);
            });

            it("does not count time passing on the clock", () => {
                const definition = "root { wait [1000] }";
                const options = { getDeltaTime: () => 0.1 };

                const source = new BehaviourTree(definition, {}, options);
                source.step();
                clock.tick(2 * HOUR);

                const snapshot = JSON.parse(JSON.stringify(source.snapshot()));
                assert.strictEqual(snapshot.root.children[0].waitedDuration, 100);
            });
        });

        it("keeps the random duration that was selected", () => {
            const definition = "root { wait [100, 200] }";

            // This will select a duration of 200ms.
            const source = new BehaviourTree(definition, {}, { random: createRandom([0.999]) });
            source.step();
            clock.tick(150);

            const snapshot = JSON.parse(JSON.stringify(source.snapshot()));
            assert.strictEqual(snapshot.root.children[0].totalDuration, 200);

            // This would select a duration of 100ms if the restored tree selected a new duration.
            const random = createRandom([0]);
            const target = new BehaviourTree(definition, {}, { random });
            target.restore(snapshot);

            clock.tick(49);
            target.step();
            assert.strictEqual(target.getState(), State.RUNNING);

            clock.tick(1);
            target.step();
            assert.strictEqual(target.getState(), State.SUCCEEDED);
            assert.strictEqual(random.count, 0);
        });

        it("keeps a wait node with no duration waiting", () => {
            const source = new BehaviourTree("root { wait }", {});
            source.step();
            clock.tick(HOUR);

            const snapshot = JSON.parse(JSON.stringify(source.snapshot()));
            assert.strictEqual(snapshot.root.children[0].totalDuration, null);

            const target = new BehaviourTree("root { wait }", {});
            target.restore(snapshot);

            clock.tick(HOUR);
            target.step();
            assert.strictEqual(target.getState(), State.RUNNING);
        });

        it("keeps no timing information for a node that is not running", () => {
            const tree = new BehaviourTree("root { wait [1000] }", {});

            assert.deepEqual(tree.snapshot().root.children![0], {
                type: "wait",
                state: State.READY,
                totalDuration: null,
                waitedDuration: 0
            });

            tree.step();
            clock.tick(1000);
            tree.step();

            assert.deepEqual(tree.snapshot().root.children![0], {
                type: "wait",
                state: State.SUCCEEDED,
                totalDuration: null,
                waitedDuration: 0
            });
        });

        it("will error if the snapshot has an invalid duration or waited duration", () => {
            const tree = new BehaviourTree("root { wait [1000] }", {});
            tree.step();
            const valid = JSON.parse(JSON.stringify(tree.snapshot()));

            const invalid = (changes: object) => ({
                ...valid,
                root: { ...valid.root, children: [{ ...valid.root.children[0], ...changes }] }
            });

            assert.throws(
                () => tree.restore(invalid({ totalDuration: "1000" })),
                "invalid snapshot: expected 'root.children[0].totalDuration' to be null or a non-negative integer but it was '1000'"
            );
            assert.throws(
                () => tree.restore(invalid({ waitedDuration: null })),
                "invalid snapshot: expected 'root.children[0].waitedDuration' to be a finite number but it was 'null'"
            );
            assert.throws(
                () => tree.restore(invalid({ waitedDuration: undefined })),
                "invalid snapshot: expected 'root.children[0].waitedDuration' to be a finite number but it was 'undefined'"
            );
        });
    });

    describe("snapshot and restore of an action node", () => {
        const definition = "root { sequence { action [Act] exit(Exited) action [Next] } }";

        const createPromiseAgent = (act: () => Promise<State.SUCCEEDED | State.FAILED> | State.RUNNING) => {
            const agent = {
                calls: [] as string[],
                Act: act,
                Exited: () => agent.calls.push("Exited"),
                Next: () => State.RUNNING
            };
            const counted = agent.Act;
            agent.Act = () => (agent.calls.push("Act"), counted());
            return agent;
        };

        const nextTick = () => new Promise((resolve) => setImmediate(resolve));

        it("calls the function of a running action again on the next step", () => {
            const source = new BehaviourTree(
                definition,
                createPromiseAgent(() => State.RUNNING)
            );
            source.step();

            const targetAgent = createPromiseAgent(() => State.RUNNING);
            const target = new BehaviourTree(definition, targetAgent);
            target.restore(JSON.parse(JSON.stringify(source.snapshot())));
            assert.deepEqual(targetAgent.calls, []);

            target.step();
            assert.deepEqual(targetAgent.calls, ["Act"]);
        });

        it("keeps the outcome of a promise that has resolved, without calling the function again", async () => {
            const sourceAgent = createPromiseAgent(() => Promise.resolve(State.SUCCEEDED));
            const source = new BehaviourTree(definition, sourceAgent);
            source.step();
            await nextTick();

            const snapshot = JSON.parse(JSON.stringify(source.snapshot()));
            assert.strictEqual(snapshot.root.children[0].children[0].promiseResult, State.SUCCEEDED);

            const targetAgent = createPromiseAgent(() => State.RUNNING);
            const target = new BehaviourTree(definition, targetAgent);
            target.restore(snapshot);

            target.step();

            assert.deepEqual(targetAgent.calls, ["Exited"]);
            assert.deepEqual(
                withoutIds(target.getTreeNodeDetails()).children[0].children.map((child: any) => child.state),
                [State.SUCCEEDED, State.RUNNING]
            );
        });

        it("keeps the outcome of a promise that has resolved as a failure", async () => {
            const source = new BehaviourTree(
                definition,
                createPromiseAgent(() => Promise.resolve(State.FAILED))
            );
            source.step();
            await nextTick();

            const targetAgent = createPromiseAgent(() => State.RUNNING);
            const target = new BehaviourTree(definition, targetAgent);
            target.restore(JSON.parse(JSON.stringify(source.snapshot())));
            target.step();

            assert.strictEqual(target.getState(), State.FAILED);
            assert.deepEqual(targetAgent.calls, ["Exited"]);
        });

        it("keeps no promise outcome for an action that is not using a promise", async () => {
            const tree = new BehaviourTree(
                definition,
                createPromiseAgent(() => State.RUNNING)
            );
            tree.step();

            assert.notProperty(tree.snapshot().root.children![0].children![0], "promiseResult");
        });

        describe("while a promise has not settled yet", () => {
            const actionStates = (tree: BehaviourTree) =>
                withoutIds(tree.getTreeNodeDetails()).children[0].children.map((child: any) => child.state);

            const createPendingAgent = () => {
                const resolvers: ((state: State.SUCCEEDED | State.FAILED) => void)[] = [];
                const agent = createPromiseAgent(() => new Promise((resolve) => resolvers.push(resolve)));
                return { agent, resolvers };
            };

            it("is snapshotted as an action that has not started", async () => {
                const { agent } = createPendingAgent();
                const tree = new BehaviourTree(definition, agent);
                tree.step();
                await nextTick();

                const snapshot = JSON.parse(JSON.stringify(tree.snapshot()));

                assert.deepEqual(snapshot.root.children[0].children[0], { type: "action", state: State.READY });
                assert.strictEqual(snapshot.root.children[0].state, State.RUNNING);
                assert.strictEqual(snapshot.root.state, State.RUNNING);
            });

            it("is restored as an action that has not started, which calls its function again on the next step", async () => {
                const source = createPendingAgent();
                const sourceTree = new BehaviourTree(definition, source.agent);
                sourceTree.step();
                await nextTick();
                const snapshot = JSON.parse(JSON.stringify(sourceTree.snapshot()));

                const target = createPendingAgent();
                const targetTree = new BehaviourTree(definition, target.agent);
                targetTree.restore(snapshot);

                assert.deepEqual(actionStates(targetTree), [State.READY, State.READY]);
                assert.strictEqual(targetTree.getState(), State.RUNNING);
                assert.deepEqual(target.agent.calls, []);

                targetTree.step();
                assert.deepEqual(target.agent.calls, ["Act"]);
                assert.deepEqual(actionStates(targetTree), [State.RUNNING, State.READY]);

                // The tree carries on from there once the new promise resolves.
                targetTree.step();
                assert.deepEqual(target.agent.calls, ["Act"]);

                target.resolvers[0](State.SUCCEEDED);
                await nextTick();
                targetTree.step();

                assert.deepEqual(target.agent.calls, ["Act", "Exited"]);
                assert.deepEqual(actionStates(targetTree), [State.SUCCEEDED, State.RUNNING]);
            });

            it("is restored with the callbacks of the action called again as they are for an action that has not started", async () => {
                const calls: string[] = [];
                const agent = {
                    Act: () => (calls.push("Act"), new Promise<State.SUCCEEDED>(() => {})),
                    Entered: () => calls.push("Entered"),
                    Stepped: () => calls.push("Stepped")
                };
                const tree = new BehaviourTree("root { action [Act] entry(Entered) step(Stepped) }", agent);
                tree.step();
                await nextTick();
                assert.deepEqual(calls.splice(0), ["Entered", "Stepped", "Act"]);

                const target = new BehaviourTree("root { action [Act] entry(Entered) step(Stepped) }", agent);
                target.restore(JSON.parse(JSON.stringify(tree.snapshot())));
                assert.deepEqual(calls, []);

                target.step();
                assert.deepEqual(calls, ["Entered", "Stepped", "Act"]);
            });

            it("does not change the tree that the snapshot was taken from", async () => {
                const { agent, resolvers } = createPendingAgent();
                const tree = new BehaviourTree(definition, agent);
                tree.step();
                await nextTick();
                const detailsBefore = withoutIds(tree.getTreeNodeDetails());

                tree.snapshot();
                tree.snapshot();

                assert.deepEqual(withoutIds(tree.getTreeNodeDetails()), detailsBefore);

                // The original tree still waits for its own promise, and does not call its function again.
                tree.step();
                assert.deepEqual(agent.calls, ["Act"]);

                resolvers[0](State.SUCCEEDED);
                await nextTick();
                tree.step();

                assert.deepEqual(agent.calls, ["Act", "Exited"]);
                assert.deepEqual(actionStates(tree), [State.SUCCEEDED, State.RUNNING]);
            });

            it("is restored as an action that has not started if the snapshot is restored to the tree that it was taken from", async () => {
                const { agent, resolvers } = createPendingAgent();
                const tree = new BehaviourTree(definition, agent);
                tree.step();
                await nextTick();
                const snapshot = tree.snapshot();

                tree.restore(snapshot);
                assert.deepEqual(actionStates(tree), [State.READY, State.READY]);

                // The promise from before the restore resolving is not relevant to the tree any more.
                resolvers[0](State.SUCCEEDED);
                await nextTick();
                tree.step();

                assert.deepEqual(agent.calls, ["Act", "Act"]);
                assert.deepEqual(actionStates(tree), [State.RUNNING, State.READY]);

                resolvers[1](State.FAILED);
                await nextTick();
                tree.step();

                assert.strictEqual(tree.getState(), State.FAILED);
            });

            it("is restored as an action that has not started alongside nodes that have already finished", async () => {
                const calls: string[] = [];
                const agent = {
                    Done: () => (calls.push("Done"), State.SUCCEEDED),
                    Act: () => (calls.push("Act"), new Promise<State.SUCCEEDED>(() => {}))
                };
                const parallel = "root { parallel { action [Done] action [Act] } }";
                const tree = new BehaviourTree(parallel, agent);
                tree.step();
                await nextTick();
                calls.length = 0;

                const target = new BehaviourTree(parallel, agent);
                target.restore(JSON.parse(JSON.stringify(tree.snapshot())));
                target.step();

                assert.deepEqual(calls, ["Act"]);
                assert.deepEqual(
                    withoutIds(target.getTreeNodeDetails()).children[0].children.map((child: any) => child.state),
                    [State.SUCCEEDED, State.RUNNING]
                );
            });

            for (const [description, parent] of [
                ["a sequence", "sequence { action [Act] action [Next] }"],
                ["a selector", "selector { action [Act] action [Next] }"],
                ["a parallel", "parallel { action [Act] action [Next] }"],
                ["a race", "race { action [Act] action [Next] }"],
                ["an all", "all { action [Act] action [Next] }"],
                ["a lotto", "lotto { action [Act] }"],
                ["a repeat", "repeat [2] { action [Act] }"],
                ["a retry", "retry [2] { action [Act] }"],
                ["a flip", "flip { action [Act] }"],
                ["a succeed", "succeed { action [Act] }"],
                ["a fail", "fail { action [Act] }"],
                ["a nested subtree", "sequence { branch [sub] }"],
                ["no parent but the root", "action [Act]"]
            ]) {
                it(`is restored as an action that has not started inside ${description}`, async () => {
                    const definition = `root { ${parent} } root [sub] { repeat [2] { action [Act] } }`;

                    const createTree = () => {
                        const resolvers: ((state: State.SUCCEEDED) => void)[] = [];
                        const calls: string[] = [];
                        const agent = {
                            Act: () => (
                                calls.push("Act"), new Promise<State.SUCCEEDED>((resolve) => resolvers.push(resolve))
                            ),
                            Next: () => State.RUNNING
                        };

                        return { tree: new BehaviourTree(definition, agent), resolvers, calls };
                    };

                    /** Steps a tree twice, with the promise of its first action call resolving in between. */
                    const stepAndResolve = async ({ tree, resolvers }: ReturnType<typeof createTree>) => {
                        tree.step();
                        resolvers[0](State.SUCCEEDED);
                        await nextTick();
                        tree.step();
                    };

                    const source = createTree();
                    source.tree.step();
                    await nextTick();
                    const snapshot = JSON.parse(JSON.stringify(source.tree.snapshot()));

                    // A tree that has been restored must behave as a tree that is yet to start the action.
                    const control = createTree();
                    await stepAndResolve(control);

                    const target = createTree();
                    target.tree.restore(snapshot);
                    assert.deepEqual(target.calls, []);
                    await stepAndResolve(target);

                    assert.deepEqual(target.calls, control.calls);
                    assert.isNotEmpty(target.calls);
                    assert.deepEqual(
                        withoutIds(target.tree.getTreeNodeDetails()),
                        withoutIds(control.tree.getTreeNodeDetails())
                    );
                });
            }
        });

        describe("will error when taking a snapshot while", () => {
            it("a promise has resolved with an invalid value", async () => {
                const tree = new BehaviourTree(
                    definition,
                    createPromiseAgent(() => Promise.resolve("nope") as any)
                );
                tree.step();
                await nextTick();

                assert.throws(
                    () => tree.snapshot(),
                    Error,
                    "error taking snapshot: cannot capture the state of action node 'Act' as the promise returned by the function resolved with an invalid value"
                );
            });

            it("a promise has rejected", async () => {
                const tree = new BehaviourTree(
                    definition,
                    createPromiseAgent(() => Promise.reject("oh no"))
                );
                tree.step();
                await nextTick();

                assert.throws(
                    () => tree.snapshot(),
                    Error,
                    "error taking snapshot: cannot capture the state of action node 'Act' as the promise returned by the function was rejected"
                );
            });
        });

        it("will error if the snapshot has an invalid promise outcome", () => {
            const tree = new BehaviourTree(
                definition,
                createPromiseAgent(() => State.RUNNING)
            );
            tree.step();
            const valid = JSON.parse(JSON.stringify(tree.snapshot()));

            const invalid = (changes: object) => ({
                ...valid,
                root: {
                    ...valid.root,
                    children: [
                        {
                            ...valid.root.children[0],
                            children: [
                                { ...valid.root.children[0].children[0], ...changes },
                                valid.root.children[0].children[1]
                            ]
                        }
                    ]
                }
            });

            assert.throws(
                () => tree.restore(invalid({ promiseResult: State.RUNNING })),
                "invalid snapshot: expected 'root.children[0].children[0].promiseResult' to be a resolved node state but it was 'mistreevous.running'"
            );
            assert.throws(
                () => tree.restore(invalid({ state: State.READY, promiseResult: State.SUCCEEDED })),
                "invalid snapshot: expected 'root.children[0].children[0].promiseResult' to not be defined for a node that is not running"
            );
        });

        it("is not affected by a promise from before a restore that resolves afterwards", async () => {
            const resolvers: ((state: State.SUCCEEDED) => void)[] = [];
            const agent = createPromiseAgent(() => new Promise((resolve) => resolvers.push(resolve)));
            const tree = new BehaviourTree(definition, agent);

            const snapshot = tree.snapshot();

            tree.step();
            tree.restore(snapshot);
            tree.step();
            assert.strictEqual(resolvers.length, 2);

            // The promise for the action call from before the restore resolves, which is no longer relevant to the tree.
            resolvers[0](State.SUCCEEDED);
            await nextTick();
            tree.step();

            assert.deepEqual(
                withoutIds(tree.getTreeNodeDetails()).children[0].children.map((child: any) => child.state),
                [State.RUNNING, State.READY]
            );
            assert.strictEqual(agent.calls.filter((call) => call === "Act").length, 2);

            // The promise for the action call after the restore is the one that counts.
            resolvers[1](State.SUCCEEDED);
            await nextTick();
            tree.step();

            assert.deepEqual(
                withoutIds(tree.getTreeNodeDetails()).children[0].children.map((child: any) => child.state),
                [State.SUCCEEDED, State.RUNNING]
            );
        });
    });

    describe("snapshot and restore of a finished tree", () => {
        // Moves to a failed state at the end of the run if the tree is meant to fail.
        const createDefinition = (outcome: State) => `root {
            sequence {
                repeat [1, 3] { action [Tick, 1] }
                wait [100, 200]
                lotto {
                    action [Tick, 1]
                    action [Tick, 1]
                    action [Tick, 1]
                }
                ${outcome === State.FAILED ? "flip { action [Tick, 1] }" : ""}
            }
        }`;

        for (const outcome of [State.SUCCEEDED, State.FAILED]) {
            it(`restores as ${
                outcome === State.SUCCEEDED ? "succeeded" : "failed"
            }, and the next step starts a new run that makes random choices again`, () => {
                const world = { step: 0 };
                const randomValues = [0.2, 0.6, 0.9, 0.4];

                const sourceRandom = createRandom(randomValues);
                const source = new BehaviourTree(createDefinition(outcome), createAgent(world, []), {
                    random: sourceRandom
                });

                while (source.getState() !== State.SUCCEEDED && source.getState() !== State.FAILED) {
                    clock.tick(100);
                    world.step++;
                    source.step();
                }

                assert.strictEqual(source.getState(), outcome);

                const randomCountAtFinish = sourceRandom.count;
                const snapshot = JSON.parse(JSON.stringify(source.snapshot()));

                const targetRandom = createRandom(randomValues, randomCountAtFinish);
                const target = new BehaviourTree(createDefinition(outcome), createAgent(world, []), {
                    random: targetRandom
                });
                target.restore(snapshot);

                assert.strictEqual(target.getState(), outcome);
                assert.isFalse(target.isRunning());
                assert.deepEqual(withoutIds(target.getTreeNodeDetails()), withoutIds(source.getTreeNodeDetails()));
                assert.strictEqual(targetRandom.count, randomCountAtFinish);

                // The next step starts a new run in both trees, which makes the same random choices again.
                clock.tick(100);
                world.step++;
                source.step();
                target.step();

                assert.isAbove(targetRandom.count, randomCountAtFinish);
                assert.strictEqual(targetRandom.count, sourceRandom.count);
                assert.deepEqual(withoutIds(target.getTreeNodeDetails()), withoutIds(source.getTreeNodeDetails()));
            });
        }
    });

    describe("restores a tree that behaves exactly as the tree that the snapshot was taken from", () => {
        const definitions: { [description: string]: string } = {
            "sequence and selector nodes": `root {
                sequence {
                    selector {
                        condition [IsOdd]
                        action [Work, 4]
                    }
                    action [Work, 6]
                    selector {
                        action [Fussy, 8]
                        action [Work, 10]
                    }
                }
            }`,
            "parallel nodes": `root {
                parallel {
                    action [Work, 3]
                    sequence {
                        action [Work, 5]
                        action [Work, 7]
                    }
                    action [Work, 9]
                }
            }`,
            "race nodes": `root {
                race {
                    sequence {
                        action [Work, 12]
                        action [Work, 14]
                    }
                    action [Work, 8]
                    action [Fussy, 6]
                }
            }`,
            "all nodes": `root {
                all {
                    action [Work, 4]
                    sequence {
                        action [Work, 6]
                        action [Fussy, 8]
                    }
                    condition [IsOdd]
                }
            }`,
            "flip, succeed and fail nodes": `root {
                sequence {
                    flip { action [Work, 3] }
                    succeed { action [Fussy, 5] }
                    fail { action [Work, 7] }
                }
            }`,
            "repeat nodes with a fixed number of iterations": `root {
                sequence {
                    repeat [3] { action [Tick, 2] }
                    repeat [2] { action [Tick, 3] }
                }
            }`,
            "repeat nodes with a random number of iterations": `root {
                sequence {
                    repeat [2, 5] { action [Tick, 3] }
                    repeat [1, 4] { sequence { action [Tick, 2] action [Tick, 3] } }
                }
            }`,
            "repeat nodes without a number of iterations": `root {
                repeat { action [Tick, 3] while(IsEarly, 21) }
            }`,
            "repeat nodes that fail": `root {
                repeat [3, 6] { sequence { action [Tick, 3] condition [IsEarly, 8] } }
            }`,
            "retry nodes with a fixed number of attempts": `root {
                sequence {
                    retry [3] { action [Trip, 2] }
                }
            }`,
            "retry nodes with a random number of attempts": `root {
                selector {
                    retry [2, 5] { action [Trip, 3] }
                    retry [1, 4] { sequence { action [Tick, 2] action [Trip, 3] } }
                }
            }`,
            "retry nodes that succeed": `root {
                retry [5] { sequence { action [Tick, 2] action [Fussy, 11] } }
            }`,
            "lotto nodes": `root {
                lotto {
                    action [Tick, 2]
                    sequence { action [Tick, 3] action [Tick, 2] }
                    action [Trip, 4]
                }
            }`,
            "weighted lotto nodes that are repeated": `root {
                repeat [4] {
                    lotto [1, 4, 2] {
                        action [Tick, 2]
                        sequence { action [Tick, 3] action [Tick, 2] }
                        action [Trip, 4]
                    }
                }
            }`,
            "wait nodes": `root {
                sequence {
                    wait [250]
                    action [Tick, 2]
                    wait [150, 400]
                    wait [100]
                }
            }`,
            "wait nodes that are repeated": `root {
                repeat [3, 5] { wait [150, 450] }
            }`,
            "wait nodes that are aborted": `root {
                sequence {
                    race {
                        wait [900]
                        wait
                        sequence { wait [400] action [Work, 9] }
                    }
                    parallel {
                        wait [300]
                        wait [700]
                    }
                    race {
                        wait [2000]
                        action [Work, 24]
                    }
                }
            }`,
            attributes: `root entry(Entered, "root") exit(Exited, "root") {
                sequence entry(Entered, "sequence") step(Stepped, "sequence") exit(Exited, "sequence") {
                    action [Work, 4] while(IsEarly, 6) entry(Entered, "first") exit(Exited, "first")
                    action [Work, 20] until(IsOdd) step(Stepped, "second") exit(Exited, "second")
                }
            }`,
            branches: `root {
                sequence {
                    branch [Waiting]
                    branch [Waiting]
                }
            }
            root [Waiting] {
                sequence {
                    action [Work, 5]
                    condition [IsOdd]
                }
            }`
        };

        for (const [description, definition] of Object.entries(definitions)) {
            it(`(${description})`, () => {
                assertRestoredTreesBehaveLikeTheOriginal(clock, definition);
            });

            it(`(${description}, using 'getDeltaTime')`, () => {
                assertRestoredTreesBehaveLikeTheOriginal(clock, definition, { useDeltaTime: true });
            });
        }
    });
});
