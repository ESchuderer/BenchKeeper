import { assert } from "chai";
import { SinonFakeTimers } from "sinon";

import { BehaviourTree, BehaviourTreeOptions, NodeDetails, State } from "../src/index";
import { RootNodeDefinition } from "../src/BehaviourTreeDefinition";

/**
 * Removes the (randomly generated) node ids from the given node details so that the details of different tree instances can be compared.
 */
export function withoutIds(details: NodeDetails): any {
    const { id, children, ...rest } = details;

    return children ? { ...rest, children: children.map(withoutIds) } : rest;
}

/**
 * Creates a deterministic 'random' function that yields the given values in a cycle, starting at the given position.
 * The number of values drawn so far (including the starting position) is available via the 'count' property.
 */
export function createRandom(values: number[], startCount = 0) {
    const random = () => values[random.count++ % values.length];

    random.count = startCount;

    return random;
}

/**
 * The state of the 'outside world' that the agent functions respond to.
 * Agent functions only ever depend on this and not on any state of their own, so that the agents of different tree instances behave identically.
 */
export type World = { step: number };

/**
 * Creates an agent that logs every function call it receives, and that responds to the state of the world.
 */
export function createAgent(world: World, log: string[]) {
    const logCall = (name: string, ...args: any[]) => log.push([name, ...args, `@${world.step}`].join(" "));

    return {
        // Succeeds once the world has reached the given step, running until then.
        Work: (until: number) => {
            logCall("Work", until);
            return world.step >= until ? State.SUCCEEDED : State.RUNNING;
        },
        // Fails, apart from on every 4th step.
        Flaky: () => {
            logCall("Flaky");
            return world.step % 4 === 3 ? State.SUCCEEDED : State.FAILED;
        },
        // Fails until the world has reached the given step.
        Fussy: (until: number) => {
            logCall("Fussy", until);
            return world.step >= until ? State.SUCCEEDED : State.FAILED;
        },
        // Runs until the world step is a multiple of the given number, and then succeeds.
        Tick: (every: number) => {
            logCall("Tick", every);
            return world.step % every === 0 ? State.SUCCEEDED : State.RUNNING;
        },
        // Runs until the world step is a multiple of the given number, and then fails.
        Trip: (every: number) => {
            logCall("Trip", every);
            return world.step % every === 0 ? State.FAILED : State.RUNNING;
        },
        IsOdd: () => {
            logCall("IsOdd");
            return world.step % 2 === 1;
        },
        IsEarly: (until: number) => {
            logCall("IsEarly", until);
            return world.step < until;
        },
        Entered: (name: string) => logCall("Entered", name),
        Stepped: (name: string) => logCall("Stepped", name),
        Exited: (result: { succeeded: boolean; aborted: boolean }, name: string) =>
            logCall("Exited", name, result.succeeded ? "succeeded" : "failed", result.aborted ? "aborted" : "")
    };
}

/**
 * Everything that is observable about a tree after a step.
 */
function capture(tree: BehaviourTree, log: string[]) {
    return { state: tree.getState(), details: withoutIds(tree.getTreeNodeDetails()), calls: log.splice(0) };
}

const BASE_TIME = 1_000_000;
const STEP_INTERVAL_MS = 100;
const IDLE_TIME_BEFORE_SNAPSHOT_MS = 30;
const RESTORE_TIME = 5_000_000_000;

/**
 * Asserts that a tree that is restored from a snapshot behaves exactly as the tree that the snapshot was taken from.
 *
 * A reference tree is stepped 'steps' times, and a snapshot is taken after each step (and one before the first). Each snapshot is then
 * (after a round trip through JSON) restored into a new tree, which is stepped alongside a world that continues from the same point
 * as the reference tree. Every observable of each remaining step must match what the reference tree went through, and the restored tree
 * must make the same random draws. The restored tree runs at a much later time to make sure that time that passes between taking and
 * restoring a snapshot is not counted.
 */
export function assertRestoredTreesBehaveLikeTheOriginal(
    clock: SinonFakeTimers,
    definition: string | RootNodeDefinition | RootNodeDefinition[],
    {
        steps = 30,
        useDeltaTime = false,
        randomValues = [0.1, 0.9, 0.5, 0.3, 0.7]
    }: { steps?: number; useDeltaTime?: boolean; randomValues?: number[] } = {}
) {
    const createTree = (world: World, log: string[], random: () => number) => {
        const options: BehaviourTreeOptions = { random };

        if (useDeltaTime) {
            options.getDeltaTime = () => STEP_INTERVAL_MS / 1000;
        }

        return new BehaviourTree(definition, createAgent(world, log), options);
    };

    // Run the tree without ever taking a snapshot, to make sure that taking snapshots does not affect the tree.
    const plainTraces: ReturnType<typeof capture>[] = [];
    {
        const world = { step: 0 };
        const log: string[] = [];
        const tree = createTree(world, log, createRandom(randomValues));

        for (world.step = 1; world.step <= steps; world.step++) {
            clock.setSystemTime(BASE_TIME + world.step * STEP_INTERVAL_MS);
            tree.step();
            plainTraces.push(capture(tree, log));
        }
    }

    // Run the reference tree, taking a snapshot after each step.
    const referenceWorld = { step: 0 };
    const referenceLog: string[] = [];
    const referenceRandom = createRandom(randomValues);
    const referenceTree = createTree(referenceWorld, referenceLog, referenceRandom);

    const snapshots: string[] = [];
    const randomCounts: number[] = [];
    const detailsAfterStep: any[] = [withoutIds(referenceTree.getTreeNodeDetails())];
    const referenceTraces: ReturnType<typeof capture>[] = [];

    const takeSnapshot = (step: number) => {
        clock.setSystemTime(BASE_TIME + step * STEP_INTERVAL_MS + IDLE_TIME_BEFORE_SNAPSHOT_MS);
        const snapshot = referenceTree.snapshot();

        // A snapshot must be unchanged by a round trip through JSON, which it would not be if it had undefined properties for example.
        assert.deepEqual(JSON.parse(JSON.stringify(snapshot)), snapshot, "snapshot is changed by a trip through JSON");

        snapshots.push(JSON.stringify(snapshot));
        randomCounts.push(referenceRandom.count);
    };

    takeSnapshot(0);

    for (referenceWorld.step = 1; referenceWorld.step <= steps; referenceWorld.step++) {
        clock.setSystemTime(BASE_TIME + referenceWorld.step * STEP_INTERVAL_MS);
        referenceTree.step();
        referenceTraces.push(capture(referenceTree, referenceLog));
        detailsAfterStep.push(withoutIds(referenceTree.getTreeNodeDetails()));
        takeSnapshot(referenceWorld.step);
    }

    assert.deepEqual(referenceTraces, plainTraces, "taking snapshots changed the behaviour of the tree");

    // Restore each snapshot into a new tree and carry on from there.
    for (let snapshotStep = 0; snapshotStep <= steps; snapshotStep++) {
        const context = `restored from the snapshot taken after step ${snapshotStep}`;

        const world = { step: snapshotStep };
        const log: string[] = [];
        const random = createRandom(randomValues, randomCounts[snapshotStep]);
        const tree = createTree(world, log, random);

        const snapshotTime = BASE_TIME + snapshotStep * STEP_INTERVAL_MS + IDLE_TIME_BEFORE_SNAPSHOT_MS;
        clock.setSystemTime(RESTORE_TIME);
        tree.restore(JSON.parse(snapshots[snapshotStep]));

        assert.deepEqual(withoutIds(tree.getTreeNodeDetails()), detailsAfterStep[snapshotStep], context);
        assert.deepEqual(log, [], `${context}, restoring called agent functions`);
        assert.strictEqual(random.count, randomCounts[snapshotStep], `${context}, restoring drew random numbers`);

        for (world.step = snapshotStep + 1; world.step <= steps; world.step++) {
            clock.setSystemTime(RESTORE_TIME + (BASE_TIME + world.step * STEP_INTERVAL_MS - snapshotTime));
            tree.step();

            assert.deepEqual(capture(tree, log), referenceTraces[world.step - 1], `${context}, at step ${world.step}`);
        }

        assert.strictEqual(random.count, referenceRandom.count, `${context}, random draws differed`);
    }
}
