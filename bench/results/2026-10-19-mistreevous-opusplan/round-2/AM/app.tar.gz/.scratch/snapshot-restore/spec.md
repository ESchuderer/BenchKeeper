# Tree snapshot and restore

Status: ready-for-agent

## Goal

`BehaviourTree.snapshot()` returns the execution state as a plain object. `BehaviourTree.restore(snapshot)` applies it to a tree built from the same definition. Storage, events and scheduling stay in the application.

## Snapshot format

`TreeSnapshot = { version: 1, definition: string, root: NodeSnapshot }`, where `definition` is a hash of the tree definition that is the same for an MDSL definition and its equivalent JSON definition, exported as a type from `src/index.ts`.

`NodeSnapshot` is one object per node, in definition order (children nested), with only JSON values (no `undefined`, no functions, no class instances):

| Node | Fields |
|---|---|
| every node | `id`, `type`, `state` |
| composite, decorator | `children` |
| `repeat`, `retry` | `targetCount` (number or null), `currentCount` |
| `lotto` | `selectedChild` (index or null) |
| `wait` | `totalDuration` (number or null), `waitedDuration` (ms, 0 unless `RUNNING`) |
| `action` | `updatePromiseResult` (`{ isResolved, value }` with `value` as a string, only while `RUNNING` with a settled promise that no step has handled yet) |

`condition` keeps only the common fields.

## Decisions

- Nodes are matched by position and `type`. `restore` throws, and leaves the tree unchanged, if the snapshot does not match the tree (version, shape, node type, child count, field types).
- `id` is stored so `getTreeNodeDetails()` and `onNodeStateChange` ids match the tree the snapshot came from.
- `wait`: `waitedDuration` is the time waited at snapshot time (`Date` mode: now minus first update time, `getDeltaTime` mode: accumulated delta). `restore` sets the first update time to now minus `waitedDuration`, so time between snapshot and restore does not count.
- `restore` does not call `onNodeStateChange` and does not call any agent function (no exit callbacks, no aborts).
- A finished tree restores as finished. `step()` then resets it, and random choices are made again.
- `restore` throws, and leaves the tree unchanged, if the snapshot is of a different definition or is not a snapshot at all.
- An `action` node that is `RUNNING` and waiting on a promise that has not settled is snapshotted as `READY`: the promise cannot be serialized, so the restored tree calls the action function again on its next step. Actions that return `State.RUNNING` (or nothing) are not affected.
- A promise left over from before a `restore` (or `reset`) is ignored when it settles, including after the action function has been called again.
- `restore` also rejects a `RUNNING` lotto node snapshot with no picked child.
- Not stored: agent, options, registered functions and subtrees, random generator state. The restored tree must be built with the same definition and registrations. Registered subtrees are not part of the definition hash.

## Acceptance criteria

- [ ] `snapshot()` result is deep-equal after `JSON.parse(JSON.stringify(...))`.
- [ ] After `restore`, node states, agent calls and results match the original tree for every node type.
- [ ] Repeat/retry counts (fixed and random), lotto choice, random wait duration and elapsed wait time are kept.
- [ ] Waiting time between snapshot and restore does not count, with `Date` and with `getDeltaTime`.
- [ ] Finished-tree snapshot restores as finished and the next `step()` starts a new run with new random choices.
- [ ] Invalid snapshots, including snapshots of another definition, throw clear errors.
- [ ] Pending-promise actions are restored as not yet started, and the README documents it.
- [ ] README documents the API with an example. Version History row and package version are bumped (minor: 4.4.0).
- [ ] `npm test` passes.
