import State, { AnyState } from "./State";
import Node from "./nodes/Node";
import Composite from "./nodes/composite/Composite";
import Decorator from "./nodes/decorator/Decorator";
import { RootNodeDefinition } from "./BehaviourTreeDefinition";

/**
 * A snapshot of the execution state of a tree node.
 * Only the fields that apply to the node type are defined.
 */
export type NodeSnapshot = {
    /**
     * The node unique identifier.
     */
    id: string;
    /**
     * The node type.
     */
    type: string;
    /**
     * The node state.
     */
    state: AnyState;
    /**
     * The snapshots of the child nodes in definition order, defined for composite and decorator nodes.
     */
    children?: NodeSnapshot[];
    /**
     * The target number of iterations or attempts, or null if there is no target, defined for repeat and retry nodes.
     */
    targetCount?: number | null;
    /**
     * The number of iterations or attempts made so far, defined for repeat and retry nodes.
     */
    currentCount?: number;
    /**
     * The index of the child node that was picked, or null if none was, defined for lotto nodes.
     */
    selectedChild?: number | null;
    /**
     * The total duration in milliseconds to wait for, or null to wait indefinitely, defined for wait nodes.
     */
    totalDuration?: number | null;
    /**
     * The duration in milliseconds that has been waited for, defined for wait nodes.
     */
    waitedDuration?: number;
    /**
     * The settled result of the action function promise if there is one that has not been handled yet, defined for action nodes.
     */
    updatePromiseResult?: {
        /**
         * Whether the promise was resolved rather than rejected.
         */
        isResolved: boolean;
        /**
         * The resolved value or rejection reason as a string.
         */
        value: string;
    };
};

/**
 * A snapshot of the execution state of a behaviour tree, which can be passed through JSON.stringify and JSON.parse unchanged.
 */
export type TreeSnapshot = {
    /**
     * The snapshot format version.
     */
    version: 1;
    /**
     * The hash of the definition of the tree that the snapshot was taken from. A definition in MDSL and its equivalent JSON definition have the same hash.
     */
    definition: string;
    /**
     * The snapshot of the root node.
     */
    root: NodeSnapshot;
};

/**
 * Gets a copy of a definition value with sorted keys and with the defaults that the MDSL converter fills in made explicit,
 * so that equivalent definitions give the same result.
 * @param value The definition value.
 * @param key The key of the value in its parent object.
 */
function canonicalise(value: unknown, key?: string): unknown {
    if (Array.isArray(value)) {
        return value.map((item) => canonicalise(item));
    }

    if (typeof value !== "object" || value === null) {
        return value;
    }

    const source: Record<string, unknown> = { ...value };

    if (typeof source.call === "string") {
        source.args ??= [];
    }

    if (key === "while" || key === "until") {
        source.succeedOnAbort = !!source.succeedOnAbort;
    }

    return Object.fromEntries(
        Object.keys(source)
            .filter((name) => source[name] !== undefined)
            .sort()
            .map((name) => [name, canonicalise(source[name], name)])
    );
}

/**
 * Gets a hash of a tree definition, which is the same for an MDSL definition and its equivalent JSON definition.
 * @param definition The tree definition as an array of root node definitions.
 * @returns The hash of the definition.
 */
export function getDefinitionHash(definition: RootNodeDefinition[]): string {
    // Root nodes are looked up by id, so their order is not part of the definition. The main root has no id and sorts first.
    const roots = [...definition].sort((a, b) => ((a.id ?? "") < (b.id ?? "") ? -1 : 1));
    const text = JSON.stringify(canonicalise(roots));

    // A 53 bit string hash (cyrb53), as the browser build has no crypto module to rely on.
    let h1 = 0xdeadbeef;
    let h2 = 0x41c6ce57;
    for (let index = 0; index < text.length; index++) {
        const code = text.charCodeAt(index);
        h1 = Math.imul(h1 ^ code, 2654435761);
        h2 = Math.imul(h2 ^ code, 1597334677);
    }
    h1 = Math.imul(h1 ^ (h1 >>> 16), 2246822507) ^ Math.imul(h2 ^ (h2 >>> 13), 3266489909);
    h2 = Math.imul(h2 ^ (h2 >>> 16), 2246822507) ^ Math.imul(h1 ^ (h1 >>> 13), 3266489909);

    return (4294967296 * (2097151 & h2) + (h1 >>> 0)).toString(16);
}

const isNonNegativeInteger = (value: unknown) => Number.isInteger(value) && (value as number) >= 0;

/**
 * Validates that a snapshot is a snapshot of the tree with the given root node and definition hash.
 * @param root The root node of the tree.
 * @param definition The hash of the definition of the tree.
 * @param snapshot The snapshot to validate.
 * @throws An error describing the first mismatch found.
 */
export function validateSnapshot(root: Node, definition: string, snapshot: any): void {
    if (typeof snapshot !== "object" || snapshot === null || Array.isArray(snapshot)) {
        throw new Error("the snapshot must be an object");
    }

    if (snapshot.version !== 1) {
        throw new Error(`unsupported snapshot version '${snapshot.version}'`);
    }

    if (typeof snapshot.definition !== "string") {
        throw new Error("the snapshot has no definition");
    }

    if (snapshot.definition !== definition) {
        throw new Error("the snapshot does not match the tree's definition");
    }

    validateNodeSnapshot(root, snapshot.root, "root");
}

/**
 * Validates that a node snapshot is a snapshot of the given node and of each of its descendants.
 * @param node The node.
 * @param snapshot The node snapshot to validate.
 * @param path The path of the node in the snapshot, for use in error messages.
 */
function validateNodeSnapshot(node: Node, snapshot: any, path: string): void {
    const fail = (reason: string): never => {
        throw new Error(`invalid snapshot at '${path}': ${reason}`);
    };

    if (typeof snapshot !== "object" || snapshot === null) {
        return fail("expected a node snapshot object");
    }

    if (snapshot.type !== node.getType()) {
        return fail(`expected a '${node.getType()}' node but got '${snapshot.type}'`);
    }

    if (typeof snapshot.id !== "string") {
        return fail("expected 'id' to be a string");
    }

    if (!Object.values(State).includes(snapshot.state)) {
        return fail("expected 'state' to be a node state");
    }

    const children = node instanceof Composite || node instanceof Decorator ? node.getChildren() : null;

    if (children) {
        if (!Array.isArray(snapshot.children) || snapshot.children.length !== children.length) {
            return fail(`expected 'children' to be an array of ${children.length} node snapshots`);
        }

        children.forEach((child, index) =>
            validateNodeSnapshot(child, snapshot.children[index], `${path}.children[${index}]`)
        );
    }

    switch (snapshot.type) {
        case "repeat":
        case "retry":
            if (snapshot.targetCount !== null && !isNonNegativeInteger(snapshot.targetCount)) {
                return fail("expected 'targetCount' to be null or a non-negative integer");
            }
            if (!isNonNegativeInteger(snapshot.currentCount)) {
                return fail("expected 'currentCount' to be a non-negative integer");
            }
            break;
        case "lotto":
            if (
                snapshot.selectedChild !== null &&
                !(isNonNegativeInteger(snapshot.selectedChild) && snapshot.selectedChild < children!.length)
            ) {
                return fail("expected 'selectedChild' to be null or the index of a child");
            }
            if (snapshot.state === State.RUNNING && snapshot.selectedChild === null) {
                return fail("expected 'selectedChild' to be defined for a running lotto node");
            }
            break;
        case "wait":
            if (
                snapshot.totalDuration !== null &&
                !(Number.isFinite(snapshot.totalDuration) && snapshot.totalDuration >= 0)
            ) {
                return fail("expected 'totalDuration' to be null or a non-negative number");
            }
            if (!(Number.isFinite(snapshot.waitedDuration) && snapshot.waitedDuration >= 0)) {
                return fail("expected 'waitedDuration' to be a non-negative number");
            }
            break;
        case "action": {
            const result = snapshot.updatePromiseResult;
            if (result !== undefined && snapshot.state !== State.RUNNING) {
                return fail("expected 'updatePromiseResult' to be undefined unless the node is running");
            }
            if (
                result !== undefined &&
                !(typeof result?.isResolved === "boolean" && typeof result.value === "string")
            ) {
                return fail(
                    "expected 'updatePromiseResult' to be undefined or an object with 'isResolved' and 'value'"
                );
            }
        }
    }
}
