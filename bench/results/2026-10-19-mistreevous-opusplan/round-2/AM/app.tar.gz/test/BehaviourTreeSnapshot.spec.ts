import { assert } from "chai";
import sinon, { SinonFakeTimers } from "sinon";

import { BehaviourTree, BehaviourTreeOptions, State, TreeSnapshot } from "../src/index";
import { NodeStateChange } from "../src/BehaviourTreeOptions";
import { RootNodeDefinition } from "../src/BehaviourTreeDefinition";

type Definition = string | RootNodeDefinition | RootNodeDefinition[];

/**
 * The result of an agent function call, given the 1-based number of times the function has been called.
 */
type AgentResult = (callNumber: number) => State | boolean | undefined | Promise<State>;

/**
 * Create an agent whose functions log each call and take their result from the given scripts.
 * The call counts stand in for application state, so a restored agent can start from the counts of the original.
 */
function createAgent(results: Record<string, AgentResult>, counts: Record<string, number> = {}) {
    const log: string[] = [];
    const agent: Record<string, any> = { log, counts: { ...counts } };

    for (const name of Object.keys(results)) {
        agent[name] = () => {
            agent.counts[name] = (agent.counts[name] ?? 0) + 1;
            log.push(name);
            return results[name](agent.counts[name]);
        };
    }

    return agent;
}

/**
 * Step a tree, take a snapshot, pass it through JSON and restore it into a second tree built from the same
 * definition. Both trees are then stepped in lockstep and must show the same node details and agent calls.
 */
function assertRestoredTreeMatches(
    definition: Definition,
    results: Record<string, AgentResult>,
    stepsBeforeSnapshot: number,
    stepsAfterRestore: number,
    options: { original?: BehaviourTreeOptions; restored?: BehaviourTreeOptions } = {}
) {
    const originalAgent = createAgent(results);
    const original = new BehaviourTree(definition, originalAgent, options.original);

    for (let step = 0; step < stepsBeforeSnapshot; step++) {
        original.step();
    }

    const snapshot: TreeSnapshot = JSON.parse(JSON.stringify(original.snapshot()));
    const callsBeforeRestore = originalAgent.log.length;

    const restoredAgent = createAgent(results, originalAgent.counts);
    const restored = new BehaviourTree(definition, restoredAgent, options.restored);
    restored.restore(snapshot);

    assert.deepEqual(restored.getTreeNodeDetails(), original.getTreeNodeDetails());

    for (let step = 0; step < stepsAfterRestore; step++) {
        original.step();
        restored.step();

        assert.deepEqual(restored.getTreeNodeDetails(), original.getTreeNodeDetails(), `after step ${step + 1}`);
        assert.deepEqual(restoredAgent.log, originalAgent.log.slice(callsBeforeRestore), `after step ${step + 1}`);
    }

    return { original, restored, originalAgent, restoredAgent };
}

/**
 * Returns RUNNING for the given number of calls, then the given state.
 */
const runningFor =
    (calls: number, then: State = State.SUCCEEDED): AgentResult =>
    (callNumber) =>
        callNumber <= calls ? State.RUNNING : then;

const succeed: AgentResult = () => State.SUCCEEDED;
const fail: AgentResult = () => State.FAILED;

describe("A BehaviourTree snapshot", () => {
    describe("is a plain object that", () => {
        it("is unchanged by a JSON round trip, for a tree using every node type", () => {
            const definition = `
                root {
                    sequence {
                        selector {
                            action [fail]
                            lotto { action [succeed] action [succeed] }
                        }
                        parallel { action [succeed] condition [yes] }
                        race { action [slow] action [slow] }
                        all { action [succeed] action [slow] }
                        repeat [2, 3] { flip { action [fail] } }
                        retry [2, 3] { succeed { action [fail] } }
                        fail { action [succeed] }
                        wait [100, 200]
                        branch [sub]
                    }
                }
                root [sub] { wait [50] }
            `;
            const tree = new BehaviourTree(
                definition,
                createAgent({ succeed, fail, slow: runningFor(5), yes: () => true }),
                { random: () => 0.5 }
            );

            for (let step = 0; step < 4; step++) {
                const snapshot: TreeSnapshot = tree.snapshot();

                assert.deepEqual(JSON.parse(JSON.stringify(snapshot)), snapshot);

                tree.step();
            }
        });

        it("has no undefined values", () => {
            const tree = new BehaviourTree(
                "root { sequence { action [succeed] wait [10] } }",
                createAgent({ succeed })
            );

            tree.step();

            assert.notInclude(JSON.stringify(tree.snapshot()), "undefined");
            assert.strictEqual(
                JSON.stringify(tree.snapshot()),
                JSON.stringify(JSON.parse(JSON.stringify(tree.snapshot())))
            );
        });
    });

    describe("restores a tree built from the same definition so that it", () => {
        describe("matches the original tree in node states and agent calls for", () => {
            const nodes: [string, string][] = [
                ["a sequence", "sequence { action [succeed] action [slow] action [succeed] }"],
                ["a selector", "selector { action [fail] action [slow] action [succeed] }"],
                ["a parallel", "parallel { action [slow] action [succeed] action [slow] }"],
                ["a race", "race { action [fail] action [slow] action [slow] }"],
                ["an all", "all { action [succeed] action [slow] action [fail] }"],
                ["a flip", "flip { action [slow] }"],
                ["a succeed", "succeed { action [slow] }"],
                ["a fail", "fail { action [slow] }"],
                ["a condition in a sequence", "sequence { condition [yes] action [slow] }"]
            ];

            for (const [name, node] of nodes) {
                for (let stepsBeforeSnapshot = 0; stepsBeforeSnapshot <= 4; stepsBeforeSnapshot++) {
                    it(`${name} snapshotted after ${stepsBeforeSnapshot} steps`, () => {
                        assertRestoredTreeMatches(
                            `root { ${node} }`,
                            { succeed, fail, slow: runningFor(2), yes: () => true },
                            stepsBeforeSnapshot,
                            5
                        );
                    });
                }
            }
        });

        describe("keeps the iteration count of a repeat node", () => {
            for (const stepsBeforeSnapshot of [1, 2, 3]) {
                it(`with a fixed number of iterations, snapshotted after ${stepsBeforeSnapshot} steps`, () => {
                    const { restoredAgent } = assertRestoredTreeMatches(
                        "root { repeat [4] { action [succeed] } }",
                        { succeed },
                        stepsBeforeSnapshot,
                        4 - stepsBeforeSnapshot + 1
                    );

                    assert.strictEqual(restoredAgent.log.length, 4 - stepsBeforeSnapshot);
                });
            }

            it("and the random number of iterations that was picked", () => {
                // The original picks 2 iterations, a restored tree would pick 5 if it picked again.
                const { restoredAgent } = assertRestoredTreeMatches(
                    "root { repeat [2, 5] { action [succeed] } }",
                    { succeed },
                    1,
                    2,
                    { original: { random: () => 0 }, restored: { random: () => 0.99 } }
                );

                assert.strictEqual(restoredAgent.log.length, 1);
            });
        });

        describe("keeps the attempt count of a retry node", () => {
            for (const stepsBeforeSnapshot of [1, 2, 3]) {
                it(`with a fixed number of attempts, snapshotted after ${stepsBeforeSnapshot} steps`, () => {
                    const { restoredAgent } = assertRestoredTreeMatches(
                        "root { retry [4] { action [fail] } }",
                        { fail },
                        stepsBeforeSnapshot,
                        4 - stepsBeforeSnapshot + 1
                    );

                    assert.strictEqual(restoredAgent.log.length, 4 - stepsBeforeSnapshot);
                });
            }

            it("and the random number of attempts that was picked", () => {
                const { restoredAgent } = assertRestoredTreeMatches(
                    "root { retry [2, 5] { action [fail] } }",
                    { fail },
                    1,
                    2,
                    { original: { random: () => 0 }, restored: { random: () => 0.99 } }
                );

                assert.strictEqual(restoredAgent.log.length, 1);
            });
        });

        it("keeps the child that a lotto node picked", () => {
            // The original picks the first child, a restored tree would pick the second if it picked again.
            const { restoredAgent } = assertRestoredTreeMatches(
                "root { lotto { sequence { action [a] action [slow] } sequence { action [b] action [slow] } } }",
                { a: succeed, b: succeed, slow: runningFor(2) },
                1,
                2,
                { original: { random: () => 0 }, restored: { random: () => 0.99 } }
            );

            assert.deepEqual(restoredAgent.log, ["slow", "slow"]);
        });

        describe("keeps the time that a wait node has waited for", () => {
            let clock: SinonFakeTimers;

            beforeEach(() => {
                clock = sinon.useFakeTimers();
            });

            afterEach(() => {
                clock.restore();
            });

            const getWaitState = (tree: BehaviourTree) => tree.getTreeNodeDetails().children![0].state;

            /**
             * Step a tree, let 'waitedBeforeSnapshot' milliseconds pass, snapshot it, let a long time pass and restore it into a
             * new tree. Then step the new tree after each of the given delays, returning the wait node state after each step.
             */
            function stepRestoredTree(
                definition: string,
                waitedBeforeSnapshot: number,
                delays: number[],
                options: { original?: BehaviourTreeOptions; restored?: BehaviourTreeOptions } = {}
            ) {
                const original = new BehaviourTree(definition, {}, options.original);
                original.step();
                clock.tick(waitedBeforeSnapshot);
                const snapshot: TreeSnapshot = JSON.parse(JSON.stringify(original.snapshot()));

                clock.tick(1000000);

                const restored = new BehaviourTree(definition, {}, options.restored);
                restored.restore(snapshot);

                return delays.map((delay) => {
                    clock.tick(delay);
                    restored.step();
                    return getWaitState(restored);
                });
            }

            it("and only waits for the remaining time, however long it was before the restore", () => {
                assert.deepEqual(stepRestoredTree("root { wait [1000] }", 400, [0, 599, 1]), [
                    State.RUNNING,
                    State.RUNNING,
                    State.SUCCEEDED
                ]);
            });

            it("counting the time since the last step as waited", () => {
                // The wait node was last updated 700ms before the snapshot, but was still waiting at the snapshot.
                assert.deepEqual(stepRestoredTree("root { wait [1000] }", 700, [299, 1]), [
                    State.RUNNING,
                    State.SUCCEEDED
                ]);
            });

            it("and the random duration that was picked", () => {
                // The original picks 1000ms, a restored tree would pick 1990ms if it picked again.
                assert.deepEqual(
                    stepRestoredTree("root { wait [1000, 2000] }", 500, [499, 1], {
                        original: { random: () => 0 },
                        restored: { random: () => 0.99 }
                    }),
                    [State.RUNNING, State.SUCCEEDED]
                );
            });

            it("using the getDeltaTime option", () => {
                let deltaTime = 0.4;
                const options = { getDeltaTime: () => deltaTime };
                const original = new BehaviourTree("root { wait [1000] }", {}, options);
                original.step();
                original.step();
                const snapshot: TreeSnapshot = JSON.parse(JSON.stringify(original.snapshot()));

                clock.tick(1000000);
                deltaTime = 0.1;

                const restored = new BehaviourTree("root { wait [1000] }", {}, options);
                restored.restore(snapshot);

                const states = [];
                for (let step = 0; step < 2; step++) {
                    restored.step();
                    states.push(getWaitState(restored));
                }

                // 800ms were waited before the snapshot, then 100ms for each step.
                assert.deepEqual(states, [State.RUNNING, State.SUCCEEDED]);
            });
        });

        it("does not repeat the entry callback or run exit callbacks of the nodes that were running", () => {
            const definition = `
                root {
                    sequence entry(onEntry, "seq") step(onStep, "seq") exit(onExit, "seq") {
                        action [slow] entry(onEntry, "action") exit(onExit, "action")
                    }
                }
            `;
            const results = {
                slow: runningFor(2),
                onEntry: () => undefined,
                onStep: () => undefined,
                onExit: () => undefined
            };

            const { restoredAgent } = assertRestoredTreeMatches(definition, results, 1, 2);

            assert.deepEqual(restoredAgent.log, ["onStep", "slow", "onStep", "slow", "onExit", "onExit"]);
        });

        it("keeps evaluating the guards of the nodes that were running", () => {
            const definition = `
                root {
                    sequence while(isOk) {
                        action [slow] while(isOk)
                        action [succeed]
                    }
                }
            `;
            const isOk = (callNumber: number) => callNumber < 4;

            assertRestoredTreeMatches(definition, { slow: runningFor(5), succeed, isOk }, 2, 4);
        });
    });

    describe("of a finished tree", () => {
        it("restores as finished, and the next step runs the tree again", () => {
            const { restored } = assertRestoredTreeMatches(
                "root { sequence { action [a] wait [100] action [b] } }",
                { a: succeed, b: succeed },
                1,
                4
            );

            assert.strictEqual(restored.getState(), State.RUNNING);
        });

        it("restores as finished, and the next step makes new random choices", () => {
            const definition = "root { lotto { action [succeed] action [fail] } }";
            const original = new BehaviourTree(definition, createAgent({ succeed, fail }), { random: () => 0 });
            original.step();
            assert.strictEqual(original.getState(), State.SUCCEEDED);

            const restored = new BehaviourTree(definition, createAgent({ succeed, fail }), { random: () => 0.99 });
            restored.restore(original.snapshot());

            assert.strictEqual(restored.getState(), State.SUCCEEDED);

            restored.step();

            assert.strictEqual(restored.getState(), State.FAILED);
        });
    });

    describe("of an action node", () => {
        const definition = "root { action [work] }";

        it("restores a pending action without calling its function again", () => {
            const original = new BehaviourTree(definition, createAgent({ work: runningFor(2) }));
            original.step();

            const agent = createAgent({ work: runningFor(2) }, { work: 1 });
            const restored = new BehaviourTree(definition, agent);
            restored.restore(original.snapshot());
            restored.step();

            assert.strictEqual(restored.getState(), State.RUNNING);
            assert.deepEqual(agent.log, ["work"]);
        });

        it("restores a settled promise result without calling its function again", async () => {
            const original = new BehaviourTree(
                definition,
                createAgent({ work: () => Promise.resolve(State.SUCCEEDED) })
            );
            original.step();
            await Promise.resolve();

            const agent = createAgent({ work: () => Promise.reject("not called") });
            const restored = new BehaviourTree(definition, agent);
            restored.restore(JSON.parse(JSON.stringify(original.snapshot())));
            restored.step();

            assert.strictEqual(restored.getState(), State.SUCCEEDED);
            assert.deepEqual(agent.log, []);
        });

        it("restores a rejected promise result as an error when the tree is next stepped", async () => {
            const original = new BehaviourTree(definition, createAgent({ work: () => Promise.reject("oops") }));
            original.step();
            await Promise.resolve();

            const restored = new BehaviourTree(definition, createAgent({}));
            restored.restore(JSON.parse(JSON.stringify(original.snapshot())));

            assert.throws(() => restored.step(), Error, "action function 'work' promise rejected with 'oops'");
        });

        it("is restored as not yet started when it was waiting on a promise, so its function is called again", () => {
            const original = new BehaviourTree(definition, createAgent({ work: () => new Promise<State>(() => {}) }));
            original.step();

            const snapshot: TreeSnapshot = JSON.parse(JSON.stringify(original.snapshot()));
            const agent = createAgent({ work: runningFor(1) });
            const restored = new BehaviourTree(definition, agent);
            restored.restore(snapshot);

            assert.strictEqual(restored.getTreeNodeDetails().children![0].state, State.READY);
            assert.deepEqual(agent.log, []);

            restored.step();
            assert.strictEqual(restored.getState(), State.RUNNING);
            restored.step();
            assert.strictEqual(restored.getState(), State.SUCCEEDED);
            assert.deepEqual(agent.log, ["work", "work"]);
        });

        it("calls the entry callback of an action that was waiting on a promise again", () => {
            const withEntry = "root { action [work] entry(onEntry) }";
            const original = new BehaviourTree(
                withEntry,
                createAgent({ work: () => new Promise<State>(() => {}), onEntry: () => undefined })
            );
            original.step();

            const agent = createAgent({ work: succeed, onEntry: () => undefined });
            const restored = new BehaviourTree(withEntry, agent);
            restored.restore(JSON.parse(JSON.stringify(original.snapshot())));
            restored.step();

            assert.deepEqual(agent.log, ["onEntry", "work"]);
        });

        it("only calls the function of the action that was waiting on a promise, in a running sequence", () => {
            const nested = "root { sequence { action [done] action [work] action [after] } }";
            const original = new BehaviourTree(
                nested,
                createAgent({ done: succeed, work: () => new Promise<State>(() => {}), after: succeed })
            );
            original.step();

            const agent = createAgent({ done: succeed, work: succeed, after: succeed });
            const restored = new BehaviourTree(nested, agent);
            restored.restore(JSON.parse(JSON.stringify(original.snapshot())));
            restored.step();

            assert.strictEqual(restored.getState(), State.SUCCEEDED);
            assert.deepEqual(agent.log, ["work", "after"]);
        });

        it("does not change the tree that was snapshotted while it was waiting on a promise", async () => {
            let resolve: (state: State) => void = () => {};
            const agent = createAgent({ work: () => new Promise<State>((r) => (resolve = r)) });
            const original = new BehaviourTree(definition, agent);
            original.step();

            original.snapshot();
            resolve(State.SUCCEEDED);
            await Promise.resolve();
            original.step();

            assert.strictEqual(original.getState(), State.SUCCEEDED);
            assert.deepEqual(agent.log, ["work"]);
        });

        it("ignores the promise of a tree that is restored over, after the action function is called again", async () => {
            let resolveFirst: (state: State) => void = () => {};
            const agent = createAgent({
                work: (callNumber) =>
                    callNumber === 1
                        ? new Promise<State>((resolve) => (resolveFirst = resolve))
                        : new Promise<State>(() => {})
            });
            const target = new BehaviourTree(definition, agent);
            target.step();

            target.restore(new BehaviourTree(definition, createAgent({})).snapshot());
            target.step();

            resolveFirst(State.SUCCEEDED);
            await Promise.resolve();
            target.step();

            assert.strictEqual(target.getState(), State.RUNNING);
            assert.deepEqual(agent.log, ["work", "work"]);
        });

        it("ignores the promise of a tree that is restored over", async () => {
            let resolve: (state: State) => void = () => {};
            const agent = createAgent({
                work: (callNumber) =>
                    callNumber === 1 ? new Promise<State>((r) => (resolve = r)) : runningFor(5)(callNumber)
            });
            const target = new BehaviourTree(definition, agent);
            target.step();

            const source = new BehaviourTree(definition, createAgent({ work: runningFor(5) }));
            source.step();
            target.restore(source.snapshot());

            resolve(State.SUCCEEDED);
            await Promise.resolve();
            target.step();

            assert.strictEqual(target.getState(), State.RUNNING);
            assert.deepEqual(agent.log, ["work", "work"]);
        });
    });

    describe("restoring an invalid snapshot", () => {
        const definition =
            "root { sequence { action [succeed] repeat [2] { wait [100] } lotto { action [succeed] } } }";
        const createTree = () => new BehaviourTree(definition, createAgent({ succeed }));
        const getSnapshot = (): any => {
            const tree = createTree();
            tree.step();
            return JSON.parse(JSON.stringify(tree.snapshot()));
        };
        const find = (node: any, type: string): any =>
            node.type === type ? node : (node.children ?? []).map((child: any) => find(child, type)).find(Boolean);

        const invalidSnapshots: [string, (snapshot: any) => unknown][] = [
            ["is not an object", () => "snapshot"],
            ["is null", () => null],
            ["is a number", () => 1],
            ["is an array", () => []],
            ["is undefined", () => undefined],
            ["is an object without the snapshot fields", () => ({})],
            ["has no definition", (snapshot) => ({ ...snapshot, definition: undefined })],
            ["has a definition that is not a string", (snapshot) => ({ ...snapshot, definition: 1 })],
            ["has an unsupported version", (snapshot) => ({ ...snapshot, version: 2 })],
            ["has no root", (snapshot) => ({ ...snapshot, root: undefined })],
            [
                "has a root node of a different type",
                (snapshot) => ({ ...snapshot, root: { ...snapshot.root, type: "wait" } })
            ],
            [
                "has a node with an invalid state",
                (snapshot) => ((find(snapshot.root, "action").state = "nope"), snapshot)
            ],
            ["has a node with an invalid id", (snapshot) => ((find(snapshot.root, "action").id = 1), snapshot)],
            [
                "has a node with a missing child",
                (snapshot) => (find(snapshot.root, "sequence").children.pop(), snapshot)
            ],
            [
                "has a deeply nested node of a different type",
                (snapshot) => ((find(snapshot.root, "lotto").children[0].type = "condition"), snapshot)
            ],
            [
                "has a repeat node with an invalid count",
                (snapshot) => ((find(snapshot.root, "repeat").currentCount = "1"), snapshot)
            ],
            [
                "has a repeat node with an invalid target",
                (snapshot) => ((find(snapshot.root, "repeat").targetCount = -1), snapshot)
            ],
            [
                "has a lotto node with an out of range child",
                (snapshot) => ((find(snapshot.root, "lotto").selectedChild = 1), snapshot)
            ],
            [
                "has a lotto node that was started but picked no child",
                (snapshot) => {
                    find(snapshot.root, "lotto").state = State.RUNNING;
                    find(snapshot.root, "lotto").selectedChild = null;
                    return snapshot;
                }
            ],
            [
                "has a wait node with an invalid duration",
                (snapshot) => ((find(snapshot.root, "wait").totalDuration = "100"), snapshot)
            ],
            [
                "has a wait node with a negative waited duration",
                (snapshot) => ((find(snapshot.root, "wait").waitedDuration = -1), snapshot)
            ],
            [
                "has a finished action node with a promise result",
                (snapshot) => (
                    (find(snapshot.root, "action").updatePromiseResult = { isResolved: true, value: State.SUCCEEDED }),
                    snapshot
                )
            ],
            [
                "has a wait node with an invalid waited duration",
                (snapshot) => ((find(snapshot.root, "wait").waitedDuration = null), snapshot)
            ],
            [
                "has an action node with an invalid promise result",
                (snapshot) => ((find(snapshot.root, "action").updatePromiseResult = { isResolved: "yes" }), snapshot)
            ]
        ];

        for (const [name, createInvalidSnapshot] of invalidSnapshots) {
            it(`throws and leaves the tree unchanged if the snapshot ${name}`, () => {
                const tree = createTree();
                tree.step();
                tree.step();
                const detailsBefore = tree.getTreeNodeDetails();
                const fresh = createTree().snapshot();

                assert.throws(
                    () => tree.restore(createInvalidSnapshot(getSnapshot()) as TreeSnapshot),
                    Error,
                    "error restoring tree: "
                );
                assert.deepEqual(tree.getTreeNodeDetails(), detailsBefore);
                assert.notDeepEqual(tree.snapshot(), fresh);
            });
        }

        it("throws if the snapshot is from a tree with a different definition", () => {
            const tree = new BehaviourTree("root { sequence { action [succeed] } }", createAgent({ succeed }));

            assert.throws(() => tree.restore(getSnapshot()), Error, "does not match the tree's definition");
        });
    });

    describe("restoring a snapshot of another definition", () => {
        const base = "root { sequence { action [a, 1] wait [100] repeat [2] { condition [c] while(g) } } }";
        const others: [string, string][] = [
            ["an action name", "root { sequence { action [b, 1] wait [100] repeat [2] { condition [c] while(g) } } }"],
            ["an argument", "root { sequence { action [a, 2] wait [100] repeat [2] { condition [c] while(g) } } }"],
            ["a wait duration", "root { sequence { action [a, 1] wait [101] repeat [2] { condition [c] while(g) } } }"],
            [
                "an iteration count",
                "root { sequence { action [a, 1] wait [100] repeat [3] { condition [c] while(g) } } }"
            ],
            ["a guard", "root { sequence { action [a, 1] wait [100] repeat [2] { condition [c] while(h) } } }"],
            ["a missing guard", "root { sequence { action [a, 1] wait [100] repeat [2] { condition [c] } } }"]
        ];
        const functions = { a: succeed, b: succeed, c: () => true, g: () => true, h: () => true };

        for (const [name, other] of others) {
            it(`throws and leaves the tree unchanged if it differs in ${name}`, () => {
                // A delta time keeps the waited duration from depending on the clock between the two snapshots.
                const tree = new BehaviourTree(other, createAgent(functions), { getDeltaTime: () => 0.001 });
                tree.step();
                const before = tree.snapshot();

                const source = new BehaviourTree(base, createAgent(functions));
                source.step();

                assert.throws(() => tree.restore(source.snapshot()), Error, "does not match the tree's definition");
                assert.deepEqual(tree.snapshot(), before);
            });
        }

        it("throws if the weights of a lotto node differ", () => {
            const source = new BehaviourTree("root { lotto [1, 2] { action [a] action [a] } }", createAgent(functions));
            const target = new BehaviourTree("root { lotto [2, 1] { action [a] action [a] } }", createAgent(functions));

            assert.throws(() => target.restore(source.snapshot()), Error, "does not match the tree's definition");
        });

        it("leaves a stepped tree exactly as it was, including counts, lotto choices and waited time", () => {
            let now = 0;
            const tree = new BehaviourTree(
                "root { sequence { wait [100] repeat [3] { lotto { action [a] action [b] } } } }",
                createAgent({ a: runningFor(5), b: runningFor(5) }),
                { getDeltaTime: () => (now += 0.01), random: () => 0.7 }
            );
            tree.step();
            tree.step();
            const before = tree.snapshot();

            const other = new BehaviourTree(
                "root { sequence { wait [100] repeat [4] { lotto { action [a] action [b] } } } }",
                {}
            );

            assert.throws(() => tree.restore(other.snapshot()), Error, "does not match the tree's definition");
            assert.deepEqual(tree.snapshot(), before);
        });

        it("accepts the same MDSL definition with different whitespace and comments", () => {
            const source = new BehaviourTree(base, createAgent(functions));
            const target = new BehaviourTree(
                `root {
                    /* a comment */
                    sequence { action [a, 1]   wait [100]
                        repeat [2] { condition [c] while(g) } }
                }`,
                createAgent(functions)
            );
            source.step();

            target.restore(source.snapshot());

            assert.deepEqual(target.getTreeNodeDetails(), source.getTreeNodeDetails());
        });
    });

    describe("restoring a snapshot between an MDSL definition and its equivalent JSON definition", () => {
        const mdsl = `
            root {
                sequence while(guard, 1, "a") entry(onEntry) step(onStep) exit(onExit) {
                    action [work, 1, true, null, $x]
                    selector until(done) { condition [yes] fail { wait [10, 20] } }
                    lotto [1, 3] { repeat [2, 3] { action [work] } retry [2] { succeed { action [work] } } }
                    parallel { race { all { flip { action [work] } wait } branch [sub] } }
                }
            }
            root [sub] { retry { action [work] } }
        `;
        // Written by hand: keys out of order, the sub root first and the defaults the MDSL converter fills in left out.
        const json: RootNodeDefinition[] = [
            { id: "sub", type: "root", child: { child: { call: "work", type: "action" }, type: "retry" } },
            {
                child: {
                    children: [
                        { type: "action", call: "work", args: [1, true, null, { $: "x" }] },
                        {
                            type: "selector",
                            until: { call: "done" },
                            children: [
                                { type: "condition", call: "yes" },
                                { type: "fail", child: { type: "wait", duration: [10, 20] } }
                            ]
                        },
                        {
                            type: "lotto",
                            weights: [1, 3],
                            children: [
                                { type: "repeat", iterations: [2, 3], child: { type: "action", call: "work" } },
                                {
                                    type: "retry",
                                    attempts: 2,
                                    child: { type: "succeed", child: { type: "action", call: "work" } }
                                }
                            ]
                        },
                        {
                            type: "parallel",
                            children: [
                                {
                                    type: "race",
                                    children: [
                                        {
                                            type: "all",
                                            children: [
                                                { type: "flip", child: { type: "action", call: "work" } },
                                                { type: "wait" }
                                            ]
                                        },
                                        { type: "branch", ref: "sub" }
                                    ]
                                }
                            ]
                        }
                    ],
                    entry: { call: "onEntry" },
                    exit: { call: "onExit" },
                    step: { call: "onStep" },
                    type: "sequence",
                    while: { call: "guard", args: [1, "a"] }
                },
                type: "root"
            }
        ] as RootNodeDefinition[];
        const functions = {
            work: runningFor(1),
            guard: () => true,
            done: () => false,
            yes: () => true,
            onEntry: () => undefined,
            onStep: () => undefined,
            onExit: () => undefined
        };
        const agent = () => ({ ...createAgent(functions), x: 1 });

        it("accepts an MDSL snapshot in a JSON tree", () => {
            const source = new BehaviourTree(mdsl, agent());
            source.step();
            const target = new BehaviourTree(json, agent());

            target.restore(JSON.parse(JSON.stringify(source.snapshot())));

            assert.deepEqual(target.getTreeNodeDetails(), source.getTreeNodeDetails());
        });

        it("accepts a JSON snapshot in an MDSL tree", () => {
            const source = new BehaviourTree(json, agent());
            source.step();
            const target = new BehaviourTree(mdsl, agent());

            target.restore(JSON.parse(JSON.stringify(source.snapshot())));

            assert.deepEqual(target.getTreeNodeDetails(), source.getTreeNodeDetails());
        });

        it("accepts a snapshot between forms that leave out counts, weights and arguments", () => {
            const plain = "root { lotto { repeat { action [work] } retry { condition [yes] } } }";
            const withArguments = `root { action [work] entry(onEntry, 1) exit(onExit, "s") step(onStep, true) until(done, 2) }`;
            const plainJson = [
                {
                    type: "root",
                    child: {
                        type: "lotto",
                        children: [
                            { type: "repeat", child: { type: "action", call: "work" } },
                            { type: "retry", child: { type: "condition", call: "yes" } }
                        ]
                    }
                }
            ] as RootNodeDefinition[];
            const withArgumentsJson = {
                type: "root",
                child: {
                    type: "action",
                    call: "work",
                    entry: { call: "onEntry", args: [1] },
                    exit: { call: "onExit", args: ["s"] },
                    step: { call: "onStep", args: [true] },
                    until: { call: "done", args: [2] }
                }
            } as RootNodeDefinition;

            for (const [from, to] of [
                [plain, plainJson],
                [plainJson, plain],
                [withArguments, withArgumentsJson],
                [withArgumentsJson, withArguments]
            ]) {
                const source = new BehaviourTree(from, agent());
                source.step();
                const target = new BehaviourTree(to, agent());

                target.restore(JSON.parse(JSON.stringify(source.snapshot())));

                assert.deepEqual(target.getTreeNodeDetails(), source.getTreeNodeDetails());
            }
        });

        it("does not change the JSON definition it was given", () => {
            const copy = JSON.parse(JSON.stringify(json));

            new BehaviourTree(json, agent()).snapshot();

            assert.deepEqual(json, copy);
        });
    });

    describe("of a lotto node that failed a guard before picking a child", () => {
        it("restores as failed", () => {
            const tree = new BehaviourTree(
                "root { lotto while(no) { action [succeed] } }",
                createAgent({ succeed, no: () => false })
            );
            tree.step();

            const { restored } = assertRestoredTreeMatches(
                "root { lotto while(no) { action [succeed] } }",
                { succeed, no: () => false },
                1,
                2
            );

            assert.strictEqual(tree.getState(), State.FAILED);
            assert.strictEqual(restored.getState(), State.FAILED);
        });
    });

    describe("of a wait node that finished because of an infinite delta time", () => {
        it("is unchanged by a JSON round trip", () => {
            const tree = new BehaviourTree("root { wait [100] }", {}, { getDeltaTime: () => Infinity });
            tree.step();

            const snapshot = tree.snapshot();

            assert.deepEqual(JSON.parse(JSON.stringify(snapshot)), snapshot);
        });
    });

    describe("restoring", () => {
        it("replaces the state of a tree that has already been stepped", () => {
            const definition = "root { sequence { action [succeed] action [slow] action [succeed] } }";
            const results = { succeed, slow: runningFor(2) };
            const source = new BehaviourTree(definition, createAgent(results));
            source.step();
            const snapshot = source.snapshot();

            const target = new BehaviourTree(definition, createAgent(results));
            for (let step = 0; step < 4; step++) {
                target.step();
            }
            target.restore(snapshot);

            assert.deepEqual(target.getTreeNodeDetails(), source.getTreeNodeDetails());
        });

        it("does not call agent functions or the onNodeStateChange option", () => {
            const definition = "root { sequence { action [succeed] action [slow] exit(onExit) } }";
            const agent = createAgent({ succeed, slow: runningFor(2), onExit: () => undefined });
            const source = new BehaviourTree(definition, agent);
            source.step();

            const changes: NodeStateChange[] = [];
            const target = new BehaviourTree(definition, agent, {
                onNodeStateChange: (change) => changes.push(change)
            });
            const callsBefore = agent.log.length;

            target.restore(source.snapshot());

            assert.strictEqual(agent.log.length, callsBefore);
            assert.deepEqual(changes, []);

            // Later changes report the restored state as their previous state.
            target.step();
            target.step();
            target.step();
            assert.isAbove(changes.length, 0);
            assert.strictEqual(changes[0].previousState, State.RUNNING);
        });

        describe("a tree using every node type", () => {
            const definition = `
                root {
                    sequence {
                        selector { action [fail] lotto { action [succeed] action [succeed] } }
                        parallel { action [succeed] condition [yes] }
                        race { action [slow] action [slow] }
                        all { action [succeed] action [slow] }
                        repeat [2, 3] { flip { action [fail] } }
                        retry [2, 3] { succeed { action [fail] } }
                        fail { action [succeed] }
                        wait [100, 200]
                    }
                }
            `;
            const results = { succeed, fail, slow: runningFor(5), yes: () => true };
            let clock: SinonFakeTimers;

            beforeEach(() => {
                clock = sinon.useFakeTimers();
            });

            afterEach(() => {
                clock.restore();
            });

            it("does not call onNodeStateChange when restoring, only on the steps after it", () => {
                const source = new BehaviourTree(definition, createAgent(results), { random: () => 0.5 });
                const snapshots: TreeSnapshot[] = [];

                for (let step = 0; step < 6; step++) {
                    source.step();
                    snapshots.push(source.snapshot());
                }

                const changes: NodeStateChange[] = [];
                const target = new BehaviourTree(definition, createAgent(results), {
                    random: () => 0.5,
                    onNodeStateChange: (change) => changes.push(change)
                });

                for (const snapshot of snapshots) {
                    target.restore(snapshot);

                    assert.deepEqual(changes, []);
                }

                target.step();

                assert.isAbove(changes.length, 0);
            });

            it("leaves a snapshot unchanged when the tree it was taken from is stepped", () => {
                const tree = new BehaviourTree(definition, createAgent(results), { random: () => 0.5 });

                for (let step = 0; step < 8; step++) {
                    const snapshot = tree.snapshot();
                    const json = JSON.stringify(snapshot);

                    tree.step();
                    clock.tick(30);

                    assert.strictEqual(JSON.stringify(snapshot), json, `after step ${step + 1}`);
                }
            });

            it("leaves a snapshot unchanged when the tree it was restored into is stepped", () => {
                const source = new BehaviourTree(definition, createAgent(results), { random: () => 0.5 });
                const target = new BehaviourTree(definition, createAgent(results), { random: () => 0.5 });

                for (let step = 0; step < 8; step++) {
                    const snapshot = source.snapshot();
                    const json = JSON.stringify(snapshot);

                    target.restore(snapshot);
                    target.step();
                    clock.tick(30);

                    assert.strictEqual(JSON.stringify(snapshot), json, `after step ${step + 1}`);

                    source.step();
                }
            });

            it("gives a snapshot equal to the one restored when it is taken before any step", () => {
                const source = new BehaviourTree(definition, createAgent(results), { random: () => 0.5 });
                const target = new BehaviourTree(definition, createAgent(results), { random: () => 0.5 });

                for (let step = 0; step < 8; step++) {
                    const snapshot: TreeSnapshot = JSON.parse(JSON.stringify(source.snapshot()));

                    target.restore(snapshot);

                    assert.deepEqual(JSON.parse(JSON.stringify(target.snapshot())), snapshot, `after step ${step}`);

                    source.step();
                    clock.tick(30);
                }
            });
        });

        describe("a tree with an action that has a settled promise result", () => {
            const definition = "root { sequence { action [work] action [after] } }";

            const createSource = async () => {
                const agent = createAgent({ work: async () => State.SUCCEEDED, after: succeed });
                const tree = new BehaviourTree(definition, agent);
                tree.step();
                await Promise.resolve();

                return tree;
            };

            it("leaves a snapshot unchanged when the tree it was restored into is stepped", async () => {
                const snapshot = (await createSource()).snapshot();
                const json = JSON.stringify(snapshot);
                const target = new BehaviourTree(definition, createAgent({ work: succeed, after: succeed }));

                target.restore(snapshot);
                target.step();

                assert.strictEqual(target.getState(), State.SUCCEEDED);
                assert.strictEqual(JSON.stringify(snapshot), json);
            });

            it("gives a snapshot equal to the one restored when it is taken before any step", async () => {
                const snapshot: TreeSnapshot = JSON.parse(JSON.stringify((await createSource()).snapshot()));
                const target = new BehaviourTree(definition, createAgent({ work: succeed, after: succeed }));

                target.restore(snapshot);

                assert.deepEqual(JSON.parse(JSON.stringify(target.snapshot())), snapshot);
            });
        });
    });
});
