import { AnyState } from "./State";
import { RootNodeDefinition } from "./BehaviourTreeDefinition";

/**
 * The snapshot of an update promise result of an action node.
 */
export type UpdatePromiseResultSnapshot = {
    /**
     * Whether the promise was resolved rather than rejected.
     */
    isResolved: boolean;

    /**
     * The state that the promise resolved with, or the rejection reason as a string.
     * This will be null if the promise resolved with something that is not a valid finished state.
     */
    value: string | null;
};

/**
 * The snapshot of the execution state of a node, which is plain data that can be serialised as JSON.
 * Only the properties that are relevant to the type of node and its state will be defined.
 */
export type NodeSnapshot = {
    /**
     * The node type.
     */
    type: string;
    /**
     * The node name, which is used to detect whether a snapshot is being restored to a tree with a different definition.
     */
    name: string;
    /**
     * The state of the node.
     */
    state: AnyState;
    /**
     * The snapshots of the child nodes, defined if the node is a composite or decorator node.
     */
    children?: NodeSnapshot[];
    /**
     * The index of the child that was picked, defined for any `lotto` node that has picked a child.
     */
    selectedChild?: number;
    /**
     * The number of iterations that a `repeat` node will make, or null if it will make an unlimited number of iterations.
     */
    targetIterationCount?: number | null;
    /**
     * The number of iterations that a `repeat` node has completed.
     */
    currentIterationCount?: number;
    /**
     * The number of attempts that a `retry` node will make, or null if it will make an unlimited number of attempts.
     */
    targetAttemptCount?: number | null;
    /**
     * The number of attempts that a `retry` node has completed.
     */
    currentAttemptCount?: number;
    /**
     * The duration in milliseconds that a `wait` node is waiting for, or null if it will wait indefinitely.
     */
    totalDuration?: number | null;
    /**
     * The duration in milliseconds that a `wait` node has waited for at the point that the snapshot was taken.
     */
    waitedDuration?: number;
    /**
     * The result of the promise returned by an `action` node function, if the promise has settled but the node has not yet been updated to handle it.
     */
    updatePromiseResult?: UpdatePromiseResultSnapshot;
};

/**
 * The snapshot of the execution state of a behaviour tree, which is plain data that can be serialised as JSON.
 * It can only be restored to a tree that was created from the same definition.
 */
export type BehaviourTreeSnapshot = {
    /**
     * The snapshot format version.
     */
    version: number;
    /**
     * The identifier of the definition of the tree that the snapshot was taken from.
     * This is the same for an MDSL definition and its equivalent JSON definition, and is used to detect whether a snapshot is being restored to a tree with a different definition.
     */
    definition: string;
    /**
     * The snapshot of the root node, which contains the snapshots of every node in the tree.
     */
    root: NodeSnapshot;
};

/**
 * The current snapshot format version.
 */
export const SNAPSHOT_VERSION = 1;

/**
 * Gets a copy of a part of a definition in a canonical form, so that equivalent definitions have the same canonical form.
 * Properties are sorted, undefined properties are left out and so are the properties that have the same meaning as their absence,
 * which are empty arguments and a 'succeedOnAbort' of false. An MDSL definition will have these where an equivalent JSON definition may not.
 * @param value The part of the definition.
 * @returns The canonical form of the part of the definition.
 */
function canonicalise(value: unknown): unknown {
    if (Array.isArray(value)) {
        return value.map(canonicalise);
    }

    if (!isObject(value)) {
        return value;
    }

    const canonical: { [property: string]: unknown } = {};

    for (const property of Object.keys(value).sort()) {
        const propertyValue = value[property];

        const isDefault =
            propertyValue === undefined ||
            (property === "args" && Array.isArray(propertyValue) && propertyValue.length === 0) ||
            (property === "succeedOnAbort" && propertyValue === false);

        if (!isDefault) {
            canonical[property] = canonicalise(propertyValue);
        }
    }

    return canonical;
}

/**
 * Gets a 53-bit hash of a string (cyrb53), as hexadecimal.
 * @param text The string.
 * @returns The hash of the string.
 */
function hash(text: string): string {
    let h1 = 0xdeadbeef;
    let h2 = 0x41c6ce57;

    for (let index = 0; index < text.length; index++) {
        const code = text.charCodeAt(index);
        h1 = Math.imul(h1 ^ code, 2654435761);
        h2 = Math.imul(h2 ^ code, 1597334677);
    }

    h1 = Math.imul(h1 ^ (h1 >>> 16), 2246822507) ^ Math.imul(h2 ^ (h2 >>> 13), 3266489909);
    h2 = Math.imul(h2 ^ (h2 >>> 16), 2246822507) ^ Math.imul(h1 ^ (h1 >>> 13), 3266489909);

    return (4294967296 * (2097151 & h2) + (h1 >>> 0)).toString(16);
}

/**
 * Creates the identifier of a tree definition, which is stored in a snapshot to detect it being restored to a tree with a different definition.
 * The identifier does not depend on whether the definition was MDSL or JSON, or on the order of its root nodes.
 * Registered subtrees are not part of it, as they are not part of the definition.
 * @param definition The validated JSON definition, as an array of root node definitions.
 * @returns The definition identifier.
 */
export function createDefinitionIdentifier(definition: RootNodeDefinition[]): string {
    const rootNodes = definition.map((rootNode) => JSON.stringify(canonicalise(rootNode)));

    return hash(rootNodes.sort().join("\n"));
}

/**
 * Gets whether a value is a plain (non-array) object.
 * @param value The value.
 * @returns Whether the value is a plain (non-array) object.
 */
export function isObject(value: unknown): value is { [property: string]: unknown } {
    return typeof value === "object" && value !== null && !Array.isArray(value);
}

/**
 * Creates an error for an invalid snapshot.
 * @param message The message describing what is invalid.
 * @returns The error.
 */
export function invalidSnapshotError(message: string): Error {
    return new Error(`invalid snapshot: ${message}`);
}

/**
 * Validates that a node snapshot property is a non-negative integer, or optionally null.
 * @param snapshot The node snapshot.
 * @param path The path of the node snapshot.
 * @param property The name of the property to validate.
 * @param isNullable Whether the property can be null.
 */
export function validateCountProperty(
    snapshot: NodeSnapshot,
    path: string,
    property: keyof NodeSnapshot,
    isNullable = false
) {
    const value = snapshot[property];

    if (isNullable && value === null) {
        return;
    }

    if (typeof value !== "number" || !Number.isInteger(value) || value < 0) {
        throw invalidSnapshotError(
            `expected ${isNullable ? "null or " : ""}non-negative integer '${property}' at '${path}' but got '${value}'`
        );
    }
}

/**
 * Validates the child snapshots of a node snapshot against the child nodes that they will be restored to.
 * @param snapshot The node snapshot.
 * @param path The path of the node snapshot.
 * @param children The child nodes.
 */
export function validateChildSnapshots(
    snapshot: NodeSnapshot,
    path: string,
    children: { validateSnapshot(snapshot: unknown, path: string): void }[]
) {
    const childSnapshots: unknown = snapshot.children ?? [];

    if (!Array.isArray(childSnapshots) || childSnapshots.length !== children.length) {
        const count = Array.isArray(childSnapshots) ? childSnapshots.length : childSnapshots;
        throw invalidSnapshotError(`expected ${children.length} children at '${path}' but got ${count}`);
    }

    children.forEach((child, index) => child.validateSnapshot(childSnapshots[index], `${path}.children[${index}]`));
}
