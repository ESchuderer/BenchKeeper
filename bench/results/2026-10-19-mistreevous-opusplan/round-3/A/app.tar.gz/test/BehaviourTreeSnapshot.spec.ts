import { assert } from "chai";

import { BehaviourTree, State } from "../src/index";
import type { BehaviourTreeSnapshot } from "../src/index";
import type { NodeStateChange } from "../src/BehaviourTreeOptions";

import {
    Scenario,
    assertRestoredTreesBehaveIdentically,
    createScenarioAgent,
    getDetailsWithoutIds,
    useFakeClock
} from "./SnapshotUtilities";

const approveAtStep = (step: number) => (world: any, stepIndex: number) => {
    if (stepIndex === step) {
        world.approved = true;
    }
};

describe("A BehaviourTree", () => {
    const getClock = useFakeClock();

    describe("snapshot()", () => {
        it("returns a plain object that is unchanged by a trip through JSON", () => {
            const log: string[] = [];
            const tree = new BehaviourTree(
                "root { sequence { action [Work] wait [1000, 5000] repeat [2, 4] { action [Tick] } } }",
                createScenarioAgent({}, log)
            );

            for (let step = 0; step < 4; step++) {
                tree.step();

                const snapshot: BehaviourTreeSnapshot = tree.snapshot();

                assert.deepStrictEqual(JSON.parse(JSON.stringify(snapshot)), snapshot);
            }
        });

        it("returns a new object each time that does not share state with the tree", () => {
            const tree = new BehaviourTree(
                "root { sequence { action [Work] action [Work] } }",
                createScenarioAgent({}, [])
            );

            tree.step();

            const first = tree.snapshot();
            const second = tree.snapshot();

            assert.notStrictEqual(first, second);
            assert.deepStrictEqual(first, second);

            // Messing with a snapshot should not change the tree.
            first.root.state = State.FAILED;
            first.root.children![0].children![0].state = State.FAILED;

            assert.strictEqual(tree.getState(), State.RUNNING);
            assert.deepStrictEqual(tree.snapshot(), second);
        });

        it("does not change the tree or call any agent functions", () => {
            const log: string[] = [];
            const tree = new BehaviourTree(
                "root { sequence { action [Work] action [Work] } }",
                createScenarioAgent({}, log)
            );

            tree.step();

            const logLength = log.length;
            const details = getDetailsWithoutIds(tree);

            tree.snapshot();

            assert.strictEqual(log.length, logLength);
            assert.deepStrictEqual(getDetailsWithoutIds(tree), details);
        });
    });

    describe("restore()", () => {
        describe("will error without changing the tree if the snapshot", () => {
            const definition =
                "root { sequence { action [Work] repeat [3] { action [Tick] } lotto { action [Work] action [Tick] } } }";

            const createSteppedTree = () => {
                const tree = new BehaviourTree(definition, createScenarioAgent({}, []));
                tree.step();
                tree.step();
                return tree;
            };

            const assertRestoreErrors = (mutate: (snapshot: any) => any, message: string | RegExp) => {
                const snapshot = JSON.parse(JSON.stringify(createSteppedTree().snapshot()));
                const tree = createSteppedTree();
                const before = JSON.stringify(tree.snapshot());

                assert.throws(() => tree.restore(mutate(snapshot)), Error, message);
                assert.strictEqual(JSON.stringify(tree.snapshot()), before);
            };

            it("is not an object", () => {
                assertRestoreErrors(() => null, "invalid snapshot: expected an object");
                assertRestoreErrors(() => "snapshot", "invalid snapshot: expected an object");
                assertRestoreErrors(() => [], "invalid snapshot: expected an object");
            });

            it("is of an unsupported version", () => {
                assertRestoreErrors(
                    (snapshot) => ({ ...snapshot, version: 2 }),
                    "invalid snapshot: unsupported version '2'"
                );
                assertRestoreErrors(({ root }) => ({ root }), "invalid snapshot: unsupported version 'undefined'");
            });

            it("has no root node", () => {
                assertRestoreErrors(
                    ({ version, definition }) => ({ version, definition }),
                    "invalid snapshot: expected an object at 'root'"
                );
            });

            it("has a node of a different type", () => {
                assertRestoreErrors((snapshot) => {
                    snapshot.root.children[0].children[1].type = "retry";
                    return snapshot;
                }, "invalid snapshot: expected 'repeat' node at 'root.children[0].children[1]' but got 'retry'");
            });

            it("has a node with a different name, meaning that the definition has changed", () => {
                assertRestoreErrors((snapshot) => {
                    snapshot.root.children[0].children[0].name = "Home";
                    return snapshot;
                }, "invalid snapshot: expected node named 'Work' at 'root.children[0].children[0]' but got 'Home'");
            });

            it("has a node with a different number of children", () => {
                assertRestoreErrors((snapshot) => {
                    snapshot.root.children[0].children.pop();
                    return snapshot;
                }, "invalid snapshot: expected 3 children at 'root.children[0]' but got 2");

                assertRestoreErrors((snapshot) => {
                    delete snapshot.root.children;
                    return snapshot;
                }, "invalid snapshot: expected 1 children at 'root' but got 0");
            });

            it("has a node with an invalid state", () => {
                assertRestoreErrors((snapshot) => {
                    snapshot.root.children[0].children[0].state = "mistreevous.sleeping";
                    return snapshot;
                }, "invalid snapshot: invalid state 'mistreevous.sleeping' at 'root.children[0].children[0]'");
            });
        });

        it("will put a new tree in the state that the snapshot was taken in", () => {
            const log: string[] = [];
            const original = new BehaviourTree(
                "root { sequence { action [Work] action [Work] } }",
                createScenarioAgent({}, log)
            );

            original.step();
            original.step();

            const restored = new BehaviourTree(
                "root { sequence { action [Work] action [Work] } }",
                createScenarioAgent({}, [])
            );
            restored.restore(original.snapshot());

            assert.strictEqual(restored.getState(), State.RUNNING);
            assert.isTrue(restored.isRunning());
            assert.deepStrictEqual(getDetailsWithoutIds(restored), getDetailsWithoutIds(original));
        });

        it("will put a tree that has already been stepped back to the state that the snapshot was taken in", () => {
            const world = {};
            const log: string[] = [];
            const tree = new BehaviourTree(
                "root { sequence { action [Work] action [Work] } }",
                createScenarioAgent(world, log)
            );

            tree.step();

            const snapshot = tree.snapshot();
            const details = getDetailsWithoutIds(tree);

            tree.step();
            tree.step();
            tree.step();

            assert.notDeepEqual(getDetailsWithoutIds(tree), details);

            tree.restore(snapshot);

            assert.deepStrictEqual(getDetailsWithoutIds(tree), details);
            assert.deepStrictEqual(tree.snapshot(), snapshot);
        });

        it("will put a tree back to being ready if the snapshot was taken before it was ever stepped", () => {
            const tree = new BehaviourTree(
                "root { sequence { action [Work] action [Work] } }",
                createScenarioAgent({}, [])
            );
            const snapshot = tree.snapshot();

            tree.step();
            tree.step();
            tree.restore(snapshot);

            assert.strictEqual(tree.getState(), State.READY);
            assert.deepStrictEqual(tree.snapshot(), snapshot);
        });

        it("will not call the 'onNodeStateChange' option or any agent functions, but the next step will", () => {
            const definition = "root { sequence { action [Work] action [Work] } }";
            const log: string[] = [];
            const changes: NodeStateChange[] = [];

            const original = new BehaviourTree(definition, createScenarioAgent({}, []));
            original.step();

            // The next call of the action function will succeed, as it did for the tree that the snapshot was taken from.
            const restored = new BehaviourTree(definition, createScenarioAgent({ work: 2 }, log), {
                onNodeStateChange: (change) => changes.push(change)
            });
            restored.restore(original.snapshot());

            assert.strictEqual(restored.getState(), State.RUNNING);
            assert.isEmpty(changes);
            assert.isEmpty(log);

            restored.step();

            assert.deepStrictEqual(
                changes.map(({ type, previousState, state }) => [type, previousState, state]),
                [
                    ["action", State.RUNNING, State.SUCCEEDED],
                    ["action", State.READY, State.RUNNING]
                ]
            );
        });

        it("will not call the 'onNodeStateChange' option when restoring a tree that has already been stepped", () => {
            const definition = "root { sequence { action [Work] action [Work] } }";
            const changes: NodeStateChange[] = [];

            const original = new BehaviourTree(definition, createScenarioAgent({}, []));
            const readySnapshot = original.snapshot();
            original.step();

            const tree = new BehaviourTree(definition, createScenarioAgent({}, []), {
                onNodeStateChange: (change) => changes.push(change)
            });
            tree.step();
            changes.length = 0;

            tree.restore(readySnapshot);
            tree.restore(original.snapshot());

            assert.isEmpty(changes);
            assert.strictEqual(tree.getState(), State.RUNNING);
        });
    });

    describe("restore() will error without changing the tree if the snapshot", () => {
        const assertRestoreErrors = (definition: string, mutate: (snapshot: any) => void, message: string) => {
            const createSteppedTree = () => {
                const tree = new BehaviourTree(definition, createScenarioAgent({}, []));
                tree.step();
                tree.step();
                return tree;
            };

            const snapshot = JSON.parse(JSON.stringify(createSteppedTree().snapshot()));
            const tree = createSteppedTree();
            const before = JSON.stringify(tree.snapshot());

            mutate(snapshot);

            assert.throws(() => tree.restore(snapshot), Error, message);
            assert.strictEqual(JSON.stringify(tree.snapshot()), before);
        };

        for (const [type, definition, properties, nullable] of [
            [
                "repeat",
                "root { repeat [3] { action [Work] } }",
                ["targetIterationCount", "currentIterationCount"],
                "targetIterationCount"
            ],
            [
                "retry",
                "root { retry [3] { action [Work] } }",
                ["targetAttemptCount", "currentAttemptCount"],
                "targetAttemptCount"
            ]
        ] as const) {
            for (const property of properties) {
                it(`has a ${type} node with a missing '${property}'`, () => {
                    assertRestoreErrors(
                        definition,
                        (snapshot) => delete snapshot.root.children[0][property],
                        `invalid snapshot: expected ${
                            property === nullable ? "null or " : ""
                        }non-negative integer '${property}' at 'root.children[0]' but got 'undefined'`
                    );
                });

                it(`has a ${type} node with a '${property}' that is not a non-negative integer`, () => {
                    for (const value of [-1, 1.5, "2", true, NaN]) {
                        assertRestoreErrors(
                            definition,
                            (snapshot) => (snapshot.root.children[0][property] = value),
                            `invalid snapshot: expected ${
                                property === nullable ? "null or " : ""
                            }non-negative integer '${property}' at 'root.children[0]' but got '${value}'`
                        );
                    }
                });
            }
        }

        it("has a lotto node that has picked a child that does not exist", () => {
            for (const value of [-1, 2, 0.5, "0", null]) {
                assertRestoreErrors(
                    "root { lotto { action [Work] action [Work] } }",
                    (snapshot) => (snapshot.root.children[0].selectedChild = value),
                    `invalid snapshot: expected a 'selectedChild' that is the index of a child at 'root.children[0]' but got '${value}'`
                );
            }
        });

        it("has a lotto node that is not ready and has not picked a child", () => {
            assertRestoreErrors(
                "root { lotto { action [Work] action [Work] } }",
                (snapshot) => delete snapshot.root.children[0].selectedChild,
                "invalid snapshot: expected a 'selectedChild' that is the index of a child at 'root.children[0]' but got 'undefined'"
            );
        });
    });

    describe("restoring a snapshot will keep random choices that have already been made", () => {
        const createRandomTree = (definition: string, random: number) => {
            const log: string[] = [];
            const tree = new BehaviourTree(definition, createScenarioAgent({}, log), { random: () => random });
            return { tree, log };
        };

        const stepUntil = (tree: BehaviourTree, state: State) => {
            for (let step = 0; step < 50 && tree.getState() !== state; step++) {
                tree.step();
            }

            assert.strictEqual(tree.getState(), state);
        };

        const countCalls = (log: string[], name: string) => log.filter((entry) => entry === name).length;

        it("for the number of iterations of a repeat node", () => {
            const definition = "root { repeat [2, 5] { action [Tick] exit(OnExit) } }";
            const { tree: original } = createRandomTree(definition, 0.99);
            original.step();

            const { tree, log } = createRandomTree(definition, 0);
            tree.restore(original.snapshot());

            stepUntil(tree, State.SUCCEEDED);

            assert.strictEqual(countCalls(log, "Tick"), 5 * 2);
        });

        it("for the number of attempts of a retry node", () => {
            const definition = "root { retry [2, 5] { action [AlwaysFail] } }";
            const { tree: original } = createRandomTree(definition, 0.99);
            original.step();

            const { tree, log } = createRandomTree(definition, 0);
            tree.restore(original.snapshot());

            stepUntil(tree, State.FAILED);

            // The first attempt was made by the original tree.
            assert.strictEqual(countCalls(log, "AlwaysFail"), 5 - 1);
        });

        it("for the child that a lotto node picked", () => {
            const definition = "root { lotto { action [Work] action [Tick] action [Approval] } }";
            const picked = new Set<string>();

            for (const random of [0, 0.5, 0.99]) {
                const { tree: original, log: originalLog } = createRandomTree(definition, random);
                original.step();

                // This tree would pick a different child if it did not restore the one that was picked.
                const { tree, log } = createRandomTree(definition, 1 - random - 0.01);
                tree.restore(original.snapshot());
                tree.step();

                assert.strictEqual(originalLog.length, 1);
                assert.deepStrictEqual(log, originalLog);

                picked.add(originalLog[0]);
            }

            // Make sure that the test was picking different children.
            assert.isAbove(picked.size, 1);
        });
    });

    describe("restoring a snapshot will make a wait node wait only for the time remaining", () => {
        const HOUR = 60 * 60 * 1000;

        it("when using the clock", () => {
            const clock = getClock();
            const definition = "root { wait [5000] }";
            const original = new BehaviourTree(definition, {});

            original.step();
            clock.tick(3000);

            const snapshot = JSON.parse(JSON.stringify(original.snapshot()));

            // The time between taking the snapshot and restoring it should not count, even if the original tree was left to carry on.
            clock.tick(HOUR);
            original.step();
            assert.strictEqual(original.getState(), State.SUCCEEDED);

            const restored = new BehaviourTree(definition, {});
            restored.restore(snapshot);

            restored.step();
            assert.strictEqual(restored.getState(), State.RUNNING);

            clock.tick(1999);
            restored.step();
            assert.strictEqual(restored.getState(), State.RUNNING);

            clock.tick(1);
            restored.step();
            assert.strictEqual(restored.getState(), State.SUCCEEDED);
        });

        it("when using the 'getDeltaTime' option", () => {
            const clock = getClock();
            const definition = "root { wait [5000] }";
            const getDeltaTime = () => 1;
            const original = new BehaviourTree(definition, {}, { getDeltaTime });

            // The first step already waits for one delta time.
            original.step();
            original.step();
            original.step();

            const snapshot = JSON.parse(JSON.stringify(original.snapshot()));

            clock.tick(HOUR);

            const restored = new BehaviourTree(definition, {}, { getDeltaTime });
            restored.restore(snapshot);

            restored.step();
            assert.strictEqual(restored.getState(), State.RUNNING);

            restored.step();
            assert.strictEqual(restored.getState(), State.SUCCEEDED);
        });

        it("when the tree was restored from a snapshot taken from a tree using the clock to a tree using the 'getDeltaTime' option", () => {
            const clock = getClock();
            const definition = "root { wait [5000] }";
            const original = new BehaviourTree(definition, {});

            original.step();
            clock.tick(4000);

            const restored = new BehaviourTree(definition, {}, { getDeltaTime: () => 0.5 });
            restored.restore(original.snapshot());

            restored.step();
            assert.strictEqual(restored.getState(), State.RUNNING);

            restored.step();
            assert.strictEqual(restored.getState(), State.SUCCEEDED);
        });
    });

    describe("restore() will error without changing the tree if the snapshot has a wait node with", () => {
        const assertRestoreErrors = (mutate: (snapshot: any) => void, message: string) => {
            const createSteppedTree = () => {
                const tree = new BehaviourTree("root { wait [5000] }", {});
                tree.step();
                return tree;
            };

            const snapshot = JSON.parse(JSON.stringify(createSteppedTree().snapshot()));
            const tree = createSteppedTree();
            const before = JSON.stringify(tree.snapshot());

            mutate(snapshot);

            assert.throws(() => tree.restore(snapshot), Error, message);
            assert.strictEqual(JSON.stringify(tree.snapshot()), before);
        };

        it("a missing or invalid total duration", () => {
            for (const value of [undefined, -1, 1.5, "5000", NaN]) {
                assertRestoreErrors(
                    (snapshot) => (snapshot.root.children[0].totalDuration = value),
                    `invalid snapshot: expected null or non-negative integer 'totalDuration' at 'root.children[0]' but got '${value}'`
                );
            }
        });

        it("a missing or invalid waited duration", () => {
            for (const value of [undefined, null, Infinity, "5000", NaN]) {
                assertRestoreErrors(
                    (snapshot) => (snapshot.root.children[0].waitedDuration = value),
                    `invalid snapshot: expected finite number 'waitedDuration' at 'root.children[0]' but got '${value}'`
                );
            }
        });
    });

    describe("a snapshot", () => {
        const create = (definition: string | any) => new BehaviourTree(definition, createScenarioAgent({}, []));

        it("records the definition of the tree, which is the same for every tree created from the definition", () => {
            const definition = "root { sequence { action [Work] wait [1000] } }";

            const first = create(definition).snapshot();
            const second = create(definition).snapshot();

            assert.isString(first.definition);
            assert.isNotEmpty(first.definition);
            assert.strictEqual(first.definition, second.definition);

            // It is not affected by the state of the tree.
            const tree = create(definition);
            tree.step();
            assert.strictEqual(tree.snapshot().definition, first.definition);
        });

        it("records a different definition for every kind of change to the definition", () => {
            const definitions = [
                "root { sequence { action [Work] wait [1000] } }",
                "root { selector { action [Work] wait [1000] } }",
                "root { sequence { wait [1000] action [Work] } }",
                "root { sequence { action [Tick] wait [1000] } }",
                "root { sequence { action [Work, 1] wait [1000] } }",
                "root { sequence { action [Work, 2] wait [1000] } }",
                'root { sequence { action [Work, "1"] wait [1000] } }',
                "root { sequence { action [Work] wait [2000] } }",
                "root { sequence { action [Work] wait [1000, 2000] } }",
                "root { sequence { action [Work] wait } }",
                "root { sequence { action [Work] while(IsActive) wait [1000] } }",
                "root { sequence { action [Work] while(IsActive, true) wait [1000] } }",
                "root { sequence { action [Work] until(IsActive) wait [1000] } }",
                "root { sequence { action [Work] entry(OnEntry) wait [1000] } }",
                "root { sequence { action [Work] step(OnEntry) wait [1000] } }",
                "root { sequence { action [Work] exit(OnEntry) wait [1000] } }",
                "root { repeat [3] { action [Work] } }",
                "root { repeat [4] { action [Work] } }",
                "root { repeat [3, 4] { action [Work] } }",
                "root { repeat { action [Work] } }",
                "root { retry [3] { action [Work] } }",
                "root { retry [4] { action [Work] } }",
                "root { lotto { action [Work] action [Tick] } }",
                "root { lotto [1, 2] { action [Work] action [Tick] } }",
                "root { lotto [2, 1] { action [Work] action [Tick] } }",
                "root { condition [IsActive] }",
                "root { flip { condition [IsActive] } }"
            ];

            const ids = definitions.map((definition) => create(definition).snapshot().definition);

            assert.strictEqual(new Set(ids).size, definitions.length);
        });

        it("records the same definition for an MDSL definition and its equivalent JSON definition", () => {
            const mdsl = `
                root {
                    sequence while(IsActive, true) {
                        action [Work, 1, "two", null, false, $three] entry(OnEntry)
                        wait [1000, 2000]
                        repeat [2, 4] {
                            lotto [1, 3] {
                                condition [IsDone] until(IsDone)
                                action [Tick]
                            }
                        }
                    }
                }`;

            // The JSON definition leaves out defaults, such as empty arguments, and has its properties in a different order.
            const json = {
                type: "root",
                child: {
                    children: [
                        {
                            call: "Work",
                            args: [1, "two", null, false, { $: "three" }],
                            type: "action",
                            entry: { call: "OnEntry" }
                        },
                        { type: "wait", duration: [1000, 2000] },
                        {
                            iterations: [2, 4],
                            type: "repeat",
                            child: {
                                type: "lotto",
                                weights: [1, 3],
                                children: [
                                    { type: "condition", call: "IsDone", until: { call: "IsDone" } },
                                    { type: "action", call: "Tick" }
                                ]
                            }
                        }
                    ],
                    type: "sequence",
                    while: { call: "IsActive", args: [true] }
                }
            };

            const fromMDSL = create(mdsl).snapshot();

            assert.strictEqual(create(json).snapshot().definition, fromMDSL.definition);
            assert.strictEqual(create([json]).snapshot().definition, fromMDSL.definition);
        });

        it("records the same definition however the root nodes of a definition are ordered", () => {
            const first = "root { branch [Sub1] } root [Sub1] { action [Work] } root [Sub2] { action [Tick] }";
            const second = "root [Sub2] { action [Tick] } root { branch [Sub1] } root [Sub1] { action [Work] }";

            assert.strictEqual(create(first).snapshot().definition, create(second).snapshot().definition);
        });

        it("records a different definition if a subtree of the definition is different", () => {
            const definition = (action: string) => `root { branch [Sub] } root [Sub] { action [${action}] }`;

            assert.notStrictEqual(
                create(definition("Work")).snapshot().definition,
                create(definition("Tick")).snapshot().definition
            );
        });
    });

    describe("restore() with a snapshot of another definition", () => {
        const definition = "root { sequence { action [Work] repeat [3] { action [Tick] } wait [1000] } }";

        const createSteppedTree = (definition: string | any) => {
            const tree = new BehaviourTree(definition, createScenarioAgent({}, []));
            tree.step();
            tree.step();
            return tree;
        };

        const assertRestoreErrors = (otherDefinition: string | any) => {
            const snapshot = JSON.parse(JSON.stringify(createSteppedTree(otherDefinition).snapshot()));
            const tree = createSteppedTree(definition);
            const snapshotBefore = JSON.stringify(tree.snapshot());
            const detailsBefore = getDetailsWithoutIds(tree);

            assert.throws(() => tree.restore(snapshot), Error, "does not match the tree's definition");

            assert.strictEqual(JSON.stringify(tree.snapshot()), snapshotBefore);
            assert.deepStrictEqual(getDetailsWithoutIds(tree), detailsBefore);
        };

        it("will error without changing the tree if a node has a different type", () => {
            assertRestoreErrors("root { selector { action [Work] repeat [3] { action [Tick] } wait [1000] } }");
        });

        it("will error without changing the tree if the nodes are of the same types but have different names", () => {
            assertRestoreErrors("root { sequence { action [Work] repeat [3] { action [Flaky] } wait [1000] } }");
        });

        it("will error without changing the tree if the nodes only have different arguments", () => {
            assertRestoreErrors("root { sequence { action [Work] repeat [3] { action [Tick, 1] } wait [1000] } }");
        });

        it("will error without changing the tree if the nodes only have different attributes", () => {
            assertRestoreErrors(
                "root { sequence { action [Work] repeat [3] { action [Tick] entry(OnEntry) } wait [1000] } }"
            );
            assertRestoreErrors(
                "root { sequence while(IsActive) { action [Work] repeat [3] { action [Tick] } wait [1000] } }"
            );
        });

        it("will error without changing the tree if the nodes only have different iteration counts or durations", () => {
            assertRestoreErrors("root { sequence { action [Work] repeat [4] { action [Tick] } wait [1000] } }");
            assertRestoreErrors("root { sequence { action [Work] repeat [3] { action [Tick] } wait [2000] } }");
        });

        it("will error without changing the tree if the snapshot has a different number of nodes", () => {
            assertRestoreErrors("root { sequence { action [Work] repeat [3] { action [Tick] } } }");
            assertRestoreErrors(
                "root { sequence { action [Work] repeat [3] { action [Tick] } wait [1000] wait [1000] } }"
            );
        });

        it("will error without changing the tree if the snapshot is of a definition that is a part of this one", () => {
            assertRestoreErrors("root { action [Work] }");
        });

        it("will error without changing the tree if only the recorded definition of the snapshot is tampered with", () => {
            const snapshot = JSON.parse(JSON.stringify(createSteppedTree(definition).snapshot()));
            const tree = createSteppedTree(definition);
            const before = JSON.stringify(tree.snapshot());

            snapshot.definition = `${snapshot.definition}0`;

            assert.throws(() => tree.restore(snapshot), Error, "does not match the tree's definition");
            assert.strictEqual(JSON.stringify(tree.snapshot()), before);
        });

        it("will error without changing the tree if the snapshot was taken after the other tree finished", () => {
            const finished = new BehaviourTree("root { action [AlwaysFail] }", createScenarioAgent({}, []));
            finished.step();

            const tree = createSteppedTree(definition);
            const before = JSON.stringify(tree.snapshot());

            assert.throws(() => tree.restore(finished.snapshot()), Error, "does not match the tree's definition");
            assert.strictEqual(JSON.stringify(tree.snapshot()), before);
        });

        it("will restore a snapshot of the same definition given as MDSL or as the equivalent JSON", () => {
            const mdsl = "root { sequence { action [Work, 1] while(IsActive, true) wait [1000, 2000] } }";
            const json = {
                type: "root",
                child: {
                    type: "sequence",
                    children: [
                        { type: "action", call: "Work", args: [1], while: { call: "IsActive", args: [true] } },
                        { type: "wait", duration: [1000, 2000] }
                    ]
                }
            };

            for (const [from, to] of [
                [mdsl, json],
                [json, mdsl]
            ]) {
                const source = createSteppedTree(from);
                const tree = new BehaviourTree(to as any, createScenarioAgent({}, []));

                tree.restore(JSON.parse(JSON.stringify(source.snapshot())));

                assert.deepStrictEqual(getDetailsWithoutIds(tree), getDetailsWithoutIds(source));
                assert.deepStrictEqual(tree.snapshot(), source.snapshot());
            }
        });
    });

    describe("restore() with something that is not a snapshot", () => {
        const createSteppedTree = () => {
            const tree = new BehaviourTree(
                "root { sequence { action [Work] action [Work] } }",
                createScenarioAgent({}, [])
            );
            tree.step();
            return tree;
        };

        const validSnapshot = () => JSON.parse(JSON.stringify(createSteppedTree().snapshot()));

        for (const [description, value] of [
            ["null", null],
            ["undefined", undefined],
            ["a string", "snapshot"],
            ["a JSON string of a snapshot", JSON.stringify(validSnapshot())],
            ["a number", 5],
            ["a boolean", true],
            ["a function", () => validSnapshot()],
            ["an array", []],
            ["an array of a snapshot", [validSnapshot()]],
            ["an empty object", {}],
            ["an object without the fields of a snapshot", { name: "snapshot", state: State.RUNNING }],
            ["an object with only a version", { version: 1 }],
            ["an object with only a definition", { definition: validSnapshot().definition }],
            ["an object with only a root", { root: validSnapshot().root }],
            ["an object with a version and a root but no definition", { version: 1, root: validSnapshot().root }],
            [
                "an object with a version and a definition but no root",
                { version: 1, definition: validSnapshot().definition }
            ],
            ["an object with a definition that is not a string", { ...validSnapshot(), definition: 5 }],
            ["an object with a root that is not an object", { ...validSnapshot(), root: "root" }],
            ["an object with a null root", { ...validSnapshot(), root: null }]
        ] as [string, any][]) {
            it(`will error without changing the tree if given ${description}`, () => {
                const tree = createSteppedTree();
                const before = JSON.stringify(tree.snapshot());
                const detailsBefore = getDetailsWithoutIds(tree);

                assert.throws(() => tree.restore(value), Error);

                assert.strictEqual(JSON.stringify(tree.snapshot()), before);
                assert.deepStrictEqual(getDetailsWithoutIds(tree), detailsBefore);
            });
        }
    });

    describe("restoring a snapshot taken while an action node has a promise", () => {
        type Deferred = { promise: Promise<any>; resolve: (value: any) => void; reject: (reason: any) => void };

        const defer = (): Deferred => {
            const deferred = {} as Deferred;
            deferred.promise = new Promise((resolve, reject) => Object.assign(deferred, { resolve, reject }));
            return deferred;
        };

        // Give any promise handlers a chance to be called.
        const flushPromises = async () => {
            for (let tick = 0; tick < 5; tick++) {
                await Promise.resolve();
            }
        };

        const definition = "root { sequence { action [Fetch] action [Done] } }";

        const createFetchTree = (deferreds: Deferred[], log: string[]) =>
            new BehaviourTree(definition, {
                Fetch: () => {
                    log.push("Fetch");
                    const deferred = defer();
                    deferreds.push(deferred);
                    return deferred.promise;
                },
                Done: () => {
                    log.push("Done");
                    return State.SUCCEEDED;
                }
            });

        it("will use the result of the promise if it had settled, without calling the action function again", async () => {
            for (const result of [State.SUCCEEDED, State.FAILED]) {
                const deferreds: Deferred[] = [];
                const original = createFetchTree(deferreds, []);

                original.step();
                deferreds[0].resolve(result);
                await flushPromises();

                const snapshot = JSON.parse(JSON.stringify(original.snapshot()));

                const log: string[] = [];
                const restored = createFetchTree(deferreds, log);
                restored.restore(snapshot);

                assert.strictEqual(restored.getState(), State.RUNNING);

                restored.step();
                original.step();

                assert.strictEqual(restored.getState(), original.getState());
                assert.deepStrictEqual(getDetailsWithoutIds(restored), getDetailsWithoutIds(original));
                assert.deepStrictEqual(log, result === State.SUCCEEDED ? ["Done"] : []);
                assert.strictEqual(deferreds.length, 1);
            }
        });

        it("will throw as the original tree would if the promise was rejected", async () => {
            const deferreds: Deferred[] = [];
            const original = createFetchTree(deferreds, []);

            original.step();
            deferreds[0].reject(new Error("no network"));
            await flushPromises();

            const restored = createFetchTree([], []);
            restored.restore(JSON.parse(JSON.stringify(original.snapshot())));

            const expected = /^error stepping tree: action function 'Fetch' promise rejected with 'Error: no network'$/;

            assert.throws(() => original.step(), Error, expected);
            assert.throws(() => restored.step(), Error, expected);
        });

        it("will throw as the original tree would if the promise was resolved with an invalid value", async () => {
            const deferreds: Deferred[] = [];
            const original = createFetchTree(deferreds, []);

            original.step();
            deferreds[0].resolve("banana");
            await flushPromises();

            const restored = createFetchTree([], []);
            restored.restore(JSON.parse(JSON.stringify(original.snapshot())));

            const expected = /^error stepping tree: action node promise resolved with an invalid value/;

            assert.throws(() => original.step(), Error, expected);
            assert.throws(() => restored.step(), Error, expected);
        });

        it("will not be affected by a promise that settles after restoring", async () => {
            const settled: Deferred[] = [];
            const source = createFetchTree(settled, []);
            source.step();
            settled[0].resolve(State.SUCCEEDED);
            await flushPromises();

            const pending: Deferred[] = [];
            const log: string[] = [];
            const tree = createFetchTree(pending, log);
            tree.step();

            // Restoring a snapshot with a settled promise should ignore the promise that is still pending.
            tree.restore(source.snapshot());
            pending[0].resolve(State.FAILED);
            await flushPromises();

            tree.step();
            assert.strictEqual(tree.getState(), State.SUCCEEDED);
            assert.deepStrictEqual(log, ["Fetch", "Done"]);

            // Restoring a snapshot without a promise should also ignore it, and call the action function again.
            const next: Deferred[] = [];
            const nextTree = createFetchTree(next, []);
            const ready = nextTree.snapshot();
            nextTree.step();
            nextTree.restore(ready);
            nextTree.step();
            next[0].resolve(State.FAILED);
            await flushPromises();
            next[1].resolve(State.SUCCEEDED);
            await flushPromises();
            nextTree.step();
            assert.strictEqual(nextTree.getState(), State.SUCCEEDED);
        });

        it("will restore an action whose promise is still pending as not yet started, calling its action function again", async () => {
            const deferreds: Deferred[] = [];
            const original = createFetchTree(deferreds, []);

            original.step();

            // The snapshot can be taken while the promise is pending, and is plain JSON.
            const snapshot = original.snapshot();
            assert.deepStrictEqual(JSON.parse(JSON.stringify(snapshot)), snapshot);
            assert.strictEqual(snapshot.root.children![0].children![0].state, State.READY);

            const restoredDeferreds: Deferred[] = [];
            const log: string[] = [];
            const restored = createFetchTree(restoredDeferreds, log);
            restored.restore(JSON.parse(JSON.stringify(snapshot)));

            // Restoring does not call the action function.
            assert.isEmpty(log);
            assert.strictEqual(restored.getState(), State.RUNNING);
            assert.strictEqual(getDetailsWithoutIds(restored).children[0].children[0].state, State.READY);

            // The next step calls the action function again, and waits for the new promise.
            restored.step();
            assert.deepStrictEqual(log, ["Fetch"]);
            assert.strictEqual(restored.getState(), State.RUNNING);

            restored.step();
            assert.deepStrictEqual(log, ["Fetch"]);

            restoredDeferreds[0].resolve(State.SUCCEEDED);
            await flushPromises();
            restored.step();

            assert.deepStrictEqual(log, ["Fetch", "Done"]);
            assert.strictEqual(restored.getState(), State.SUCCEEDED);
        });

        it("will not affect the tree that the snapshot was taken from", async () => {
            const deferreds: Deferred[] = [];
            const log: string[] = [];
            const tree = createFetchTree(deferreds, log);

            tree.step();
            tree.snapshot();
            tree.snapshot();

            assert.strictEqual(getDetailsWithoutIds(tree).children[0].children[0].state, State.RUNNING);

            // The tree still waits for the original promise, and does not call the action function again.
            tree.step();
            assert.deepStrictEqual(log, ["Fetch"]);

            deferreds[0].resolve(State.SUCCEEDED);
            await flushPromises();
            tree.step();

            assert.deepStrictEqual(log, ["Fetch", "Done"]);
            assert.strictEqual(tree.getState(), State.SUCCEEDED);
        });

        it("will ignore the pending promise when restored to the tree that the snapshot was taken from", async () => {
            const deferreds: Deferred[] = [];
            const log: string[] = [];
            const tree = createFetchTree(deferreds, log);

            tree.step();
            tree.restore(tree.snapshot());
            tree.step();

            assert.deepStrictEqual(log, ["Fetch", "Fetch"]);

            // The promise from before the restore should have no effect, unlike the promise from after it.
            deferreds[0].resolve(State.FAILED);
            await flushPromises();
            tree.step();
            assert.strictEqual(tree.getState(), State.RUNNING);

            deferreds[1].resolve(State.SUCCEEDED);
            await flushPromises();
            tree.step();
            assert.strictEqual(tree.getState(), State.SUCCEEDED);
            assert.deepStrictEqual(log, ["Fetch", "Fetch", "Done"]);
        });

        it("will call the entry callback of the action again, as it has not yet started", () => {
            const log: string[] = [];
            const create = () =>
                new BehaviourTree("root { action [Fetch] entry(OnEntry) exit(OnExit) }", {
                    Fetch: () => {
                        log.push("Fetch");
                        return new Promise<State.SUCCEEDED>(() => {});
                    },
                    OnEntry: () => log.push("OnEntry"),
                    OnExit: () => log.push("OnExit")
                });

            const original = create();
            original.step();
            assert.deepStrictEqual(log, ["OnEntry", "Fetch"]);

            log.length = 0;
            const restored = create();
            restored.restore(original.snapshot());
            assert.isEmpty(log);

            restored.step();
            assert.deepStrictEqual(log, ["OnEntry", "Fetch"]);
        });

        it("will keep the results of other nodes, only restoring the actions with a pending promise as not yet started", async () => {
            const deferreds: Record<string, Deferred> = {};
            const log: string[] = [];
            const create = () =>
                new BehaviourTree(
                    "root { parallel { action [Settled] action [Pending] action [Quick] sequence { action [Quick] wait [5000] } } }",
                    {
                        Settled: () => {
                            log.push("Settled");
                            return (deferreds.Settled = defer()).promise;
                        },
                        Pending: () => {
                            log.push("Pending");
                            return (deferreds.Pending = defer()).promise;
                        },
                        Quick: () => {
                            log.push("Quick");
                            return State.SUCCEEDED;
                        }
                    }
                );

            const original = create();
            original.step();
            deferreds.Settled.resolve(State.SUCCEEDED);
            await flushPromises();

            const snapshot = original.snapshot();
            const states = snapshot.root.children![0].children!.map(({ state }) => state);
            assert.deepStrictEqual(states, [State.RUNNING, State.READY, State.SUCCEEDED, State.RUNNING]);

            log.length = 0;
            const restored = create();
            restored.restore(JSON.parse(JSON.stringify(snapshot)));
            restored.step();

            // Only the pending action is called again.
            assert.deepStrictEqual(log, ["Pending"]);
            assert.deepStrictEqual(
                getDetailsWithoutIds(restored).children[0].children.map(({ state }: any) => state),
                [State.SUCCEEDED, State.RUNNING, State.SUCCEEDED, State.RUNNING]
            );

            deferreds.Pending.resolve(State.SUCCEEDED);
            await flushPromises();
            restored.step();

            assert.deepStrictEqual(log, ["Pending"]);
            assert.strictEqual(restored.getState(), State.RUNNING);
        });

        it("will restore an action with a pending promise nested in other nodes as not yet started", async () => {
            for (const definition of [
                "root { repeat [2] { action [Fetch] } }",
                "root { retry [2] { action [Fetch] } }",
                "root { selector { action [Fetch] action [Done] } }",
                "root { lotto { action [Fetch] } }",
                "root { race { action [Fetch] wait [5000] } }",
                "root { all { action [Fetch] wait [5000] } }",
                "root { flip { action [Fetch] } }",
                "root { sequence { branch [Sub] } } root [Sub] { action [Fetch] }"
            ]) {
                const create = (deferreds: Deferred[], log: string[]) =>
                    new BehaviourTree(definition, {
                        Fetch: () => {
                            log.push("Fetch");
                            return deferreds[deferreds.push(defer()) - 1].promise;
                        },
                        Done: () => State.SUCCEEDED
                    });

                const original = create([], []);
                original.step();

                const log: string[] = [];
                const deferreds: Deferred[] = [];
                const restored = create(deferreds, log);
                restored.restore(JSON.parse(JSON.stringify(original.snapshot())));

                assert.strictEqual(restored.getState(), State.RUNNING, definition);

                restored.step();
                assert.deepStrictEqual(log, ["Fetch"], definition);

                deferreds[0].resolve(State.SUCCEEDED);
                await flushPromises();
                restored.step();

                assert.deepStrictEqual(log, ["Fetch"], definition);
            }
        });

        it("will take a snapshot of a restored tree that is waiting for the action function to be called again", async () => {
            const deferreds: Deferred[] = [];
            const original = createFetchTree(deferreds, []);
            original.step();

            const restored = createFetchTree([], []);
            restored.restore(original.snapshot());

            assert.deepStrictEqual(restored.snapshot(), original.snapshot());

            // Once stepped it has a pending promise again, which is saved in the same way.
            restored.step();
            assert.deepStrictEqual(restored.snapshot(), original.snapshot());
        });

        it("will not be possible to take if the action node is in a pending state that was left behind by a finished run", async () => {
            const deferreds: Deferred[] = [];
            const tree = createFetchTree(deferreds, []);

            tree.step();
            deferreds[0].resolve(State.SUCCEEDED);
            await flushPromises();
            tree.step();

            assert.strictEqual(tree.getState(), State.SUCCEEDED);
            assert.doesNotThrow(() => tree.snapshot());
        });
    });

    describe("restore() will error without changing the tree if the snapshot has an action node with an invalid update promise result", () => {
        const createRunningTree = () => {
            const tree = new BehaviourTree("root { action [Work] }", createScenarioAgent({}, []));
            tree.step();
            return tree;
        };

        for (const [description, result] of [
            ["that is not an object", "settled"],
            ["with no 'isResolved' boolean", { value: State.SUCCEEDED }],
            ["with a 'value' that is not a string or null", { isResolved: true, value: 5 }],
            [
                "with a resolved 'value' that is a string but not a finished state",
                { isResolved: true, value: "banana" }
            ],
            ["with a resolved 'value' that is not a finished state", { isResolved: true, value: State.RUNNING }]
        ] as const) {
            it(description, () => {
                const snapshot = JSON.parse(JSON.stringify(createRunningTree().snapshot()));
                snapshot.root.children[0].updatePromiseResult = result;

                const tree = createRunningTree();
                const before = JSON.stringify(tree.snapshot());

                assert.throws(
                    () => tree.restore(snapshot),
                    Error,
                    "invalid snapshot: invalid 'updatePromiseResult' at 'root.children[0]'"
                );
                assert.strictEqual(JSON.stringify(tree.snapshot()), before);
            });
        }
    });

    describe("restoring a snapshot of a finished tree", () => {
        const createTree = (definition: string, randoms: number[], log: string[]) => {
            let index = 0;

            return new BehaviourTree(definition, createScenarioAgent({}, log), {
                random: () => randoms[index++]
            });
        };

        const stepUntilFinished = (tree: BehaviourTree) => {
            let steps = 0;

            do {
                tree.step();
                steps++;
            } while (tree.isRunning() && steps < 50);

            assert.isFalse(tree.isRunning());

            return steps;
        };

        it("will leave the tree finished and not call any agent functions", () => {
            for (const definition of [
                "root { repeat [3] { action [Tick] } }",
                "root { sequence { action [Tick] action [AlwaysFail] } }"
            ]) {
                const log: string[] = [];
                const original = createTree(definition, [], log);
                stepUntilFinished(original);

                const restoredLog: string[] = [];
                const restored = createTree(definition, [], restoredLog);
                restored.restore(JSON.parse(JSON.stringify(original.snapshot())));

                assert.notStrictEqual(restored.getState(), State.READY);
                assert.strictEqual(restored.getState(), original.getState());
                assert.isFalse(restored.isRunning());
                assert.deepStrictEqual(getDetailsWithoutIds(restored), getDetailsWithoutIds(original));
                assert.isEmpty(restoredLog);
            }
        });

        const assertNextRunMatchesOriginal = (definition: string, randoms: number[]) => {
            const originalLog: string[] = [];
            let randomsUsed = 0;
            const original = new BehaviourTree(definition, createScenarioAgent({}, originalLog), {
                random: () => randoms[randomsUsed++]
            });

            stepUntilFinished(original);

            const firstRunLog = originalLog.splice(0);
            const randomsUsedByFirstRun = randomsUsed;
            const snapshot = JSON.parse(JSON.stringify(original.snapshot()));

            // The original tree carries on to do another run, using the next random numbers.
            stepUntilFinished(original);

            // The restored tree should do the same given the same next random numbers.
            const log: string[] = [];
            const restored = createTree(definition, randoms.slice(randomsUsedByFirstRun), log);
            restored.restore(snapshot);

            assert.isFalse(restored.isRunning());

            stepUntilFinished(restored);

            assert.deepStrictEqual(log, originalLog);
            assert.deepStrictEqual(getDetailsWithoutIds(restored), getDetailsWithoutIds(original));

            return { firstRunLog, secondRunLog: log };
        };

        it("will start a new run on the next step that makes random choices again for a repeat node", () => {
            // The first run makes 2 iterations, the second run makes 5.
            const { firstRunLog, secondRunLog } = assertNextRunMatchesOriginal(
                "root { repeat [2, 5] { action [Tick] } }",
                [0, 0.99]
            );

            assert.strictEqual(firstRunLog.length, 4);
            assert.strictEqual(secondRunLog.length, 10);
        });

        it("will start a new run on the next step that makes random choices again for a retry node", () => {
            // The first run makes 2 attempts, the second run makes 5.
            const { firstRunLog, secondRunLog } = assertNextRunMatchesOriginal(
                "root { retry [2, 5] { action [AlwaysFail] } }",
                [0, 0.99]
            );

            assert.strictEqual(firstRunLog.length, 2);
            assert.strictEqual(secondRunLog.length, 5);
        });

        it("will start a new run on the next step that makes random choices again for a lotto node", () => {
            const { firstRunLog, secondRunLog } = assertNextRunMatchesOriginal(
                "root { lotto { action [Tick] action [AlwaysFail] } }",
                [0, 0.99]
            );

            // Each run picks a different child.
            assert.notDeepEqual(firstRunLog.slice(0, 1), secondRunLog.slice(0, 1));
        });
    });

    describe("will behave exactly as the tree the snapshot was taken from after restoring it for", () => {
        const scenarios: { [description: string]: Scenario } = {
            "a sequence": {
                definition: "root { sequence { action [Work] action [Approval] action [Flaky] action [Tick] } }",
                steps: 14,
                beforeStep: approveAtStep(6)
            },
            "a selector": {
                definition:
                    "root { selector { action [AlwaysFail] sequence { action [Work] action [AlwaysFail] } action [Approval] } }",
                steps: 14,
                beforeStep: approveAtStep(8)
            },
            "a parallel": {
                definition:
                    "root { parallel { action [Work] action [Approval] sequence { action [Tick] action [Tick] } } }",
                steps: 14,
                beforeStep: approveAtStep(7)
            },
            "a parallel with a failing child that aborts the others": {
                definition: "root { parallel { action [Approval] sequence { action [Tick] action [AlwaysFail] } } }",
                steps: 8
            },
            "a race": {
                definition: "root { race { action [Approval] exit(OnExit) sequence { action [Tick] action [Work] } } }",
                steps: 10
            },
            "an all": {
                definition:
                    "root { all { action [Approval] sequence { action [Work] action [AlwaysFail] } action [Tick] } }",
                steps: 12,
                beforeStep: approveAtStep(9)
            },
            "flip, succeed and fail decorators": {
                definition:
                    "root { sequence { flip { action [Work] } succeed { sequence { action [Tick] action [AlwaysFail] } } fail { action [Work] } } }",
                steps: 10
            },
            "a branch": {
                definition: "root { sequence { branch [Part] action [Tick] } } root [Part] { action [Work] }",
                steps: 8
            },
            "a repeat with an explicit number of iterations": {
                definition: "root { repeat [3] { action [Tick] } }",
                steps: 14
            },
            "a repeat with random iterations picked using the 'random' option": {
                definition: "root { repeat [2, 5] { sequence { action [Tick] action [Work] } } }",
                steps: 40
            },
            "a repeat with no limit on iterations": {
                definition: "root { repeat { sequence { action [Tick] action [Approval] } } }",
                steps: 12,
                beforeStep: (world, stepIndex) => {
                    world.approved = stepIndex % 3 === 0;
                }
            },
            "a retry with an explicit number of attempts": {
                definition: "root { retry [2] { action [Flaky] } }",
                steps: 12
            },
            "a retry with random attempts picked using the 'random' option": {
                definition: "root { retry [1, 5] { sequence { action [Tick] action [Flaky] } } }",
                steps: 40
            },
            "a retry with no limit on attempts": {
                definition: "root { retry { sequence { action [Tick] action [Approval] } } }",
                steps: 12,
                beforeStep: approveAtStep(8)
            },
            "nested repeat and retry nodes": {
                definition: "root { repeat [2, 3] { retry [2, 4] { sequence { action [Flaky] action [Tick] } } } }",
                steps: 40
            },
            "a lotto": {
                definition:
                    "root { lotto [1, 2, 3] { action [Work] sequence { action [Tick] action [Flaky] } action [Approval] } }",
                steps: 30,
                beforeStep: (world, stepIndex) => {
                    world.approved = stepIndex % 4 === 0;
                }
            },
            "a wait using the clock": {
                definition: "root { sequence { action [Tick] wait [3500] action [Work] } }",
                steps: 16
            },
            "a wait using the 'getDeltaTime' option": {
                definition: "root { sequence { action [Tick] wait [3500] action [Work] } }",
                steps: 16,
                useDeltaTime: true
            },
            "waits with random durations picked using the 'random' option": {
                definition: "root { repeat { sequence { wait [1000, 6000] action [Tick] } } }",
                steps: 40
            },
            "waits with random durations picked using the 'random' option and 'getDeltaTime' option": {
                definition: "root { repeat { sequence { wait [1000, 6000] action [Tick] } } }",
                steps: 40,
                useDeltaTime: true
            },
            "waits running at the same time": {
                definition: "root { parallel { wait [2500] exit(OnExit) wait [4500] exit(OnExit) } }",
                steps: 10
            },
            "a wait with no duration that is aborted": {
                definition: "root { race { wait exit(OnExit) sequence { action [Tick] action [Approval] } } }",
                steps: 12,
                beforeStep: approveAtStep(7)
            },
            "a wait that is aborted by a guard": {
                definition: "root { sequence { wait [5000] while(IsActive) exit(OnExit) action [Tick] } }",
                steps: 12,
                beforeStep: (world, stepIndex) => {
                    world.active = stepIndex < 4;
                }
            },
            "nodes with entry, step and exit callbacks": {
                definition:
                    "root { sequence entry(OnEntry) step(OnStep) exit(OnExit) { action [Work] entry(OnEntry) step(OnStep) exit(OnExit) action [Tick] exit(OnExit) } }",
                steps: 8
            },
            "nodes with while guards that are satisfied then not": {
                definition:
                    "root { sequence while(IsActive) { action [Work] while(IsActive) action [Approval] exit(OnExit) } }",
                steps: 12,
                beforeStep: (world, stepIndex) => {
                    world.active = stepIndex < 7;
                }
            },
            "nodes with until guards that are satisfied then not": {
                definition: "root { sequence until(IsDone) { action [Work] action [Approval] exit(OnExit) } }",
                steps: 12,
                beforeStep: (world, stepIndex) => {
                    world.done = stepIndex >= 6;
                }
            }
        };

        for (const [description, scenario] of Object.entries(scenarios)) {
            it(description, () => {
                const results = assertRestoredTreesBehaveIdentically(scenario, getClock());

                // Make sure that the scenario did something worth checking.
                assert.isAbove(new Set(results.map((result) => JSON.stringify(result))).size, 2);
            });
        }
    });

    describe("a snapshot is independent of the tree", () => {
        const definitions: { [description: string]: string } = {
            "with repeat and wait nodes":
                "root { sequence { action [Work] wait [1000, 5000] repeat [2, 4] { action [Tick] } } }",
            "with a retry node and a wait node": "root { retry [2, 4] { sequence { action [Flaky] wait [3000] } } }",
            "with a lotto node": "root { lotto [1, 2] { action [Work] sequence { action [Tick] action [Work] } } }",
            "with a parallel node and an indefinite wait": "root { parallel { action [Work] wait action [Tick] } }",
            "with actions that return promises": "root { sequence { action [Fetch] action [Work] action [Slow] } }"
        };

        // Gives any promise handlers a chance to be called.
        const flushPromises = async () => {
            for (let tick = 0; tick < 5; tick++) {
                await Promise.resolve();
            }
        };

        for (const useDeltaTime of [false, true]) {
            for (const [description, definition] of Object.entries(definitions)) {
                it(`${description}, ${useDeltaTime ? "using" : "not using"} the 'getDeltaTime' option`, async () => {
                    const createTree = () =>
                        new BehaviourTree(
                            definition,
                            {
                                ...createScenarioAgent({}, []),
                                Fetch: () => Promise.resolve(State.SUCCEEDED),
                                Slow: () => new Promise<State>(() => {})
                            },
                            {
                                random: () => 0.5,
                                ...(useDeltaTime ? { getDeltaTime: () => 1 } : {})
                            }
                        );

                    const tree = createTree();

                    for (let step = 0; step < 10; step++) {
                        tree.step();
                        await flushPromises();
                        getClock().tick(1000);

                        const snapshot = tree.snapshot();
                        const expected = JSON.parse(JSON.stringify(snapshot));

                        // Stepping the tree that the snapshot was taken from should not change the snapshot.
                        tree.step();
                        assert.deepStrictEqual(
                            snapshot,
                            expected,
                            `stepping the tree changed the snapshot of step ${step}`
                        );

                        // Restoring should put the tree in the state of the snapshot, so a snapshot taken straight after is the same.
                        const restored = createTree();
                        restored.restore(snapshot);
                        assert.deepStrictEqual(
                            JSON.parse(JSON.stringify(restored.snapshot())),
                            expected,
                            `the snapshot of the restored tree differs from the snapshot of step ${step}`
                        );

                        // Stepping the restored tree should not change the snapshot that it was restored from.
                        restored.step();
                        await flushPromises();
                        restored.step();
                        assert.deepStrictEqual(
                            snapshot,
                            expected,
                            `stepping a restored tree changed the snapshot of step ${step}`
                        );
                    }
                });
            }
        }
    });
});
