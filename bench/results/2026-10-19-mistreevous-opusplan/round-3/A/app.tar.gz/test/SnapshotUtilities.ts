import { assert } from "chai";
import sinon, { SinonFakeTimers } from "sinon";

import { BehaviourTree, State } from "../src/index";
import type { BehaviourTreeOptions, NodeDetails } from "../src/index";
import { Agent } from "../src/Agent";

/**
 * The state of the 'world' that a scenario agent operates in. It is plain data so that it can be cloned at the point a snapshot is taken.
 */
export type World = { [key: string]: any };

/**
 * A scenario that is used to check that a restored tree behaves exactly like the tree that the snapshot was taken from.
 */
export type Scenario = {
    /**
     * The MDSL tree definition.
     */
    definition: string;
    /**
     * The number of times that the tree is stepped.
     */
    steps: number;
    /**
     * Any initial world properties.
     */
    world?: World;
    /**
     * Whether the tree should use a 'getDeltaTime' option instead of the clock to work out how long wait nodes have waited.
     */
    useDeltaTime?: boolean;
    /**
     * Called before every tree step to allow the world to change, e.g. an external event happening.
     */
    beforeStep?: (world: World, stepIndex: number) => void;
};

/**
 * The time in milliseconds between each step of a scenario tree.
 */
export const STEP_MS = 1000;

/**
 * The time in milliseconds between a snapshot being taken and being restored.
 */
export const RESTORE_DELAY_MS = 10 * 60 * 60 * 1000;

const START_TIME = 1_000_000;

/**
 * The sequence of 'random' values that scenario trees pick from, which is walked by an index held in the world.
 */
const RANDOM_VALUES = [0.1, 0.9, 0.5, 0.3, 0.7, 0.2, 0.8, 0.4, 0.6, 0.0, 0.95];

/**
 * Creates the agent for a scenario. Every agent function adds its name to the log when it is called.
 */
export const createScenarioAgent = (world: World, log: string[]): Agent => {
    const next = (key: string) => (world[key] = (world[key] ?? 0) + 1);

    return {
        // Running for two calls, succeeding on the third and every third call after.
        Work: () => {
            log.push("Work");
            return next("work") % 3 === 0 ? State.SUCCEEDED : State.RUNNING;
        },
        // Running for one call and succeeding on the second and every second call after.
        Tick: () => {
            log.push("Tick");
            return next("tick") % 2 === 0 ? State.SUCCEEDED : undefined;
        },
        // Failing twice and succeeding on the third and every third call after.
        Flaky: () => {
            log.push("Flaky");
            return next("flaky") % 3 === 0 ? State.SUCCEEDED : State.FAILED;
        },
        AlwaysFail: () => {
            log.push("AlwaysFail");
            return State.FAILED;
        },
        // Running until the world has been approved.
        Approval: () => {
            log.push("Approval");
            return world.approved ? State.SUCCEEDED : State.RUNNING;
        },
        IsActive: () => {
            log.push("IsActive");
            return world.active !== false;
        },
        IsDone: () => {
            log.push("IsDone");
            return !!world.done;
        },
        OnEntry: () => log.push("OnEntry"),
        OnStep: () => log.push("OnStep"),
        OnExit: (result: { succeeded: boolean; aborted: boolean }) =>
            log.push(`OnExit succeeded=${result.succeeded} aborted=${result.aborted}`)
    };
};

/**
 * Gets the details of every node in a tree without their ids, which differ between tree instances.
 */
export const getDetailsWithoutIds = (tree: BehaviourTree): any => {
    const strip = ({ id, children, ...details }: NodeDetails): any => ({
        ...details,
        ...(children ? { children: children.map(strip) } : {})
    });

    return strip(tree.getTreeNodeDetails());
};

type Run = { tree: BehaviourTree; world: World; log: string[] };

type StepResult = { log: string[]; state: State; details: any };

/**
 * Checks that restoring a snapshot, taken after any number of steps, into a new tree behaves exactly as the original tree does from that point.
 * The new tree is restored a long time after the snapshot was taken, which must not count towards any wait.
 * @param scenario The scenario.
 * @returns The result of every step of the reference run.
 */
export const assertRestoredTreesBehaveIdentically = (scenario: Scenario, clock: SinonFakeTimers): StepResult[] => {
    const createRun = (world: World): Run => {
        const log: string[] = [];
        const options: BehaviourTreeOptions = {
            random: () => RANDOM_VALUES[world.randomIndex++ % RANDOM_VALUES.length]
        };

        if (scenario.useDeltaTime) {
            options.getDeltaTime = () => STEP_MS / 1000;
        }

        return { tree: new BehaviourTree(scenario.definition, createScenarioAgent(world, log), options), world, log };
    };

    const stepRun = (run: Run, stepIndex: number): StepResult => {
        scenario.beforeStep?.(run.world, stepIndex);

        const logLength = run.log.length;
        run.tree.step();

        return { log: run.log.slice(logLength), state: run.tree.getState(), details: getDetailsWithoutIds(run.tree) };
    };

    const timeOfStep = (stepIndex: number) => START_TIME + stepIndex * STEP_MS;

    // A snapshot is taken part way between steps so that time between steps is covered.
    const timeOfSnapshot = (stepIndex: number) => timeOfStep(stepIndex) + STEP_MS / 4;

    const reference = createRun({ randomIndex: 0, ...structuredClone(scenario.world ?? {}) });
    const referenceResults: StepResult[] = [];
    const checkpoints: { snapshot: any; world: World; details: any; state: State }[] = [];

    const takeCheckpoint = (stepIndex: number) => {
        clock.setSystemTime(timeOfSnapshot(stepIndex));

        const snapshot = reference.tree.snapshot();
        const parsed = JSON.parse(JSON.stringify(snapshot));

        // The snapshot must be unchanged by a trip through JSON, i.e. no undefined, functions or class instances.
        assert.deepStrictEqual(parsed, snapshot, `snapshot after ${stepIndex} steps is not plain JSON`);

        checkpoints.push({
            snapshot: parsed,
            world: structuredClone(reference.world),
            details: getDetailsWithoutIds(reference.tree),
            state: reference.tree.getState()
        });
    };

    clock.setSystemTime(timeOfStep(0));
    takeCheckpoint(0);

    for (let stepIndex = 1; stepIndex <= scenario.steps; stepIndex++) {
        clock.setSystemTime(timeOfStep(stepIndex));
        referenceResults[stepIndex] = stepRun(reference, stepIndex);
        takeCheckpoint(stepIndex);
    }

    checkpoints.forEach((checkpoint, restoredAtStep) => {
        const restored = createRun(structuredClone(checkpoint.world));

        // Any time that passes between taking a snapshot and restoring it should not count.
        clock.setSystemTime(timeOfSnapshot(restoredAtStep) + RESTORE_DELAY_MS);
        restored.tree.restore(checkpoint.snapshot);

        assert.deepStrictEqual(
            getDetailsWithoutIds(restored.tree),
            checkpoint.details,
            `node details differ after restoring snapshot of step ${restoredAtStep}`
        );
        assert.strictEqual(restored.tree.getState(), checkpoint.state);
        assert.isEmpty(restored.log, "restoring should not call any agent functions");

        // Taking a snapshot of a restored tree should give us what we restored.
        assert.deepStrictEqual(restored.tree.snapshot(), checkpoint.snapshot);

        for (let stepIndex = restoredAtStep + 1; stepIndex <= scenario.steps; stepIndex++) {
            clock.setSystemTime(timeOfStep(stepIndex) + RESTORE_DELAY_MS);

            assert.deepStrictEqual(
                stepRun(restored, stepIndex),
                referenceResults[stepIndex],
                `step ${stepIndex} differs after restoring snapshot of step ${restoredAtStep}`
            );
        }
    });

    return referenceResults;
};

/**
 * Installs a fake clock for the duration of each test in the current suite and returns a function to get it.
 */
export const useFakeClock = (): (() => SinonFakeTimers) => {
    let clock: SinonFakeTimers;

    beforeEach(() => {
        clock = sinon.useFakeTimers(START_TIME);
    });

    afterEach(() => {
        clock.restore();
    });

    return () => clock;
};
