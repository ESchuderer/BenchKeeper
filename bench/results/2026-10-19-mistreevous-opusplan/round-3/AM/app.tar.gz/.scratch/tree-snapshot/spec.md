# Tree snapshot and restore

Request: serialise a tree's execution state and restore it in a tree built from the same definition (long-running workflows, process restarts).

## Interface

- `BehaviourTree.snapshot(): BehaviourTreeSnapshot`
- `BehaviourTree.restore(snapshot: BehaviourTreeSnapshot): void`
- `BehaviourTreeSnapshot` and `NodeSnapshot` are exported types from the package.

## Format

```
BehaviourTreeSnapshot = { version: 1, definition: string, root: NodeSnapshot }
NodeSnapshot = { id, type, state, children?, ...node specific fields }
```

- `definition` is a hash of the normalised JSON definition (keys sorted, empty `args` and `succeedOnAbort: false` dropped, roots ordered by id), so an MDSL definition and its equivalent JSON definition give the same value. Registered subtrees are not included.
- Nested, mirrors the tree. `children` is present on composite and decorator nodes.
- JSON-safe: no `undefined` values (keys are omitted), `null` means "infinite" or "no choice made", numbers are finite.
- `id` is the node uid. It is restored so `getTreeNodeDetails()` of the restored tree equals the original's, and `onNodeStateChange` ids stay stable.

## State kept per node type

| Node | Fields besides `id`, `type`, `state` |
|---|---|
| root, sequence, selector, parallel, race, all, flip, succeed, fail, condition | none (children's states are the progress) |
| lotto | `selectedChild`: index or `null` |
| repeat | `targetIterationCount` (number or `null`), `currentIterationCount` |
| retry | `targetAttemptCount` (number or `null`), `currentAttemptCount` |
| wait | `totalDuration` (number or `null`), `waitedDuration` |
| action | `updatePromiseResult`: `null` or `{ isResolved, value }` (a settled promise not yet consumed by a step) |

## Behaviour

- Wait: `waitedDuration` for a running wait with no `getDeltaTime` option is `now - initialUpdateTime` at snapshot time. Restore sets `initialUpdateTime = now - waitedDuration`. Time between snapshot and restore does not count. With `getDeltaTime` the stored accumulated value is used.
- Finished tree: no special case. `step()` resets a finished root and the READY branches draw random values again.
- Action waiting on a pending promise: promises cannot be serialised. It is saved as READY (not yet started), so the next step after a restore calls the action function and its entry callback again. A settled but unconsumed result is kept. A promise from before the restore is ignored when it settles.
- Wait: the stored waited duration is capped at the total duration, so an infinite `getDeltaTime` value cannot enter the snapshot.
- Restore writes node state directly: no `onNodeStateChange`, no entry/exit callbacks.
- Restore overwrites the full execution state of the tree it is called on.
- Validation: the input is a snapshot (object with `version` 1, string `definition`, `root`), `definition` equals the tree's, node `type`, child count, `state` values, field types, a running lotto node has a selected child, an action in the READY state has no promise result. The whole snapshot is validated before any node is changed, so an invalid snapshot throws and leaves the tree untouched.

## Acceptance criteria

1. Snapshot survives `JSON.parse(JSON.stringify())` unchanged.
2. Differential: a tree restored from a snapshot of tree A, stepped in lockstep with A, gives the same agent call log, same `getTreeNodeDetails()` and same state after every step (sequence, selector, parallel, race, all, lotto, repeat, retry with ranges, wait in both clock modes, guards).
3. Wait counts only the remaining time (Date and `getDeltaTime`).
4. Finished tree restores as finished; the next step draws new random values.
5. Invalid snapshots throw and leave the tree unchanged.
6. README documents both methods with an example; Version History row and package version updated (4.4.0).
7. A snapshot records its definition. `restore()` throws an Error saying the snapshot does not match the tree's definition when it was taken from another definition, and the tree is unchanged.
8. An MDSL definition and its equivalent JSON definition (written by hand, with other key order and without default `args` and `succeedOnAbort`) are the same definition.
9. Input that is not a snapshot (`null`, a string, a number, an array, an object without the snapshot's fields) throws an Error and leaves the tree unchanged.
10. An action waiting on a pending promise is saved as READY, the restored tree calls its action function again on its next step, and the README documents this limitation next to the snapshot API.

## Not included

- Storing, scheduling, event handling (application side).
- Restoring in-flight action promises.
- Checking a snapshot against node parameters of registered subtrees. Only their tree shape is checked.
