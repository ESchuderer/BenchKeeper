import Node, { NodeDetails, NodeSnapshot } from "../Node";
import State from "../../State";
import { Agent } from "../../Agent";
import Attribute from "../../attributes/Attribute";
import { BehaviourTreeOptions } from "../../BehaviourTreeOptions";

/**
 * A composite node that wraps child nodes.
 */
export default abstract class Composite extends Node {
    /**
     * @param type The node type.
     * @param attributes The node attributes.
     * @param options The behaviour tree options.
     * @param children The child nodes.
     */
    constructor(type: string, attributes: Attribute[], options: BehaviourTreeOptions, protected children: Node[]) {
        super(type, attributes, options);
    }

    /**
     * Gets the children of this node.
     */
    getChildren = () => this.children;

    /**
     * Reset the state of the node.
     */
    reset = () => {
        // Reset the state of this node.
        this.setState(State.READY);

        // Reset the state of any child nodes.
        this.children.forEach((child) => child.reset());
    };

    /**
     * Abort the running of this node.
     * @param agent The agent.
     */
    abort = (agent: Agent) => {
        // There is nothing to do if this node is not in the running state.
        if (!this.is(State.RUNNING)) {
            return;
        }

        // Abort any child nodes.
        this.children.forEach((child) => child.abort(agent));

        // Reset the state of this node.
        this.reset();

        this.attributes.exit?.callAgentFunction(agent, false, true);
    };

    /**
     * Gets the details of this node instance.
     * @returns The details of this node instance.
     */
    public getDetails(): NodeDetails {
        return {
            ...super.getDetails(),
            children: this.children.map((child) => child.getDetails())
        };
    }

    /**
     * Gets the execution state of this node instance.
     * @returns The execution state of this node instance.
     */
    public getSnapshot(): NodeSnapshot {
        return {
            ...super.getSnapshot(),
            children: this.children.map((child) => child.getSnapshot())
        };
    }

    /**
     * Checks that a snapshot matches this node instance and the nodes beneath it, without changing any of them.
     * @param snapshot The execution state to set.
     * @returns A function that sets the execution state, without calling any callbacks or state change handlers.
     */
    public prepareRestore(snapshot: NodeSnapshot): () => void {
        const restoreNode = super.prepareRestore(snapshot);

        if (!Array.isArray(snapshot.children) || snapshot.children.length !== this.children.length) {
            throw new Error(`expected '${snapshot.type}' node snapshot to have ${this.children.length} children`);
        }

        const restoreChildren = this.children.map((child, index) => child.prepareRestore(snapshot.children![index]));

        return () => {
            restoreNode();
            restoreChildren.forEach((restoreChild) => restoreChild());
        };
    }
}
