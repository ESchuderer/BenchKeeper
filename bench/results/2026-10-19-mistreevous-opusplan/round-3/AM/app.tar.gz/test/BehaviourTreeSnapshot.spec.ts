import { assert } from "chai";
import sinon, { SinonFakeTimers } from "sinon";

import { BehaviourTree, BehaviourTreeOptions, BehaviourTreeSnapshot, State } from "../src/index";
import { RootNodeDefinition } from "../src/BehaviourTreeDefinition";

import { findNode } from "./TestUtilities";

type Definition = string | RootNodeDefinition | RootNodeDefinition[];

/**
 * Creates a pseudo-random function that returns the given values in order, wrapping around at the end.
 * The `used` property is the number of values returned so far.
 */
const createRandom = (values: number[], used = 0) => {
    const random = () => values[random.used++ % values.length];
    random.used = used;
    return random;
};

/**
 * A tree with an agent that records every function call and takes its results from the shared `results` object,
 * which stands in for the application's external events. Functions with no result set keep running.
 */
const createRig = (
    definition: Definition,
    results: Record<string, State | undefined>,
    options?: BehaviourTreeOptions
) => {
    const calls: string[] = [];

    const agent: Record<string, () => State | boolean | undefined> = {};

    for (const name of ["A", "B", "C", "D", "E"]) {
        agent[name] = () => {
            calls.push(name);
            return results[name];
        };
    }

    // Conditions, guards and callbacks all return a boolean.
    for (const name of ["Yes", "No", "Entry", "Step", "Exit"]) {
        agent[name] = () => {
            calls.push(name);
            return name !== "No";
        };
    }

    return { tree: new BehaviourTree(definition, agent, options), calls };
};

type Rig = ReturnType<typeof createRig>;

/**
 * Steps the original and the restored tree in lockstep, asserting after each step that they made the same
 * agent function calls and have the same node details.
 */
const stepInLockstep = (original: Rig, restored: Rig, steps: number, beforeStep?: (step: number) => void) => {
    const originalCallsFrom = original.calls.length;
    const restoredCallsFrom = restored.calls.length;

    for (let step = 0; step < steps; step++) {
        beforeStep?.(step);

        original.tree.step();
        restored.tree.step();

        assert.deepEqual(
            restored.calls.slice(restoredCallsFrom),
            original.calls.slice(originalCallsFrom),
            `agent calls differ on step ${step}`
        );
        assert.deepEqual(
            restored.tree.getTreeNodeDetails(),
            original.tree.getTreeNodeDetails(),
            `node details differ on step ${step}`
        );
    }
};

/**
 * Steps the original and the restored tree in lockstep until the restored tree has succeeded.
 */
const stepUntilSucceeded = (original: Rig, restored: Rig, beforeStep?: () => void) => {
    for (let step = 0; step < 12 && restored.tree.getState() !== State.SUCCEEDED; step++) {
        stepInLockstep(original, restored, 1, beforeStep);
    }

    assert.strictEqual(restored.tree.getState(), State.SUCCEEDED);
};

/**
 * Steps a tree the given number of times, takes a snapshot, passes it through JSON and restores it into a second tree.
 */
const snapshotAndRestore = (
    definition: Definition,
    results: Record<string, State | undefined>,
    stepsBeforeSnapshot: number,
    options: (random?: () => number) => BehaviourTreeOptions = () => ({})
) => {
    const originalRandom = createRandom([0.1, 0.9, 0.5, 0.3, 0.7, 0.2]);
    const original = createRig(definition, results, options(originalRandom));

    for (let step = 0; step < stepsBeforeSnapshot; step++) {
        original.tree.step();
    }

    const snapshot: BehaviourTreeSnapshot = JSON.parse(JSON.stringify(original.tree.snapshot()));

    // The restored tree draws the random values that the original draws next.
    const restored = createRig(
        definition,
        results,
        options(createRandom([0.1, 0.9, 0.5, 0.3, 0.7, 0.2], originalRandom.used))
    );

    restored.tree.restore(snapshot);

    // The original's calls up to the snapshot are not repeated by the restored tree.
    return { original, restored, snapshot };
};

describe("A behaviour tree snapshot", () => {
    let clock: SinonFakeTimers;

    beforeEach(() => {
        clock = sinon.useFakeTimers();
    });

    afterEach(() => {
        clock.restore();
    });

    it("is unchanged by a JSON round trip", () => {
        const results = { A: State.SUCCEEDED, B: State.SUCCEEDED, C: State.SUCCEEDED };
        const { original } = snapshotAndRestore(
            "root { sequence { repeat [1,3] { action [A] } lotto { action [B] action [C] } wait [100,200] } }",
            results,
            4,
            (random) => ({ random })
        );

        const snapshot = original.tree.snapshot();

        assert.strictEqual(findNode(original.tree, "wait").state, State.RUNNING);

        assert.deepEqual(JSON.parse(JSON.stringify(snapshot)), snapshot);
    });

    describe("restores a random choice so that", () => {
        it("a lotto node keeps its selected child", () => {
            // Each of the two lotto draws picks a different child for these random values.
            const results: Record<string, State | undefined> = {};
            const { original, restored } = snapshotAndRestore(
                "root { lotto { action [A] action [B] action [C] } }",
                results,
                1,
                (random) => ({ random })
            );

            const selected = ["A", "B", "C"].find(
                (name) => findNode(original.tree, "action", name).state === State.RUNNING
            );
            assert.isDefined(selected);
            assert.strictEqual(findNode(restored.tree, "action", selected).state, State.RUNNING);

            stepInLockstep(original, restored, 2, (step) => {
                if (step === 1) {
                    results[selected!] = State.SUCCEEDED;
                }
            });

            assert.deepEqual(restored.calls, [selected, selected]);
        });

        it("a repeat node keeps its random iteration count and progress", () => {
            const results: Record<string, State | undefined> = { A: State.SUCCEEDED };
            const { original, restored } = snapshotAndRestore(
                "root { repeat [2,5] { action [A] } }",
                results,
                2,
                (random) => ({ random })
            );

            stepInLockstep(original, restored, 1);
            assert.strictEqual(restored.tree.getState(), State.SUCCEEDED);

            // The next run draws a new random count, which is the same one the original draws.
            stepInLockstep(original, restored, 8);
        });

        it("a retry node keeps its random attempt count and progress", () => {
            const results: Record<string, State | undefined> = { A: State.FAILED };
            const { original, restored } = snapshotAndRestore(
                "root { retry [2,5] { action [A] } }",
                results,
                2,
                (random) => ({ random })
            );

            stepInLockstep(original, restored, 1);
            assert.strictEqual(restored.tree.getState(), State.FAILED);

            stepInLockstep(original, restored, 8);
        });

        it("a repeat node keeps an infinite iteration count", () => {
            const results: Record<string, State | undefined> = { A: State.SUCCEEDED };
            const { original, restored } = snapshotAndRestore("root { repeat { action [A] } }", results, 3);

            stepInLockstep(original, restored, 5);
            assert.isTrue(restored.tree.isRunning());
        });
    });

    describe("restores a wait node so that it", () => {
        const restoreInto = (definition: string, snapshot: BehaviourTreeSnapshot, options?: BehaviourTreeOptions) => {
            const { tree } = createRig(definition, {}, options);
            tree.restore(JSON.parse(JSON.stringify(snapshot)));
            return tree;
        };

        it("waits only for the remaining time, ignoring the time before the restore (Date)", () => {
            const original = createRig("root { wait [1000] }", {}).tree;

            original.step();
            clock.tick(600);

            // Time since the last step counts as time waited.
            const snapshot = original.snapshot();

            clock.tick(10000);

            const restored = restoreInto("root { wait [1000] }", snapshot);

            clock.tick(399);
            restored.step();
            assert.strictEqual(findNode(restored, "wait").state, State.RUNNING);

            clock.tick(1);
            restored.step();
            assert.strictEqual(findNode(restored, "wait").state, State.SUCCEEDED);
        });

        it("waits only for the remaining time, ignoring the time before the restore (getDeltaTime)", () => {
            let deltaTime = 0.5;
            const options = { getDeltaTime: () => deltaTime };

            const original = createRig("root { wait [1000] }", {}, options).tree;

            original.step();
            const snapshot = original.snapshot();

            clock.tick(10000);

            const restored = restoreInto("root { wait [1000] }", snapshot, options);

            deltaTime = 0.4;
            restored.step();
            assert.strictEqual(findNode(restored, "wait").state, State.RUNNING);

            deltaTime = 0.1;
            restored.step();
            assert.strictEqual(findNode(restored, "wait").state, State.SUCCEEDED);
        });

        it("keeps its random duration", () => {
            const options = (used = 0) => ({ random: createRandom([0, 1], used) });

            const original = createRig("root { wait [100,5000] }", {}, options()).tree;

            // A random value of 0 gives the minimum duration of 100ms.
            original.step();
            const snapshot = original.snapshot();

            // The restored tree would pick the maximum duration of 5000ms if it drew a new one.
            const restored = restoreInto("root { wait [100,5000] }", snapshot, options(1));

            clock.tick(100);
            restored.step();
            assert.strictEqual(findNode(restored, "wait").state, State.SUCCEEDED);
        });

        it("has a snapshot that survives JSON when the delta time is infinite", () => {
            const options = { getDeltaTime: () => Infinity };
            const original = createRig("root { wait [1000] }", {}, options).tree;

            original.step();
            assert.strictEqual(findNode(original, "wait").state, State.SUCCEEDED);

            const snapshot = original.snapshot();
            assert.deepEqual(JSON.parse(JSON.stringify(snapshot)), snapshot);

            const restored = restoreInto("root { wait [1000] }", snapshot, options);
            assert.strictEqual(findNode(restored, "wait").state, State.SUCCEEDED);
        });

        it("has a waited duration of 0 when it has no duration, in the snapshot", () => {
            const original = createRig("root { wait }", {}).tree;

            original.step();
            clock.tick(5000);

            assert.strictEqual((original.snapshot().root.children![0] as any).waitedDuration, 0);
        });

        it("keeps waiting indefinitely when it has no duration", () => {
            const original = createRig("root { wait }", {}).tree;

            original.step();

            const restored = restoreInto("root { wait }", original.snapshot());

            clock.tick(100000);
            restored.step();
            assert.strictEqual(findNode(restored, "wait").state, State.RUNNING);
        });
    });

    describe("restores a finished tree so that it", () => {
        it("is finished and starts a new run with new random choices on the next step", () => {
            const results: Record<string, State | undefined> = { A: State.SUCCEEDED };
            const { original, restored } = snapshotAndRestore(
                "root { repeat [1,3] { action [A] } }",
                results,
                2,
                (random) => ({ random })
            );

            // The first run drew 1 iteration, which is the minimum.
            assert.strictEqual(restored.tree.getState(), State.SUCCEEDED);
            assert.deepEqual(original.calls, ["A"]);

            stepInLockstep(original, restored, 4);

            // The second run drew 3 iterations, which is the maximum.
            assert.deepEqual(restored.calls, ["A", "A", "A"]);
        });
    });

    describe("restores an action node so that it", () => {
        const createPromiseRig = () => {
            const calls: string[] = [];
            let resolve: (state: State) => void = () => {};
            let reject: (reason: Error) => void = () => {};

            const agent = {
                A: () => {
                    calls.push("A");
                    return new Promise<State>((resolvePromise, rejectPromise) => {
                        resolve = resolvePromise;
                        reject = rejectPromise;
                    });
                }
            };

            return {
                tree: new BehaviourTree("root { action [A] }", agent),
                calls,
                resolve: (state: State) => resolve(state),
                reject: (reason: Error) => reject(reason)
            };
        };

        it("calls the action function again if it was waiting on a promise", () => {
            const original = createPromiseRig();
            original.tree.step();

            const restored = createPromiseRig();
            restored.tree.restore(JSON.parse(JSON.stringify(original.tree.snapshot())));

            assert.strictEqual(findNode(restored.tree, "action").state, State.READY);

            restored.tree.step();
            assert.deepEqual(restored.calls, ["A"]);
            assert.strictEqual(findNode(restored.tree, "action").state, State.RUNNING);
        });

        it("is saved as not yet started if it was waiting on a promise, leaving the original tree as it was", () => {
            const original = createPromiseRig();
            original.tree.step();

            const snapshot = original.tree.snapshot();

            assert.strictEqual(snapshot.root.children![0].state, State.READY);
            assert.strictEqual(findNode(original.tree, "action").state, State.RUNNING);
        });

        it("starts again, calling its entry callback, when it was waiting on a promise inside a running sequence", () => {
            const definition = "root { sequence { action [Before] action [A] entry(Entry) action [After] } }";
            const createWorkflow = () => {
                const calls: string[] = [];
                const agent = {
                    Before: () => State.SUCCEEDED,
                    A: () => {
                        calls.push("A");
                        return new Promise<State>(() => {});
                    },
                    Entry: () => calls.push("Entry"),
                    After: () => State.SUCCEEDED
                };
                return { tree: new BehaviourTree(definition, agent), calls };
            };

            const original = createWorkflow();
            original.tree.step();
            assert.deepEqual(original.calls, ["Entry", "A"]);

            const restored = createWorkflow();
            restored.tree.restore(JSON.parse(JSON.stringify(original.tree.snapshot())));

            assert.strictEqual(restored.tree.getState(), State.RUNNING);
            assert.strictEqual(findNode(restored.tree, "action", "A").state, State.READY);

            restored.tree.step();
            assert.deepEqual(restored.calls, ["Entry", "A"]);
            assert.strictEqual(findNode(restored.tree, "action", "A").state, State.RUNNING);
        });

        it("keeps the result of a promise that settled but was not yet handled by a step", async () => {
            const original = createPromiseRig();
            original.tree.step();
            original.resolve(State.FAILED);
            await Promise.resolve();

            const restored = createPromiseRig();
            restored.tree.restore(JSON.parse(JSON.stringify(original.tree.snapshot())));

            restored.tree.step();
            assert.deepEqual(restored.calls, []);
            assert.strictEqual(findNode(restored.tree, "action").state, State.FAILED);
        });

        it("ignores a promise from before the restore when it settles", async () => {
            const original = createPromiseRig();
            original.tree.step();
            original.resolve(State.FAILED);
            await Promise.resolve();
            const snapshot = JSON.parse(JSON.stringify(original.tree.snapshot()));

            const target = createPromiseRig();
            target.tree.step();
            target.tree.restore(snapshot);

            // The promise the target tree was waiting on settles after the restore.
            target.resolve(State.SUCCEEDED);
            await Promise.resolve();

            target.tree.step();
            assert.strictEqual(findNode(target.tree, "action").state, State.FAILED);
        });

        it("keeps waiting on its promise when a restore is rejected", async () => {
            const target = createPromiseRig();
            target.tree.step();

            const snapshot: any = JSON.parse(JSON.stringify(target.tree.snapshot()));
            snapshot.root.type = "sequence";
            assert.throws(() => target.tree.restore(snapshot), Error, "expected snapshot of 'root' node");

            target.resolve(State.SUCCEEDED);
            await Promise.resolve();

            target.tree.step();
            assert.deepEqual(target.calls, ["A"]);
            assert.strictEqual(findNode(target.tree, "action").state, State.SUCCEEDED);
        });

        it("keeps the reason a promise was rejected", async () => {
            const original = createPromiseRig();
            original.tree.step();
            original.reject(new Error("approval timed out"));
            await Promise.resolve();

            const restored = createPromiseRig();
            restored.tree.restore(JSON.parse(JSON.stringify(original.tree.snapshot())));

            assert.throws(
                () => restored.tree.step(),
                Error,
                "action function 'A' promise rejected with 'Error: approval timed out'"
            );
            assert.deepEqual(restored.calls, []);
        });
    });

    describe("restores a tree with a completed promise action so that it", () => {
        const definition = "root { sequence { action [Implement] action [Review] } }";

        const createWorkflow = () => {
            const calls: string[] = [];
            const agent = {
                Implement: () => {
                    calls.push("Implement");
                    return Promise.resolve(State.SUCCEEDED);
                },
                Review: () => {
                    calls.push("Review");
                    return reviewResult;
                }
            };
            return { tree: new BehaviourTree(definition, agent), calls };
        };

        let reviewResult: State | undefined;

        beforeEach(() => {
            reviewResult = undefined;
        });

        it("carries on from the running action", async () => {
            const original = createWorkflow();
            original.tree.step();
            await Promise.resolve();
            original.tree.step();

            const restored = createWorkflow();
            restored.tree.restore(JSON.parse(JSON.stringify(original.tree.snapshot())));

            reviewResult = State.SUCCEEDED;
            original.tree.step();
            restored.tree.step();

            assert.deepEqual(restored.calls, ["Review"]);
            assert.strictEqual(restored.tree.getState(), State.SUCCEEDED);
            assert.deepEqual(restored.tree.getTreeNodeDetails(), original.tree.getTreeNodeDetails());
        });

        it("is finished when the tree was finished", async () => {
            reviewResult = State.SUCCEEDED;

            const original = createWorkflow();
            original.tree.step();
            await Promise.resolve();
            original.tree.step();
            assert.strictEqual(original.tree.getState(), State.SUCCEEDED);

            const restored = createWorkflow();
            restored.tree.restore(JSON.parse(JSON.stringify(original.tree.snapshot())));

            assert.strictEqual(restored.tree.getState(), State.SUCCEEDED);
            assert.deepEqual(restored.tree.getTreeNodeDetails(), original.tree.getTreeNodeDetails());
        });
    });

    describe("restores a lotto node that was aborted by a guard before it picked a child", () => {
        it("as failed", () => {
            const definition = "root { lotto while(No) { action [A] action [B] } }";
            const original = createRig(definition, {});
            original.tree.step();
            assert.strictEqual(original.tree.getState(), State.FAILED);

            const restored = createRig(definition, {});
            restored.tree.restore(JSON.parse(JSON.stringify(original.tree.snapshot())));

            assert.strictEqual(restored.tree.getState(), State.FAILED);
        });
    });

    describe("restores every state that a tree reaches", () => {
        it("(promise actions, guards on composites, random choices)", async () => {
            const definition = `root {
                repeat [1,2] {
                    sequence {
                        action [A]
                        lotto while(Yes) { action [B] action [C] }
                        lotto while(No) { action [D] action [E] }
                        parallel { action [B] wait [50] }
                    }
                }
            }`;
            const outcomes = [undefined, State.SUCCEEDED, State.FAILED];

            const createTree = (random: () => number) => {
                const promiseResult = (name: string, step: number) =>
                    (step + name.charCodeAt(0)) % 2 ? Promise.resolve(State.SUCCEEDED) : outcomes[(step + 1) % 3];
                let step = 0;
                const agent: any = { Yes: () => true, No: () => step % 3 !== 2 };
                for (const name of ["A", "B", "C", "D", "E"]) {
                    agent[name] = () => promiseResult(name, step);
                }
                return { tree: new BehaviourTree(definition, agent, { random }), nextStep: () => step++ };
            };

            const { tree, nextStep } = createTree(createRandom([0.1, 0.9, 0.5, 0.3, 0.7]));

            for (let step = 0; step < 40; step++) {
                nextStep();
                tree.step();
                await Promise.resolve();

                const snapshot = JSON.parse(JSON.stringify(tree.snapshot()));
                const fresh = createTree(createRandom([0.5])).tree;
                fresh.restore(snapshot);

                assert.deepEqual(fresh.snapshot(), snapshot, `snapshot differs after step ${step}`);
            }
        });
    });

    describe("restores nodes without calling handlers or callbacks", () => {
        it("(onNodeStateChange, entry, step and exit)", () => {
            const results = { A: State.SUCCEEDED };
            const definition = "root { sequence { action [A] entry(Entry) step(Step) exit(Exit) action [B] } }";
            const original = createRig(definition, results);
            original.tree.step();

            const changes: unknown[] = [];
            const restored = createRig(definition, results, { onNodeStateChange: (change) => changes.push(change) });
            restored.tree.restore(original.tree.snapshot());

            assert.deepEqual(changes, []);
            assert.deepEqual(restored.calls, []);
            assert.deepEqual(restored.tree.getTreeNodeDetails(), original.tree.getTreeNodeDetails());
        });
    });

    describe("restores trees of every node type so that they", () => {
        const definitions: Record<string, string> = {
            sequence: "root { sequence { action [A] action [B] action [C] } }",
            selector: "root { selector { action [A] action [B] action [C] } }",
            parallel: "root { parallel { action [A] action [B] action [C] } }",
            race: "root { race { action [A] action [B] action [C] } }",
            all: "root { all { action [A] action [B] action [C] } }",
            decorators:
                "root { sequence { flip { succeed { action [A] } } fail { action [B] } condition [Yes] action [C] } }",
            guards: "root { sequence { action [A] while(Yes) until(No) action [B] while(Yes) } }",
            callbacks:
                "root { sequence { action [A] entry(Entry) step(Step) exit(Exit) action [B] entry(Entry) exit(Exit) } }",
            "nested repeat and retry": "root { repeat [2] { retry [2] { sequence { action [A] action [B] } } } }"
        };

        for (const [name, definition] of Object.entries(definitions)) {
            it(`carry on exactly as the original does (${name})`, () => {
                // Each function succeeds, fails or keeps running depending on the step.
                const outcomes = [undefined, State.SUCCEEDED, State.FAILED];

                for (let stepsBeforeSnapshot = 0; stepsBeforeSnapshot < 5; stepsBeforeSnapshot++) {
                    const results: Record<string, State | undefined> = {};
                    const { original, restored, snapshot } = snapshotAndRestore(
                        definition,
                        results,
                        stepsBeforeSnapshot
                    );

                    assert.deepEqual(restored.tree.snapshot(), snapshot);
                    assert.deepEqual(restored.tree.getTreeNodeDetails(), original.tree.getTreeNodeDetails());

                    stepInLockstep(original, restored, 9, (step) => {
                        for (const [index, key] of ["A", "B", "C"].entries()) {
                            results[key] = outcomes[(step + index + stepsBeforeSnapshot) % outcomes.length];
                        }
                    });
                }
            });
        }

        it("carry on exactly as the original does (wait, using the clock)", () => {
            const results: Record<string, State | undefined> = { A: State.SUCCEEDED };
            const { original, restored } = snapshotAndRestore(
                "root { sequence { wait [100] action [A] wait [100,200] action [A] } }",
                results,
                2,
                (random) => ({ random })
            );

            stepUntilSucceeded(original, restored, () => clock.tick(60));
        });

        it("carry on exactly as the original does (wait, using getDeltaTime)", () => {
            const results: Record<string, State | undefined> = { A: State.SUCCEEDED };
            const { original, restored } = snapshotAndRestore(
                "root { sequence { wait [100] action [A] wait [100,200] action [A] } }",
                results,
                2,
                (random) => ({ random, getDeltaTime: () => 0.06 })
            );

            stepUntilSucceeded(original, restored);
        });

        it("replace the state of a tree that is already running", () => {
            const definition = "root { sequence { lotto { action [A] action [B] } repeat [1,3] { action [C] } } }";
            const fresh = createRig(definition, {}).tree.snapshot();

            const { restored } = snapshotAndRestore(definition, { A: State.SUCCEEDED, B: State.SUCCEEDED }, 2);
            restored.tree.restore(fresh);

            assert.deepEqual(restored.tree.snapshot(), fresh);
            assert.strictEqual(restored.tree.getState(), State.READY);
        });
    });

    describe("is rejected when restoring it would not match the tree, so that", () => {
        const definition = "root { sequence { action [A] action [B] } }";

        const createRunningTree = () => {
            const rig = createRig(definition, { A: State.SUCCEEDED });
            rig.tree.step();
            return rig.tree;
        };

        const assertRejected = (change: (snapshot: any) => void, message: string) => {
            const tree = createRunningTree();
            const before = tree.getTreeNodeDetails();

            const snapshot: any = JSON.parse(JSON.stringify(createRig(definition, {}).tree.snapshot()));
            change(snapshot);

            assert.throws(() => tree.restore(snapshot), Error, message);

            // Nothing was changed, even though the nodes before the invalid one were valid.
            assert.deepEqual(tree.getTreeNodeDetails(), before);
        };

        it("the version is unknown", () => assertRejected((s) => (s.version = 2), "expected a snapshot"));
        it("it is not a snapshot", () => {
            const tree = createRunningTree();
            const before = tree.getTreeNodeDetails();
            const notSnapshots = [null, undefined, "snapshot", 42, true, [], [1, 2], {}, { root: {} }, { version: 1 }];

            for (const notSnapshot of notSnapshots) {
                assert.throws(() => tree.restore(notSnapshot as any), Error, "expected a snapshot");
                assert.deepEqual(tree.getTreeNodeDetails(), before);
            }
        });
        it("the definition is missing", () => assertRejected((s) => delete s.definition, "expected a snapshot"));
        it("the definition is not a string", () => assertRejected((s) => (s.definition = 1), "expected a snapshot"));
        it("the root node is missing", () =>
            assertRejected((s) => delete s.root, "expected node snapshot to be an object"));
        it("a node has a different type", () =>
            assertRejected(
                (s) => (s.root.children[0].children[1].type = "condition"),
                "expected snapshot of 'action' node"
            ));
        it("a node has a different number of children", () =>
            assertRejected((s) => s.root.children[0].children.pop(), "to have 2 children"));
        it("a node has an invalid state", () =>
            assertRejected((s) => (s.root.children[0].children[1].state = "running"), "invalid state 'running'"));
        it("a node has no id", () =>
            assertRejected((s) => delete s.root.children[0].children[1].id, "id to be a string"));
        it("a lotto node is running but has no selected child", () => {
            const tree = new BehaviourTree("root { lotto { action [A] action [B] } }", {});
            const snapshot: any = JSON.parse(JSON.stringify(tree.snapshot()));
            snapshot.root.children[0].state = State.RUNNING;

            assert.throws(() => tree.restore(snapshot), Error, "valid selected child");
        });
        it("an action node that is ready has a promise result", () => {
            const tree = new BehaviourTree("root { action [A] }", {});
            const snapshot: any = JSON.parse(JSON.stringify(tree.snapshot()));
            snapshot.root.children[0].updatePromiseResult = { isResolved: true, value: State.SUCCEEDED };

            assert.throws(() => tree.restore(snapshot), Error, "valid update promise result");
        });
        it("a repeat node has invalid counts", () => {
            const tree = new BehaviourTree("root { repeat [2] { action [A] } }", {});
            const snapshot: any = JSON.parse(JSON.stringify(tree.snapshot()));
            snapshot.root.children[0].currentIterationCount = -1;

            assert.throws(() => tree.restore(snapshot), Error, "valid iteration counts");
        });
        it("a lotto node has an invalid selected child", () => {
            const tree = new BehaviourTree("root { lotto { action [A] action [B] } }", {});
            const snapshot: any = JSON.parse(JSON.stringify(tree.snapshot()));
            snapshot.root.children[0].selectedChild = 2;

            assert.throws(() => tree.restore(snapshot), Error, "valid selected child");
        });
        it("a wait node has invalid durations", () => {
            const tree = new BehaviourTree("root { wait [100] }", {});
            const snapshot: any = JSON.parse(JSON.stringify(tree.snapshot()));
            snapshot.root.children[0].waitedDuration = null;

            assert.throws(() => tree.restore(snapshot), Error, "valid durations");
        });
    });

    describe("is rejected when it was taken from a tree of another definition, so that", () => {
        const assertMismatch = (snapshotDefinition: Definition, treeDefinition: Definition) => {
            const source = createRig(snapshotDefinition, { A: State.SUCCEEDED });
            source.tree.step();
            const snapshot = JSON.parse(JSON.stringify(source.tree.snapshot()));

            const target = createRig(treeDefinition, { A: State.SUCCEEDED });
            target.tree.step();
            const detailsBefore = target.tree.getTreeNodeDetails();
            const snapshotBefore = target.tree.snapshot();

            assert.throws(() => target.tree.restore(snapshot), Error, "snapshot does not match the tree's definition");

            assert.deepEqual(target.tree.getTreeNodeDetails(), detailsBefore);
            assert.deepEqual(target.tree.snapshot(), snapshotBefore);
        };

        it("an action with another name does not restore", () =>
            assertMismatch(
                "root { sequence { action [A] action [B] } }",
                "root { sequence { action [A] action [C] } }"
            ));
        it("an action with other arguments does not restore", () =>
            assertMismatch(
                "root { sequence { action [A, 1] action [B] } }",
                "root { sequence { action [A, 2] action [B] } }"
            ));
        it("a repeat node with another iteration count does not restore", () =>
            assertMismatch("root { repeat [2] { action [A] } }", "root { repeat [3] { action [A] } }"));
        it("a wait node with another duration does not restore", () =>
            assertMismatch("root { sequence { wait [10] action [A] } }", "root { sequence { wait [20] action [A] } }"));
        it("a node with another guard does not restore", () =>
            assertMismatch(
                "root { sequence while(Yes) { action [A] } }",
                "root { sequence while(No) { action [A] } }"
            ));
        it("a node with another callback does not restore", () =>
            assertMismatch(
                "root { sequence { action [A] entry(Entry) } }",
                "root { sequence { action [A] exit(Entry) } }"
            ));
        it("a tree with other children does not restore", () =>
            assertMismatch("root { sequence { action [A] action [B] } }", "root { sequence { action [A] } }"));
        it("a tree with another named root node does not restore", () =>
            assertMismatch(
                "root { branch [Sub] } root [Sub] { action [A] }",
                "root { branch [Sub] } root [Sub] { action [B] }"
            ));
        it("a tree with another order of children does not restore", () =>
            assertMismatch(
                "root { sequence { action [A] action [B] } }",
                "root { sequence { action [B] action [A] } }"
            ));
        it("a guard that succeeds on abort does not restore into a guard that fails on abort", () =>
            assertMismatch(
                { type: "root", child: { type: "action", call: "A", while: { call: "Yes", succeedOnAbort: true } } },
                { type: "root", child: { type: "action", call: "A", while: { call: "Yes" } } }
            ));
        it("a rejected restore does not change the ids of the tree", () => {
            const source = createRig("root { action [A] }", {});
            const target = createRig("root { action [B] }", {});
            const id = target.tree.getTreeNodeDetails().id;

            assert.throws(() => target.tree.restore(source.tree.snapshot()), Error, "does not match");
            assert.strictEqual(target.tree.getTreeNodeDetails().id, id);
        });
    });

    describe("restores into a tree of an equivalent definition, so that", () => {
        const mdsl = `root {
            sequence while(Yes) entry(Entry) {
                action [A, 1, "b"]
                wait [10]
                repeat [2] { condition [Yes] exit(Exit) }
                branch [Sub]
            }
        }
        root [Sub] { action [B] }`;

        // Written as a person would, without the empty argument lists and false abort flags that MDSL conversion adds.
        const json: RootNodeDefinition[] = [
            { id: "Sub", type: "root", child: { type: "action", call: "B" } },
            {
                type: "root",
                child: {
                    entry: { call: "Entry" },
                    while: { call: "Yes" },
                    type: "sequence",
                    children: [
                        { call: "A", type: "action", args: [1, "b"] },
                        { type: "wait", duration: 10 },
                        {
                            type: "repeat",
                            iterations: 2,
                            child: { type: "condition", call: "Yes", exit: { call: "Exit" } }
                        },
                        { type: "branch", ref: "Sub" }
                    ]
                }
            }
        ];

        const restoreInto = (from: Definition, into: Definition) => {
            const source = createRig(from, { A: State.SUCCEEDED });
            source.tree.step();
            const target = createRig(into, { A: State.SUCCEEDED });
            target.tree.restore(JSON.parse(JSON.stringify(source.tree.snapshot())));

            assert.deepEqual(target.tree.getTreeNodeDetails(), source.tree.getTreeNodeDetails());
        };

        it("an MDSL snapshot restores into a JSON tree", () => restoreInto(mdsl, json));
        it("a JSON snapshot restores into an MDSL tree", () => restoreInto(json, mdsl));
        it("a snapshot of a single root node object restores into an MDSL tree", () =>
            restoreInto({ type: "root", child: { type: "action", call: "A", args: [] } }, "root { action [A] }"));
        it("a definition with its default values written out restores into one without them", () =>
            restoreInto(
                {
                    type: "root",
                    child: {
                        type: "action",
                        call: "A",
                        args: [],
                        while: { call: "Yes", args: [], succeedOnAbort: false }
                    }
                },
                { type: "root", child: { type: "action", call: "A", while: { call: "Yes" } } }
            ));
        it("a definition with its root nodes in another order restores into the same definition", () =>
            restoreInto(json, [json[1], json[0]]));
        it("an MDSL snapshot restores into a tree of the same MDSL with other spacing", () =>
            restoreInto(
                "root{sequence{action[A]action[B]}}",
                "root {\n  sequence {\n    action [A]\n    action [B]\n  }\n}"
            ));
    });

    describe("restores a sequence part way through so that it", () => {
        it("carries on from the running child", () => {
            const results: Record<string, State | undefined> = { A: State.SUCCEEDED, B: undefined, C: State.SUCCEEDED };
            const { original, restored } = snapshotAndRestore(
                "root { sequence { action [A] action [B] action [C] } }",
                results,
                1
            );

            assert.strictEqual(findNode(restored.tree, "action", "A").state, State.SUCCEEDED);
            assert.strictEqual(findNode(restored.tree, "action", "B").state, State.RUNNING);
            assert.strictEqual(findNode(restored.tree, "action", "C").state, State.READY);
            assert.isTrue(restored.tree.isRunning());

            stepInLockstep(original, restored, 2, (step) => {
                if (step === 1) {
                    results.B = State.SUCCEEDED;
                }
            });

            assert.strictEqual(restored.tree.getState(), State.SUCCEEDED);
            assert.deepEqual(restored.calls, ["B", "B", "C"]);
        });
    });

    describe("restores independently of the tree so that", () => {
        const definition = `root {
            sequence {
                action [A]
                lotto { action [B] action [C] }
                repeat [2,3] { action [D] }
                wait [100]
                action [E]
            }
        }`;

        // Takes snapshots, as plain objects, of a tree that is stepped through to completion.
        const snapshotsOfSteppedTree = () => {
            const results: Record<string, State | undefined> = { A: State.SUCCEEDED, B: undefined, D: undefined };
            const rig = createRig(definition, results, { random: createRandom([0.7, 0.2]) });
            const snapshots: BehaviourTreeSnapshot[] = [];

            for (let step = 0; step < 8; step++) {
                snapshots.push(JSON.parse(JSON.stringify(rig.tree.snapshot())));

                if (step === 1) {
                    results.B = State.SUCCEEDED;
                } else if (step === 2) {
                    results.D = State.SUCCEEDED;
                }

                clock.tick(40);
                rig.tree.step();
            }

            return { rig, snapshots };
        };

        const allSucceed = { A: State.SUCCEEDED, B: State.SUCCEEDED, C: State.SUCCEEDED, D: State.SUCCEEDED };

        it("restoring does not call onNodeStateChange and the next step reports changes as usual", () => {
            for (const snapshot of snapshotsOfSteppedTree().snapshots) {
                const changes: { previousState: State; state: State }[] = [];
                const restored = createRig(definition, allSucceed, {
                    random: createRandom([0.7, 0.2]),
                    onNodeStateChange: (change) => changes.push(change)
                });

                // Leave the tree part way through, so that the restore replaces states that are not READY.
                restored.tree.step();
                restored.tree.step();
                changes.length = 0;

                restored.tree.restore(snapshot);

                assert.deepEqual(changes, []);

                restored.tree.step();

                assert.isNotEmpty(changes);
                assert.isTrue(changes.every((change) => change.previousState !== change.state));
            }
        });

        it("stepping the tree does not change a snapshot of it", () => {
            const { rig, snapshots } = snapshotsOfSteppedTree();
            const expected = JSON.stringify(snapshots);

            for (let step = 0; step < 8; step++) {
                clock.tick(40);
                rig.tree.step();
            }

            assert.strictEqual(JSON.stringify(snapshots), expected);
        });

        it("stepping a restored tree does not change the snapshot, and a snapshot taken right after restoring equals it", () => {
            const { snapshots } = snapshotsOfSteppedTree();
            const expected = JSON.stringify(snapshots);

            snapshots.forEach((snapshot, index) => {
                const restored = createRig(definition, allSucceed, { random: createRandom([0.7, 0.2]) });
                restored.tree.restore(snapshot);

                assert.deepEqual(JSON.parse(JSON.stringify(restored.tree.snapshot())), JSON.parse(expected)[index]);

                for (let step = 0; step < 8; step++) {
                    clock.tick(40);
                    restored.tree.step();
                }
            });

            assert.strictEqual(JSON.stringify(snapshots), expected);
        });

        it("stepping a restored tree does not change a snapshot with a settled promise", async () => {
            const promiseDefinition = "root { sequence { action [P] action [A] } }";
            const agent = { P: () => Promise.resolve(State.SUCCEEDED), A: () => undefined };
            const original = new BehaviourTree(promiseDefinition, agent);
            original.step();
            await Promise.resolve();

            const snapshot = JSON.parse(JSON.stringify(original.snapshot()));
            const expected = JSON.stringify(snapshot);
            const restored = new BehaviourTree(promiseDefinition, agent);
            restored.restore(snapshot);

            assert.strictEqual(JSON.stringify(restored.snapshot()), expected);

            restored.step();
            restored.step();

            assert.strictEqual(JSON.stringify(snapshot), expected);
        });
    });
});
